# Lesson 3 Part B: Repository Statistics and Blame Analysis

## Introduction to Repository Analysis

The Aider project implements a sophisticated repository analysis system through the `scripts/blame.py` script. This system provides detailed insights into code ownership, contribution patterns, and project evolution over time. Understanding this system is crucial for project maintenance and team coordination.

## File Structure and Organization

The blame analysis system is organized as follows:

```
scripts/
├── blame.py           # Main blame analysis script
└── update-blame.sh    # Shell script for automated blame updates
```

## Core Components and Functionality

### 1. Git Integration and Version Analysis

The script implements comprehensive Git integration for analyzing repository history. It uses Git's blame functionality to track changes and attribute them to authors. The core functionality includes:

```python
def get_commit_authors(commits):
    commit_to_author = dict()
    for commit in commits:
        author = run(["git", "show", "-s", "--format=%an", commit]).strip()
        commit_message = run(["git", "show", "-s", "--format=%s", commit]).strip()
        if commit_message.lower().startswith("aider:"):
            author += " (aider)"
        commit_to_author[commit] = author
```

### 2. Analysis Components

#### Version Tag Management
The script handles semantic versioning to track changes between releases:

```python
def get_latest_version_tag():
    all_tags = run(["git", "tag", "--sort=-v:refname"]).strip().split("\n")
    for tag in all_tags:
        if semver.Version.is_valid(tag[1:]) and tag.endswith(".0"):
            return tag
```

#### File-level Analysis
The system analyzes individual files to track changes and contributions:

```python
def get_counts_for_file(start_tag, end_tag, authors, fname):
    try:
        if end_tag:
            text = run(["git", "blame", f"{start_tag}..{end_tag}", "--", fname])
        else:
            text = run(["git", "blame", f"{start_tag}..HEAD", "--", fname])
```

### 3. Report Generation

The script generates detailed YAML reports containing:
- Author contributions
- File-level statistics
- Version comparisons
- Timeline analysis

Example report structure:
```yaml
- start_tag: v0.1.0
  end_tag: v0.2.0
  end_date: "2024-03-15"
  file_counts:
    file1.py:
      author1: 150
      author2: 75
  grand_total:
    author1: 500
    author2: 250
  total_lines: 750
  aider_total: 300
  aider_percentage: 40.0
```

## Usage and Operation

### Running the Analysis

1. Basic blame analysis:
   ```bash
   ./scripts/blame.py v0.1.0
   ```

2. Analysis between specific versions:
   ```bash
   ./scripts/blame.py v0.1.0 --end-tag v0.2.0
   ```

3. Generating comprehensive reports:
   ```bash
   ./scripts/blame.py v0.1.0 --all --output report.yml
   ```

### Automated Updates

The `update-blame.sh` script automates regular blame analysis:

```bash
#!/bin/bash
set -e
./scripts/blame.py v0.1.0 --all --output aider/website/_data/blame.yml
```

## Analysis Features

### 1. Author Attribution

The system carefully tracks authorship, with special handling for:
- Human contributors
- AI-generated code (marked with "aider")
- Co-authored commits
- Automated system changes

### 2. Timeline Analysis

The script can analyze changes over time:
```python
def get_tag_date(tag):
    date_str = run(["git", "log", "-1", "--format=%ai", tag]).strip()
    return datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S %z")
```

### 3. File Type Filtering

The system intelligently filters relevant files:
```python
files = [
    f for f in files
    if f.endswith((".py", ".scm", ".sh", "Dockerfile", "Gemfile"))
    or (f.startswith(".github/workflows/") and f.endswith(".yml"))
]
```

## Advanced Features

### 1. Incremental Analysis

The script supports incremental analysis between versions:
```python
def process_all_tags_since(start_tag):
    tags = get_all_tags_since(start_tag)
    results = []
    for i in range(len(tags) - 1):
        start_tag, end_tag = tags[i], tags[i + 1]
        results.append(blame(start_tag, end_tag))
```

### 2. Statistical Aggregation

The system provides various statistical aggregations:
- Per-file statistics
- Author-based metrics
- Timeline-based analysis
- Type-based grouping

## Best Practices and Guidelines

When working with the blame analysis system:

1. Regular Updates: Maintain up-to-date statistics by running the analysis regularly.

2. Version Control: Always specify version tags for consistent analysis.

3. Report Management: Store generated reports in version control for historical tracking.

4. Performance Considerations: For large repositories, use incremental analysis.

5. Data Interpretation: Consider context when interpreting blame statistics:
   - Code refactoring may shift authorship
   - Automated changes should be considered separately
   - Co-authored contributions need careful attribution

## Error Handling and Edge Cases

The script implements robust error handling:

```python
def get_counts_for_file(start_tag, end_tag, authors, fname):
    try:
        # ... blame analysis ...
    except subprocess.CalledProcessError as e:
        if "no such path" in str(e).lower():
            return None
        else:
            print(f"Warning: Unable to blame file {fname}. Error: {e}", 
                  file=sys.stderr)
            return None
```

This ensures reliable operation even with:
- Missing files
- Invalid tags
- Corrupted history
- Permission issues
