# Lesson 3 Part A: Issue Management System in Aider

## Introduction to Automated Issue Management

The Aider project implements a sophisticated issue management system through the `scripts/issues.py` script. This system automates several critical maintenance tasks related to GitHub issues, ensuring efficient project management and consistent handling of user reports and feature requests.

## File Structure and Organization

The issue management system is organized as follows:

```
scripts/
└── issues.py       # Main issue management script
```

## Core Components and Functionality

### 1. Environment Setup and Configuration

The script begins by establishing necessary connections to GitHub's API using environment variables. A crucial requirement is the `GITHUB_TOKEN` environment variable, which should be set in your `.env` file:

```python
GITHUB_API_URL = "https://api.github.com"
REPO_OWNER = "Aider-AI"
REPO_NAME = "aider"
TOKEN = os.getenv("GITHUB_TOKEN")
```

This configuration enables secure authentication with GitHub's API while keeping sensitive credentials separate from the codebase.

### 2. Issue Collection and Processing

The script implements a robust pagination system to collect all repository issues. This is particularly important for repositories with many issues, as GitHub's API limits results per page. The `get_issues()` function demonstrates effective pagination handling:

```python
def get_issues(state="open"):
    issues = []
    page = 1
    per_page = 100
    
    while True:
        response = requests.get(
            f"{GITHUB_API_URL}/repos/{REPO_OWNER}/{REPO_NAME}/issues",
            headers=headers,
            params={"state": state, "page": page, "per_page": per_page},
        )
        response.raise_for_status()
        page_issues = response.json()
        if not page_issues:
            break
        issues.extend(page_issues)
        page += 1
```

### 3. Automated Issue Management Features

The script implements several key automation features:

#### Duplicate Issue Detection
The system identifies potential duplicate issues by analyzing issue titles and content. It uses pattern matching to identify similar issues, particularly focusing on error messages and stack traces. The `group_issues_by_subject()` function demonstrates this functionality:

```python
def group_issues_by_subject(issues):
    grouped_issues = defaultdict(list)
    pattern = r"Uncaught .+ in .+ line \d+"
    for issue in issues:
        if re.search(pattern, issue["title"]):
            subject = issue["title"]
            grouped_issues[subject].append(issue)
    return grouped_issues
```

#### Stale Issue Management
The script implements a three-stage approach to handling stale issues:
1. After 14 days of inactivity, issues are marked as stale with a warning comment
2. A 7-day grace period is provided for response
3. If no activity occurs during the grace period, the issue is automatically closed

This is implemented through the `handle_stale_issues()` and `handle_stale_closing()` functions.

#### Automated Comments
The system uses predefined comment templates for consistent communication:
- Duplicate issue notifications
- Stale warnings
- Closure notifications

Example template:
```python
STALE_COMMENT = """I'm labeling this issue as stale because it has been open for 2 weeks with no activity. If there are no additional comments, it will be closed in 7 days."""
```

## Usage and Operation

### Running the Script

To execute the issue management system:

1. Ensure environment setup:
   ```bash
   export GITHUB_TOKEN=your_token_here
   ```

2. Run the script:
   ```bash
   python scripts/issues.py [--yes]
   ```
   The `--yes` flag enables automatic mode without prompts.

### Common Operations

#### Managing Unlabeled Issues
The script automatically identifies unlabeled issues with maintainer comments and can apply appropriate labels:
```python
def handle_unlabeled_issues(all_issues, auto_yes):
    unlabeled_issues = find_unlabeled_with_paul_comments(all_issues)
    for issue in unlabeled_issues:
        # Add 'question' label
        url = f"{GITHUB_API_URL}/repos/{REPO_OWNER}/{REPO_NAME}/issues/{issue['number']}"
        response = requests.patch(url, headers=headers, json={"labels": ["question"]})
```

#### Handling Stale Issues
The script implements a careful process for managing stale issues:
1. Detection of inactive issues
2. Warning notification
3. Grace period monitoring
4. Automatic closure if necessary

## Error Handling and Reliability

The script implements robust error handling throughout:
- API rate limit management
- Network error handling
- Invalid response handling
- User permission verification

Example error handling pattern:
```python
try:
    response = requests.get(url, headers=headers)
    response.raise_for_status()
except requests.exceptions.RequestException as e:
    print(f"Error accessing GitHub API: {e}")
    return
```

## Best Practices and Guidelines

When working with the issue management system:

1. Regular Execution: Run the script periodically (e.g., daily or weekly) to maintain consistent issue management.

2. API Token Security: Always use environment variables for sensitive credentials. Never hard-code tokens.

3. Testing Changes: Before implementing new automation rules, test them thoroughly in a development environment.

4. Communication: Ensure automated messages are clear, professional, and helpful to users.

5. Monitoring: Regularly review the script's actions to ensure it's working as intended and adjust thresholds if needed.
