# Lesson 2B: Version Management with versionbump.py

## Introduction to Version Management

Version management in Aider is handled through a sophisticated Python script (versionbump.py) that automates the entire process of version updates, git tagging, and development version management. This system ensures consistent and reliable version control across the project.

## Version Management File Structure

```
scripts/
└── versionbump.py      # Main version management script

aider/
└── __init__.py         # Contains version information
```

## Understanding versionbump.py

### Script Architecture

The version bump script is organized into several key components:

1. Pre-flight Checks:
   ```python
   def check_branch():
       branch = subprocess.run(
           ["git", "rev-parse", "--abbrev-ref", "HEAD"],
           capture_output=True,
           text=True
       ).stdout.strip()
       if branch != "main":
           print("Error: Not on the main branch.")
           sys.exit(1)
   ```

2. Working Directory Validation:
   ```python
   def check_working_directory_clean():
       status = subprocess.run(
           ["git", "status", "--porcelain"],
           capture_output=True,
           text=True
       ).stdout
       if status:
           print("Error: Working directory is not clean.")
           sys.exit(1)
   ```

### Version Update Process

The script handles version updates through several stages:

1. Version Validation:
   - Ensures new version follows x.y.z format
   - Validates version is greater than current
   - Checks version string formatting

2. File Updates:
   - Modifies aider/__init__.py with new version
   - Creates appropriate git commits
   - Generates version tags

3. Development Version Management:
   - Automatically increments to next development version
   - Appends .dev suffix to version number
   - Updates repository with development version

## Usage Guide

### Basic Version Bump

1. Standard Version Update:
   ```bash
   ./scripts/versionbump.py 1.2.3
   ```

2. Dry Run Mode:
   ```bash
   ./scripts/versionbump.py 1.2.3 --dry-run
   ```

### Version Bump Workflow

1. Pre-bump Checklist:
   - Ensure you're on main branch
   - Pull latest changes
   - Clean working directory
   - All tests passing

2. Running the Version Bump:
   ```bash
   # 1. Switch to main branch
   git checkout main
   
   # 2. Pull latest changes
   git pull origin main
   
   # 3. Run version bump
   ./scripts/versionbump.py x.y.z
   ```

3. Post-bump Verification:
   - Check git tags
   - Verify __init__.py version
   - Confirm pushes completed

## Version Number Management

### Version Number Format

The script enforces semantic versioning (SemVer):

1. Production Versions:
   - Format: x.y.z
   - Example: 1.2.3

2. Development Versions:
   - Format: x.y.z.dev
   - Example: 1.2.4.dev

### Version Increment Logic

```python
new_version = version.parse(new_version_str)
incremented_version = version.Version(
    f"{new_version.major}.{new_version.minor}.{new_version.micro + 1}"
)
```

## Git Integration

### Tag Management

The script handles git tags systematically:

1. Release Tags:
   ```python
   git_commands = [
       ["git", "add", "aider/__init__.py"],
       ["git", "commit", "-m", f"version bump to {new_version}"],
       ["git", "tag", f"v{new_version}"],
       ["git", "push", "origin"],
       ["git", "push", "origin", f"v{new_version}", "--no-verify"],
   ]
   ```

2. Development Tags:
   ```python
   git_commands_dev = [
       ["git", "add", "aider/__init__.py"],
       ["git", "commit", "-m", f"set version to {new_dev_version}"],
       ["git", "tag", f"v{new_dev_version}"],
       ["git", "push", "origin", "--no-verify"],
       ["git", "push", "origin", f"v{new_dev_version}", "--no-verify"],
   ]
   ```

## Error Handling and Validation

### Pre-execution Checks

1. Branch Validation:
   - Ensures operations on main branch
   - Verifies branch is up-to-date
   - Checks for clean working directory

2. Version Validation:
   - Validates version format
   - Ensures version increment
   - Checks for version conflicts

### Error Recovery

1. Common Issues:
   - Branch mismatch resolution
   - Working directory cleanup
   - Version conflict resolution

2. Recovery Steps:
   - Clear procedure for each error type
   - Validation before proceeding
   - Rollback procedures if needed

## Best Practices

### Version Management Guidelines

1. Version Planning:
   - Plan version numbers carefully
   - Follow semantic versioning principles
   - Consider impact on dependencies

2. Release Process:
   - Document changes before version bump
   - Test thoroughly before release
   - Verify all CI/CD pipelines pass

3. Post-Release Verification:
   - Check package availability
   - Verify documentation updates
   - Monitor for deployment issues

This comprehensive guide provides a detailed understanding of Aider's version management system, ensuring reliable and consistent version control across the project.