# Practical Exercises for Documentation and Version Management

## Documentation Management Exercises

### Exercise 1: Setting Up Local Documentation Environment

#### Objective
Learn to set up and configure a local documentation development environment using Docker and Jekyll.

#### Prerequisites
- Docker installed
- Git repository cloned
- Basic command line knowledge

#### Steps

1. Initial Environment Setup
```bash
# Create a practice branch
git checkout -b doc-practice-yourname

# Ensure you're in project root
cd /path/to/aider

# Create test content directory
mkdir -p tmp.practice/website
```

2. Creating Test Documentation
```bash
# Create a test markdown file
cat > tmp.practice/website/test-page.md << EOF
---
layout: default
title: Test Documentation Page
---

# Test Documentation

This is a test page for learning Jekyll documentation management.

## Section 1

Content for section 1.

## Section 2

Content for section 2.
EOF
```

3. Custom Docker Configuration
```bash
# Create a modified Dockerfile for practice
cat > tmp.practice/Dockerfile.jekyll << EOF
FROM bretfisher/jekyll-serve

WORKDIR /site
COPY website /site

RUN apt-get update && apt-get install libcurl4
RUN bundle install --retry 5 --jobs 20

ENTRYPOINT [ "docker-entrypoint.sh" ]
CMD [ "bundle", "exec", "jekyll", "serve", "--force_polling", "-H", "0.0.0.0", "-P", "4001" ]
EOF
```

4. Build and Run Scripts
```bash
# Create build script
cat > tmp.practice/jekyll_build.sh << EOF
#!/bin/bash
docker build -t practice-jekyll-site -f Dockerfile.jekyll .
EOF

# Create run script
cat > tmp.practice/jekyll_run.sh << EOF
#!/bin/bash
docker run \
       --rm \
       -v "\$PWD/website:/site" \
       -p 4001:4001 \
       -e HISTFILE=/site/.bash_history \
       -it \
       practice-jekyll-site
EOF

# Make scripts executable
chmod +x tmp.practice/jekyll_*.sh
```

#### Tasks

1. Basic Setup Verification:
   - Run the build script
   - Start the documentation server
   - Access the test page at http://localhost:4001/test-page
   - Document any errors encountered and their resolution

2. Content Modifications:
   - Add a new section to test-page.md while the server is running
   - Observe live updates
   - Create a new page linking to test-page.md
   - Verify internal links work correctly

3. Error Handling:
   - Intentionally introduce a YAML front matter error
   - Observe error messages
   - Fix the error and verify recovery
   - Document the troubleshooting process

### Exercise 2: Advanced Documentation Features

#### Objective
Understand and implement advanced Jekyll features used in Aider's documentation.

#### Tasks

1. Create a Custom Layout:
```bash
# Create a new layout file
mkdir -p tmp.practice/website/_layouts
cat > tmp.practice/website/_layouts/custom.html << EOF
<!DOCTYPE html>
<html>
<head>
    <title>{{ page.title }}</title>
</head>
<body>
    <header>
        <h1>{{ page.title }}</h1>
    </header>
    <main>
        {{ content }}
    </main>
    <footer>
        <p>Last updated: {{ page.last_modified_at }}</p>
    </footer>
</body>
</html>
EOF
```

2. Implement Custom Includes:
```bash
# Create an include file
mkdir -p tmp.practice/website/_includes
cat > tmp.practice/website/_includes/warning.html << EOF
<div class="warning">
    <strong>Warning:</strong> {{ include.message }}
</div>
EOF
```

3. Use Data Files:
```bash
# Create a data file
mkdir -p tmp.practice/website/_data
cat > tmp.practice/website/_data/features.yml << EOF
- name: Documentation
  description: Comprehensive project documentation
  status: active

- name: Version Control
  description: Automated version management
  status: active

- name: Testing
  description: Extensive test coverage
  status: in-progress
EOF
```

#### Evaluation Criteria
- Successful server setup and operation
- Proper handling of content updates
- Error recovery implementation
- Documentation of process and issues

## Version Management Exercises

### Exercise 1: Version Bump Simulation

#### Objective
Practice version management procedures in a controlled environment.

#### Setup

1. Create Practice Environment:
```bash
# Create practice directory
mkdir -p tmp.practice/version-test
cd tmp.practice/version-test

# Initialize git repository
git init
git config user.email "practice@example.com"
git config user.name "Practice User"

# Create initial files
mkdir aider
cat > aider/__init__.py << EOF
__version__ = "0.1.0"
EOF

# Initial commit
git add .
git commit -m "Initial commit"
```

2. Create Practice Version Bump Script:
```python
#!/usr/bin/env python3
import re
import sys
from packaging import version

def bump_version(new_version_str, dry_run=False):
    # Validate version format
    if not re.match(r"^\d+\.\d+\.\d+$", new_version_str):
        raise ValueError(f"Invalid version format: {new_version_str}")
    
    # Read current version
    with open("aider/__init__.py", "r") as f:
        content = f.read()
    
    current_version = re.search(r'__version__ = "(.*?)"', content).group(1)
    
    # Validate version increment
    if version.parse(new_version_str) <= version.parse(current_version):
        raise ValueError(f"New version must be greater than {current_version}")
    
    # Update version
    updated_content = re.sub(
        r'__version__ = ".*?"',
        f'__version__ = "{new_version_str}"',
        content
    )
    
    if not dry_run:
        with open("aider/__init__.py", "w") as f:
            f.write(updated_content)
        print(f"Updated version to {new_version_str}")
    else:
        print(f"Would update version to {new_version_str}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: ./version_bump.py NEW_VERSION [--dry-run]")
        sys.exit(1)
    
    dry_run = "--dry-run" in sys.argv
    new_version = sys.argv[1]
    
    try:
        bump_version(new_version, dry_run)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
```

#### Tasks

1. Basic Version Bumping:
   - Run dry-run version bump
   - Perform actual version bump
   - Verify file changes
   - Create appropriate git commits and tags

2. Error Handling:
   - Attempt invalid version formats
   - Try downgrading version
   - Test with missing files
   - Document error messages

3. Git Integration:
   - Create version tags
   - Push changes to remote
   - Handle tag conflicts
   - Implement rollback procedures

### Exercise 2: Advanced Version Management

#### Objective
Handle complex version management scenarios and automate processes.

#### Tasks

1. Implement Development Versions:
```bash
# Modify version bump script to handle dev versions
cat >> version_bump.py << EOF

def create_dev_version(current_version):
    """Create development version after release."""
    v = version.parse(current_version)
    next_version = f"{v.major}.{v.minor}.{v.micro + 1}.dev"
    return next_version
EOF
```

2. Auto-increment Script:
```bash
# Create auto-increment script
cat > auto_increment.sh << EOF
#!/bin/bash

# Get current version
current_version=$(grep '__version__' aider/__init__.py | cut -d'"' -f2)

# Split version
IFS='.' read -r major minor patch <<< "$current_version"

# Increment patch version
new_patch=$((patch + 1))
new_version="$major.$minor.$new_patch"

# Run version bump
./version_bump.py "$new_version"
EOF
chmod +x auto_increment.sh
```

#### Evaluation Criteria
- Successful version updates
- Proper error handling
- Git integration implementation
- Documentation of procedures

### Exercise 3: Integration Testing

#### Objective
Test version management in a simulated production environment.

#### Tasks

1. Create Test Release Workflow:
   - Set up CI simulation
   - Implement version checks
   - Test release procedures
   - Document release process

2. Handle Edge Cases:
   - Concurrent version bumps
   - Failed updates
   - Network issues
   - Recovery procedures

3. Documentation Updates:
   - Update change logs
   - Maintain version history
   - Document release notes
   - Update user guides

## Additional Challenges

### Documentation Challenges

1. Create Custom Jekyll Plugin:
   - Implement version display
   - Add last modified dates
   - Create custom filters
   - Handle multiple languages

2. Performance Optimization:
   - Implement caching
   - Optimize build time
   - Reduce Docker image size
   - Improve load times

### Version Management Challenges

1. Automated Release Notes:
   - Parse commit messages
   - Generate change logs
   - Categorize changes
   - Format release notes

2. Version Strategy:
   - Handle multiple branches
   - Manage pre-releases
   - Support hotfixes
   - Coordinate dependencies

## Submission Guidelines

For each exercise:
1. Document all steps taken
2. Provide screenshots where applicable
3. List any errors encountered and solutions
4. Suggest improvements to the process
5. Create a summary of lessons learned

## Resources

- Jekyll Documentation: https://jekyllrb.com/docs/
- Docker Documentation: https://docs.docker.com/
- Git Documentation: https://git-scm.com/doc
- Python Packaging Guide: https://packaging.python.org/