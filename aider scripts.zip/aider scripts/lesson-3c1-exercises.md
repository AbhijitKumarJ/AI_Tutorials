# Practical Exercises: Project Automation and Maintenance Tools

## Exercise Set 3: Hands-on Automation Tools Practice

### Part 1: Issue Management System Implementation

#### Exercise 3.1: Setting Up the Issue Management Environment

**Objective**: Configure and test the GitHub API integration for issue management.

**Setup Instructions**:

1. Create a GitHub Personal Access Token:
   ```bash
   # Create a .env file in your project root
   echo "GITHUB_TOKEN=your_token_here" > .env
   
   # Ensure the file is not tracked by git
   echo ".env" >> .gitignore
   ```

2. Validate Environment:
   ```python
   # Create a test script: test_github_connection.py
   import os
   import requests
   from dotenv import load_dotenv

   load_dotenv()
   token = os.getenv("GITHUB_TOKEN")
   headers = {"Authorization": f"token {token}"}
   
   response = requests.get(
       "https://api.github.com/repos/Aider-AI/aider/issues",
       headers=headers
   )
   print(f"Connection status: {response.status_code}")
   print(f"Rate limit remaining: {response.headers.get('X-RateLimit-Remaining')}")
   ```

#### Exercise 3.2: Implementing Custom Issue Labels

**Objective**: Create a system to automatically label issues based on content analysis.

1. Create a label analysis function:
```python
def analyze_issue_content(issue_body):
    labels = set()
    
    # Example patterns
    if "error:" in issue_body.lower():
        labels.add("bug")
    if "feature request" in issue_body.lower():
        labels.add("enhancement")
    if "help" in issue_body.lower():
        labels.add("question")
        
    return labels
```

2. Implement the labeling system:
```python
def auto_label_issues(issues):
    for issue in issues:
        if not issue["labels"]:
            labels = analyze_issue_content(issue["body"])
            if labels:
                url = f"{GITHUB_API_URL}/repos/{REPO_OWNER}/{REPO_NAME}/issues/{issue['number']}"
                response = requests.patch(
                    url,
                    headers=headers,
                    json={"labels": list(labels)}
                )
                print(f"Issue #{issue['number']} labeled with: {labels}")
```

#### Exercise 3.3: Implementing Issue Analytics

**Objective**: Create a system to analyze issue patterns and generate reports.

1. Create an analytics class:
```python
class IssueAnalytics:
    def __init__(self, issues):
        self.issues = issues
        self.stats = {}
    
    def analyze_response_times(self):
        response_times = []
        for issue in self.issues:
            created = datetime.strptime(issue["created_at"], "%Y-%m-%dT%H:%M:%SZ")
            if issue["comments"] > 0:
                comments_url = issue["comments_url"]
                response = requests.get(comments_url, headers=headers)
                first_comment = response.json()[0]
                first_response = datetime.strptime(
                    first_comment["created_at"],
                    "%Y-%m-%dT%H:%M:%SZ"
                )
                response_time = (first_response - created).total_seconds() / 3600
                response_times.append(response_time)
        
        self.stats["avg_response_time"] = sum(response_times) / len(response_times)
        return self.stats
```

### Part 2: Repository Statistics Implementation

#### Exercise 3.4: Custom Blame Analysis

**Objective**: Implement specialized blame analysis for specific file types.

1. Create a file type analyzer:
```python
class FileTypeAnalyzer:
    def __init__(self, repo_path):
        self.repo_path = repo_path
        self.stats = {}
    
    def analyze_file_types(self):
        file_types = defaultdict(int)
        authors_by_type = defaultdict(lambda: defaultdict(int))
        
        for root, _, files in os.walk(self.repo_path):
            if ".git" in root:
                continue
            
            for file in files:
                ext = os.path.splitext(file)[1]
                if ext:
                    file_types[ext] += 1
                    
                    # Get blame info for the file
                    try:
                        blame_output = subprocess.check_output(
                            ["git", "blame", "--line-porcelain", file],
                            cwd=self.repo_path,
                            text=True
                        )
                        
                        current_author = None
                        for line in blame_output.split("\n"):
                            if line.startswith("author "):
                                current_author = line[7:]
                                authors_by_type[ext][current_author] += 1
                    except subprocess.CalledProcessError:
                        continue
        
        self.stats["file_types"] = dict(file_types)
        self.stats["authors_by_type"] = {
            k: dict(v) for k, v in authors_by_type.items()
        }
        return self.stats
```

#### Exercise 3.5: Timeline Analysis Implementation

**Objective**: Create a system to analyze repository activity over time.

1. Implement a timeline analyzer:
```python
class TimelineAnalyzer:
    def __init__(self, repo_path):
        self.repo_path = repo_path
        self.activity = defaultdict(lambda: defaultdict(int))
    
    def analyze_activity(self, start_date=None, end_date=None):
        cmd = ["git", "log", "--format=%at %ae", "--numstat"]
        if start_date and end_date:
            cmd.extend([f"--since={start_date}", f"--until={end_date}"])
        
        try:
            log_output = subprocess.check_output(
                cmd,
                cwd=self.repo_path,
                text=True
            )
            
            current_timestamp = None
            current_author = None
            
            for line in log_output.split("\n"):
                if not line:
                    continue
                    
                if line[0].isdigit():
                    timestamp, author = line.split()
                    current_timestamp = datetime.fromtimestamp(
                        int(timestamp)
                    ).strftime("%Y-%m")
                    current_author = author
                elif line[0].isdigit() or line[0] == "-":
                    additions, deletions, _ = line.split("\t")
                    if additions != "-":
                        self.activity[current_timestamp]["additions"] += int(additions)
                    if deletions != "-":
                        self.activity[current_timestamp]["deletions"] += int(deletions)
                    self.activity[current_timestamp]["commits"] += 1
            
            return dict(self.activity)
        except subprocess.CalledProcessError as e:
            print(f"Error analyzing timeline: {e}")
            return None
```

### Implementation Validation

For each exercise, validate your implementation using these criteria:

1. Issue Management System:
   - Successfully connects to GitHub API
   - Correctly identifies and labels issues
   - Generates accurate analytics reports
   - Handles rate limiting and errors gracefully

2. Repository Analysis:
   - Accurately tracks file changes
   - Correctly attributes changes to authors
   - Generates meaningful timeline data
   - Handles repository edge cases (empty files, binary files, etc.)

### Testing Procedures

1. Issue Management Tests:
```python
def test_issue_management():
    # Test API connection
    assert test_github_connection() == 200
    
    # Test label analysis
    test_issue = {"body": "Error: Application crashes on startup"}
    labels = analyze_issue_content(test_issue["body"])
    assert "bug" in labels
    
    # Test analytics
    analytics = IssueAnalytics(get_test_issues())
    stats = analytics.analyze_response_times()
    assert "avg_response_time" in stats
```

2. Repository Analysis Tests:
```python
def test_repo_analysis():
    # Test file type analysis
    analyzer = FileTypeAnalyzer("./")
    stats = analyzer.analyze_file_types()
    assert ".py" in stats["file_types"]
    
    # Test timeline analysis
    timeline = TimelineAnalyzer("./")
    activity = timeline.analyze_activity()
    assert len(activity) > 0
```

### Documentation Requirements

For each implementation:

1. Create detailed inline documentation
2. Generate API documentation using docstrings
3. Provide usage examples
4. Document error handling procedures
5. Include performance considerations

### Performance Optimization Tasks

1. Implement caching for API requests:
```python
from functools import lru_cache

@lru_cache(maxsize=100)
def get_issue_comments(issue_id):
    url = f"{GITHUB_API_URL}/repos/{REPO_OWNER}/{REPO_NAME}/issues/{issue_id}/comments"
    return requests.get(url, headers=headers).json()
```

2. Optimize blame analysis for large repositories:
```python
def optimize_blame_analysis(repo_path):
    # Use git's cache for better performance
    os.environ["GIT_BLAME_USAGE"] = "1"
    
    # Implement parallel processing for multiple files
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = [
            executor.submit(analyze_file, fname)
            for fname in get_repository_files(repo_path)
        ]
        return [f.result() for f in futures]
```
