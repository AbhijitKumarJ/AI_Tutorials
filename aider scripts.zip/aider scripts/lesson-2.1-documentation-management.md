# Lesson 2A: Documentation Management with Jekyll

## Introduction to Documentation System

The Aider project uses Jekyll, a static site generator, for managing its documentation. This lesson explores how the project handles documentation building and serving through Docker containers, ensuring consistency across different development environments.

## Documentation File Structure

The documentation system is organized as follows:

```
scripts/
├── Dockerfile.jekyll    # Jekyll container configuration
├── jekyll_build.sh      # Build script for documentation
└── jekyll_run.sh        # Script to serve documentation locally

website/                 # Main documentation content
├── Gemfile             # Ruby dependencies
├── _config.yml         # Jekyll configuration
├── assets/            # Static assets
├── docs/              # Main documentation files
├── _data/             # Data files for Jekyll
├── _includes/         # Reusable components
├── _layouts/          # Page templates
└── _posts/            # Blog posts and updates
```

## Jekyll Docker Environment

### Understanding Dockerfile.jekyll

The Dockerfile.jekyll is designed to create a consistent environment for building and serving documentation:

```dockerfile
FROM bretfisher/jekyll-serve

WORKDIR /site
COPY website /site

RUN apt-get update && apt-get install libcurl4
RUN bundle install --retry 5 --jobs 20

ENTRYPOINT [ "docker-entrypoint.sh" ]
CMD [ "bundle", "exec", "jekyll", "serve", "--force_polling", "-H", "0.0.0.0", "-P", "4000" ]
```

Key aspects of this Dockerfile:
1. Uses bretfisher/jekyll-serve as the base image, which provides a pre-configured Jekyll environment
2. Sets up the working directory and copies website content
3. Installs additional dependencies like libcurl4
4. Configures bundle installation with retry logic for reliability
5. Sets up the command to serve the documentation

## Documentation Build Process

### jekyll_build.sh Analysis

The jekyll_build.sh script handles the Docker image building process:

```bash
#!/bin/bash
docker build -t my-jekyll-site -f scripts/Dockerfile.jekyll .
```

This script:
1. Creates a Docker image named 'my-jekyll-site'
2. Uses the Dockerfile.jekyll configuration
3. Builds from the current directory context (.)

Key considerations for running the build:
- Must be run from the project root directory
- Requires Docker to be installed and running
- Builds all documentation into a contained environment

## Local Development Server

### jekyll_run.sh Deep Dive

The jekyll_run.sh script provides a development environment for documentation:

```bash
#!/bin/bash
docker run \
       --rm \
       -v "$PWD/aider/website:/site" \
       -p 4000:4000 \
       -e HISTFILE=/site/.bash_history \
       -it \
       my-jekyll-site
```

Important features:
1. Volume mounting (-v flag):
   - Maps local website directory to container
   - Enables real-time editing of documentation
   - Preserves changes across container restarts

2. Port mapping (-p flag):
   - Maps container port 4000 to host port 4000
   - Enables access via http://localhost:4000

3. Environment configuration:
   - Maintains bash history for convenience
   - Interactive terminal enabled (-it flags)
   - Automatic cleanup on exit (--rm flag)

## Usage Guide

### Setting Up Documentation Environment

1. Initial Setup:
   ```bash
   # From project root
   ./scripts/jekyll_build.sh
   ```

2. Starting Development Server:
   ```bash
   ./scripts/jekyll_run.sh
   ```

3. Accessing Documentation:
   - Open browser to http://localhost:4000
   - Changes to files in aider/website/ reflect immediately
   - Use Ctrl+C to stop the server

### Best Practices for Documentation Development

1. File Organization:
   - Keep related documentation files together
   - Use meaningful file names
   - Follow Jekyll's naming conventions for posts

2. Content Updates:
   - Always test changes locally before committing
   - Use Jekyll's built-in drafts feature for work in progress
   - Verify internal links work correctly

3. Performance Considerations:
   - Optimize images before adding to assets
   - Use Jekyll's incremental build feature for faster development
   - Leverage Jekyll's caching mechanisms

## Troubleshooting Common Issues

1. Port Conflicts:
   - If port 4000 is in use, modify jekyll_run.sh to use a different port
   - Check for other Jekyll instances running

2. Build Failures:
   - Verify Docker is running
   - Check for sufficient disk space
   - Ensure all required files are present

3. Content Not Updating:
   - Clear Jekyll cache
   - Verify file permissions
   - Check for syntax errors in Jekyll front matter

## Security Considerations

1. Docker Security:
   - Regular updates of base images
   - Proper permission management
   - Careful handling of exposed ports

2. Content Security:
   - Sanitize user inputs in documentation
   - Protect sensitive information
   - Regular security audits of dependencies

This comprehensive guide provides the foundation for managing Aider's documentation system effectively, ensuring consistency and maintainability across the project.