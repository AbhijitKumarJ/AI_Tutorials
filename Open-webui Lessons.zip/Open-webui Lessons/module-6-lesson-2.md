# Module 6, Lesson 2: Custom Feature Development

## Introduction

Welcome to Module 6, Lesson 2 of the Open WebUI Mastery course. This lesson focuses on developing custom features for Open WebUI, covering both frontend and backend development. We'll explore the plugin architecture, testing strategies, and best practices for implementing new functionality while maintaining security and performance.

## Prerequisites

Before starting this lesson, ensure you have:
- Completed Module 6, Lesson 1 (Development Environment Setup)
- Working knowledge of React and FastAPI
- Understanding of TypeScript and Python
- Familiarity with testing frameworks
- Basic knowledge of security principles

## Custom Feature Development Process

### Planning Phase

Before writing any code, follow this structured approach to feature planning:

1. **Feature Specification Document**
   Create a specification document template:

   ```markdown
   # Feature Specification: [Feature Name]
   
   ## Overview
   [Brief description of the feature]
   
   ## Requirements
   - Functional Requirements
   - Technical Requirements
   - Security Requirements
   - Performance Requirements
   
   ## Architecture
   - Frontend Components
   - Backend Services
   - Data Models
   - API Endpoints
   
   ## Testing Strategy
   - Unit Tests
   - Integration Tests
   - Performance Tests
   
   ## Security Considerations
   - Authentication
   - Authorization
   - Data Validation
   
   ## Implementation Timeline
   - Phase 1: [Description]
   - Phase 2: [Description]
   - Phase 3: [Description]
   ```

### Frontend Development

#### 1. Component Development

Create new React components following this structure:

```typescript
// src/components/features/MyFeature/index.tsx
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth';
import { ApiClient } from '@/lib/api';

interface MyFeatureProps {
  initialData?: any;
  onUpdate?: (data: any) => void;
}

export const MyFeature: React.FC<MyFeatureProps> = ({ 
  initialData,
  onUpdate 
}) => {
  const [data, setData] = useState(initialData);
  const { user } = useAuth();
  const api = new ApiClient();

  useEffect(() => {
    // Initialize component
    const fetchData = async () => {
      try {
        const result = await api.get('/api/feature-data');
        setData(result);
      } catch (error) {
        console.error('Failed to fetch data:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="p-4 bg-white rounded-lg shadow">
      {/* Component JSX */}
    </div>
  );
};
```

#### 2. State Management

Implement state management using React Context:

```typescript
// src/contexts/FeatureContext.tsx
import React, { createContext, useContext, useReducer } from 'react';

interface FeatureState {
  // State interface
}

interface FeatureContextType {
  state: FeatureState;
  dispatch: React.Dispatch<FeatureAction>;
}

const FeatureContext = createContext<FeatureContextType | undefined>(undefined);

export const FeatureProvider: React.FC<{ children: React.ReactNode }> = ({ 
  children 
}) => {
  const [state, dispatch] = useReducer(featureReducer, initialState);

  return (
    <FeatureContext.Provider value={{ state, dispatch }}>
      {children}
    </FeatureContext.Provider>
  );
};

export const useFeature = () => {
  const context = useContext(FeatureContext);
  if (context === undefined) {
    throw new Error('useFeature must be used within a FeatureProvider');
  }
  return context;
};
```

### Backend Development

#### 1. API Endpoint Development

Create new API endpoints following RESTful principles:

```python
# backend/open_webui/routers/feature.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from ..database import get_db
from ..models import FeatureModel
from ..schemas import FeatureSchema
from ..auth import get_current_user

router = APIRouter(prefix="/api/features", tags=["features"])

@router.get("/{feature_id}", response_model=FeatureSchema)
async def get_feature(
    feature_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Retrieve a specific feature by ID.
    
    Args:
        feature_id: The ID of the feature to retrieve
        db: Database session
        current_user: The authenticated user
        
    Returns:
        FeatureSchema: The requested feature
        
    Raises:
        HTTPException: If feature is not found or user lacks permission
    """
    feature = db.query(FeatureModel).filter(
        FeatureModel.id == feature_id
    ).first()
    
    if not feature:
        raise HTTPException(status_code=404, detail="Feature not found")
        
    if not feature.user_has_access(current_user):
        raise HTTPException(status_code=403, detail="Permission denied")
        
    return feature
```

#### 2. Database Models

Define SQLAlchemy models for your feature:

```python
# backend/open_webui/models/feature.py
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

from ..database import Base

class FeatureModel(Base):
    __tablename__ = "features"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    description = Column(String)
    user_id = Column(Integer, ForeignKey("users.id"))
    
    user = relationship("User", back_populates="features")
    
    def user_has_access(self, user):
        """Check if user has access to this feature."""
        return self.user_id == user.id or user.is_admin
```

### Plugin Architecture

#### 1. Plugin System Design

Create a plugin system that allows for easy extension:

```python
# backend/open_webui/plugins/base.py
from abc import ABC, abstractmethod
from typing import Dict, Any

class PluginBase(ABC):
    """Base class for all plugins."""
    
    @abstractmethod
    def initialize(self) -> None:
        """Initialize the plugin."""
        pass
        
    @abstractmethod
    def execute(self, context: Dict[str, Any]) -> Any:
        """Execute the plugin's main functionality."""
        pass
        
    @abstractmethod
    def cleanup(self) -> None:
        """Clean up any resources used by the plugin."""
        pass
```

#### 2. Plugin Implementation

Example of a custom plugin:

```python
# backend/open_webui/plugins/custom_feature.py
from typing import Dict, Any
from .base import PluginBase

class CustomFeaturePlugin(PluginBase):
    """Implementation of a custom feature plugin."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.initialized = False
        
    def initialize(self) -> None:
        """Set up plugin resources."""
        # Initialize plugin resources
        self.initialized = True
        
    def execute(self, context: Dict[str, Any]) -> Any:
        """Execute plugin logic."""
        if not self.initialized:
            raise RuntimeError("Plugin not initialized")
            
        # Plugin logic here
        result = self._process_data(context)
        return result
        
    def cleanup(self) -> None:
        """Clean up plugin resources."""
        self.initialized = False
        
    def _process_data(self, context: Dict[str, Any]) -> Any:
        """Internal method for data processing."""
        # Implementation details
        pass
```

### Testing Strategy

#### 1. Frontend Testing

Create comprehensive tests for React components:

```typescript
// src/components/features/MyFeature/index.test.tsx
import { render, screen, fireEvent } from '@testing-library/react';
import { MyFeature } from './index';
import { FeatureProvider } from '@/contexts/FeatureContext';

describe('MyFeature Component', () => {
  beforeEach(() => {
    // Setup test environment
  });

  test('renders feature component', () => {
    render(
      <FeatureProvider>
        <MyFeature />
      </FeatureProvider>
    );
    
    expect(screen.getByTestId('feature-container')).toBeInTheDocument();
  });

  test('handles user interaction', async () => {
    render(
      <FeatureProvider>
        <MyFeature />
      </FeatureProvider>
    );
    
    const button = screen.getByRole('button');
    await fireEvent.click(button);
    
    // Assert expected behavior
  });
});
```

#### 2. Backend Testing

Implement backend tests using pytest:

```python
# backend/tests/test_feature.py
import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from open_webui.models import FeatureModel
from open_webui.database import get_db

def test_create_feature(
    client: TestClient,
    db: Session,
    admin_token: str
):
    """Test feature creation endpoint."""
    response = client.post(
        "/api/features/",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "name": "Test Feature",
            "description": "Test Description"
        }
    )
    
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "Test Feature"
    
    # Verify database entry
    feature = db.query(FeatureModel).filter(
        FeatureModel.id == data["id"]
    ).first()
    assert feature is not None

def test_feature_access_control(
    client: TestClient,
    db: Session,
    user_token: str
):
    """Test feature access control."""
    # Test implementation
    pass
```

### Security Considerations

#### 1. Input Validation

Implement proper input validation:

```python
# backend/open_webui/schemas/feature.py
from pydantic import BaseModel, validator
import re

class FeatureCreate(BaseModel):
    name: str
    description: str
    
    @validator('name')
    def validate_name(cls, v):
        if not re.match(r'^[a-zA-Z0-9_-]+$', v):
            raise ValueError('Name contains invalid characters')
        return v
        
    @validator('description')
    def validate_description(cls, v):
        if len(v) > 1000:
            raise ValueError('Description too long')
        return v
```

#### 2. Authorization

Implement role-based access control:

```python
# backend/open_webui/auth/permissions.py
from functools import wraps
from fastapi import HTTPException, Depends
from ..models import User

def require_permission(permission: str):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, current_user: User = Depends(get_current_user), **kwargs):
            if not current_user.has_permission(permission):
                raise HTTPException(
                    status_code=403,
                    detail="Permission denied"
                )
            return await func(*args, current_user=current_user, **kwargs)
        return wrapper
    return decorator
```

### Performance Optimization

#### 1. Frontend Optimization

Implement performance optimizations:

```typescript
// src/components/features/MyFeature/index.tsx
import React, { memo, useMemo, useCallback } from 'react';

export const MyFeature: React.FC<MyFeatureProps> = memo(({ data }) => {
  const processedData = useMemo(() => {
    return expensiveOperation(data);
  }, [data]);

  const handleClick = useCallback(() => {
    // Handle click event
  }, []);

  return (
    <div>
      {/* Optimized rendering */}
    </div>
  );
});
```

#### 2. Backend Optimization

Implement database query optimization:

```python
# backend/open_webui/models/feature.py
from sqlalchemy import select
from sqlalchemy.orm import joinedload

async def get_feature_with_related(db: Session, feature_id: int):
    """Optimized query for fetching feature with related data."""
    query = (
        select(FeatureModel)
        .options(joinedload(FeatureModel.user))
        .where(FeatureModel.id == feature_id)
    )
    result = await db.execute(query)
    return result.scalar_one_or_none()
```

## Deployment Considerations

### 1. Feature Flags

Implement feature flags for controlled rollout:

```python
# backend/open_webui/config/features.py
class FeatureFlags:
    def __init__(self):
        self.flags = {}
        
    def is_enabled(self, feature_name: str, user_id: int = None) -> bool:
        """Check if a feature is enabled for a user."""
        if feature_name not in self.flags:
            return False
            
        flag = self.flags[feature_name]
        if user_id and 'users' in flag:
            return user_id in flag['users']
            
        return flag.get('enabled', False)
```

### 2. Documentation

Maintain comprehensive documentation:

```markdown
# Feature Documentation

## Overview
[Feature description and purpose]

## Technical Architecture
[Detailed technical implementation]

## Usage Guide
[How to use the feature]

## API Reference
[API endpoints and parameters]

## Configuration
[Configuration options]

## Troubleshooting
[Common issues and solutions]
```

## Conclusion

This lesson has covered the essential aspects of custom feature development in Open WebUI, including:
- Frontend and backend development
- Plugin architecture
- Testing strategies
- Security considerations
- Performance optimization
- Deployment considerations

## Next Steps

- Review the code examples and implement a sample feature
- Write comprehensive tests for your implementation
- Document your feature following the provided templates
- Prepare for the next lesson on Production Deployment

## Additional Resources

- [React Documentation](https://reactjs.org/docs)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [Testing Best Practices](https://docs.pytest.org/en/stable/)
- [Security Guidelines](https://owasp.org/www-project-top-ten/)
