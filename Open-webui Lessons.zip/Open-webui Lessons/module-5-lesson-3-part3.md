# Module 5, Lesson 3: Advanced Administration
## Part 3: Backup Strategies and Compliance Management

## Overview

In this final part of Advanced Administration, we'll focus on implementing robust backup strategies and ensuring compliance with various regulatory requirements. We'll cover automated backup systems, disaster recovery procedures, and compliance frameworks.

## Learning Objectives

By the end of Part 3, you will understand:
- How to implement comprehensive backup strategies
- Disaster recovery procedures
- Compliance management and auditing
- Data retention and privacy policies

## 1. Backup Strategies

### 1.1 Database Backup System

Implementing automated database backups:

```python
import asyncio
import aioshutil
import os
from datetime import datetime
from typing import Optional, List

class DatabaseBackup:
    def __init__(
        self,
        db_url: str,
        backup_dir: str,
        retention_days: int = 30
    ):
        self.db_url = db_url
        self.backup_dir = backup_dir
        self.retention_days = retention_days
        os.makedirs(backup_dir, exist_ok=True)

    async def create_backup(self) -> str:
        """Create a database backup"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_file = f"backup_{timestamp}.sql"
        backup_path = os.path.join(self.backup_dir, backup_file)

        try:
            # Execute pg_dump command
            process = await asyncio.create_subprocess_shell(
                f"pg_dump {self.db_url} > {backup_path}",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            await process.communicate()
            
            if process.returncode == 0:
                return backup_path
            else:
                raise Exception("Backup failed")
                
        except Exception as e:
            raise Exception(f"Backup error: {str(e)}")

    async def restore_backup(self, backup_file: str):
        """Restore database from backup"""
        try:
            # Execute psql command
            process = await asyncio.create_subprocess_shell(
                f"psql {self.db_url} < {backup_file}",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            await process.communicate()
            
            if process.returncode != 0:
                raise Exception("Restore failed")
                
        except Exception as e:
            raise Exception(f"Restore error: {str(e)}")

    async def cleanup_old_backups(self):
        """Remove backups older than retention period"""
        current_time = datetime.now()
        
        for file in os.listdir(self.backup_dir):
            file_path = os.path.join(self.backup_dir, file)
            file_time = datetime.fromtimestamp(
                os.path.getctime(file_path)
            )
            
            age_days = (current_time - file_time).days
            
            if age_days > self.retention_days:
                os.remove(file_path)
```

### 1.2 File System Backup

Managing file system backups:

```python
import tarfile
from pathlib import Path
from typing import List

class FileSystemBackup:
    def __init__(
        self,
        source_dirs: List[str],
        backup_dir: str
    ):
        self.source_dirs = source_dirs
        self.backup_dir = backup_dir
        Path(backup_dir).mkdir(parents=True, exist_ok=True)

    async def create_backup(self) -> str:
        """Create compressed backup of source directories"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_file = f"files_backup_{timestamp}.tar.gz"
        backup_path = Path(self.backup_dir) / backup_file

        try:
            with tarfile.open(backup_path, "w:gz") as tar:
                for source_dir in self.source_dirs:
                    tar.add(
                        source_dir,
                        arcname=os.path.basename(source_dir)
                    )
            return str(backup_path)
            
        except Exception as e:
            raise Exception(f"Backup error: {str(e)}")

    async def restore_backup(
        self,
        backup_file: str,
        restore_path: Optional[str] = None
    ):
        """Restore files from backup"""
        try:
            restore_path = restore_path or self.source_dirs[0]
            
            with tarfile.open(backup_file, "r:gz") as tar:
                tar.extractall(path=restore_path)
                
        except Exception as e:
            raise Exception(f"Restore error: {str(e)}")
```

## 2. Disaster Recovery

### 2.1 Recovery Procedures

Implementing disaster recovery processes:

```python
from enum import Enum
from typing import List, Dict

class RecoveryStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"

class DisasterRecovery:
    def __init__(
        self,
        db_backup: DatabaseBackup,
        fs_backup: FileSystemBackup
    ):
        self.db_backup = db_backup
        self.fs_backup = fs_backup
        self.status = RecoveryStatus.PENDING

    async def initiate_recovery(
        self,
        backup_files: Dict[str, str]
    ) -> bool:
        """Start recovery process"""
        self.status = RecoveryStatus.IN_PROGRESS
        
        try:
            # Restore database
            if "database" in backup_files:
                await self.db_backup.restore_backup(
                    backup_files["database"]
                )

            # Restore files
            if "files" in backup_files:
                await self.fs_backup.restore_backup(
                    backup_files["files"]
                )

            self.status = RecoveryStatus.COMPLETED
            return True
            
        except Exception as e:
            self.status = RecoveryStatus.FAILED
            raise Exception(f"Recovery failed: {str(e)}")

    async def verify_recovery(self) -> bool:
        """Verify recovery success"""
        # Implement verification logic
        return True
```

## 3. Compliance Management

### 3.1 Data Privacy Implementation

```python
from typing import List, Dict, Any
import hashlib
import json

class DataPrivacyManager:
    def __init__(self):
        self.sensitive_fields = [
            "password",
            "credit_card",
            "ssn",
            "phone_number"
        ]

    def mask_sensitive_data(
        self,
        data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Mask sensitive information in data"""
        masked_data = data.copy()
        
        for field in self.sensitive_fields:
            if field in masked_data:
                if isinstance(masked_data[field], str):
                    masked_data[field] = self._mask_string(
                        masked_data[field]
                    )
                    
        return masked_data

    def _mask_string(self, value: str) -> str:
        """Mask string while preserving some visible characters"""
        if len(value) <= 4:
            return "*" * len(value)
            
        return value[:2] + "*" * (len(value)-4) + value[-2:]

    def hash_sensitive_data(self, value: str) -> str:
        """Hash sensitive data for storage"""
        return hashlib.sha256(
            value.encode()
        ).hexdigest()
```

### 3.2 Audit Logging

```python
from datetime import datetime
from typing import Optional, Dict, Any

class AuditLogger:
    def __init__(self, db_connection):
        self.db = db_connection

    async def log_event(
        self,
        event_type: str,
        user_id: str,
        details: Dict[str, Any],
        ip_address: Optional[str] = None
    ):
        """Log audit event"""
        query = """
            INSERT INTO audit_logs (
                event_type,
                user_id,
                details,
                ip_address,
                created_at
            ) VALUES ($1, $2, $3, $4, $5)
        """
        
        await self.db.execute(
            query,
            event_type,
            user_id,
            json.dumps(details),
            ip_address,
            datetime.utcnow()
        )

    async def get_user_events(
        self,
        user_id: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> List[Dict[str, Any]]:
        """Retrieve audit logs for user"""
        query = """
            SELECT *
            FROM audit_logs
            WHERE user_id = $1
        """
        params = [user_id]
        
        if start_date:
            query += " AND created_at >= $2"
            params.append(start_date)
            
        if end_date:
            query += " AND created_at <= $3"
            params.append(end_date)
            
        return await self.db.fetch_all(query, *params)
```

## 4. Data Retention and Privacy

### 4.1 Data Retention Policy

```python
from datetime import datetime, timedelta
from typing import List, Dict

class DataRetentionManager:
    def __init__(self, db_connection):
        self.db = db_connection
        self.retention_periods = {
            "chat_messages": 90,  # days
            "user_activity": 180,  # days
            "audit_logs": 365     # days
        }

    async def cleanup_expired_data(self):
        """Remove data beyond retention period"""
        for table, days in self.retention_periods.items():
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            query = f"""
                DELETE FROM {table}
                WHERE created_at < $1
            """
            
            await self.db.execute(query, cutoff_date)

    async def get_retention_status(self) -> Dict[str, Dict]:
        """Get retention status for each data type"""
        status = {}
        
        for table, days in self.retention_periods.items():
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            query = f"""
                SELECT 
                    COUNT(*) as total,
                    COUNT(*) FILTER (
                        WHERE created_at < $1
                    ) as expired
                FROM {table}
            """
            
            result = await self.db.fetch_one(query, cutoff_date)
            
            status[table] = {
                "total_records": result["total"],
                "expired_records": result["expired"],
                "retention_days": days
            }
            
        return status
```

### 4.2 Privacy Policy Implementation

```python
from enum import Enum
from typing import List, Dict, Optional

class DataCategory(Enum):
    PERSONAL = "personal"
    SENSITIVE = "sensitive"
    OPERATIONAL = "operational"

class PrivacyManager:
    def __init__(self, db_connection):
        self.db = db_connection
        self.privacy_policy = self._load_privacy_policy()

    def _load_privacy_policy(self) -> Dict[str, Dict]:
        """Load privacy policy configurations"""
        return {
            "personal_data": {
                "category": DataCategory.PERSONAL,
                "retention_period": 365,
                "requires_consent": True,
                "encryption_required": True
            },
            "chat_data": {
                "category": DataCategory.OPERATIONAL,
                "retention_period": 90,
                "requires_consent": False,
                "encryption_required": False
            }
        }

    async def verify_consent(
        self,
        user_id: str,
        data_type: str
    ) -> bool:
        """Verify user consent for data processing"""
        if not self.privacy_policy[data_type]["requires_consent"]:
            return True
            
        query = """
            SELECT has_consented
            FROM user_consent
            WHERE user_id = $1 AND data_type = $2
        """
        
        result = await self.db.fetch_one(
            query,
            user_id,
            data_type
        )
        
        return result["has_consented"] if result else False

    async def record_consent(
        self,
        user_id: str,
        data_type: str,
        has_consented: bool
    ):
        """Record user consent"""
        query = """
            INSERT INTO user_consent (
                user_id,
                data_type,
                has_consented,
                updated_at
            ) VALUES ($1, $2, $3, $4)
            ON CONFLICT (user_id, data_type)
            DO UPDATE SET
                has_consented = $3,
                updated_at = $4
        """
        
        await self.db.execute(
            query,
            user_id,
            data_type,
            has_consented,
            datetime.utcnow()
        )
```

## Exercises and Practice

1. Implement automated backup system
2. Create disaster recovery procedures
3. Set up compliance monitoring
4. Implement data retention policies
5. Create privacy management system

## Additional Resources

- PostgreSQL Backup Documentation: https://www.postgresql.org/docs/current/backup.html
- GDPR Compliance Guide: https://gdpr.eu/
- HIPAA Security Rule: https://www.hhs.gov/hipaa/for-professionals/security/
- Data Protection Best Practices: https://ico.org.uk/for-organisations/

Remember to regularly check the Open WebUI documentation for updates and new features that might affect backup strategies and compliance management.