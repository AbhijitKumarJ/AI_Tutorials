# Module 6, Lesson 3: Production Deployment
## Part 2B: Advanced Topics and Disaster Recovery

## Introduction

This final section of the Production Deployment lesson covers advanced deployment configurations, scaling strategies, and comprehensive disaster recovery procedures. We'll explore high availability setups, automated failover, and recovery strategies for various failure scenarios.

## Advanced Deployment Configurations

### High Availability Setup

#### 1. Load Balancer Configuration

Create HAProxy configuration in `haproxy/haproxy.cfg`:

```cfg
global
    log /dev/log local0
    log /dev/log local1 notice
    chroot /var/lib/haproxy
    stats socket /run/haproxy/admin.sock mode 660 level admin expose-fd listeners
    stats timeout 30s
    user haproxy
    group haproxy
    daemon

defaults
    log global
    mode http
    option httplog
    option dontlognull
    timeout connect 5000
    timeout client  50000
    timeout server  50000

frontend http_front
    bind *:80
    stats uri /haproxy?stats
    default_backend http_back
    
    # Redirect HTTP to HTTPS
    redirect scheme https code 301 if !{ ssl_fc }

frontend https_front
    bind *:443 ssl crt /etc/haproxy/certs/server.pem
    option httplog
    option forwardfor
    option http-server-close
    
    # HSTS (uncomment if you're using HTTPS)
    # rspadd Strict-Transport-Security:\ max-age=31536000
    
    acl is_websocket hdr(Upgrade) -i WebSocket
    use_backend ws_back if is_websocket
    default_backend http_back

backend http_back
    balance roundrobin
    option httpchk GET /health
    http-check expect status 200
    server web1 openwebui1:8080 check
    server web2 openwebui2:8080 check
    server web3 openwebui3:8080 check backup

backend ws_back
    balance source
    option httpchk GET /health
    http-check expect status 200
    server web1 openwebui1:8080 check
    server web2 openwebui2:8080 check
    server web3 openwebui3:8080 check backup
```

#### 2. Multi-Node Docker Swarm Configuration

Create `docker-compose.swarm.yml`:

```yaml
version: '3.8'

services:
  openwebui:
    image: ghcr.io/open-webui/open-webui:main
    deploy:
      replicas: 3
      update_config:
        parallelism: 1
        delay: 10s
        order: start-first
      restart_policy:
        condition: on-failure
      resources:
        limits:
          cpus: '1'
          memory: 2G
    environment:
      - ENV=prod
      - DATABASE_URL=postgresql://user:password@db:5432/openwebui
    networks:
      - webui_net
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  db:
    image: postgres:14-alpine
    deploy:
      replicas: 1
      placement:
        constraints:
          - node.role == manager
    volumes:
      - db_data:/var/lib/postgresql/data
    networks:
      - webui_net
    environment:
      - POSTGRES_USER=openwebui
      - POSTGRES_PASSWORD=secure-password
      - POSTGRES_DB=openwebui

  redis:
    image: redis:alpine
    deploy:
      replicas: 2
      update_config:
        parallelism: 1
        delay: 10s
      restart_policy:
        condition: on-failure
    command: redis-server --appendonly yes
    volumes:
      - redis_data:/data
    networks:
      - webui_net

networks:
  webui_net:
    driver: overlay
    attachable: true

volumes:
  db_data:
  redis_data:
```

### Database Clustering

#### 1. PostgreSQL Replication Setup

Create primary database configuration in `postgresql/primary/postgresql.conf`:

```ini
# Replication
wal_level = replica
max_wal_senders = 10
max_replication_slots = 10
synchronous_commit = on
synchronous_standby_names = 'FIRST 1 (standby1, standby2)'

# Archive
archive_mode = on
archive_command = 'test ! -f /var/lib/postgresql/archive/%f && cp %p /var/lib/postgresql/archive/%f'
```

Create standby configuration in `postgresql/standby/postgresql.conf`:

```ini
# Replication
hot_standby = on
hot_standby_feedback = on
max_standby_streaming_delay = 30s
max_standby_archive_delay = 30s
```

Create `postgresql/standby/recovery.conf`:

```ini
standby_mode = 'on'
primary_conninfo = 'host=primary port=5432 user=replicator password=secure-password'
restore_command = 'cp /var/lib/postgresql/archive/%f %p'
```

### Automated Failover

#### 1. Patroni Configuration

Create `patroni/config.yml`:

```yaml
scope: openwebui-cluster
namespace: /db/
name: postgresql0

restapi:
  listen: 0.0.0.0:8008
  connect_address: postgresql0:8008

bootstrap:
  dcs:
    ttl: 30
    loop_wait: 10
    retry_timeout: 10
    maximum_lag_on_failover: 1048576
    postgresql:
      use_pg_rewind: true
      parameters:
        max_connections: 100
        shared_buffers: 256MB
        work_mem: 8MB
        maintenance_work_mem: 64MB
        dynamic_shared_memory_type: posix
        
postgresql:
  listen: 0.0.0.0:5432
  connect_address: postgresql0:5432
  data_dir: /data/postgresql0
  pgpass: /tmp/pgpass
  authentication:
    replication:
      username: replicator
      password: secure-password
    superuser:
      username: postgres
      password: secure-password
  parameters:
    unix_socket_directories: '.'

tags:
  nofailover: false
  noloadbalance: false
  clonefrom: false
  nosync: false
```

## Disaster Recovery Procedures

### 1. Recovery Plan Documentation

Create a comprehensive recovery plan document:

```markdown
# Disaster Recovery Plan

## Emergency Contacts

- Primary Contact: [Name] - [Phone] - [Email]
- Secondary Contact: [Name] - [Phone] - [Email]
- Database Admin: [Name] - [Phone] - [Email]

## Recovery Scenarios

### 1. Complete System Failure

#### Steps:
1. Activate backup infrastructure
2. Restore latest database backup
3. Restore application state
4. Verify system integrity
5. Switch DNS records
6. Monitor system

### 2. Database Corruption

#### Steps:
1. Stop application servers
2. Switch to standby database
3. Verify data integrity
4. Restart application servers
5. Monitor system

### 3. Network Outage

#### Steps:
1. Switch to backup datacenter
2. Update DNS records
3. Verify connectivity
4. Monitor system

## Recovery Procedures
```

### 2. Recovery Automation Scripts

Create `scripts/disaster_recovery.sh`:

```bash
#!/bin/bash

# Configuration
BACKUP_DIR="/backup"
RECOVERY_DIR="/recovery"
LOG_FILE="recovery.log"

# Function to log messages
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Function to restore database
restore_database() {
    local backup_file="$1"
    log_message "Starting database restoration from $backup_file"
    
    # Stop application
    docker compose down
    
    # Restore database
    gunzip -c "$backup_file" | docker exec -i openwebui-db psql -U openwebui
    
    # Start application
    docker compose up -d
    
    log_message "Database restoration completed"
}

# Function to restore volumes
restore_volumes() {
    local backup_file="$1"
    local volume_name="$2"
    
    log_message "Restoring volume $volume_name from $backup_file"
    
    # Stop services
    docker compose down
    
    # Create temporary container
    docker run --rm \
        -v "$volume_name":/destination \
        -v "$BACKUP_DIR":/backup \
        alpine sh -c "cd /destination && tar xzf /backup/$backup_file"
    
    # Start services
    docker compose up -d
    
    log_message "Volume restoration completed"
}

# Function to verify system integrity
verify_system() {
    log_message "Verifying system integrity"
    
    # Check services
    docker compose ps | grep "unhealthy"
    if [ $? -eq 0 ]; then
        log_message "System verification failed - unhealthy services detected"
        return 1
    fi
    
    # Check database
    docker exec openwebui-db pg_isready
    if [ $? -ne 0 ]; then
        log_message "System verification failed - database not ready"
        return 1
    fi
    
    log_message "System verification completed successfully"
    return 0
}
```

### 3. Data Recovery Procedures

Create `scripts/data_recovery.sh`:

```bash
#!/bin/bash

# Configuration
BACKUP_DIR="/backup"
TEMP_DIR="/tmp/recovery"
LOG_FILE="data_recovery.log"

# Function to recover specific data
recover_data() {
    local backup_file="$1"
    local table_name="$2"
    local where_clause="$3"
    
    log_message "Starting data recovery for table $table_name"
    
    # Create temporary directory
    mkdir -p "$TEMP_DIR"
    
    # Extract backup
    gunzip -c "$backup_file" > "$TEMP_DIR/backup.sql"
    
    # Recover specific data
    if [ -n "$where_clause" ]; then
        docker exec -i openwebui-db psql -U openwebui -c "
            BEGIN;
            CREATE TEMPORARY TABLE temp_recovery AS 
            SELECT * FROM $table_name WHERE $where_clause;
            DELETE FROM $table_name WHERE $where_clause;
            INSERT INTO $table_name SELECT * FROM temp_recovery;
            DROP TABLE temp_recovery;
            COMMIT;
        "
    fi
    
    log_message "Data recovery completed"
}

# Function to verify data integrity
verify_data() {
    local table_name="$1"
    
    log_message "Verifying data integrity for table $table_name"
    
    docker exec openwebui-db psql -U openwebui -c "
        SELECT count(*) FROM $table_name;
        SELECT COUNT(*) FROM $table_name WHERE NOT valid_check_constraint;
    "
    
    log_message "Data verification completed"
}
```

### Failover Testing

#### 1. Failover Test Script

Create `scripts/test_failover.sh`:

```bash
#!/bin/bash

# Configuration
LOG_FILE="failover_test.log"
PRIMARY_HOST="postgresql0"
STANDBY_HOST="postgresql1"

# Function to test failover
test_failover() {
    log_message "Starting failover test"
    
    # Stop primary
    docker stop "$PRIMARY_HOST"
    
    # Wait for failover
    sleep 30
    
    # Verify standby promotion
    docker exec "$STANDBY_HOST" psql -U postgres -c "SELECT pg_is_in_recovery();"
    
    # Verify application connectivity
    curl -f http://localhost:8080/health
    
    log_message "Failover test completed"
}

# Function to test failback
test_failback() {
    log_message "Starting failback test"
    
    # Start primary
    docker start "$PRIMARY_HOST"
    
    # Wait for sync
    sleep 60
    
    # Verify replication
    docker exec "$PRIMARY_HOST" psql -U postgres -c "SELECT * FROM pg_stat_replication;"
    
    log_message "Failback test completed"
}
```

## Conclusion

This concludes our comprehensive coverage of Production Deployment for Open WebUI. You should now have a thorough understanding of:

1. Advanced deployment configurations
2. High availability setups
3. Database clustering and replication
4. Automated failover procedures
5. Disaster recovery planning and implementation

Remember to:
- Regularly test recovery procedures
- Keep documentation updated
- Monitor system health
- Maintain backup integrity
- Train team members on recovery procedures

## Next Steps

- Implement the configurations in a staging environment
- Conduct failover testing
- Document specific procedures for your environment
- Train team members on recovery procedures
- Schedule regular disaster recovery drills

## Additional Resources

- [PostgreSQL High Availability Documentation](https://www.postgresql.org/docs/current/high-availability.html)
- [Docker Swarm Documentation](https://docs.docker.com/engine/swarm/)
- [HAProxy Configuration Manual](http://cbonte.github.io/haproxy-dconv/)
- [Prometheus Documentation](https://prometheus.io/docs/introduction/overview/)