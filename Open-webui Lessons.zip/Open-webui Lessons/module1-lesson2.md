# Module 1, Lesson 2: Installation Fundamentals

## Introduction

In this lesson, we'll dive deep into the installation process for Open WebUI. We'll cover every installation method, from Docker-based deployments to manual installations, ensuring you understand the advantages and considerations of each approach. By the end of this lesson, you'll be equipped to choose and implement the most appropriate installation method for your needs.

## System Requirements

Before beginning any installation, it's crucial to understand the system requirements for running Open WebUI effectively.

### Hardware Requirements

**Minimum Requirements:**
- CPU: 2 cores
- RAM: 4GB
- Storage: 10GB available space
- Network: Stable internet connection

**Recommended Requirements:**
- CPU: 4+ cores
- RAM: 8GB or more
- Storage: 20GB+ SSD storage
- Network: High-speed internet connection

**GPU Requirements (Optional):**
- NVIDIA GPU with CUDA support for GPU acceleration
- AMD GPU with ROCm support (for specific deployments)

### Software Requirements

**Operating System Compatibility:**
- Linux (Ubuntu 20.04+, CentOS 8+, or similar)
- macOS (10.15+)
- Windows 10/11 with WSL2 for Docker-based installations

**Required Software:**
- Docker Engine 20.10+ (for Docker installations)
- Python 3.11+ (for manual installations)
- Git (for source code management)
- Node.js 20.10+ (for development)

## Docker-based Installation

Docker is the recommended installation method as it provides consistency across different environments and simplified management.

### Basic Docker Setup

1. **Docker Environment Preparation**

First, ensure Docker is properly installed and configured:

```bash
# Check Docker installation
docker --version
docker-compose --version

# Start Docker service (Linux)
sudo systemctl start docker
sudo systemctl enable docker
```

2. **Basic Installation Command**

```bash
docker run -d \
  -p 3000:8080 \
  --add-host=host.docker.internal:host-gateway \
  -v open-webui:/app/backend/data \
  --name open-webui \
  --restart always \
  ghcr.io/open-webui/open-webui:main
```

### Docker Compose Installation

For more complex setups, Docker Compose provides better management of services. Create a `docker-compose.yml` file:

```yaml
version: '3'
services:
  open-webui:
    image: ghcr.io/open-webui/open-webui:main
    ports:
      - "3000:8080"
    volumes:
      - open-webui:/app/backend/data
    environment:
      - OLLAMA_BASE_URL=http://ollama:11434
    restart: always

  ollama:
    image: ollama/ollama:latest
    volumes:
      - ollama:/root/.ollama
    restart: always

volumes:
  open-webui:
  ollama:
```

Start the services with:
```bash
docker-compose up -d
```

### GPU Support Configuration

For installations requiring GPU support, additional configuration is needed:

```bash
docker run -d \
  -p 3000:8080 \
  --gpus all \
  -v open-webui:/app/backend/data \
  --name open-webui \
  --restart always \
  ghcr.io/open-webui/open-webui:cuda
```

## Python/Pip Installation

For environments where Docker isn't suitable, a direct Python installation is available.

### Virtual Environment Setup

```bash
# Create virtual environment
python -m venv open-webui-env

# Activate virtual environment
# On Linux/macOS
source open-webui-env/bin/activate
# On Windows
.\open-webui-env\Scripts\activate

# Install Open WebUI
pip install open-webui

# Start the server
open-webui serve
```

### Manual Installation from Source

```bash
# Clone repository
git clone https://github.com/open-webui/open-webui.git
cd open-webui

# Install dependencies
pip install -r requirements.txt

# Start development server
sh dev.sh
```

## Kubernetes Deployment

For enterprise environments, Kubernetes offers scalable deployment options.

### Helm Chart Installation

```bash
# Add Open WebUI Helm repository
helm repo add open-webui https://open-webui.github.io/helm-charts
helm repo update

# Install Open WebUI chart
helm install openwebui open-webui/open-webui
```

### Kustomize Configuration

Create a `kustomization.yaml`:

```yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
  - github.com/open-webui/k8s-manifests//base
```

Apply the configuration:
```bash
kubectl apply -k .
```

## Network Architecture

Understanding the network architecture is crucial for proper deployment.

### Standard Architecture
```
[Client Browser] → [Open WebUI (8080)] → [Ollama (11434)]
                                      → [External APIs]
```

### Reverse Proxy Setup

For production deployments, a reverse proxy is recommended:

```nginx
server {
    listen 80;
    server_name your_domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## Dependency Management

Proper dependency management ensures stable operation.

### Core Dependencies
- FastAPI for backend API
- React for frontend
- SQLite/PostgreSQL for database
- ChromaDB for vector storage

### Version Control
```bash
# Lock dependencies versions
pip freeze > requirements.txt

# Update dependencies
pip install -r requirements.txt --upgrade
```

## Troubleshooting Common Installation Issues

### Docker Issues

1. **Connection Refused**
   ```
   Error: connect ECONNREFUSED 127.0.0.1:11434
   ```
   Solution: Check Ollama service status and ensure proper network configuration:
   ```bash
   docker logs ollama
   docker network inspect bridge
   ```

2. **Volume Mounting Issues**
   ```
   Error: cannot create directory '/app/backend/data'
   ```
   Solution: Check permissions and volume configuration:
   ```bash
   docker volume inspect open-webui
   ```

### Python Installation Issues

1. **Dependency Conflicts**
   ```
   ERROR: Cannot install -r requirements.txt due to version conflicts
   ```
   Solution: Create a fresh virtual environment and install dependencies sequentially:
   ```bash
   python -m venv clean-env
   source clean-env/bin/activate
   pip install -r requirements.txt --no-cache-dir
   ```

2. **Port Already in Use**
   ```
   ERROR: Address already in use
   ```
   Solution: Find and stop the process using the port:
   ```bash
   lsof -i :8080
   kill -9 <PID>
   ```

## Platform-specific Configurations

### Linux Configuration

1. **System Limits**
   ```bash
   # Increase file descriptor limits
   echo "fs.file-max = 65535" | sudo tee -a /etc/sysctl.conf
   sudo sysctl -p
   ```

2. **Firewall Configuration**
   ```bash
   sudo ufw allow 3000/tcp
   sudo ufw allow 11434/tcp
   ```

### Windows Configuration

1. **WSL2 Setup**
   ```powershell
   wsl --install
   wsl --set-default-version 2
   ```

2. **Docker Desktop Settings**
   - Enable WSL2 backend
   - Configure resource limits

### macOS Configuration

1. **Docker Desktop Resources**
   - Allocate sufficient CPU and RAM
   - Enable virtualisation features

2. **Network Configuration**
   ```bash
   sudo pfctl -F all -f /etc/pf.conf
   ```

## Conclusion

We've covered comprehensive installation methods for Open WebUI across different platforms and deployment scenarios. Understanding these fundamentals is crucial for maintaining a stable and secure installation. In the next lesson, we'll explore basic configuration and customization options.

## Practice Exercises

1. **Docker Deployment**
   Set up Open WebUI using Docker with GPU support and integrate it with an external Ollama instance.

2. **Kubernetes Setup**
   Deploy Open WebUI on a local Kubernetes cluster using Helm, including proper volume management.

3. **Troubleshooting Practice**
   Identify and resolve common installation issues in a test environment.

## Additional Resources

- [Official Installation Guide](https://docs.openwebui.com/getting-started)
- [Docker Documentation](https://docs.docker.com/)
- [Kubernetes Documentation](https://kubernetes.io/docs/)
- [Python Virtual Environments Guide](https://docs.python.org/3/tutorial/venv.html)

