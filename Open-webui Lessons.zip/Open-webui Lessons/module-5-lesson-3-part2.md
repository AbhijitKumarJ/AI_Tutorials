# Module 5, Lesson 3: Advanced Administration
## Part 2: Performance Optimization

## Overview

In this second part of Advanced Administration, we'll focus on performance optimization strategies for Open WebUI. We'll cover database optimization, caching strategies, resource management, and monitoring system performance.

## Learning Objectives

By the end of Part 2, you will understand:
- How to optimize database performance
- Implementation of effective caching strategies
- Resource management techniques
- Performance monitoring and tuning

## 1. Database Optimization

### 1.1 Database Configuration

Optimizing database settings for Open WebUI:

```python
from databases import Database
from typing import Optional

class DatabaseConfig:
    def __init__(
        self,
        url: str,
        min_size: int = 5,
        max_size: int = 20
    ):
        self.url = url
        self.min_size = min_size
        self.max_size = max_size
        self._db: Optional[Database] = None

    async def get_connection(self) -> Database:
        if not self._db:
            self._db = Database(
                url=self.url,
                min_size=self.min_size,
                max_size=self.max_size
            )
            await self._db.connect()
        return self._db

    def get_connection_params(self) -> dict:
        return {
            "pool_size": self.max_size,
            "max_overflow": 10,
            "pool_timeout": 30,
            "pool_recycle": 1800
        }
```

### 1.2 Query Optimization

Implementing efficient database queries:

```python
from sqlalchemy import text
from typing import List, Dict, Any

class QueryOptimizer:
    def __init__(self, db_connection):
        self.db = db_connection

    async def batch_insert(
        self,
        table: str,
        records: List[Dict[str, Any]]
    ):
        """Efficient batch insert operation"""
        if not records:
            return

        columns = records[0].keys()
        values = [
            [record[column] for column in columns]
            for record in records
        ]

        query = f"""
            INSERT INTO {table} ({', '.join(columns)})
            VALUES ({', '.join(['$' + str(i+1) for i in range(len(columns))])})
        """
        
        await self.db.execute_many(query, values)

    async def optimized_select(
        self,
        table: str,
        columns: List[str],
        conditions: Dict[str, Any],
        limit: int = 1000
    ):
        """Optimized select query with pagination"""
        where_clause = " AND ".join(
            f"{k} = ${i+1}"
            for i, k in enumerate(conditions.keys())
        )

        query = f"""
            SELECT {', '.join(columns)}
            FROM {table}
            WHERE {where_clause}
            LIMIT {limit}
        """

        return await self.db.fetch_all(
            query,
            *conditions.values()
        )
```

## 2. Caching Strategies

### 2.1 Redis Cache Implementation

```python
from redis import asyncio as aioredis
import json
from typing import Optional, Any

class CacheManager:
    def __init__(self, redis_url: str):
        self.redis = aioredis.from_url(redis_url)
        self.default_ttl = 3600  # 1 hour

    async def get(self, key: str) -> Optional[Any]:
        """Retrieve item from cache"""
        value = await self.redis.get(key)
        if value:
            return json.loads(value)
        return None

    async def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None
    ):
        """Store item in cache"""
        ttl = ttl or self.default_ttl
        await self.redis.set(
            key,
            json.dumps(value),
            ex=ttl
        )

    async def delete(self, key: str):
        """Remove item from cache"""
        await self.redis.delete(key)

    async def clear_pattern(self, pattern: str):
        """Clear all keys matching pattern"""
        keys = await self.redis.keys(pattern)
        if keys:
            await self.redis.delete(*keys)
```

### 2.2 Model Response Caching

```python
from functools import wraps
from hashlib import sha256

def cache_response(ttl: int = 3600):
    """Decorator for caching model responses"""
    def decorator(func):
        @wraps(func)
        async def wrapper(self, *args, **kwargs):
            # Generate cache key
            key_parts = [
                func.__name__,
                str(args),
                str(sorted(kwargs.items()))
            ]
            cache_key = sha256(
                "_".join(key_parts).encode()
            ).hexdigest()

            # Try to get from cache
            cached_response = await self.cache.get(cache_key)
            if cached_response is not None:
                return cached_response

            # Execute function and cache result
            result = await func(self, *args, **kwargs)
            await self.cache.set(cache_key, result, ttl)
            return result
        return wrapper
    return decorator
```

## 3. Resource Management

### 3.1 Memory Management

```python
import psutil
import gc
from typing import Dict

class MemoryManager:
    def __init__(self, threshold_percent: float = 90.0):
        self.threshold_percent = threshold_percent

    def get_memory_usage(self) -> Dict[str, float]:
        """Get current memory usage statistics"""
        memory = psutil.virtual_memory()
        return {
            "total_gb": memory.total / (1024**3),
            "available_gb": memory.available / (1024**3),
            "used_gb": memory.used / (1024**3),
            "percent": memory.percent
        }

    async def check_memory_threshold(self) -> bool:
        """Check if memory usage exceeds threshold"""
        memory = psutil.virtual_memory()
        return memory.percent > self.threshold_percent

    async def optimize_memory(self):
        """Perform memory optimization"""
        if await self.check_memory_threshold():
            # Force garbage collection
            gc.collect()
            
            # Clear memory caches
            await self.clear_caches()
            
            return True
        return False

    async def clear_caches(self):
        """Clear various caches to free memory"""
        # Clear Redis cache
        cache = CacheManager(redis_url="redis://localhost")
        await cache.clear_pattern("*")
```

### 3.2 CPU Management

```python
import multiprocessing
from typing import Dict

class CPUManager:
    def __init__(self, max_workers: Optional[int] = None):
        self.max_workers = max_workers or multiprocessing.cpu_count()

    def get_cpu_usage(self) -> Dict[str, float]:
        """Get CPU usage statistics"""
        cpu_percent = psutil.cpu_percent(interval=1, percpu=True)
        return {
            "overall_percent": sum(cpu_percent) / len(cpu_percent),
            "per_cpu_percent": cpu_percent,
            "num_cpus": len(cpu_percent)
        }

    async def optimize_cpu_usage(
        self,
        current_workers: int
    ) -> int:
        """Optimize number of workers based on CPU usage"""
        cpu_usage = self.get_cpu_usage()
        
        if cpu_usage["overall_percent"] > 80:
            # Reduce workers if CPU usage is high
            return max(1, current_workers - 1)
        elif cpu_usage["overall_percent"] < 50:
            # Increase workers if CPU usage is low
            return min(self.max_workers, current_workers + 1)
            
        return current_workers
```

## 4. Performance Monitoring

### 4.1 Prometheus Metrics

```python
from prometheus_client import Counter, Histogram, Gauge
from typing import Dict

class PerformanceMetrics:
    def __init__(self):
        # Request metrics
        self.request_count = Counter(
            'web_request_count',
            'Total number of requests',
            ['endpoint', 'method']
        )
        
        self.request_latency = Histogram(
            'web_request_latency_seconds',
            'Request latency in seconds',
            ['endpoint']
        )
        
        # Resource metrics
        self.memory_usage = Gauge(
            'memory_usage_bytes',
            'Memory usage in bytes'
        )
        
        self.cpu_usage = Gauge(
            'cpu_usage_percent',
            'CPU usage percentage'
        )

    async def record_request(
        self,
        endpoint: str,
        method: str,
        duration: float
    ):
        """Record request metrics"""
        self.request_count.labels(
            endpoint=endpoint,
            method=method
        ).inc()
        
        self.request_latency.labels(
            endpoint=endpoint
        ).observe(duration)

    async def update_resource_metrics(self):
        """Update resource usage metrics"""
        memory = psutil.virtual_memory()
        cpu = psutil.cpu_percent()
        
        self.memory_usage.set(memory.used)
        self.cpu_usage.set(cpu)
```

### 4.2 Performance Middleware

```python
import time
from fastapi import Request
from typing import Callable

class PerformanceMiddleware:
    def __init__(self, metrics: PerformanceMetrics):
        self.metrics = metrics

    async def __call__(
        self,
        request: Request,
        call_next: Callable
    ):
        start_time = time.time()
        
        response = await call_next(request)
        
        duration = time.time() - start_time
        await self.metrics.record_request(
            endpoint=request.url.path,
            method=request.method,
            duration=duration
        )
        
        return response
```

## Exercises and Practice

1. Implement database optimization strategies
2. Create a caching system with Redis
3. Implement resource management controls
4. Set up Prometheus metrics
5. Create performance monitoring dashboards

## Additional Resources

- Redis Documentation: https://redis.io/docs/
- Prometheus Documentation: https://prometheus.io/docs/
- SQLAlchemy Documentation: https://docs.sqlalchemy.org/
- FastAPI Performance Tips: https://fastapi.tiangolo.com/advanced/performance/

Remember to regularly check the Open WebUI documentation for updates and new features that might affect performance optimization strategies.