# Module 6, Lesson 1: Development Environment Setup

## Introduction

Welcome to Module 6, Lesson 1 of the Open WebUI Mastery course. In this comprehensive lesson, we'll dive deep into setting up a development environment for Open WebUI. This environment will serve as your foundation for both contributing to the core project and developing custom features. We'll cover everything from basic setup to advanced development tools integration.

## Prerequisites

Before beginning this lesson, ensure you have:
- Basic understanding of web development concepts
- Familiarity with command-line interfaces
- Basic knowledge of Git version control
- Understanding of Python and JavaScript/TypeScript
- Basic Docker knowledge

## Development Environment Components

### Project Structure

Open WebUI follows a clean, organized structure. Here's the standard layout you'll be working with:

```
open-webui/
├── .github/               # GitHub-specific configurations
├── backend/              # Python backend code
│   ├── open_webui/       # Main backend package
│   ├── requirements.txt  # Python dependencies
│   └── tests/           # Backend tests
├── src/                 # Frontend source code
│   ├── components/      # React components
│   ├── lib/            # Shared utilities
│   └── styles/         # CSS and styling
├── docs/               # Documentation
├── scripts/           # Development scripts
└── package.json      # Node.js dependencies
```

### Development Tools Setup

#### 1. Code Editor Configuration

We recommend Visual Studio Code with the following extensions:

```json
{
    "recommendations": [
        "dbaeumer.vscode-eslint",
        "esbenp.prettier-vscode",
        "ms-python.python",
        "bradlc.vscode-tailwindcss",
        "unifiedjs.vscode-mdx"
    ]
}
```

Create a `.vscode/settings.json` file for consistent editor settings:

```json
{
    "editor.formatOnSave": true,
    "editor.codeActionsOnSave": {
        "source.fixAll.eslint": true
    },
    "python.linting.enabled": true,
    "python.linting.pylintEnabled": true,
    "files.eol": "\n"
}
```

#### 2. Environment Setup

First, clone the repository and set up your development environment:

```bash
# Clone the repository
git clone https://github.com/open-webui/open-webui.git
cd open-webui

# Create Python virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install Python dependencies
cd backend
pip install -r requirements.txt

# Install Node.js dependencies
cd ..
npm install
```

#### 3. Database Configuration

For development, we use SQLite by default. Create a `.env` file in the root directory:

```ini
DATABASE_URL=sqlite:///./backend/data/webui.db
ENABLE_SIGNUP=True
ENV=dev
```

### Version Control Setup

#### 1. Git Configuration

Configure Git with your credentials:

```bash
git config user.name "Your Name"
git config user.email "your.email@example.com"
```

Create a `.gitignore` file to exclude unnecessary files:

```gitignore
# Python
__pycache__/
*.py[cod]
venv/
*.egg-info/

# Node
node_modules/
dist/
.next/
.cache/

# Development
.env
*.log
.DS_Store
```

#### 2. Pre-commit Hooks

Install pre-commit hooks to ensure code quality:

```bash
pip install pre-commit
pre-commit install
```

Create a `.pre-commit-config.yaml`:

```yaml
repos:
-   repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.4.0
    hooks:
    -   id: trailing-whitespace
    -   id: end-of-file-fixer
    -   id: check-yaml
    -   id: check-added-large-files

-   repo: https://github.com/psf/black
    rev: 23.3.0
    hooks:
    -   id: black

-   repo: https://github.com/PyCQA/flake8
    rev: 6.0.0
    hooks:
    -   id: flake8
```

### Development Workflow

#### 1. Running the Development Server

Start the backend development server:

```bash
# In the backend directory
python -m uvicorn open_webui.main:app --reload
```

Start the frontend development server:

```bash
# In the root directory
npm run dev
```

#### 2. Testing Setup

For backend testing, we use pytest. Create a `pytest.ini` file:

```ini
[pytest]
python_files = test_*.py
python_classes = Test*
python_functions = test_*
testpaths = backend/tests
```

For frontend testing, we use Jest. Configure it in `jest.config.js`:

```javascript
module.exports = {
    testEnvironment: 'jsdom',
    setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
    moduleNameMapper: {
        '^@/(.*)$': '<rootDir>/src/$1',
    },
};
```

#### 3. Debugging Configuration

Create launch configurations for VS Code in `.vscode/launch.json`:

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Python: FastAPI",
            "type": "python",
            "request": "launch",
            "module": "uvicorn",
            "args": [
                "open_webui.main:app",
                "--reload"
            ],
            "jinja": true,
            "justMyCode": true
        },
        {
            "name": "Next.js: debug server-side",
            "type": "node-terminal",
            "request": "launch",
            "command": "npm run dev"
        }
    ]
}
```

## Best Practices

### Code Style and Standards

Follow these guidelines for consistent code:

1. Python Code:
   - Follow PEP 8 style guide
   - Use type hints for function parameters
   - Document functions using docstrings
   - Keep functions focused and small

2. JavaScript/TypeScript:
   - Use ESLint and Prettier for formatting
   - Follow React hooks guidelines
   - Use TypeScript for type safety
   - Keep components pure and functional

### Documentation

Maintain documentation as you develop:

1. Code Documentation:
   - Document all public functions and classes
   - Include examples in docstrings
   - Update README.md with new features
   - Keep API documentation current

2. Development Documentation:
   - Document setup procedures
   - Include troubleshooting guides
   - Maintain changelog
   - Update deployment guides

## Common Issues and Solutions

### Environment Setup Issues

1. Node.js Version Conflicts:
   ```bash
   nvm install 16
   nvm use 16
   ```

2. Python Dependencies:
   ```bash
   pip install --upgrade pip
   pip install -r requirements.txt --no-cache-dir
   ```

### Database Migration Issues

1. Reset Database:
   ```bash
   rm backend/data/webui.db
   python backend/scripts/init_db.py
   ```

2. Update Schema:
   ```bash
   alembic upgrade head
   ```

## Conclusion

This comprehensive development environment setup provides a solid foundation for contributing to Open WebUI. Remember to:

- Regularly update your development environment
- Follow the established coding standards
- Run tests before submitting changes
- Document your code and changes
- Participate in code reviews

## Next Steps

- Explore the codebase to understand the project structure
- Set up your first development branch
- Try running the test suite
- Make your first contribution

## Additional Resources

- [Open WebUI Documentation](https://docs.openwebui.com/)
- [Contributing Guidelines](https://docs.openwebui.com/contributing)
- [API Documentation](https://docs.openwebui.com/api)
- [Development Tips](https://docs.openwebui.com/development)