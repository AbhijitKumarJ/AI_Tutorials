# Module 2, Lesson 2: Model Integration in Open WebUI

## Introduction to Model Integration

Model integration in Open WebUI represents the bridge between different AI model providers and your application. This lesson covers the comprehensive process of integrating various model types, from local Ollama models to external API-based services, ensuring robust, efficient, and secure connections.

## Ollama Integration Setup

### Basic Configuration

Ollama integration forms the foundation of local model deployment in Open WebUI. The setup process involves several key components:

```yaml
# Example docker-compose.yml configuration
version: '3'
services:
  openwebui:
    image: ghcr.io/open-webui/open-webui:main
    environment:
      OLLAMA_BASE_URL: http://ollama:11434
      OLLAMA_API_BASE_URLS: "http://ollama1:11434;http://ollama2:11434"
    volumes:
      - open-webui:/app/backend/data
    depends_on:
      - ollama

  ollama:
    image: ollama/ollama:latest
    volumes:
      - ollama:/root/.ollama
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: all
              capabilities: [gpu]
```

### Advanced Ollama Configuration

For production environments, consider implementing these advanced configurations:

1. **Load Balancing Setup**:
   ```python
   # Example load balancing configuration
   OLLAMA_ENDPOINTS = [
       "http://ollama1:11434",
       "http://ollama2:11434",
       "http://ollama3:11434"
   ]
   
   class OllamaLoadBalancer:
       def __init__(self, endpoints):
           self.endpoints = endpoints
           self.current = 0
           
       def get_next_endpoint(self):
           endpoint = self.endpoints[self.current]
           self.current = (self.current + 1) % len(self.endpoints)
           return endpoint
   ```

2. **Health Check Implementation**:
   ```python
   async def check_ollama_health(endpoint):
       try:
           async with aiohttp.ClientSession() as session:
               async with session.get(f"{endpoint}/health") as response:
                   return response.status == 200
       except Exception as e:
           logger.error(f"Health check failed for {endpoint}: {e}")
           return False
   ```

## OpenAI API Integration

### Basic OpenAI Setup

Configure OpenAI API integration with proper authentication and endpoint management:

```python
# Environment configuration
OPENAI_API_CONFIG = {
    "base_url": "https://api.openai.com/v1",
    "alternative_base_url": "https://your-proxy.com/v1",
    "api_key": "your-api-key",
    "organization_id": "your-org-id"  # Optional
}

# Implementation example
class OpenAIIntegration:
    def __init__(self, config):
        self.config = config
        self.session = None
        
    async def initialize(self):
        self.session = aiohttp.ClientSession(
            headers={
                "Authorization": f"Bearer {self.config['api_key']}",
                "OpenAI-Organization": self.config.get('organization_id', '')
            }
        )
```

### Rate Limiting Implementation

Implement robust rate limiting to manage API usage:

```python
from datetime import datetime, timedelta
from collections import deque

class RateLimiter:
    def __init__(self, requests_per_minute=60):
        self.rate_limit = requests_per_minute
        self.requests = deque()
        
    async def check_limit(self):
        now = datetime.now()
        # Remove requests older than 1 minute
        while self.requests and self.requests[0] < now - timedelta(minutes=1):
            self.requests.popleft()
            
        if len(self.requests) >= self.rate_limit:
            return False
            
        self.requests.append(now)
        return True
```

## Authentication Patterns

### Multi-Provider Authentication

Implement a flexible authentication system that handles multiple providers:

```python
class ModelAuthManager:
    def __init__(self):
        self.auth_handlers = {
            'ollama': self.handle_ollama_auth,
            'openai': self.handle_openai_auth,
            'custom': self.handle_custom_auth
        }
        
    async def authenticate_request(self, provider, request_data):
        handler = self.auth_handlers.get(provider)
        if not handler:
            raise ValueError(f"Unsupported provider: {provider}")
            
        return await handler(request_data)
        
    async def handle_ollama_auth(self, request_data):
        # Implement Ollama-specific authentication
        pass
        
    async def handle_openai_auth(self, request_data):
        # Implement OpenAI-specific authentication
        pass
```

### Token Management

Implement secure token handling and rotation:

```python
class TokenManager:
    def __init__(self):
        self.tokens = {}
        self.rotation_intervals = {
            'openai': timedelta(days=30),
            'custom': timedelta(days=7)
        }
        
    async def rotate_token(self, provider):
        """
        Implements secure token rotation for different providers
        """
        current_token = self.tokens.get(provider)
        if not current_token:
            return
            
        # Implementation of token rotation logic
        pass
```

## Error Handling Approaches

### Comprehensive Error Management

Implement robust error handling for various scenarios:

```python
class ModelIntegrationError(Exception):
    def __init__(self, message, provider, error_code=None, retriable=False):
        super().__init__(message)
        self.provider = provider
        self.error_code = error_code
        self.retriable = retriable

class ErrorHandler:
    def __init__(self):
        self.retry_policies = {
            'rate_limit': self.handle_rate_limit,
            'timeout': self.handle_timeout,
            'connection': self.handle_connection_error
        }
        
    async def handle_error(self, error, context):
        if isinstance(error, ModelIntegrationError):
            handler = self.retry_policies.get(error.error_code)
            if handler and error.retriable:
                return await handler(error, context)
        
        # Log and raise if unhandled
        logger.error(f"Unhandled error: {error}")
        raise error
```

## Load Balancing Implementation

### Advanced Load Balancing

Implement sophisticated load balancing strategies:

```python
from enum import Enum

class LoadBalancingStrategy(Enum):
    ROUND_ROBIN = "round_robin"
    LEAST_CONNECTIONS = "least_connections"
    WEIGHTED = "weighted"

class ModelLoadBalancer:
    def __init__(self, strategy=LoadBalancingStrategy.ROUND_ROBIN):
        self.strategy = strategy
        self.endpoints = {}
        self.current_loads = {}
        
    def register_endpoint(self, endpoint, weight=1):
        self.endpoints[endpoint] = {
            'weight': weight,
            'active_connections': 0
        }
        
    async def get_next_endpoint(self):
        if self.strategy == LoadBalancingStrategy.ROUND_ROBIN:
            return await self._round_robin_select()
        elif self.strategy == LoadBalancingStrategy.LEAST_CONNECTIONS:
            return await self._least_connections_select()
        elif self.strategy == LoadBalancingStrategy.WEIGHTED:
            return await self._weighted_select()
```

## Cost Optimization Techniques

### Implementing Cost Management

Develop systems for tracking and optimizing costs:

```python
class CostManager:
    def __init__(self):
        self.cost_tracking = {}
        self.budget_limits = {}
        
    async def track_request_cost(self, provider, model, tokens):
        cost_per_token = self.get_model_cost(provider, model)
        total_cost = tokens * cost_per_token
        
        await self.update_usage_metrics(provider, model, total_cost)
        await self.check_budget_limits(provider)
        
    async def update_usage_metrics(self, provider, model, cost):
        if provider not in self.cost_tracking:
            self.cost_tracking[provider] = {}
            
        if model not in self.cost_tracking[provider]:
            self.cost_tracking[provider][model] = {
                'total_cost': 0,
                'request_count': 0
            }
            
        self.cost_tracking[provider][model]['total_cost'] += cost
        self.cost_tracking[provider][model]['request_count'] += 1
```

## Integration Testing Methods

### Comprehensive Testing Framework

Implement thorough testing procedures:

```python
import pytest
import asyncio

class ModelIntegrationTester:
    def __init__(self):
        self.test_cases = {
            'basic_functionality': self.test_basic_functionality,
            'error_handling': self.test_error_handling,
            'performance': self.test_performance,
            'security': self.test_security
        }
        
    async def run_test_suite(self):
        results = {}
        for test_name, test_func in self.test_cases.items():
            try:
                result = await test_func()
                results[test_name] = {
                    'status': 'passed',
                    'details': result
                }
            except Exception as e:
                results[test_name] = {
                    'status': 'failed',
                    'error': str(e)
                }
        return results
```

## Practical Exercises

1. **Basic Integration Setup**:
   Configure a basic integration with both Ollama and OpenAI APIs.

2. **Load Balancer Implementation**:
   Create a simple load balancer for multiple Ollama instances.

3. **Error Handling System**:
   Implement a comprehensive error handling system with retry logic.

## Troubleshooting Guide

Common integration issues and their solutions:

1. **Connection Issues**:
   - Check network connectivity
   - Verify endpoint configurations
   - Validate authentication credentials

2. **Performance Problems**:
   - Monitor resource usage
   - Check load balancing configuration
   - Verify rate limiting settings

## Best Practices Summary

1. **Security**:
   - Implement robust authentication
   - Secure credential management
   - Regular security audits

2. **Performance**:
   - Efficient load balancing
   - Proper error handling
   - Regular monitoring

3. **Maintenance**:
   - Regular testing
   - Documentation updates
   - Performance optimization

## Further Reading and Resources

1. **Official Documentation**:
   - [Open WebUI Integration Guide](https://docs.openwebui.com)
   - [Ollama API Documentation](https://ollama.com/docs)
   - [OpenAI API Reference](https://platform.openai.com/docs)

2. **Community Resources**:
   - [Integration Best Practices](https://github.com/open-webui/open-webui/discussions)
   - [Performance Optimization Tips](https://github.com/open-webui/open-webui/wiki)

This lesson provides a comprehensive overview of model integration in Open WebUI. In the next lesson, we'll explore advanced model features and optimizations.
