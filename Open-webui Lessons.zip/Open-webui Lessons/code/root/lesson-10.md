# Lesson 10: Development Tools and Utilities

## Overview
This final lesson explores the development tools and utilities that support the Open WebUI project. We'll examine the build configurations, development scripts, formatting tools, and workflow optimization techniques that make development efficient and consistent.

## Build Configuration Files

### Package Configuration
The `package.json` file defines project metadata and scripts:

```json
{
  "name": "open-webui",
  "version": "0.3.35",
  "private": true,
  "scripts": {
    "dev": "npm run pyodide:fetch && vite dev --host",
    "build": "npm run pyodide:fetch && vite build",
    "preview": "vite preview",
    "check": "svelte-kit sync && svelte-check --tsconfig ./tsconfig.json",
    "lint": "npm run lint:frontend ; npm run lint:types ; npm run lint:backend",
    "format": "prettier --plugin-search-dir --write \"**/*.{js,ts,svelte,css,md,html,json}\"",
    "i18n:parse": "i18next --config i18next-parser.config.ts"
  }
}
```

Features:
1. Development scripts
2. Build commands
3. Testing utilities
4. Format tooling

### TypeScript Configuration
`tsconfig.json` manages TypeScript settings:

```json
{
  "extends": "./.svelte-kit/tsconfig.json",
  "compilerOptions": {
    "allowJs": true,
    "checkJs": true,
    "esModuleInterop": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "skipLibCheck": true,
    "sourceMap": true,
    "strict": true
  }
}
```

Controls:
1. Type checking
2. Module resolution
3. Compilation options
4. Development tools

### Vite Configuration
`vite.config.ts` handles build and development:

```typescript
import { sveltekit } from '@sveltejs/kit/vite';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [sveltekit()],
  define: {
    APP_VERSION: JSON.stringify(process.env.npm_package_version),
    APP_BUILD_HASH: JSON.stringify(process.env.APP_BUILD_HASH || 'dev-build')
  },
  build: {
    sourcemap: true
  },
  worker: {
    format: 'es'
  }
});
```

Features:
1. Plugin system
2. Build optimization
3. Development server
4. Asset handling

## Development Scripts

### Build Scripts
Key scripts include:
1. `run-compose.sh`
2. `confirm_remove.sh`
3. `update_ollama_models.sh`
4. `prepare-pyodide.js`

Example script structure:
```bash
#!/bin/bash
echo "Warning: This will remove all containers and volumes..." 
read ans
if [ "$ans" == "Y" ] || [ "$ans" == "y" ]; then
  docker compose down -v
else
  echo "Operation cancelled."
fi
```

### Utility Scripts
Located in `scripts/`:
1. Build helpers
2. Development tools
3. Update scripts
4. Maintenance utilities

## Code Formatting and Linting

### ESLint Configuration
`.eslintrc.cjs` defines linting rules:

```javascript
module.exports = {
  root: true,
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended',
    'plugin:svelte/recommended',
    'plugin:cypress/recommended',
    'prettier'
  ],
  parser: '@typescript-eslint/parser',
  plugins: ['@typescript-eslint']
};
```

Features:
1. Code standards
2. Error detection
3. Style enforcement
4. Plugin integration

### Prettier Configuration
`.prettierrc` manages code formatting:

```json
{
  "useTabs": true,
  "singleQuote": true,
  "trailingComma": "none",
  "printWidth": 100,
  "plugins": ["prettier-plugin-svelte"],
  "overrides": [
    { "files": "*.svelte", "options": { "parser": "svelte" } }
  ]
}
```

Controls:
1. Code style
2. Format rules
3. File handling
4. Parser options

## Version Control Integration

### Git Configuration
`.gitattributes` and `.gitignore`:

```
# .gitattributes
*.sh text eol=lf

# .gitignore
node_modules/
/build
.env
.DS_Store
```

Features:
1. File handling
2. Line endings
3. Ignore patterns
4. Attribute management

## Development Workflow

### Local Development
Steps:
1. Environment setup
2. Dependency installation
3. Development server
4. Testing setup

### Build Process
Stages:
1. Code compilation
2. Asset processing
3. Optimization
4. Distribution

## Development Tools

### Node.js Tools
1. NPM scripts
2. Package management
3. Development server
4. Build utilities

### Python Tools
1. Virtual environments
2. Package management
3. Testing framework
4. Development utilities

## Best Practices

### Code Organization
1. File structure
2. Naming conventions
3. Module organization
4. Component architecture

### Development Workflow
1. Branch strategy
2. Commit practices
3. Review process
4. Release management

## Common Issues and Solutions

### Development Problems
1. Build failures
2. Dependency conflicts
3. Version mismatches
4. Environment issues

### Solutions
1. Troubleshooting steps
2. Common fixes
3. Prevention strategies
4. Best practices

## Performance Optimization

### Build Optimization
1. Code splitting
2. Asset optimization
3. Cache strategies
4. Bundle analysis

### Development Performance
1. Hot reloading
2. Cache utilization
3. Resource management
4. Tool configuration

## Security Considerations

### Development Security
1. Dependency scanning
2. Code analysis
3. Security testing
4. Best practices

### Build Security
1. Asset protection
2. Source maps
3. Environment variables
4. Access control

## Practical Exercise

### Task 1: Tool Setup
1. Configure environment
2. Install tools
3. Set up linting
4. Configure formatting

### Task 2: Workflow Implementation
1. Create build script
2. Implement testing
3. Configure CI/CD
4. Document process

## Cross-Platform Development

### Platform Considerations
1. Windows development
2. Linux development
3. macOS development
4. Container development

### Environment Setup
1. Tool installation
2. Path configuration
3. Permission handling
4. Platform-specific issues

## Continuous Integration

### CI/CD Setup
1. GitHub Actions
2. Build pipelines
3. Test automation
4. Deployment process

### Quality Gates
1. Code quality
2. Test coverage
3. Performance metrics
4. Security scans

## Course Conclusion

### Key Takeaways
1. Development workflow
2. Tool utilization
3. Best practices
4. Problem-solving strategies

### Next Steps
1. Advanced topics
2. Community contribution
3. Project maintenance
4. Continuing education

## Additional Resources
- Development tool documentation
- Build optimization guides
- Workflow best practices
- Community resources
