# Lesson 6: Docker Configuration

## Overview
Docker plays a crucial role in Open WebUI's deployment and development workflow. This lesson explores the Docker configuration files, container orchestration, and deployment strategies used in the project.

## Docker Configuration Files

### Primary Docker Files
The project includes several Docker-related files:
```
/
├── Dockerfile
├── docker-compose.yaml
├── docker-compose.gpu.yaml
├── docker-compose.api.yaml
├── docker-compose.data.yaml
└── docker-compose.amdgpu.yaml
```

## Dockerfile Analysis

### Build Arguments
```dockerfile
ARG USE_CUDA=false
ARG USE_OLLAMA=false
ARG USE_CUDA_VER=cu121
ARG USE_EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
ARG USE_RERANKING_MODEL=""
ARG USE_TIKTOKEN_ENCODING_NAME="cl100k_base"
ARG BUILD_HASH=dev-build
ARG UID=0
ARG GID=0
```

These arguments control:
- GPU support configuration
- Model selection
- Encoding settings
- Build identification
- User permissions

### Multi-Stage Build

#### Frontend Stage
```dockerfile
FROM --platform=$BUILDPLATFORM node:22-alpine3.20 AS build
ARG BUILD_HASH
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci
COPY . .
ENV APP_BUILD_HASH=${BUILD_HASH}
RUN npm run build
```

This stage:
1. Sets up Node.js environment
2. Installs dependencies
3. Builds frontend assets
4. Prepares for production

#### Backend Stage
```dockerfile
FROM python:3.11-slim-bookworm AS base
```

Handles:
1. Python environment setup
2. Backend dependencies
3. Server configuration
4. Production optimization

## Docker Compose Configuration

### Base Configuration (docker-compose.yaml)

```yaml
services:
  ollama:
    volumes:
      - ollama:/root/.ollama
    container_name: ollama
    pull_policy: always
    tty: true
    restart: unless-stopped
    image: ollama/ollama:${OLLAMA_DOCKER_TAG-latest}

  open-webui:
    build:
      context: .
      args:
        OLLAMA_BASE_URL: '/ollama'
      dockerfile: Dockerfile
    image: ghcr.io/open-webui/open-webui:${WEBUI_DOCKER_TAG-main}
    container_name: open-webui
    volumes:
      - open-webui:/app/backend/data
    depends_on:
      - ollama
    ports:
      - ${OPEN_WEBUI_PORT-3000}:8080
```

This configuration:
1. Defines service structure
2. Sets up volumes
3. Configures networking
4. Manages dependencies

### GPU Support (docker-compose.gpu.yaml)

```yaml
services:
  ollama:
    deploy:
      resources:
        reservations:
          devices:
            - driver: ${OLLAMA_GPU_DRIVER-nvidia}
              count: ${OLLAMA_GPU_COUNT-1}
              capabilities:
                - gpu
```

Enables:
1. GPU access
2. Resource allocation
3. Driver configuration
4. Performance optimization

### API Configuration (docker-compose.api.yaml)

```yaml
services:
  ollama:
    ports:
      - ${OLLAMA_WEBAPI_PORT-11434}:11434
```

Manages:
1. API exposure
2. Port mapping
3. Service access
4. Network security

## Environment Configuration

### Environment Variables
Key variables include:
1. `OLLAMA_BASE_URL`
2. `OPENAI_API_BASE_URL`
3. `OPENAI_API_KEY`
4. `WEBUI_SECRET_KEY`

### Volume Management
```yaml
volumes:
  ollama: {}
  open-webui: {}
```

Handles:
1. Data persistence
2. State management
3. File storage
4. Backup support

## Deployment Configurations

### Development Setup
1. Local development
2. Hot reloading
3. Debug support
4. Test environment

### Production Deployment
1. Optimization
2. Security
3. Scaling
4. Monitoring

## GPU Support

### NVIDIA Configuration
```yaml
deploy:
  resources:
    reservations:
      devices:
        - driver: nvidia
          count: 1
          capabilities:
            - gpu
```

Features:
1. GPU allocation
2. Driver management
3. Resource limits
4. Performance tuning

### AMD GPU Support
```yaml
services:
  ollama:
    devices:
      - /dev/kfd:/dev/kfd
      - /dev/dri:/dev/dri
    image: ollama/ollama:${OLLAMA_DOCKER_TAG-rocm}
    environment:
      - 'HSA_OVERRIDE_GFX_VERSION=${HSA_OVERRIDE_GFX_VERSION-11.0.0}'
```

Enables:
1. AMD GPU support
2. Device mapping
3. Driver configuration
4. Performance optimization

## Container Orchestration

### Service Dependencies
1. Service order
2. Health checks
3. Restart policies
4. Network setup

### Resource Management
1. Memory limits
2. CPU allocation
3. Storage configuration
4. Network resources

## Best Practices

### Security Considerations
1. Image scanning
2. Secret management
3. Access control
4. Network isolation

### Performance Optimization
1. Layer caching
2. Multi-stage builds
3. Image size reduction
4. Resource efficiency

## Common Issues and Solutions

### Troubleshooting
1. Build failures
2. Container startup
3. Volume permissions
4. Network connectivity

### Solutions
1. Log analysis
2. Configuration review
3. Permission checks
4. Network debugging

## Practical Exercise

### Task 1: Basic Setup
1. Build images
2. Run containers
3. Test functionality
4. Debug issues

### Task 2: Advanced Configuration
1. Enable GPU support
2. Configure API access
3. Optimize performance
4. Implement monitoring

## Next Steps

In the next lesson, we'll explore Kubernetes implementation, understanding how to deploy Open WebUI in a containerized cluster environment.

## Additional Resources
- Docker documentation
- Compose file reference
- GPU container toolkit
- Container security guides
