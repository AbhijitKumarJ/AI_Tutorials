# Lesson 9: Static Assets and Theming (static/ folder)

## Overview
The static/ directory in Open WebUI manages all static assets and theming components. This lesson explores how static assets are organized, how themes are implemented, and how to manage various resources for the application.

## Static Directory Structure

### Root Level Organization
```
static/
├── manifest.json
├── opensearch.xml
├── robots.txt
├── assets/
│   └── fonts/
├── audio/
├── pyodide/
├── static/
│   ├── favicon.png
│   ├── splash-dark.png
│   └── splash.png
└── themes/
    ├── rosepine-dawn.css
    └── rosepine.css
```

## Core Components

### Manifest Configuration
The `manifest.json` file defines Progressive Web App (PWA) settings:
```json
{
  "name": "Open WebUI",
  "short_name": "OpenUI",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#000000"
}
```

Purpose:
- PWA configuration
- App metadata
- Installation settings
- Theme colors

### Search Configuration
`opensearch.xml` provides browser search integration:
```xml
<OpenSearchDescription xmlns="http://a9.com/-/spec/opensearch/1.1/">
    <ShortName>Open WebUI</ShortName>
    <Description>Search Open WebUI</Description>
    <InputEncoding>UTF-8</InputEncoding>
    <Image width="16" height="16" type="image/x-icon">
        http://localhost:5137/favicon.png
    </Image>
    <Url type="text/html" method="get" 
         template="http://localhost:5137/?q={searchTerms}"/>
</OpenSearchDescription>
```

Features:
- Browser integration
- Search functionality
- Metadata description
- Icon settings

### Robot Control
`robots.txt` manages search engine behavior:
```txt
User-agent: *
Disallow: /
```

Purpose:
- Search engine control
- Crawling rules
- Access restrictions
- Privacy settings

## Theme Implementation

### Rose Pine Theme
`rosepine.css` implements dark theme:

```css
.rose-pine * {
    color: #e0def4 !important;
    stroke: #907aa9 !important;
}

.rose-pine .app > * {
    background-color: #1f1d2e !important;
}

.rose-pine #nav {
    background-color: #191724;
}
```

Features:
1. Color schemes
2. Typography
3. Component styling
4. Layout configuration

### Rose Pine Dawn Theme
`rosepine-dawn.css` implements light theme:

```css
.rose-pine-dawn * {
    color: #575279 !important;
    stroke: #d7827e !important;
}

.rose-pine-dawn .app > * {
    background-color: #faf4ed !important;
}
```

Components:
1. Light color palette
2. Contrast settings
3. Visual hierarchy
4. Accessibility considerations

## Asset Organization

### Font Management
```
assets/fonts/
```
Handles:
1. Custom fonts
2. Font variations
3. Font formats
4. Loading optimization

### Audio Resources
```
audio/
```
Contains:
1. Sound effects
2. Notification sounds
3. Interface feedback
4. Audio assets

### Python Web Assembly
```
pyodide/
```
Manages:
1. Pyodide files
2. WASM modules
3. Python packages
4. Runtime components

## Theme Structure

### Common Elements
1. Color variables
2. Typography settings
3. Spacing rules
4. Component styles

### Customization Points
1. Color schemes
2. Layout options
3. Component variants
4. Visual effects

## Implementation Details

### Color Management
```css
:root {
    --primary-color: #e0def4;
    --secondary-color: #907aa9;
    --background-color: #1f1d2e;
    --text-color: #e0def4;
}
```

Features:
1. CSS variables
2. Color inheritance
3. Theme switching
4. Dark/light modes

### Component Styling
```css
.component-class {
    background-color: var(--background-color);
    color: var(--text-color);
    padding: var(--spacing-unit);
    margin: var(--margin-unit);
}
```

Aspects:
1. Modular design
2. Responsive layout
3. Theme integration
4. Style inheritance

## Asset Management

### Image Resources
Management of:
1. Icons
2. Splash screens
3. Favicons
4. Interface graphics

### Static File Serving
Considerations for:
1. Caching strategy
2. Performance optimization
3. Version control
4. Content delivery

## Theme Customization

### Creating New Themes
Steps:
1. Define color palette
2. Create CSS variables
3. Implement component styles
4. Test across devices

### Theme Switching
Implementation:
1. Theme detection
2. User preferences
3. System integration
4. Smooth transitions

## Best Practices

### Asset Optimization
1. Image compression
2. Font subsetting
3. File minification
4. Cache utilization

### Theme Development
1. Consistent naming
2. Modular structure
3. Documentation
4. Testing strategy

## Common Issues and Solutions

### Asset Loading
Issues:
1. Slow loading times
2. Missing resources
3. Version conflicts
4. Cache problems

Solutions:
1. Optimization techniques
2. Error handling
3. Version management
4. Cache strategies

## Practical Exercise

### Task 1: Theme Creation
1. Design color scheme
2. Implement CSS
3. Test components
4. Document changes

### Task 2: Asset Management
1. Organize resources
2. Optimize files
3. Implement caching
4. Test performance

## Cross-Platform Considerations

### Browser Support
1. Vendor prefixes
2. Feature detection
3. Fallback strategies
4. Progressive enhancement

### Device Compatibility
1. Responsive design
2. Touch interfaces
3. Screen sizes
4. Platform specifics

## Next Steps

In the next lesson, we'll explore development tools and utilities, understanding how to optimize the development workflow in Open WebUI.

## Additional Resources
- CSS architecture guides
- Asset optimization tools
- Theme design patterns
- Performance best practices
