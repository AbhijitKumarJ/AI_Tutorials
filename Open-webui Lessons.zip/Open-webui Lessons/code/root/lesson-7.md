# Lesson 7: Kubernetes Implementation

## Overview
This lesson explores the Kubernetes implementation in Open WebUI, focusing on how the application is deployed and managed in a Kubernetes cluster. We'll examine the manifest files, Helm charts, and deployment strategies that enable scalable and maintainable container orchestration.

## Kubernetes Directory Structure

### Project Organization
```
kubernetes/
├── helm/
│   └── README.md
└── manifest/
    ├── base/
    │   ├── kustomization.yaml
    │   ├── ollama-service.yaml
    │   ├── ollama-statefulset.yaml
    │   ├── open-webui.yaml
    │   ├── webui-deployment.yaml
    │   ├── webui-ingress.yaml
    │   ├── webui-pvc.yaml
    │   └── webui-service.yaml
    └── gpu/
        ├── kustomization.yaml
        └── ollama-statefulset-gpu.yaml
```

## Base Configuration

### Namespace Definition
`open-webui.yaml`:
```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: open-webui
```

Purpose:
- Resource isolation
- Access control
- Resource quotas
- Network policies

### StatefulSet Configuration

#### Ollama StatefulSet
`ollama-statefulset.yaml`:
```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: ollama
  namespace: open-webui
spec:
  serviceName: "ollama"
  replicas: 1
  selector:
    matchLabels:
      app: ollama
  template:
    metadata:
      labels:
        app: ollama
    spec:
      containers:
      - name: ollama
        image: ollama/ollama:latest
        ports:
        - containerPort: 11434
        resources:
          requests:
            cpu: "2000m"
            memory: "2Gi"
          limits:
            cpu: "4000m"
            memory: "4Gi"
```

Features:
1. Resource management
2. State persistence
3. Network configuration
4. Container specification

### Service Definitions

#### Ollama Service
`ollama-service.yaml`:
```yaml
apiVersion: v1
kind: Service
metadata:
  name: ollama-service
  namespace: open-webui
spec:
  selector:
    app: ollama
  ports:
  - protocol: TCP
    port: 11434
    targetPort: 11434
```

#### WebUI Service
`webui-service.yaml`:
```yaml
apiVersion: v1
kind: Service
metadata:
  name: open-webui-service
  namespace: open-webui
spec:
  type: NodePort
  selector:
    app: open-webui
  ports:
    - protocol: TCP
      port: 8080
      targetPort: 8080
```

Service features:
1. Load balancing
2. Service discovery
3. Port mapping
4. Network policies

## Deployment Configuration

### WebUI Deployment
`webui-deployment.yaml`:
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: open-webui-deployment
  namespace: open-webui
spec:
  replicas: 1
  selector:
    matchLabels:
      app: open-webui
  template:
    metadata:
      labels:
        app: open-webui
    spec:
      containers:
      - name: open-webui
        image: ghcr.io/open-webui/open-webui:main
        ports:
        - containerPort: 8080
        env:
        - name: OLLAMA_BASE_URL
          value: "http://ollama-service.open-webui.svc.cluster.local:11434"
```

Key aspects:
1. Replica management
2. Container configuration
3. Environment variables
4. Resource allocation

## Persistent Storage

### PVC Configuration
`webui-pvc.yaml`:
```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  labels:
    app: open-webui
  name: open-webui-pvc
  namespace: open-webui
spec:
  accessModes: ["ReadWriteOnce"]
  resources:
    requests:
      storage: 2Gi
```

Storage features:
1. Volume claims
2. Storage classes
3. Access modes
4. Capacity planning

## Ingress Configuration

### Ingress Rules
`webui-ingress.yaml`:
```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: open-webui-ingress
  namespace: open-webui
spec:
  rules:
  - host: open-webui.minikube.local
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: open-webui-service
            port:
              number: 8080
```

Ingress features:
1. Host routing
2. Path configuration
3. TLS termination
4. Load balancing

## GPU Support

### GPU Configuration
`gpu/ollama-statefulset-gpu.yaml`:
```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: ollama
  namespace: open-webui
spec:
  selector:
    matchLabels:
      app: ollama
  template:
    spec:
      containers:
      - name: ollama
        resources:
          limits:
            nvidia.com/gpu: "1"
```

GPU features:
1. Device allocation
2. Resource limits
3. Driver configuration
4. Scheduling policies

## Kustomization

### Base Configuration
`base/kustomization.yaml`:
```yaml
resources:
  - open-webui.yaml
  - ollama-service.yaml
  - ollama-statefulset.yaml
  - webui-deployment.yaml
  - webui-service.yaml
  - webui-ingress.yaml
  - webui-pvc.yaml
```

### GPU Overlay
`gpu/kustomization.yaml`:
```yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
  - ../base
patches:
  - path: ollama-statefulset-gpu.yaml
```

Kustomize features:
1. Resource composition
2. Configuration variants
3. Patch management
4. Environment overlays

## Deployment Strategies

### Rolling Updates
1. Update configuration
2. Health checks
3. Rollback procedures
4. Version control

### Scaling Configuration
1. Horizontal scaling
2. Vertical scaling
3. Resource allocation
4. Load balancing

## Best Practices

### Security
1. RBAC configuration
2. Network policies
3. Secret management
4. Pod security

### Resource Management
1. Request/limits
2. Quota management
3. Namespace isolation
4. Node selection

## Common Issues and Solutions

### Troubleshooting
1. Pod failures
2. Network issues
3. Storage problems
4. Resource constraints

### Debugging
1. Log analysis
2. Event monitoring
3. Resource tracking
4. Network debugging

## Practical Exercise

### Task 1: Basic Deployment
1. Setup minikube
2. Deploy base configuration
3. Verify services
4. Test functionality

### Task 2: Advanced Configuration
1. Enable GPU support
2. Configure ingress
3. Setup monitoring
4. Implement scaling

## Next Steps

In the next lesson, we'll explore project documentation and support resources, understanding how to maintain and contribute to the Open WebUI project effectively.

## Additional Resources
- Kubernetes documentation
- Kustomize guides
- GPU operator documentation
- Container orchestration patterns
