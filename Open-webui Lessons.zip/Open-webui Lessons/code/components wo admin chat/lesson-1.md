# Lesson 1: Foundation Components and Design Principles

## Introduction to Foundation Components

Welcome to our first lesson in mastering modern UI components. In this comprehensive session, we'll explore the fundamental building blocks that form the basis of our component library. We'll examine how these foundational elements are structured, how they interact, and how they come together to create a cohesive user interface.

## Component Library Structure

Let's first understand how the foundation components are organized in our codebase. The basic components are located in the `src/lib/components/common` directory. Here's the relevant structure:

```
components/
  common/
    Badge.svelte
    Banner.svelte
    Checkbox.svelte
    Switch.svelte
    Button.svelte
    Input.svelte
    Modal.svelte
    Tooltip.svelte
```

This organized structure helps maintain clarity and makes components easily discoverable.

## Understanding Basic UI Building Blocks

### Badge Component
The Badge component (`Badge.svelte`) serves as a perfect example of a foundational UI element. Let's examine its implementation:

```svelte
<script lang="ts">
    export let type = 'info';
    export let content = '';

    const classNames: Record<string, string> = {
        info: 'bg-blue-500/20 text-blue-700 dark:text-blue-200',
        success: 'bg-green-500/20 text-green-700 dark:text-green-200',
        warning: 'bg-yellow-500/20 text-yellow-700 dark:text-yellow-200',
        error: 'bg-red-500/20 text-red-700 dark:text-red-200',
        muted: 'bg-gray-500/20 text-gray-700 dark:text-gray-200'
    };
</script>

<div class="text-xs font-bold {classNames[type] ?? classNames['info']} w-fit px-2 rounded uppercase line-clamp-1 mr-0.5">
    {content}
</div>
```

The Badge component demonstrates several important principles:
1. **Props Interface**: It accepts two props - `type` for styling variations and `content` for the display text
2. **Type System**: Utilizes TypeScript for type safety
3. **Design System Integration**: Uses consistent color schemes through class mappings
4. **Responsive Design**: Uses utility classes for proper sizing and spacing
5. **Dark Mode Support**: Includes dark mode variants with the `dark:` prefix

### Switch Component
The Switch component (`Switch.svelte`) showcases more complex interactions:

```svelte
<script lang="ts">
    import { createEventDispatcher, tick } from 'svelte';
    import { Switch } from 'bits-ui';
    export let state = true;

    const dispatch = createEventDispatcher();
</script>

<Switch.Root
    bind:checked={state}
    onCheckedChange={async (e) => {
        await tick();
        dispatch('change', e);
    }}
    class="flex h-5 min-h-5 w-9 shrink-0 cursor-pointer items-center rounded-full px-[3px] mx-[1px] transition 
        {state ? 'bg-emerald-600' : 'bg-gray-200 dark:bg-transparent'} 
        outline outline-1 outline-gray-100 dark:outline-gray-800"
>
    <Switch.Thumb
        class="pointer-events-none block size-4 shrink-0 rounded-full bg-white transition-transform 
            data-[state=checked]:translate-x-3.5 data-[state=unchecked]:translate-x-0 
            data-[state=unchecked]:shadow-mini"
    />
</Switch.Root>
```

This component demonstrates:
1. **Component Composition**: Uses the bits-ui library for base functionality
2. **State Management**: Handles internal state and provides external state binding
3. **Event Dispatching**: Uses Svelte's event dispatch system
4. **Transitions**: Implements smooth transitions for state changes
5. **Accessibility**: Inherits accessibility features from bits-ui

## Accessibility Implementation

Accessibility is a crucial aspect of our foundation components. Here's how we implement it:

1. **ARIA Attributes**: Components use appropriate ARIA roles and states
2. **Keyboard Navigation**: All interactive components are keyboard accessible
3. **Focus Management**: Proper focus handling and visual indicators
4. **Screen Reader Support**: Meaningful labels and descriptions

Example from our Button component:
```svelte
<button
    class="focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
    aria-label={ariaLabel}
    {disabled}
    on:click
>
    <slot />
</button>
```

## Event Handling and Component Communication

Our components implement a robust event handling system. Let's examine the pattern:

1. **Event Dispatching**: Using Svelte's createEventDispatcher
```typescript
const dispatch = createEventDispatcher();
dispatch('change', newValue);
```

2. **Event Bubbling**: Proper event propagation control
```svelte
<button on:click|stopPropagation={() => {
    // Handle click
}}>
```

3. **Two-way Binding**: Using Svelte's bind: directive
```svelte
<input bind:value={inputValue} on:input={handleInput} />
```

## Design System Integration

Our components integrate with a consistent design system:

1. **Color System**:
```javascript
const colors = {
    primary: {
        500: '#3B82F6',
        600: '#2563EB',
        700: '#1D4ED8'
    },
    // ... other color definitions
};
```

2. **Spacing System**:
```javascript
const spacing = {
    px: '1px',
    0: '0',
    0.5: '0.125rem',
    1: '0.25rem',
    // ... other spacing values
};
```

3. **Typography System**:
```javascript
const typography = {
    sans: ['Inter var', 'sans-serif'],
    sizes: {
        xs: ['0.75rem', '1rem'],
        sm: ['0.875rem', '1.25rem'],
        // ... other size definitions
    }
};
```

## Cross-platform Considerations

Our foundation components are built with cross-platform compatibility in mind:

1. **Touch Targets**: Ensuring appropriate sizing for touch devices
```css
.touch-target {
    min-height: 44px; /* iOS minimum touch target size */
    min-width: 44px;
}
```

2. **Platform-specific Behaviors**:
```typescript
const isTouchDevice = 'ontouchstart' in window;
const interactionEvents = isTouchDevice 
    ? { onTouchStart, onTouchEnd }
    : { onMouseDown, onMouseUp };
```

## Conclusion

Understanding these foundation components and their underlying principles is crucial for building more complex UI elements. Each component serves as a building block that can be composed into more sophisticated interfaces while maintaining consistency, accessibility, and cross-platform compatibility.

In the next lesson, we'll explore how these foundation components come together to create layout structures and more complex UI patterns.

## Exercise

Try creating a simple form using the foundation components we've covered:
1. Create a form with input fields
2. Add validation using the Badge component for error states
3. Implement a submit button with loading state
4. Ensure the form is fully accessible
5. Test the form across different devices and platforms

This will help solidify your understanding of the concepts covered in this lesson.

Remember to follow the established patterns and principles we've discussed, paying particular attention to accessibility and cross-platform considerations.