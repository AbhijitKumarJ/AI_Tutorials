# Lesson 2: Layout and Structure

## Introduction to Layout Components

In this lesson, we'll dive deep into the components that form the structural foundation of our applications. Layout components are crucial as they define how content is organized and presented to users. We'll explore how these components work together to create fluid, responsive, and accessible layouts.

## Component Library Structure

The layout components are organized in the following directory structure:

```
components/
    layout/
        Navbar.svelte
        Sidebar.svelte
        Help.svelte
        UpdateInfoToast.svelte
    common/
        Modal.svelte
        Drawer.svelte
        Collapsible.svelte
```

## Modal Implementation

Let's start with one of the most important layout components - the Modal. Our implementation in `Modal.svelte` showcases several advanced concepts:

```svelte
<script lang="ts">
    import { onDestroy, onMount } from 'svelte';
    import { fade } from 'svelte/transition';
    import { flyAndScale } from '$lib/utils/transitions';

    export let show = true;
    export let size = 'md';
    export let className = 'bg-gray-50 dark:bg-gray-900 rounded-2xl';

    let modalElement = null;
    let mounted = false;

    const sizeToWidth = (size) => {
        if (size === 'full') return 'w-full';
        if (size === 'xs') return 'w-[16rem]';
        if (size === 'sm') return 'w-[30rem]';
        if (size === 'md') return 'w-[48rem]';
        return 'w-[56rem]';
    };

    const handleKeyDown = (event: KeyboardEvent) => {
        if (event.key === 'Escape' && isTopModal()) {
            show = false;
        }
    };

    const isTopModal = () => {
        const modals = document.getElementsByClassName('modal');
        return modals.length && modals[modals.length - 1] === modalElement;
    };

    $: if (show && modalElement) {
        document.body.appendChild(modalElement);
        window.addEventListener('keydown', handleKeyDown);
        document.body.style.overflow = 'hidden';
    } else if (modalElement) {
        window.removeEventListener('keydown', handleKeyDown);
        document.body.removeChild(modalElement);
        document.body.style.overflow = 'unset';
    }

    onDestroy(() => {
        show = false;
        if (modalElement) {
            document.body.removeChild(modalElement);
        }
    });
</script>

{#if show}
    <div
        bind:this={modalElement}
        class="modal fixed top-0 right-0 left-0 bottom-0 bg-black/60 w-full h-screen 
               max-h-[100dvh] flex justify-center z-[9999] overflow-hidden overscroll-contain"
        in:fade={{ duration: 10 }}
        on:mousedown={() => {
            show = false;
        }}
    >
        <div
            class="m-auto max-w-full {sizeToWidth(size)} {size !== 'full' ? 'mx-2' : ''} 
                   shadow-3xl max-h-[100dvh] overflow-y-auto scrollbar-hidden {className}"
            in:flyAndScale
            on:mousedown={(e) => {
                e.stopPropagation();
            }}
        >
            <slot />
        </div>
    </div>
{/if}
```

Key concepts demonstrated in the Modal component:
1. **Document Body Management**: Handles overflow and modal stacking
2. **Keyboard Accessibility**: Implements Escape key handling
3. **Event Propagation**: Careful handling of click events
4. **Responsive Design**: Size adaptations for different screen sizes
5. **Transitions**: Smooth enter/exit animations
6. **Z-index Management**: Proper layering of multiple modals
7. **Memory Management**: Proper cleanup on component destruction

## Drawer Component

The Drawer component (`Drawer.svelte`) implements a sliding panel that can emerge from any edge of the screen:

```svelte
<script lang="ts">
    import { onDestroy, onMount, createEventDispatcher } from 'svelte';
    import { flyAndScale } from '$lib/utils/transitions';
    import { fade, fly, slide } from 'svelte/transition';

    export let show = false;
    export let className = '';
    export let side = 'right';

    const dispatch = createEventDispatcher();
    let drawerElement = null;

    onMount(() => {
        if (show) {
            document.body.style.overflow = 'hidden';
        }
    });

    $: if (show && drawerElement) {
        document.body.style.overflow = 'hidden';
    } else if (drawerElement) {
        document.body.style.overflow = 'unset';
        dispatch('close');
    }
</script>

{#if show}
    <div
        class="absolute z-20 top-0 right-0 left-0 bottom-0 bg-white/20 dark:bg-black/5 
               w-full min-h-full h-full flex justify-center overflow-hidden overscroll-contain"
        on:mousedown={() => {
            show = false;
        }}
        transition:fade
    />

    <div
        class="absolute z-30 shadow-xl {side === 'right' ? 'right-0' : 'left-0'} top-0 bottom-0"
        transition:slide={{ easing: quadInOut, axis: side === 'right' ? 'x' : 'y' }}
    >
        <div class="{className} h-full" style="width: {show ? width : '0px'}">
            <slot />
        </div>
    </div>
{/if}
```

The Drawer component demonstrates:
1. **Dynamic Positioning**: Support for different sides
2. **Smooth Animations**: Using Svelte's built-in transitions
3. **Backdrop Handling**: Semi-transparent overlay
4. **Width Management**: Dynamic width control
5. **Event Dispatching**: Notifying parent components of state changes

## Collapsible Implementation

The Collapsible component (`Collapsible.svelte`) provides expandable/collapsible sections:

```svelte
<script lang="ts">
    import { getContext, createEventDispatcher } from 'svelte';
    const dispatch = createEventDispatcher();
    $: dispatch('change', open);

    import { slide } from 'svelte/transition';
    import { quintOut } from 'svelte/easing';

    export let open = false;
    export let className = '';
    export let buttonClassName = 'w-fit text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition';
    export let title = null;
    export let grow = false;
</script>

<div class={className}>
    {#if title !== null}
        <div
            class="{buttonClassName} cursor-pointer"
            on:pointerup={() => {
                open = !open;
            }}
        >
            <div class="w-full font-medium flex items-center justify-between gap-2">
                <div class="">
                    {title}
                </div>
                <div>
                    {#if open}
                        <ChevronUp strokeWidth="3.5" className="size-3.5" />
                    {:else}
                        <ChevronDown strokeWidth="3.5" className="size-3.5" />
                    {/if}
                </div>
            </div>
        </div>
    {/if}

    {#if !grow}
        {#if open}
            <div transition:slide={{ duration: 300, easing: quintOut, axis: 'y' }}>
                <slot name="content" />
            </div>
        {/if}
    {/if}
</div>
```

Key features of the Collapsible component:
1. **Flexible Content**: Supports both simple and complex content
2. **Smooth Transitions**: Uses slide transitions for smooth expansion/collapse
3. **Customizable Styling**: Extensive style customization options
4. **Event Handling**: Proper event dispatching for state changes

## Sidebar Implementation

The Sidebar component (`Sidebar.svelte`) provides navigation and content organization:

```svelte
<script lang="ts">
    import { showSettings, showArchivedChats, mobile, showSidebar } from '$lib/stores';
    
    export let show = false;
    export let side = 'right';
    export let width = '200px';
</script>

{#if show}
    <div
        class="absolute z-20 top-0 right-0 left-0 bottom-0 bg-white/20 dark:bg-black/5 
               w-full min-h-full h-full flex justify-center overflow-hidden overscroll-contain"
        on:mousedown={() => {
            show = false;
        }}
        transition:fade
    />

    <div
        class="absolute z-30 shadow-xl {side === 'right' ? 'right-0' : 'left-0'} top-0 bottom-0"
        transition:slide={{ easing: quadInOut, axis: side === 'right' ? 'x' : 'y' }}
    >
        <div class="{className} h-full" style="width: {show ? width : '0px'}">
            <slot />
        </div>
    </div>
{/if}
```

The Sidebar demonstrates:
1. **Responsive Design**: Adapts to different screen sizes
2. **State Management**: Integration with application-wide state
3. **Mobile Considerations**: Special handling for mobile views
4. **Customizable Width**: Dynamic width control

## Advanced Layout Patterns

### Z-index Management
We implement a consistent z-index strategy across components:

```typescript
const zIndexLevels = {
    base: 0,
    dropdown: 1000,
    sticky: 1200,
    fixed: 1300,
    modalBackdrop: 1400,
    modal: 1500,
    popover: 1600,
    tooltip: 1700
};
```

### Responsive Design Implementation
Our components use a mobile-first approach:

```typescript
const breakpoints = {
    sm: '640px',
    md: '768px',
    lg: '1024px',
    xl: '1280px',
    '2xl': '1536px'
};

// Usage in components
const isMobile = window.innerWidth < parseInt(breakpoints.md);
```

### Layout Composition Patterns
We follow these principles for component composition:
1. **Single Responsibility**: Each component handles one aspect of layout
2. **Flexible Slots**: Using Svelte slots for content injection
3. **Props for Configuration**: Extensive props for customization
4. **Event-based Communication**: Clear event patterns between components

## Performance Optimization

Several techniques are employed to ensure optimal performance:

1. **Lazy Loading**:
```typescript
const Modal = {
    component: () => import('./Modal.svelte')
};
```

2. **Content Virtualization**:
```typescript
import { virtualList } from '@sveltejs/virtualize';

<div use:virtualList={{ items, height: 30 }}>
    {#each visible as item}
        <div>{item}</div>
    {/each}
</div>
```

3. **Efficient DOM Updates**:
```svelte
{#if shouldRender}
    <div transition:fade>
        <slot />
    </div>
{/if}
```

## Cross-platform Considerations

Our layout components account for various platforms:

1. **Touch Events**:
```typescript
const handleInteraction = isTouchDevice
    ? { onTouchStart, onTouchEnd }
    : { onMouseDown, onMouseUp };
```

2. **Platform-specific Styles**:
```css
.scrollable {
    -webkit-overflow-scrolling: touch; /* iOS smooth scrolling */
    scrollbar-width: thin; /* Firefox scrollbar */
}
```

## Conclusion

Layout and structure components form the backbone of our UI system. Understanding how these components work together and following the established patterns ensures consistent, maintainable, and performant applications.

## Exercise

Create a complex layout that includes:
1. A responsive sidebar with collapsible sections
2. A modal system that can stack multiple modals
3. A drawer that can be triggered from different sides
4. Proper z-index management across all components
5. Full keyboard navigation support
6. Touch device support

Test the layout across different devices and screen sizes to ensure consistent behavior and appearance.

Remember to follow the established patterns and principles, paying particular attention to accessibility and responsive design.