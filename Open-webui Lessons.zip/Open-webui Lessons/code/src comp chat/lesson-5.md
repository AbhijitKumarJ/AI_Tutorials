# Lesson 5: Interactive Features

## Introduction
This lesson explores the interactive features of the chat application, focusing on real-time functionality, artifacts system, chat controls, and event handling. These features create a dynamic and responsive user experience.

## Table of Contents
1. Artifacts System
2. Chat Controls and Tooling
3. WebSocket Integration
4. Event System
5. Real-time Updates
6. Interactive UI Elements

## 1. Artifacts System

### Artifacts Component
From `Artifacts.svelte`, the artifacts management system:

```javascript
export let overlay = false;
export let history;
let messages = [];

let contents: Array<{ type: string; content: string }> = [];
let selectedContentIdx = 0;

// Content processing
const getContents = () => {
    contents = [];
    messages.forEach((message) => {
        if (message?.role !== 'user' && message?.content) {
            // Process code blocks
            const codeBlockContents = message.content.match(/```[\s\S]*?```/g);
            let codeBlocks = [];

            if (codeBlockContents) {
                codeBlockContents.forEach((block) => {
                    const lang = block.split('\n')[0].replace('```', '').trim();
                    const code = block.replace(/```[\s\S]*?\n/, '')
                        .replace(/```$/, '');
                    codeBlocks.push({ lang, code });
                });
            }

            // Process different content types
            if (htmlContent || cssContent || jsContent) {
                const renderedContent = `
                    <!DOCTYPE html>
                    <html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width">
                            <style>${cssContent}</style>
                        </head>
                        <body>
                            ${htmlContent}
                            <script>${jsContent}</script>
                        </body>
                    </html>
                `;
                contents = [...contents, { 
                    type: 'iframe', 
                    content: renderedContent 
                }];
            }
        }
    });
};
```

### Artifact Rendering
```javascript
<div class="w-full h-full relative flex flex-col bg-gray-50 dark:bg-gray-850">
    <div class="w-full h-full flex-1 relative">
        {#if contents.length > 0}
            <div class="max-w-full w-full h-full">
                {#if contents[selectedContentIdx].type === 'iframe'}
                    <iframe
                        bind:this={iframeElement}
                        title="Content"
                        srcdoc={contents[selectedContentIdx].content}
                        class="w-full border-0 h-full rounded-none"
                        sandbox="allow-scripts allow-forms allow-same-origin"
                        on:load={iframeLoadHandler}
                    />
                {:else if contents[selectedContentIdx].type === 'svg'}
                    <SvgPanZoom
                        className="w-full h-full max-h-full overflow-hidden"
                        svg={contents[selectedContentIdx].content}
                    />
                {/if}
            </div>
        {/if}
    </div>
</div>
```

## 2. Chat Controls and Tooling

### ChatControls Component
From `ChatControls.svelte`:

```javascript
export let history;
export let models = [];
export let chatId = null;
export let chatFiles = [];
export let params = {};
export let eventTarget: EventTarget;
export let submitPrompt: Function;
export let stopResponse: Function;
export let files;
export let modelId;

// Responsive handling
const handleMediaQuery = async (e) => {
    if (e.matches) {
        largeScreen = true;
        if ($showCallOverlay) {
            showCallOverlay.set(false);
            await tick();
            showCallOverlay.set(true);
        }
    } else {
        largeScreen = false;
        pane = null;
    }
};

// Control panel sizing
const openPane = () => {
    if (parseInt(localStorage?.chatControlsSize)) {
        pane.resize(parseInt(localStorage?.chatControlsSize));
    } else {
        pane.resize(minSize);
    }
};
```

### Tools Implementation
```javascript
// Tool integration
<div class="flex items-center space-x-2">
    {#each tools as tool}
        <button
            class="tool-button"
            on:click={() => handleToolClick(tool)}
            disabled={!tool.available}
        >
            <Icon name={tool.icon} />
            <span>{tool.name}</span>
        </button>
    {/each}
</div>

// Tool handling
const handleToolClick = async (tool) => {
    switch (tool.type) {
        case 'file':
            await handleFileUpload();
            break;
        case 'voice':
            startVoiceRecording();
            break;
        case 'search':
            toggleSearch();
            break;
        default:
            console.warn('Unknown tool type:', tool.type);
    }
};
```

## 3. WebSocket Integration

### Socket Setup
```javascript
const setupWebSocket = () => {
    const socket = io(WEBUI_API_BASE_URL, {
        transports: ['websocket'],
        auth: {
            token: localStorage.token
        }
    });

    socket.on('connect', () => {
        console.log('Connected to WebSocket');
    });

    socket.on('disconnect', () => {
        console.log('Disconnected from WebSocket');
    });

    return socket;
};

// Socket event handling
socket.on('chat-events', async (event) => {
    if (event.chat_id === chatId) {
        await handleChatEvent(event);
    }
});

const handleChatEvent = async (event) => {
    const { type, data } = event;
    
    switch (type) {
        case 'message':
            await handleMessageEvent(data);
            break;
        case 'status':
            updateStatus(data);
            break;
        case 'error':
            handleError(data);
            break;
    }
};
```

## 4. Event System

### Custom Events
```javascript
// Event target setup
const eventTarget = new EventTarget();

// Event dispatching
const dispatchMessageEvent = (message) => {
    eventTarget.dispatchEvent(
        new CustomEvent('chat', {
            detail: {
                id: message.id,
                content: message.content
            }
        })
    );
};

// Event handling
eventTarget.addEventListener('chat:start', async (event) => {
    const { id } = event.detail;
    await startMessageProcessing(id);
});

eventTarget.addEventListener('chat:finish', async (event) => {
    const { id, content } = event.detail;
    await finalizeMessage(id, content);
});
```

### Event Handlers
```javascript
const chatEventHandler = async (event, cb) => {
    if (event.chat_id === $chatId) {
        let message = history.messages[event.message_id];
        const type = event?.data?.type ?? null;
        const data = event?.data?.data ?? null;

        switch (type) {
            case 'status':
                if (message?.statusHistory) {
                    message.statusHistory.push(data);
                } else {
                    message.statusHistory = [data];
                }
                break;
                
            case 'citation':
                if (data?.type === 'code_execution') {
                    handleCodeExecution(message, data);
                } else {
                    handleCitation(message, data);
                }
                break;
                
            case 'message':
                message.content += data.content;
                break;
        }

        history.messages[event.message_id] = message;
    }
};
```

## 5. Real-time Updates

### Message Streaming
```javascript
const handleMessageStream = async (res) => {
    const textStream = await createOpenAITextStream(
        res.body, 
        $settings.splitLargeChunks
    );

    for await (const update of textStream) {
        const { value, done, citations, error, usage } = update;
        
        if (error) {
            await handleError(error);
            break;
        }
        
        if (done) {
            finalizeMessage();
            break;
        }

        if (usage) {
            updateUsageStats(usage);
        }

        if (citations) {
            handleCitations(citations);
        }

        await updateMessageContent(value);
    }
};
```

### Status Updates
```javascript
const updateMessageStatus = (message, status) => {
    const statusUpdate = {
        action: status.action,
        description: status.description,
        timestamp: Date.now()
    };

    if (message.statusHistory) {
        message.statusHistory.push(statusUpdate);
    } else {
        message.statusHistory = [statusUpdate];
    }

    history.messages[message.id] = message;
};
```

## 6. Interactive UI Elements

### Voice Recording
```javascript
const VoiceRecording = {
    data() {
        return {
            recording: false,
            audioChunks: [],
            mediaRecorder: null
        };
    },

    methods: {
        async startRecording() {
            try {
                const stream = await navigator.mediaDevices
                    .getUserMedia({ audio: true });
                    
                this.mediaRecorder = new MediaRecorder(stream);
                this.audioChunks = [];

                this.mediaRecorder.addEventListener(
                    'dataavailable', 
                    event => {
                        this.audioChunks.push(event.data);
                    }
                );

                this.mediaRecorder.addEventListener(
                    'stop', 
                    () => {
                        this.processRecording();
                    }
                );

                this.mediaRecorder.start();
                this.recording = true;
            } catch (error) {
                console.error('Recording error:', error);
                toast.error('Failed to start recording');
            }
        },

        async processRecording() {
            const audioBlob = new Blob(
                this.audioChunks, 
                { type: 'audio/wav' }
            );
            const audioUrl = URL.createObjectURL(audioBlob);
            
            // Process audio
            const text = await transcribeAudio(audioBlob);
            this.$emit('recorded', { text, audioUrl });
        }
    }
};
```

### Drag and Drop
```javascript
const handleDragOver = (e) => {
    e.preventDefault();
    if (e.dataTransfer?.types?.includes('Files')) {
        dragged = true;
    } else {
        dragged = false;
    }
};

const handleDrop = async (e) => {
    e.preventDefault();
    if (e.dataTransfer?.files) {
        const inputFiles = Array.from(e.dataTransfer?.files);
        if (inputFiles && inputFiles.length > 0) {
            await processFiles(inputFiles);
        }
    }
    dragged = false;
};
```

## Best Practices and Patterns

1. **Real-time Communication**
   - Efficient WebSocket usage
   - Proper connection management
   - Error handling and recovery

2. **Event Handling**
   - Clear event hierarchy
   - Type-safe event data
   - Proper cleanup

3. **User Interaction**
   - Responsive feedback
   - Progress indication
   - Error recovery

4. **Performance**
   - Efficient updates
   - Resource cleanup
   - Memory management

## Exercises

1. Implement a real-time chat feature:
   - WebSocket connection
   - Message streaming
   - Status updates
   - Error handling

2. Create an interactive tool:
   - User interface
   - Event handling
   - State management
   - Error handling

3. Build a voice recording system:
   - Recording interface
   - Audio processing
   - Transcription
   - Error handling

4. Implement a drag-and-drop system:
   - File handling
   - Progress indication
   - Error handling
   - Success feedback

## Next Steps
The next and final lesson will focus on User Experience and Polish, covering themes, internationalization, keyboard shortcuts, and performance optimizations.

