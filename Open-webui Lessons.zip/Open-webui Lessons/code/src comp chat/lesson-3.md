# Lesson 3: UI Components Deep Dive

## Introduction
This lesson explores the UI component architecture of the chat application, focusing on how different components work together to create a cohesive and responsive interface. We'll examine component relationships, styling patterns, and interaction models.

## Table of Contents
1. Component Hierarchy
2. Core UI Components
3. Modal System
4. Responsive Design
5. Component Interaction Patterns
6. Styling and Theme Management

## 1. Component Hierarchy

### Overall Structure
The application's component hierarchy is organized as follows:

```
Chat.svelte (Root)
├── Navbar
├── Messages
│   ├── Message
│   │   ├── ProfileImageBase
│   │   ├── MessageContent
│   │   └── MessageActions
│   └── MessageInput
│       ├── InputMenu
│       ├── Commands
│       └── FilesOverlay
├── ChatControls
│   ├── Controls
│   ├── CallOverlay
│   └── Overview
└── Modals
    ├── SettingsModal
    ├── ShareChatModal
    └── ShortcutsModal
```

### Component Relationships
From `Chat.svelte`, the main orchestrator:

```javascript
<div class="h-screen max-h-[100dvh] {$showSidebar ? 'md:max-w-[calc(100%-260px)]' : ''} 
    w-full max-w-full flex flex-col" id="chat-container">
    
    <Navbar
        bind:this={navbarElement}
        chat={{
            id: $chatId,
            chat: {
                title: $chatTitle,
                models: selectedModels,
                system: $settings.system ?? undefined,
                params: params,
                history: history,
                timestamp: Date.now()
            }
        }}
        title={$chatTitle}
        bind:selectedModels
        shareEnabled={!!history.currentId}
        {initNewChat}
    />

    <PaneGroup direction="horizontal" class="w-full h-full">
        <Pane defaultSize={50} class="h-full flex w-full relative">
            <Messages />
            <MessageInput />
        </Pane>
        
        <ChatControls />
    </PaneGroup>
</div>
```

## 2. Core UI Components

### Messages Component
The Messages component handles message display and interaction:

```javascript
// Messages.svelte
<div class="h-full flex pt-8">
    {#if Object.keys(history?.messages ?? {}).length == 0}
        <ChatPlaceholder
            modelIds={selectedModels}
            submitPrompt={async (p) => {
                let text = p;
                prompt = text;
                await tick();
            }}
        />
    {:else}
        <div class="w-full pt-2">
            {#each messages as message, messageIdx (message.id)}
                <Message
                    {chatId}
                    bind:history
                    messageId={message.id}
                    idx={messageIdx}
                    {user}
                    {showPreviousMessage}
                    {showNextMessage}
                    {editMessage}
                    {deleteMessage}
                    {rateMessage}
                    {regenerateResponse}
                    {continueResponse}
                    {mergeResponses}
                    {readOnly}
                />
            {/each}
        </div>
    {/if}
</div>
```

### MessageInput Component
Handles user input with rich features:

```javascript
// MessageInput.svelte
<div class="w-full font-primary">
    <div class="flex flex-col px-2.5 max-w-6xl w-full">
        <form class="w-full flex gap-1.5">
            <div class="flex-1 flex flex-col relative w-full rounded-3xl px-1.5 
                bg-gray-50 dark:bg-gray-850 dark:text-gray-100">
                
                {#if files.length > 0}
                    <FilesPreview {files} on:remove={handleFileRemove} />
                {/if}
                
                <div class="flex">
                    <InputMenu {webSearchEnabled} {selectedToolIds} />
                    <RichTextInput
                        bind:value={prompt}
                        on:submit={handleSubmit}
                        on:upload={handleUpload}
                    />
                    <ActionButtons {recording} on:record={handleRecord} />
                </div>
            </div>
        </form>
    </div>
</div>
```

### ChatControls Component
Manages chat control panels and overlays:

```javascript
// ChatControls.svelte
<SvelteFlowProvider>
    {#if !largeScreen}
        <Drawer show={$showControls}>
            <div class="{$showCallOverlay || $showOverview || $showArtifacts 
                ? 'h-screen w-screen' : 'px-6 py-4'} h-full">
                
                {#if $showCallOverlay}
                    <CallOverlay
                        bind:files
                        {submitPrompt}
                        {stopResponse}
                        {modelId}
                        {chatId}
                        {eventTarget}
                    />
                {:else if $showArtifacts}
                    <Artifacts {history} />
                {:else if $showOverview}
                    <Overview
                        {history}
                        on:nodeclick={handleNodeClick}
                    />
                {:else}
                    <Controls
                        {models}
                        bind:chatFiles
                        bind:params
                    />
                {/if}
            </div>
        </Drawer>
    {:else}
        <Pane configuration />
    {/if}
</SvelteFlowProvider>
```

## 3. Modal System

### Modal Implementation
The application uses a flexible modal system:

```javascript
// Modal.svelte base component
<div class="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-0">
    <div class="fixed inset-0 bg-black/30 dark:bg-black/50" 
        on:click={closeModal} />
    
    <div class="relative overflow-hidden rounded-2xl bg-white 
        dark:bg-gray-900 shadow-xl ring-1 ring-black/5 dark:ring-white/5 
        {sizeClass}">
        <slot />
    </div>
</div>
```

### Settings Modal Example
```javascript
// SettingsModal.svelte
<Modal bind:show>
    <div class="text-gray-700 dark:text-gray-100">
        <div class="flex justify-between dark:text-gray-300 px-5 pt-4 pb-1">
            <div class="text-lg font-medium self-center">
                {$i18n.t('Settings')}
            </div>
            <CloseButton on:click={() => show = false} />
        </div>
        
        <div class="flex flex-col md:flex-row w-full px-4 pt-2 pb-4 md:space-x-4">
            <TabsNavigation />
            <TabContent />
        </div>
    </div>
</Modal>
```

## 4. Responsive Design

### Breakpoint System
The application uses Tailwind CSS for responsive design:

```javascript
// Responsive layout classes
<div class="h-screen max-h-[100dvh] 
    md:max-w-[calc(100%-260px)] 
    w-full max-w-full 
    flex flex-col">
```

### Mobile Adaptations
```javascript
// Mobile-specific handling
$: if (!largeScreen) {
    // Mobile layout adjustments
    showControls.set(false);
    await tick();
    showControls.set(true);
} else {
    // Desktop layout
    if ($showCallOverlay) {
        showCallOverlay.set(false);
        await tick();
        showCallOverlay.set(true);
    }
}
```

## 5. Component Interaction Patterns

### Event Dispatching
Components communicate through events:

```javascript
// Event dispatch example
const dispatch = createEventDispatcher();

const handleAction = async () => {
    dispatch('action', {
        type: 'message',
        data: {
            id: messageId,
            content: content
        }
    });
};
```

### Store-based Communication
Components share state through stores:

```javascript
import { chatId, showControls, showCallOverlay, showOverview } from '$lib/stores';

// Store subscriptions
showControls.subscribe(async (value) => {
    if (controlPane && !$mobile) {
        if (value) {
            controlPaneComponent.openPane();
        } else {
            controlPane.collapse();
        }
    }
});
```

## 6. Styling and Theme Management

### Theme System
The application supports light and dark themes:

```javascript
// Theme classes
<div class="bg-white dark:bg-gray-900 
    text-gray-700 dark:text-gray-100
    border-gray-200 dark:border-gray-800">
```

### Component Styling
Components use a combination of Tailwind and custom styles:

```javascript
// Styling patterns
<button class="px-2.5 py-2 min-w-fit rounded-lg 
    flex-1 md:flex-none 
    flex text-left transition 
    {selectedTab === 'general'
        ? 'bg-gray-100 dark:bg-gray-800'
        : 'hover:bg-gray-100 dark:hover:bg-gray-850'}">
```

## Best Practices and Patterns

1. **Component Organization**
   - Single responsibility principle
   - Clear component boundaries
   - Consistent naming conventions

2. **State Management**
   - Local state for UI-specific data
   - Stores for shared state
   - Props for component configuration

3. **Event Handling**
   - Custom event dispatching
   - Event bubbling control
   - Proper cleanup

4. **Performance**
   - Conditional rendering
   - Efficient updates
   - Proper unsubscribing

## Exercises

1. Create a new modal component with:
   - Customizable size
   - Animation
   - Backdrop click handling
   - Accessibility features

2. Implement a responsive component that:
   - Adapts to different screen sizes
   - Handles touch events
   - Maintains proper layout

3. Build a theme-aware component:
   - Support light/dark modes
   - Use CSS variables
   - Implement smooth transitions

4. Create an interactive component with:
   - Event dispatching
   - Store integration
   - State management
   - Proper cleanup

## Next Steps
The next lesson will focus on Advanced Features, including model selection, chat history, and search capabilities.

