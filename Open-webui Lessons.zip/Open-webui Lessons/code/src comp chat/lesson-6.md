# Lesson 6: User Experience and Polish

## Introduction
This final lesson covers the aspects that transform a functional application into a polished, professional product. We'll explore theme management, internationalization, keyboard shortcuts, performance optimizations, and user feedback systems.

## Table of Contents
1. Theme Management
2. Internationalization (i18n)
3. Keyboard Shortcuts
4. Performance Optimizations
5. Error Handling
6. User Feedback Systems

## 1. Theme Management

### Theme System Implementation
From the theme management system:

```javascript
// Theme store and settings
import { writable } from 'svelte/store';
export const theme = writable('system');

// Theme application
const applyTheme = (themeName) => {
    const root = document.documentElement;
    const isDark = themeName === 'dark' || 
        (themeName === 'system' && 
            window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDark) {
        root.classList.add('dark');
    } else {
        root.classList.remove('dark');
    }
};

// Theme reactivity
$: if (browser) {
    applyTheme($theme);
}
```

### Theme Classes Implementation
```javascript
// Base theme classes
const baseThemeClasses = {
    app: `
        bg-white dark:bg-gray-900
        text-gray-900 dark:text-gray-100
    `,
    input: `
        bg-gray-50 dark:bg-gray-850
        text-gray-900 dark:text-gray-100
        border-gray-200 dark:border-gray-800
    `,
    button: `
        bg-gray-100 dark:bg-gray-800
        hover:bg-gray-200 dark:hover:bg-gray-700
        text-gray-900 dark:text-gray-100
    `
};

// Theme application in components
<div class={`
    ${baseThemeClasses.app}
    transition-colors duration-200
`}>
    <input class={`
        ${baseThemeClasses.input}
        rounded-lg px-4 py-2
    `} />
    
    <button class={`
        ${baseThemeClasses.button}
        rounded-lg px-4 py-2
    `}>
        {$i18n.t('Submit')}
    </button>
</div>
```

## 2. Internationalization (i18n)

### I18n Setup and Configuration
```javascript
// i18n initialization
import i18next from 'i18next';
import { createI18nStore } from 'svelte-i18next';

const i18n = createI18nStore(i18next);

i18next.init({
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
        escapeValue: false
    },
    resources: {
        en: {
            translation: require('./locales/en.json')
        },
        es: {
            translation: require('./locales/es.json')
        }
    }
});

// Making i18n available to components
setContext('i18n', i18n);
```

### Translation Implementation
```javascript
// Translation usage in components
<script>
    const i18n = getContext('i18n');
</script>

<div>
    <h1>{$i18n.t('Welcome, {{name}}', { name: user.name })}</h1>
    <p>{$i18n.t('messages.greeting')}</p>
    
    <!-- Pluralization -->
    <p>
        {$i18n.t('messages.items', { 
            count: items.length,
            defaultValue: '{{count}} item',
            defaultValue_plural: '{{count}} items'
        })}
    </p>
    
    <!-- Date formatting -->
    <p>
        {$i18n.t('messages.date', { 
            date: new Date(),
            formatParams: {
                date: {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                }
            }
        })}
    </p>
</div>
```

## 3. Keyboard Shortcuts

### Shortcuts System
From `ShortcutsModal.svelte`:

```javascript
// Keyboard shortcuts registration
const registerShortcuts = () => {
    const shortcuts = {
        'mod+shift+o': initNewChat,
        'shift+escape': focusChatInput,
        'mod+shift+;': copyLastCodeBlock,
        'mod+shift+c': copyLastResponse,
        'mod+.': toggleSettings,
        'mod+shift+s': toggleSidebar,
        'mod+shift+delete': deleteChat,
        'mod+/': showShortcuts
    };

    Object.entries(shortcuts).forEach(([key, handler]) => {
        keyboardjs.bind(key, (e) => {
            e.preventDefault();
            handler();
        });
    });
};

// Shortcut handler implementation
const handleKeyDown = (event: KeyboardEvent) => {
    // Command/Ctrl + Shift + Enter to submit a message pair
    if ((event.ctrlKey || event.metaKey) && 
        event.key === 'Enter' && 
        event.shiftKey) {
        event.preventDefault();
        createMessagePair(prompt);
    }

    // Check for Ctrl + R for regeneration
    if (prompt === '' && 
        (event.ctrlKey || event.metaKey) && 
        event.key.toLowerCase() === 'r') {
        event.preventDefault();
        const regenerateButton = document
            .getElementsByClassName('regenerate-response-button')
            ?.at(-1);
        regenerateButton?.click();
    }
};
```

### Shortcuts Modal
```javascript
<Modal bind:show>
    <div class="text-gray-700 dark:text-gray-100">
        <div class="flex flex-col space-y-3">
            {#each shortcuts as shortcut}
                <div class="flex justify-between items-center">
                    <div class="text-sm">
                        {$i18n.t(shortcut.description)}
                    </div>
                    
                    <div class="flex space-x-1 text-xs">
                        {#each shortcut.keys as key}
                            <div class="px-2 py-1 rounded border">
                                {key}
                            </div>
                        {/each}
                    </div>
                </div>
            {/each}
        </div>
    </div>
</Modal>
```

## 4. Performance Optimizations

### Virtual Scrolling
```javascript
// Virtual scrolling implementation
const VirtualList = {
    data() {
        return {
            visibleItems: [],
            startIndex: 0,
            endIndex: 0,
            itemHeight: 50,
            containerHeight: 0,
            scrollTop: 0
        };
    },

    computed: {
        totalHeight() {
            return this.items.length * this.itemHeight;
        },
        
        visibleCount() {
            return Math.ceil(this.containerHeight / this.itemHeight) + 2;
        }
    },

    methods: {
        updateVisibleItems() {
            this.startIndex = Math.floor(
                this.scrollTop / this.itemHeight
            );
            this.endIndex = Math.min(
                this.startIndex + this.visibleCount,
                this.items.length
            );
            
            this.visibleItems = this.items.slice(
                this.startIndex,
                this.endIndex
            );
        },

        handleScroll(event) {
            this.scrollTop = event.target.scrollTop;
            this.updateVisibleItems();
        }
    }
};
```

### Lazy Loading
```javascript
// Lazy loading implementation
const lazyLoadMessages = async () => {
    const observer = new IntersectionObserver(
        (entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !messagesLoading) {
                    loadMoreMessages();
                }
            });
        },
        { threshold: 0.5 }
    );

    const sentinel = document.querySelector('.load-more-sentinel');
    if (sentinel) {
        observer.observe(sentinel);
    }
};

// Message loading
const loadMoreMessages = async () => {
    messagesLoading = true;
    
    try {
        const newMessages = await fetchMessages(
            currentPage + 1,
            pageSize
        );
        messages = [...messages, ...newMessages];
        currentPage += 1;
    } catch (error) {
        console.error('Failed to load messages:', error);
    } finally {
        messagesLoading = false;
    }
};
```

## 5. Error Handling

### Error Handling System
```javascript
// Global error handler
const handleError = async (error, context = '') => {
    console.error(`Error in ${context}:`, error);
    
    // Determine error type and appropriate response
    let userMessage = '';
    if (error.name === 'NetworkError') {
        userMessage = $i18n.t('errors.network');
    } else if (error.name === 'AuthError') {
        userMessage = $i18n.t('errors.authentication');
        await handleAuthError();
    } else {
        userMessage = $i18n.t('errors.generic');
    }
    
    // Show error to user
    toast.error(userMessage);
    
    // Log error for analysis
    await logError({
        error: error.toString(),
        context,
        timestamp: new Date(),
        user: $user.id
    });
};

// Component-level error handling
const handleComponentError = async (error, component) => {
    // Update component state
    component.error = true;
    component.errorMessage = error.message;
    
    // Show error UI
    if (component.showError) {
        component.showError(error);
    }
    
    // Log error
    await handleError(error, component.name);
};
```

### Error Boundaries
```javascript
// Error boundary component
<script>
    let hasError = false;
    let error = null;

    function handleError(event) {
        hasError = true;
        error = event.error;
    }
</script>

<svelte:window on:error={handleError} />

{#if hasError}
    <div class="error-boundary">
        <h2>{$i18n.t('errors.component_error')}</h2>
        <p>{error.message}</p>
        <button on:click={() => {
            hasError = false;
            error = null;
        }}>
            {$i18n.t('errors.retry')}
        </button>
    </div>
{:else}
    <slot />
{/if}
```

## 6. User Feedback Systems

### Toast Notifications
```javascript
// Toast system implementation
const showToast = (message, type = 'info') => {
    toast[type](message, {
        position: 'bottom-center',
        duration: 3000,
        className: `
            ${type === 'error' ? 'bg-red-500' : 'bg-gray-800'} 
            text-white rounded-lg px-4 py-2
        `
    });
};

// Usage examples
const handleSuccess = () => {
    showToast($i18n.t('messages.success'), 'success');
};

const handleError = (error) => {
    showToast(error.message, 'error');
};
```

### Progress Indicators
```javascript
// Progress handling
const ProgressIndicator = {
    data() {
        return {
            progress: 0,
            status: 'idle',
            message: ''
        };
    },

    methods: {
        startProgress() {
            this.status = 'loading';
            this.progress = 0;
            this.updateProgress();
        },

        updateProgress(increment = 10) {
            if (this.status === 'loading') {
                this.progress = Math.min(
                    this.progress + increment,
                    99
                );
                setTimeout(
                    () => this.updateProgress(increment / 2),
                    100
                );
            }
        },

        complete() {
            this.progress = 100;
            this.status = 'complete';
            setTimeout(() => {
                this.reset();
            }, 1000);
        },

        reset() {
            this.progress = 0;
            this.status = 'idle';
            this.message = '';
        }
    }
};
```

### Loading States
```javascript
// Loading state management
const LoadingState = {
    data() {
        return {
            loading: false,
            loadingMessage: '',
            error: null
        };
    },

    methods: {
        async withLoading(action, message = '') {
            this.loading = true;
            this.loadingMessage = message;
            this.error = null;

            try {
                await action();
            } catch (error) {
                this.error = error;
                handleError(error);
            } finally {
                this.loading = false;
                this.loadingMessage = '';
            }
        }
    }
};
```

## Best Practices and Patterns

1. **Theme Management**
   - Consistent color schemes
   - Smooth transitions
   - System theme support
   - Accessible contrast ratios

2. **Internationalization**
   - String externalization
   - Format handling
   - RTL support
   - Cultural considerations

3. **Performance**
   - Resource optimization
   - Lazy loading
   - Memory management
   - Event delegation

4. **Error Handling**
   - Graceful degradation
   - Clear user feedback
   - Error recovery
   - Logging and monitoring

## Exercises

1. Implement a theme system:
   - Light/dark modes
   - System preference detection
   - Theme switching
   - Persistence

2. Create an i18n implementation:
   - Multiple languages
   - String management
   - Format handling
   - RTL support

3. Build a shortcuts system:
   - Keyboard shortcuts
   - Command palette
   - Custom bindings
   - User preferences

4. Implement performance optimizations:
   - Virtual scrolling
   - Lazy loading
   - Resource management
   - Caching

## Conclusion

This concludes our comprehensive exploration of the chat application. We've covered:
- Foundational architecture
- Core functionality
- UI components
- Advanced features
- Interactive elements
- Polish and optimization

The skills and patterns learned can be applied to build sophisticated, production-ready web applications.

Remember to:
- Follow best practices
- Consider user experience
- Maintain code quality
- Test thoroughly
- Document properly
- Monitor performance

Keep exploring and improving your applications!

