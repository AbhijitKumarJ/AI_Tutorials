# Lesson 4: Advanced Features

## Introduction
This lesson explores the advanced features of the chat application, focusing on model management, history handling, search capabilities, and organizational features that enhance the user experience.

## Table of Contents
1. Model Selection and Management
2. Chat History System
3. Search and Filtering
4. Tags and Organization
5. Settings Management
6. State Persistence

## 1. Model Selection and Management

### ModelSelector Component
From `ModelSelector.svelte`, the model selection system:

```javascript
export let selectedModels = [''];
export let disabled = false;
export let showSetDefault = true;

const saveDefaultModel = async () => {
    // Validate model selection
    const hasEmptyModel = selectedModels.filter((it) => it === '');
    if (hasEmptyModel.length) {
        toast.error($i18n.t('Choose a model before saving...'));
        return;
    }
    
    // Update settings and persist
    settings.set({ ...$settings, models: selectedModels });
    await updateUserSettings(localStorage.token, { ui: $settings });
    toast.success($i18n.t('Default model updated'));
};
```

### Model State Management
```javascript
// Model selection state handling
$: if (selectedModels.length > 0 && $models.length > 0) {
    selectedModels = selectedModels.map((model) =>
        $models.map((m) => m.id).includes(model) ? model : ''
    );
}

// Model selector interface
<div class="flex flex-col w-full items-start">
    {#each selectedModels as selectedModel, selectedModelIdx}
        <div class="flex w-full max-w-fit">
            <Selector
                id={`${selectedModelIdx}`}
                placeholder={$i18n.t('Select a model')}
                items={$models.map((model) => ({
                    value: model.id,
                    label: model.name,
                    model: model
                }))}
                showTemporaryChatControl={$user.role === 'user'
                    ? ($config?.permissions?.chat?.temporary ?? true)
                    : true}
                bind:value={selectedModel}
            />
        </div>
    {/each}
</div>
```

## 2. Chat History System

### History Data Structure
```javascript
interface ChatHistory {
    messages: {
        [key: string]: Message;
    };
    currentId: string | null;
}

interface Message {
    id: string;
    parentId: string | null;
    childrenIds: string[];
    content: string;
    role: 'user' | 'assistant';
    timestamp: number;
    model?: string;
    files?: FileAttachment[];
}
```

### History Management
From `Chat.svelte`, history handling:

```javascript
const loadChat = async () => {
    chatId.set(chatIdProp);
    chat = await getChatById(localStorage.token, $chatId);

    if (chat) {
        const chatContent = chat.chat;
        if (chatContent) {
            // Load models
            selectedModels = (chatContent?.models ?? undefined) !== undefined
                ? chatContent.models
                : [chatContent.models ?? ''];
                
            // Load history
            history = (chatContent?.history ?? undefined) !== undefined
                ? chatContent.history
                : convertMessagesToHistory(chatContent.messages);

            // Set chat title
            chatTitle.set(chatContent.title);
            
            // Load settings
            params = chatContent?.params ?? {};
            chatFiles = chatContent?.files ?? [];
            
            // Update UI state
            autoScroll = true;
            await tick();
            
            if (history.currentId) {
                history.messages[history.currentId].done = true;
            }
            
            return true;
        }
    }
    return false;
};
```

### History Navigation
```javascript
const showPreviousMessage = async (message) => {
    if (message.parentId !== null) {
        let messageId = history.messages[message.parentId]
            .childrenIds[Math.max(
                history.messages[message.parentId]
                .childrenIds.indexOf(message.id) - 1, 
                0
            )];
            
        if (message.id !== messageId) {
            let messageChildrenIds = history.messages[messageId].childrenIds;
            while (messageChildrenIds.length !== 0) {
                messageId = messageChildrenIds.at(-1);
                messageChildrenIds = history.messages[messageId].childrenIds;
            }
            history.currentId = messageId;
        }
    }
};
```

## 3. Search and Filtering

### Search Implementation
From the chat management system:

```javascript
const searchChats = async (query) => {
    const searchParams = new URLSearchParams({
        q: query,
        page: currentPage.toString(),
        limit: pageSize.toString()
    });

    try {
        const response = await fetch(
            `${WEBUI_API_BASE_URL}/chats/search?${searchParams}`,
            {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );
        
        if (!response.ok) {
            throw new Error('Search failed');
        }
        
        const data = await response.json();
        return data.chats;
    } catch (error) {
        console.error('Search error:', error);
        return [];
    }
};
```

### Filtering Capabilities
```javascript
const filterChats = (chats, filters) => {
    return chats.filter(chat => {
        // Apply model filter
        if (filters.model && chat.models.includes(filters.model)) {
            return false;
        }
        
        // Apply date filter
        if (filters.dateRange) {
            const chatDate = new Date(chat.timestamp);
            if (chatDate < filters.dateRange.start || 
                chatDate > filters.dateRange.end) {
                return false;
            }
        }
        
        // Apply tag filter
        if (filters.tags && filters.tags.length > 0) {
            const hasAllTags = filters.tags.every(tag => 
                chat.tags.includes(tag)
            );
            if (!hasAllTags) return false;
        }
        
        return true;
    });
};
```

## 4. Tags and Organization

### Tag Management
From `Tags.svelte`:

```javascript
export let chatId = '';
let tags = [];

const getTags = async () => {
    return await getTagsById(localStorage.token, chatId)
        .catch(async (error) => {
            return [];
        });
};

const addTag = async (tagName) => {
    const res = await addTagById(localStorage.token, chatId, tagName)
        .catch(async (error) => {
            toast.error(error);
            return null;
        });
        
    if (!res) return;
    
    tags = await getTags();
    await updateChatById(localStorage.token, chatId, {
        tags: tags
    });
    
    await _tags.set(await getAllTags(localStorage.token));
};

const deleteTag = async (tagName) => {
    const res = await deleteTagById(localStorage.token, chatId, tagName);
    tags = await getTags();
    await updateChatById(localStorage.token, chatId, {
        tags: tags
    });
    
    await _tags.set(await getAllTags(localStorage.token));
};
```

### Tag Interface
```javascript
<Tags
    {tags}
    on:delete={(e) => {
        deleteTag(e.detail);
    }}
    on:add={(e) => {
        addTag(e.detail);
    }}
/>
```

## 5. Settings Management

### Settings Structure
```javascript
interface Settings {
    system?: string;
    models?: string[];
    params?: {
        temperature?: number;
        top_p?: number;
        frequency_penalty?: number;
        max_tokens?: number;
        stop?: string[];
    };
    ui?: {
        theme?: string;
        fontSize?: string;
        chatDirection?: 'LTR' | 'RTL';
        hapticFeedback?: boolean;
        notificationEnabled?: boolean;
    };
}
```

### Settings Management
From `SettingsModal.svelte`:

```javascript
const saveSettings = async (updated) => {
    await settings.set({ ...$settings, ...updated });
    await models.set(await getModels());
    await updateUserSettings(localStorage.token, { ui: $settings });
};

// Settings modal structure
<Modal bind:show>
    <div class="text-gray-700 dark:text-gray-100">
        <div class="flex flex-col md:flex-row w-full px-4 pt-2 pb-4">
            <div class="tabs flex flex-row overflow-x-auto">
                <button
                    class="px-2.5 py-2 min-w-fit rounded-lg"
                    on:click={() => {
                        selectedTab = 'general';
                    }}
                >
                    {$i18n.t('General')}
                </button>
                <!-- Other tabs -->
            </div>
            
            <div class="flex-1">
                {#if selectedTab === 'general'}
                    <General
                        {getModels}
                        {saveSettings}
                        on:save={() => {
                            toast.success($i18n.t('Settings saved'));
                        }}
                    />
                {/if}
            </div>
        </div>
    </div>
</Modal>
```

## 6. State Persistence

### Local Storage
```javascript
// Persisting state to local storage
const persistState = async () => {
    try {
        localStorage.setItem('settings', 
            JSON.stringify($settings)
        );
        localStorage.setItem('lastChat', 
            JSON.stringify({
                id: $chatId,
                title: $chatTitle,
                timestamp: Date.now()
            })
        );
    } catch (error) {
        console.error('State persistence error:', error);
    }
};

// Loading persisted state
const loadPersistedState = async () => {
    try {
        const settings = JSON.parse(
            localStorage.getItem('settings') ?? '{}'
        );
        const lastChat = JSON.parse(
            localStorage.getItem('lastChat') ?? 'null'
        );
        
        if (settings) {
            await settings.set(settings);
        }
        
        if (lastChat) {
            await chatId.set(lastChat.id);
            await chatTitle.set(lastChat.title);
        }
    } catch (error) {
        console.error('State loading error:', error);
    }
};
```

### Server Synchronization
```javascript
const syncState = async () => {
    try {
        // Sync settings
        const userSettings = await getUserSettings(
            localStorage.token
        );
        
        if (userSettings) {
            settings.set(userSettings.ui);
        }
        
        // Sync chat state
        if (chatId) {
            const chat = await getChatById(
                localStorage.token, 
                chatId
            );
            if (chat) {
                history = chat.history;
                chatTitle.set(chat.title);
            }
        }
    } catch (error) {
        console.error('Sync error:', error);
    }
};
```

## Best Practices and Patterns

1. **State Management**
   - Clear separation of local and remote state
   - Efficient updates
   - Proper error handling

2. **Data Persistence**
   - Regular state saving
   - Error recovery
   - Sync management

3. **User Experience**
   - Responsive feedback
   - Error messages
   - Loading states

4. **Performance**
   - Efficient filtering
   - Pagination
   - Caching

## Exercises

1. Implement a model selection system with:
   - Multiple model support
   - Default model handling
   - Model capabilities checking

2. Create a chat history system:
   - Navigation
   - State management
   - Persistence

3. Build a tag management system:
   - CRUD operations
   - Tag filtering
   - Tag suggestions

4. Implement a settings system:
   - Multiple setting types
   - Validation
   - Persistence

## Next Steps
The next lesson will focus on Interactive Features, including the artifacts system, chat controls, and real-time updates.

