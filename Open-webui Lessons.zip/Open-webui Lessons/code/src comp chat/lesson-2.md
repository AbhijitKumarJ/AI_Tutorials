# Lesson 2: Core Chat Functionality Implementation

## Introduction
This lesson explores the core chat functionality implementation, focusing on how messages are handled, processed, and displayed in the application. We'll examine the message lifecycle from input to display and all the intermediate processing.

## Table of Contents
1. Message Data Structure
2. Message Input Handling
3. Message Processing Pipeline
4. Real-time Communication
5. Message Display and Rendering
6. File and Media Handling

## 1. Message Data Structure

### Message Object Model
The application uses a sophisticated message structure:

```typescript
interface Message {
    id: string;               // Unique message identifier
    parentId: string | null;  // Parent message reference
    childrenIds: string[];    // Child message references
    role: 'user' | 'assistant'; // Message sender role
    content: string;          // Message content
    timestamp: number;        // Unix timestamp
    files?: FileAttachment[]; // Optional file attachments
    model?: string;          // AI model identifier (for assistant messages)
    modelName?: string;      // Human-readable model name
    modelIdx?: number;       // Model index for multiple models
    error?: ErrorInfo;       // Error information if applicable
    statusHistory?: Status[]; // Processing status history
    done?: boolean;          // Message completion status
}
```

### History Management
Messages are organized in a tree structure:

```javascript
let history = {
    messages: {}, // Map of message ID to message object
    currentId: null // Currently active message ID
};
```

## 2. Message Input Handling

### Input Component Structure
From `MessageInput.svelte`, the input handling system manages:
- Text input
- File attachments
- Voice recording
- Command processing

```javascript
// Key input state management
export let prompt = '';
export let files = [];
export let autoScroll = false;
export let webSearchEnabled = false;

// Input handling
const submitPrompt = async (userPrompt, { _raw = false } = {}) => {
    if (userPrompt === '') {
        toast.error($i18n.t('Please enter a prompt'));
        return;
    }
    
    // File upload validation
    if (files.length > 0 && 
        files.filter(file => file.type !== 'image' && 
        file.status === 'uploading').length > 0) {
        toast.error($i18n.t('Files still uploading...'));
        return;
    }
    
    // Process and send message
    let _responses = [];
    prompt = '';
    await tick();
    
    // Create message structure
    const userMessageId = uuidv4();
    const userMessage = {
        id: userMessageId,
        parentId: messages.length !== 0 ? messages.at(-1).id : null,
        childrenIds: [],
        role: 'user',
        content: userPrompt,
        files: _files.length > 0 ? _files : undefined,
        timestamp: Math.floor(Date.now() / 1000),
        models: selectedModels
    };
    
    // Update history
    history.messages[userMessageId] = userMessage;
    history.currentId = userMessageId;
};
```

## 3. Message Processing Pipeline

### Message Creation
Messages go through several stages of processing:

1. **Initial Creation**
```javascript
const createMessagePair = async (userPrompt) => {
    const userMessageId = uuidv4();
    const responseMessageId = uuidv4();
    
    // Create user message
    const userMessage = {
        id: userMessageId,
        parentId: parentMessage ? parentMessage.id : null,
        childrenIds: [responseMessageId],
        role: 'user',
        content: userPrompt,
        timestamp: Math.floor(Date.now() / 1000)
    };
    
    // Create response message
    const responseMessage = {
        id: responseMessageId,
        parentId: userMessageId,
        childrenIds: [],
        role: 'assistant',
        content: '',
        model: modelId,
        modelName: model.name ?? model.id,
        timestamp: Math.floor(Date.now() / 1000)
    };
};
```

2. **Message Processing**
```javascript
const processMessage = async (message) => {
    // Handle different message types
    if (message?.role !== 'user' && message?.content) {
        const codeBlockContents = message.content.match(/```[\s\S]*?```/g);
        let codeBlocks = [];
        
        if (codeBlockContents) {
            codeBlockContents.forEach((block) => {
                const lang = block.split('\n')[0].replace('```', '').trim();
                const code = block.replace(/```[\s\S]*?\n/, '').replace(/```$/, '');
                codeBlocks.push({ lang, code });
            });
        }
    }
};
```

## 4. Real-time Communication

### WebSocket Integration
The application uses WebSocket for real-time updates:

```javascript
const chatEventHandler = async (event, cb) => {
    if (event.chat_id === $chatId) {
        let message = history.messages[event.message_id];
        const type = event?.data?.type ?? null;
        const data = event?.data?.data ?? null;
        
        switch(type) {
            case 'status':
                updateMessageStatus(message, data);
                break;
            case 'citation':
                handleCitation(message, data);
                break;
            case 'message':
                appendMessageContent(message, data);
                break;
            case 'replace':
                replaceMessageContent(message, data);
                break;
        }
    }
};
```

### Event Handling System
```javascript
const getChatEventEmitter = async (modelId: string, chatId: string = '') => {
    return setInterval(() => {
        $socket?.emit('usage', {
            action: 'chat',
            model: modelId,
            chat_id: chatId
        });
    }, 1000);
};
```

## 5. Message Display and Rendering

### Message Component
From `Messages.svelte`, messages are rendered with various features:

```javascript
const renderMessage = async (message) => {
    // Handle message content types
    if (message.role === 'assistant') {
        // Process markdown, code blocks, etc.
        const codeBlocks = processCodeBlocks(message.content);
        const markdown = processMarkdown(message.content);
        
        // Handle special content
        if (message.files) {
            processAttachments(message.files);
        }
    }
};
```

### History Navigation
```javascript
const showPreviousMessage = async (message) => {
    if (message.parentId !== null) {
        let messageId = history.messages[message.parentId]
            .childrenIds[Math.max(
                history.messages[message.parentId]
                .childrenIds.indexOf(message.id) - 1, 
                0
            )];
        
        history.currentId = messageId;
    }
};
```

## 6. File and Media Handling

### File Upload System
```javascript
const uploadFileHandler = async (file) => {
    const fileItem = {
        type: 'file',
        file: '',
        id: null,
        url: '',
        name: file.name,
        collection_name: '',
        status: 'uploading',
        size: file.size,
        error: '',
        itemId: uuidv4()
    };
    
    try {
        const uploadedFile = await uploadFile(
            localStorage.token, 
            file
        );
        
        if (uploadedFile) {
            fileItem.status = 'uploaded';
            fileItem.file = uploadedFile;
            fileItem.id = uploadedFile.id;
            fileItem.collection_name = uploadedFile?.meta?.collection_name;
            fileItem.url = `${WEBUI_API_BASE_URL}/files/${uploadedFile.id}`;
        }
    } catch (e) {
        toast.error(e);
        files = files.filter(item => item?.itemId !== fileItem.itemId);
    }
};
```

### Media Processing
```javascript
const processMedia = async (file) => {
    if (['image/gif', 'image/webp', 'image/jpeg', 'image/png']
        .includes(file['type'])) {
        let reader = new FileReader();
        reader.onload = (event) => {
            files = [
                ...files,
                {
                    type: 'image',
                    url: `${event.target.result}`
                }
            ];
        };
        reader.readAsDataURL(file);
    }
};
```

## Best Practices and Patterns

1. **Message Handling**
   - Unique IDs for all messages
   - Parent-child relationships
   - Status tracking
   - Error handling

2. **Real-time Updates**
   - WebSocket for instant updates
   - Event-based communication
   - Status synchronization

3. **File Management**
   - Progressive upload
   - Type validation
   - Error handling
   - Status tracking

4. **Performance**
   - Efficient message rendering
   - Lazy loading
   - Proper cleanup

## Exercise
1. Implement a basic message creation and display system
2. Add file upload functionality
3. Implement message history navigation
4. Add real-time update handling
5. Implement message processing for different content types

## Next Steps
The next lesson will focus on UI Components Deep Dive, exploring how the interface is built and how different components interact with each other.

