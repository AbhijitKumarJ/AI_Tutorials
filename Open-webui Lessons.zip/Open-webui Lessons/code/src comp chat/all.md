File: lesson-1.md


# Lesson 1: Foundations and Architecture of Modern Chat Interface

## Introduction
This lesson covers the foundational architecture of a modern chat interface built using Svelte. We'll explore the application's structure, key technologies, and core architectural patterns that make it scalable and maintainable.

## Table of Contents
1. Project Structure
2. Core Technologies
3. Component Architecture
4. State Management
5. Communication Patterns
6. Best Practices

## 1. Project Structure

### File Layout
The application follows a well-organized structure:
```
/
├── Artifacts.svelte          # Handles artifact rendering and management
├── Chat.svelte              # Main chat component orchestrator
├── ChatControls.svelte      # Chat control panel functionality
├── ChatPlaceholder.svelte   # Placeholder states for chat
├── MessageInput.svelte      # Message input handling
├── Messages.svelte          # Message display and management
├── ModelSelector.svelte     # Model selection interface
├── Overview.svelte          # Chat overview visualization
├── Placeholder.svelte       # Generic placeholder component
├── SettingsModal.svelte     # Settings management
├── ShareChatModal.svelte    # Chat sharing functionality
├── ShortcutsModal.svelte    # Keyboard shortcuts interface
├── Suggestions.svelte       # Chat suggestions component
├── TagChatModal.svelte      # Tag management modal
└── Tags.svelte             # Tag display and handling
```

### Key Directories
The application is organized into logical components, each serving a specific purpose:

1. **Root Components**: Primary chat interface components
2. **Modal Components**: Handling various modal dialogs
3. **Utility Components**: Reusable components like placeholders and tags
4. **Overview Components**: Visualization and chat overview features

## 2. Core Technologies

### Primary Framework: Svelte
The application is built using Svelte, a modern JavaScript framework that compiles components at build time. Key Svelte features used include:

1. **Reactive Declarations**
```javascript
$: if (history.currentId) {
    let _messages = [];
    let message = history.messages[history.currentId];
    while (message && _messages.length <= messagesCount) {
        _messages.unshift({ ...message });
        message = message.parentId !== null ? history.messages[message.parentId] : null;
    }
    messages = _messages;
}
```

2. **Stores and State Management**
```javascript
import { chatId, chats, config, models, settings } from '$lib/stores';
```

### Additional Technologies
1. **WebSocket Integration** for real-time communication
2. **Mermaid** for diagram generation
3. **UUID** for unique identifier generation
4. **i18n** for internationalization support

## 3. Component Architecture

### Core Components

#### Chat.svelte
The main orchestrator component that manages:
- Chat state and history
- Message handling
- Real-time communication
- Model selection
- File handling

Key features:
```javascript
export let chatIdProp = '';
let loaded = false;
const eventTarget = new EventTarget();
let controlPane;
let controlPaneComponent;
let stopResponseFlag = false;
let autoScroll = true;
```

#### MessageInput.svelte
Handles user input with features:
- Text input management
- File uploads
- Voice recording
- Command handling
- Autocomplete

#### Messages.svelte
Manages message display with:
- Message rendering
- History navigation
- Message actions (edit, delete, etc.)
- Scroll management

## 4. State Management

### Store Structure
The application uses Svelte stores for global state management:

```javascript
import {
    chatId,        // Current chat ID
    chats,         // All chats
    config,        // Application configuration
    models,        // Available models
    settings,      // User settings
    showSidebar,   // UI state
    user,          // User information
    socket         // WebSocket connection
} from '$lib/stores';
```

### Local State Management
Components maintain local state for specific functionalities:
```javascript
let history = {
    messages: {},
    currentId: null
};
let prompt = '';
let chatFiles = [];
let files = [];
let params = {};
```

## 5. Communication Patterns

### Event Handling
The application uses a sophisticated event system:

1. **WebSocket Events**
```javascript
const chatEventHandler = async (event, cb) => {
    if (event.chat_id === $chatId) {
        await tick();
        let message = history.messages[event.message_id];
        const type = event?.data?.type ?? null;
        const data = event?.data?.data ?? null;
        // Event handling logic
    }
};
```

2. **Custom Events**
```javascript
eventTarget.dispatchEvent(
    new CustomEvent('chat:start', {
        detail: {
            id: responseMessageId
        }
    })
);
```

### Component Communication
Components communicate through:
1. Props and bindings
2. Event dispatching
3. Shared stores
4. Custom events

## 6. Best Practices

### Code Organization
1. **Component Modularity**
   - Each component has a single responsibility
   - Clear separation of concerns
   - Reusable components for common patterns

2. **State Management**
   - Centralized stores for global state
   - Local state for component-specific data
   - Clear update patterns

3. **Error Handling**
```javascript
try {
    const res = await processWeb(localStorage.token, '', url);
    if (res) {
        fileItem.status = 'uploaded';
        fileItem.collection_name = res.collection_name;
    }
} catch (e) {
    files = files.filter((f) => f.name !== url);
    toast.error(JSON.stringify(e));
}
```

### Performance Considerations
1. **Reactive Updates**
   - Efficient state updates
   - Minimal re-renders
   - Proper use of Svelte reactivity

2. **Resource Management**
   - Proper cleanup in onDestroy
   - Efficient event listener management
   - Memory leak prevention

```javascript
onDestroy(() => {
    chatIdUnsubscriber?.();
    window.removeEventListener('message', onMessageHandler);
    $socket?.off('chat-events');
});
```

## Conclusion

The chat interface demonstrates a well-structured, modern web application architecture with:
- Clear component hierarchy
- Efficient state management
- Robust communication patterns
- Scalable structure
- Maintainable codebase

Understanding these foundations is crucial for:
- Adding new features
- Debugging issues
- Maintaining code quality
- Scaling the application

## Exercise
1. Map out the component hierarchy in a diagram
2. Identify all the stores and their purposes
3. Trace the message flow from input to display
4. List all the events and their handlers

Next lesson will dive deeper into the chat functionality implementation and message handling patterns.
















File: lesson-2.md


# Lesson 2: Core Chat Functionality Implementation

## Introduction
This lesson explores the core chat functionality implementation, focusing on how messages are handled, processed, and displayed in the application. We'll examine the message lifecycle from input to display and all the intermediate processing.

## Table of Contents
1. Message Data Structure
2. Message Input Handling
3. Message Processing Pipeline
4. Real-time Communication
5. Message Display and Rendering
6. File and Media Handling

## 1. Message Data Structure

### Message Object Model
The application uses a sophisticated message structure:

```typescript
interface Message {
    id: string;               // Unique message identifier
    parentId: string | null;  // Parent message reference
    childrenIds: string[];    // Child message references
    role: 'user' | 'assistant'; // Message sender role
    content: string;          // Message content
    timestamp: number;        // Unix timestamp
    files?: FileAttachment[]; // Optional file attachments
    model?: string;          // AI model identifier (for assistant messages)
    modelName?: string;      // Human-readable model name
    modelIdx?: number;       // Model index for multiple models
    error?: ErrorInfo;       // Error information if applicable
    statusHistory?: Status[]; // Processing status history
    done?: boolean;          // Message completion status
}
```

### History Management
Messages are organized in a tree structure:

```javascript
let history = {
    messages: {}, // Map of message ID to message object
    currentId: null // Currently active message ID
};
```

## 2. Message Input Handling

### Input Component Structure
From `MessageInput.svelte`, the input handling system manages:
- Text input
- File attachments
- Voice recording
- Command processing

```javascript
// Key input state management
export let prompt = '';
export let files = [];
export let autoScroll = false;
export let webSearchEnabled = false;

// Input handling
const submitPrompt = async (userPrompt, { _raw = false } = {}) => {
    if (userPrompt === '') {
        toast.error($i18n.t('Please enter a prompt'));
        return;
    }
    
    // File upload validation
    if (files.length > 0 && 
        files.filter(file => file.type !== 'image' && 
        file.status === 'uploading').length > 0) {
        toast.error($i18n.t('Files still uploading...'));
        return;
    }
    
    // Process and send message
    let _responses = [];
    prompt = '';
    await tick();
    
    // Create message structure
    const userMessageId = uuidv4();
    const userMessage = {
        id: userMessageId,
        parentId: messages.length !== 0 ? messages.at(-1).id : null,
        childrenIds: [],
        role: 'user',
        content: userPrompt,
        files: _files.length > 0 ? _files : undefined,
        timestamp: Math.floor(Date.now() / 1000),
        models: selectedModels
    };
    
    // Update history
    history.messages[userMessageId] = userMessage;
    history.currentId = userMessageId;
};
```

## 3. Message Processing Pipeline

### Message Creation
Messages go through several stages of processing:

1. **Initial Creation**
```javascript
const createMessagePair = async (userPrompt) => {
    const userMessageId = uuidv4();
    const responseMessageId = uuidv4();
    
    // Create user message
    const userMessage = {
        id: userMessageId,
        parentId: parentMessage ? parentMessage.id : null,
        childrenIds: [responseMessageId],
        role: 'user',
        content: userPrompt,
        timestamp: Math.floor(Date.now() / 1000)
    };
    
    // Create response message
    const responseMessage = {
        id: responseMessageId,
        parentId: userMessageId,
        childrenIds: [],
        role: 'assistant',
        content: '',
        model: modelId,
        modelName: model.name ?? model.id,
        timestamp: Math.floor(Date.now() / 1000)
    };
};
```

2. **Message Processing**
```javascript
const processMessage = async (message) => {
    // Handle different message types
    if (message?.role !== 'user' && message?.content) {
        const codeBlockContents = message.content.match(/```[\s\S]*?```/g);
        let codeBlocks = [];
        
        if (codeBlockContents) {
            codeBlockContents.forEach((block) => {
                const lang = block.split('\n')[0].replace('```', '').trim();
                const code = block.replace(/```[\s\S]*?\n/, '').replace(/```$/, '');
                codeBlocks.push({ lang, code });
            });
        }
    }
};
```

## 4. Real-time Communication

### WebSocket Integration
The application uses WebSocket for real-time updates:

```javascript
const chatEventHandler = async (event, cb) => {
    if (event.chat_id === $chatId) {
        let message = history.messages[event.message_id];
        const type = event?.data?.type ?? null;
        const data = event?.data?.data ?? null;
        
        switch(type) {
            case 'status':
                updateMessageStatus(message, data);
                break;
            case 'citation':
                handleCitation(message, data);
                break;
            case 'message':
                appendMessageContent(message, data);
                break;
            case 'replace':
                replaceMessageContent(message, data);
                break;
        }
    }
};
```

### Event Handling System
```javascript
const getChatEventEmitter = async (modelId: string, chatId: string = '') => {
    return setInterval(() => {
        $socket?.emit('usage', {
            action: 'chat',
            model: modelId,
            chat_id: chatId
        });
    }, 1000);
};
```

## 5. Message Display and Rendering

### Message Component
From `Messages.svelte`, messages are rendered with various features:

```javascript
const renderMessage = async (message) => {
    // Handle message content types
    if (message.role === 'assistant') {
        // Process markdown, code blocks, etc.
        const codeBlocks = processCodeBlocks(message.content);
        const markdown = processMarkdown(message.content);
        
        // Handle special content
        if (message.files) {
            processAttachments(message.files);
        }
    }
};
```

### History Navigation
```javascript
const showPreviousMessage = async (message) => {
    if (message.parentId !== null) {
        let messageId = history.messages[message.parentId]
            .childrenIds[Math.max(
                history.messages[message.parentId]
                .childrenIds.indexOf(message.id) - 1, 
                0
            )];
        
        history.currentId = messageId;
    }
};
```

## 6. File and Media Handling

### File Upload System
```javascript
const uploadFileHandler = async (file) => {
    const fileItem = {
        type: 'file',
        file: '',
        id: null,
        url: '',
        name: file.name,
        collection_name: '',
        status: 'uploading',
        size: file.size,
        error: '',
        itemId: uuidv4()
    };
    
    try {
        const uploadedFile = await uploadFile(
            localStorage.token, 
            file
        );
        
        if (uploadedFile) {
            fileItem.status = 'uploaded';
            fileItem.file = uploadedFile;
            fileItem.id = uploadedFile.id;
            fileItem.collection_name = uploadedFile?.meta?.collection_name;
            fileItem.url = `${WEBUI_API_BASE_URL}/files/${uploadedFile.id}`;
        }
    } catch (e) {
        toast.error(e);
        files = files.filter(item => item?.itemId !== fileItem.itemId);
    }
};
```

### Media Processing
```javascript
const processMedia = async (file) => {
    if (['image/gif', 'image/webp', 'image/jpeg', 'image/png']
        .includes(file['type'])) {
        let reader = new FileReader();
        reader.onload = (event) => {
            files = [
                ...files,
                {
                    type: 'image',
                    url: `${event.target.result}`
                }
            ];
        };
        reader.readAsDataURL(file);
    }
};
```

## Best Practices and Patterns

1. **Message Handling**
   - Unique IDs for all messages
   - Parent-child relationships
   - Status tracking
   - Error handling

2. **Real-time Updates**
   - WebSocket for instant updates
   - Event-based communication
   - Status synchronization

3. **File Management**
   - Progressive upload
   - Type validation
   - Error handling
   - Status tracking

4. **Performance**
   - Efficient message rendering
   - Lazy loading
   - Proper cleanup

## Exercise
1. Implement a basic message creation and display system
2. Add file upload functionality
3. Implement message history navigation
4. Add real-time update handling
5. Implement message processing for different content types

## Next Steps
The next lesson will focus on UI Components Deep Dive, exploring how the interface is built and how different components interact with each other.

















File: lesson-3.md


# Lesson 3: UI Components Deep Dive

## Introduction
This lesson explores the UI component architecture of the chat application, focusing on how different components work together to create a cohesive and responsive interface. We'll examine component relationships, styling patterns, and interaction models.

## Table of Contents
1. Component Hierarchy
2. Core UI Components
3. Modal System
4. Responsive Design
5. Component Interaction Patterns
6. Styling and Theme Management

## 1. Component Hierarchy

### Overall Structure
The application's component hierarchy is organized as follows:

```
Chat.svelte (Root)
├── Navbar
├── Messages
│   ├── Message
│   │   ├── ProfileImageBase
│   │   ├── MessageContent
│   │   └── MessageActions
│   └── MessageInput
│       ├── InputMenu
│       ├── Commands
│       └── FilesOverlay
├── ChatControls
│   ├── Controls
│   ├── CallOverlay
│   └── Overview
└── Modals
    ├── SettingsModal
    ├── ShareChatModal
    └── ShortcutsModal
```

### Component Relationships
From `Chat.svelte`, the main orchestrator:

```javascript
<div class="h-screen max-h-[100dvh] {$showSidebar ? 'md:max-w-[calc(100%-260px)]' : ''} 
    w-full max-w-full flex flex-col" id="chat-container">
    
    <Navbar
        bind:this={navbarElement}
        chat={{
            id: $chatId,
            chat: {
                title: $chatTitle,
                models: selectedModels,
                system: $settings.system ?? undefined,
                params: params,
                history: history,
                timestamp: Date.now()
            }
        }}
        title={$chatTitle}
        bind:selectedModels
        shareEnabled={!!history.currentId}
        {initNewChat}
    />

    <PaneGroup direction="horizontal" class="w-full h-full">
        <Pane defaultSize={50} class="h-full flex w-full relative">
            <Messages />
            <MessageInput />
        </Pane>
        
        <ChatControls />
    </PaneGroup>
</div>
```

## 2. Core UI Components

### Messages Component
The Messages component handles message display and interaction:

```javascript
// Messages.svelte
<div class="h-full flex pt-8">
    {#if Object.keys(history?.messages ?? {}).length == 0}
        <ChatPlaceholder
            modelIds={selectedModels}
            submitPrompt={async (p) => {
                let text = p;
                prompt = text;
                await tick();
            }}
        />
    {:else}
        <div class="w-full pt-2">
            {#each messages as message, messageIdx (message.id)}
                <Message
                    {chatId}
                    bind:history
                    messageId={message.id}
                    idx={messageIdx}
                    {user}
                    {showPreviousMessage}
                    {showNextMessage}
                    {editMessage}
                    {deleteMessage}
                    {rateMessage}
                    {regenerateResponse}
                    {continueResponse}
                    {mergeResponses}
                    {readOnly}
                />
            {/each}
        </div>
    {/if}
</div>
```

### MessageInput Component
Handles user input with rich features:

```javascript
// MessageInput.svelte
<div class="w-full font-primary">
    <div class="flex flex-col px-2.5 max-w-6xl w-full">
        <form class="w-full flex gap-1.5">
            <div class="flex-1 flex flex-col relative w-full rounded-3xl px-1.5 
                bg-gray-50 dark:bg-gray-850 dark:text-gray-100">
                
                {#if files.length > 0}
                    <FilesPreview {files} on:remove={handleFileRemove} />
                {/if}
                
                <div class="flex">
                    <InputMenu {webSearchEnabled} {selectedToolIds} />
                    <RichTextInput
                        bind:value={prompt}
                        on:submit={handleSubmit}
                        on:upload={handleUpload}
                    />
                    <ActionButtons {recording} on:record={handleRecord} />
                </div>
            </div>
        </form>
    </div>
</div>
```

### ChatControls Component
Manages chat control panels and overlays:

```javascript
// ChatControls.svelte
<SvelteFlowProvider>
    {#if !largeScreen}
        <Drawer show={$showControls}>
            <div class="{$showCallOverlay || $showOverview || $showArtifacts 
                ? 'h-screen w-screen' : 'px-6 py-4'} h-full">
                
                {#if $showCallOverlay}
                    <CallOverlay
                        bind:files
                        {submitPrompt}
                        {stopResponse}
                        {modelId}
                        {chatId}
                        {eventTarget}
                    />
                {:else if $showArtifacts}
                    <Artifacts {history} />
                {:else if $showOverview}
                    <Overview
                        {history}
                        on:nodeclick={handleNodeClick}
                    />
                {:else}
                    <Controls
                        {models}
                        bind:chatFiles
                        bind:params
                    />
                {/if}
            </div>
        </Drawer>
    {:else}
        <Pane configuration />
    {/if}
</SvelteFlowProvider>
```

## 3. Modal System

### Modal Implementation
The application uses a flexible modal system:

```javascript
// Modal.svelte base component
<div class="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-0">
    <div class="fixed inset-0 bg-black/30 dark:bg-black/50" 
        on:click={closeModal} />
    
    <div class="relative overflow-hidden rounded-2xl bg-white 
        dark:bg-gray-900 shadow-xl ring-1 ring-black/5 dark:ring-white/5 
        {sizeClass}">
        <slot />
    </div>
</div>
```

### Settings Modal Example
```javascript
// SettingsModal.svelte
<Modal bind:show>
    <div class="text-gray-700 dark:text-gray-100">
        <div class="flex justify-between dark:text-gray-300 px-5 pt-4 pb-1">
            <div class="text-lg font-medium self-center">
                {$i18n.t('Settings')}
            </div>
            <CloseButton on:click={() => show = false} />
        </div>
        
        <div class="flex flex-col md:flex-row w-full px-4 pt-2 pb-4 md:space-x-4">
            <TabsNavigation />
            <TabContent />
        </div>
    </div>
</Modal>
```

## 4. Responsive Design

### Breakpoint System
The application uses Tailwind CSS for responsive design:

```javascript
// Responsive layout classes
<div class="h-screen max-h-[100dvh] 
    md:max-w-[calc(100%-260px)] 
    w-full max-w-full 
    flex flex-col">
```

### Mobile Adaptations
```javascript
// Mobile-specific handling
$: if (!largeScreen) {
    // Mobile layout adjustments
    showControls.set(false);
    await tick();
    showControls.set(true);
} else {
    // Desktop layout
    if ($showCallOverlay) {
        showCallOverlay.set(false);
        await tick();
        showCallOverlay.set(true);
    }
}
```

## 5. Component Interaction Patterns

### Event Dispatching
Components communicate through events:

```javascript
// Event dispatch example
const dispatch = createEventDispatcher();

const handleAction = async () => {
    dispatch('action', {
        type: 'message',
        data: {
            id: messageId,
            content: content
        }
    });
};
```

### Store-based Communication
Components share state through stores:

```javascript
import { chatId, showControls, showCallOverlay, showOverview } from '$lib/stores';

// Store subscriptions
showControls.subscribe(async (value) => {
    if (controlPane && !$mobile) {
        if (value) {
            controlPaneComponent.openPane();
        } else {
            controlPane.collapse();
        }
    }
});
```

## 6. Styling and Theme Management

### Theme System
The application supports light and dark themes:

```javascript
// Theme classes
<div class="bg-white dark:bg-gray-900 
    text-gray-700 dark:text-gray-100
    border-gray-200 dark:border-gray-800">
```

### Component Styling
Components use a combination of Tailwind and custom styles:

```javascript
// Styling patterns
<button class="px-2.5 py-2 min-w-fit rounded-lg 
    flex-1 md:flex-none 
    flex text-left transition 
    {selectedTab === 'general'
        ? 'bg-gray-100 dark:bg-gray-800'
        : 'hover:bg-gray-100 dark:hover:bg-gray-850'}">
```

## Best Practices and Patterns

1. **Component Organization**
   - Single responsibility principle
   - Clear component boundaries
   - Consistent naming conventions

2. **State Management**
   - Local state for UI-specific data
   - Stores for shared state
   - Props for component configuration

3. **Event Handling**
   - Custom event dispatching
   - Event bubbling control
   - Proper cleanup

4. **Performance**
   - Conditional rendering
   - Efficient updates
   - Proper unsubscribing

## Exercises

1. Create a new modal component with:
   - Customizable size
   - Animation
   - Backdrop click handling
   - Accessibility features

2. Implement a responsive component that:
   - Adapts to different screen sizes
   - Handles touch events
   - Maintains proper layout

3. Build a theme-aware component:
   - Support light/dark modes
   - Use CSS variables
   - Implement smooth transitions

4. Create an interactive component with:
   - Event dispatching
   - Store integration
   - State management
   - Proper cleanup

## Next Steps
The next lesson will focus on Advanced Features, including model selection, chat history, and search capabilities.

















File: lesson-4.md


# Lesson 4: Advanced Features

## Introduction
This lesson explores the advanced features of the chat application, focusing on model management, history handling, search capabilities, and organizational features that enhance the user experience.

## Table of Contents
1. Model Selection and Management
2. Chat History System
3. Search and Filtering
4. Tags and Organization
5. Settings Management
6. State Persistence

## 1. Model Selection and Management

### ModelSelector Component
From `ModelSelector.svelte`, the model selection system:

```javascript
export let selectedModels = [''];
export let disabled = false;
export let showSetDefault = true;

const saveDefaultModel = async () => {
    // Validate model selection
    const hasEmptyModel = selectedModels.filter((it) => it === '');
    if (hasEmptyModel.length) {
        toast.error($i18n.t('Choose a model before saving...'));
        return;
    }
    
    // Update settings and persist
    settings.set({ ...$settings, models: selectedModels });
    await updateUserSettings(localStorage.token, { ui: $settings });
    toast.success($i18n.t('Default model updated'));
};
```

### Model State Management
```javascript
// Model selection state handling
$: if (selectedModels.length > 0 && $models.length > 0) {
    selectedModels = selectedModels.map((model) =>
        $models.map((m) => m.id).includes(model) ? model : ''
    );
}

// Model selector interface
<div class="flex flex-col w-full items-start">
    {#each selectedModels as selectedModel, selectedModelIdx}
        <div class="flex w-full max-w-fit">
            <Selector
                id={`${selectedModelIdx}`}
                placeholder={$i18n.t('Select a model')}
                items={$models.map((model) => ({
                    value: model.id,
                    label: model.name,
                    model: model
                }))}
                showTemporaryChatControl={$user.role === 'user'
                    ? ($config?.permissions?.chat?.temporary ?? true)
                    : true}
                bind:value={selectedModel}
            />
        </div>
    {/each}
</div>
```

## 2. Chat History System

### History Data Structure
```javascript
interface ChatHistory {
    messages: {
        [key: string]: Message;
    };
    currentId: string | null;
}

interface Message {
    id: string;
    parentId: string | null;
    childrenIds: string[];
    content: string;
    role: 'user' | 'assistant';
    timestamp: number;
    model?: string;
    files?: FileAttachment[];
}
```

### History Management
From `Chat.svelte`, history handling:

```javascript
const loadChat = async () => {
    chatId.set(chatIdProp);
    chat = await getChatById(localStorage.token, $chatId);

    if (chat) {
        const chatContent = chat.chat;
        if (chatContent) {
            // Load models
            selectedModels = (chatContent?.models ?? undefined) !== undefined
                ? chatContent.models
                : [chatContent.models ?? ''];
                
            // Load history
            history = (chatContent?.history ?? undefined) !== undefined
                ? chatContent.history
                : convertMessagesToHistory(chatContent.messages);

            // Set chat title
            chatTitle.set(chatContent.title);
            
            // Load settings
            params = chatContent?.params ?? {};
            chatFiles = chatContent?.files ?? [];
            
            // Update UI state
            autoScroll = true;
            await tick();
            
            if (history.currentId) {
                history.messages[history.currentId].done = true;
            }
            
            return true;
        }
    }
    return false;
};
```

### History Navigation
```javascript
const showPreviousMessage = async (message) => {
    if (message.parentId !== null) {
        let messageId = history.messages[message.parentId]
            .childrenIds[Math.max(
                history.messages[message.parentId]
                .childrenIds.indexOf(message.id) - 1, 
                0
            )];
            
        if (message.id !== messageId) {
            let messageChildrenIds = history.messages[messageId].childrenIds;
            while (messageChildrenIds.length !== 0) {
                messageId = messageChildrenIds.at(-1);
                messageChildrenIds = history.messages[messageId].childrenIds;
            }
            history.currentId = messageId;
        }
    }
};
```

## 3. Search and Filtering

### Search Implementation
From the chat management system:

```javascript
const searchChats = async (query) => {
    const searchParams = new URLSearchParams({
        q: query,
        page: currentPage.toString(),
        limit: pageSize.toString()
    });

    try {
        const response = await fetch(
            `${WEBUI_API_BASE_URL}/chats/search?${searchParams}`,
            {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );
        
        if (!response.ok) {
            throw new Error('Search failed');
        }
        
        const data = await response.json();
        return data.chats;
    } catch (error) {
        console.error('Search error:', error);
        return [];
    }
};
```

### Filtering Capabilities
```javascript
const filterChats = (chats, filters) => {
    return chats.filter(chat => {
        // Apply model filter
        if (filters.model && chat.models.includes(filters.model)) {
            return false;
        }
        
        // Apply date filter
        if (filters.dateRange) {
            const chatDate = new Date(chat.timestamp);
            if (chatDate < filters.dateRange.start || 
                chatDate > filters.dateRange.end) {
                return false;
            }
        }
        
        // Apply tag filter
        if (filters.tags && filters.tags.length > 0) {
            const hasAllTags = filters.tags.every(tag => 
                chat.tags.includes(tag)
            );
            if (!hasAllTags) return false;
        }
        
        return true;
    });
};
```

## 4. Tags and Organization

### Tag Management
From `Tags.svelte`:

```javascript
export let chatId = '';
let tags = [];

const getTags = async () => {
    return await getTagsById(localStorage.token, chatId)
        .catch(async (error) => {
            return [];
        });
};

const addTag = async (tagName) => {
    const res = await addTagById(localStorage.token, chatId, tagName)
        .catch(async (error) => {
            toast.error(error);
            return null;
        });
        
    if (!res) return;
    
    tags = await getTags();
    await updateChatById(localStorage.token, chatId, {
        tags: tags
    });
    
    await _tags.set(await getAllTags(localStorage.token));
};

const deleteTag = async (tagName) => {
    const res = await deleteTagById(localStorage.token, chatId, tagName);
    tags = await getTags();
    await updateChatById(localStorage.token, chatId, {
        tags: tags
    });
    
    await _tags.set(await getAllTags(localStorage.token));
};
```

### Tag Interface
```javascript
<Tags
    {tags}
    on:delete={(e) => {
        deleteTag(e.detail);
    }}
    on:add={(e) => {
        addTag(e.detail);
    }}
/>
```

## 5. Settings Management

### Settings Structure
```javascript
interface Settings {
    system?: string;
    models?: string[];
    params?: {
        temperature?: number;
        top_p?: number;
        frequency_penalty?: number;
        max_tokens?: number;
        stop?: string[];
    };
    ui?: {
        theme?: string;
        fontSize?: string;
        chatDirection?: 'LTR' | 'RTL';
        hapticFeedback?: boolean;
        notificationEnabled?: boolean;
    };
}
```

### Settings Management
From `SettingsModal.svelte`:

```javascript
const saveSettings = async (updated) => {
    await settings.set({ ...$settings, ...updated });
    await models.set(await getModels());
    await updateUserSettings(localStorage.token, { ui: $settings });
};

// Settings modal structure
<Modal bind:show>
    <div class="text-gray-700 dark:text-gray-100">
        <div class="flex flex-col md:flex-row w-full px-4 pt-2 pb-4">
            <div class="tabs flex flex-row overflow-x-auto">
                <button
                    class="px-2.5 py-2 min-w-fit rounded-lg"
                    on:click={() => {
                        selectedTab = 'general';
                    }}
                >
                    {$i18n.t('General')}
                </button>
                <!-- Other tabs -->
            </div>
            
            <div class="flex-1">
                {#if selectedTab === 'general'}
                    <General
                        {getModels}
                        {saveSettings}
                        on:save={() => {
                            toast.success($i18n.t('Settings saved'));
                        }}
                    />
                {/if}
            </div>
        </div>
    </div>
</Modal>
```

## 6. State Persistence

### Local Storage
```javascript
// Persisting state to local storage
const persistState = async () => {
    try {
        localStorage.setItem('settings', 
            JSON.stringify($settings)
        );
        localStorage.setItem('lastChat', 
            JSON.stringify({
                id: $chatId,
                title: $chatTitle,
                timestamp: Date.now()
            })
        );
    } catch (error) {
        console.error('State persistence error:', error);
    }
};

// Loading persisted state
const loadPersistedState = async () => {
    try {
        const settings = JSON.parse(
            localStorage.getItem('settings') ?? '{}'
        );
        const lastChat = JSON.parse(
            localStorage.getItem('lastChat') ?? 'null'
        );
        
        if (settings) {
            await settings.set(settings);
        }
        
        if (lastChat) {
            await chatId.set(lastChat.id);
            await chatTitle.set(lastChat.title);
        }
    } catch (error) {
        console.error('State loading error:', error);
    }
};
```

### Server Synchronization
```javascript
const syncState = async () => {
    try {
        // Sync settings
        const userSettings = await getUserSettings(
            localStorage.token
        );
        
        if (userSettings) {
            settings.set(userSettings.ui);
        }
        
        // Sync chat state
        if (chatId) {
            const chat = await getChatById(
                localStorage.token, 
                chatId
            );
            if (chat) {
                history = chat.history;
                chatTitle.set(chat.title);
            }
        }
    } catch (error) {
        console.error('Sync error:', error);
    }
};
```

## Best Practices and Patterns

1. **State Management**
   - Clear separation of local and remote state
   - Efficient updates
   - Proper error handling

2. **Data Persistence**
   - Regular state saving
   - Error recovery
   - Sync management

3. **User Experience**
   - Responsive feedback
   - Error messages
   - Loading states

4. **Performance**
   - Efficient filtering
   - Pagination
   - Caching

## Exercises

1. Implement a model selection system with:
   - Multiple model support
   - Default model handling
   - Model capabilities checking

2. Create a chat history system:
   - Navigation
   - State management
   - Persistence

3. Build a tag management system:
   - CRUD operations
   - Tag filtering
   - Tag suggestions

4. Implement a settings system:
   - Multiple setting types
   - Validation
   - Persistence

## Next Steps
The next lesson will focus on Interactive Features, including the artifacts system, chat controls, and real-time updates.

















File: lesson-5.md


# Lesson 5: Interactive Features

## Introduction
This lesson explores the interactive features of the chat application, focusing on real-time functionality, artifacts system, chat controls, and event handling. These features create a dynamic and responsive user experience.

## Table of Contents
1. Artifacts System
2. Chat Controls and Tooling
3. WebSocket Integration
4. Event System
5. Real-time Updates
6. Interactive UI Elements

## 1. Artifacts System

### Artifacts Component
From `Artifacts.svelte`, the artifacts management system:

```javascript
export let overlay = false;
export let history;
let messages = [];

let contents: Array<{ type: string; content: string }> = [];
let selectedContentIdx = 0;

// Content processing
const getContents = () => {
    contents = [];
    messages.forEach((message) => {
        if (message?.role !== 'user' && message?.content) {
            // Process code blocks
            const codeBlockContents = message.content.match(/```[\s\S]*?```/g);
            let codeBlocks = [];

            if (codeBlockContents) {
                codeBlockContents.forEach((block) => {
                    const lang = block.split('\n')[0].replace('```', '').trim();
                    const code = block.replace(/```[\s\S]*?\n/, '')
                        .replace(/```$/, '');
                    codeBlocks.push({ lang, code });
                });
            }

            // Process different content types
            if (htmlContent || cssContent || jsContent) {
                const renderedContent = `
                    <!DOCTYPE html>
                    <html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width">
                            <style>${cssContent}</style>
                        </head>
                        <body>
                            ${htmlContent}
                            <script>${jsContent}</script>
                        </body>
                    </html>
                `;
                contents = [...contents, { 
                    type: 'iframe', 
                    content: renderedContent 
                }];
            }
        }
    });
};
```

### Artifact Rendering
```javascript
<div class="w-full h-full relative flex flex-col bg-gray-50 dark:bg-gray-850">
    <div class="w-full h-full flex-1 relative">
        {#if contents.length > 0}
            <div class="max-w-full w-full h-full">
                {#if contents[selectedContentIdx].type === 'iframe'}
                    <iframe
                        bind:this={iframeElement}
                        title="Content"
                        srcdoc={contents[selectedContentIdx].content}
                        class="w-full border-0 h-full rounded-none"
                        sandbox="allow-scripts allow-forms allow-same-origin"
                        on:load={iframeLoadHandler}
                    />
                {:else if contents[selectedContentIdx].type === 'svg'}
                    <SvgPanZoom
                        className="w-full h-full max-h-full overflow-hidden"
                        svg={contents[selectedContentIdx].content}
                    />
                {/if}
            </div>
        {/if}
    </div>
</div>
```

## 2. Chat Controls and Tooling

### ChatControls Component
From `ChatControls.svelte`:

```javascript
export let history;
export let models = [];
export let chatId = null;
export let chatFiles = [];
export let params = {};
export let eventTarget: EventTarget;
export let submitPrompt: Function;
export let stopResponse: Function;
export let files;
export let modelId;

// Responsive handling
const handleMediaQuery = async (e) => {
    if (e.matches) {
        largeScreen = true;
        if ($showCallOverlay) {
            showCallOverlay.set(false);
            await tick();
            showCallOverlay.set(true);
        }
    } else {
        largeScreen = false;
        pane = null;
    }
};

// Control panel sizing
const openPane = () => {
    if (parseInt(localStorage?.chatControlsSize)) {
        pane.resize(parseInt(localStorage?.chatControlsSize));
    } else {
        pane.resize(minSize);
    }
};
```

### Tools Implementation
```javascript
// Tool integration
<div class="flex items-center space-x-2">
    {#each tools as tool}
        <button
            class="tool-button"
            on:click={() => handleToolClick(tool)}
            disabled={!tool.available}
        >
            <Icon name={tool.icon} />
            <span>{tool.name}</span>
        </button>
    {/each}
</div>

// Tool handling
const handleToolClick = async (tool) => {
    switch (tool.type) {
        case 'file':
            await handleFileUpload();
            break;
        case 'voice':
            startVoiceRecording();
            break;
        case 'search':
            toggleSearch();
            break;
        default:
            console.warn('Unknown tool type:', tool.type);
    }
};
```

## 3. WebSocket Integration

### Socket Setup
```javascript
const setupWebSocket = () => {
    const socket = io(WEBUI_API_BASE_URL, {
        transports: ['websocket'],
        auth: {
            token: localStorage.token
        }
    });

    socket.on('connect', () => {
        console.log('Connected to WebSocket');
    });

    socket.on('disconnect', () => {
        console.log('Disconnected from WebSocket');
    });

    return socket;
};

// Socket event handling
socket.on('chat-events', async (event) => {
    if (event.chat_id === chatId) {
        await handleChatEvent(event);
    }
});

const handleChatEvent = async (event) => {
    const { type, data } = event;
    
    switch (type) {
        case 'message':
            await handleMessageEvent(data);
            break;
        case 'status':
            updateStatus(data);
            break;
        case 'error':
            handleError(data);
            break;
    }
};
```

## 4. Event System

### Custom Events
```javascript
// Event target setup
const eventTarget = new EventTarget();

// Event dispatching
const dispatchMessageEvent = (message) => {
    eventTarget.dispatchEvent(
        new CustomEvent('chat', {
            detail: {
                id: message.id,
                content: message.content
            }
        })
    );
};

// Event handling
eventTarget.addEventListener('chat:start', async (event) => {
    const { id } = event.detail;
    await startMessageProcessing(id);
});

eventTarget.addEventListener('chat:finish', async (event) => {
    const { id, content } = event.detail;
    await finalizeMessage(id, content);
});
```

### Event Handlers
```javascript
const chatEventHandler = async (event, cb) => {
    if (event.chat_id === $chatId) {
        let message = history.messages[event.message_id];
        const type = event?.data?.type ?? null;
        const data = event?.data?.data ?? null;

        switch (type) {
            case 'status':
                if (message?.statusHistory) {
                    message.statusHistory.push(data);
                } else {
                    message.statusHistory = [data];
                }
                break;
                
            case 'citation':
                if (data?.type === 'code_execution') {
                    handleCodeExecution(message, data);
                } else {
                    handleCitation(message, data);
                }
                break;
                
            case 'message':
                message.content += data.content;
                break;
        }

        history.messages[event.message_id] = message;
    }
};
```

## 5. Real-time Updates

### Message Streaming
```javascript
const handleMessageStream = async (res) => {
    const textStream = await createOpenAITextStream(
        res.body, 
        $settings.splitLargeChunks
    );

    for await (const update of textStream) {
        const { value, done, citations, error, usage } = update;
        
        if (error) {
            await handleError(error);
            break;
        }
        
        if (done) {
            finalizeMessage();
            break;
        }

        if (usage) {
            updateUsageStats(usage);
        }

        if (citations) {
            handleCitations(citations);
        }

        await updateMessageContent(value);
    }
};
```

### Status Updates
```javascript
const updateMessageStatus = (message, status) => {
    const statusUpdate = {
        action: status.action,
        description: status.description,
        timestamp: Date.now()
    };

    if (message.statusHistory) {
        message.statusHistory.push(statusUpdate);
    } else {
        message.statusHistory = [statusUpdate];
    }

    history.messages[message.id] = message;
};
```

## 6. Interactive UI Elements

### Voice Recording
```javascript
const VoiceRecording = {
    data() {
        return {
            recording: false,
            audioChunks: [],
            mediaRecorder: null
        };
    },

    methods: {
        async startRecording() {
            try {
                const stream = await navigator.mediaDevices
                    .getUserMedia({ audio: true });
                    
                this.mediaRecorder = new MediaRecorder(stream);
                this.audioChunks = [];

                this.mediaRecorder.addEventListener(
                    'dataavailable', 
                    event => {
                        this.audioChunks.push(event.data);
                    }
                );

                this.mediaRecorder.addEventListener(
                    'stop', 
                    () => {
                        this.processRecording();
                    }
                );

                this.mediaRecorder.start();
                this.recording = true;
            } catch (error) {
                console.error('Recording error:', error);
                toast.error('Failed to start recording');
            }
        },

        async processRecording() {
            const audioBlob = new Blob(
                this.audioChunks, 
                { type: 'audio/wav' }
            );
            const audioUrl = URL.createObjectURL(audioBlob);
            
            // Process audio
            const text = await transcribeAudio(audioBlob);
            this.$emit('recorded', { text, audioUrl });
        }
    }
};
```

### Drag and Drop
```javascript
const handleDragOver = (e) => {
    e.preventDefault();
    if (e.dataTransfer?.types?.includes('Files')) {
        dragged = true;
    } else {
        dragged = false;
    }
};

const handleDrop = async (e) => {
    e.preventDefault();
    if (e.dataTransfer?.files) {
        const inputFiles = Array.from(e.dataTransfer?.files);
        if (inputFiles && inputFiles.length > 0) {
            await processFiles(inputFiles);
        }
    }
    dragged = false;
};
```

## Best Practices and Patterns

1. **Real-time Communication**
   - Efficient WebSocket usage
   - Proper connection management
   - Error handling and recovery

2. **Event Handling**
   - Clear event hierarchy
   - Type-safe event data
   - Proper cleanup

3. **User Interaction**
   - Responsive feedback
   - Progress indication
   - Error recovery

4. **Performance**
   - Efficient updates
   - Resource cleanup
   - Memory management

## Exercises

1. Implement a real-time chat feature:
   - WebSocket connection
   - Message streaming
   - Status updates
   - Error handling

2. Create an interactive tool:
   - User interface
   - Event handling
   - State management
   - Error handling

3. Build a voice recording system:
   - Recording interface
   - Audio processing
   - Transcription
   - Error handling

4. Implement a drag-and-drop system:
   - File handling
   - Progress indication
   - Error handling
   - Success feedback

## Next Steps
The next and final lesson will focus on User Experience and Polish, covering themes, internationalization, keyboard shortcuts, and performance optimizations.

















File: lesson-6.md


# Lesson 6: User Experience and Polish

## Introduction
This final lesson covers the aspects that transform a functional application into a polished, professional product. We'll explore theme management, internationalization, keyboard shortcuts, performance optimizations, and user feedback systems.

## Table of Contents
1. Theme Management
2. Internationalization (i18n)
3. Keyboard Shortcuts
4. Performance Optimizations
5. Error Handling
6. User Feedback Systems

## 1. Theme Management

### Theme System Implementation
From the theme management system:

```javascript
// Theme store and settings
import { writable } from 'svelte/store';
export const theme = writable('system');

// Theme application
const applyTheme = (themeName) => {
    const root = document.documentElement;
    const isDark = themeName === 'dark' || 
        (themeName === 'system' && 
            window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDark) {
        root.classList.add('dark');
    } else {
        root.classList.remove('dark');
    }
};

// Theme reactivity
$: if (browser) {
    applyTheme($theme);
}
```

### Theme Classes Implementation
```javascript
// Base theme classes
const baseThemeClasses = {
    app: `
        bg-white dark:bg-gray-900
        text-gray-900 dark:text-gray-100
    `,
    input: `
        bg-gray-50 dark:bg-gray-850
        text-gray-900 dark:text-gray-100
        border-gray-200 dark:border-gray-800
    `,
    button: `
        bg-gray-100 dark:bg-gray-800
        hover:bg-gray-200 dark:hover:bg-gray-700
        text-gray-900 dark:text-gray-100
    `
};

// Theme application in components
<div class={`
    ${baseThemeClasses.app}
    transition-colors duration-200
`}>
    <input class={`
        ${baseThemeClasses.input}
        rounded-lg px-4 py-2
    `} />
    
    <button class={`
        ${baseThemeClasses.button}
        rounded-lg px-4 py-2
    `}>
        {$i18n.t('Submit')}
    </button>
</div>
```

## 2. Internationalization (i18n)

### I18n Setup and Configuration
```javascript
// i18n initialization
import i18next from 'i18next';
import { createI18nStore } from 'svelte-i18next';

const i18n = createI18nStore(i18next);

i18next.init({
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
        escapeValue: false
    },
    resources: {
        en: {
            translation: require('./locales/en.json')
        },
        es: {
            translation: require('./locales/es.json')
        }
    }
});

// Making i18n available to components
setContext('i18n', i18n);
```

### Translation Implementation
```javascript
// Translation usage in components
<script>
    const i18n = getContext('i18n');
</script>

<div>
    <h1>{$i18n.t('Welcome, {{name}}', { name: user.name })}</h1>
    <p>{$i18n.t('messages.greeting')}</p>
    
    <!-- Pluralization -->
    <p>
        {$i18n.t('messages.items', { 
            count: items.length,
            defaultValue: '{{count}} item',
            defaultValue_plural: '{{count}} items'
        })}
    </p>
    
    <!-- Date formatting -->
    <p>
        {$i18n.t('messages.date', { 
            date: new Date(),
            formatParams: {
                date: {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                }
            }
        })}
    </p>
</div>
```

## 3. Keyboard Shortcuts

### Shortcuts System
From `ShortcutsModal.svelte`:

```javascript
// Keyboard shortcuts registration
const registerShortcuts = () => {
    const shortcuts = {
        'mod+shift+o': initNewChat,
        'shift+escape': focusChatInput,
        'mod+shift+;': copyLastCodeBlock,
        'mod+shift+c': copyLastResponse,
        'mod+.': toggleSettings,
        'mod+shift+s': toggleSidebar,
        'mod+shift+delete': deleteChat,
        'mod+/': showShortcuts
    };

    Object.entries(shortcuts).forEach(([key, handler]) => {
        keyboardjs.bind(key, (e) => {
            e.preventDefault();
            handler();
        });
    });
};

// Shortcut handler implementation
const handleKeyDown = (event: KeyboardEvent) => {
    // Command/Ctrl + Shift + Enter to submit a message pair
    if ((event.ctrlKey || event.metaKey) && 
        event.key === 'Enter' && 
        event.shiftKey) {
        event.preventDefault();
        createMessagePair(prompt);
    }

    // Check for Ctrl + R for regeneration
    if (prompt === '' && 
        (event.ctrlKey || event.metaKey) && 
        event.key.toLowerCase() === 'r') {
        event.preventDefault();
        const regenerateButton = document
            .getElementsByClassName('regenerate-response-button')
            ?.at(-1);
        regenerateButton?.click();
    }
};
```

### Shortcuts Modal
```javascript
<Modal bind:show>
    <div class="text-gray-700 dark:text-gray-100">
        <div class="flex flex-col space-y-3">
            {#each shortcuts as shortcut}
                <div class="flex justify-between items-center">
                    <div class="text-sm">
                        {$i18n.t(shortcut.description)}
                    </div>
                    
                    <div class="flex space-x-1 text-xs">
                        {#each shortcut.keys as key}
                            <div class="px-2 py-1 rounded border">
                                {key}
                            </div>
                        {/each}
                    </div>
                </div>
            {/each}
        </div>
    </div>
</Modal>
```

## 4. Performance Optimizations

### Virtual Scrolling
```javascript
// Virtual scrolling implementation
const VirtualList = {
    data() {
        return {
            visibleItems: [],
            startIndex: 0,
            endIndex: 0,
            itemHeight: 50,
            containerHeight: 0,
            scrollTop: 0
        };
    },

    computed: {
        totalHeight() {
            return this.items.length * this.itemHeight;
        },
        
        visibleCount() {
            return Math.ceil(this.containerHeight / this.itemHeight) + 2;
        }
    },

    methods: {
        updateVisibleItems() {
            this.startIndex = Math.floor(
                this.scrollTop / this.itemHeight
            );
            this.endIndex = Math.min(
                this.startIndex + this.visibleCount,
                this.items.length
            );
            
            this.visibleItems = this.items.slice(
                this.startIndex,
                this.endIndex
            );
        },

        handleScroll(event) {
            this.scrollTop = event.target.scrollTop;
            this.updateVisibleItems();
        }
    }
};
```

### Lazy Loading
```javascript
// Lazy loading implementation
const lazyLoadMessages = async () => {
    const observer = new IntersectionObserver(
        (entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !messagesLoading) {
                    loadMoreMessages();
                }
            });
        },
        { threshold: 0.5 }
    );

    const sentinel = document.querySelector('.load-more-sentinel');
    if (sentinel) {
        observer.observe(sentinel);
    }
};

// Message loading
const loadMoreMessages = async () => {
    messagesLoading = true;
    
    try {
        const newMessages = await fetchMessages(
            currentPage + 1,
            pageSize
        );
        messages = [...messages, ...newMessages];
        currentPage += 1;
    } catch (error) {
        console.error('Failed to load messages:', error);
    } finally {
        messagesLoading = false;
    }
};
```

## 5. Error Handling

### Error Handling System
```javascript
// Global error handler
const handleError = async (error, context = '') => {
    console.error(`Error in ${context}:`, error);
    
    // Determine error type and appropriate response
    let userMessage = '';
    if (error.name === 'NetworkError') {
        userMessage = $i18n.t('errors.network');
    } else if (error.name === 'AuthError') {
        userMessage = $i18n.t('errors.authentication');
        await handleAuthError();
    } else {
        userMessage = $i18n.t('errors.generic');
    }
    
    // Show error to user
    toast.error(userMessage);
    
    // Log error for analysis
    await logError({
        error: error.toString(),
        context,
        timestamp: new Date(),
        user: $user.id
    });
};

// Component-level error handling
const handleComponentError = async (error, component) => {
    // Update component state
    component.error = true;
    component.errorMessage = error.message;
    
    // Show error UI
    if (component.showError) {
        component.showError(error);
    }
    
    // Log error
    await handleError(error, component.name);
};
```

### Error Boundaries
```javascript
// Error boundary component
<script>
    let hasError = false;
    let error = null;

    function handleError(event) {
        hasError = true;
        error = event.error;
    }
</script>

<svelte:window on:error={handleError} />

{#if hasError}
    <div class="error-boundary">
        <h2>{$i18n.t('errors.component_error')}</h2>
        <p>{error.message}</p>
        <button on:click={() => {
            hasError = false;
            error = null;
        }}>
            {$i18n.t('errors.retry')}
        </button>
    </div>
{:else}
    <slot />
{/if}
```

## 6. User Feedback Systems

### Toast Notifications
```javascript
// Toast system implementation
const showToast = (message, type = 'info') => {
    toast[type](message, {
        position: 'bottom-center',
        duration: 3000,
        className: `
            ${type === 'error' ? 'bg-red-500' : 'bg-gray-800'} 
            text-white rounded-lg px-4 py-2
        `
    });
};

// Usage examples
const handleSuccess = () => {
    showToast($i18n.t('messages.success'), 'success');
};

const handleError = (error) => {
    showToast(error.message, 'error');
};
```

### Progress Indicators
```javascript
// Progress handling
const ProgressIndicator = {
    data() {
        return {
            progress: 0,
            status: 'idle',
            message: ''
        };
    },

    methods: {
        startProgress() {
            this.status = 'loading';
            this.progress = 0;
            this.updateProgress();
        },

        updateProgress(increment = 10) {
            if (this.status === 'loading') {
                this.progress = Math.min(
                    this.progress + increment,
                    99
                );
                setTimeout(
                    () => this.updateProgress(increment / 2),
                    100
                );
            }
        },

        complete() {
            this.progress = 100;
            this.status = 'complete';
            setTimeout(() => {
                this.reset();
            }, 1000);
        },

        reset() {
            this.progress = 0;
            this.status = 'idle';
            this.message = '';
        }
    }
};
```

### Loading States
```javascript
// Loading state management
const LoadingState = {
    data() {
        return {
            loading: false,
            loadingMessage: '',
            error: null
        };
    },

    methods: {
        async withLoading(action, message = '') {
            this.loading = true;
            this.loadingMessage = message;
            this.error = null;

            try {
                await action();
            } catch (error) {
                this.error = error;
                handleError(error);
            } finally {
                this.loading = false;
                this.loadingMessage = '';
            }
        }
    }
};
```

## Best Practices and Patterns

1. **Theme Management**
   - Consistent color schemes
   - Smooth transitions
   - System theme support
   - Accessible contrast ratios

2. **Internationalization**
   - String externalization
   - Format handling
   - RTL support
   - Cultural considerations

3. **Performance**
   - Resource optimization
   - Lazy loading
   - Memory management
   - Event delegation

4. **Error Handling**
   - Graceful degradation
   - Clear user feedback
   - Error recovery
   - Logging and monitoring

## Exercises

1. Implement a theme system:
   - Light/dark modes
   - System preference detection
   - Theme switching
   - Persistence

2. Create an i18n implementation:
   - Multiple languages
   - String management
   - Format handling
   - RTL support

3. Build a shortcuts system:
   - Keyboard shortcuts
   - Command palette
   - Custom bindings
   - User preferences

4. Implement performance optimizations:
   - Virtual scrolling
   - Lazy loading
   - Resource management
   - Caching

## Conclusion

This concludes our comprehensive exploration of the chat application. We've covered:
- Foundational architecture
- Core functionality
- UI components
- Advanced features
- Interactive elements
- Polish and optimization

The skills and patterns learned can be applied to build sophisticated, production-ready web applications.

Remember to:
- Follow best practices
- Consider user experience
- Maintain code quality
- Test thoroughly
- Document properly
- Monitor performance

Keep exploring and improving your applications!

















