# Lesson 6: Testing and Development Workflow
## Part 2: Development Workflow and Best Practices

## Overview and Learning Objectives

This second part of the 4-hour lesson focuses on establishing efficient development workflows and implementing best practices in the Open WebUI project. We'll cover Git workflows, code review processes, documentation standards, and performance optimization techniques.

By the end of Part 2, developers will be able to:
1. Implement efficient Git workflows
2. Conduct effective code reviews
3. Write comprehensive documentation
4. Debug across different platforms
5. Optimize application performance

## Section 1: Development Workflow Implementation (60 minutes)

### Git Workflow Structure

The Open WebUI project follows a structured Git workflow:

```
main (production)
  │
  ├── develop (staging)
  │     │
  │     ├── feature/add-chat-export
  │     ├── feature/improve-search
  │     └── feature/update-settings
  │
  ├── hotfix/security-patch
  └── release/v1.2.0
```

### Workflow Implementation

Implementation of development workflow tools:

```typescript
// scripts/workflow/pre-commit.ts

import { execSync } from 'child_process';
import { readFileSync, writeFileSync } from 'fs';

interface CommitCheck {
    name: string;
    check: () => boolean;
    fix?: () => void;
}

class PreCommitChecker {
    private checks: CommitCheck[] = [
        {
            name: 'Code Formatting',
            check: () => this.checkFormatting(),
            fix: () => this.fixFormatting()
        },
        {
            name: 'Type Checking',
            check: () => this.checkTypes()
        },
        {
            name: 'Unit Tests',
            check: () => this.runTests()
        },
        {
            name: 'Lint Rules',
            check: () => this.checkLinting(),
            fix: () => this.fixLinting()
        }
    ];

    async run(): Promise<boolean> {
        let success = true;
        
        for (const check of this.checks) {
            try {
                console.log(`Running ${check.name}...`);
                const passed = check.check();
                
                if (!passed && check.fix) {
                    console.log(`Attempting to fix ${check.name}...`);
                    check.fix();
                    
                    if (!check.check()) {
                        console.error(`Failed to fix ${check.name}`);
                        success = false;
                        break;
                    }
                } else if (!passed) {
                    console.error(`${check.name} failed`);
                    success = false;
                    break;
                }
            } catch (error) {
                console.error(`Error in ${check.name}:`, error);
                success = false;
                break;
            }
        }
        
        return success;
    }

    private checkFormatting(): boolean {
        try {
            execSync('npm run format:check', { stdio: 'ignore' });
            return true;
        } catch {
            return false;
        }
    }

    private fixFormatting(): void {
        execSync('npm run format');
    }

    private checkTypes(): boolean {
        try {
            execSync('npm run type-check', { stdio: 'ignore' });
            return true;
        } catch {
            return false;
        }
    }

    private runTests(): boolean {
        try {
            execSync('npm run test:unit', { stdio: 'ignore' });
            return true;
        } catch {
            return false;
        }
    }

    private checkLinting(): boolean {
        try {
            execSync('npm run lint:check', { stdio: 'ignore' });
            return true;
        } catch {
            return false;
        }
    }

    private fixLinting(): void {
        execSync('npm run lint:fix');
    }
}

// Run pre-commit checks
const checker = new PreCommitChecker();
checker.run().then(success => {
    process.exit(success ? 0 : 1);
});
```

### Code Review Process

Implementation of code review tools and automation:

```typescript
// scripts/workflow/review-check.ts

interface ReviewCheck {
    title: string;
    description: string;
    check: () => Promise<boolean>;
}

class CodeReviewChecker {
    private checks: ReviewCheck[] = [
        {
            title: 'Bundle Size',
            description: 'Check if bundle size increased significantly',
            check: async () => this.checkBundleSize()
        },
        {
            title: 'Test Coverage',
            description: 'Verify test coverage meets threshold',
            check: async () => this.checkTestCoverage()
        },
        {
            title: 'Performance Metrics',
            description: 'Check performance benchmarks',
            check: async () => this.checkPerformance()
        }
    ];

    async runChecks(): Promise<boolean> {
        let allPassed = true;
        const results = [];

        for (const check of this.checks) {
            try {
                console.log(`Running ${check.title}...`);
                const passed = await check.check();
                
                results.push({
                    title: check.title,
                    passed,
                    description: check.description
                });

                if (!passed) {
                    allPassed = false;
                }
            } catch (error) {
                console.error(`Error in ${check.title}:`, error);
                allPassed = false;
            }
        }

        this.generateReport(results);
        return allPassed;
    }

    private async checkBundleSize(): Promise<boolean> {
        const stats = await import('../../dist/stats.json');
        const maxSize = 1024 * 1024; // 1MB
        return stats.assets.every(asset => asset.size < maxSize);
    }

    private async checkTestCoverage(): Promise<boolean> {
        const coverage = await import('../../coverage/coverage-summary.json');
        const threshold = 80;
        return coverage.total.lines.pct >= threshold;
    }

    private async checkPerformance(): Promise<boolean> {
        const metrics = await this.runPerformanceTests();
        return metrics.score >= 90;
    }

    private generateReport(results: any[]): void {
        const report = {
            timestamp: new Date().toISOString(),
            results,
            summary: {
                total: results.length,
                passed: results.filter(r => r.passed).length
            }
        };

        writeFileSync(
            'review-report.json',
            JSON.stringify(report, null, 2)
        );
    }
}
```

## Section 2: Documentation and Debugging (60 minutes)

### Documentation Implementation

Example of documentation generation system:

```typescript
// scripts/docs/generator.ts

import { parse } from 'typescript';
import { readFileSync, writeFileSync } from 'fs';
import { resolve } from 'path';

interface DocItem {
    name: string;
    description: string;
    params?: Parameter[];
    returns?: string;
    examples?: string[];
}

interface Parameter {
    name: string;
    type: string;
    description: string;
}

class DocumentationGenerator {
    private docs: DocItem[] = [];

    async generateDocs(sourceDir: string): Promise<void> {
        // Parse TypeScript files
        const files = this.getTypeScriptFiles(sourceDir);
        
        for (const file of files) {
            const source = readFileSync(file, 'utf-8');
            const ast = parse(source, {
                jsx: true,
                decorators: true
            });

            const docItems = this.extractDocs(ast);
            this.docs.push(...docItems);
        }

        // Generate documentation
        await this.generateMarkdown();
        await this.generateHTML();
    }

    private extractDocs(ast: any): DocItem[] {
        const items: DocItem[] = [];
        
        // Traverse AST and extract documentation
        this.traverseNode(ast, (node) => {
            if (this.isDocumentedNode(node)) {
                const doc = this.parseDocComments(node);
                if (doc) items.push(doc);
            }
        });

        return items;
    }

    private generateMarkdown(): void {
        let markdown = '# API Documentation\n\n';

        for (const item of this.docs) {
            markdown += `## ${item.name}\n\n`;
            markdown += `${item.description}\n\n`;

            if (item.params?.length) {
                markdown += '### Parameters\n\n';
                for (const param of item.params) {
                    markdown += `- **${param.name}** (${param.type}): ${param.description}\n`;
                }
                markdown += '\n';
            }

            if (item.returns) {
                markdown += `### Returns\n\n${item.returns}\n\n`;
            }

            if (item.examples?.length) {
                markdown += '### Examples\n\n';
                for (const example of item.examples) {
                    markdown += '```typescript\n' + example + '\n```\n\n';
                }
            }
        }

        writeFileSync('docs/api.md', markdown);
    }

    private generateHTML(): void {
        let html = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>API Documentation</title>
            <style>
                body { font-family: system-ui; max-width: 800px; margin: 0 auto; }
                .doc-item { margin: 2em 0; padding: 1em; border: 1px solid #eee; }
                .parameters { margin: 1em 0; }
                .example { background: #f5f5f5; padding: 1em; margin: 1em 0; }
            </style>
        </head>
        <body>
            <h1>API Documentation</h1>
        `;

        for (const item of this.docs) {
            html += `
            <div class="doc-item">
                <h2>${item.name}</h2>
                <p>${item.description}</p>
            `;

            if (item.params?.length) {
                html += `
                <div class="parameters">
                    <h3>Parameters</h3>
                    <ul>
                    ${item.params.map(param => `
                        <li>
                            <strong>${param.name}</strong> (${param.type}):
                            ${param.description}
                        </li>
                    `).join('')}
                    </ul>
                </div>
                `;
            }

            if (item.examples?.length) {
                html += `
                <div class="examples">
                    <h3>Examples</h3>
                    ${item.examples.map(example => `
                        <pre class="example"><code>${example}</code></pre>
                    `).join('')}
                </div>
                `;
            }

            html += '</div>';
        }

        html += '</body></html>';
        writeFileSync('docs/api.html', html);
    }
}
```

### Debugging Implementation

Cross-platform debugging utilities:

```typescript
// utils/debug.ts

interface DebugConfig {
    enabled: boolean;
    level: 'error' | 'warn' | 'info' | 'debug';
    platform: 'browser' | 'node';
}

class DebugManager {
    private static instance: DebugManager;
    private config: DebugConfig;

    private constructor() {
        this.config = {
            enabled: process.env.NODE_ENV !== 'production',
            level: 'info',
            platform: typeof window !== 'undefined' ? 'browser' : 'node'
        };
    }

    static getInstance(): DebugManager {
        if (!DebugManager.instance) {
            DebugManager.instance = new DebugManager();
        }
        return DebugManager.instance;
    }

    setConfig(config: Partial<DebugConfig>): void {
        this.config = { ...this.config, ...config };
    }

    log(level: DebugConfig['level'], message: string, ...args: any[]): void {
        if (!this.config.enabled) return;
        if (this.getLevelPriority(level) > this.getLevelPriority(this.config.level)) return;

        const timestamp = new Date().toISOString();
        const formattedMessage = `[${timestamp}] ${level.toUpperCase()}: ${message}`;

        if (this.config.platform === 'browser') {
            switch (level) {
                case 'error':
                    console.error(formattedMessage, ...args);
                    break;
                case 'warn':
                    console.warn(formattedMessage, ...args);
                    break;
                case 'info':
                    console.info(formattedMessage, ...args);
                    break;
                case 'debug':
                    console.debug(formattedMessage, ...args);
                    break;
            }
        } else {
            // Node.js specific logging
            const util = require('util');
            const formatted = util.format(formattedMessage, ...args);
            process.stdout.write(formatted + '\n');
        }
    }

    private getLevelPriority(level: DebugConfig['level']): number {
        const priorities = {
            error: 0,
            warn: 1,
            info: 2,
            debug: 3
        };
        return priorities[level];
    }
}

export const debug = DebugManager.getInstance();
```

## Assessment Activities for Part 2

### Exercise 1: Workflow Implementation

Create a complete development workflow:

1. Set up Git hooks
2. Implement automated checks
3. Create review processes
4. Configure CI/CD pipelines
5. Document workflow procedures

### Exercise 2: Documentation Generation

Implement documentation systems:

1. Set up auto-documentation
2. Create documentation templates
3. Implement style guides
4. Generate API documentation
5. Create usage examples

### Exercise 3: Debugging Implementation

Create debugging tools:

1. Implement logging system
2. Create debug utilities
3. Add performance monitoring
4. Implement error tracking
5. Create debugging documentation

## Additional Resources

1. Workflow Documentation
- Git Best Practices
- Code Review Guidelines
- Documentation Standards
- Debugging Techniques
- Performance Optimization Guides

2. Tool References
- Git Documentation
- TypeScript Documentation
- Node.js Debugging Guide
- Chrome DevTools Documentation
- Performance Profiling Tools

## Final Assessment Criteria

Developers will be evaluated based on:

1. Workflow Implementation
- Git workflow understanding
- Code review process
- Documentation quality
- Debugging capabilities
- Performance optimization

2. Code Quality
- Code organization
- Documentation standards
- Error handling
- Cross-platform compatibility
- Performance considerations

3. Project Deliverables
- Workflow documentation
- Code review checklist
- API documentation
- Debug utilities
- Performance reports

## Next Steps

After completing this lesson, developers should:

1. Review workflow practices
2. Implement documentation standards
3. Set up debugging tools
4. Configure performance monitoring
5. Prepare for the next lesson on Security and Production Deployment

This comprehensive lesson provides developers with the knowledge and tools needed to implement effective development workflows while maintaining high code quality and documentation standards.