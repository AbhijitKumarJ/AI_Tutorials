# Lesson 6: Testing and Development Workflow
## Part 1: Testing Architecture and Implementation

## Overview and Learning Objectives

This first part of the 4-hour lesson focuses on establishing a robust testing architecture and implementing comprehensive testing strategies for Open WebUI. The emphasis is on ensuring code quality and cross-platform compatibility through systematic testing approaches.

By the end of Part 1, developers will be able to:
1. Set up a complete testing environment
2. Implement various types of tests
3. Create platform-specific test cases
4. Understand and implement test coverage analysis
5. Debug effectively across different platforms

## Section 1: Testing Setup and Architecture (60 minutes)

### Project Testing Structure

The Open WebUI testing infrastructure is organized as follows:

```
/
├── cypress/                 # End-to-end testing
│   ├── e2e/                # E2E test specifications
│   │   ├── chat.cy.ts
│   │   ├── documents.cy.ts
│   │   ├── registration.cy.ts
│   │   └── settings.cy.ts
│   ├── support/            # Test support files
│   │   ├── e2e.ts
│   │   └── index.d.ts
│   └── tsconfig.json       # TypeScript configuration
├── test/                   # Unit and integration tests
│   ├── test_files/        # Test fixtures
│   └── utils/             # Test utilities
└── package.json           # Test dependencies and scripts
```

### Testing Framework Configuration

Implementation of test configuration:

```typescript
// cypress/support/e2e.ts

import './commands';

declare global {
    namespace Cypress {
        interface Chainable {
            login(email: string, password: string): Chainable<void>;
            logout(): Chainable<void>;
            createChat(): Chainable<string>;
            clearLocalStorage(): Chainable<void>;
        }
    }
}

Cypress.Commands.add('login', (email, password) => {
    cy.visit('/auth');
    cy.get('[data-cy=email-input]').type(email);
    cy.get('[data-cy=password-input]').type(password);
    cy.get('[data-cy=login-button]').click();
    cy.url().should('not.include', '/auth');
});

Cypress.Commands.add('createChat', () => {
    cy.get('[data-cy=new-chat-button]').click();
    cy.get('[data-cy=chat-input]').should('be.visible');
    return cy.url().then(url => {
        const chatId = url.split('/').pop();
        return chatId;
    });
});
```

### Test Data Management

Implementation of test data handling:

```typescript
// test/utils/testData.ts

export interface TestFixture {
    users: TestUser[];
    chats: TestChat[];
    messages: TestMessage[];
}

export class TestDataManager {
    private static instance: TestDataManager;
    private fixtures: Map<string, TestFixture> = new Map();

    private constructor() {
        // Private constructor for singleton pattern
    }

    static getInstance(): TestDataManager {
        if (!TestDataManager.instance) {
            TestDataManager.instance = new TestDataManager();
        }
        return TestDataManager.instance;
    }

    async loadFixture(name: string): Promise<TestFixture> {
        if (this.fixtures.has(name)) {
            return this.fixtures.get(name)!;
        }

        const fixture = await import(`../test_files/${name}.json`);
        this.fixtures.set(name, fixture);
        return fixture;
    }

    async cleanupFixture(name: string): Promise<void> {
        // Cleanup test data after test completion
        if (this.fixtures.has(name)) {
            const fixture = this.fixtures.get(name)!;
            await this.cleanupTestData(fixture);
            this.fixtures.delete(name);
        }
    }

    private async cleanupTestData(fixture: TestFixture): Promise<void> {
        // Implement cleanup logic for test data
        for (const user of fixture.users) {
            await this.deleteTestUser(user);
        }
        // Similar cleanup for other data types
    }
}
```

## Section 2: Unit Testing Implementation (60 minutes)

### Component Testing

Example of component testing implementation:

```typescript
// test/components/Chat.test.ts

import { render, fireEvent, screen } from '@testing-library/svelte';
import { tick } from 'svelte';
import Chat from '$lib/components/chat/Chat.svelte';
import { chatStore } from '$lib/stores';
import type { ChatMessage } from '$lib/types';

describe('Chat Component', () => {
    let mockMessages: ChatMessage[];
    
    beforeEach(() => {
        mockMessages = [
            {
                id: '1',
                content: 'Test message 1',
                role: 'user',
                timestamp: Date.now()
            },
            {
                id: '2',
                content: 'Test response 1',
                role: 'assistant',
                timestamp: Date.now()
            }
        ];
        
        chatStore.set({ messages: mockMessages });
    });

    test('renders chat messages correctly', () => {
        const { container } = render(Chat);
        
        const messageElements = container.querySelectorAll('[data-testid^="chat-message-"]');
        expect(messageElements).toHaveLength(mockMessages.length);
        
        const firstMessage = screen.getByTestId('chat-message-1');
        expect(firstMessage).toHaveTextContent('Test message 1');
    });

    test('handles new message submission', async () => {
        const { container } = render(Chat);
        
        const input = container.querySelector('[data-testid="chat-input"]');
        const sendButton = container.querySelector('[data-testid="send-button"]');
        
        await fireEvent.input(input, { target: { value: 'New test message' } });
        await fireEvent.click(sendButton);
        
        await tick();
        
        const messages = chatStore.get().messages;
        expect(messages).toHaveLength(mockMessages.length + 1);
        expect(messages[messages.length - 1].content).toBe('New test message');
    });

    test('handles message deletion', async () => {
        const { container } = render(Chat);
        
        const deleteButton = container.querySelector('[data-testid="delete-message-1"]');
        await fireEvent.click(deleteButton);
        
        await tick();
        
        const messages = chatStore.get().messages;
        expect(messages).toHaveLength(mockMessages.length - 1);
        expect(messages.find(m => m.id === '1')).toBeUndefined();
    });
});
```

### Utility Testing

Implementation of utility function testing:

```typescript
// test/utils/chatUtils.test.ts

import { 
    sanitizeResponseContent,
    convertMessagesToHistory,
    getTimeRange
} from '$lib/utils';

describe('Chat Utilities', () => {
    describe('sanitizeResponseContent', () => {
        test('removes unsafe HTML content', () => {
            const input = '<script>alert("xss")</script>Hello<b>World</b>';
            const expected = 'Hello&lt;b&gt;World&lt;/b&gt;';
            expect(sanitizeResponseContent(input)).toBe(expected);
        });

        test('handles empty string', () => {
            expect(sanitizeResponseContent('')).toBe('');
        });

        test('preserves unicode characters', () => {
            const input = 'Hello 👋 World 🌍';
            expect(sanitizeResponseContent(input)).toBe(input);
        });
    });

    describe('convertMessagesToHistory', () => {
        const mockMessages = [
            { id: '1', content: 'Hello', role: 'user' },
            { id: '2', content: 'Hi', role: 'assistant' }
        ];

        test('creates correct history structure', () => {
            const history = convertMessagesToHistory(mockMessages);
            
            expect(history).toHaveProperty('messages');
            expect(history).toHaveProperty('currentId');
            expect(Object.keys(history.messages)).toHaveLength(mockMessages.length);
        });

        test('maintains message order', () => {
            const history = convertMessagesToHistory(mockMessages);
            const messageIds = Object.keys(history.messages);
            
            expect(history.messages[messageIds[0]].content).toBe('Hello');
            expect(history.messages[messageIds[1]].content).toBe('Hi');
        });
    });

    describe('getTimeRange', () => {
        test('returns "Today" for current date', () => {
            const now = Date.now();
            expect(getTimeRange(now / 1000)).toBe('Today');
        });

        test('returns "Yesterday" for yesterday', () => {
            const yesterday = Date.now() - 24 * 60 * 60 * 1000;
            expect(getTimeRange(yesterday / 1000)).toBe('Yesterday');
        });
    });
});
```

### Store Testing

Implementation of store testing:

```typescript
// test/stores/chatStore.test.ts

import { get } from 'svelte/store';
import { 
    chatStore,
    createChat,
    updateChat,
    deleteChat 
} from '$lib/stores/chat';

describe('Chat Store', () => {
    beforeEach(() => {
        chatStore.reset();
    });

    test('creates new chat correctly', () => {
        const chatData = {
            id: '123',
            title: 'Test Chat',
            messages: []
        };

        createChat(chatData);
        
        const storeValue = get(chatStore);
        expect(storeValue.chats).toHaveLength(1);
        expect(storeValue.chats[0]).toMatchObject(chatData);
    });

    test('updates existing chat', () => {
        const chatId = '123';
        const initialData = {
            id: chatId,
            title: 'Initial Title',
            messages: []
        };
        
        createChat(initialData);

        const updatedData = {
            title: 'Updated Title',
            messages: [{ id: '1', content: 'Hello', role: 'user' }]
        };
        
        updateChat(chatId, updatedData);
        
        const storeValue = get(chatStore);
        expect(storeValue.chats[0].title).toBe('Updated Title');
        expect(storeValue.chats[0].messages).toHaveLength(1);
    });

    test('deletes chat correctly', () => {
        const chatId = '123';
        const chatData = {
            id: chatId,
            title: 'Test Chat',
            messages: []
        };
        
        createChat(chatData);
        expect(get(chatStore).chats).toHaveLength(1);
        
        deleteChat(chatId);
        expect(get(chatStore).chats).toHaveLength(0);
    });

    test('handles concurrent modifications', async () => {
        const chatId = '123';
        const initialData = {
            id: chatId,
            title: 'Initial Title',
            messages: []
        };
        
        createChat(initialData);

        // Simulate concurrent updates
        await Promise.all([
            updateChat(chatId, { title: 'Update 1' }),
            updateChat(chatId, { title: 'Update 2' })
        ]);

        const storeValue = get(chatStore);
        expect(storeValue.chats).toHaveLength(1);
        expect(['Update 1', 'Update 2']).toContain(storeValue.chats[0].title);
    });
});
```

## Assessment Activities for Part 1

### Exercise 1: Test Suite Creation

Develop a complete test suite for a component:

1. Setup test environment
2. Write unit tests
3. Implement integration tests
4. Add snapshot tests
5. Create test documentation

### Exercise 2: Cross-platform Test Implementation

Create platform-specific test cases:

1. Desktop browser tests
2. Mobile browser tests
3. Touch input tests
4. Responsive design tests
5. Platform-specific feature tests

### Exercise 3: Test Coverage Analysis

Implement test coverage reporting:

1. Configure coverage tools
2. Create coverage reports
3. Analyze coverage gaps
4. Implement missing tests
5. Document coverage requirements

## Additional Resources

1. Testing Documentation
- Jest Documentation
- Cypress Guides
- Test Coverage Tools
- Testing Best Practices

2. Code Examples
- Test Suite Templates
- Coverage Configuration
- CI/CD Integration
- Platform-specific Tests

Continue to Part 2 for Development Workflow implementation.