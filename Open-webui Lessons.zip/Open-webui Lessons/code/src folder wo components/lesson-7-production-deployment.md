# Production Deployment Guide for Open WebUI

## Overview
This comprehensive guide covers the production deployment process for Open WebUI, including build optimization, deployment strategies, and production-specific configurations. The guide provides detailed instructions for both containerized and traditional deployments.

## 1. Build Process and Optimization

### 1.1 Frontend Build Configuration

The frontend build process utilizes Vite and SvelteKit for optimal production builds. Key configuration files are structured as follows:

```
frontend/
├── vite.config.ts           # Vite configuration
├── svelte.config.js         # SvelteKit configuration
├── tailwind.config.js       # Tailwind CSS configuration
└── package.json            # Dependencies and scripts
```

#### Vite Configuration for Production

```typescript
// vite.config.ts

import { defineConfig } from 'vite';
import { sveltekit } from '@sveltejs/kit/vite';

export default defineConfig({
    plugins: [sveltekit()],
    build: {
        target: 'es2020',
        minify: 'terser',
        terserOptions: {
            compress: {
                drop_console: true,
                dead_code: true
            }
        },
        rollupOptions: {
            output: {
                manualChunks: {
                    vendor: [
                        'lodash',
                        'marked',
                        'katex'
                    ]
                }
            }
        },
        cssCodeSplit: true,
        sourcemap: false
    },
    optimizeDeps: {
        include: ['lodash', 'marked', 'katex']
    }
});
```

#### SvelteKit Production Configuration

```javascript
// svelte.config.js

import adapter from '@sveltejs/adapter-node';
import preprocess from 'svelte-preprocess';

/** @type {import('@sveltejs/kit').Config} */
const config = {
    kit: {
        adapter: adapter({
            out: 'build',
            precompress: true,
            envPrefix: 'APP_'
        }),
        serviceWorker: {
            register: true,
            files: (filepath) => !/\.(?:png|jpg|gif|svg|mp3)$/.test(filepath)
        },
        csp: {
            mode: 'auto',
            directives: {
                'default-src': ['self'],
                'script-src': ['self', 'unsafe-inline'],
                'style-src': ['self', 'unsafe-inline'],
                'img-src': ['self', 'data:', 'blob:']
            }
        }
    },
    preprocess: preprocess({
        postcss: true,
        typescript: true
    })
};

export default config;
```

### 1.2 Backend Build Process

The backend build process involves Python package compilation and dependency management:

```
backend/
├── pyproject.toml          # Project metadata and dependencies
├── setup.py               # Build configuration
└── requirements.txt       # Production dependencies
```

#### Production Requirements Configuration

```python
# requirements.txt

fastapi==0.68.1
uvicorn[standard]==0.15.0
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
sqlalchemy==1.4.23
alembic==1.7.1
psycopg2-binary==2.9.1
redis==4.0.1
gunicorn==20.1.0
```

#### WSGI Production Configuration

```python
# gunicorn.conf.py

import multiprocessing

# Server socket configuration
bind = "0.0.0.0:8000"
backlog = 2048

# Worker processes
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "uvicorn.workers.UvicornWorker"
worker_connections = 1000
timeout = 30
keepalive = 2

# Process naming
proc_name = "open-webui"
pythonpath = "backend"

# Logging
accesslog = "-"
errorlog = "-"
loglevel = "info"

# SSL Configuration
keyfile = "/etc/ssl/private/open-webui.key"
certfile = "/etc/ssl/certs/open-webui.crt"
```

## 2. Deployment Strategies

### 2.1 Docker Container Deployment

The application is containerized using multi-stage builds for optimal image size:

```dockerfile
# Dockerfile

# Build stage
FROM node:16-alpine AS frontend-builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

# Backend build stage
FROM python:3.9-slim AS backend-builder
WORKDIR /app
COPY requirements.txt .
RUN pip wheel --no-cache-dir --no-deps --wheel-dir /app/wheels -r requirements.txt

# Final stage
FROM python:3.9-slim
WORKDIR /app

# Copy wheels and install dependencies
COPY --from=backend-builder /app/wheels /wheels
RUN pip install --no-cache /wheels/*

# Copy application code
COPY --from=frontend-builder /app/build ./frontend/build
COPY backend .

# Runtime configuration
ENV PORT=8000
EXPOSE 8000

CMD ["gunicorn", "open_webui.main:app"]
```

Docker Compose configuration for production:

```yaml
# docker-compose.production.yml

version: '3.8'

services:
  web:
    build: .
    restart: always
    environment:
      - DATABASE_URL=postgresql://user:password@db:5432/openwebui
      - REDIS_URL=redis://cache:6379/0
      - SECRET_KEY=${SECRET_KEY}
    ports:
      - "443:8000"
    depends_on:
      - db
      - cache
    volumes:
      - ./ssl:/etc/ssl
      - static_volume:/app/static
    networks:
      - webui_net

  db:
    image: postgres:13
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
      - POSTGRES_DB=openwebui
    networks:
      - webui_net

  cache:
    image: redis:6-alpine
    volumes:
      - redis_data:/data
    networks:
      - webui_net

volumes:
  postgres_data:
  redis_data:
  static_volume:

networks:
  webui_net:
    driver: bridge
```

### 2.2 Kubernetes Deployment

For scalable deployments, Kubernetes configurations are provided:

```yaml
# kubernetes/deployment.yml

apiVersion: apps/v1
kind: Deployment
metadata:
  name: open-webui
  namespace: production
spec:
  replicas: 3
  selector:
    matchLabels:
      app: open-webui
  template:
    metadata:
      labels:
        app: open-webui
    spec:
      containers:
        - name: open-webui
          image: open-webui:latest
          ports:
            - containerPort: 8000
          env:
            - name: DATABASE_URL
              valueFrom:
                secretKeyRef:
                  name: webui-secrets
                  key: database-url
          resources:
            requests:
              cpu: "500m"
              memory: "512Mi"
            limits:
              cpu: "1000m"
              memory: "1Gi"
          livenessProbe:
            httpGet:
              path: /health
              port: 8000
            initialDelaySeconds: 30
            periodSeconds: 10
          readinessProbe:
            httpGet:
              path: /ready
              port: 8000
            initialDelaySeconds: 5
            periodSeconds: 5
```

Service configuration:

```yaml
# kubernetes/service.yml

apiVersion: v1
kind: Service
metadata:
  name: open-webui
  namespace: production
spec:
  type: LoadBalancer
  ports:
    - port: 443
      targetPort: 8000
      protocol: TCP
  selector:
    app: open-webui
```

## 3. Production Optimization

### 3.1 Static Asset Optimization

Implementation of asset optimization strategies:

```typescript
// frontend/src/lib/utils/asset-loader.ts

export const optimizeImage = async (src: string, width: number): Promise<string> => {
    if (!src) return '';
    
    const imageService = new ImageService({
        quality: 80,
        format: 'webp',
        progressive: true
    });
    
    return await imageService.optimize(src, {
        width,
        height: 0,
        fit: 'contain'
    });
};

export const lazyLoadImage = (
    element: HTMLImageElement,
    src: string,
    options = { threshold: 0.1 }
): void => {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                element.src = src;
                observer.disconnect();
            }
        });
    }, options);
    
    observer.observe(element);
};
```

### 3.2 Caching Strategy

Implementation of a multi-layer caching strategy:

```typescript
// frontend/src/lib/utils/cache.ts

export class CacheManager {
    private static instance: CacheManager;
    private cache: Map<string, CacheEntry>;
    
    private constructor() {
        this.cache = new Map();
    }
    
    static getInstance(): CacheManager {
        if (!CacheManager.instance) {
            CacheManager.instance = new CacheManager();
        }
        return CacheManager.instance;
    }
    
    async get<T>(key: string): Promise<T | null> {
        const entry = this.cache.get(key);
        if (!entry) return null;
        
        if (this.isExpired(entry)) {
            this.cache.delete(key);
            return null;
        }
        
        return entry.value as T;
    }
    
    set(key: string, value: any, ttl: number = 3600): void {
        this.cache.set(key, {
            value,
            timestamp: Date.now(),
            ttl
        });
    }
    
    private isExpired(entry: CacheEntry): boolean {
        return Date.now() - entry.timestamp > entry.ttl * 1000;
    }
}
```

### 3.3 Database Optimization

Implementation of database optimization strategies:

```python
# backend/open_webui/database.py

from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker
from sqlalchemy.engine import Engine

# Configure connection pooling
engine = create_engine(
    DATABASE_URL,
    pool_size=20,
    max_overflow=10,
    pool_timeout=30,
    pool_recycle=1800
)

# Enable foreign key support for SQLite
@event.listens_for(Engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()

# Create session factory
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
    expire_on_commit=False
)

# Database optimization functions
async def optimize_queries():
    """Analyze and optimize database queries."""
    session = SessionLocal()
    try:
        # Analyze tables
        await session.execute("ANALYZE VERBOSE")
        
        # Update statistics
        await session.execute("VACUUM ANALYZE")
        
        # Reindex tables
        await session.execute("REINDEX DATABASE openwebui")
    finally:
        session.close()
```

## 4. Environment-Specific Configurations

### 4.1 Production Environment Variables

```bash
# .env.production

NODE_ENV=production
APP_ENV=production
PORT=443
DATABASE_URL=postgresql://user:password@localhost:5432/openwebui
REDIS_URL=redis://localhost:6379/0
SECRET_KEY=your-secret-key
JWT_SECRET=your-jwt-secret
CORS_ORIGINS=https://your-domain.com
SSL_CERT_PATH=/etc/ssl/certs/open-webui.crt
SSL_KEY_PATH=/etc/ssl/private/open-webui.key
```

### 4.2 Nginx Production Configuration

```nginx
# nginx.conf

user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    
    # Security headers
    add_header X-Frame-Options "DENY" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Content-Security-Policy "default-src 'self';" always;
    
    # SSL configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # Proxy settings
    proxy_cache_path /var/cache/nginx levels=1:2 keys_zone=STATIC:10m inactive=7d use_temp_path=off;
    
    upstream open_webui {
        server 127.0.0.1:8000;
    }
    
    server {
        listen 443 ssl http2;
        server_name your-domain.com;
        
        ssl_certificate /etc/ssl/certs/open-webui.crt;
        ssl_certificate_key /etc/ssl/private/open-webui.key;
        
        location / {
            proxy_pass http://open_webui;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_cache_bypass $http_upgrade;
            
            # Cache static assets
            location /static/ {
                proxy_cache STATIC;
                proxy_ignore_headers Cache-Control;
                proxy_cache_use_stale error timeout http_500 http_502 http_503 http_504;
                proxy_cache_valid 200 60m;
                proxy_cache_valid 404 1m;
                proxy_cache_lock on;
            }
        }
    }
}
```

This deployment guide provides a comprehensive approach to deploying Open WebUI in a production environment. The next artifact will cover monitoring and maintenance strategies. Would you like me to proceed with creating the final artifact?