# Lesson 5: Advanced Features and Utilities

## Overview and Learning Objectives

This comprehensive 6-hour lesson focuses on advanced features and utility functions within Open WebUI. The lesson emphasizes practical implementation while ensuring cross-platform compatibility. Throughout the session, developers will learn to build robust, scalable features that enhance the application's capabilities across different platforms and use cases.

By the end of this lesson, developers will be able to:
- Build and implement core utility functions for common operations
- Create comprehensive internationalization systems
- Handle complex file processing operations
- Implement advanced rendering systems
- Develop platform-aware feature detection systems

## Section 1: Core Utility Functions (90 minutes)

### Understanding the Open WebUI Utility Structure

The Open WebUI maintains a well-organized utility structure in the `src/lib/utils` directory:

```
src/lib/utils/
├── index.ts                  # Main utility exports
├── _template_old.ts         # Legacy template utilities
├── characters/              # Character handling utilities
│   └── index.ts
├── marked/                  # Markdown processing
│   ├── extension.ts         # Custom extensions
│   └── katex-extension.ts   # Math rendering
├── rag/                     # RAG-related utilities
│   └── index.ts
├── transitions/             # Animation utilities
│   └── index.ts
└── workers/                 # Web worker utilities
    └── pyodide.worker.ts    # Python integration
```

### Core Helper Functions

Let's examine key utility implementations from index.ts:

```typescript
/**
 * Replaces template tokens with actual values
 * @param content Original content
 * @param char Character name
 * @param user User name
 */
export const replaceTokens = (content: string, char?: string, user?: string) => {
    const charToken = /{{char}}/gi;
    const userToken = /{{user}}/gi;
    
    if (char) content = content.replace(charToken, char);
    if (user) content = content.replace(userToken, user);
    
    return content;
};

/**
 * Converts message arrays to hierarchical history
 * @param messages Array of chat messages
 */
export const convertMessagesToHistory = (messages: Message[]) => {
    const history = {
        messages: {},
        currentId: null
    };

    let parentMessageId = null;
    let messageId = null;

    for (const message of messages) {
        messageId = generateUUID();
        
        if (parentMessageId !== null) {
            history.messages[parentMessageId].childrenIds.push(messageId);
        }
        
        history.messages[messageId] = {
            ...message,
            id: messageId,
            parentId: parentMessageId,
            childrenIds: []
        };
        
        parentMessageId = messageId;
    }
    
    history.currentId = messageId;
    return history;
};
```

### Platform Utilities

Cross-platform utilities handle platform-specific needs:

```typescript
/**
 * Detects platform capabilities
 */
export const canvasPixelTest = () => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.height = 1;
    canvas.width = 1;
    
    const imageData = new ImageData(1, 1);
    const pixelValues = imageData.data;
    
    // Generate test data
    for (let i = 0; i < imageData.data.length; i += 1) {
        if (i % 4 !== 3) {
            pixelValues[i] = Math.floor(256 * Math.random());
        } else {
            pixelValues[i] = 255;
        }
    }
    
    ctx.putImageData(imageData, 0, 0);
    const p = ctx.getImageData(0, 0, 1, 1).data;
    
    // Validate pixel values
    for (let i = 0; i < p.length; i += 1) {
        if (p[i] !== pixelValues[i]) {
            console.log('Canvas pixel test failed');
            return false;
        }
    }
    
    return true;
};
```

## Section 2: Internationalization Implementation (90 minutes)

### I18n System Architecture

The internationalization system is built using i18next and custom extensions:

```typescript
// i18n/index.ts

import i18next from 'i18next';
import { writable } from 'svelte/store';
import type { i18n as i18nType } from 'i18next';

const createI18nStore = (i18n: i18nType) => {
    const i18nWritable = writable(i18n);
    
    // Handle i18n events
    i18n.on('initialized', () => i18nWritable.set(i18n));
    i18n.on('loaded', () => i18nWritable.set(i18n));
    i18n.on('languageChanged', () => i18nWritable.set(i18n));
    
    return i18nWritable;
};

export const initI18n = (defaultLocale?: string) => {
    let detectionOrder = defaultLocale
        ? ['querystring', 'localStorage']
        : ['querystring', 'localStorage', 'navigator'];
        
    let fallbackDefaultLocale = defaultLocale ? [defaultLocale] : ['en-US'];

    i18next
        .use(resourcesToBackend(loadResource))
        .use(LanguageDetector)
        .init({
            detection: {
                order: detectionOrder,
                caches: ['localStorage'],
                lookupQuerystring: 'lang',
                lookupLocalStorage: 'locale'
            },
            fallbackLng: {
                default: fallbackDefaultLocale
            },
            interpolation: {
                escapeValue: false
            }
        });
};
```

### Language Resource Management

The system includes comprehensive language resource handling:

```typescript
interface LanguageResource {
    translation: {
        [key: string]: string | LanguageResource;
    };
}

const loadLanguageResource = async (language: string): Promise<LanguageResource> => {
    try {
        const module = await import(`./locales/${language}/translation.json`);
        return module.default;
    } catch (error) {
        console.error(`Failed to load language resource: ${language}`, error);
        return { translation: {} };
    }
};

export const addLanguageResource = async (language: string) => {
    const resource = await loadLanguageResource(language);
    i18next.addResourceBundle(language, 'translation', resource.translation);
};
```

## Section 3: File Processing Systems (90 minutes)

### File Upload Implementation

Comprehensive file handling system:

```typescript
/**
 * Handles file uploads with progress tracking
 * @param file File to upload
 * @param onProgress Progress callback
 */
export const uploadFile = async (
    file: File,
    onProgress?: (progress: number) => void
): Promise<UploadResult> => {
    const chunkSize = 1024 * 1024; // 1MB chunks
    const totalChunks = Math.ceil(file.size / chunkSize);
    let uploadedChunks = 0;
    
    for (let start = 0; start < file.size; start += chunkSize) {
        const chunk = file.slice(start, start + chunkSize);
        await uploadChunk(chunk, start);
        uploadedChunks++;
        
        if (onProgress) {
            onProgress((uploadedChunks / totalChunks) * 100);
        }
    }
    
    return finalizeUpload(file);
};
```

### File Processing and Conversion

Implementation of file processing capabilities:

```typescript
/**
 * Processes files based on type
 * @param file Input file
 * @param options Processing options
 */
export const processFile = async (
    file: File,
    options: ProcessingOptions
): Promise<ProcessedFile> => {
    const type = file.type;
    
    // Handle different file types
    switch (type) {
        case 'application/pdf':
            return processPDFFile(file, options);
            
        case 'image/png':
        case 'image/jpeg':
            return processImageFile(file, options);
            
        case 'text/csv':
            return processCSVFile(file, options);
            
        default:
            throw new Error(`Unsupported file type: ${type}`);
    }
};
```

## Section 4: Rendering Systems (90 minutes)

### Markdown Processing

Implementation of the markdown rendering system:

```typescript
// utils/marked/extension.ts

import { marked } from 'marked';
import hljs from 'highlight.js';

export const configureMarked = () => {
    // Configure marked options
    marked.setOptions({
        highlight: (code, lang) => {
            if (lang && hljs.getLanguage(lang)) {
                return hljs.highlight(code, { language: lang }).value;
            }
            return code;
        },
        breaks: true,
        gfm: true
    });
    
    // Add custom extensions
    marked.use({
        extensions: [{
            name: 'custom-block',
            level: 'block',
            start(src) {
                return src.match(/^::: /)?.index;
            },
            tokenizer(src) {
                const rule = /^::: (\w+)\n([\s\S]+?)\n:::/;
                const match = rule.exec(src);
                if (match) {
                    return {
                        type: 'custom-block',
                        raw: match[0],
                        blockType: match[1],
                        content: match[2]
                    };
                }
            },
            renderer(token) {
                return `<div class="custom-block ${token.blockType}">
                    ${marked.parse(token.content)}
                </div>`;
            }
        }]
    });
};
```

### LaTeX Rendering System

Implementation of mathematical expression rendering:

```typescript
// utils/marked/katex-extension.ts

import katex from 'katex';

const createKatexRenderer = () => ({
    extensions: [{
        name: 'katex',
        level: 'inline',
        start(src) {
            return src.match(/\$/)?.index;
        },
        tokenizer(src) {
            const rule = /^\$+([^$\n]+?)\$+/;
            const match = rule.exec(src);
            if (match) {
                return {
                    type: 'katex',
                    raw: match[0],
                    text: match[1].trim(),
                    displayMode: match[0].startsWith('$$')
                };
            }
        },
        renderer(token) {
            try {
                return katex.renderToString(token.text, {
                    throwOnError: false,
                    displayMode: token.displayMode
                });
            } catch (error) {
                console.error('KaTeX rendering error:', error);
                return token.raw;
            }
        }
    }]
});
```

## Hands-on Exercises

### Exercise 1: Implementing Language Support

Create a complete internationalization system that includes:

1. Language Detection:
```typescript
const detectUserLanguage = () => {
    // Get browser language
    const browserLang = navigator.language;
    
    // Get system language
    const systemLang = Intl.DateTimeFormat().resolvedOptions().locale;
    
    // Find best match among supported languages
    return findBestMatch([browserLang, systemLang], supportedLocales);
};
```

2. Language Switching:
```typescript
const switchLanguage = async (language: string) => {
    // Load language resources
    await loadLanguageResource(language);
    
    // Update application locale
    await i18next.changeLanguage(language);
    
    // Update document direction for RTL support
    updateDocumentDirection(language);
    
    // Persist language preference
    localStorage.setItem('locale', language);
};
```

### Exercise 2: Building File Processing System

Implement a comprehensive file processing system:

1. Chunk Upload Implementation:
```typescript
const uploadChunk = async (
    chunk: Blob,
    start: number,
    file: File
): Promise<void> => {
    const formData = new FormData();
    formData.append('chunk', chunk);
    formData.append('start', start.toString());
    formData.append('filename', file.name);
    
    await fetch('/api/upload/chunk', {
        method: 'POST',
        body: formData
    });
};
```

2. File Conversion System:
```typescript
const convertFile = async (
    file: File,
    targetFormat: string
): Promise<File> => {
    const converter = getConverter(file.type, targetFormat);
    const converted = await converter.convert(file);
    
    return new File(
        [converted],
        file.name.replace(/\.[^/.]+$/, `.${targetFormat}`),
        { type: getMimeType(targetFormat) }
    );
};
```

### Exercise 3: Implementing Feature Detection

Create a comprehensive feature detection system:

1. Browser Capability Detection:
```typescript
const detectBrowserCapabilities = () => {
    return {
        webGL: detectWebGLSupport(),
        webAssembly: typeof WebAssembly === 'object',
        serviceWorker: 'serviceWorker' in navigator,
        webSocket: 'WebSocket' in window,
        webRTC: 'RTCPeerConnection' in window,
        storage: detectStorageSupport()
    };
};
```

2. Progressive Enhancement:
```typescript
const enhanceFeatures = (capabilities) => {
    if (capabilities.webGL) {
        enableWebGLFeatures();
    }
    
    if (capabilities.webAssembly) {
        enableWasmFeatures();
    }
    
    if (capabilities.serviceWorker) {
        registerServiceWorker();
    }
};
```

## Assessment Criteria

Developers will be evaluated based on:

1. Code Quality
- Modularity and reusability
- Error handling implementation
- Performance optimization
- Cross-platform compatibility
- Documentation quality

2. Feature Implementation
- Internationalization support
- File processing capabilities
- Rendering system functionality
- Feature detection accuracy
- Progressive enhancement

3. Best Practices
- Security considerations
- Accessibility implementation
- Performance optimization
- Error handling
- Documentation

## Additional Resources

1. Documentation
- i18next Documentation: https://www.i18next.com/
- File API Reference: https://developer.mozilla.org/en-US/docs/Web/API/File
- KaTeX Documentation: https://katex.org/docs/api.html
- Marked Documentation: https://marked.js.org/

2. Code Examples
- Utility Implementation Examples
- I18n Setup Templates
- File Processing Patterns
- Feature Detection Examples

## Next Steps

After completing this lesson, developers should:

1. Review implemented utilities
2. Test across different platforms
3. Document platform-specific considerations
4. Contribute to the shared utility library
5. Prepare for the next lesson on Testing and Development Workflow

This lesson provides a comprehensive understanding of advanced features and utilities in Open WebUI, preparing developers for implementing complex functionality while maintaining cross-platform compatibility.