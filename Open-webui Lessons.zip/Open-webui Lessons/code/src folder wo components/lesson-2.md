# Lesson 2: Core Application Components

## Duration: 6 Hours

## Overview
This lesson provides an in-depth exploration of Open WebUI's core application components, focusing on the main application files, routing system, and layout components. Students will gain a thorough understanding of how these components work together to create a cohesive application structure while maintaining cross-platform compatibility.

## Main Application Files

### Understanding app.html
The `app.html` file serves as the application's HTML template and entry point. Let's examine its structure and key features:

```html
<!-- src/app.html -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <link rel="icon" href="%sveltekit.assets%/favicon.png" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#171717" />
        <meta name="robots" content="noindex,nofollow" />
        <meta name="description" content="Open WebUI" />
        %sveltekit.head%
    </head>
    <body>
        <div style="display: contents">%sveltekit.body%</div>
        
        <!-- Splash Screen Implementation -->
        <div id="splash-screen">
            <!-- Splash screen content -->
        </div>
    </body>
</html>
```

Key features of app.html:
1. Dynamic Asset Handling: Uses `%sveltekit.assets%` for proper asset path resolution
2. Meta Configuration: Includes essential meta tags for SEO and mobile optimization
3. SvelteKit Integration: Utilizes `%sveltekit.head%` and `%sveltekit.body%` for dynamic content injection
4. Splash Screen: Implements a loading screen for better user experience

### CSS Organization
The application's CSS is organized through multiple files and approaches:

1. Global Styles (app.css):
```css
/* src/app.css */
@font-face {
    font-family: 'Inter';
    src: url('/assets/fonts/Inter-Variable.ttf');
    font-display: swap;
}

/* Global Styles */
html {
    word-break: break-word;
}

/* Utility Classes */
.markdown-prose {
    @apply prose dark:prose-invert prose-p:my-0 prose-img:my-1;
}

/* Component-specific styles */
.scrollbar-hidden::-webkit-scrollbar {
    display: none;
}
```

2. Tailwind Configuration:
```javascript
// tailwind.config.js
module.exports = {
    content: ['./src/**/*.{html,js,svelte,ts}'],
    theme: {
        extend: {
            fontFamily: {
                primary: ['Inter', 'sans-serif']
            },
            colors: {
                primary: { /* color values */ },
                secondary: { /* color values */ }
            }
        }
    },
    plugins: [
        require('@tailwindcss/typography'),
        require('@tailwindcss/forms')
    ]
};
```

## Routing System

### SvelteKit Routing Patterns
The application uses SvelteKit's file-based routing system with a structured approach:

```
src/routes/
├── +layout.svelte          # Root layout
├── +layout.js             # Root layout logic
├── +page.svelte           # Root page
├── (app)/                 # App routes
│   ├── +layout.svelte     # App layout
│   ├── +page.svelte      # App home page
│   ├── admin/            # Admin section
│   │   ├── +layout.svelte
│   │   ├── +page.svelte
│   │   └── settings/
│   └── workspace/        # Workspace section
├── auth/                  # Authentication routes
│   └── +page.svelte
└── error/                # Error handling
    └── +page.svelte
```

Example of a route implementation:
```typescript
// src/routes/(app)/workspace/+page.svelte
<script lang="ts">
    import { onMount } from 'svelte';
    import { page } from '$app/stores';
    import WorkspaceLayout from '$lib/components/workspace/Layout.svelte';
    
    onMount(async () => {
        // Initialize workspace
    });
</script>

<WorkspaceLayout>
    <div class="workspace-container">
        <!-- Workspace content -->
    </div>
</WorkspaceLayout>
```

### Dynamic Route Handling
The application implements dynamic routes for flexible content handling:

1. Parameter Routes:
```typescript
// src/routes/(app)/c/[id]/+page.svelte
<script lang="ts">
    import { page } from '$app/stores';
    import Chat from '$lib/components/chat/Chat.svelte';
    
    const chatId = $page.params.id;
</script>

<Chat {chatId} />
```

2. Route Parameters Validation:
```typescript
// src/lib/utils/route.ts
export const validateRouteParams = (params: RouteParams): boolean => {
    const { id } = params;
    return typeof id === 'string' && id.length > 0;
};
```

## Layout Components

### Base Layout System
The application uses a hierarchical layout system:

1. Root Layout (+layout.svelte):
```svelte
<!-- src/routes/+layout.svelte -->
<script lang="ts">
    import { onMount } from 'svelte';
    import { initializeApp } from '$lib/utils/init';
    import '../app.css';
    
    onMount(async () => {
        await initializeApp();
    });
</script>

<slot />

<style>
    :global(html) {
        @apply h-full bg-white dark:bg-gray-900;
    }
</style>
```

2. App Layout:
```svelte
<!-- src/routes/(app)/+layout.svelte -->
<script lang="ts">
    import Sidebar from '$lib/components/layout/Sidebar.svelte';
    import Navbar from '$lib/components/layout/Navbar.svelte';
    
    export let data;
</script>

<div class="app-container">
    <Sidebar />
    <main class="main-content">
        <Navbar />
        <slot />
    </main>
</div>
```

### Responsive Design Implementation
The application implements a comprehensive responsive design system:

1. Breakpoint Management:
```typescript
// src/lib/utils/responsive.ts
export const BREAKPOINTS = {
    sm: 640,
    md: 768,
    lg: 1024,
    xl: 1280
} as const;

export const useBreakpoint = () => {
    const mobile = writable(false);
    
    onMount(() => {
        const checkMobile = () => {
            mobile.set(window.innerWidth < BREAKPOINTS.md);
        };
        
        window.addEventListener('resize', checkMobile);
        checkMobile();
        
        return () => window.removeEventListener('resize', checkMobile);
    });
    
    return mobile;
};
```

2. Responsive Component Example:
```svelte
<!-- src/lib/components/layout/Sidebar.svelte -->
<script lang="ts">
    import { mobile } from '$lib/stores';
    
    $: sidebarClass = $mobile ? 'fixed inset-0 z-40' : 'relative flex-shrink-0';
</script>

<nav class={sidebarClass}>
    <!-- Sidebar content -->
</nav>
```

## Application Initialization

### Bootstrap Process
The application follows a structured initialization process:

```typescript
// src/lib/utils/init.ts
export const initializeApp = async () => {
    // 1. Load Configuration
    const config = await loadConfig();
    
    // 2. Initialize Stores
    initializeStores(config);
    
    // 3. Setup Authentication
    await setupAuth();
    
    // 4. Initialize Services
    await initializeServices();
    
    // 5. Setup WebSocket
    setupWebSocket();
};
```

### Asset Loading Strategy
The application implements efficient asset loading:

1. Font Loading:
```typescript
// src/lib/utils/fonts.ts
export const loadFonts = async () => {
    const fonts = [
        { family: 'Inter', url: '/assets/fonts/Inter-Variable.ttf' },
        { family: 'Archivo', url: '/assets/fonts/Archivo-Variable.ttf' }
    ];
    
    await Promise.all(
        fonts.map(font => 
            new FontFace(font.family, `url(${font.url})`).load()
        )
    );
};
```

2. Image Loading:
```typescript
// src/lib/utils/images.ts
export const preloadCriticalImages = async () => {
    const criticalImages = [
        '/static/logo.png',
        '/static/favicon.png'
    ];
    
    await Promise.all(
        criticalImages.map(src => {
            const img = new Image();
            img.src = src;
            return new Promise((resolve) => {
                img.onload = resolve;
            });
        })
    );
};
```

## Hands-on Exercises

### Exercise 1: Creating a Layout System
**Objective**: Implement a flexible layout system with responsive design.

Steps:
1. Create a base layout component
2. Implement responsive sidebar
3. Add navigation components
4. Handle different screen sizes

Example implementation:
```svelte
<!-- Layout.svelte -->
<script lang="ts">
    import { mobile } from '$lib/stores';
    import Sidebar from './Sidebar.svelte';
    import Navbar from './Navbar.svelte';
    
    export let showSidebar = true;
</script>

<div class="layout-container">
    {#if showSidebar}
        <Sidebar class={$mobile ? 'floating' : 'fixed'} />
    {/if}
    
    <main class="main-content">
        <Navbar />
        <slot />
    </main>
</div>

<style lang="postcss">
    .layout-container {
        @apply flex h-screen bg-white dark:bg-gray-900;
    }
    
    .main-content {
        @apply flex-1 overflow-auto;
    }
</style>
```

### Exercise 2: Implementing Dynamic Routes
**Objective**: Create a dynamic routing system with parameter handling.

Steps:
1. Create dynamic route components
2. Implement parameter validation
3. Add loading states
4. Handle route errors

Example implementation:
```typescript
// src/routes/(app)/item/[id]/+page.ts
import { error } from '@sveltejs/kit';
import type { PageLoad } from './$types';

export const load: PageLoad = async ({ params, fetch }) => {
    try {
        const response = await fetch(`/api/items/${params.id}`);
        if (!response.ok) throw error(404, 'Item not found');
        
        return {
            item: await response.json()
        };
    } catch (e) {
        throw error(500, 'Failed to load item');
    }
};
```

### Exercise 3: Building Platform-Specific Features
**Objective**: Implement features that adapt to different platforms.

Steps:
1. Create platform detection utilities
2. Implement platform-specific styles
3. Add conditional feature rendering
4. Test across different platforms

Example implementation:
```typescript
// src/lib/utils/platform.ts
export const getPlatform = () => {
    const userAgent = navigator.userAgent.toLowerCase();
    
    return {
        isMobile: /mobile|android|ios/.test(userAgent),
        isTablet: /ipad|tablet/.test(userAgent),
        isDesktop: !(/mobile|android|ios|ipad|tablet/.test(userAgent)),
        isSafari: /safari/.test(userAgent) && !/chrome/.test(userAgent),
        isIOS: /iphone|ipad|ipod/.test(userAgent)
    };
};
```

## Assessment
Students should be able to:
1. Explain the application's routing and layout system
2. Implement responsive layouts
3. Create dynamic routes with parameter handling
4. Build platform-specific features
5. Understand the initialization process

## Additional Resources

### Documentation
- [SvelteKit Routing Documentation](https://kit.svelte.dev/docs/routing)
- [Responsive Design Guide](https://tailwindcss.com/docs/responsive-design)
- [Cross-Platform Development Best Practices](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps)

### Code Examples
- Complete layout implementations
- Route handling patterns
- Platform-specific adaptations

### Next Steps
- Review the completed exercises
- Explore the application's routing system
- Prepare for Lesson 3: State Management and API Integration
