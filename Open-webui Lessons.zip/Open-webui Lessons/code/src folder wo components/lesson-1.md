# Lesson 1: Foundation and Project Structure

## Duration: 4 Hours

## Overview
This foundational lesson establishes the critical groundwork for understanding the Open WebUI architecture. The lesson is structured to provide both theoretical knowledge and hands-on experience with the project's structure, build system, and core technologies. By the end of this lesson, students will have a comprehensive understanding of how the various components interact and how to set up their development environment for cross-platform development.

## Project Architecture Overview

### SvelteKit Application Structure
The Open WebUI project follows a modern SvelteKit application structure, which provides a robust foundation for building scalable web applications. Let's examine the core directory structure:

```
/
├── src/                    # Main source code directory
│   ├── app.html           # Base HTML template
│   ├── app.css            # Global styles
│   ├── routes/            # SvelteKit routes
│   │   ├── +layout.svelte # Root layout
│   │   ├── +page.svelte   # Root page
│   │   └── (app)/        # App routes
│   ├── lib/               # Shared library code
│   │   ├── components/    # Reusable components
│   │   ├── stores/        # State management
│   │   └── utils/         # Utility functions
│   └── static/            # Static assets
├── backend/               # Backend Python code
└── tests/                 # Test files
```

The project uses a clear separation of concerns between frontend and backend components. The frontend, built with SvelteKit, resides in the `src` directory, while the backend Python code is contained in the `backend` directory.

### Frontend-Backend Communication Pattern
The application implements a modern client-server architecture with several key communication patterns:

1. REST API Communication
   - The frontend communicates with the backend through a well-defined REST API
   - API endpoints are organized in the `src/lib/apis` directory
   - All API calls include proper error handling and type safety

2. WebSocket Communication
   - Real-time updates are handled through WebSocket connections
   - Socket.io is used for reliable bi-directional communication
   - Connection management is centralized in the socket store

Example of API structure:
```typescript
// src/lib/apis/index.ts
export const getModels = async (token: string = '') => {
    const res = await fetch(`${WEBUI_BASE_URL}/api/models`, {
        method: 'GET',
        headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            ...(token && { authorization: `Bearer ${token}` })
        }
    });
    // Error handling and response processing
    return res;
};
```

## Development Environment Setup

### Local Development Configuration
To begin development, you'll need to set up your local environment with the following tools:

1. Node.js (LTS version)
   - Required for running the frontend development server
   - Manages package dependencies through npm
   - Enables build process through Vite

2. Python 3.8+
   - Powers the backend server
   - Handles ML model interactions
   - Manages file processing and data analysis

3. Development Tools
   - VS Code with recommended extensions:
     - Svelte for VS Code
     - ESLint
     - Prettier
     - Python
   - Git for version control
   - Docker for containerized development

### Setting Up the Development Environment
Follow these steps to set up your development environment:

1. Clone the repository:
```bash
git clone https://github.com/open-webui/open-webui.git
cd open-webui
```

2. Install frontend dependencies:
```bash
npm install
```

3. Install backend dependencies:
```bash
cd backend
pip install -r requirements.txt
```

4. Configure environment variables:
```bash
cp .env.example .env
```

5. Start the development servers:
```bash
# Terminal 1 - Frontend
npm run dev

# Terminal 2 - Backend
cd backend
python -m open_webui
```

## Core Technology Stack

### SvelteKit Deep Dive
SvelteKit serves as the foundation of our frontend architecture. Key concepts include:

1. Routing System
   - File-based routing in the `routes` directory
   - Dynamic route parameters with `[param]` syntax
   - Layout components for shared UI elements

2. Component Structure
   - Components are written in `.svelte` files
   - Combine HTML, CSS, and JavaScript in single files
   - Reactive declarations and stores for state management

Example of a basic SvelteKit component:
```svelte
<script lang="ts">
    import { onMount } from 'svelte';
    import { user } from '$lib/stores';
    
    let data = [];
    
    onMount(async () => {
        // Component initialization
    });
</script>

<div class="container">
    {#each data as item}
        <div class="item">{item.name}</div>
    {/each}
</div>

<style>
    .container {
        @apply p-4;
    }
</style>
```

### TypeScript Implementation
The project uses TypeScript for type safety and better development experience:

1. Type Definitions
   - Located in `src/lib/types`
   - Shared interfaces and type definitions
   - Strict type checking enabled

2. Configuration
   - TypeScript configuration in `tsconfig.json`
   - Path aliases for clean imports
   - Strict mode enabled for better type safety

### Tailwind CSS Architecture
The styling system is built on Tailwind CSS:

1. Configuration
   - Custom configuration in `tailwind.config.js`
   - Extended theme settings
   - Custom plugins and utilities

2. Usage Patterns
   - Utility-first approach
   - Component-specific styles
   - Responsive design utilities

Example of Tailwind configuration:
```javascript
// tailwind.config.js
module.exports = {
    content: ['./src/**/*.{html,js,svelte,ts}'],
    theme: {
        extend: {
            colors: {
                primary: {...},
                secondary: {...}
            }
        }
    },
    plugins: []
};
```

## Hands-on Exercises

### Exercise 1: Setting Up Development Environment
**Objective**: Create a complete development environment setup.

Steps:
1. Install all required tools and dependencies
2. Configure VS Code with recommended extensions
3. Set up local environment variables
4. Start development servers
5. Verify the setup by accessing the application

### Exercise 2: Creating a Basic SvelteKit Component
**Objective**: Build a reusable component with TypeScript and Tailwind CSS.

Create a simple user card component:
```svelte
<script lang="ts">
    interface User {
        name: string;
        email: string;
        avatar: string;
    }
    
    export let user: User;
</script>

<div class="bg-white rounded-lg shadow p-4">
    <img src={user.avatar} alt={user.name} class="w-16 h-16 rounded-full" />
    <h2 class="text-xl font-bold">{user.name}</h2>
    <p class="text-gray-600">{user.email}</p>
</div>
```

### Exercise 3: Implementing Cross-platform Configurations
**Objective**: Create platform-specific configurations and implementations.

Steps:
1. Implement platform detection
2. Create platform-specific styles
3. Handle platform-specific features
4. Test on different platforms

## Assessment
By the end of this lesson, students should be able to:

1. Explain the Open WebUI project structure and architecture
2. Set up and configure a complete development environment
3. Create basic SvelteKit components with TypeScript and Tailwind CSS
4. Understand how frontend and backend communicate
5. Implement platform-specific configurations

## Additional Resources

### Documentation
- [SvelteKit Documentation](https://kit.svelte.dev/docs)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)

### Code Examples
- Project repository examples
- Sample components
- Configuration templates

### Next Steps
- Review the exercises
- Explore the codebase
- Prepare for Lesson 2: Core Application Components
