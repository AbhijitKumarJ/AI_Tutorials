# Lesson 3: State Management and API Integration

## Duration: 8 Hours

## Overview
This advanced lesson covers state management patterns and API integration in Open WebUI, focusing on data flow and communication between frontend and backend services. Students will learn how to implement robust state management solutions and integrate various API services while maintaining clean, maintainable code.

## State Management

### Svelte Store Implementation
The application uses Svelte's built-in store system with custom implementations for different state management needs. Let's examine the core store structure:

```typescript
// src/lib/stores/index.ts
import { writable } from 'svelte/store';
import type { Writable } from 'svelte/store';
import type { GlobalModelConfig, ModelConfig } from '$lib/apis';
import type { Banner } from '$lib/types';

// Backend State
export const WEBUI_NAME = writable(APP_NAME);
export const config: Writable<Config | undefined> = writable(undefined);
export const user: Writable<SessionUser | undefined> = writable(undefined);

// Frontend State
export const mobile = writable(false);
export const theme = writable('system');
export const chatId = writable('');
export const chatTitle = writable('');
export const models: Writable<Model[]> = writable([]);

// UI State
export const showSidebar = writable(false);
export const showSettings = writable(false);
export const showControls = writable(false);
```

### Custom Store Creation
Creating specialized stores for complex state management:

```typescript
// src/lib/stores/chat.ts
import { derived, writable } from 'svelte/store';

function createChatStore() {
    const { subscribe, set, update } = writable({
        messages: [],
        currentId: null,
        isLoading: false
    });

    return {
        subscribe,
        addMessage: (message) => update(state => ({
            ...state,
            messages: [...state.messages, message]
        })),
        setLoading: (loading) => update(state => ({
            ...state,
            isLoading: loading
        })),
        reset: () => set({
            messages: [],
            currentId: null,
            isLoading: false
        })
    };
}

export const chatStore = createChatStore();
```

### State Management Patterns

#### Global State Pattern
Implementation of global application state:

```typescript
// src/lib/stores/global.ts
interface GlobalState {
    isAuthenticated: boolean;
    currentUser: User | null;
    settings: AppSettings;
}

function createGlobalStore() {
    const { subscribe, set, update } = writable<GlobalState>({
        isAuthenticated: false,
        currentUser: null,
        settings: defaultSettings
    });

    return {
        subscribe,
        login: (user: User) => update(state => ({
            ...state,
            isAuthenticated: true,
            currentUser: user
        })),
        logout: () => update(state => ({
            ...state,
            isAuthenticated: false,
            currentUser: null
        })),
        updateSettings: (settings: Partial<AppSettings>) => update(state => ({
            ...state,
            settings: { ...state.settings, ...settings }
        }))
    };
}

export const globalStore = createGlobalStore();
```

## API Integration

### REST API Implementation
The application implements a comprehensive API integration system:

```typescript
// src/lib/apis/base.ts
export class APIError extends Error {
    constructor(public status: number, message: string) {
        super(message);
        this.name = 'APIError';
    }
}

export async function fetchWithAuth(
    endpoint: string,
    options: RequestInit = {}
): Promise<Response> {
    const token = localStorage.getItem('token');
    const headers = new Headers(options.headers);
    
    if (token) {
        headers.set('Authorization', `Bearer ${token}`);
    }
    
    const response = await fetch(`${WEBUI_BASE_URL}${endpoint}`, {
        ...options,
        headers
    });
    
    if (!response.ok) {
        const error = await response.json();
        throw new APIError(response.status, error.message);
    }
    
    return response;
}
```

### API Modules Organization
Organization of different API modules:

```typescript
// src/lib/apis/models/index.ts
import { fetchWithAuth } from '../base';

export const getModels = async (token: string = '') => {
    try {
        const response = await fetchWithAuth('/api/models', {
            method: 'GET'
        });
        return await response.json();
    } catch (error) {
        console.error('Error fetching models:', error);
        throw error;
    }
};

export const updateModel = async (token: string, id: string, model: object) => {
    try {
        const response = await fetchWithAuth(`/api/models/${id}`, {
            method: 'POST',
            body: JSON.stringify(model)
        });
        return await response.json();
    } catch (error) {
        console.error('Error updating model:', error);
        throw error;
    }
};
```

### WebSocket Integration
Implementation of real-time communication:

```typescript
// src/lib/socket/index.ts
import { io } from 'socket.io-client';
import { writable } from 'svelte/store';

export const createSocketStore = () => {
    const { subscribe, set, update } = writable({
        socket: null,
        connected: false,
        error: null
    });

    const connect = () => {
        const socket = io(WEBUI_BASE_URL, {
            path: '/ws/socket.io',
            auth: { token: localStorage.token }
        });

        socket.on('connect', () => {
            update(state => ({ ...state, connected: true, error: null }));
        });

        socket.on('disconnect', (reason) => {
            update(state => ({ ...state, connected: false }));
        });

        socket.on('error', (error) => {
            update(state => ({ ...state, error }));
        });

        set({ socket, connected: socket.connected, error: null });
    };

    return {
        subscribe,
        connect,
        disconnect: () => {
            update(state => {
                state.socket?.disconnect();
                return { socket: null, connected: false, error: null };
            });
        }
    };
};

export const socketStore = createSocketStore();
```

### Error Handling Patterns
Implementing robust error handling:

```typescript
// src/lib/utils/error.ts
export class ApplicationError extends Error {
    constructor(
        message: string,
        public code: string,
        public details?: any
    ) {
        super(message);
        this.name = 'ApplicationError';
    }
}

export const handleApiError = (error: any) => {
    if (error instanceof APIError) {
        if (error.status === 401) {
            globalStore.logout();
            goto('/auth');
        }
        
        toast.error(error.message);
    } else {
        console.error('Unexpected error:', error);
        toast.error('An unexpected error occurred');
    }
};
```

## Data Persistence

### Local Storage Implementation
Managing persistent data:

```typescript
// src/lib/utils/storage.ts
export const storage = {
    set: (key: string, value: any) => {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (error) {
            console.error('Error saving to localStorage:', error);
        }
    },
    
    get: (key: string, defaultValue: any = null) => {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (error) {
            console.error('Error reading from localStorage:', error);
            return defaultValue;
        }
    },
    
    remove: (key: string) => {
        try {
            localStorage.removeItem(key);
        } catch (error) {
            console.error('Error removing from localStorage:', error);
        }
    }
};
```

### IndexedDB Usage
Implementing complex data storage:

```typescript
// src/lib/utils/db.ts
import { openDB, DBSchema, IDBPDatabase } from 'idb';

interface ChatDB extends DBSchema {
    chats: {
        key: string;
        value: {
            id: string;
            messages: Message[];
            timestamp: number;
        };
        indexes: { 'by-timestamp': number };
    };
}

export class ChatDatabase {
    private db: IDBPDatabase<ChatDB>;

    async init() {
        this.db = await openDB<ChatDB>('Chats', 1, {
            upgrade(db) {
                const store = db.createObjectStore('chats', {
                    keyPath: 'id'
                });
                store.createIndex('by-timestamp', 'timestamp');
            }
        });
    }

    async saveChat(chat: Chat) {
        await this.db.put('chats', {
            id: chat.id,
            messages: chat.messages,
            timestamp: Date.now()
        });
    }

    async getChat(id: string) {
        return await this.db.get('chats', id);
    }

    async getAllChats() {
        return await this.db.getAllFromIndex('chats', 'by-timestamp');
    }
}

export const chatDB = new ChatDatabase();
```

## Hands-on Exercises

### Exercise 1: Implementing Custom Store
Create a custom store for managing user preferences:

```typescript
// UserPreferencesStore.ts
interface UserPreferences {
    theme: 'light' | 'dark' | 'system';
    fontSize: number;
    language: string;
    notifications: boolean;
}

function createPreferencesStore() {
    const { subscribe, set, update } = writable<UserPreferences>({
        theme: 'system',
        fontSize: 16,
        language: 'en',
        notifications: true
    });

    return {
        subscribe,
        updatePreference: <K extends keyof UserPreferences>(
            key: K,
            value: UserPreferences[K]
        ) => {
            update(prefs => ({
                ...prefs,
                [key]: value
            }));
            // Persist to storage
            storage.set('userPreferences', value);
        },
        resetToDefaults: () => {
            set({
                theme: 'system',
                fontSize: 16,
                language: 'en',
                notifications: true
            });
            storage.remove('userPreferences');
        }
    };
}
```

### Exercise 2: API Integration Implementation
Create a complete API service for a new feature:

```typescript
// src/lib/apis/features/index.ts
import { fetchWithAuth } from '../base';
import type { Feature } from '$lib/types';

export class FeatureService {
    private readonly baseUrl = '/api/features';

    async getAll(): Promise<Feature[]> {
        const response = await fetchWithAuth(this.baseUrl);
        return response.json();
    }

    async getById(id: string): Promise<Feature> {
        const response = await fetchWithAuth(`${this.baseUrl}/${id}`);
        return response.json();
    }

    async create(feature: Omit<Feature, 'id'>): Promise<Feature> {
        const response = await fetchWithAuth(this.baseUrl, {
            method: 'POST',
            body: JSON.stringify(feature)
        });
        return response.json();
    }

    async update(id: string, feature: Partial<Feature>): Promise<Feature> {
        const response = await fetchWithAuth(`${this.baseUrl}/${id}`, {
            method: 'PUT',
            body: JSON.stringify(feature)
        });
        return response.json();
    }

    async delete(id: string): Promise<void> {
        await fetchWithAuth(`${this.baseUrl}/${id}`, {
            method: 'DELETE'
        });
    }
}

export const featureService = new FeatureService();
```

### Exercise 3: Real-time Features Implementation
Implement a real-time chat feature using WebSocket:

```typescript
// src/lib/components/chat/RealTimeChat.svelte
<script lang="ts">
    import { onMount, onDestroy } from 'svelte';
    import { socketStore } from '$lib/socket';
    import type { Message } from '$lib/types';

    let messages: Message[] = [];
    let currentMessage = '';

    onMount(() => {
        socketStore.connect();
        
        // Subscribe to messages
        const unsubscribe = socketStore.subscribe(({ socket }) => {
            if (socket) {
                socket.on('message', (message: Message) => {
                    messages = [...messages, message];
                });
            }
        });

        return () => {
            unsubscribe();
            socketStore.disconnect();
        };
    });

    async function sendMessage() {
        if (!currentMessage.trim()) return;
        
        const message = {
            id: crypto.randomUUID(),
            content: currentMessage,
            timestamp: Date.now()
        };

        socketStore.subscribe(({ socket }) => {
            socket?.emit('message', message);
        });

        currentMessage = '';
    }
</script>

<div class="chat-container">
    <div class="messages">
        {#each messages as message}
            <div class="message">
                <span class="timestamp">
                    {new Date(message.timestamp).toLocaleTimeString()}
                </span>
                <p>{message.content}</p>
            </div>
        {/each}
    </div>

    <div class="input-area">
        <input
            bind:value={currentMessage}
            on:keypress={(e) => e.key === 'Enter' && sendMessage()}
            placeholder="Type a message..."
        />
        <button on:click={sendMessage}>Send</button>
    </div>
</div>

<style>
    .chat-container {
        @apply flex flex-col h-full;
    }

    .messages {
        @apply flex-1 overflow-y-auto p-4;
    }

    .message {
        @apply mb-4 p-2 rounded-lg bg-gray-100 dark:bg-gray-800;
    }

    .input-area {
        @apply p-4 border-t dark:border-gray-700;
    }
</style>
```

## Assessment
Students should demonstrate:
1. Understanding of Svelte stores and state management
2. Ability to implement REST API integration
3. Knowledge of WebSocket implementation
4. Proficiency in error handling
5. Skills in data persistence implementation

## Additional Resources

### Documentation
- [Svelte Store Documentation](https://svelte.dev/docs#run-time-svelte-store)
- [Socket.IO Client Documentation](https://socket.io/docs/v4/client-api/)
- [IndexedDB Documentation](https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API)

### Code Examples
- Complete store implementations
- API integration patterns
- WebSocket usage examples

### Next Steps
- Review implemented exercises
- Explore advanced state management patterns
- Prepare for Lesson 4: Component Architecture and UI System
