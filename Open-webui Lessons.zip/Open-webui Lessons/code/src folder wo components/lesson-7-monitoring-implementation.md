# Monitoring Implementation Guide for Open WebUI

## Overview
This comprehensive guide covers the monitoring implementation for Open WebUI, focusing on logging, metrics collection, and alerting systems. The guide provides detailed instructions for setting up a complete monitoring infrastructure.

## 1. Logging System Implementation

### 1.1 Logging Architecture

The logging system in Open WebUI follows a structured logging approach using multiple handlers and formatters. The implementation spans across both frontend and backend:

```
backend/
  └── open_webui/
      ├── utils/
      │   └── logger.py           # Logger configuration
      └── logging/
          ├── handlers/
          │   ├── file.py         # File logging handler
          │   └── elastic.py      # Elasticsearch handler
          └── formatters/
              └── json.py         # JSON formatter

frontend/
  └── src/
      └── lib/
          └── utils/
              └── logger.ts       # Frontend logging utility
```

### 1.2 Backend Logging Implementation

```python
# backend/open_webui/utils/logger.py

import logging
import json
from datetime import datetime
from typing import Any, Dict
from pythonjsonlogger import jsonlogger

class CustomJSONFormatter(jsonlogger.JsonFormatter):
    def add_fields(self, log_record: Dict[str, Any], record: logging.LogRecord, message_dict: Dict[str, Any]) -> None:
        super(CustomJSONFormatter, self).add_fields(log_record, record, message_dict)
        log_record['timestamp'] = datetime.utcnow().isoformat()
        log_record['level'] = record.levelname
        log_record['application'] = 'open-webui'
        log_record['environment'] = os.getenv('APP_ENV', 'production')

def setup_logger():
    logger = logging.getLogger('open_webui')
    logger.setLevel(logging.INFO)

    # Console Handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(CustomJSONFormatter())
    logger.addHandler(console_handler)

    # File Handler
    file_handler = logging.FileHandler('logs/open-webui.log')
    file_handler.setFormatter(CustomJSONFormatter())
    logger.addHandler(file_handler)

    # Elasticsearch Handler
    if os.getenv('ELASTICSEARCH_URL'):
        es_handler = ElasticsearchHandler(
            hosts=[os.getenv('ELASTICSEARCH_URL')],
            index_name='open-webui-logs'
        )
        es_handler.setFormatter(CustomJSONFormatter())
        logger.addHandler(es_handler)

    return logger

# Usage example
logger = setup_logger()
```

### 1.3 Frontend Logging Implementation

```typescript
// frontend/src/lib/utils/logger.ts

interface LogEntry {
    level: 'info' | 'warn' | 'error';
    message: string;
    timestamp: string;
    context?: Record<string, any>;
    tags?: string[];
}

class Logger {
    private static instance: Logger;
    private logBuffer: LogEntry[] = [];
    private readonly bufferSize: number = 100;
    private readonly logEndpoint: string = '/api/v1/logs';

    private constructor() {
        window.addEventListener('unload', () => this.flushLogs());
    }

    static getInstance(): Logger {
        if (!Logger.instance) {
            Logger.instance = new Logger();
        }
        return Logger.instance;
    }

    private async sendLogs(logs: LogEntry[]): Promise<void> {
        try {
            await fetch(this.logEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ logs }),
            });
        } catch (error) {
            console.error('Failed to send logs:', error);
        }
    }

    private addToBuffer(entry: LogEntry): void {
        this.logBuffer.push(entry);
        if (this.logBuffer.length >= this.bufferSize) {
            this.flushLogs();
        }
    }

    private async flushLogs(): Promise<void> {
        if (this.logBuffer.length > 0) {
            const logs = [...this.logBuffer];
            this.logBuffer = [];
            await this.sendLogs(logs);
        }
    }

    info(message: string, context?: Record<string, any>, tags?: string[]): void {
        this.addToBuffer({
            level: 'info',
            message,
            timestamp: new Date().toISOString(),
            context,
            tags,
        });
    }

    error(message: string, context?: Record<string, any>, tags?: string[]): void {
        this.addToBuffer({
            level: 'error',
            message,
            timestamp: new Date().toISOString(),
            context,
            tags,
        });
    }
}

export const logger = Logger.getInstance();
```

## 2. Metrics Collection System

### 2.1 Prometheus Integration

Implementation of Prometheus metrics collection:

```python
# backend/open_webui/monitoring/metrics.py

from prometheus_client import Counter, Histogram, Summary, Gauge
from prometheus_client.exposition import generate_latest
from fastapi import APIRouter, Response

router = APIRouter()

# Define metrics
REQUEST_COUNT = Counter(
    'http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status']
)

REQUEST_LATENCY = Histogram(
    'http_request_duration_seconds',
    'HTTP request latency',
    ['method', 'endpoint']
)

ACTIVE_USERS = Gauge(
    'active_users',
    'Number of currently active users'
)

MODEL_PROCESSING_TIME = Summary(
    'model_processing_seconds',
    'Time spent processing model requests',
    ['model_name']
)

@router.get("/metrics")
async def metrics():
    return Response(
        generate_latest(),
        media_type="text/plain"
    )
```

### 2.2 Custom Metrics Middleware

```python
# backend/open_webui/middleware/metrics.py

import time
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

class MetricsMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        
        response = await call_next(request)
        
        # Record request duration
        duration = time.time() - start_time
        REQUEST_LATENCY.labels(
            method=request.method,
            endpoint=request.url.path
        ).observe(duration)
        
        # Increment request counter
        REQUEST_COUNT.labels(
            method=request.method,
            endpoint=request.url.path,
            status=response.status_code
        ).inc()
        
        return response
```

### 2.3 Application Performance Monitoring (APM)

Integration with Elastic APM:

```python
# backend/open_webui/monitoring/apm.py

from elasticapm.contrib.starlette import ElasticAPM
from elasticapm.conf import Config

def setup_apm(app):
    apm_config = Config(
        service_name='open-webui',
        server_url=os.getenv('ELASTIC_APM_SERVER_URL'),
        environment=os.getenv('APP_ENV', 'production'),
        service_version=os.getenv('APP_VERSION'),
        transaction_sample_rate=1.0
    )
    
    apm = ElasticAPM(app, config=apm_config)
    return apm

# Custom transaction monitoring
def monitor_transaction(name: str, type: str = 'custom'):
    def decorator(func):
        async def wrapper(*args, **kwargs):
            with elasticapm.capture_transaction(name, type):
                return await func(*args, **kwargs)
        return wrapper
    return decorator
```

## 3. Real-time Monitoring Dashboard

### 3.1 Metrics Visualization Component

```typescript
// frontend/src/lib/components/monitoring/Dashboard.svelte

<script lang="ts">
    import { onMount, onDestroy } from 'svelte';
    import { Line, Bar } from 'svelte-chartjs';
    
    let metrics = {
        requestCount: [],
        latency: [],
        activeUsers: 0,
        errors: []
    };
    
    let updateInterval: NodeJS.Timer;
    
    async function fetchMetrics() {
        const response = await fetch('/api/v1/metrics/summary');
        const data = await response.json();
        metrics = {
            ...metrics,
            ...data
        };
    }
    
    onMount(() => {
        fetchMetrics();
        updateInterval = setInterval(fetchMetrics, 30000);
    });
    
    onDestroy(() => {
        clearInterval(updateInterval);
    });
</script>

<div class="grid grid-cols-2 gap-4">
    <div class="p-4 bg-white rounded-lg shadow">
        <h3>Request Count</h3>
        <Line
            data={metrics.requestCount}
            options={{
                responsive: true,
                maintainAspectRatio: false
            }}
        />
    </div>
    
    <div class="p-4 bg-white rounded-lg shadow">
        <h3>Response Latency</h3>
        <Line
            data={metrics.latency}
            options={{
                responsive: true,
                maintainAspectRatio: false
            }}
        />
    </div>
    
    <div class="p-4 bg-white rounded-lg shadow">
        <h3>Active Users</h3>
        <div class="text-4xl font-bold">
            {metrics.activeUsers}
        </div>
    </div>
    
    <div class="p-4 bg-white rounded-lg shadow">
        <h3>Error Rate</h3>
        <Bar
            data={metrics.errors}
            options={{
                responsive: true,
                maintainAspectRatio: false
            }}
        />
    </div>
</div>
```

## 4. Alerting System

### 4.1 Alert Configuration

```typescript
// frontend/src/lib/monitoring/alerts.ts

interface AlertRule {
    id: string;
    name: string;
    condition: (metrics: any) => boolean;
    severity: 'info' | 'warning' | 'critical';
    message: string;
    cooldown: number;
}

const alertRules: AlertRule[] = [
    {
        id: 'high-error-rate',
        name: 'High Error Rate',
        condition: (metrics) => metrics.errorRate > 0.05,
        severity: 'critical',
        message: 'Error rate exceeds 5%',
        cooldown: 300000 // 5 minutes
    },
    {
        id: 'high-latency',
        name: 'High Latency',
        condition: (metrics) => metrics.averageLatency > 1000,
        severity: 'warning',
        message: 'Average latency exceeds 1000ms',
        cooldown: 600000 // 10 minutes
    }
];
```

### 4.2 Alert Manager Implementation

```typescript
// frontend/src/lib/monitoring/alertManager.ts

class AlertManager {
    private static instance: AlertManager;
    private alertHistory: Map<string, number> = new Map();
    private subscribers: Set<(alert: Alert) => void> = new Set();

    private constructor() {
        this.startMonitoring();
    }

    static getInstance(): AlertManager {
        if (!AlertManager.instance) {
            AlertManager.instance = new AlertManager();
        }
        return AlertManager.instance;
    }

    private async startMonitoring(): Promise<void> {
        setInterval(async () => {
            const metrics = await this.fetchMetrics();
            this.evaluateRules(metrics);
        }, 60000);
    }

    private async fetchMetrics(): Promise<any> {
        const response = await fetch('/api/v1/metrics/current');
        return await response.json();
    }

    private evaluateRules(metrics: any): void {
        for (const rule of alertRules) {
            const lastAlertTime = this.alertHistory.get(rule.id) || 0;
            const currentTime = Date.now();

            if (currentTime - lastAlertTime > rule.cooldown) {
                if (rule.condition(metrics)) {
                    this.triggerAlert({
                        ruleId: rule.id,
                        severity: rule.severity,
                        message: rule.message,
                        timestamp: new Date().toISOString()
                    });
                    this.alertHistory.set(rule.id, currentTime);
                }
            }
        }
    }

    private triggerAlert(alert: Alert): void {
        this.subscribers.forEach(subscriber => subscriber(alert));
        this.sendAlertToBackend(alert);
    }

    private async sendAlertToBackend(alert: Alert): Promise<void> {
        try {
            await fetch('/api/v1/alerts', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(alert)
            });
        } catch (error) {
            console.error('Failed to send alert:', error);
        }
    }

    subscribe(callback: (alert: Alert) => void): () => void {
        this.subscribers.add(callback);
        return () => this.subscribers.delete(callback);
    }
}

export const alertManager = AlertManager.getInstance();
```

This monitoring implementation guide provides a comprehensive approach to tracking and visualizing the health and performance of Open WebUI. The next artifact will cover maintenance strategies and operational procedures. Would you like me to proceed with creating the final artifact?