# Module 6, Lesson 3: Production Deployment
## Part 2A: Monitoring and Maintenance

## Introduction

This section of the Production Deployment lesson focuses on setting up comprehensive monitoring systems and establishing maintenance procedures for Open WebUI in production. We'll cover monitoring setup, log management, backup strategies, and routine maintenance tasks.

## Monitoring Setup

### System Monitoring

#### 1. Prometheus Configuration

Create a `prometheus.yml` configuration file:

```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

alerting:
  alertmanagers:
    - static_configs:
        - targets: ['alertmanager:9093']

rule_files:
  - "rules/*.yml"

scrape_configs:
  - job_name: 'openwebui'
    static_configs:
      - targets: ['openwebui:8080']
    metrics_path: '/metrics'
    scheme: http

  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node-exporter:9100']

  - job_name: 'cadvisor'
    static_configs:
      - targets: ['cadvisor:8080']
```

Add Prometheus services to `docker-compose.yml`:

```yaml
services:
  prometheus:
    image: prom/prometheus:latest
    volumes:
      - ./prometheus:/etc/prometheus
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/usr/share/prometheus/console_libraries'
      - '--web.console.templates=/usr/share/prometheus/consoles'
    ports:
      - "9090:9090"
    networks:
      - webui_net

  node-exporter:
    image: prom/node-exporter:latest
    volumes:
      - /proc:/host/proc:ro
      - /sys:/host/sys:ro
      - /:/rootfs:ro
    command:
      - '--path.procfs=/host/proc'
      - '--path.sysfs=/host/sys'
      - '--collector.filesystem.ignored-mount-points=^/(sys|proc|dev|host|etc)($$|/)'
    ports:
      - "9100:9100"
    networks:
      - webui_net

  cadvisor:
    image: gcr.io/cadvisor/cadvisor:latest
    volumes:
      - /:/rootfs:ro
      - /var/run:/var/run:ro
      - /sys:/sys:ro
      - /var/lib/docker/:/var/lib/docker:ro
      - /dev/disk/:/dev/disk:ro
    ports:
      - "8080:8080"
    networks:
      - webui_net

volumes:
  prometheus_data: {}
```

#### 2. Grafana Dashboard Setup

Add Grafana service to `docker-compose.yml`:

```yaml
services:
  grafana:
    image: grafana/grafana:latest
    depends_on:
      - prometheus
    ports:
      - "3000:3000"
    volumes:
      - grafana_data:/var/lib/grafana
      - ./grafana/provisioning:/etc/grafana/provisioning
    environment:
      - GF_SECURITY_ADMIN_USER=${GRAFANA_ADMIN_USER:-admin}
      - GF_SECURITY_ADMIN_PASSWORD=${GRAFANA_ADMIN_PASSWORD:-admin}
      - GF_USERS_ALLOW_SIGN_UP=false
    networks:
      - webui_net

volumes:
  grafana_data: {}
```

Create a basic dashboard in `grafana/provisioning/dashboards/openwebui.json`:

```json
{
  "dashboard": {
    "id": null,
    "title": "Open WebUI Dashboard",
    "tags": ["openwebui"],
    "timezone": "browser",
    "panels": [
      {
        "title": "CPU Usage",
        "type": "graph",
        "datasource": "Prometheus",
        "targets": [
          {
            "expr": "rate(process_cpu_seconds_total{job=\"openwebui\"}[5m])",
            "legendFormat": "CPU Usage"
          }
        ]
      },
      {
        "title": "Memory Usage",
        "type": "graph",
        "datasource": "Prometheus",
        "targets": [
          {
            "expr": "process_resident_memory_bytes{job=\"openwebui\"}",
            "legendFormat": "Memory Usage"
          }
        ]
      }
    ]
  }
}
```

### Log Management

#### 1. ELK Stack Configuration

Add Elasticsearch, Logstash, and Kibana services:

```yaml
services:
  elasticsearch:
    image: docker.elastic.co/elasticsearch/elasticsearch:8.x
    environment:
      - discovery.type=single-node
      - ES_JAVA_OPTS=-Xms512m -Xmx512m
    volumes:
      - elasticsearch_data:/usr/share/elasticsearch/data
    networks:
      - webui_net

  logstash:
    image: docker.elastic.co/logstash/logstash:8.x
    volumes:
      - ./logstash/pipeline:/usr/share/logstash/pipeline
    depends_on:
      - elasticsearch
    networks:
      - webui_net

  kibana:
    image: docker.elastic.co/kibana/kibana:8.x
    ports:
      - "5601:5601"
    depends_on:
      - elasticsearch
    networks:
      - webui_net

volumes:
  elasticsearch_data: {}
```

Create Logstash pipeline configuration in `logstash/pipeline/logstash.conf`:

```conf
input {
  gelf {
    port => 12201
    type => docker
  }
}

filter {
  if [container_name] =~ /^openwebui/ {
    grok {
      match => { "message" => "%{COMBINEDAPACHELOG}" }
    }
  }
}

output {
  elasticsearch {
    hosts => ["elasticsearch:9200"]
    index => "openwebui-logs-%{+YYYY.MM.dd}"
  }
}
```

### Performance Monitoring

#### 1. Application Performance Monitoring

Add OpenTelemetry configuration to Open WebUI:

```python
# backend/open_webui/telemetry.py
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.jaeger.thrift import JaegerExporter

def setup_telemetry():
    """Configure OpenTelemetry with Jaeger exporter."""
    trace.set_tracer_provider(TracerProvider())
    jaeger_exporter = JaegerExporter(
        agent_host_name="jaeger",
        agent_port=6831,
    )
    trace.get_tracer_provider().add_span_processor(
        BatchSpanProcessor(jaeger_exporter)
    )
```

Add Jaeger service to `docker-compose.yml`:

```yaml
services:
  jaeger:
    image: jaegertracing/all-in-one:latest
    ports:
      - "16686:16686"
      - "6831:6831/udp"
    networks:
      - webui_net
```

## Maintenance Procedures

### Backup Strategy

#### 1. Database Backup Script

Create `scripts/backup_db.sh`:

```bash
#!/bin/bash

# Configuration
BACKUP_DIR="/backup/postgres"
RETENTION_DAYS=7
DATE=$(date +%Y%m%d_%H%M%S)
DB_CONTAINER="openwebui-db"
DB_NAME="openwebui"
DB_USER="openwebui"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Perform backup
docker exec "$DB_CONTAINER" pg_dump -U "$DB_USER" "$DB_NAME" | gzip > "$BACKUP_DIR/backup_${DATE}.sql.gz"

# Remove old backups
find "$BACKUP_DIR" -type f -name "backup_*.sql.gz" -mtime +$RETENTION_DAYS -delete

# Log backup completion
echo "Backup completed: backup_${DATE}.sql.gz"
```

#### 2. Volume Backup Script

Create `scripts/backup_volumes.sh`:

```bash
#!/bin/bash

# Configuration
BACKUP_DIR="/backup/volumes"
DATE=$(date +%Y%m%d_%H%M%S)
VOLUMES=("openwebui_data" "prometheus_data" "grafana_data")

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Stop services
docker compose down

# Backup each volume
for VOLUME in "${VOLUMES[@]}"; do
    echo "Backing up volume: $VOLUME"
    docker run --rm \
        -v "$VOLUME":/source:ro \
        -v "$BACKUP_DIR":/backup \
        alpine tar czf "/backup/${VOLUME}_${DATE}.tar.gz" -C /source .
done

# Restart services
docker compose up -d

# Log backup completion
echo "Volume backup completed: ${DATE}"
```

### Update Procedures

#### 1. Update Script

Create `scripts/update.sh`:

```bash
#!/bin/bash

# Configuration
BACKUP_SCRIPT="./scripts/backup_db.sh"
COMPOSE_FILE="docker-compose.yml"
LOG_FILE="update.log"

# Function to log messages
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Perform backup
log_message "Starting backup before update"
$BACKUP_SCRIPT
if [ $? -ne 0 ]; then
    log_message "Backup failed, aborting update"
    exit 1
fi

# Pull new images
log_message "Pulling new images"
docker compose pull
if [ $? -ne 0 ]; then
    log_message "Failed to pull new images"
    exit 1
fi

# Stop services
log_message "Stopping services"
docker compose down

# Start updated services
log_message "Starting updated services"
docker compose up -d

# Check service health
log_message "Checking service health"
sleep 30
docker compose ps | grep "unhealthy"
if [ $? -eq 0 ]; then
    log_message "Some services are unhealthy after update"
    exit 1
fi

log_message "Update completed successfully"
```

### Monitoring Alerts

#### 1. Alertmanager Configuration

Create `prometheus/alertmanager.yml`:

```yaml
global:
  resolve_timeout: 5m

route:
  group_by: ['alertname']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 1h
  receiver: 'email-notifications'

receivers:
- name: 'email-notifications'
  email_configs:
  - to: 'admin@your-domain.com'
    from: 'alertmanager@your-domain.com'
    smarthost: 'smtp.your-domain.com:587'
    auth_username: 'alertmanager@your-domain.com'
    auth_identity: 'alertmanager@your-domain.com'
    auth_password: 'your-smtp-password'
```

#### 2. Alert Rules

Create `prometheus/rules/openwebui.yml`:

```yaml
groups:
- name: openwebui
  rules:
  - alert: HighMemoryUsage
    expr: process_resident_memory_bytes{job="openwebui"} > 1e9
    for: 5m
    labels:
      severity: warning
    annotations:
      summary: High memory usage on OpenWebUI
      description: OpenWebUI is using more than 1GB of memory for 5 minutes.

  - alert: HighCPUUsage
    expr: rate(process_cpu_seconds_total{job="openwebui"}[5m]) > 0.8
    for: 5m
    labels:
      severity: warning
    annotations:
      summary: High CPU usage on OpenWebUI
      description: OpenWebUI is using more than 80% CPU for 5 minutes.

  - alert: HighErrorRate
    expr: rate(http_requests_total{status=~"5.."}[5m]) > 1
    for: 1m
    labels:
      severity: critical
    annotations:
      summary: High error rate on OpenWebUI
      description: OpenWebUI is experiencing a high rate of 5xx errors.
```

This concludes Part 2A of the Production Deployment lesson. Continue to Part 2B for advanced deployment topics and disaster recovery procedures.