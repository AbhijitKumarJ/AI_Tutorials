# Module 5, Lesson 3: Advanced Administration
## Part 1: System Administration and Security

## Overview

In this first part of Advanced Administration, we'll focus on system administration fundamentals, user management, and security configurations in Open WebUI. This knowledge is essential for maintaining a secure and well-organized Open WebUI deployment.

## Learning Objectives

By the end of Part 1, you will understand:
- How to implement and manage user authentication systems
- Role-based access control (RBAC) configuration
- Security best practices and implementation
- System monitoring fundamentals

## 1. User Management Systems

### 1.1 User Database Structure

Open WebUI uses a structured approach to user management. The basic database schema is organized as follows:

```sql
CREATE TABLE users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    hashed_password TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT FALSE,
    is_superuser BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE roles (
    id TEXT PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    permissions JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_roles (
    user_id TEXT REFERENCES users(id),
    role_id TEXT REFERENCES roles(id),
    PRIMARY KEY (user_id, role_id)
);
```

### 1.2 User Management Implementation

Here's an example of implementing user management functions:

```python
from typing import Optional
from datetime import datetime
from pydantic import BaseModel, EmailStr
from fastapi import HTTPException
import bcrypt

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    role_id: Optional[str] = None

class UserManager:
    def __init__(self, db_connection):
        self.db = db_connection

    async def create_user(self, user: UserCreate) -> dict:
        # Hash password
        salt = bcrypt.gensalt()
        hashed_password = bcrypt.hashpw(
            user.password.encode('utf-8'), 
            salt
        )
        
        try:
            query = """
                INSERT INTO users (id, email, hashed_password)
                VALUES ($1, $2, $3)
                RETURNING id, email, created_at
            """
            user_id = generate_uuid()
            result = await self.db.fetch_one(
                query, 
                user_id, 
                user.email, 
                hashed_password.decode()
            )
            
            if user.role_id:
                await self.assign_role(user_id, user.role_id)
                
            return dict(result)
        except Exception as e:
            raise HTTPException(
                status_code=400,
                detail=f"Could not create user: {str(e)}"
            )

    async def assign_role(self, user_id: str, role_id: str):
        query = """
            INSERT INTO user_roles (user_id, role_id)
            VALUES ($1, $2)
        """
        await self.db.execute(query, user_id, role_id)
```

## 2. Role-Based Access Control (RBAC)

### 2.1 RBAC Configuration

Implementation of role-based access control system:

```python
from enum import Enum
from typing import List, Set
from pydantic import BaseModel

class Permission(Enum):
    READ_MODELS = "read:models"
    WRITE_MODELS = "write:models"
    MANAGE_USERS = "manage:users"
    ACCESS_ADMIN = "access:admin"
    MANAGE_SYSTEM = "manage:system"

class Role(BaseModel):
    id: str
    name: str
    permissions: Set[Permission]

class RBACManager:
    def __init__(self):
        self.roles: dict[str, Role] = {}
        self._setup_default_roles()

    def _setup_default_roles(self):
        # Set up admin role
        self.roles["admin"] = Role(
            id="admin",
            name="Administrator",
            permissions={
                Permission.READ_MODELS,
                Permission.WRITE_MODELS,
                Permission.MANAGE_USERS,
                Permission.ACCESS_ADMIN,
                Permission.MANAGE_SYSTEM
            }
        )
        
        # Set up user role
        self.roles["user"] = Role(
            id="user",
            name="User",
            permissions={
                Permission.READ_MODELS
            }
        )

    async def check_permission(
        self,
        user_id: str,
        permission: Permission
    ) -> bool:
        user_roles = await self.get_user_roles(user_id)
        return any(
            permission in self.roles[role].permissions
            for role in user_roles
        )

    async def get_user_roles(self, user_id: str) -> List[str]:
        query = """
            SELECT r.name
            FROM roles r
            JOIN user_roles ur ON r.id = ur.role_id
            WHERE ur.user_id = $1
        """
        results = await self.db.fetch_all(query, user_id)
        return [result['name'] for result in results]
```

### 2.2 Implementing RBAC Middleware

FastAPI middleware for RBAC enforcement:

```python
from fastapi import Depends, HTTPException
from functools import wraps

def require_permission(permission: Permission):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            user = kwargs.get('current_user')
            if not user:
                raise HTTPException(
                    status_code=401,
                    detail="Authentication required"
                )
                
            rbac = RBACManager()
            has_permission = await rbac.check_permission(
                user.id,
                permission
            )
            
            if not has_permission:
                raise HTTPException(
                    status_code=403,
                    detail="Permission denied"
                )
                
            return await func(*args, **kwargs)
        return wrapper
    return decorator

# Usage example
@app.get("/admin/users")
@require_permission(Permission.MANAGE_USERS)
async def list_users(current_user: User = Depends(get_current_user)):
    # Implementation
    pass
```

## 3. Security Configurations

### 3.1 Authentication Security

Implementing secure authentication practices:

```python
from jose import JWTError, jwt
from datetime import datetime, timedelta
from typing import Optional

class SecurityConfig:
    SECRET_KEY = "your-secret-key"
    ALGORITHM = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES = 30
    
    @classmethod
    def create_access_token(
        cls,
        data: dict,
        expires_delta: Optional[timedelta] = None
    ) -> str:
        to_encode = data.copy()
        
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(
                minutes=cls.ACCESS_TOKEN_EXPIRE_MINUTES
            )
            
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(
            to_encode,
            cls.SECRET_KEY,
            algorithm=cls.ALGORITHM
        )
        return encoded_jwt

    @classmethod
    async def verify_token(cls, token: str) -> dict:
        try:
            payload = jwt.decode(
                token,
                cls.SECRET_KEY,
                algorithms=[cls.ALGORITHM]
            )
            return payload
        except JWTError:
            raise HTTPException(
                status_code=401,
                detail="Could not validate credentials"
            )
```

### 3.2 Password Security

Implementing secure password handling:

```python
import bcrypt
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class PasswordManager:
    @staticmethod
    def verify_password(plain_password: str, hashed_password: str) -> bool:
        return pwd_context.verify(plain_password, hashed_password)

    @staticmethod
    def get_password_hash(password: str) -> str:
        return pwd_context.hash(password)

    @staticmethod
    def validate_password_strength(password: str) -> bool:
        """
        Validate password strength based on criteria:
        - Minimum length of 8 characters
        - Contains at least one uppercase letter
        - Contains at least one lowercase letter
        - Contains at least one number
        - Contains at least one special character
        """
        if len(password) < 8:
            return False
            
        if not any(c.isupper() for c in password):
            return False
            
        if not any(c.islower() for c in password):
            return False
            
        if not any(c.isdigit() for c in password):
            return False
            
        special_chars = "!@#$%^&*()_+-=[]{}|;:,.<>?"
        if not any(c in special_chars for c in password):
            return False
            
        return True
```

## 4. System Monitoring Fundamentals

### 4.1 Logging Configuration

Setting up comprehensive logging:

```python
import logging
import logging.handlers
import os
from datetime import datetime

class LogConfig:
    def __init__(
        self,
        log_dir: str = "logs",
        log_level: int = logging.INFO
    ):
        self.log_dir = log_dir
        self.log_level = log_level
        os.makedirs(log_dir, exist_ok=True)

    def setup_logger(self, name: str) -> logging.Logger:
        logger = logging.getLogger(name)
        logger.setLevel(self.log_level)

        # File handler with rotation
        log_file = os.path.join(
            self.log_dir,
            f"{name}_{datetime.now():%Y-%m-%d}.log"
        )
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=10485760,  # 10MB
            backupCount=5
        )

        # Console handler
        console_handler = logging.StreamHandler()

        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        logger.addHandler(file_handler)
        logger.addHandler(console_handler)

        return logger
```

### 4.2 Basic Health Checks

Implementing system health checks:

```python
from fastapi import FastAPI
from typing import Dict
import psutil
import asyncio

app = FastAPI()

class SystemHealth:
    @staticmethod
    async def check_database() -> bool:
        try:
            # Implement database connection check
            return True
        except Exception:
            return False

    @staticmethod
    def check_disk_usage() -> Dict[str, float]:
        disk = psutil.disk_usage('/')
        return {
            "total": disk.total / (1024**3),  # GB
            "used": disk.used / (1024**3),
            "free": disk.free / (1024**3),
            "percent": disk.percent
        }

    @staticmethod
    def check_memory_usage() -> Dict[str, float]:
        memory = psutil.virtual_memory()
        return {
            "total": memory.total / (1024**3),
            "available": memory.available / (1024**3),
            "percent": memory.percent
        }

@app.get("/health")
async def health_check():
    health = SystemHealth()
    
    db_status = await health.check_database()
    disk_status = health.check_disk_usage()
    memory_status = health.check_memory_usage()
    
    return {
        "status": "healthy" if db_status else "unhealthy",
        "disk": disk_status,
        "memory": memory_status
    }
```

## Exercises and Practice

1. Implement a complete user management system with RBAC
2. Create a secure authentication system with JWT tokens
3. Set up comprehensive logging for your Open WebUI instance
4. Implement health checks and monitoring
5. Create a password policy and implement password validation

## Additional Resources

- FastAPI Security Documentation: https://fastapi.tiangolo.com/tutorial/security/
- OWASP Authentication Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html
- Python Logging Documentation: https://docs.python.org/3/library/logging.html
- JWT Documentation: https://pyjwt.readthedocs.io/

Remember to regularly check the Open WebUI documentation for updates and new features that might affect system administration and security configurations.