# Module 1, Lesson 3: Basic Configuration

## Introduction

In this lesson, we'll explore the comprehensive configuration options available in Open WebUI. Understanding these configuration options is crucial for optimizing your deployment for security, performance, and functionality. We'll cover environment variables, authentication setup, network configuration, data persistence, logging, and monitoring.

## Environment Variable Configuration

Environment variables provide a flexible way to configure Open WebUI without modifying the source code. Let's explore the major configuration categories and their impact on the system.

### Core Configuration Variables

The core configuration determines the fundamental behavior of your Open WebUI instance:

```bash
# Basic Setup
WEBUI_NAME="My Open WebUI Instance"
WEBUI_AUTH=True
PORT=8080
ENV=prod  # 'dev' for development mode
```

### Database Configuration

Database settings control how Open WebUI stores and manages its data:

```bash
# Database Configuration
DATABASE_URL="sqlite:///app/backend/data/webui.db"
DATABASE_POOL_SIZE=20
DATABASE_POOL_TIMEOUT=30
DATABASE_POOL_MAX_OVERFLOW=10
DATABASE_POOL_RECYCLE=3600
```

For PostgreSQL deployments:
```bash
DATABASE_URL="postgresql://user:password@localhost:5432/openwebui"
```

### Security Configuration

Security settings manage authentication and access control:

```bash
# Security Settings
ENABLE_SIGNUP=True
DEFAULT_USER_ROLE="pending"  # Options: pending, user, admin
WEBUI_JWT_SECRET_KEY="your-secure-secret-key"
JWT_EXPIRES_IN=3600  # Token expiration in seconds
```

## Authentication Setup and Management

Authentication in Open WebUI follows a hierarchical approach with multiple configuration options.

### Local Authentication Setup

1. **Initial Admin Creation**
   The first user to register automatically becomes the administrator:

   ```python
   # Example configuration in config.py
   ADMIN_EMAIL = os.getenv("ADMIN_EMAIL")
   SHOW_ADMIN_DETAILS = True
   ```

2. **User Management Configuration**
   ```bash
   # User Management Settings
   USER_PERMISSIONS_CHAT_DELETION=True
   USER_PERMISSIONS_CHAT_EDITING=True
   USER_PERMISSIONS_CHAT_TEMPORARY=True
   ```

### OAuth Integration

For enterprises requiring SSO integration:

```bash
# OAuth Configuration
ENABLE_OAUTH_SIGNUP=True
OAUTH_PROVIDER_NAME="SSO"
OAUTH_CLIENT_ID="your-client-id"
OAUTH_CLIENT_SECRET="your-client-secret"
OAUTH_SCOPES="openid email profile"
```

## Network and Proxy Configuration

Proper network configuration ensures secure and efficient communication between components.

### Basic Network Settings

```bash
# Network Configuration
HOST="0.0.0.0"
PORT=8080
CORS_ALLOW_ORIGIN="*"
```

### Proxy Configuration

For deployments behind a proxy:

```bash
# Proxy Settings
http_proxy="http://proxy.example.com:8080"
https_proxy="http://proxy.example.com:8080"
no_proxy="localhost,127.0.0.1"
```

### Load Balancer Configuration

For distributed deployments:

```bash
# Load Balancer Settings
OLLAMA_BASE_URLS="http://ollama1:11434;http://ollama2:11434"
OPENAI_API_BASE_URLS="https://api1.example.com;https://api2.example.com"
```

## Data Persistence Strategies

Proper data persistence configuration ensures your data remains safe and accessible.

### Volume Configuration

For Docker deployments:

```yaml
# docker-compose.yml
volumes:
  open-webui:
    driver: local
    driver_opts:
      type: none
      device: /path/to/data
      o: bind
```

### Backup Configuration

Implement automated backup strategies:

```bash
# Backup Settings
BACKUP_ENABLED=True
BACKUP_INTERVAL=86400  # Daily backups
BACKUP_RETENTION=7     # Keep last 7 backups
```

Example backup script:
```bash
#!/bin/bash
# backup.sh
DATE=$(date +%Y%m%d)
docker exec open-webui tar czf /backup/data_$DATE.tar.gz /app/backend/data
find /backup -name "data_*.tar.gz" -mtime +7 -delete
```

## Database Setup and Management

Configure and optimize your database settings for optimal performance.

### SQLite Configuration

For smaller deployments:
```bash
# SQLite Configuration
DATABASE_URL="sqlite:///app/backend/data/webui.db"
```

### PostgreSQL Configuration

For larger deployments:
```bash
# PostgreSQL Configuration
DATABASE_URL="postgresql://user:password@localhost:5432/openwebui"
DATABASE_POOL_SIZE=20
DATABASE_POOL_RECYCLE=3600
```

### Migration Management

Handle database schema updates:
```bash
# Database Migration Command
alembic upgrade head
```

## Logging and Monitoring Setup

Comprehensive logging and monitoring ensure system health and troubleshooting capabilities.

### Logging Configuration

```bash
# Logging Settings
GLOBAL_LOG_LEVEL="INFO"
DB_LOG_LEVEL="WARNING"
MODELS_LOG_LEVEL="INFO"
OLLAMA_LOG_LEVEL="INFO"
```

Example log configuration:
```python
# logging_config.py
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'standard': {
            'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
        },
    },
    'handlers': {
        'default': {
            'level': 'INFO',
            'formatter': 'standard',
            'class': 'logging.StreamHandler',
        },
        'file': {
            'level': 'INFO',
            'formatter': 'standard',
            'class': 'logging.FileHandler',
            'filename': 'open-webui.log',
        },
    },
    'loggers': {
        '': {
            'handlers': ['default', 'file'],
            'level': 'INFO',
            'propagate': True
        },
    }
}
```

### Monitoring Setup

Implement system monitoring:

```bash
# Monitoring Configuration
ENABLE_METRICS=True
METRICS_PORT=9090
```

Example Prometheus configuration:
```yaml
# prometheus.yml
scrape_configs:
  - job_name: 'open-webui'
    static_configs:
      - targets: ['localhost:9090']
```

## Performance Tuning

Optimize system performance through configuration.

### Cache Configuration

```bash
# Cache Settings
CACHE_TYPE="redis"
CACHE_REDIS_URL="redis://localhost:6379/0"
CACHE_DEFAULT_TIMEOUT=300
```

### Resource Limits

```bash
# Resource Configuration
MAX_REQUESTS_PER_MINUTE=60
MAX_TOKENS_PER_MINUTE=100000
CONCURRENT_REQUEST_LIMIT=10
```

## Backup and Recovery Procedures

Implement robust backup and recovery processes.

### Backup Configuration

```bash
# Backup Settings
BACKUP_DIRECTORY="/path/to/backups"
BACKUP_RETENTION_DAYS=30
```

Example backup script:
```bash
#!/bin/bash
# backup_data.sh
BACKUP_DIR="/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Backup database
docker exec open-webui pg_dump -U postgres openwebui > $BACKUP_DIR/db_$TIMESTAMP.sql

# Backup files
docker exec open-webui tar czf $BACKUP_DIR/files_$TIMESTAMP.tar.gz /app/backend/data

# Clean old backups
find $BACKUP_DIR -type f -mtime +30 -delete
```

## Practice Exercises

1. **Basic Configuration**
   Set up a complete Open WebUI instance with custom environment variables for:
   - Custom instance name
   - Authentication settings
   - Database configuration
   - Logging settings

2. **Advanced Configuration**
   Implement:
   - OAuth integration
   - Custom backup solution
   - Monitoring setup
   - Load balancer configuration

3. **Performance Optimization**
   Create a configuration focused on optimizing performance for:
   - High-traffic environment
   - Limited resource environment
   - Enterprise deployment

## Conclusion

Understanding and properly configuring Open WebUI is crucial for a successful deployment. This lesson covered the essential configuration aspects needed for both basic and advanced setups. In the next module, we'll dive into working with models and advanced features.

## Additional Resources

- [Environment Variables Documentation](https://docs.openwebui.com/getting-started/env-configuration)
- [Authentication Guide](https://docs.openwebui.com/features/sso)
- [Database Configuration](https://docs.openwebui.com/getting-started/advanced-topics)
- [Monitoring Setup Guide](https://docs.openwebui.com/getting-started/advanced-topics/logging)

Remember to always refer to the official documentation for the most up-to-date configuration options and best practices.
