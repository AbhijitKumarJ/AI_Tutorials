# Module 6, Lesson 3: Production Deployment
## Part 1: Setup and Configuration

## Introduction

Welcome to Module 6, Lesson 3 of the Open WebUI Mastery course. In this first part, we'll focus on preparing and configuring Open WebUI for production deployment. We'll cover essential aspects of production setup, security configurations, and initial deployment strategies.

## Prerequisites

Before beginning production deployment, ensure you have:
- Completed Module 6, Lessons 1 and 2
- Access to a production server or cloud environment
- Domain name and SSL certificates
- Basic understanding of Linux system administration
- Knowledge of containerization and Docker
- Understanding of web server configurations

## Production Environment Setup

### Server Requirements

Your production server should meet these minimum specifications:

```yaml
# Production Server Requirements
Specifications:
  CPU: 4 cores minimum
  RAM: 8GB minimum (16GB recommended)
  Storage: 50GB SSD minimum
  Network: 100Mbps minimum
Operating System:
  Recommended: Ubuntu 22.04 LTS
  Alternatives: Debian 11+, CentOS 8+
```

### Initial Server Setup

#### 1. System Updates and Security

First, secure your server with these essential steps:

```bash
# Update system packages
sudo apt update
sudo apt upgrade -y

# Install essential security packages
sudo apt install -y unattended-upgrades fail2ban ufw

# Configure automatic security updates
sudo dpkg-reconfigure -plow unattended-upgrades

# Configure firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw enable
```

#### 2. Create Service User

Create a dedicated user for running Open WebUI:

```bash
# Create user and add to Docker group
sudo useradd -m -s /bin/bash openwebui
sudo usermod -aG docker openwebui

# Set up SSH directory
sudo mkdir -p /home/openwebui/.ssh
sudo cp ~/.ssh/authorized_keys /home/openwebui/.ssh/
sudo chown -R openwebui:openwebui /home/openwebui/.ssh
sudo chmod 700 /home/openwebui/.ssh
sudo chmod 600 /home/openwebui/.ssh/authorized_keys
```

### Docker Configuration

#### 1. Production Docker Compose

Create a production `docker-compose.yml`:

```yaml
version: '3.8'

services:
  openwebui:
    image: ghcr.io/open-webui/open-webui:main
    restart: always
    environment:
      - ENV=prod
      - PORT=8080
      - HOST=0.0.0.0
      - ENABLE_SIGNUP=${ENABLE_SIGNUP:-false}
      - WEBUI_SECRET_KEY=${WEBUI_SECRET_KEY}
      - DATABASE_URL=${DATABASE_URL}
      - ENABLE_ADMIN_CHAT_ACCESS=${ENABLE_ADMIN_CHAT_ACCESS:-true}
    volumes:
      - openwebui_data:/app/backend/data
      - /etc/ssl/certs:/etc/ssl/certs:ro
    networks:
      - webui_net
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  nginx:
    image: nginx:alpine
    restart: always
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx:/etc/nginx/conf.d
      - ./ssl:/etc/nginx/ssl
      - ./www:/var/www/html
    depends_on:
      - openwebui
    networks:
      - webui_net

networks:
  webui_net:
    driver: bridge

volumes:
  openwebui_data:
    driver: local
```

#### 2. Environment Configuration

Create a `.env` file with production settings:

```ini
# Production Environment Variables
ENV=prod
PORT=8080
HOST=0.0.0.0

# Security
WEBUI_SECRET_KEY=your-secure-secret-key
WEBUI_SESSION_COOKIE_SECURE=true
CORS_ALLOW_ORIGIN=https://your-domain.com

# Database
DATABASE_URL=postgresql://user:password@db:5432/openwebui

# Features
ENABLE_SIGNUP=false
ENABLE_ADMIN_CHAT_ACCESS=true
ENABLE_COMMUNITY_SHARING=false

# Logging
LOG_LEVEL=INFO
```

### SSL/TLS Configuration

#### 1. Nginx Configuration

Create the Nginx configuration file `nginx/openwebui.conf`:

```nginx
# HTTP - redirect all traffic to HTTPS
server {
    listen 80;
    listen [::]:80;
    server_name your-domain.com www.your-domain.com;
    
    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        return 301 https://$host$request_uri;
    }
}

# HTTPS configuration
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name your-domain.com www.your-domain.com;

    # SSL
    ssl_certificate /etc/nginx/ssl/fullchain.pem;
    ssl_certificate_key /etc/nginx/ssl/privkey.pem;
    ssl_session_timeout 1d;
    ssl_session_cache shared:SSL:50m;
    ssl_session_tickets off;

    # modern configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;

    # HSTS
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # OCSP stapling
    ssl_stapling on;
    ssl_stapling_verify on;
    resolver 8.8.8.8 8.8.4.4 valid=300s;
    resolver_timeout 5s;

    # security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

    # reverse proxy
    location / {
        proxy_pass http://openwebui:8080;
        proxy_http_version 1.1;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # WebSocket support
        proxy_read_timeout 86400;
    }

    # gzip
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml application/json application/javascript application/rss+xml application/atom+xml image/svg+xml;
}
```

#### 2. SSL Certificate Setup

Set up SSL certificates using Let's Encrypt:

```bash
# Install certbot
sudo apt install -y certbot python3-certbot-nginx

# Obtain SSL certificate
sudo certbot certonly --webroot \
  -w /var/www/html \
  -d your-domain.com \
  -d www.your-domain.com

# Create SSL directory and copy certificates
sudo mkdir -p /etc/nginx/ssl
sudo cp /etc/letsencrypt/live/your-domain.com/fullchain.pem /etc/nginx/ssl/
sudo cp /etc/letsencrypt/live/your-domain.com/privkey.pem /etc/nginx/ssl/
```

### Database Setup

#### 1. PostgreSQL Configuration

For production, set up PostgreSQL with proper configurations:

```sql
-- Create database and user
CREATE DATABASE openwebui;
CREATE USER openwebui WITH PASSWORD 'secure-password';
GRANT ALL PRIVILEGES ON DATABASE openwebui TO openwebui;

-- Connect to the database and create extensions
\c openwebui
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
```

Configure PostgreSQL for production in `postgresql.conf`:

```ini
# Memory Configuration
shared_buffers = 1GB
work_mem = 32MB
maintenance_work_mem = 256MB

# Checkpoint Configuration
checkpoint_completion_target = 0.9
checkpoint_timeout = 15min
max_wal_size = 2GB
min_wal_size = 1GB

# Query Planning
effective_cache_size = 3GB
random_page_cost = 1.1

# Connection Settings
max_connections = 100
```

## Initial Deployment

### 1. Deployment Script

Create a deployment script `deploy.sh`:

```bash
#!/bin/bash

# Exit on error
set -e

# Load environment variables
source .env

# Pull latest images
docker compose pull

# Stop and remove existing containers
docker compose down

# Start new containers
docker compose up -d

# Check container status
docker compose ps

# Follow logs for potential issues
docker compose logs -f --tail=100
```

Make the script executable:

```bash
chmod +x deploy.sh
```

### 2. First-Time Deployment

Run the initial deployment:

```bash
# Initialize deployment
./deploy.sh

# Verify deployment
curl -I https://your-domain.com
```

This concludes Part 1 of the Production Deployment lesson. Continue to Part 2 for monitoring, maintenance, and advanced deployment topics.