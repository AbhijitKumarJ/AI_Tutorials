# Module 5, Lesson 2: Pipeline Development

## Overview

This lesson focuses on pipeline development in Open WebUI, covering how to create, deploy, and maintain processing pipelines. Pipelines are crucial for extending Open WebUI's functionality, allowing for custom processing flows, advanced integrations, and enhanced capabilities.

## Learning Objectives

By the end of this lesson, you will understand:
- The fundamentals of Open WebUI's pipeline architecture
- How to create custom pipelines
- Deployment strategies for pipelines
- Methods for monitoring and maintaining pipeline performance
- Scaling considerations and best practices

## 1. Pipeline Architecture

### 1.1 Understanding Pipeline Structure

Open WebUI's pipeline architecture follows a modular design pattern. The basic structure is organized as follows:

```plaintext
/pipelines/
  ├── examples/
  │   ├── filters/
  │   │   ├── function_calling_filter_pipeline.py
  │   │   ├── langfuse_filter_pipeline.py
  │   │   └── rate_limit_filter_pipeline.py
  │   ├── pipelines/
  │   │   ├── rag/
  │   │   │   └── llamaindex_pipeline.py
  │   │   └── providers/
  │   │       └── openai_manifold_pipeline.py
  │   └── scaffolds/
  │       └── example_pipeline_scaffold.py
  ├── requirements.txt
  └── start.sh
```

### 1.2 Pipeline Types

Open WebUI supports several types of pipelines:

1. **Filter Pipelines**
   - Process incoming and outgoing messages
   - Modify content or add functionality
   - Example: toxicity filtering, translation services

2. **Provider Pipelines**
   - Connect to external LLM providers
   - Handle API communication
   - Manage model-specific features

3. **RAG Pipelines**
   - Implement custom retrieval strategies
   - Handle document processing
   - Manage knowledge bases

## 2. Custom Pipeline Creation

### 2.1 Basic Pipeline Structure

Here's an example of a basic pipeline structure:

```python
from typing import Optional, Union, Generator, Iterator
from pydantic import BaseModel, Field

class Pipeline:
    class Valves(BaseModel):
        priority: int = Field(
            default=0,
            description="Priority level for pipeline operations"
        )
        rate_limit: int = Field(
            default=60,
            description="Requests per minute limit"
        )

    def __init__(self):
        self.type = "pipe"
        self.id = "custom_pipeline"
        self.name = "Custom Pipeline"
        self.valves = self.Valves()

    def pipe(self, body: dict) -> Union[str, Generator, Iterator]:
        # Implementation logic here
        return body
```

### 2.2 Implementing Pipeline Features

Here's an example of a more complex pipeline with additional features:

```python
class AdvancedPipeline:
    class Valves(BaseModel):
        api_key: str = Field(
            default="",
            description="API key for external service"
        )
        model_name: str = Field(
            default="gpt-3.5-turbo",
            description="Model to use for processing"
        )
        max_tokens: int = Field(
            default=2000,
            description="Maximum tokens per request"
        )

    def __init__(self):
        self.type = "manifold"
        self.id = "advanced_pipeline"
        self.name = "Advanced Pipeline"
        self.valves = self.Valves()

    def get_provider_models(self):
        return [
            {"id": "model_1", "name": "Model One"},
            {"id": "model_2", "name": "Model Two"}
        ]

    async def process_request(self, request: dict) -> dict:
        try:
            # Request processing logic
            return {"status": "success", "data": request}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def pipe(self, body: dict) -> Union[str, Generator, Iterator]:
        # Implementation logic with error handling
        try:
            result = self.process_request(body)
            return result
        except Exception as e:
            return {"error": str(e)}
```

## 3. Deployment Strategies

### 3.1 Docker Deployment

The recommended way to deploy pipelines is using Docker. Here's an example `docker-compose.yml`:

```yaml
version: '3'
services:
  pipelines:
    image: ghcr.io/open-webui/pipelines:main
    ports:
      - "9099:9099"
    volumes:
      - ./pipelines:/app/pipelines
    environment:
      - PIPELINES_DIR=/app/pipelines
      - API_KEY=your-secret-key
    restart: always
```

### 3.2 Environment Configuration

Configure pipeline settings using environment variables:

```bash
# Pipeline Configuration
PIPELINES_DIR=/app/pipelines
PIPELINES_HOST=0.0.0.0
PIPELINES_PORT=9099
PIPELINES_WORKERS=4

# Security Settings
API_KEY=your-secret-key
ENABLE_AUTH=true

# Performance Settings
MAX_CONCURRENT_REQUESTS=100
REQUEST_TIMEOUT=300
```

## 4. Service Integration

### 4.1 External Service Integration

Example of integrating an external service:

```python
import aiohttp
from typing import Optional

class ExternalServicePipeline:
    class Valves(BaseModel):
        service_url: str = Field(
            default="https://api.external-service.com"
        )
        api_key: str = Field(default="")
        timeout: int = Field(default=30)

    async def call_external_service(
        self,
        endpoint: str,
        data: dict,
        headers: Optional[dict] = None
    ) -> dict:
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(
                    f"{self.valves.service_url}{endpoint}",
                    json=data,
                    headers=headers,
                    timeout=self.valves.timeout
                ) as response:
                    return await response.json()
            except Exception as e:
                raise Exception(f"External service error: {str(e)}")
```

## 5. Error Handling and Monitoring

### 5.1 Comprehensive Error Handling

Implement robust error handling in pipelines:

```python
class PipelineError(Exception):
    def __init__(self, message: str, code: int = 500):
        self.message = message
        self.code = code
        super().__init__(self.message)

class RobustPipeline:
    async def safe_process(self, data: dict) -> dict:
        try:
            # Processing logic
            return {"status": "success", "data": processed_data}
        except ValueError as e:
            raise PipelineError(f"Invalid input: {str(e)}", 400)
        except TimeoutError as e:
            raise PipelineError(f"Service timeout: {str(e)}", 504)
        except Exception as e:
            raise PipelineError(f"Internal error: {str(e)}", 500)
```

### 5.2 Monitoring Implementation

Set up monitoring for your pipelines:

```python
import time
from prometheus_client import Counter, Histogram

class MonitoredPipeline:
    def __init__(self):
        self.requests_total = Counter(
            'pipeline_requests_total',
            'Total requests processed',
            ['pipeline_id', 'status']
        )
        self.processing_time = Histogram(
            'pipeline_processing_seconds',
            'Time spent processing requests',
            ['pipeline_id']
        )

    async def process_with_monitoring(self, data: dict):
        start_time = time.time()
        try:
            result = await self.process(data)
            self.requests_total.labels(
                pipeline_id=self.id,
                status='success'
            ).inc()
            return result
        except Exception as e:
            self.requests_total.labels(
                pipeline_id=self.id,
                status='error'
            ).inc()
            raise e
        finally:
            self.processing_time.labels(
                pipeline_id=self.id
            ).observe(time.time() - start_time)
```

## 6. Scaling Considerations

### 6.1 Horizontal Scaling

Implement pipeline scaling using Docker Swarm or Kubernetes:

```yaml
# docker-compose.scale.yml
version: '3'
services:
  pipelines:
    image: ghcr.io/open-webui/pipelines:main
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: '0.50'
          memory: 512M
      restart_policy:
        condition: on-failure
    ports:
      - "9099:9099"
```

### 6.2 Load Balancing

Configure load balancing for distributed pipelines:

```python
class LoadBalancedPipeline:
    def __init__(self):
        self.endpoints = [
            "http://pipeline1:9099",
            "http://pipeline2:9099",
            "http://pipeline3:9099"
        ]
        self.current_endpoint = 0

    def get_next_endpoint(self) -> str:
        endpoint = self.endpoints[self.current_endpoint]
        self.current_endpoint = (self.current_endpoint + 1) % len(self.endpoints)
        return endpoint

    async def process_distributed(self, data: dict) -> dict:
        endpoint = self.get_next_endpoint()
        async with aiohttp.ClientSession() as session:
            async with session.post(endpoint, json=data) as response:
                return await response.json()
```

## 7. Maintenance Procedures

### 7.1 Health Checks

Implement health checks for pipeline monitoring:

```python
from fastapi import FastAPI, HTTPException
from typing import Dict

app = FastAPI()

class HealthCheck:
    def __init__(self):
        self.services: Dict[str, bool] = {}

    async def check_service_health(self, service_name: str) -> bool:
        # Implement service-specific health checks
        return self.services.get(service_name, False)

@app.get("/health")
async def health_check():
    health_checker = HealthCheck()
    services_status = await health_checker.check_service_health("pipeline")
    if not services_status:
        raise HTTPException(status_code=503, detail="Service unhealthy")
    return {"status": "healthy"}
```

### 7.2 Logging Configuration

Set up comprehensive logging:

```python
import logging
from logging.handlers import RotatingFileHandler

def setup_pipeline_logging(pipeline_id: str):
    logger = logging.getLogger(f"pipeline_{pipeline_id}")
    logger.setLevel(logging.INFO)

    # File handler with rotation
    handler = RotatingFileHandler(
        f"logs/pipeline_{pipeline_id}.log",
        maxBytes=10000000,
        backupCount=5
    )
    
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    
    return logger
```

## Exercises and Practice

1. Create a basic pipeline that processes and transforms text
2. Implement a pipeline with external service integration
3. Add monitoring and logging to your pipeline
4. Deploy your pipeline using Docker
5. Implement load balancing for multiple pipeline instances

## Additional Resources

- FastAPI Documentation: https://fastapi.tiangolo.com/
- Docker Documentation: https://docs.docker.com/
- Prometheus Documentation: https://prometheus.io/docs/introduction/overview/
- aiohttp Documentation: https://docs.aiohttp.org/

Remember to regularly check the Open WebUI documentation for updates and new features that might affect pipeline development and deployment.
