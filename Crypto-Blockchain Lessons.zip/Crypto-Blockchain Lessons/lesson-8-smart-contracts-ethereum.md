# Lesson 8: Smart Contracts and Ethereum

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand the concept of smart contracts and their significance in blockchain technology
2. Grasp the basics of the Solidity programming language
3. Create and deploy simple smart contracts
4. Interact with smart contracts using Python
5. Comprehend gas optimization techniques and best practices
6. Implement testing strategies for smart contracts

## 1. Introduction to Ethereum and Smart Contracts

### What is Ethereum?
Ethereum is a decentralized, open-source blockchain platform that enables the creation and deployment of smart contracts and decentralized applications (DApps). Unlike Bitcoin, which primarily focuses on peer-to-peer digital currency transactions, Ethereum provides a more flexible and programmable blockchain infrastructure.

### Understanding Smart Contracts
Smart contracts are self-executing contracts with the terms of the agreement directly written into code. They run on the blockchain, allowing for trustless and automated execution of contractual terms. Key features of smart contracts include:

- Autonomy: Once deployed, they operate independently
- Transparency: All terms and transactions are visible on the blockchain
- Immutability: Code cannot be changed once deployed (unless specifically designed to be upgradeable)
- Efficiency: Automated execution reduces the need for intermediaries

## 2. Solidity Programming Language Basics

Solidity is the primary programming language used for writing smart contracts on Ethereum. It's a statically-typed, contract-oriented language influenced by C++, Python, and JavaScript.

### Key Solidity Concepts:
1. Contract Structure:
   ```solidity
   pragma solidity ^0.8.0;

   contract MyContract {
       // State variables
       uint public myVariable;

       // Constructor
       constructor() {
           myVariable = 0;
       }

       // Functions
       function setValue(uint _newValue) public {
           myVariable = _newValue;
       }
   }
   ```

2. Data Types:
   - Value Types: bool, int, uint, address, bytes
   - Reference Types: arrays, structs, mappings

3. Functions:
   - Function Visibility: public, private, internal, external
   - Function Modifiers: view, pure, payable

4. Events:
   ```solidity
   event ValueChanged(uint oldValue, uint newValue);
   ```

5. Inheritance and Interfaces

6. Error Handling:
   - require(), assert(), revert()

## 3. Creating and Deploying Simple Smart Contracts

### Step-by-step Guide:
1. Set up development environment:
   - Install Node.js and npm
   - Install Truffle: `npm install -g truffle`
   - Install Ganache for local blockchain simulation

2. Create a new Truffle project:
   ```
   mkdir my_contract
   cd my_contract
   truffle init
   ```

3. Write a simple smart contract (e.g., a basic token):
   ```solidity
   // contracts/SimpleToken.sol
   pragma solidity ^0.8.0;

   contract SimpleToken {
       string public name = "SimpleToken";
       string public symbol = "SIM";
       uint256 public totalSupply = 1000000;
       mapping(address => uint256) public balanceOf;

       constructor() {
           balanceOf[msg.sender] = totalSupply;
       }

       function transfer(address _to, uint256 _value) public returns (bool success) {
           require(balanceOf[msg.sender] >= _value, "Insufficient balance");
           balanceOf[msg.sender] -= _value;
           balanceOf[_to] += _value;
           return true;
       }
   }
   ```

4. Compile the contract:
   ```
   truffle compile
   ```

5. Create a migration script:
   ```javascript
   // migrations/2_deploy_simple_token.js
   const SimpleToken = artifacts.require("SimpleToken");

   module.exports = function(deployer) {
     deployer.deploy(SimpleToken);
   };
   ```

6. Deploy to local network:
   ```
   truffle migrate
   ```

## 4. Interacting with Smart Contracts using Python

Python's `web3.py` library allows interaction with Ethereum smart contracts. Here's a basic example:

```python
from web3 import Web3

# Connect to Ethereum node
w3 = Web3(Web3.HTTPProvider('http://localhost:8545'))

# Contract ABI and address
contract_address = '0x...'  # Replace with actual contract address
contract_abi = [...]  # Replace with actual ABI

# Create contract instance
contract = w3.eth.contract(address=contract_address, abi=contract_abi)

# Call contract function
balance = contract.functions.balanceOf(w3.eth.accounts[0]).call()
print(f"Balance: {balance}")

# Send transaction
tx_hash = contract.functions.transfer(w3.eth.accounts[1], 100).transact({'from': w3.eth.accounts[0]})
receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
print(f"Transaction receipt: {receipt}")
```

## 5. Gas Optimization and Best Practices

Gas is the fuel that powers operations on the Ethereum network. Optimizing gas usage is crucial for creating efficient and cost-effective smart contracts.

### Gas Optimization Techniques:
1. Use appropriate data types (e.g., uint8 instead of uint256 for small numbers)
2. Avoid unnecessary storage operations
3. Batch operations when possible
4. Use libraries for common functions
5. Optimize loops and avoid unbounded loops

### Best Practices:
1. Follow established design patterns (e.g., Checks-Effects-Interactions)
2. Use the latest stable Solidity version
3. Implement access control mechanisms
4. Use SafeMath for arithmetic operations
5. Thoroughly test and audit your contracts

## 6. Testing Smart Contracts

Testing is crucial for ensuring the correctness and security of smart contracts. Truffle provides a testing framework that allows writing tests in JavaScript and Solidity.

### JavaScript Tests:
```javascript
const SimpleToken = artifacts.require("SimpleToken");

contract("SimpleToken", (accounts) => {
  it("should put 1000000 SimpleToken in the first account", async () => {
    const simpleTokenInstance = await SimpleToken.deployed();
    const balance = await simpleTokenInstance.balanceOf.call(accounts[0]);
    assert.equal(balance.toNumber(), 1000000, "1000000 wasn't in the first account");
  });

  it("should transfer tokens correctly", async () => {
    const simpleTokenInstance = await SimpleToken.deployed();
    
    // Transfer 100 tokens from account 0 to 1
    await simpleTokenInstance.transfer(accounts[1], 100, { from: accounts[0] });

    // Get balances of first and second account after the transfer
    const account0Balance = await simpleTokenInstance.balanceOf.call(accounts[0]);
    const account1Balance = await simpleTokenInstance.balanceOf.call(accounts[1]);

    assert.equal(account0Balance.toNumber(), 999900, "Amount wasn't correctly taken from the sender");
    assert.equal(account1Balance.toNumber(), 100, "Amount wasn't correctly sent to the receiver");
  });
});
```

To run tests:
```
truffle test
```

## Conclusion and Next Steps

This lesson has introduced you to smart contracts, Ethereum, and the basics of Solidity programming. You've learned how to create, deploy, and interact with smart contracts, as well as important considerations like gas optimization and testing.

In the next lesson, we'll dive deeper into advanced blockchain concepts, exploring scaling solutions, privacy features, and cross-chain interoperability.

## Additional Resources
1. Ethereum Official Documentation: https://ethereum.org/developers/
2. Solidity Documentation: https://docs.soliditylang.org/
3. OpenZeppelin Contracts: https://github.com/OpenZeppelin/openzeppelin-contracts
4. Web3.py Documentation: https://web3py.readthedocs.io/
5. "Mastering Ethereum" by Andreas M. Antonopoulos and Gavin Wood

