# Lesson 7: Wallets and Transactions

## Overview
In this lesson, we'll delve into the crucial components of cryptocurrency ecosystems: wallets and transactions. We'll explore how to create and manage cryptocurrency wallets, implement more complex transaction structures, and handle transaction verification and signing. This lesson will also touch on multi-signature wallets and provide an introduction to hardware wallet integration.

## Learning Objectives
By the end of this lesson, you will be able to:
1. Understand the concept and importance of cryptocurrency wallets
2. Create a basic cryptocurrency wallet using Python
3. Generate and manage public/private key pairs
4. Implement a more complex transaction structure
5. Verify and sign transactions
6. Understand the concept of multi-signature wallets
7. Gain an introductory understanding of hardware wallet integration

## File Structure
We'll extend our existing project structure with new files for wallets and transactions:

```
blockchain_network/
│
├── blockchain/
│   ├── __init__.py
│   ├── block.py
│   ├── blockchain.py
│   ├── transaction.py
│   └── proof_of_work.py
│
├── wallet/
│   ├── __init__.py
│   ├── wallet.py
│   └── key_pair.py
│
├── networking/
│   ├── __init__.py
│   ├── node.py
│   ├── message.py
│   └── peer_manager.py
│
├── main.py
└── requirements.txt
```

## Detailed Lesson Content

### 1. Understanding Cryptocurrency Wallets

Cryptocurrency wallets are essential tools in the blockchain ecosystem. Despite their name, wallets don't actually store cryptocurrencies. Instead, they store the cryptographic keys that give you access to your blockchain addresses and, consequently, your funds.

Key points about cryptocurrency wallets:

- They manage private and public key pairs
- They interact with various blockchain networks to monitor balances and send transactions
- They can be software-based (hot wallets) or hardware-based (cold wallets)
- They come in various forms: desktop wallets, mobile wallets, web wallets, and hardware wallets

In essence, a wallet is an interface to the blockchain, allowing users to manage their blockchain identities and make transactions.

### 2. Creating a Basic Cryptocurrency Wallet

Let's start by implementing a basic wallet class. We'll create this in `wallet/wallet.py`:

```python
import os
from .key_pair import KeyPair

class Wallet:
    def __init__(self):
        self.key_pairs = []
        self.addresses = []

    def create_new_address(self):
        key_pair = KeyPair()
        self.key_pairs.append(key_pair)
        address = key_pair.get_address()
        self.addresses.append(address)
        return address

    def get_balance(self, blockchain, address):
        balance = 0
        for block in blockchain.chain:
            for tx in block.transactions:
                if tx.recipient == address:
                    balance += tx.amount
                if tx.sender == address:
                    balance -= tx.amount
        return balance

    def create_transaction(self, sender, recipient, amount, blockchain):
        if sender not in self.addresses:
            raise ValueError("Sender address not found in wallet")
        
        sender_balance = self.get_balance(blockchain, sender)
        if sender_balance < amount:
            raise ValueError("Insufficient funds")

        key_pair = next(kp for kp in self.key_pairs if kp.get_address() == sender)
        transaction = Transaction(sender, recipient, amount)
        transaction.sign(key_pair)
        return transaction

    def export_to_file(self, filename):
        with open(filename, 'w') as f:
            for key_pair in self.key_pairs:
                f.write(f"{key_pair.private_key.hex()},{key_pair.public_key.hex()}\n")

    @classmethod
    def import_from_file(cls, filename):
        wallet = cls()
        with open(filename, 'r') as f:
            for line in f:
                private_key, public_key = line.strip().split(',')
                key_pair = KeyPair.from_keys(bytes.fromhex(private_key), bytes.fromhex(public_key))
                wallet.key_pairs.append(key_pair)
                wallet.addresses.append(key_pair.get_address())
        return wallet
```

This `Wallet` class provides basic functionality for managing addresses, creating transactions, and checking balances. It also includes methods for exporting and importing wallet data, which is crucial for backup and recovery purposes.

### 3. Generating and Managing Public/Private Key Pairs

The core of a cryptocurrency wallet is its ability to manage cryptographic key pairs. Let's implement a `KeyPair` class in `wallet/key_pair.py`:

```python
import hashlib
from ecdsa import SigningKey, SECP256k1
import base58

class KeyPair:
    def __init__(self):
        self.private_key = SigningKey.generate(curve=SECP256k1)
        self.public_key = self.private_key.get_verifying_key()

    @classmethod
    def from_keys(cls, private_key, public_key):
        instance = cls.__new__(cls)
        instance.private_key = SigningKey.from_string(private_key, curve=SECP256k1)
        instance.public_key = instance.private_key.get_verifying_key()
        return instance

    def get_address(self):
        public_key_bytes = self.public_key.to_string()
        sha256_hash = hashlib.sha256(public_key_bytes).digest()
        ripemd160_hash = hashlib.new('ripemd160', sha256_hash).digest()
        version_byte = b'\x00'  # Mainnet version byte
        full_hash = version_byte + ripemd160_hash
        checksum = hashlib.sha256(hashlib.sha256(full_hash).digest()).digest()[:4]
        address_bytes = full_hash + checksum
        return base58.b58encode(address_bytes).decode('utf-8')

    def sign(self, message):
        return self.private_key.sign(message)

    def verify(self, signature, message):
        return self.public_key.verify(signature, message)
```

This `KeyPair` class uses the ECDSA (Elliptic Curve Digital Signature Algorithm) to generate and manage key pairs. It also implements methods for creating Bitcoin-style addresses and for signing and verifying messages.

### 4. Implementing a Complex Transaction Structure

Now, let's enhance our `Transaction` class to include more features. We'll update `blockchain/transaction.py`:

```python
import time
import json
import hashlib

class Transaction:
    def __init__(self, sender, recipient, amount):
        self.sender = sender
        self.recipient = recipient
        self.amount = amount
        self.timestamp = int(time.time())
        self.signature = None
        self.transaction_id = self.calculate_hash()

    def calculate_hash(self):
        transaction_string = json.dumps({
            'sender': self.sender,
            'recipient': self.recipient,
            'amount': self.amount,
            'timestamp': self.timestamp
        }, sort_keys=True).encode()
        return hashlib.sha256(transaction_string).hexdigest()

    def sign(self, key_pair):
        if key_pair.get_address() != self.sender:
            raise ValueError("You cannot sign transactions for other wallets!")
        
        transaction_hash = self.calculate_hash().encode()
        self.signature = key_pair.sign(transaction_hash)

    def is_valid(self):
        if self.sender == "0":  # Mining reward
            return True
        
        if not self.signature or len(self.signature) == 0:
            raise ValueError("No signature in this transaction")
        
        from .wallet import Wallet  # Avoid circular import
        public_key = Wallet.address_to_public_key(self.sender)
        transaction_hash = self.calculate_hash().encode()
        return public_key.verify(self.signature, transaction_hash)
```

This enhanced `Transaction` class includes methods for calculating a unique transaction hash, signing transactions, and verifying transaction validity.

### 5. Verifying and Signing Transactions

Transaction verification and signing are crucial for maintaining the integrity and security of the blockchain. Let's add methods to our `Blockchain` class to handle these operations:

```python
class Blockchain:
    # ... (previous methods) ...

    def add_transaction(self, transaction):
        if not transaction.is_valid():
            raise ValueError("Cannot add invalid transaction to chain")
        
        self.pending_transactions.append(transaction)

    def mine_pending_transactions(self, miner_address):
        if not self.pending_transactions:
            return False
        
        new_block = Block(len(self.chain), self.get_latest_block().hash, self.pending_transactions)
        new_block.mine_block(self.difficulty)
        
        if self.add_block(new_block):
            self.pending_transactions = [
                Transaction("0", miner_address, self.mining_reward)  # Mining reward
            ]
            return True
        return False
```

These methods ensure that only valid transactions are added to the blockchain and provide a mechanism for mining pending transactions and rewarding miners.

### 6. Multi-Signature Wallets

Multi-signature (multisig) wallets add an extra layer of security by requiring multiple signatures to authorize a transaction. This is particularly useful for shared accounts or for adding additional security to high-value wallets.

Here's a basic implementation of a multisig transaction:

```python
class MultisigTransaction(Transaction):
    def __init__(self, sender, recipient, amount, required_signatures):
        super().__init__(sender, recipient, amount)
        self.required_signatures = required_signatures
        self.signatures = []

    def sign(self, key_pair):
        if len(self.signatures) >= self.required_signatures:
            raise ValueError("Transaction already has the required number of signatures")
        
        signature = super().sign(key_pair)
        self.signatures.append(signature)

    def is_valid(self):
        if len(self.signatures) < self.required_signatures:
            return False
        
        # Verify all signatures
        transaction_hash = self.calculate_hash().encode()
        for signature in self.signatures:
            if not any(key_pair.verify(signature, transaction_hash) for key_pair in self.sender.key_pairs):
                return False
        
        return True
```

This `MultisigTransaction` class extends our basic `Transaction` class to require multiple signatures before a transaction is considered valid.

### 7. Introduction to Hardware Wallet Integration

Hardware wallets are physical devices that store private keys offline, providing an extra layer of security. While implementing a full hardware wallet integration is beyond the scope of this lesson, we can discuss the basic principles and provide a simple example of how our software might interact with a hardware wallet.

The key aspects of hardware wallet integration include:

1. Communication protocol: Most hardware wallets communicate via USB HID (Human Interface Device) protocol.
2. Key management: Private keys never leave the device; instead, the device signs transactions internally.
3. Transaction verification: Users must physically confirm transactions on the device.

Here's a conceptual example of how we might integrate with a hardware wallet:

```python
from hardware_wallet_lib import HardwareWallet  # This is a hypothetical library

class HardwareWalletInterface:
    def __init__(self):
        self.hw_wallet = HardwareWallet()

    def get_address(self):
        return self.hw_wallet.get_public_key()

    def sign_transaction(self, transaction):
        # Send transaction details to the hardware wallet
        tx_details = {
            'sender': transaction.sender,
            'recipient': transaction.recipient,
            'amount': transaction.amount,
            'fee': transaction.fee
        }
        
        # User confirms on the device
        if self.hw_wallet.confirm_transaction(tx_details):
            # Hardware wallet signs the transaction
            signature = self.hw_wallet.sign_transaction(transaction.calculate_hash())
            transaction.signature = signature
            return True
        return False
```

This example demonstrates how a software wallet might interact with a hardware wallet for key operations like getting an address or signing a transaction.

## Conclusion

In this lesson, we've explored the fundamental concepts of cryptocurrency wallets and transactions. We've implemented basic wallet functionality, including key pair generation and management, transaction creation and signing, and balance checking. We've also touched on more advanced concepts like multi-signature wallets and hardware wallet integration.

These components form the core of how users interact with blockchain networks, enabling secure ownership and transfer of digital assets. As you continue to develop your blockchain application, remember that wallet and transaction security are paramount – they are the primary interface between users and the blockchain.

## Exercises

1. Implement a simple command-line interface for your wallet, allowing users to create new addresses, check balances, and send transactions.
2. Extend the `Wallet` class to support multiple cryptocurrencies (you'll need to implement different address generation schemes for each).
3. Implement a basic version of a hierarchical deterministic (HD) wallet, which generates a tree of key pairs from a single seed.
4. Create a more advanced multisig wallet that requires M-of-N signatures (e.g., 2 out of 3) to authorize a transaction.
5. Research and implement a basic version of a paper wallet generator, which creates printable wallets for cold storage.

## Additional Resources

- "Mastering Bitcoin" by Andreas M. Antonopoulos (Chapters on Wallets and Transactions)
- BIP39 for Mnemonic code generation: https://github.com/bitcoin/bips/blob/master/bip-0039.mediawiki
- Python ECDSA library documentation: https://github.com/warner/python-ecdsa
- Trezor hardware wallet developer resources: https://wiki.trezor.io/Developers_guide
- "Programming Bitcoin" by Jimmy Song (for a deep dive into Bitcoin-specific wallet implementations)

In the next lesson, we'll explore smart contracts and the Ethereum platform, learning how to create, deploy, and interact with smart contracts using Python.
