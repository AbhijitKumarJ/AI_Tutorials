# Lesson 3: Cryptography Basics

## Lesson Objectives
By the end of this lesson, students will be able to:
1. Understand the fundamental concepts of cryptography and its importance in blockchain technology
2. Distinguish between symmetric and asymmetric encryption methods
3. Explain the purpose and function of hash functions, particularly SHA-256 and Keccak
4. Comprehend the concept of digital signatures and their role in blockchain transactions
5. Understand the principles of public and private keys
6. Grasp the basics of key derivation and management in cryptocurrency systems

## Lesson Content

### 1. Introduction to Cryptography

Cryptography is the practice and study of techniques for secure communication in the presence of adversaries. In the context of blockchain and cryptocurrencies, cryptography plays a crucial role in ensuring the security, integrity, and privacy of transactions and user data.

Key aspects of cryptography in blockchain:
- Securing transactions: Ensuring that only the rightful owner can spend their funds
- Maintaining privacy: Protecting user identities and transaction details
- Ensuring data integrity: Preventing unauthorized modifications to the blockchain
- Consensus mechanisms: Enabling agreement on the state of the blockchain across a distributed network

Historical context:
- Ancient cryptography: Simple substitution ciphers (e.g., Caesar cipher)
- World War II: Machine-based encryption (e.g., Enigma machine)
- Modern era: Development of complex mathematical algorithms for encryption

### 2. Symmetric vs. Asymmetric Encryption

#### Symmetric Encryption
In symmetric encryption, the same key is used for both encryption and decryption of the data.

Key characteristics:
- Fast and efficient for large amounts of data
- Requires secure key exchange between parties
- Examples: AES (Advanced Encryption Standard), DES (Data Encryption Standard)

Process:
1. Sender and recipient agree on a secret key
2. Sender encrypts the message using the secret key
3. Recipient decrypts the message using the same secret key

Advantages:
- Fast encryption and decryption
- Efficient for large data sets

Disadvantages:
- Key distribution problem: How to securely share the key?
- Scalability issues in systems with many users

#### Asymmetric Encryption (Public Key Cryptography)
Asymmetric encryption uses a pair of keys: a public key for encryption and a private key for decryption.

Key characteristics:
- Slower than symmetric encryption but solves the key distribution problem
- Enables secure communication without prior key exchange
- Examples: RSA, ECC (Elliptic Curve Cryptography)

Process:
1. Each user generates a key pair: public and private
2. Public key is shared openly, private key is kept secret
3. Sender encrypts message using recipient's public key
4. Recipient decrypts message using their private key

Advantages:
- Solves key distribution problem
- Enables digital signatures
- Provides basis for secure key exchange protocols

Disadvantages:
- Slower than symmetric encryption
- Requires more computational resources

### 3. Hash Functions (SHA-256, Keccak)

A hash function is a mathematical algorithm that takes an input (or 'message') and returns a fixed-size string of bytes. The output, called the hash value or digest, is unique to each unique input.

Key properties of cryptographic hash functions:
- Deterministic: Same input always produces the same output
- Quick to compute the hash value for any given input
- Infeasible to generate a message from its hash value
- Infeasible to find two different messages with the same hash value
- A small change to a message should change the hash value so extensively that it appears uncorrelated with the old hash value

#### SHA-256 (Secure Hash Algorithm 256-bit)
- Used in Bitcoin and many other cryptocurrencies
- Produces a 256-bit (32-byte) hash value
- Part of the SHA-2 family designed by the U.S. National Security Agency

Example in Python:
```python
import hashlib

message = "Hello, Blockchain!"
hash_object = hashlib.sha256(message.encode())
hex_dig = hash_object.hexdigest()
print(hex_dig)
# Output: 872e4e50ce9990d8b041330c47c9ddd11bec6b503ae9386a99da8584e9bb12c4
```

#### Keccak (SHA-3)
- Used in Ethereum (a variant called Keccak-256)
- Designed to be different from SHA-2 to provide an alternative in case SHA-2 is broken
- Produces hash values of arbitrary length

Example in Python (using pycryptodome library):
```python
from Crypto.Hash import keccak

message = "Hello, Blockchain!"
keccak_hash = keccak.new(digest_bits=256)
keccak_hash.update(message.encode())
hex_dig = keccak_hash.hexdigest()
print(hex_dig)
# Output: 7dddf4bc9b86352b67e8823e5010ddbc2ce3ef9e92af93c85ec50f61defb0fe6
```

### 4. Digital Signatures

Digital signatures are a cryptographic mechanism that provides authentication, non-repudiation, and integrity to digital messages or documents.

Key aspects of digital signatures:
- Based on asymmetric cryptography
- Provide proof of origin, identity, and status of an electronic document
- Ensure that the message hasn't been altered in transit

Process of creating and verifying a digital signature:
1. Creation:
   - Hash the message to create a digest
   - Encrypt the digest with the sender's private key
2. Verification:
   - Recipient decrypts the signature using the sender's public key
   - Independently hashes the received message
   - Compares the decrypted hash with the independently created hash

Use in blockchain:
- Signing transactions to prove ownership of funds
- Ensuring the integrity of blocks and transactions

Example of signing and verifying in Python (using pycryptodome):
```python
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

# Generate key pair
key = RSA.generate(2048)
private_key = key.export_key()
public_key = key.publickey().export_key()

# Sign message
message = b"Transaction data"
hash_obj = SHA256.new(message)
signature = pkcs1_15.new(RSA.import_key(private_key)).sign(hash_obj)

# Verify signature
public_key_obj = RSA.import_key(public_key)
try:
    pkcs1_15.new(public_key_obj).verify(hash_obj, signature)
    print("Signature is valid.")
except (ValueError, TypeError):
    print("Signature is invalid.")
```

### 5. Public and Private Keys

In asymmetric cryptography, each user has a pair of keys: a public key and a private key.

#### Public Key
- Freely shared with everyone
- Used to encrypt messages or verify digital signatures
- In cryptocurrencies, often used as the address to receive funds

#### Private Key
- Kept secret by the owner
- Used to decrypt messages or create digital signatures
- In cryptocurrencies, proves ownership of funds and allows spending

Key pair generation:
- Based on complex mathematical problems (e.g., factoring large numbers for RSA)
- Elliptic Curve Cryptography (ECC) often used in blockchain for smaller key sizes

Relationship between keys:
- Mathematically related but computationally infeasible to derive the private key from the public key
- Public key can be derived from the private key, but not vice versa

### 6. Key Derivation and Management

Key derivation is the process of generating one or more keys from a master key or a passphrase. Proper key management is crucial for the security of cryptocurrency wallets and blockchain systems.

#### Key Derivation Functions (KDFs)
- Purpose: Generate secure keys from passwords or other input data
- Examples: PBKDF2, bcrypt, scrypt
- Properties: Slow to compute, use salt to prevent rainbow table attacks

#### Hierarchical Deterministic (HD) Wallets
- Generate a tree of key pairs from a single seed
- Allows for the creation of multiple addresses from one master key
- Improves privacy and backup/restore processes

BIP39 (Bitcoin Improvement Proposal 39):
- Standard for generating mnemonic phrases (seed phrases)
- Converts a random number into a sequence of words for easy backup

Example of creating a BIP39 mnemonic and deriving keys (using `mnemonic` and `bip_utils` libraries):
```python
from mnemonic import Mnemonic
from bip_utils import Bip39SeedGenerator, Bip44, Bip44Coins, Bip44Changes

# Generate mnemonic
mnemo = Mnemonic("english")
mnemonic_phrase = mnemo.generate(strength=256)
print("Mnemonic:", mnemonic_phrase)

# Generate seed
seed_bytes = Bip39SeedGenerator(mnemonic_phrase).Generate()

# Derive Bitcoin keys
bip44_mst_ctx = Bip44.FromSeed(seed_bytes, Bip44Coins.BITCOIN)
bip44_acc_ctx = bip44_mst_ctx.Purpose().Coin().Account(0)
bip44_chg_ctx = bip44_acc_ctx.Change(Bip44Changes.CHAIN_EXT)

# Generate first address
bip44_addr_ctx = bip44_chg_ctx.AddressIndex(0)
print("Bitcoin address:", bip44_addr_ctx.PublicKey().ToAddress())
print("Private key:", bip44_addr_ctx.PrivateKey().Raw().ToHex())
```

Key management best practices:
1. Use hardware wallets for large amounts
2. Employ multi-signature schemes for added security
3. Regularly backup keys and seed phrases
4. Use strong passwords and 2-factor authentication
5. Be cautious of phishing attempts and malware

## Hands-on Exercise

Create a simple program that demonstrates the use of asymmetric encryption and digital signatures:

```python
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

def generate_key_pair():
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    return private_key, public_key

def encrypt_message(message, public_key):
    key = RSA.import_key(public_key)
    cipher = PKCS1_OAEP.new(key)
    encrypted_message = cipher.encrypt(message.encode())
    return encrypted_message

def decrypt_message(encrypted_message, private_key):
    key = RSA.import_key(private_key)
    cipher = PKCS1_OAEP.new(key)
    decrypted_message = cipher.decrypt(encrypted_message)
    return decrypted_message.decode()

def sign_message(message, private_key):
    key = RSA.import_key(private_key)
    hash_obj = SHA256.new(message.encode())
    signature = pkcs1_15.new(key).sign(hash_obj)
    return signature

def verify_signature(message, signature, public_key):
    key = RSA.import_key(public_key)
    hash_obj = SHA256.new(message.encode())
    try:
        pkcs1_15.new(key).verify(hash_obj, signature)
        return True
    except (ValueError, TypeError):
        return False

# Usage
alice_private_key, alice_public_key = generate_key_pair()
bob_private_key, bob_public_key = generate_key_pair()

message = "Hello, Bob! This is a secret message from Alice."
encrypted_message = encrypt_message(message, bob_public_key)
decrypted_message = decrypt_message(encrypted_message, bob_private_key)

signature = sign_message(message, alice_private_key)
is_valid = verify_signature(message, signature, alice_public_key)

print(f"Original message: {message}")
print(f"Decrypted message: {decrypted_message}")
print(f"Signature valid: {is_valid}")
```

## Review and Quiz

1. What is the main difference between symmetric and asymmetric encryption?
2. Explain the concept of a hash function and its importance in blockchain technology.
3. How do digital signatures ensure the authenticity and integrity of a message?
4. What is the relationship between public and private keys in asymmetric cryptography?
5. Describe the purpose of a key derivation function and give an example of its use in cryptocurrency wallets.

## Additional Resources

1. "Cryptography and Network Security: Principles and Practice" by William Stallings
2. Online course: "Cryptography I" by Stanford University on Coursera
3. "Mastering Bitcoin" by Andreas M. Antonopoulos (Chapter 4: Keys, Addresses, Wallets)
4. "Serious Cryptography: A Practical Introduction to Modern Encryption" by Jean-Philippe Aumasson
5. BIP39 specification: https://github.com/bitcoin/bips/blob/master/bip-0039.mediawiki

## Preparation for Next Lesson

In the next lesson, we'll start applying our knowledge of blockchain and cryptography to practical programming. We'll set up a Python development environment and explore basic Python syntax and data structures. We'll also introduce some blockchain-related Python libraries that will be essential for our future projects. Make sure you have Python installed on your system before the next lesson.

