# Lesson 2: Blockchain Fundamentals

## Lesson Objectives
By the end of this lesson, students will be able to:
1. Understand the basic structure and components of a blockchain
2. Explain the concepts of blocks, transactions, and hashes
3. Comprehend the purpose and function of Merkle trees in blockchain
4. Differentiate between various consensus mechanisms, particularly Proof of Work and Proof of Stake
5. Grasp the basic concept of smart contracts
6. Compare different blockchain architectures

## Lesson Content

### 1. Blockchain Structure and Components

A blockchain is a distributed ledger that records transactions across many computers in a way that ensures the integrity and security of the data. The fundamental components of a blockchain include:

- Nodes: Computers that participate in the network, maintaining a copy of the blockchain
- Transactions: Records of data transfer or state change within the system
- Blocks: Groups of transactions bundled together
- Chain: The sequence of blocks, each referencing the previous block
- Consensus Mechanism: The process by which nodes agree on the state of the blockchain

The blockchain's structure provides several key benefits:
- Immutability: Once data is recorded, it's extremely difficult to change
- Transparency: All transactions are visible to all participants
- Decentralization: No single entity has control over the entire system

### 2. Blocks, Transactions, and Hashes

#### Blocks
A block in a blockchain typically contains:
- Block Header: Metadata about the block
- Transaction Data: A list of all transactions included in the block
- Block Hash: A unique identifier for the block

The block header usually includes:
- Previous Block Hash: Links the current block to the previous one, forming the chain
- Timestamp: When the block was created
- Nonce: A number used in the mining process (for Proof of Work systems)
- Merkle Root: A hash representing all transactions in the block

#### Transactions
Transactions are the basic units of data in a blockchain. They typically include:
- Sender's Address
- Recipient's Address
- Amount or Data being transferred
- Digital Signature: Proves the transaction was initiated by the sender

#### Hashes
A hash is a fixed-size string of characters generated from input data of any size. In blockchain:
- Each block has a unique hash
- Changing any data in the block changes its hash
- Hashes link blocks together, creating the chain
- Common hash functions in blockchain: SHA-256 (Bitcoin), Keccak-256 (Ethereum)

### 3. Merkle Trees

A Merkle tree, also known as a hash tree, is a data structure used in blockchain to efficiently verify the integrity of large datasets.

Key points about Merkle trees:
- Transactions in a block are hashed and paired repeatedly until a single hash (the Merkle root) is obtained
- Allows for quick verification of whether a transaction is included in a block
- Enables "light clients" to verify transactions without downloading the entire blockchain
- Improves scalability and reduces storage requirements

Process of creating a Merkle tree:
1. Hash all individual transactions
2. Pair and hash the results
3. Repeat the pairing and hashing until a single hash (Merkle root) is obtained

Benefits of Merkle trees:
- Efficient verification of large datasets
- Reduces the amount of data needed to verify transactions
- Enhances privacy by allowing proof of inclusion without revealing all transactions

### 4. Consensus Mechanisms (Proof of Work, Proof of Stake)

Consensus mechanisms are protocols that ensure all nodes in a blockchain network agree on the current state of the blockchain.

#### Proof of Work (PoW)
Used by Bitcoin and originally by Ethereum, PoW requires nodes (miners) to solve complex mathematical puzzles to add new blocks.

Key aspects of PoW:
- Miners compete to solve a cryptographic puzzle
- The first to solve the puzzle gets to add the next block and receive a reward
- Requires significant computational power and energy
- Provides strong security against attacks, but at the cost of efficiency

#### Proof of Stake (PoS)
An alternative to PoW, used by newer blockchains and the upgraded Ethereum 2.0.

Key aspects of PoS:
- Validators are chosen to create new blocks based on the amount of cryptocurrency they "stake" as collateral
- More energy-efficient than PoW
- Potentially faster transaction processing
- Critics argue it may lead to centralization as wealthy stakeholders gain more control

Other consensus mechanisms:
- Delegated Proof of Stake (DPoS)
- Practical Byzantine Fault Tolerance (PBFT)
- Proof of Authority (PoA)

### 5. Smart Contracts Introduction

Smart contracts are self-executing contracts with the terms of the agreement directly written into code.

Key features of smart contracts:
- Automatically execute when predetermined conditions are met
- Run on blockchain networks, particularly those with advanced scripting capabilities like Ethereum
- Reduce the need for intermediaries in many processes
- Can handle complex logic and interact with other smart contracts

Applications of smart contracts:
- Decentralized Finance (DeFi) protocols
- Automated token distributions
- Decentralized Autonomous Organizations (DAOs)
- Supply chain management

Limitations and challenges:
- Immutability: Once deployed, they're difficult to modify
- Security: Vulnerabilities in the code can lead to significant losses
- Scalability: Can be resource-intensive on some blockchain networks

### 6. Comparison of Different Blockchain Architectures

Blockchain architectures can vary significantly based on their design goals and use cases.

#### Public Blockchains
Examples: Bitcoin, Ethereum
- Open to anyone to participate
- Highly decentralized and transparent
- Slower transaction processing due to large network size
- High level of security through decentralization

#### Private Blockchains
Examples: Hyperledger Fabric, R3 Corda
- Restricted to approved participants
- Faster and more scalable than public blockchains
- Less decentralized, which may compromise some security benefits
- Often used in enterprise settings

#### Consortium Blockchains
Examples: Energy Web Chain, Quorum
- Partially decentralized, controlled by a group of organizations
- Balance between the benefits of public and private blockchains
- Used in industry-specific applications

#### Layer 2 Solutions
Examples: Bitcoin Lightning Network, Ethereum Plasma
- Built on top of existing blockchains to improve scalability
- Offload some transactions from the main chain
- Can significantly increase transaction speed and reduce costs

Comparison factors:
- Scalability: Transaction speed and network capacity
- Security: Resistance to attacks and data integrity
- Decentralization: Distribution of control and decision-making
- Privacy: Level of anonymity and data protection
- Interoperability: Ability to communicate with other blockchain networks

## Hands-on Exercise

Implement a basic block structure and hashing mechanism in Python:

```python
import hashlib
import time

class Block:
    def __init__(self, index, transactions, previous_hash):
        self.index = index
        self.timestamp = time.time()
        self.transactions = transactions
        self.previous_hash = previous_hash
        self.nonce = 0
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        block_string = f"{self.index}{self.timestamp}{self.transactions}{self.previous_hash}{self.nonce}"
        return hashlib.sha256(block_string.encode()).hexdigest()

    def mine_block(self, difficulty):
        target = "0" * difficulty
        while self.hash[:difficulty] != target:
            self.nonce += 1
            self.hash = self.calculate_hash()
        print(f"Block mined: {self.hash}")

class Blockchain:
    def __init__(self):
        self.chain = [self.create_genesis_block()]
        self.difficulty = 4

    def create_genesis_block(self):
        return Block(0, "Genesis Block", "0")

    def get_latest_block(self):
        return self.chain[-1]

    def add_block(self, new_block):
        new_block.previous_hash = self.get_latest_block().hash
        new_block.mine_block(self.difficulty)
        self.chain.append(new_block)

# Create a blockchain and add some blocks
blockchain = Blockchain()

blockchain.add_block(Block(1, "Transaction 1", ""))
blockchain.add_block(Block(2, "Transaction 2", ""))

# Print the blockchain
for block in blockchain.chain:
    print(f"Block #{block.index}")
    print(f"Timestamp: {block.timestamp}")
    print(f"Transactions: {block.transactions}")
    print(f"Previous Hash: {block.previous_hash}")
    print(f"Hash: {block.hash}")
    print("\n")
```

## Review and Quiz

1. What are the main components of a block in a blockchain?
2. Explain the purpose of a Merkle tree in blockchain technology.
3. What is the primary difference between Proof of Work and Proof of Stake consensus mechanisms?
4. Define a smart contract and give an example of its potential use.
5. Compare public and private blockchains in terms of accessibility and speed.

## Additional Resources

1. "Mastering Bitcoin" by Andreas M. Antonopoulos (for deep dive into Bitcoin's architecture)
2. Ethereum Whitepaper: https://ethereum.org/en/whitepaper/ (for understanding smart contracts and alternative blockchain designs)
3. "Blockchain Basics: A Non-Technical Introduction in 25 Steps" by Daniel Drescher
4. Coursera course: "Blockchain Specialization" by University at Buffalo
5. GitHub repository: https://github.com/bitcoinbook/bitcoinbook (open-source book on Bitcoin and blockchain)

## Preparation for Next Lesson

In the next lesson, we'll delve into the cryptographic principles that underpin blockchain technology. We'll explore topics such as symmetric and asymmetric encryption, hash functions, digital signatures, and key management. This knowledge will be crucial for understanding the security aspects of blockchain systems.

