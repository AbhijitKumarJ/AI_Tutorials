# Lesson 4: Python Basics for Blockchain

## Lesson Objectives
By the end of this lesson, students will be able to:
1. Set up a Python development environment suitable for blockchain programming
2. Understand and use basic Python syntax and data structures
3. Apply object-oriented programming concepts in Python
4. Work with external libraries using pip and virtual environments
5. Familiarize themselves with web3.py and other blockchain-related Python libraries

## Lesson Content

### 1. Setting up a Python Development Environment

A proper development environment is crucial for efficient and effective programming. For blockchain development with Python, we'll set up the following:

#### Python Installation
- Download and install Python from the official website (https://python.org)
- Ensure you install Python 3.7 or later, as some blockchain libraries require recent versions
- During installation, make sure to check the option to add Python to your system PATH

#### Integrated Development Environment (IDE)
While you can use any text editor, an IDE can significantly improve your productivity. Some popular options include:

- PyCharm: Full-featured IDE with excellent debugging capabilities
- Visual Studio Code: Lightweight, extensible editor with good Python support
- Jupyter Notebooks: Great for interactive development and data analysis

For this course, we recommend Visual Studio Code due to its balance of features and performance.

Steps to set up VS Code for Python:
1. Download and install VS Code from https://code.visualstudio.com/
2. Open VS Code and go to the Extensions view (Ctrl+Shift+X)
3. Search for and install the "Python" extension by Microsoft
4. Open a new file with a .py extension to start coding in Python

#### Version Control with Git
Git is essential for managing your code and collaborating with others. To set it up:

1. Download and install Git from https://git-scm.com/
2. Open a terminal or command prompt and configure Git:
   ```
   git config --global user.name "Your Name"
   git config --global user.email "your.email@example.com"
   ```
3. (Optional) Create a GitHub account for storing your repositories online

### 2. Basic Python Syntax and Data Structures

Python is known for its clear, readable syntax. Here's an overview of key elements:

#### Variables and Data Types
Python is dynamically typed, meaning you don't need to declare variable types explicitly.

```python
# Integer
x = 5

# Float
y = 3.14

# String
name = "Alice"

# Boolean
is_valid = True

# List (mutable)
numbers = [1, 2, 3, 4, 5]

# Tuple (immutable)
coordinates = (10, 20)

# Dictionary
person = {"name": "Bob", "age": 30}

# Set
unique_numbers = {1, 2, 3, 4, 5}
```

#### Control Structures
Python uses indentation to define code blocks.

```python
# If-else statement
if x > 0:
    print("Positive")
elif x < 0:
    print("Negative")
else:
    print("Zero")

# For loop
for i in range(5):
    print(i)

# While loop
while x > 0:
    print(x)
    x -= 1

# List comprehension
squares = [i**2 for i in range(10)]
```

#### Functions
Functions in Python are defined using the `def` keyword.

```python
def greet(name):
    return f"Hello, {name}!"

# Function with default argument
def power(base, exponent=2):
    return base ** exponent

# Lambda function (anonymous function)
square = lambda x: x**2
```

#### Exception Handling
Python uses try-except blocks for exception handling.

```python
try:
    result = 10 / 0
except ZeroDivisionError:
    print("Cannot divide by zero!")
finally:
    print("This always executes")
```

### 3. Object-Oriented Programming in Python

Object-Oriented Programming (OOP) is a programming paradigm that uses objects to structure code. Python is a multi-paradigm language that supports OOP.

#### Classes and Objects
A class is a blueprint for creating objects. Objects are instances of classes.

```python
class Block:
    def __init__(self, data, previous_hash):
        self.data = data
        self.previous_hash = previous_hash
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        # Simplified hash calculation
        return hash(str(self.data) + self.previous_hash)

# Creating an object
genesis_block = Block("Genesis Block", "0")
```

#### Inheritance
Inheritance allows a class to inherit attributes and methods from another class.

```python
class Animal:
    def __init__(self, name):
        self.name = name

    def speak(self):
        pass

class Dog(Animal):
    def speak(self):
        return f"{self.name} says Woof!"

class Cat(Animal):
    def speak(self):
        return f"{self.name} says Meow!"

dog = Dog("Buddy")
print(dog.speak())  # Output: Buddy says Woof!
```

#### Encapsulation
Encapsulation is the bundling of data and the methods that operate on that data within a single unit (class).

```python
class Wallet:
    def __init__(self):
        self.__balance = 0  # Private attribute

    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount

    def withdraw(self, amount):
        if 0 < amount <= self.__balance:
            self.__balance -= amount
            return amount
        return 0

    def get_balance(self):
        return self.__balance

wallet = Wallet()
wallet.deposit(100)
print(wallet.get_balance())  # Output: 100
```

#### Polymorphism
Polymorphism allows objects of different classes to be treated as objects of a common base class.

```python
def make_sound(animal):
    return animal.speak()

dog = Dog("Buddy")
cat = Cat("Whiskers")

print(make_sound(dog))  # Output: Buddy says Woof!
print(make_sound(cat))  # Output: Whiskers says Meow!
```

### 4. Working with External Libraries

Python's ecosystem is rich with libraries that can significantly speed up development. Here's how to work with them:

#### Pip (Python Package Installer)
Pip is the standard package manager for Python. It allows you to install and manage additional libraries.

Basic pip commands:
```
pip install package_name
pip uninstall package_name
pip list
pip freeze > requirements.txt
pip install -r requirements.txt
```

#### Virtual Environments
Virtual environments allow you to create isolated Python environments for your projects, avoiding conflicts between package versions.

Using venv (built-in since Python 3.3):
```
python -m venv myenv
source myenv/bin/activate  # On Windows: myenv\Scripts\activate
deactivate  # To exit the virtual environment
```

#### Managing Project Dependencies
It's a good practice to keep track of your project's dependencies:

1. Create a `requirements.txt` file:
   ```
   pip freeze > requirements.txt
   ```
2. Install dependencies in a new environment:
   ```
   pip install -r requirements.txt
   ```

### 5. Introduction to Web3.py and Other Blockchain-related Python Libraries

Several Python libraries are commonly used in blockchain development. Here's an introduction to some key libraries:

#### Web3.py
Web3.py is a Python library for interacting with Ethereum. It allows you to connect to Ethereum nodes, send transactions, interact with smart contracts, and more.

Installation:
```
pip install web3
```

Basic usage:
```python
from web3 import Web3

# Connect to an Ethereum node
w3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io/v3/YOUR-PROJECT-ID'))

# Check connection
print(w3.isConnected())

# Get latest block number
print(w3.eth.block_number)

# Get balance of an address
balance = w3.eth.get_balance('0x742d35Cc6634C0532925a3b844Bc454e4438f44e')
print(w3.from_wei(balance, 'ether'))
```

#### Bitcoin-related Libraries
For Bitcoin development, consider these libraries:

- `bitcoinlib`: Comprehensive Bitcoin library
- `python-bitcoinlib`: Python Bitcoin library
- `bit`: Bitcoin made easy

Installation example:
```
pip install bitcoinlib
```

#### Cryptography Libraries
These libraries are useful for implementing cryptographic operations:

- `pycryptodome`: Cryptographic library (fork of PyCrypto)
- `ecdsa`: Implementation of ECDSA for Python

Installation example:
```
pip install pycryptodome ecdsa
```

#### Other Useful Libraries
- `requests`: For making HTTP requests
- `flask`: For building web applications
- `sqlalchemy`: For working with databases

## Hands-on Exercise

Let's create a simple program that demonstrates some of the concepts we've learned, including OOP and using an external library.

```python
import hashlib
import time

class Block:
    def __init__(self, index, transactions, previous_hash):
        self.index = index
        self.transactions = transactions
        self.previous_hash = previous_hash
        self.nonce = 0
        self.timestamp = time.time()
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        block_string = f"{self.index}{self.transactions}{self.previous_hash}{self.nonce}{self.timestamp}"
        return hashlib.sha256(block_string.encode()).hexdigest()

    def mine_block(self, difficulty):
        target = "0" * difficulty
        while self.hash[:difficulty] != target:
            self.nonce += 1
            self.hash = self.calculate_hash()
        print(f"Block mined: {self.hash}")

class Blockchain:
    def __init__(self):
        self.chain = [self.create_genesis_block()]
        self.difficulty = 2

    def create_genesis_block(self):
        return Block(0, "Genesis Block", "0")

    def get_latest_block(self):
        return self.chain[-1]

    def add_block(self, new_block):
        new_block.previous_hash = self.get_latest_block().hash
        new_block.mine_block(self.difficulty)
        self.chain.append(new_block)

    def is_chain_valid(self):
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i-1]

            if current_block.hash != current_block.calculate_hash():
                return False

            if current_block.previous_hash != previous_block.hash:
                return False

        return True

# Usage
blockchain = Blockchain()

print("Mining block 1...")
blockchain.add_block(Block(1, "Transaction 1", ""))

print("Mining block 2...")
blockchain.add_block(Block(2, "Transaction 2", ""))

print(f"Is blockchain valid? {blockchain.is_chain_valid()}")

# Tamper with the blockchain
blockchain.chain[1].transactions = "Hacked Transaction"
print(f"Is blockchain valid after tampering? {blockchain.is_chain_valid()}")
```

This exercise demonstrates:
- Object-Oriented Programming (classes and objects)
- Use of an external library (hashlib for SHA-256 hashing)
- Basic blockchain concepts (blocks, mining, chain validation)

## Review and Quiz

1. What are the key components of a Python development environment for blockchain programming?
2. Explain the concept of a virtual environment and why it's useful.
3. How does object-oriented programming in Python support the creation of blockchain structures?
4. What is the purpose of the `web3.py` library, and how might you use it in a blockchain project?
5. In the hands-on exercise, how does the `mine_block` method simulate the mining process?

## Additional Resources

1. Official Python Documentation: https://docs.python.org/3/
2. "Python Crash Course" by Eric Matthes (book for Python beginners)
3. Web3.py Documentation: https://web3py.readthedocs.io/
4. "Mastering Bitcoin" by Andreas M. Antonopoulos (for understanding Bitcoin concepts)
5. Real Python Tutorials: https://realpython.com/ (excellent resource for Python programming)

## Preparation for Next Lesson

In the next lesson, we'll build upon the concepts learned here to create a more comprehensive blockchain implementation in Python. We'll explore topics such as transaction handling, proof of work consensus, and basic networking. Make sure you're comfortable with the Python concepts covered in this lesson, as we'll be using them extensively moving forward.

