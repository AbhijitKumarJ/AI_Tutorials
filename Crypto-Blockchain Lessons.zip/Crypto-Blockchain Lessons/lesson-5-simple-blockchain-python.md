# Lesson 5: Building a Simple Blockchain in Python

## Overview
In this lesson, we'll dive into the practical implementation of a simple blockchain using Python. This hands-on approach will solidify your understanding of blockchain fundamentals and provide you with a working foundation for more complex blockchain applications.

## Learning Objectives
By the end of this lesson, you will be able to:
1. Implement a basic block structure in Python
2. Create and manage a chain of blocks
3. Add transactions to blocks
4. Implement a simple proof of work algorithm
5. Validate the integrity of the blockchain
6. Handle basic chain reorganization

## File Structure
Before we begin, let's set up our project structure:

```
simple_blockchain/
│
├── blockchain.py
├── block.py
├── transaction.py
├── proof_of_work.py
└── main.py
```

## Detailed Lesson Content

### 1. Implementing a Basic Block Structure

We'll start by creating a `Block` class in `block.py`:

```python
import hashlib
import time

class Block:
    def __init__(self, index, previous_hash, transactions, timestamp=None):
        self.index = index
        self.previous_hash = previous_hash
        self.transactions = transactions
        self.timestamp = timestamp or time.time()
        self.nonce = 0
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        block_string = f"{self.index}{self.previous_hash}{self.transactions}{self.timestamp}{self.nonce}"
        return hashlib.sha256(block_string.encode()).hexdigest()

    def mine_block(self, difficulty):
        target = "0" * difficulty
        while self.hash[:difficulty] != target:
            self.nonce += 1
            self.hash = self.calculate_hash()
        print(f"Block mined: {self.hash}")
```

This `Block` class represents the fundamental unit of our blockchain. Each block contains:
- An index (position in the chain)
- The hash of the previous block (creating the chain link)
- A list of transactions
- A timestamp
- A nonce (used in the mining process)
- Its own hash

The `calculate_hash` method creates a unique hash for the block based on its contents. The `mine_block` method implements a simple proof of work algorithm, which we'll discuss in more detail later.

### 2. Creating a Chain of Blocks

Next, we'll implement the `Blockchain` class in `blockchain.py`:

```python
from block import Block

class Blockchain:
    def __init__(self):
        self.chain = [self.create_genesis_block()]
        self.difficulty = 4
        self.pending_transactions = []

    def create_genesis_block(self):
        return Block(0, "0", [])

    def get_latest_block(self):
        return self.chain[-1]

    def add_block(self, new_block):
        new_block.previous_hash = self.get_latest_block().hash
        new_block.mine_block(self.difficulty)
        self.chain.append(new_block)

    def is_chain_valid(self):
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i-1]

            if current_block.hash != current_block.calculate_hash():
                return False

            if current_block.previous_hash != previous_block.hash:
                return False

        return True
```

The `Blockchain` class manages the entire chain of blocks. It includes methods to:
- Create a genesis block (the first block in the chain)
- Add new blocks to the chain
- Validate the integrity of the entire chain

The `is_chain_valid` method checks two key aspects of blockchain integrity:
1. Each block's hash is correctly calculated
2. Each block's `previous_hash` matches the hash of the actual previous block

### 3. Adding Transactions to Blocks

Let's create a simple `Transaction` class in `transaction.py`:

```python
class Transaction:
    def __init__(self, sender, recipient, amount):
        self.sender = sender
        self.recipient = recipient
        self.amount = amount

    def __str__(self):
        return f"{self.sender} -> {self.recipient}: {self.amount}"
```

Now, let's add methods to handle transactions in our `Blockchain` class:

```python
def add_transaction(self, transaction):
    self.pending_transactions.append(transaction)

def mine_pending_transactions(self, miner_address):
    new_block = Block(len(self.chain), self.get_latest_block().hash, self.pending_transactions)
    new_block.mine_block(self.difficulty)
    self.chain.append(new_block)
    self.pending_transactions = [
        Transaction("System", miner_address, 1)  # Mining reward
    ]
```

These methods allow us to:
- Add new transactions to a pool of pending transactions
- Mine a new block containing all pending transactions
- Reward the miner with a new coin transaction

### 4. Implementing a Simple Proof of Work Algorithm

We've already implemented a basic proof of work algorithm in our `Block` class with the `mine_block` method. Let's create a separate `ProofOfWork` class in `proof_of_work.py` for a more flexible implementation:

```python
import hashlib

class ProofOfWork:
    @staticmethod
    def calculate_hash(block):
        block_string = f"{block.index}{block.previous_hash}{block.transactions}{block.timestamp}{block.nonce}"
        return hashlib.sha256(block_string.encode()).hexdigest()

    @staticmethod
    def mine(block, difficulty):
        target = "0" * difficulty
        while block.hash[:difficulty] != target:
            block.nonce += 1
            block.hash = ProofOfWork.calculate_hash(block)
        print(f"Block mined: {block.hash}")
```

This separates the proof of work logic from the `Block` class, allowing for easier modification and experimentation with different mining algorithms.

### 5. Validating the Blockchain

We've already implemented a basic validation method in our `Blockchain` class. Let's enhance it to include transaction validation:

```python
def is_chain_valid(self):
    for i in range(1, len(self.chain)):
        current_block = self.chain[i]
        previous_block = self.chain[i-1]

        if current_block.hash != ProofOfWork.calculate_hash(current_block):
            return False

        if current_block.previous_hash != previous_block.hash:
            return False

        # Validate transactions
        for transaction in current_block.transactions:
            if not self.is_valid_transaction(transaction):
                return False

    return True

def is_valid_transaction(self, transaction):
    # Implement transaction validation logic
    # For simplicity, we'll just check if the amount is positive
    return transaction.amount > 0
```

This enhanced validation includes a check for the validity of each transaction in every block.

### 6. Handling Chain Reorganization

Chain reorganization is crucial for maintaining consensus in a decentralized network. Let's add a simple method to handle this:

```python
def resolve_conflicts(self, other_chain):
    if len(other_chain) > len(self.chain) and self.is_valid_chain(other_chain):
        self.chain = other_chain
        return True
    return False

def is_valid_chain(self, chain):
    # Implement chain validation logic
    # This should be similar to is_chain_valid but for an external chain
    pass
```

This method allows our blockchain to replace its own chain with a longer, valid chain from another node in the network.

### Putting It All Together

Finally, let's create a `main.py` file to demonstrate how all these components work together:

```python
from blockchain import Blockchain
from transaction import Transaction

def main():
    # Create a new blockchain
    my_blockchain = Blockchain()

    # Add some transactions
    my_blockchain.add_transaction(Transaction("Alice", "Bob", 50))
    my_blockchain.add_transaction(Transaction("Bob", "Charlie", 30))

    # Mine a new block
    my_blockchain.mine_pending_transactions("Miner1")

    # Print the blockchain
    for block in my_blockchain.chain:
        print(f"Block #{block.index}")
        print(f"Hash: {block.hash}")
        print("Transactions:")
        for transaction in block.transactions:
            print(f"  {transaction}")
        print()

    # Validate the blockchain
    print(f"Is blockchain valid? {my_blockchain.is_chain_valid()}")

if __name__ == "__main__":
    main()
```

This script creates a new blockchain, adds some transactions, mines a block, and then prints out the blockchain's contents and validity.

## Conclusion

In this lesson, we've built a simple yet functional blockchain implementation in Python. We've covered the core concepts of blockchain technology, including block structure, chain creation, transaction handling, proof of work mining, chain validation, and basic conflict resolution.

This implementation serves as a foundation for understanding more complex blockchain systems. In future lessons, we'll build upon this knowledge to explore more advanced topics such as decentralized networks, consensus mechanisms, and smart contracts.

## Exercises

1. Modify the `ProofOfWork` class to implement a different hashing algorithm (e.g., SHA-3).
2. Implement a method to calculate and display the balance of any given address in the blockchain.
3. Add a mechanism to adjust the mining difficulty based on the average time taken to mine recent blocks.
4. Implement a simple command-line interface for interacting with your blockchain (e.g., adding transactions, mining blocks, checking balances).

## Additional Resources

- Bitcoin Whitepaper: https://bitcoin.org/bitcoin.pdf
- "Mastering Bitcoin" by Andreas M. Antonopoulos
- Python documentation: https://docs.python.org/3/
- HashLib documentation: https://docs.python.org/3/library/hashlib.html

In the next lesson, we'll explore networking and decentralization, learning how to create a peer-to-peer network for our blockchain and handle synchronization between nodes.
