# Lesson 6: Networking and Decentralization

## Overview
In this lesson, we'll explore the crucial aspects of networking and decentralization in blockchain technology. We'll build upon our simple blockchain implementation from the previous lesson, transforming it into a decentralized network of nodes. This lesson will cover the fundamentals of peer-to-peer (P2P) networks, blockchain synchronization, consensus mechanisms, and basic network security considerations.

## Learning Objectives
By the end of this lesson, you will be able to:
1. Understand the principles of peer-to-peer networks in blockchain systems
2. Implement a basic P2P network using Python
3. Synchronize the blockchain across multiple nodes
4. Handle conflicts and achieve consensus in a decentralized network
5. Identify common network security issues and implement basic protections

## File Structure
We'll extend our existing project structure with new files for networking:

```
blockchain_network/
│
├── blockchain/
│   ├── __init__.py
│   ├── block.py
│   ├── blockchain.py
│   ├── transaction.py
│   └── proof_of_work.py
│
├── networking/
│   ├── __init__.py
│   ├── node.py
│   ├── message.py
│   └── peer_manager.py
│
├── main.py
└── requirements.txt
```

## Detailed Lesson Content

### 1. Introduction to Peer-to-Peer Networks

Peer-to-peer (P2P) networks are a fundamental aspect of blockchain systems, enabling decentralization and removing the need for a central authority. In a P2P network, each participant (or node) acts both as a client and a server, sharing resources and information directly with other nodes.

Key characteristics of P2P networks in blockchain systems include:

- Decentralization: No single point of control or failure
- Scalability: The network can grow or shrink dynamically
- Resilience: The network continues to function even if some nodes fail
- Equal participation: All nodes have the same rights and responsibilities

In our implementation, we'll create a simplified P2P network where nodes can discover each other, exchange blockchain data, and maintain a consistent state across the network.

### 2. Implementing a Basic P2P Network in Python

Let's start by creating a basic `Node` class in `networking/node.py`:

```python
import socket
import threading
import json
from blockchain.blockchain import Blockchain

class Node:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.peers = set()
        self.blockchain = Blockchain()
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.bind((self.host, self.port))

    def start(self):
        self.socket.listen(1)
        print(f"Node listening on {self.host}:{self.port}")
        
        # Start a thread to accept incoming connections
        t = threading.Thread(target=self.accept_connections)
        t.start()

    def accept_connections(self):
        while True:
            client, address = self.socket.accept()
            client.settimeout(60)
            threading.Thread(target=self.handle_client, args=(client, address)).start()

    def handle_client(self, client, address):
        while True:
            try:
                message = client.recv(1024).decode('utf-8')
                if message:
                    self.handle_message(json.loads(message), client)
                else:
                    raise Exception('Client disconnected')
            except:
                client.close()
                return False

    def handle_message(self, message, client):
        if message['type'] == 'QUERY_LATEST':
            self.send_latest_block(client)
        elif message['type'] == 'QUERY_ALL':
            self.send_chain(client)
        elif message['type'] == 'BLOCK':
            self.handle_block_message(message['data'])

    def connect_to_peer(self, host, port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((host, port))
            self.peers.add(sock)
            threading.Thread(target=self.handle_client, args=(sock, (host, port))).start()
        except:
            print(f"Failed to connect to peer {host}:{port}")

    def broadcast(self, message):
        for peer in self.peers:
            self.send_to_peer(peer, message)

    def send_to_peer(self, peer, message):
        try:
            peer.send(json.dumps(message).encode('utf-8'))
        except:
            self.peers.remove(peer)
```

This `Node` class forms the foundation of our P2P network. It can:
- Listen for incoming connections
- Handle incoming messages
- Connect to other peers
- Broadcast messages to all connected peers

### 3. Synchronizing the Blockchain Across Nodes

To keep the blockchain consistent across all nodes, we need to implement synchronization mechanisms. Let's add methods to our `Node` class for querying and sending blockchain data:

```python
def send_latest_block(self, client):
    latest_block = self.blockchain.get_latest_block()
    self.send_to_peer(client, {
        'type': 'BLOCK',
        'data': latest_block.to_dict()
    })

def send_chain(self, client):
    chain = [block.to_dict() for block in self.blockchain.chain]
    self.send_to_peer(client, {
        'type': 'CHAIN',
        'data': chain
    })

def handle_block_message(self, block_data):
    received_block = Block.from_dict(block_data)
    latest_block = self.blockchain.get_latest_block()

    if received_block.index > latest_block.index:
        if received_block.previous_hash == latest_block.hash:
            if self.blockchain.add_block(received_block):
                self.broadcast({
                    'type': 'BLOCK',
                    'data': received_block.to_dict()
                })
        elif received_block.index == latest_block.index + 1:
            # We are one block behind, request the full chain
            self.broadcast({'type': 'QUERY_ALL'})
        else:
            # We are multiple blocks behind, request the full chain
            self.broadcast({'type': 'QUERY_ALL'})
```

These methods allow nodes to exchange blockchain data and handle incoming blocks. When a node receives a new block, it checks if the block is valid and whether it should be added to the chain or if the node needs to request the full chain from its peers.

### 4. Handling Conflicts and Achieving Consensus

In a decentralized network, conflicts can arise when different nodes have different versions of the blockchain. We need a mechanism to resolve these conflicts and achieve consensus. Let's implement a simple consensus algorithm based on the longest chain rule:

```python
def resolve_conflicts(self):
    new_chain = None
    max_length = len(self.blockchain.chain)

    for peer in self.peers:
        self.send_to_peer(peer, {'type': 'QUERY_ALL'})
        response = self.receive_chain(peer)
        
        if response and 'data' in response:
            length = len(response['data'])
            chain = [Block.from_dict(block_data) for block_data in response['data']]

            if length > max_length and self.blockchain.is_valid_chain(chain):
                max_length = length
                new_chain = chain

    if new_chain:
        self.blockchain.chain = new_chain
        return True

    return False

def receive_chain(self, peer):
    try:
        message = peer.recv(4096).decode('utf-8')
        if message:
            return json.loads(message)
    except:
        return None
```

This `resolve_conflicts` method implements the longest chain rule: if a longer valid chain is found among the node's peers, the node adopts that chain. This helps maintain consensus across the network.

### 5. Network Security and Attack Vectors

While our implementation is basic, it's important to consider security in blockchain networks. Here are some key security considerations and potential attack vectors:

1. Sybil Attacks: An attacker could create multiple fake nodes to gain influence over the network. To mitigate this, implement node reputation systems or proof-of-work for node registration.

2. Eclipse Attacks: An attacker could isolate a node from the honest network by surrounding it with malicious nodes. Implement measures to ensure diverse peer connections.

3. 51% Attacks: If an attacker controls more than half of the network's mining power, they could potentially rewrite the blockchain. This is less of a concern in private networks but crucial in public blockchains.

4. Man-in-the-Middle (MITM) Attacks: Implement encryption for all node communications to prevent eavesdropping and tampering.

5. DDoS Attacks: Implement rate limiting and other DDoS protection measures to prevent nodes from being overwhelmed with requests.

Let's add a basic security measure to our `Node` class to prevent flooding attacks:

```python
import time

class Node:
    # ... (previous code) ...

    def __init__(self, host, port):
        # ... (previous initialization) ...
        self.message_counts = {}

    def handle_client(self, client, address):
        while True:
            try:
                message = client.recv(1024).decode('utf-8')
                if message:
                    if self.is_message_allowed(address):
                        self.handle_message(json.loads(message), client)
                    else:
                        print(f"Rate limit exceeded for {address}. Message ignored.")
                else:
                    raise Exception('Client disconnected')
            except:
                client.close()
                return False

    def is_message_allowed(self, address):
        current_time = time.time()
        if address in self.message_counts:
            count, timestamp = self.message_counts[address]
            if current_time - timestamp < 60:  # 1 minute window
                if count >= 100:  # Max 100 messages per minute
                    return False
                self.message_counts[address] = (count + 1, timestamp)
            else:
                self.message_counts[address] = (1, current_time)
        else:
            self.message_counts[address] = (1, current_time)
        return True
```

This simple rate limiting mechanism prevents any single peer from flooding the node with messages.

### Putting It All Together

Let's update our `main.py` to demonstrate how these networking components work together:

```python
from networking.node import Node
import time

def main():
    # Create three nodes
    node1 = Node('localhost', 5000)
    node2 = Node('localhost', 5001)
    node3 = Node('localhost', 5002)

    # Start the nodes
    node1.start()
    node2.start()
    node3.start()

    # Connect the nodes
    node1.connect_to_peer('localhost', 5001)
    node2.connect_to_peer('localhost', 5002)
    node3.connect_to_peer('localhost', 5000)

    # Give some time for connections to establish
    time.sleep(2)

    # Node 1 creates and broadcasts a new block
    new_block = node1.blockchain.create_block("Transaction data")
    node1.broadcast({
        'type': 'BLOCK',
        'data': new_block.to_dict()
    })

    # Give some time for propagation
    time.sleep(2)

    # Check if all nodes have the same blockchain
    print("Node 1 chain:", [block.index for block in node1.blockchain.chain])
    print("Node 2 chain:", [block.index for block in node2.blockchain.chain])
    print("Node 3 chain:", [block.index for block in node3.blockchain.chain])

if __name__ == "__main__":
    main()
```

This script creates a small network of three nodes, connects them, and demonstrates block propagation across the network.

## Conclusion

In this lesson, we've expanded our blockchain implementation to function in a decentralized network. We've covered the basics of P2P networking, blockchain synchronization, conflict resolution, and touched on important security considerations. This implementation, while simplified, demonstrates the core principles of how blockchain networks operate in a decentralized manner.

## Exercises

1. Implement a node discovery mechanism that allows nodes to automatically find and connect to other nodes in the network.
2. Add support for transaction propagation across the network before they are included in blocks.
3. Implement a more sophisticated consensus algorithm, such as a basic version of Proof of Stake.
4. Create a simple command-line interface that allows users to interact with a node, such as viewing the blockchain, creating transactions, or mining blocks.
5. Implement basic encryption for node-to-node communication to protect against MITM attacks.

## Additional Resources

- "Mastering Bitcoin" by Andreas M. Antonopoulos (Chapters on Network Discovery and Network Architecture)
- "Blockchain Basics: A Non-Technical Introduction in 25 Steps" by Daniel Drescher
- Python Socket Programming Tutorial: https://realpython.com/python-sockets/
- Bitcoin Developer Guide - P2P Network: https://developer.bitcoin.org/devguide/p2p_network.html

In the next lesson, we'll explore wallets and transactions in more depth, learning how to create and manage cryptocurrency wallets, implement more complex transaction structures, and handle transaction verification and signing.
