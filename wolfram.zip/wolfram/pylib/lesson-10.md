# Lesson 10: Building Robust Applications with Wolfram Alpha API

## Lesson Overview

This lesson focuses on building production-ready applications using the Wolfram Alpha API. We'll cover robust application architecture, implementing effective caching strategies, managing API quotas, and deploying applications across different platforms. The emphasis is on creating maintainable, scalable, and reliable applications.

## Prerequisites
- Completion of Lessons 1-9
- Understanding of software architecture principles
- Basic knowledge of caching mechanisms
- Familiarity with deployment processes
- Understanding of monitoring and logging

## Lesson Duration
- 4 hours of direct instruction
- 3 hours of hands-on implementation
- 1 hour for deployment practice

## Project Structure

We'll work with a comprehensive application structure that demonstrates production-ready organization:

```
wolfram_production/
│
├── src/
│   ├── __init__.py
│   │
│   ├── core/
│   │   ├── __init__.py
│   │   ├── engine.py          # Enhanced Wolfram Engine
│   │   ├── cache.py          # Caching implementation
│   │   └── rate_limiter.py   # Rate limiting logic
│   │
│   ├── api/
│   │   ├── __init__.py
│   │   ├── routes.py         # API endpoints
│   │   └── middleware.py     # Request/Response middleware
│   │
│   ├── services/
│   │   ├── __init__.py
│   │   ├── query_service.py  # Query handling
│   │   └── result_service.py # Result processing
│   │
│   ├── cache/
│   │   ├── __init__.py
│   │   ├── redis_cache.py    # Redis implementation
│   │   └── memory_cache.py   # In-memory implementation
│   │
│   └── monitoring/
│       ├── __init__.py
│       ├── metrics.py        # Performance metrics
│       └── health.py         # Health checks
│
├── config/
│   ├── __init__.py
│   ├── settings.py           # Configuration management
│   └── environment.py        # Environment variables
│
├── tests/
│   ├── __init__.py
│   ├── integration/
│   │   └── test_api.py
│   └── unit/
│       ├── test_cache.py
│       └── test_limiter.py
│
├── deployment/
│   ├── docker/
│   │   ├── Dockerfile
│   │   └── docker-compose.yml
│   └── kubernetes/
│       ├── deployment.yaml
│       └── service.yaml
│
└── requirements.txt
```

## Detailed Content

### 1. Application Architecture

First, let's implement a robust core engine that handles the primary application logic. This will be the foundation of our production application.

In `src/core/engine.py`:
```python
from typing import Optional, Dict, Any
from datetime import datetime
import asyncio
import logging

class RobustWolframEngine:
    """
    Production-ready Wolfram Alpha Engine with advanced features
    """
    def __init__(self, 
                 config: Dict[str, Any],
                 cache_manager: Any,
                 rate_limiter: Any):
        self.config = config
        self.cache = cache_manager
        self.rate_limiter = rate_limiter
        self.logger = logging.getLogger(__name__)
        
    async def process_query(self, query: str) -> Dict[str, Any]:
        """
        Process a query with full production capabilities
        """
        try:
            # Check cache first
            cached_result = await self.cache.get(query)
            if cached_result:
                self.logger.info("Cache hit for query: %s", query)
                return cached_result
            
            # Check rate limits
            await self.rate_limiter.check_limit()
            
            # Process query
            result = await self._execute_query(query)
            
            # Cache result
            await self.cache.set(query, result)
            
            return result
            
        except Exception as e:
            self.logger.error("Query processing error: %s", str(e))
            raise
            
    async def _execute_query(self, query: str) -> Dict[str, Any]:
        """
        Execute the actual API query with retry logic
        """
        retries = self.config.get('max_retries', 3)
        
        for attempt in range(retries):
            try:
                return await self._make_api_call(query)
            except Exception as e:
                if attempt == retries - 1:
                    raise
                await asyncio.sleep(2 ** attempt)  # Exponential backoff
```

### 2. Caching Implementation

Implementing an efficient caching system is crucial for production applications. We'll create a flexible caching system that supports multiple backends.

In `src/cache/redis_cache.py`:
```python
import json
from typing import Any, Optional
from redis import Redis
from datetime import timedelta

class RedisCache:
    """
    Production-ready Redis cache implementation
    """
    def __init__(self, config: dict):
        self.redis = Redis(
            host=config['redis_host'],
            port=config['redis_port'],
            password=config['redis_password'],
            decode_responses=True
        )
        self.default_ttl = timedelta(
            seconds=config.get('cache_ttl', 3600)
        )
        
    async def get(self, key: str) -> Optional[Any]:
        """
        Retrieve cached data with error handling
        """
        try:
            data = await self.redis.get(key)
            if data:
                return json.loads(data)
        except Exception as e:
            logger.error(f"Cache retrieval error: {str(e)}")
            return None
            
    async def set(self, 
                  key: str, 
                  value: Any, 
                  ttl: Optional[int] = None) -> bool:
        """
        Store data in cache with custom TTL
        """
        try:
            ttl = ttl or self.default_ttl
            serialized = json.dumps(value)
            return await self.redis.set(
                key, 
                serialized,
                ex=ttl
            )
        except Exception as e:
            logger.error(f"Cache storage error: {str(e)}")
            return False
```

### 3. Rate Limiting and Quota Management

Implementing proper rate limiting is essential for maintaining API quotas and ensuring fair resource usage.

In `src/core/rate_limiter.py`:
```python
from datetime import datetime, timedelta
from typing import Optional
import asyncio
import time

class RateLimiter:
    """
    Advanced rate limiting implementation with token bucket algorithm
    """
    def __init__(self, 
                 requests_per_second: int,
                 burst_limit: int):
        self.rate = requests_per_second
        self.burst_limit = burst_limit
        self.tokens = burst_limit
        self.last_update = time.time()
        self._lock = asyncio.Lock()
        
    async def check_limit(self) -> bool:
        """
        Check and update rate limit tokens
        """
        async with self._lock:
            now = time.time()
            time_passed = now - self.last_update
            
            # Add new tokens based on time passed
            new_tokens = time_passed * self.rate
            self.tokens = min(
                self.burst_limit,
                self.tokens + new_tokens
            )
            self.last_update = now
            
            if self.tokens >= 1:
                self.tokens -= 1
                return True
                
            return False
            
    async def wait_for_token(self, 
                            timeout: Optional[float] = None) -> bool:
        """
        Wait for a rate limit token to become available
        """
        start_time = time.time()
        
        while timeout is None or time.time() - start_time < timeout:
            if await self.check_limit():
                return True
            await asyncio.sleep(1 / self.rate)
            
        return False
```

### 4. Production Deployment Configuration

Setting up proper deployment configurations is crucial for production environments. We'll implement Docker and Kubernetes configurations.

In `deployment/docker/Dockerfile`:
```dockerfile
# Multi-stage build for production
FROM python:3.9-slim as builder

# Install build dependencies
RUN apt-get update && apt-get install -y \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# Create virtual environment
RUN python -m venv /opt/venv
ENV PATH="/opt/venv/bin:$PATH"

# Install production dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Production image
FROM python:3.9-slim

# Copy virtual environment
COPY --from=builder /opt/venv /opt/venv
ENV PATH="/opt/venv/bin:$PATH"

# Copy application code
COPY src/ /app/src/
COPY config/ /app/config/

WORKDIR /app

# Set production environment
ENV PYTHONPATH=/app
ENV PYTHON_ENV=production

# Run application
CMD ["python", "-m", "src.api.main"]
```

### 5. Health Monitoring and Metrics

Implementing comprehensive monitoring is essential for production applications.

In `src/monitoring/health.py`:
```python
from typing import Dict, Any
import psutil
import time

class HealthMonitor:
    """
    Production health monitoring system
    """
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.start_time = time.time()
        
    async def get_health_status(self) -> Dict[str, Any]:
        """
        Comprehensive health check implementation
        """
        return {
            'status': 'healthy',
            'uptime': time.time() - self.start_time,
            'system': {
                'cpu_usage': psutil.cpu_percent(),
                'memory_usage': psutil.virtual_memory().percent,
                'disk_usage': psutil.disk_usage('/').percent
            },
            'api': {
                'response_time': await self._check_api_response(),
                'error_rate': await self._get_error_rate()
            },
            'cache': {
                'status': await self._check_cache_health(),
                'hit_rate': await self._get_cache_hit_rate()
            }
        }
```

## Hands-on Exercise

### Building a Production-Ready API Service

Students will implement a complete production-ready API service that includes:

1. Request handling with proper error management
2. Caching with Redis
3. Rate limiting implementation
4. Health monitoring endpoints
5. Deployment configuration

## Best Practices and Guidelines

1. **Architecture Design**
   - Implement proper separation of concerns
   - Use dependency injection
   - Follow SOLID principles
   - Implement proper error handling
   - Use asynchronous operations where appropriate

2. **Caching Strategy**
   - Implement multiple cache layers
   - Use appropriate cache invalidation
   - Monitor cache hit rates
   - Implement cache warming
   - Handle cache failures gracefully

3. **Production Deployment**
   - Use container orchestration
   - Implement proper logging
   - Set up monitoring and alerting
   - Use proper security measures
   - Implement backup strategies

4. **Performance Optimization**
   - Implement connection pooling
   - Use proper indexing
   - Optimize query patterns
   - Implement proper timeouts
   - Use appropriate batch processing

## Assessment Criteria

Students will be evaluated based on their ability to:

1. Design and implement a robust application architecture
2. Implement effective caching strategies
3. Create proper rate limiting mechanisms
4. Set up production deployment configurations
5. Implement comprehensive monitoring
6. Handle errors and edge cases appropriately

## Additional Resources

1. Docker and Kubernetes Documentation
2. Redis Documentation
3. Application Monitoring Best Practices
4. Production Deployment Guides
5. Performance Optimization Resources

## Next Steps

After completing this lesson, students should proceed to Lesson 11: Integration Patterns, where they'll learn about integrating their robust application with various external systems and frameworks.

Remember that building production-ready applications is an iterative process that requires continuous monitoring, optimization, and updates based on real-world usage patterns and requirements.
