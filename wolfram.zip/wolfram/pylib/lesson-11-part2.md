# Lesson 11: Integration Patterns with Wolfram Alpha API
## Part 2: Framework Implementations and Advanced Patterns

## Framework-Specific Implementations

### 1. Flask Integration

Let's implement a complete Flask integration that demonstrates best practices and patterns.

In `src/frameworks/flask_integration.py`:
```python
from flask import Flask, request, jsonify
from functools import wraps
from typing import Any, Dict, Callable

from ..core.interface import WolframIntegrationBase, IntegrationConfig
from ..core.adapters import FrameworkAdapter
from ..patterns.observer import IntegrationEvent, IntegrationObserver

class FlaskWolframAdapter(FrameworkAdapter):
    """Flask-specific adapter for Wolfram Alpha integration"""
    
    def initialize_adapter(self) -> None:
        self.observer = IntegrationObserver()
        self.error_handlers = {}
        
    async def adapt_request(self, request: Any) -> Dict[str, Any]:
        """Convert Flask request to integration format"""
        data = {}
        
        # Handle different request methods
        if request.method == 'GET':
            data = request.args.to_dict()
        elif request.method == 'POST':
            if request.is_json:
                data = request.get_json()
            else:
                data = request.form.to_dict()
                
        # Add request context
        data['headers'] = dict(request.headers)
        data['method'] = request.method
        
        return data
        
    async def adapt_response(self, response: Dict[str, Any]) -> Any:
        """Convert integration response to Flask response"""
        return jsonify({
            'status': 'success',
            'data': response
        })
        
    async def handle_error(self, error: Exception) -> Any:
        """Handle errors in Flask-appropriate way"""
        error_type = type(error)
        handler = self.error_handlers.get(error_type)
        
        if handler:
            return await handler(error)
            
        return jsonify({
            'status': 'error',
            'message': str(error),
            'type': error_type.__name__
        }), 500

def create_flask_integration(app: Flask, 
                           config: IntegrationConfig) -> FlaskWolframAdapter:
    """Create Flask integration with middleware and routes"""
    
    integration = WolframIntegrationBase(config)
    adapter = FlaskWolframAdapter(integration)
    
    # Register middleware
    @app.before_request
    async def before_request():
        await adapter.observer.notify(
            IntegrationEvent.QUERY_START,
            {'path': request.path}
        )
    
    # Register routes
    @app.route('/wolfram/query', methods=['POST'])
    async def wolfram_query():
        return await adapter.handle_request(request)
    
    @app.route('/wolfram/status', methods=['GET'])
    async def wolfram_status():
        return jsonify({
            'status': 'active',
            'config': config.__dict__
        })
        
    return adapter
```

### 2. FastAPI Integration

Now let's implement a FastAPI integration with full async support.

In `src/frameworks/fastapi_integration.py`:
```python
from fastapi import FastAPI, Request, Response, HTTPException
from fastapi.middleware.base import BaseHTTPMiddleware
from typing import Dict, Any

class FastAPIWolframMiddleware(BaseHTTPMiddleware):
    """Middleware for FastAPI Wolfram integration"""
    
    def __init__(self, app: FastAPI, adapter: 'FastAPIWolframAdapter'):
        super().__init__(app)
        self.adapter = adapter
    
    async def dispatch(self, request: Request, call_next):
        try:
            # Handle Wolfram-specific endpoints
            if request.url.path.startswith('/wolfram/'):
                return await self.adapter.handle_request(request)
                
            # Pass through other requests
            return await call_next(request)
            
        except Exception as e:
            return await self.adapter.handle_error(e)

class FastAPIWolframAdapter(FrameworkAdapter):
    """FastAPI-specific adapter for Wolfram Alpha integration"""
    
    def initialize_adapter(self) -> None:
        self.observer = IntegrationObserver()
        
    async def adapt_request(self, request: Request) -> Dict[str, Any]:
        """Convert FastAPI request to integration format"""
        data = {}
        
        if request.method == 'GET':
            data = dict(request.query_params)
        else:
            try:
                data = await request.json()
            except:
                data = await request.form()
                
        # Add request context
        data['headers'] = dict(request.headers)
        data['method'] = request.method
        
        return data
        
    async def adapt_response(self, response: Dict[str, Any]) -> Response:
        """Convert integration response to FastAPI response"""
        from fastapi.responses import JSONResponse
        
        return JSONResponse({
            'status': 'success',
            'data': response
        })
        
    async def handle_error(self, error: Exception) -> Response:
        """Handle errors in FastAPI-appropriate way"""
        from fastapi.responses import JSONResponse
        
        if isinstance(error, HTTPException):
            return JSONResponse({
                'status': 'error',
                'message': error.detail,
                'type': 'HTTPException'
            }, status_code=error.status_code)
            
        return JSONResponse({
            'status': 'error',
            'message': str(error),
            'type': type(error).__name__
        }, status_code=500)

def create_fastapi_integration(app: FastAPI,
                             config: IntegrationConfig) -> FastAPIWolframAdapter:
    """Create FastAPI integration with routes and middleware"""
    
    integration = WolframIntegrationBase(config)
    adapter = FastAPIWolframAdapter(integration)
    
    # Add middleware
    app.add_middleware(FastAPIWolframMiddleware, adapter=adapter)
    
    # Register routes
    @app.post('/wolfram/query')
    async def wolfram_query(request: Request):
        return await adapter.handle_request(request)
    
    @app.get('/wolfram/status')
    async def wolfram_status():
        return {
            'status': 'active',
            'config': config.__dict__
        }
        
    return adapter
```

### 3. CLI Integration

Let's implement a command-line interface integration.

In `src/frameworks/cli_integration.py`:
```python
import click
import asyncio
from typing import Dict, Any
import json

class CLIWolframAdapter(FrameworkAdapter):
    """CLI-specific adapter for Wolfram Alpha integration"""
    
    def initialize_adapter(self) -> None:
        self.observer = IntegrationObserver()
        
    async def adapt_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Convert CLI input to integration format"""
        return {
            'query': request.get('query'),
            'options': request.get('options', {}),
            'context': {'source': 'cli'}
        }
        
    async def adapt_response(self, response: Dict[str, Any]) -> str:
        """Convert integration response to CLI output"""
        return json.dumps(response, indent=2)
        
    async def handle_error(self, error: Exception) -> str:
        """Handle errors in CLI-appropriate way"""
        return f"Error: {str(error)}"

@click.group()
def cli():
    """Wolfram Alpha CLI Integration"""
    pass

@cli.command()
@click.argument('query')
@click.option('--format', default='json', help='Output format')
@click.option('--timeout', default=30, help='Query timeout')
def query(query: str, format: str, timeout: int):
    """Execute a Wolfram Alpha query"""
    
    config = IntegrationConfig(
        app_id=os.getenv('WOLFRAM_APP_ID'),
        timeout=timeout
    )
    
    integration = WolframIntegrationBase(config)
    adapter = CLIWolframAdapter(integration)
    
    async def run_query():
        result = await adapter.handle_request({
            'query': query,
            'options': {'format': format}
        })
        click.echo(result)
    
    asyncio.run(run_query())

if __name__ == '__main__':
    cli()
```

## Advanced Integration Patterns

### 1. Scaling Pattern

Implementation of a scaling pattern for handling increased load:

```python
from typing import List, Dict, Any
import asyncio
from concurrent.futures import ThreadPoolExecutor

class ScalingIntegration:
    """Pattern for scaling Wolfram Alpha integration"""
    
    def __init__(self, 
                 config: IntegrationConfig,
                 pool_size: int = 10):
        self.config = config
        self.pool_size = pool_size
        self.executor = ThreadPoolExecutor(max_workers=pool_size)
        self.queue = asyncio.Queue()
        self.workers: List[asyncio.Task] = []
        
    async def start(self):
        """Start worker pool"""
        for _ in range(self.pool_size):
            worker = asyncio.create_task(self._worker())
            self.workers.append(worker)
            
    async def stop(self):
        """Stop worker pool"""
        await self.queue.join()
        for worker in self.workers:
            worker.cancel()
            
    async def _worker(self):
        """Worker process for handling queries"""
        while True:
            query, future = await self.queue.get()
            try:
                result = await self._process_query(query)
                future.set_result(result)
            except Exception as e:
                future.set_exception(e)
            finally:
                self.queue.task_done()
                
    async def submit_query(self, query: Dict[str, Any]) -> Any:
        """Submit query for processing"""
        future = asyncio.Future()
        await self.queue.put((query, future))
        return await future
```

### 2. Circuit Breaker Pattern

Implementation of a circuit breaker for handling API failures:

```python
from enum import Enum
from datetime import datetime, timedelta
from typing import Optional, Callable

class CircuitState(Enum):
    CLOSED = "closed"     # Normal operation
    OPEN = "open"        # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing recovery

class CircuitBreaker:
    """Circuit breaker for Wolfram Alpha integration"""
    
    def __init__(self,
                 failure_threshold: int = 5,
                 recovery_timeout: int = 60,
                 half_open_timeout: int = 30):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_timeout = half_open_timeout
        
        self.state = CircuitState.CLOSED
        self.failures = 0
        self.last_failure_time: Optional[datetime] = None
        self.half_open_time: Optional[datetime] = None
        
    async def call(self, func: Callable, *args, **kwargs) -> Any:
        """Execute function with circuit breaker protection"""
        
        if not self._can_execute():
            raise Exception("Circuit breaker is open")
            
        try:
            result = await func(*args, **kwargs)
            self._handle_success()
            return result
        except Exception as e:
            self._handle_failure()
            raise
            
    def _can_execute(self) -> bool:
        """Check if execution is allowed"""
        now = datetime.now()
        
        if self.state == CircuitState.CLOSED:
            return True
            
        if self.state == CircuitState.OPEN:
            if (now - self.last_failure_time) > timedelta(
                seconds=self.recovery_timeout
            ):
                self.state = CircuitState.HALF_OPEN
                self.half_open_time = now
                return True
            return False
            
        if self.state == CircuitState.HALF_OPEN:
            return (now - self.half_open_time) <= timedelta(
                seconds=self.half_open_timeout
            )
            
        return False
        
    def _handle_success(self):
        """Handle successful execution"""
        if self.state == CircuitState.HALF_OPEN:
            self.state = CircuitState.CLOSED
        self.failures = 0
        
    def _handle_failure(self):
        """Handle execution failure"""
        self.failures += 1
        self.last_failure_time = datetime.now()
        
        if self.state == CircuitState.HALF_OPEN:
            self.state = CircuitState.OPEN
        elif self.failures >= self.failure_threshold:
            self.state = CircuitState.OPEN
```

## Best Practices for Framework Integration

1. **Framework Independence**
   - Keep core logic framework-agnostic
   - Use adapters for framework-specific code
   - Implement proper interface segregation
   - Maintain consistent error handling
   - Use dependency injection

2. **Performance Optimization**
   - Implement proper caching
   - Use connection pooling
   - Implement request batching
   - Optimize response handling
   - Use appropriate async patterns

3. **Error Handling**
   - Implement proper error hierarchies
   - Use appropriate status codes
   - Provide meaningful error messages
   - Implement retry mechanisms
   - Handle timeout scenarios

4. **Monitoring and Logging**
   - Implement comprehensive logging
   - Add performance metrics
   - Monitor integration health
   - Track error rates
   - Implement alerting

## Additional Resources

1. Framework Documentation:
   - Flask Documentation
   - FastAPI Documentation
   - Click Documentation
   
2. Integration Patterns:
   - Enterprise Integration Patterns
   - Python Async Patterns
   - Circuit Breaker Pattern
   
3. Best Practices:
   - API Integration Guidelines
   - Python Application Architecture
   - Testing Strategies

## Next Steps

After completing this lesson, students should proceed to Lesson 12: Advanced Topics and Best Practices, where they'll learn about advanced optimization techniques and production deployment strategies.
