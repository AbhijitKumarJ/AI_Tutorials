# Lesson 2: Setting Up the Development Environment

## Lesson Overview
This lesson focuses on establishing a robust development environment for working with the Wolfram Alpha API. We'll cover environment setup across different platforms, dependency management, project configuration, logging systems, and error handling. The goal is to create a maintainable and scalable foundation for development.

## Project Structure Extension
Building on our previous lesson's structure, we'll add development environment configurations:

```
wolfram_project/
├── src/
│   ├── __init__.py
│   ├── engine/
│   │   ├── __init__.py
│   │   └── api_client.py
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── auth.py
│   │   ├── validators.py
│   │   └── logger.py
│   └── config/
│       ├── __init__.py
│       ├── settings.py
│       ├── dev_settings.py
│       └── prod_settings.py
├── tests/
│   ├── __init__.py
│   ├── test_api_client.py
│   └── test_validators.py
├── examples/
│   ├── basic_query.py
│   └── advanced_usage.py
├── logs/
│   ├── app.log
│   └── error.log
├── requirements/
│   ├── base.txt
│   ├── dev.txt
│   └── prod.txt
├── .env.example
├── pyproject.toml
├── setup.cfg
├── requirements.txt
└── README.md
```

## 1. Python Environment Setup

### Virtual Environment Management
Creating isolated environments is crucial for maintaining dependencies and avoiding conflicts. Here's a comprehensive setup approach:

```python
# setup_environment.py
import subprocess
import sys
import os
from pathlib import Path

class EnvironmentManager:
    def __init__(self, project_name: str):
        self.project_name = project_name
        self.project_root = Path.cwd()
        self.venv_path = self.project_root / '.venv'

    def create_virtual_environment(self):
        """Create a new virtual environment"""
        try:
            subprocess.run([sys.executable, '-m', 'venv', str(self.venv_path)], check=True)
            print(f"Created virtual environment at {self.venv_path}")
        except subprocess.CalledProcessError as e:
            print(f"Failed to create virtual environment: {e}")
            sys.exit(1)

    def install_dependencies(self, requirements_file: str = 'requirements/base.txt'):
        """Install project dependencies"""
        pip_path = self.venv_path / 'bin' / 'pip' if os.name != 'nt' else self.venv_path / 'Scripts' / 'pip'
        try:
            subprocess.run([str(pip_path), 'install', '-r', requirements_file], check=True)
            print(f"Installed dependencies from {requirements_file}")
        except subprocess.CalledProcessError as e:
            print(f"Failed to install dependencies: {e}")
            sys.exit(1)

    def setup(self):
        """Complete environment setup"""
        self.create_virtual_environment()
        self.install_dependencies()
```

### Cross-Platform Configuration
Different operating systems require specific configurations. Here's how to handle them:

```python
# config/platform_config.py
import platform
import os
from pathlib import Path

class PlatformConfig:
    def __init__(self):
        self.platform = platform.system()
        self.python_version = platform.python_version()
        self.project_root = Path(__file__).parent.parent

    def get_platform_specific_paths(self):
        """Get platform-specific file paths"""
        if self.platform == "Windows":
            return {
                'config_dir': Path(os.getenv('APPDATA')) / 'WolframAPI',
                'log_dir': Path(os.getenv('LOCALAPPDATA')) / 'WolframAPI' / 'logs',
                'cache_dir': Path(os.getenv('LOCALAPPDATA')) / 'WolframAPI' / 'cache'
            }
        else:  # Unix-like systems
            return {
                'config_dir': Path.home() / '.config' / 'wolframapi',
                'log_dir': Path.home() / '.local' / 'share' / 'wolframapi' / 'logs',
                'cache_dir': Path.home() / '.cache' / 'wolframapi'
            }

    def create_directories(self):
        """Create necessary platform-specific directories"""
        paths = self.get_platform_specific_paths()
        for path in paths.values():
            path.mkdir(parents=True, exist_ok=True)
        return paths
```

## 2. Dependency Management

### Requirements Organization
Organize dependencies based on environment and purpose:

```toml
# pyproject.toml
[tool.poetry]
name = "wolfram-api-client"
version = "0.1.0"
description = "A Python client for the Wolfram Alpha API"
authors = ["Your Name <your.email@example.com>"]

[tool.poetry.dependencies]
python = "^3.8"
requests = "^2.28.0"
pydantic = "^1.9.0"
python-dotenv = "^0.20.0"

[tool.poetry.dev-dependencies]
pytest = "^7.1.0"
black = "^22.3.0"
mypy = "^0.950"
flake8 = "^4.0.1"

[build-system]
requires = ["poetry-core>=1.0.0"]
build-backend = "poetry.core.masonry.api"
```

### Dependency Installation Script

```python
# scripts/install_dependencies.py
import subprocess
import sys
from pathlib import Path

class DependencyManager:
    def __init__(self):
        self.requirements_dir = Path("requirements")

    def install_environment(self, environment: str = "dev"):
        """Install dependencies for specific environment"""
        requirements_file = self.requirements_dir / f"{environment}.txt"
        if not requirements_file.exists():
            print(f"Requirements file not found: {requirements_file}")
            sys.exit(1)

        try:
            subprocess.run([
                sys.executable, "-m", "pip", "install",
                "-r", str(requirements_file)
            ], check=True)
            print(f"Successfully installed {environment} dependencies")
        except subprocess.CalledProcessError as e:
            print(f"Failed to install dependencies: {e}")
            sys.exit(1)

    def verify_installation(self):
        """Verify all required packages are installed"""
        try:
            import requests
            import dotenv
            import pydantic
            print("All core dependencies are installed correctly")
        except ImportError as e:
            print(f"Missing dependency: {e}")
            sys.exit(1)
```

## 3. Configuration Management

### Environment-based Configuration

```python
# config/settings.py
from pydantic import BaseSettings
from typing import Optional
from pathlib import Path
import os
from dotenv import load_dotenv

class Settings(BaseSettings):
    # API Configuration
    WOLFRAM_APP_ID: str
    API_BASE_URL: str = "http://api.wolframalpha.com/v2"
    API_TIMEOUT: int = 30

    # Environment Configuration
    ENV: str = "development"
    DEBUG: bool = False
    
    # Logging Configuration
    LOG_LEVEL: str = "INFO"
    LOG_FILE: Optional[Path] = None

    # Platform-specific paths
    CONFIG_DIR: Optional[Path] = None
    CACHE_DIR: Optional[Path] = None

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

    @classmethod
    def load_config(cls, env_file: Optional[str] = None):
        """Load configuration from environment file"""
        if env_file:
            load_dotenv(env_file)
        return cls()

settings = Settings.load_config()
```

### Configuration Management Class

```python
# config/manager.py
from typing import Dict, Any, Optional
import json
from pathlib import Path
from .settings import Settings

class ConfigManager:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.config_cache: Dict[str, Any] = {}

    def load_config_file(self, config_name: str) -> Dict[str, Any]:
        """Load configuration from JSON file"""
        config_path = self.settings.CONFIG_DIR / f"{config_name}.json"
        if not config_path.exists():
            return {}
        
        with open(config_path, 'r') as f:
            return json.load(f)

    def save_config_file(self, config_name: str, data: Dict[str, Any]):
        """Save configuration to JSON file"""
        config_path = self.settings.CONFIG_DIR / f"{config_name}.json"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(config_path, 'w') as f:
            json.dump(data, f, indent=2)

    def get_config(self, key: str, default: Any = None) -> Any:
        """Get configuration value with caching"""
        if key not in self.config_cache:
            config_data = self.load_config_file('app_config')
            self.config_cache = config_data
        return self.config_cache.get(key, default)
```

## 4. Logging System

### Logging Configuration

```python
# utils/logger.py
import logging
import sys
from pathlib import Path
from typing import Optional
from logging.handlers import RotatingFileHandler

class LogManager:
    def __init__(self, log_dir: Path, app_name: str = "wolfram_api"):
        self.log_dir = log_dir
        self.app_name = app_name
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Create loggers
        self.app_logger = self._setup_logger(
            f"{app_name}_app",
            self.log_dir / "app.log"
        )
        self.error_logger = self._setup_logger(
            f"{app_name}_error",
            self.log_dir / "error.log",
            level=logging.ERROR
        )

    def _setup_logger(
        self,
        name: str,
        log_file: Path,
        level: int = logging.INFO,
        max_bytes: int = 10485760,  # 10MB
        backup_count: int = 5
    ) -> logging.Logger:
        """Setup individual logger with rotation"""
        logger = logging.getLogger(name)
        logger.setLevel(level)

        # File handler with rotation
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=max_bytes,
            backupCount=backup_count
        )
        file_handler.setFormatter(self._get_formatter())
        logger.addHandler(file_handler)

        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(self._get_formatter())
        logger.addHandler(console_handler)

        return logger

    def _get_formatter(self) -> logging.Formatter:
        """Create consistent log formatter"""
        return logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )

    def get_app_logger(self) -> logging.Logger:
        """Get application logger"""
        return self.app_logger

    def get_error_logger(self) -> logging.Logger:
        """Get error logger"""
        return self.error_logger
```

### Logger Implementation

```python
# utils/logging_utils.py
import functools
import time
from typing import Callable, Any
from .logger import LogManager

def log_execution_time(logger: LogManager) -> Callable:
    """Decorator to log function execution time"""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            start_time = time.time()
            result = func(*args, **kwargs)
            end_time = time.time()
            
            logger.get_app_logger().info(
                f"{func.__name__} executed in {end_time - start_time:.2f} seconds"
            )
            return result
        return wrapper
    return decorator
```

## 5. Error Handling System

### Custom Exceptions

```python
# utils/exceptions.py
class WolframAPIError(Exception):
    """Base exception for Wolfram API errors"""
    def __init__(self, message: str, error_code: Optional[str] = None):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)

class ConfigurationError(WolframAPIError):
    """Raised when there's a configuration error"""
    pass

class APIConnectionError(WolframAPIError):
    """Raised when API connection fails"""
    pass

class ValidationError(WolframAPIError):
    """Raised when input validation fails"""
    pass
```

### Error Handler

```python
# utils/error_handler.py
from typing import Callable, Any
import functools
from .exceptions import WolframAPIError
from .logger import LogManager

class ErrorHandler:
    def __init__(self, logger: LogManager):
        self.logger = logger

    def handle_api_errors(self, func: Callable) -> Callable:
        """Decorator to handle API-related errors"""
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            try:
                return func(*args, **kwargs)
            except WolframAPIError as e:
                self.logger.get_error_logger().error(
                    f"API Error: {e.message}",
                    extra={"error_code": e.error_code}
                )
                raise
            except Exception as e:
                self.logger.get_error_logger().error(
                    f"Unexpected error: {str(e)}",
                    exc_info=True
                )
                raise WolframAPIError(f"Unexpected error: {str(e)}")
        return wrapper
```

## Practical Exercises

1. Environment Setup:
   - Create a new project following the provided structure
   - Set up virtual environment and install dependencies
   - Configure platform-specific settings

2. Configuration Management:
   - Create different configuration files for development and production
   - Implement configuration loading and validation
   - Test configuration across different platforms

3. Logging Implementation:
   - Set up logging system with rotation
   - Implement different log levels
   - Create custom log formatters

4. Error Handling:
   - Implement custom exception classes
   - Create error handling decorators
   - Test error handling across different scenarios

## Next Steps

In the next lesson, we'll dive into the core components of the Wolfram Alpha API, focusing on the implementation of the base engine and query construction. Students should ensure their development environment is properly set up and all components are working as expected before moving forward.

## Additional Resources

1. Python Virtual Environments Documentation
2. Pydantic Documentation for Settings Management
3. Python Logging Cookbook
4. Error Handling Best Practices Guide

Remember to test your setup across different platforms and ensure all components work together seamlessly.
