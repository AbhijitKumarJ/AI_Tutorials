# Lesson 12: Advanced Topics and Best Practices
## Part 3: Advanced Error Handling Patterns

### Introduction
Error handling in production environments requires a sophisticated approach that goes beyond basic try-except blocks. In this section, we'll explore advanced error handling patterns specifically designed for Wolfram Alpha API implementations, focusing on robust error management, recovery mechanisms, and comprehensive logging systems.

### Custom Exception Hierarchy

First, let's establish a comprehensive exception hierarchy that covers all potential error scenarios:

```python
from typing import Optional, Dict, Any
from datetime import datetime

class WolframAPIError(Exception):
    """Base exception class for Wolfram API errors"""
    def __init__(self, message: str, error_code: Optional[str] = None, 
                 details: Optional[Dict[str, Any]] = None):
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        self.timestamp = datetime.utcnow()
        super().__init__(self.message)

class QueryError(WolframAPIError):
    """Errors related to query formation and validation"""
    pass

class AuthenticationError(WolframAPIError):
    """Authentication and authorization errors"""
    pass

class RateLimitError(WolframAPIError):
    """Rate limiting and quota exceeded errors"""
    def __init__(self, message: str, retry_after: Optional[int] = None, **kwargs):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after

class NetworkError(WolframAPIError):
    """Network-related errors"""
    def __init__(self, message: str, retryable: bool = True, **kwargs):
        super().__init__(message, **kwargs)
        self.retryable = retryable

class ParseError(WolframAPIError):
    """Response parsing errors"""
    pass

class TimeoutError(WolframAPIError):
    """Timeout-related errors"""
    def __init__(self, message: str, timeout_value: float, **kwargs):
        super().__init__(message, **kwargs)
        self.timeout_value = timeout_value
```

### Advanced Error Handler Implementation

Create a sophisticated error handler that manages different types of errors and implements appropriate recovery strategies:

```python
import logging
from typing import Type, Callable, Optional
from functools import wraps
import asyncio
import backoff

class ErrorHandler:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.error_handlers: Dict[Type[Exception], Callable] = {}
        self.recovery_strategies: Dict[Type[Exception], Callable] = {}
        self._initialize_handlers()

    def _initialize_handlers(self):
        """Initialize default error handlers"""
        self.register_handler(RateLimitError, self._handle_rate_limit)
        self.register_handler(NetworkError, self._handle_network_error)
        self.register_handler(TimeoutError, self._handle_timeout)
        self.register_handler(AuthenticationError, self._handle_auth_error)

    def register_handler(self, exception_type: Type[Exception], 
                        handler: Callable[[Exception], None]):
        """Register a custom error handler for an exception type"""
        self.error_handlers[exception_type] = handler

    def register_recovery_strategy(self, exception_type: Type[Exception], 
                                 strategy: Callable[[], None]):
        """Register a recovery strategy for an exception type"""
        self.recovery_strategies[exception_type] = strategy

    async def handle_error(self, error: Exception, context: Optional[Dict] = None):
        """Main error handling method"""
        error_type = type(error)
        context = context or {}
        
        # Log the error
        self.logger.error(
            f"Error occurred: {error}",
            extra={
                "error_type": error_type.__name__,
                "context": context,
                "timestamp": datetime.utcnow().isoformat()
            }
        )

        # Execute specific handler if exists
        handler = self.error_handlers.get(error_type)
        if handler:
            await handler(error, context)

        # Attempt recovery if strategy exists
        strategy = self.recovery_strategies.get(error_type)
        if strategy:
            await strategy(context)

    async def _handle_rate_limit(self, error: RateLimitError, context: Dict):
        """Handle rate limiting errors"""
        retry_after = error.retry_after or 60
        self.logger.warning(f"Rate limit exceeded. Waiting {retry_after} seconds")
        await asyncio.sleep(retry_after)
        
    async def _handle_network_error(self, error: NetworkError, context: Dict):
        """Handle network-related errors"""
        if error.retryable:
            await self._retry_with_backoff(context)
        else:
            self.logger.error("Non-retryable network error occurred")
            raise error

    async def _handle_timeout(self, error: TimeoutError, context: Dict):
        """Handle timeout errors"""
        self.logger.warning(
            f"Timeout occurred after {error.timeout_value} seconds",
            extra={"timeout_value": error.timeout_value}
        )
        await self._adjust_timeout_strategy(context)

    async def _handle_auth_error(self, error: AuthenticationError, context: Dict):
        """Handle authentication errors"""
        self.logger.critical("Authentication error occurred")
        await self._refresh_credentials(context)

    @backoff.on_exception(
        backoff.expo,
        (NetworkError, TimeoutError),
        max_tries=5
    )
    async def _retry_with_backoff(self, context: Dict):
        """Implement exponential backoff retry strategy"""
        pass

    async def _adjust_timeout_strategy(self, context: Dict):
        """Adjust timeout values based on error patterns"""
        pass

    async def _refresh_credentials(self, context: Dict):
        """Refresh API credentials"""
        pass
```

### Comprehensive Error Logging System

Implement a sophisticated logging system that captures detailed error information:

```python
import logging
import json
from datetime import datetime
from typing import Optional, Dict, Any
import traceback
import sys

class DetailedErrorLogger:
    def __init__(self, app_name: str, log_file: str):
        self.app_name = app_name
        self.logger = self._setup_logger(log_file)
        self.error_counts: Dict[str, int] = {}

    def _setup_logger(self, log_file: str) -> logging.Logger:
        """Setup detailed logging configuration"""
        logger = logging.getLogger(self.app_name)
        logger.setLevel(logging.DEBUG)

        # File handler for detailed logging
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        
        # Custom formatter with detailed information
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s\n'
            'Additional Data: %(error_data)s\n'
            'Stack Trace: %(stack_trace)s\n'
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

        return logger

    def log_error(self, error: Exception, context: Optional[Dict[str, Any]] = None):
        """Log detailed error information"""
        error_type = type(error).__name__
        self.error_counts[error_type] = self.error_counts.get(error_type, 0) + 1

        error_data = {
            'error_type': error_type,
            'error_message': str(error),
            'timestamp': datetime.utcnow().isoformat(),
            'context': context or {},
            'error_count': self.error_counts[error_type],
            'system_info': self._get_system_info()
        }

        if isinstance(error, WolframAPIError):
            error_data.update({
                'error_code': error.error_code,
                'error_details': error.details
            })

        self.logger.error(
            f"Error occurred: {error_type}",
            extra={
                'error_data': json.dumps(error_data, indent=2),
                'stack_trace': ''.join(traceback.format_tb(error.__traceback__))
            }
        )

    def _get_system_info(self) -> Dict[str, str]:
        """Gather system information for error context"""
        return {
            'python_version': sys.version,
            'platform': sys.platform,
            'timestamp': datetime.utcnow().isoformat()
        }
```

### Error Recovery and Circuit Breaker Pattern

Implement a circuit breaker to prevent cascading failures:

```python
from enum import Enum
from datetime import datetime, timedelta
from typing import Optional, Callable
import asyncio

class CircuitState(Enum):
    CLOSED = "closed"  # Normal operation
    OPEN = "open"      # Failure state
    HALF_OPEN = "half_open"  # Testing recovery

class CircuitBreaker:
    def __init__(self, 
                 failure_threshold: int = 5,
                 recovery_timeout: int = 60,
                 half_open_timeout: int = 30):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_timeout = half_open_timeout
        
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.last_failure_time: Optional[datetime] = None
        self.last_success_time: Optional[datetime] = None

    async def execute(self, 
                     func: Callable,
                     fallback: Optional[Callable] = None,
                     *args,
                     **kwargs):
        """Execute function with circuit breaker protection"""
        if not self._can_execute():
            if fallback:
                return await fallback(*args, **kwargs)
            raise RuntimeError("Circuit breaker is OPEN")

        try:
            result = await func(*args, **kwargs)
            await self._handle_success()
            return result
        except Exception as e:
            await self._handle_failure(e)
            if fallback:
                return await fallback(*args, **kwargs)
            raise

    def _can_execute(self) -> bool:
        """Determine if execution is allowed based on circuit state"""
        if self.state == CircuitState.CLOSED:
            return True

        if self.state == CircuitState.OPEN:
            if self._should_transition_to_half_open():
                self.state = CircuitState.HALF_OPEN
                return True
            return False

        # HALF_OPEN state
        return True

    async def _handle_success(self):
        """Handle successful execution"""
        self.failure_count = 0
        self.last_success_time = datetime.utcnow()
        if self.state == CircuitState.HALF_OPEN:
            self.state = CircuitState.CLOSED

    async def _handle_failure(self, error: Exception):
        """Handle execution failure"""
        self.failure_count += 1
        self.last_failure_time = datetime.utcnow()

        if (self.state == CircuitState.HALF_OPEN or 
            self.failure_count >= self.failure_threshold):
            self.state = CircuitState.OPEN

    def _should_transition_to_half_open(self) -> bool:
        """Determine if circuit should transition to HALF_OPEN state"""
        if not self.last_failure_time:
            return False
        
        recovery_time = datetime.utcnow() - self.last_failure_time
        return recovery_time.total_seconds() >= self.recovery_timeout

    async def reset(self):
        """Reset circuit breaker state"""
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.last_failure_time = None
        self.last_success_time = None
```

This comprehensive error handling system provides robust error management, detailed logging, and circuit breaker protection for production environments. Would you like me to proceed with the final section covering cross-platform maintenance strategies?