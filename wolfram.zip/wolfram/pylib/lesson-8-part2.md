# Lesson 8: Error Handling and Validation
## Part 2: Advanced Patterns and Implementation

## Recovery Strategies

Let's begin by implementing sophisticated recovery mechanisms that can handle various failure scenarios:

```python
# src/handlers/recovery_handler.py

from typing import Any, Callable, Optional, Dict
import time
from functools import wraps
from ..exceptions.api_exceptions import *

class RecoveryHandler:
    """Implements recovery strategies for various API failures"""
    
    def __init__(self, max_retries: int = 3, 
                 base_delay: float = 1.0,
                 max_delay: float = 30.0):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        
    def exponential_backoff(self, attempt: int) -> float:
        """
        Calculate delay time using exponential backoff.
        
        Args:
            attempt: Current attempt number
            
        Returns:
            float: Delay time in seconds
        """
        delay = min(self.max_delay, 
                   self.base_delay * (2 ** (attempt - 1)))
        # Add jitter to prevent thundering herd
        return delay * (0.5 + random.random())
        
    def retry_with_backoff(self, func: Callable) -> Callable:
        """
        Decorator that implements retry logic with exponential backoff.
        
        Args:
            func: Function to be wrapped
            
        Returns:
            Callable: Wrapped function with retry logic
        """
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(1, self.max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except (TimeoutError, RateLimitError) as e:
                    last_exception = e
                    delay = self.exponential_backoff(attempt)
                    
                    logging.warning(
                        f"Attempt {attempt} failed, retrying in {delay:.2f}s",
                        extra={
                            'attempt': attempt,
                            'delay': delay,
                            'error': str(e)
                        }
                    )
                    
                    time.sleep(delay)
                except (ValidationError, AuthenticationError):
                    # Don't retry client errors
                    raise
                    
            raise last_exception
            
        return wrapper
        
    def implement_circuit_breaker(self, error_threshold: int = 5,
                                reset_timeout: int = 60) -> Callable:
        """
        Implement circuit breaker pattern to prevent cascade failures.
        
        Args:
            error_threshold: Number of errors before opening circuit
            reset_timeout: Time in seconds before attempting reset
            
        Returns:
            Callable: Decorator implementing circuit breaker
        """
        circuit_state = {
            'failures': 0,
            'last_failure': 0,
            'is_open': False
        }
        
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs):
                current_time = time.time()
                
                # Check if circuit is open
                if circuit_state['is_open']:
                    if current_time - circuit_state['last_failure'] > reset_timeout:
                        # Try to reset circuit
                        circuit_state['is_open'] = False
                        circuit_state['failures'] = 0
                    else:
                        raise CircuitBreakerError("Circuit is open")
                        
                try:
                    result = func(*args, **kwargs)
                    # Success, reset failure count
                    circuit_state['failures'] = 0
                    return result
                except Exception as e:
                    circuit_state['failures'] += 1
                    circuit_state['last_failure'] = current_time
                    
                    if circuit_state['failures'] >= error_threshold:
                        circuit_state['is_open'] = True
                        logging.error("Circuit breaker opened")
                        
                    raise
                    
            return wrapper
        return decorator
```

## Cross-Platform Error Handling

Here's how we handle platform-specific issues:

```python
# src/handlers/platform_handler.py

import os
import platform
import tempfile
from pathlib import Path
from typing import Optional, Union

class PlatformHandler:
    """Handles platform-specific error handling and filesystem operations"""
    
    def __init__(self):
        self.platform = platform.system().lower()
        self.temp_dir = self._get_temp_dir()
        
    def _get_temp_dir(self) -> Path:
        """
        Get appropriate temporary directory for current platform.
        
        Returns:
            Path: Platform-specific temporary directory
        """
        if self.platform == 'windows':
            base_dir = os.environ.get('TEMP')
        else:
            base_dir = '/tmp'
            
        app_temp_dir = Path(base_dir) / 'wolfram_api'
        app_temp_dir.mkdir(exist_ok=True)
        return app_temp_dir
        
    def handle_file_operation(self, operation: Callable) -> Callable:
        """
        Decorator to handle file operations across platforms.
        
        Args:
            operation: File operation function to wrap
            
        Returns:
            Callable: Wrapped function with platform-specific error handling
        """
        @wraps(operation)
        def wrapper(*args, **kwargs):
            try:
                return operation(*args, **kwargs)
            except PermissionError:
                if self.platform == 'windows':
                    # Handle Windows-specific permission issues
                    self._handle_windows_permission_error()
                else:
                    # Handle Unix-like permission issues
                    self._handle_unix_permission_error()
            except OSError as e:
                if self.platform == 'windows' and e.winerror == 32:
                    # Handle Windows file-in-use errors
                    self._handle_windows_file_in_use()
                else:
                    raise
                    
        return wrapper
        
    def _handle_windows_permission_error(self):
        """Handle Windows-specific permission errors"""
        import win32security
        import win32api
        # Implementation of Windows-specific permission handling
        pass
        
    def _handle_unix_permission_error(self):
        """Handle Unix-like permission errors"""
        import pwd
        import grp
        # Implementation of Unix-specific permission handling
        pass
```

## Advanced Testing Approaches

Let's implement comprehensive testing strategies:

```python
# tests/test_error_handling.py

import unittest
from unittest.mock import Mock, patch
import pytest
from src.handlers.recovery_handler import RecoveryHandler
from src.handlers.platform_handler import PlatformHandler
from src.exceptions.api_exceptions import *

class TestRecoveryStrategies(unittest.TestCase):
    def setUp(self):
        self.recovery_handler = RecoveryHandler(
            max_retries=3,
            base_delay=0.1,
            max_delay=1.0
        )
        
    @patch('time.sleep')  # Prevent actual delays in tests
    def test_retry_with_backoff(self, mock_sleep):
        """Test retry mechanism with exponential backoff"""
        mock_func = Mock(side_effect=[
            TimeoutError("Timeout"),
            TimeoutError("Timeout"),
            "Success"
        ])
        
        decorated_func = self.recovery_handler.retry_with_backoff(mock_func)
        result = decorated_func()
        
        self.assertEqual(result, "Success")
        self.assertEqual(mock_func.call_count, 3)
        self.assertEqual(mock_sleep.call_count, 2)
        
    def test_circuit_breaker(self):
        """Test circuit breaker pattern"""
        mock_func = Mock(side_effect=Exception("Error"))
        circuit_breaker = self.recovery_handler.implement_circuit_breaker(
            error_threshold=2,
            reset_timeout=1
        )
        decorated_func = circuit_breaker(mock_func)
        
        # Should raise normal exception first
        with self.assertRaises(Exception):
            decorated_func()
            
        # Should raise circuit breaker error after threshold
        with self.assertRaises(CircuitBreakerError):
            decorated_func()
            decorated_func()

@pytest.mark.parametrize("platform,expected_dir", [
    ("windows", r"C:\temp\wolfram_api"),
    ("linux", "/tmp/wolfram_api"),
    ("darwin", "/tmp/wolfram_api")
])
def test_platform_specific_paths(platform, expected_dir):
    """Test platform-specific path handling"""
    with patch('platform.system', return_value=platform):
        handler = PlatformHandler()
        assert str(handler.temp_dir).replace('\\', '/') == \
               expected_dir.replace('\\', '/')
```

## Advanced Error Monitoring

Implement sophisticated error monitoring and reporting:

```python
# src/handlers/monitoring_handler.py

from typing import Dict, Any
import threading
import queue
import time
from dataclasses import dataclass
from datetime import datetime

@dataclass
class ErrorEvent:
    """Represents an error event for monitoring"""
    timestamp: datetime
    error_type: str
    message: str
    details: Dict[str, Any]
    stack_trace: str

class ErrorMonitor:
    """Monitors and analyzes error patterns"""
    
    def __init__(self, window_size: int = 3600):
        self.window_size = window_size  # Time window in seconds
        self.error_queue = queue.Queue()
        self.error_counts: Dict[str, int] = {}
        self.lock = threading.Lock()
        
        # Start background processing
        self.start_processing()
        
    def record_error(self, error: Exception, details: Dict[str, Any] = None):
        """Record an error event for analysis"""
        event = ErrorEvent(
            timestamp=datetime.now(),
            error_type=error.__class__.__name__,
            message=str(error),
            details=details or {},
            stack_trace=traceback.format_exc()
        )
        self.error_queue.put(event)
        
    def start_processing(self):
        """Start background error processing thread"""
        def process_errors():
            while True:
                try:
                    self._process_error_queue()
                    time.sleep(1)
                except Exception as e:
                    logging.error(f"Error in error processing: {e}")
                    
        thread = threading.Thread(target=process_errors, daemon=True)
        thread.start()
        
    def _process_error_queue(self):
        """Process error queue and update statistics"""
        current_time = datetime.now()
        
        while not self.error_queue.empty():
            event = self.error_queue.get()
            
            # Skip old events
            if (current_time - event.timestamp).total_seconds() > self.window_size:
                continue
                
            with self.lock:
                self.error_counts[event.error_type] = \
                    self.error_counts.get(event.error_type, 0) + 1
                    
            self._check_error_patterns(event)
            
    def _check_error_patterns(self, event: ErrorEvent):
        """Analyze error patterns and trigger alerts if needed"""
        with self.lock:
            error_count = self.error_counts.get(event.error_type, 0)
            
            # Alert on error spikes
            if error_count > 10:
                self._trigger_alert(
                    f"High error rate for {event.error_type}",
                    level="WARNING"
                )
                
            # Alert on critical errors
            if isinstance(event.error_type, (AuthenticationError, 
                                           CircuitBreakerError)):
                self._trigger_alert(
                    f"Critical error detected: {event.message}",
                    level="CRITICAL"
                )
                
    def _trigger_alert(self, message: str, level: str = "WARNING"):
        """Trigger monitoring alert"""
        logging.log(
            getattr(logging, level),
            message,
            extra={'monitor_alert': True}
        )
```

## Best Practices and Guidelines

1. **Error Categorization**: Always categorize errors properly:
   - Client Errors (4xx) - Don't retry
   - Server Errors (5xx) - Implement retry logic
   - Network Errors - Use exponential backoff
   - Platform-Specific Errors - Handle according to platform

2. **Logging Guidelines**:
   ```python
   def log_error(logger, error, context=None):
       """Standard error logging format"""
       error_data = {
           'error_type': error.__class__.__name__,
           'error_message': str(error),
           'timestamp': datetime.now().isoformat(),
           'context': context or {}
       }
       
       if hasattr(error, 'details'):
           error_data['details'] = error.details
           
       logger.error(
           f"{error_data['error_type']}: {error_data['error_message']}",
           extra=error_data
       )
   ```

3. **Recovery Strategies**:
   - Implement graceful degradation
   - Use circuit breakers for dependent services
   - Maintain fallback options
   - Cache previous successful responses

4. **Cross-Platform Considerations**:
   - Use `pathlib` for path handling
   - Handle platform-specific file operations
   - Consider encoding differences
   - Test on all target platforms

## Exercise

Implement a complete error handling system that:
1. Handles all API error scenarios
2. Implements proper recovery strategies
3. Provides comprehensive logging
4. Works across different platforms
5. Includes monitoring and alerting

## Additional Resources

- Python Error Handling Documentation
- Cross-Platform Development Guide
- Logging Best Practices
- Circuit Breaker Pattern Implementation
- Error Monitoring Systems Design

This concludes our comprehensive coverage of error handling and validation in the Wolfram Alpha API implementation. Remember to always test your error handling thoroughly and consider all possible failure scenarios in your applications.
