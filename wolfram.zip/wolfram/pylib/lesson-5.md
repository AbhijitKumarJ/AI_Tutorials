# Lesson 5: JSON Integration in Wolfram Alpha API

## Lesson Overview

This lesson focuses on JSON integration within the Wolfram Alpha API Python binding. We'll explore the implementation of JSON encoding and decoding processes, custom serialization methods, and performance optimization techniques. The lesson emphasizes practical implementation while maintaining cross-platform compatibility and robust error handling.

## Prerequisites

Before starting this lesson, ensure you have:
- Completed Lessons 1-4 of the course
- Understanding of JSON data format and structures
- Familiarity with Python's JSON handling capabilities
- Working knowledge of the Wolfram Alpha API response structure

## Project Structure

Our JSON implementation is organized across several files. Here's the relevant structure:

```
Python_Binding_1_1/
├── simplejson/
│   ├── __init__.py       # Main JSON functionality
│   ├── decoder.py        # JSON decoding implementation
│   ├── encoder.py        # JSON encoding implementation
│   ├── scanner.py        # JSON token scanning
│   └── _speedups.c       # C implementation of critical functions
├── wap.py               # Main Wolfram Alpha implementation
└── examples/
    └── json_usage.py    # JSON handling examples
```

## Understanding the JSON Implementation

### Core JSON Architecture

The simplejson implementation in our binding provides a robust foundation for JSON processing. Let's examine the key components:

```python
class JSONEncoder:
    """Core JSON encoding functionality"""
    def __init__(self, skipkeys=False, ensure_ascii=True,
                 check_circular=True, allow_nan=True, sort_keys=False,
                 indent=None, separators=None, encoding='utf-8', default=None):
        self.skipkeys = skipkeys
        self.ensure_ascii = ensure_ascii
        self.check_circular = check_circular
        self.allow_nan = allow_nan
        self.sort_keys = sort_keys
        self.indent = indent
        self.encoding = encoding
        self.default = default
```

The encoder is designed with several important features:
- Skip keys option for handling non-string dictionary keys
- ASCII enforcement for maximum compatibility
- Circular reference detection
- Custom floating-point number handling
- Pretty printing with configurable indentation
- Custom encoding support

### JSON Encoding Process

The encoding process involves several steps to ensure reliable conversion:

```python
def encode(self, obj):
    """Convert Python objects to JSON strings"""
    # Initial setup
    chunks = self.iterencode(obj, _one_shot=True)
    if not isinstance(chunks, (list, tuple)):
        chunks = list(chunks)
    return ''.join(chunks)

def default(self, obj):
    """Handle non-standard Python types"""
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, complex):
        return [obj.real, obj.imag]
    return super().default(obj)
```

### Custom Type Handling

For Wolfram Alpha specific data types, we implement custom serialization:

```python
class WolframJSONEncoder(JSONEncoder):
    """Specialized JSON encoder for Wolfram Alpha data types"""
    def default(self, obj):
        if isinstance(obj, WolframResult):
            return {
                'queryresult': obj.results,
                'success': obj.success,
                'error': obj.error,
                'timing': obj.timing
            }
        if isinstance(obj, Pod):
            return {
                'title': obj.title,
                'scanner': obj.scanner,
                'id': obj.id,
                'subpods': obj.subpods
            }
        return JSONEncoder.default(self, obj)
```

## Performance Optimization

### C Extensions Integration

The binding includes C-based speedups for critical operations:

```c
static PyObject*
_speedups_encode_basestring_ascii(PyObject* self UNUSED, PyObject *pystr)
{
    /* Fast path ASCII strings */
    if (PyString_Check(pystr)) {
        char *str = PyString_AS_STRING(pystr);
        Py_ssize_t size = PyString_GET_SIZE(pystr);
        return ascii_escape_str(str, size);
    }
    /* Handle Unicode strings */
    if (PyUnicode_Check(pystr)) {
        return ascii_escape_unicode(pystr);
    }
    PyErr_SetString(PyExc_TypeError, "first argument must be string");
    return NULL;
}
```

### Memory Management

Efficient memory handling is crucial for large datasets:

```python
def iterencode(self, obj, _one_shot=False):
    """Memory-efficient encoding iterator"""
    if self.check_circular:
        markers = {}
    else:
        markers = None
    if self.ensure_ascii:
        _encoder = encode_basestring_ascii
    else:
        _encoder = encode_basestring
    def floatstr(o, allow_nan=self.allow_nan):
        return _floatstr(o, allow_nan)
        
    _iterencode = _make_iterencode(
        markers, self.default, _encoder, self.indent,
        floatstr, self.key_separator, self.item_separator,
        self.sort_keys, self.skipkeys, _one_shot)
    return _iterencode(obj, 0)
```

## Error Handling and Validation

### Comprehensive Error Checking

Implement thorough error checking throughout the JSON processing:

```python
def decode_wolfram_response(self, json_str):
    """Safely decode Wolfram Alpha JSON responses"""
    try:
        # Validate JSON structure
        if not json_str:
            raise JSONDecodeError("Empty JSON response")
            
        # Parse JSON
        data = json.loads(json_str)
        
        # Validate required fields
        if 'queryresult' not in data:
            raise ValidationError("Missing queryresult field")
            
        # Process response
        return self._process_response(data)
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error: {e}")
        raise WolframJSONError(f"Invalid JSON format: {e}")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise
```

### Data Validation

Implement thorough validation for incoming and outgoing JSON:

```python
class JSONValidator:
    """Validate JSON data structures"""
    def validate_pod(self, pod_data):
        required_fields = {'title', 'scanner', 'id'}
        if not all(field in pod_data for field in required_fields):
            raise ValidationError("Missing required pod fields")
            
        if 'subpods' in pod_data:
            for subpod in pod_data['subpods']:
                self.validate_subpod(subpod)
                
    def validate_response(self, response_data):
        """Validate complete response structure"""
        if not isinstance(response_data, dict):
            raise ValidationError("Response must be a dictionary")
            
        if 'queryresult' not in response_data:
            raise ValidationError("Missing queryresult field")
            
        self.validate_query_result(response_data['queryresult'])
```

## Cross-Platform Considerations

### Character Encoding

Handle character encoding consistently across platforms:

```python
class CrossPlatformJSONHandler:
    """Handle JSON processing across different platforms"""
    def __init__(self, encoding='utf-8'):
        self.encoding = encoding
        
    def encode_text(self, text):
        """Encode text consistently across platforms"""
        if isinstance(text, str):
            return text.encode(self.encoding)
        return text
        
    def decode_text(self, text):
        """Decode text consistently across platforms"""
        if isinstance(text, bytes):
            return text.decode(self.encoding)
        return text
```

### Line Ending Normalization

Ensure consistent line ending handling:

```python
def normalize_json(self, json_str):
    """Normalize JSON string for cross-platform compatibility"""
    # Normalize line endings
    json_str = json_str.replace('\r\n', '\n').replace('\r', '\n')
    
    # Ensure consistent spacing
    json_str = re.sub(r'\s+', ' ', json_str)
    
    return json_str
```

## Practical Implementation Examples

### Basic JSON Processing

```python
def process_wolfram_query(query):
    """Process a Wolfram Alpha query with JSON response"""
    engine = WolframAlphaEngine(appid='YOUR_APP_ID')
    result = engine.perform_query(query)
    
    # Convert to JSON
    json_result = WolframJSONEncoder().encode(result)
    
    # Process and validate
    processor = JSONResponseProcessor()
    return processor.process(json_result)
```

### Advanced JSON Handling

```python
class JSONResponseProcessor:
    """Process and transform JSON responses"""
    def __init__(self):
        self.validator = JSONValidator()
        self.encoder = WolframJSONEncoder()
        
    def process(self, json_data):
        """Process JSON response with full validation"""
        # Validate input
        self.validator.validate_response(json_data)
        
        # Transform data
        transformed = self.transform_response(json_data)
        
        # Encode result
        return self.encoder.encode(transformed)
        
    def transform_response(self, data):
        """Transform response structure as needed"""
        result = {
            'success': data['queryresult']['success'],
            'pods': []
        }
        
        for pod in data['queryresult'].get('pods', []):
            transformed_pod = self.transform_pod(pod)
            result['pods'].append(transformed_pod)
            
        return result
```

## Exercises

1. Basic JSON Processing
Create a script that processes a Wolfram Alpha response and converts it to JSON format.

2. Custom Type Handling
Implement custom JSON encoding for specialized Wolfram Alpha data types.

3. Performance Optimization
Profile and optimize JSON processing for large response datasets.

4. Error Handling
Implement comprehensive error handling for JSON processing with detailed error reporting.

## Best Practices

1. Always validate JSON data before processing
2. Implement proper error handling and logging
3. Use memory-efficient processing for large datasets
4. Maintain consistent encoding across platforms
5. Include proper documentation and type hints
6. Implement comprehensive unit tests
7. Use appropriate error classes for different scenarios
8. Consider performance implications of chosen approaches

## Next Steps

After completing this lesson, you should be comfortable with:
- Implementing JSON encoding and decoding
- Handling custom data types
- Managing cross-platform compatibility
- Optimizing performance
- Implementing proper error handling
- Validating JSON data

The next lesson will focus on Query Optimization, where we'll explore advanced techniques for optimizing query construction and processing.

## Additional Resources

- Python JSON documentation
- Wolfram Alpha API JSON format specification
- Performance optimization guidelines
- Cross-platform development best practices
- JSON security considerations
