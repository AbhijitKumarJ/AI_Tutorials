# Lesson 7: Response Processing - Advanced Pod Processing and Multi-Format Handling

## Lesson Overview

This lesson builds upon our previous understanding of the Wolfram Alpha API to dive deep into advanced response processing techniques. We'll explore how to handle different types of pods, work with various data formats, and implement robust processing strategies that work across different platforms.

## Lesson Duration
- Total Time: 3 hours
- Theory: 1 hour
- Hands-on Practice: 2 hours

## Required Project Structure

Before we begin, let's establish the proper file structure for our lesson project:

```
wolfram_response_processing/
│
├── src/
│   ├── __init__.py
│   ├── pod_processor.py
│   ├── format_handler.py
│   ├── math_content.py
│   └── response_validator.py
│
├── tests/
│   ├── __init__.py
│   ├── test_pod_processor.py
│   ├── test_format_handler.py
│   ├── test_math_content.py
│   └── test_response_validator.py
│
├── examples/
│   ├── basic_pod_processing.py
│   ├── image_handling.py
│   ├── math_processing.py
│   └── multi_format_example.py
│
└── requirements.txt
```

## Detailed Component Implementation

### 1. Advanced Pod Processing

Let's begin by implementing the pod processor in `pod_processor.py`. This component will handle the extraction and organization of data from Wolfram Alpha pods:

```python
# src/pod_processor.py

from typing import Dict, List, Optional
import xml.dom.minidom as minidom

class PodProcessor:
    def __init__(self, response_xml: str):
        """
        Initialize the pod processor with the raw XML response from Wolfram Alpha.
        
        Args:
            response_xml (str): The complete XML response from the API
        """
        self.dom = minidom.parseString(response_xml)
        self.pods = self.dom.getElementsByTagName('pod')
        
    def get_primary_pod(self) -> Optional[Dict]:
        """
        Extract the primary pod (usually marked with primary=true attribute).
        
        Returns:
            Dict containing pod data or None if no primary pod exists
        """
        for pod in self.pods:
            if pod.getAttribute('primary') == 'true':
                return self._process_pod(pod)
        return None
    
    def _process_pod(self, pod: minidom.Element) -> Dict:
        """
        Process an individual pod and extract all relevant information.
        
        Args:
            pod: XML element representing a pod
            
        Returns:
            Dict containing processed pod data
        """
        result = {
            'title': pod.getAttribute('title'),
            'scanner': pod.getAttribute('scanner'),
            'id': pod.getAttribute('id'),
            'position': pod.getAttribute('position'),
            'subpods': []
        }
        
        subpods = pod.getElementsByTagName('subpod')
        for subpod in subpods:
            subpod_data = self._process_subpod(subpod)
            result['subpods'].append(subpod_data)
            
        return result
    
    def _process_subpod(self, subpod: minidom.Element) -> Dict:
        """
        Extract all data from a subpod element.
        
        Args:
            subpod: XML element representing a subpod
            
        Returns:
            Dict containing processed subpod data
        """
        return {
            'title': subpod.getAttribute('title'),
            'plaintext': self._get_plaintext(subpod),
            'img': self._get_image_data(subpod),
            'mathml': self._get_mathml(subpod)
        }
```

### 2. Format Handler Implementation

The format handler in `format_handler.py` will manage different response formats and ensure proper conversion between them:

```python
# src/format_handler.py

import base64
from typing import Optional, Union
import requests
from PIL import Image
from io import BytesIO

class FormatHandler:
    """Handles different response formats from Wolfram Alpha API"""
    
    def __init__(self):
        self.supported_formats = ['plaintext', 'image', 'mathml', 'wav']
        
    def convert_image(self, image_url: str, 
                     output_format: str = 'PNG') -> Optional[bytes]:
        """
        Download and convert image data from Wolfram Alpha.
        
        Args:
            image_url: URL of the image from the API response
            output_format: Desired output format (PNG, JPEG, etc.)
            
        Returns:
            Bytes containing the converted image or None if conversion fails
        """
        try:
            response = requests.get(image_url)
            response.raise_for_status()
            
            img = Image.open(BytesIO(response.content))
            output = BytesIO()
            img.save(output, format=output_format)
            return output.getvalue()
            
        except Exception as e:
            print(f"Error converting image: {str(e)}")
            return None
            
    def process_mathml(self, mathml_content: str) -> Dict:
        """
        Process MathML content and extract useful components.
        
        Args:
            mathml_content: Raw MathML string from the API
            
        Returns:
            Dict containing processed MathML data
        """
        # Implementation for MathML processing
        pass
```

### 3. Mathematical Content Processing

The `math_content.py` file handles specialized processing for mathematical responses:

```python
# src/math_content.py

import re
from typing import Optional, List, Dict

class MathContentProcessor:
    """Processes mathematical content from Wolfram Alpha responses"""
    
    def __init__(self):
        self.math_patterns = {
            'equation': r'(.*?)=(.*)',
            'matrix': r'\{\{.*\}\}',
            'function': r'[a-zA-Z]+\(.*\)'
        }
    
    def parse_mathematical_expression(self, 
                                   expression: str) -> Dict[str, str]:
        """
        Parse various types of mathematical expressions.
        
        Args:
            expression: Raw mathematical expression string
            
        Returns:
            Dict containing parsed components of the expression
        """
        result = {
            'type': self._determine_expression_type(expression),
            'components': self._extract_components(expression),
            'variables': self._extract_variables(expression)
        }
        return result
```

## Platform-Specific Considerations

When implementing response processing, we need to consider several platform-specific aspects:

1. **Character Encoding**: Different platforms may use different default encodings. We ensure consistent UTF-8 encoding across all platforms:

```python
# Add to format_handler.py

def ensure_unicode(self, text: Union[str, bytes]) -> str:
    """Ensure text is properly encoded as Unicode across platforms"""
    if isinstance(text, bytes):
        return text.decode('utf-8')
    return text
```

2. **File Path Handling**: When saving processed results, we use platform-agnostic path handling:

```python
# Add to format_handler.py

from pathlib import Path

def save_processed_result(self, 
                         content: bytes, 
                         filename: str,
                         directory: str = 'output'):
    """Save processed content using platform-agnostic paths"""
    output_path = Path(directory) / filename
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(output_path, 'wb') as f:
        f.write(content)
```

## Practical Examples

Let's look at a comprehensive example that brings together all the components:

```python
# examples/multi_format_example.py

from src.pod_processor import PodProcessor
from src.format_handler import FormatHandler
from src.math_content import MathContentProcessor

def process_complex_response(response_xml: str):
    # Initialize processors
    pod_processor = PodProcessor(response_xml)
    format_handler = FormatHandler()
    math_processor = MathContentProcessor()
    
    # Get primary pod
    primary_pod = pod_processor.get_primary_pod()
    
    # Process each subpod
    for subpod in primary_pod['subpods']:
        # Handle plaintext
        if subpod['plaintext']:
            text = format_handler.ensure_unicode(subpod['plaintext'])
            
        # Handle images
        if subpod['img']:
            image_data = format_handler.convert_image(
                subpod['img']['src'],
                'PNG'
            )
            
        # Handle mathematical content
        if subpod['mathml']:
            math_content = math_processor.parse_mathematical_expression(
                subpod['plaintext']
            )
```

## Testing Strategy

For robust response processing, implement comprehensive tests:

```python
# tests/test_pod_processor.py

import unittest
from src.pod_processor import PodProcessor

class TestPodProcessor(unittest.TestCase):
    def setUp(self):
        self.sample_response = '''
            <queryresult>
                <pod id="Result" title="Result" primary="true">
                    <subpod>
                        <plaintext>Sample result</plaintext>
                        <img src="http://example.com/image.gif"/>
                    </subpod>
                </pod>
            </queryresult>
        '''
        
    def test_primary_pod_extraction(self):
        processor = PodProcessor(self.sample_response)
        primary_pod = processor.get_primary_pod()
        
        self.assertIsNotNone(primary_pod)
        self.assertEqual(primary_pod['id'], 'Result')
```

## Best Practices and Common Pitfalls

1. **Error Handling**: Always implement proper error handling for network requests and file operations:
   ```python
   try:
       # Process response
   except requests.RequestException as e:
       logger.error(f"Network error: {str(e)}")
   except xml.parsers.expat.ExpatError as e:
       logger.error(f"XML parsing error: {str(e)}")
   ```

2. **Memory Management**: For large responses, implement streaming processing:
   ```python
   def process_large_response(self, response_iterator):
       for chunk in response_iterator:
           # Process chunk
           yield processed_result
   ```

3. **Validation**: Always validate response data before processing:
   ```python
   def validate_pod_data(self, pod):
       required_attributes = ['id', 'title']
       return all(pod.getAttribute(attr) 
                 for attr in required_attributes)
   ```

## Exercise

Implement a complete response processor that can:
1. Handle multiple pods with different content types
2. Process and save images in various formats
3. Extract and format mathematical content
4. Generate a comprehensive report of the processed data

## Additional Resources

- Wolfram Alpha API Documentation
- XML Processing Best Practices
- MathML Reference Guide
- Image Processing Libraries Documentation

Remember to maintain proper error handling and logging throughout your implementation to ensure robust processing across different platforms and response types.

