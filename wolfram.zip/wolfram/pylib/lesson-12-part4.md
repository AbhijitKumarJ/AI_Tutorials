# Lesson 12: Advanced Topics and Best Practices
## Part 4: Cross-Platform Maintenance Strategies

### Introduction
Maintaining a Wolfram Alpha API implementation across different platforms presents unique challenges that require careful consideration of platform-specific requirements, deployment strategies, and version management. This section explores comprehensive approaches to cross-platform maintenance and deployment.

### Cross-Platform Configuration Management

First, let's implement a robust configuration management system that handles platform-specific settings:

```python
import os
import yaml
import json
from typing import Dict, Any, Optional
from pathlib import Path
import platform

class ConfigurationManager:
    def __init__(self, base_config_path: str):
        self.base_config_path = Path(base_config_path)
        self.platform = self._detect_platform()
        self.environment = os.getenv('WOLFRAM_ENV', 'development')
        self.configs: Dict[str, Any] = {}
        self._load_configurations()

    def _detect_platform(self) -> str:
        """Detect current platform and return standardized platform identifier"""
        system = platform.system().lower()
        if system == 'darwin':
            return 'macos'
        elif system == 'windows':
            return 'windows'
        elif system == 'linux':
            return self._detect_linux_variant()
        return 'unknown'

    def _detect_linux_variant(self) -> str:
        """Detect specific Linux distribution"""
        try:
            with open('/etc/os-release') as f:
                os_release = dict(line.strip().split('=', 1) for line in f if '=' in line)
            return os_release.get('ID', 'linux').lower()
        except FileNotFoundError:
            return 'linux'

    def _load_configurations(self):
        """Load configuration files with platform-specific overrides"""
        # Load base configuration
        base_config = self._load_yaml_config('base_config.yaml')
        
        # Load platform-specific configuration
        platform_config = self._load_yaml_config(f'config_{self.platform}.yaml')
        
        # Load environment-specific configuration
        env_config = self._load_yaml_config(f'config_{self.environment}.yaml')
        
        # Merge configurations with proper precedence
        self.configs = self._deep_merge(base_config, platform_config, env_config)

    def _load_yaml_config(self, filename: str) -> Dict[str, Any]:
        """Load and parse YAML configuration file"""
        config_path = self.base_config_path / filename
        if config_path.exists():
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        return {}

    def _deep_merge(self, *dicts: Dict) -> Dict:
        """Recursively merge dictionaries with proper override behavior"""
        result = {}
        for dictionary in dicts:
            for key, value in dictionary.items():
                if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                    result[key] = self._deep_merge(result[key], value)
                else:
                    result[key] = value
        return result

    def get_config(self, key: str, default: Any = None) -> Any:
        """Get configuration value with dot notation support"""
        try:
            value = self.configs
            for k in key.split('.'):
                value = value[k]
            return value
        except (KeyError, TypeError):
            return default
```

### Version Management and Compatibility

Implement a version management system that handles cross-platform compatibility:

```python
from packaging import version
from typing import Set, List, Tuple
import subprocess
import sys

class VersionManager:
    def __init__(self):
        self.current_version = self._get_current_version()
        self.platform_requirements = self._load_platform_requirements()
        self.compatibility_matrix = self._load_compatibility_matrix()

    def _get_current_version(self) -> str:
        """Get current version of the implementation"""
        try:
            return "1.1.0"  # Replace with actual version detection
        except Exception as e:
            logging.error(f"Failed to detect version: {e}")
            return "unknown"

    def _load_platform_requirements(self) -> Dict[str, Dict[str, str]]:
        """Load platform-specific requirements"""
        return {
            'windows': {
                'python_version': '>=3.7,<4.0',
                'dependencies': {
                    'requests': '>=2.25.0',
                    'urllib3': '>=1.26.0'
                }
            },
            'linux': {
                'python_version': '>=3.6,<4.0',
                'dependencies': {
                    'requests': '>=2.24.0',
                    'urllib3': '>=1.25.0'
                }
            },
            'macos': {
                'python_version': '>=3.7,<4.0',
                'dependencies': {
                    'requests': '>=2.25.0',
                    'urllib3': '>=1.26.0'
                }
            }
        }

    async def check_compatibility(self) -> Tuple[bool, List[str]]:
        """Check system compatibility and return status with issues"""
        issues = []
        platform_reqs = self.platform_requirements.get(sys.platform, {})
        
        # Check Python version
        if 'python_version' in platform_reqs:
            if not self._check_python_version(platform_reqs['python_version']):
                issues.append(f"Python version does not meet requirements: {platform_reqs['python_version']}")

        # Check dependencies
        if 'dependencies' in platform_reqs:
            dependency_issues = await self._check_dependencies(platform_reqs['dependencies'])
            issues.extend(dependency_issues)

        return len(issues) == 0, issues

    def _check_python_version(self, requirement: str) -> bool:
        """Check if current Python version meets requirements"""
        current = version.parse(platform.python_version())
        req = version.parse(requirement.replace('>=', '').replace('<', ''))
        return current >= req

    async def _check_dependencies(self, requirements: Dict[str, str]) -> List[str]:
        """Check if installed dependencies meet requirements"""
        issues = []
        for package, req in requirements.items():
            try:
                import pkg_resources
                installed = pkg_resources.get_distribution(package)
                if not self._version_satisfies_requirement(installed.version, req):
                    issues.append(f"Package {package} version {installed.version} does not meet requirement {req}")
            except pkg_resources.DistributionNotFound:
                issues.append(f"Required package {package} is not installed")
        return issues

    def _version_satisfies_requirement(self, installed: str, requirement: str) -> bool:
        """Check if installed version satisfies requirement"""
        try:
            installed_version = version.parse(installed)
            req_version = version.parse(requirement.replace('>=', ''))
            return installed_version >= req_version
        except version.InvalidVersion:
            return False
```

### Deployment Management

Implement a deployment manager that handles cross-platform deployment:

```python
from enum import Enum
from dataclasses import dataclass
import shutil
import tempfile

class DeploymentEnvironment(Enum):
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"

@dataclass
class DeploymentConfig:
    environment: DeploymentEnvironment
    platform: str
    config_path: str
    backup_path: Optional[str] = None
    require_validation: bool = True

class DeploymentManager:
    def __init__(self, config: DeploymentConfig):
        self.config = config
        self.version_manager = VersionManager()
        self.logger = logging.getLogger(__name__)

    async def deploy(self) -> bool:
        """Execute deployment process"""
        try:
            # Validate deployment prerequisites
            if not await self._validate_deployment():
                return False

            # Create backup if specified
            if self.config.backup_path:
                await self._create_backup()

            # Perform platform-specific preparation
            await self._prepare_platform()

            # Execute deployment steps
            await self._execute_deployment_steps()

            # Verify deployment
            if not await self._verify_deployment():
                await self._rollback()
                return False

            return True

        except Exception as e:
            self.logger.error(f"Deployment failed: {e}")
            await self._rollback()
            return False

    async def _validate_deployment(self) -> bool:
        """Validate deployment prerequisites"""
        # Check system compatibility
        compatible, issues = await self.version_manager.check_compatibility()
        if not compatible:
            self.logger.error(f"Compatibility check failed: {issues}")
            return False

        # Validate configuration
        if not self._validate_configuration():
            return False

        return True

    async def _prepare_platform(self):
        """Prepare platform-specific requirements"""
        platform_prep = {
            'windows': self._prepare_windows,
            'linux': self._prepare_linux,
            'macos': self._prepare_macos
        }
        
        prep_func = platform_prep.get(self.config.platform)
        if prep_func:
            await prep_func()

    async def _create_backup(self):
        """Create backup of current deployment"""
        try:
            backup_dir = Path(self.config.backup_path)
            backup_dir.mkdir(parents=True, exist_ok=True)
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_name = f"backup_{timestamp}"
            
            # Create temporary directory for backup
            with tempfile.TemporaryDirectory() as temp_dir:
                # Copy current deployment to temporary directory
                shutil.copytree(self.config.config_path, temp_dir, dirs_exist_ok=True)
                
                # Create compressed backup
                shutil.make_archive(
                    str(backup_dir / backup_name),
                    'zip',
                    temp_dir
                )
                
            self.logger.info(f"Backup created: {backup_name}")
            return True
        except Exception as e:
            self.logger.error(f"Backup creation failed: {e}")
            return False

    async def _verify_deployment(self) -> bool:
        """Verify deployment success"""
        try:
            # Verify file integrity
            if not self._verify_file_integrity():
                return False

            # Verify configuration
            if not self._verify_configuration():
                return False

            # Verify connectivity
            if not await self._verify_connectivity():
                return False

            return True
        except Exception as e:
            self.logger.error(f"Deployment verification failed: {e}")
            return False

    async def _rollback(self):
        """Rollback deployment if necessary"""
        if not self.config.backup_path:
            self.logger.warning("No backup path specified, rollback not possible")
            return

        try:
            # Find latest backup
            backup_dir = Path(self.config.backup_path)
            backups = list(backup_dir.glob("backup_*.zip"))
            if not backups:
                self.logger.error("No backups found for rollback")
                return

            latest_backup = max(backups, key=lambda x: x.stat().st_mtime)

            # Restore from backup
            with tempfile.TemporaryDirectory() as temp_dir:
                shutil.unpack_archive(str(latest_backup), temp_dir)
                shutil.rmtree(self.config.config_path)
                shutil.copytree(temp_dir, self.config.config_path)

            self.logger.info("Rollback completed successfully")
        except Exception as e:
            self.logger.error(f"Rollback failed: {e}")
```

### Production Monitoring

Implement a cross-platform monitoring system:

```python
from abc import ABC, abstractmethod
import psutil
import platform
from typing import Dict, List, Any
import json

class MetricsCollector(ABC):
    @abstractmethod
    async def collect_metrics(self) -> Dict[str, Any]:
        pass

class SystemMetricsCollector(MetricsCollector):
    async def collect_metrics(self) -> Dict[str, Any]:
        """Collect system-specific metrics"""
        metrics = {
            'cpu_usage': psutil.cpu_percent(interval=1),
            'memory_usage': psutil.virtual_memory().percent,
            'disk_usage': psutil.disk_usage('/').percent,
            'platform_info': {
                'system': platform.system(),
                'release': platform.release(),
                'version': platform.version(),
                'machine': platform.machine()
            }
        }
        
        # Add platform-specific metrics
        if platform.system() == 'Linux':
            metrics.update(await self._collect_linux_metrics())
        elif platform.system() == 'Windows':
            metrics.update(await self._collect_windows_metrics())
        elif platform.system() == 'Darwin':
            metrics.update(await self._collect_macos_metrics())

        return metrics

    async def _collect_linux_metrics(self) -> Dict[str, Any]:
        """Collect Linux-specific metrics"""
        return {
            'load_average': os.getloadavg(),
            'processes': len(psutil.pids())
        }

class APIMetricsCollector(MetricsCollector):
    async def collect_metrics(self) -> Dict[str, Any]:
        """Collect API-specific metrics"""
        return {
            'api_calls': self._get_api_call_count(),
            'response_times': self._get_response_times(),
            'error_rates': self._get_error_rates()
        }

class MetricsManager:
    def __init__(self, export_path: str):
        self.export_path = Path(export_path)
        self.collectors: List[MetricsCollector] = [
            SystemMetricsCollector(),
            APIMetricsCollector()
        ]
        self.logger = logging.getLogger(__name__)

    async def collect_and_export(self):
        """Collect and export all metrics"""
        try:
            metrics = {}
            for collector in self.collectors:
                metrics.update(await collector.collect_metrics())

            # Export metrics
            await self._export_metrics(metrics)

        except Exception as e:
            self.logger.error(f"Metrics collection failed: {e}")

    async def _export_metrics(self, metrics: Dict[str, Any]):
        """Export metrics to specified format and location"""
        timestamp = datetime.now().isoformat()
        metrics['timestamp'] = timestamp

        # Ensure export directory exists
        self.export_path.mkdir(parents=True, exist_ok=True)

        # Export to JSON file
        export_file = self.export_path / f"metrics_{timestamp}.json"
        with open(export_file, 'w') as f:
            json.dump(metrics, f, indent=2)
```

This final section completes our comprehensive coverage of cross-platform maintenance strategies, including configuration management, version control, deployment processes, and production monitoring. These implementations provide a robust foundation for maintaining a Wolfram Alpha API implementation across different platforms and environments.

The complete Lesson 12 now provides a thorough exploration of:
1. Performance Optimization Techniques
2. Scalability Considerations
3. Advanced Error Handling Patterns
4. Cross-Platform Maintenance Strategies

This comprehensive coverage ensures that developers can build and maintain robust, scalable, and reliable Wolfram Alpha API implementations across different platforms and environments.