# Lesson 12: Advanced Topics and Best Practices
## Part 2: Scalability Considerations

### Introduction
Building upon our performance optimization strategies, we'll now explore how to scale Wolfram Alpha API implementations effectively. Scalability ensures your application can handle growing workloads while maintaining performance and reliability.

### System Architecture for Scalability

#### Distributed Query System
Let's implement a distributed query system that can scale horizontally:

```python
from typing import Dict, List, Optional
import redis
from distributed import Client, LocalCluster

class DistributedQuerySystem:
    def __init__(self, redis_host: str = 'localhost', redis_port: int = 6379):
        """
        Initialize distributed query system with Redis for coordination
        and Dask for distributed computing.
        """
        self.redis_client = redis.Redis(host=redis_host, port=redis_port)
        self.cluster = LocalCluster()
        self.client = Client(self.cluster)
        self.query_partitions: Dict[str, List[str]] = {}

    def partition_queries(self, queries: List[str], partition_size: int = 100):
        """
        Partition incoming queries for distributed processing.
        
        Args:
            queries: List of query strings to process
            partition_size: Number of queries per partition
        """
        partitions = []
        for i in range(0, len(queries), partition_size):
            partition = queries[i:i + partition_size]
            partition_id = f"partition_{i//partition_size}"
            self.query_partitions[partition_id] = partition
            partitions.append(partition)
        return partitions

    async def process_distributed_queries(self):
        """Process queries across distributed workers"""
        futures = []
        for partition_id, queries in self.query_partitions.items():
            future = self.client.submit(self._process_partition, queries)
            futures.append(future)
        return await self.client.gather(futures)

    def _process_partition(self, queries: List[str]):
        """Process a single partition of queries"""
        results = []
        for query in queries:
            result = self._execute_query(query)
            results.append(result)
        return results
```

### Load Balancing Implementation

Implement a load balancer to distribute queries across multiple API instances:

```python
from collections import deque
import asyncio
from dataclasses import dataclass
from typing import List, Deque

@dataclass
class ApiInstance:
    """Represents a Wolfram Alpha API instance"""
    id: str
    endpoint: str
    current_load: int = 0
    max_load: int = 100
    health_status: bool = True

class LoadBalancer:
    def __init__(self, api_instances: List[ApiInstance]):
        self.instances: Deque[ApiInstance] = deque(api_instances)
        self.lock = asyncio.Lock()
        
    async def get_next_instance(self) -> Optional[ApiInstance]:
        """Get next available API instance using round-robin with health checks"""
        async with self.lock:
            if not self.instances:
                return None
                
            # Rotate until we find a healthy instance
            for _ in range(len(self.instances)):
                instance = self.instances[0]
                self.instances.rotate(-1)
                
                if instance.health_status and instance.current_load < instance.max_load:
                    return instance
        return None

    async def execute_balanced_query(self, query: str):
        """Execute query using load balanced API instances"""
        instance = await self.get_next_instance()
        if not instance:
            raise RuntimeError("No healthy API instances available")
            
        try:
            instance.current_load += 1
            result = await self._execute_query(instance, query)
            return result
        finally:
            instance.current_load -= 1

    async def _execute_query(self, instance: ApiInstance, query: str):
        """Execute query on specific API instance"""
        # Implementation of actual query execution
        pass
```

### Horizontal Scaling Manager

Implement a system to manage horizontal scaling based on load:

```python
import psutil
import statistics
from datetime import datetime, timedelta

class ScalingManager:
    def __init__(self, min_instances: int = 2, max_instances: int = 10):
        self.min_instances = min_instances
        self.max_instances = max_instances
        self.current_instances = min_instances
        self.metrics_history = []
        self.scaling_cooldown = timedelta(minutes=5)
        self.last_scale_time = datetime.now()

    def collect_metrics(self):
        """Collect system metrics for scaling decisions"""
        metrics = {
            'cpu_percent': psutil.cpu_percent(interval=1),
            'memory_percent': psutil.virtual_memory().percent,
            'query_latency': self._get_average_query_latency(),
            'query_queue_length': self._get_queue_length()
        }
        self.metrics_history.append(metrics)
        
        # Keep last hour of metrics
        if len(self.metrics_history) > 360:  # 1 hour at 10-second intervals
            self.metrics_history.pop(0)

    def evaluate_scaling_needs(self):
        """Determine if scaling is needed based on metrics"""
        if datetime.now() - self.last_scale_time < self.scaling_cooldown:
            return None

        recent_metrics = self.metrics_history[-30:]  # Last 5 minutes
        avg_cpu = statistics.mean(m['cpu_percent'] for m in recent_metrics)
        avg_latency = statistics.mean(m['query_latency'] for m in recent_metrics)

        if avg_cpu > 80 and self.current_instances < self.max_instances:
            return 'scale_up'
        elif avg_cpu < 20 and self.current_instances > self.min_instances:
            return 'scale_down'
        return None

    async def apply_scaling_decision(self, decision: str):
        """Apply scaling decision and manage instance lifecycle"""
        if decision == 'scale_up':
            await self._add_instance()
            self.current_instances += 1
        elif decision == 'scale_down':
            await self._remove_instance()
            self.current_instances -= 1
        
        self.last_scale_time = datetime.now()
```

### Database Sharding Strategy

Implement database sharding for efficient data storage and retrieval:

```python
from hashlib import md5
from typing import Any, Dict

class ShardManager:
    def __init__(self, shard_count: int = 4):
        self.shard_count = shard_count
        self.shard_connections: Dict[int, Any] = {}
        self._initialize_shards()

    def _initialize_shards(self):
        """Initialize connections to all database shards"""
        for shard_id in range(self.shard_count):
            self.shard_connections[shard_id] = self._create_shard_connection(shard_id)

    def get_shard_id(self, key: str) -> int:
        """Determine shard ID for a given key using consistent hashing"""
        hash_value = int(md5(key.encode()).hexdigest(), 16)
        return hash_value % self.shard_count

    async def store_result(self, query: str, result: Dict[str, Any]):
        """Store query result in appropriate shard"""
        shard_id = self.get_shard_id(query)
        connection = self.shard_connections[shard_id]
        await connection.store(query, result)

    async def retrieve_result(self, query: str) -> Optional[Dict[str, Any]]:
        """Retrieve query result from appropriate shard"""
        shard_id = self.get_shard_id(query)
        connection = self.shard_connections[shard_id]
        return await connection.retrieve(query)
```

### Monitoring and Alerts for Scalability

Implement a monitoring system to track scaling metrics:

```python
import logging
from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional

@dataclass
class ScalingEvent:
    timestamp: datetime
    event_type: str
    reason: str
    metrics: Dict[str, float]

class ScalingMonitor:
    def __init__(self):
        self.scaling_history: List[ScalingEvent] = []
        self.alert_thresholds = {
            'cpu_percent': 90,
            'memory_percent': 85,
            'query_latency': 5000,  # ms
            'error_rate': 0.05
        }

    def record_scaling_event(self, event_type: str, reason: str, metrics: Dict[str, float]):
        """Record scaling event for analysis"""
        event = ScalingEvent(
            timestamp=datetime.now(),
            event_type=event_type,
            reason=reason,
            metrics=metrics
        )
        self.scaling_history.append(event)
        self._check_alerts(metrics)

    def _check_alerts(self, metrics: Dict[str, float]):
        """Check if any metrics exceed alert thresholds"""
        for metric, value in metrics.items():
            if metric in self.alert_thresholds:
                if value > self.alert_thresholds[metric]:
                    self._send_alert(metric, value)

    def _send_alert(self, metric: str, value: float):
        """Send alert for exceeded threshold"""
        logging.warning(f"Alert: {metric} exceeded threshold: {value}")
        # Implement alert notification system (email, Slack, etc.)
```

This section provides a comprehensive overview of scalability considerations, including distributed systems, load balancing, horizontal scaling, database sharding, and monitoring. Would you like me to proceed with the next section on advanced error handling patterns?