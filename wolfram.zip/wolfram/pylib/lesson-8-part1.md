# Lesson 8: Error Handling and Validation
## Part 1: Core Concepts and Implementation

## Lesson Overview

This comprehensive lesson focuses on building robust error handling and validation systems for Wolfram Alpha API implementations. We'll explore how to create reliable, maintainable, and cross-platform compatible error handling mechanisms that ensure your applications remain stable and user-friendly even when encountering unexpected situations.

## Lesson Duration
- Total Time: 3 hours
- Theory: 1 hour
- Hands-on Practice: 2 hours

## Required Project Structure

Let's establish a well-organized project structure that separates concerns and promotes maintainability:

```
wolfram_error_handling/
│
├── src/
│   ├── __init__.py
│   ├── exceptions/
│   │   ├── __init__.py
│   │   ├── api_exceptions.py
│   │   ├── validation_exceptions.py
│   │   └── system_exceptions.py
│   │
│   ├── validation/
│   │   ├── __init__.py
│   │   ├── input_validator.py
│   │   ├── response_validator.py
│   │   └── schema_validator.py
│   │
│   ├── handlers/
│   │   ├── __init__.py
│   │   ├── error_handler.py
│   │   ├── logging_handler.py
│   │   └── recovery_handler.py
│   │
│   └── utils/
│       ├── __init__.py
│       └── error_utils.py
│
├── tests/
│   ├── __init__.py
│   ├── test_input_validation.py
│   ├── test_response_validation.py
│   ├── test_error_handling.py
│   └── test_recovery.py
│
├── examples/
│   ├── basic_error_handling.py
│   ├── advanced_validation.py
│   └── recovery_strategies.py
│
├── config/
│   ├── logging_config.yaml
│   └── validation_schemas.json
│
└── requirements.txt
```

## Core Exception Classes

Let's start by implementing our custom exception hierarchy in `api_exceptions.py`:

```python
# src/exceptions/api_exceptions.py

class WolframAPIError(Exception):
    """Base exception class for all Wolfram API related errors"""
    
    def __init__(self, message: str, error_code: int = None, 
                 details: dict = None):
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        super().__init__(self.message)

class ValidationError(WolframAPIError):
    """Raised when input validation fails"""
    pass

class ResponseError(WolframAPIError):
    """Raised when API response is invalid or unexpected"""
    pass

class AuthenticationError(WolframAPIError):
    """Raised when authentication fails"""
    pass

class RateLimitError(WolframAPIError):
    """Raised when API rate limit is exceeded"""
    pass

class TimeoutError(WolframAPIError):
    """Raised when API request times out"""
    pass
```

## Input Validation System

The input validation system ensures all data sent to the API is correct and well-formed:

```python
# src/validation/input_validator.py

from typing import Any, Dict, Optional, Union
import re
from ..exceptions.api_exceptions import ValidationError

class InputValidator:
    """Validates all input parameters before sending to Wolfram Alpha API"""
    
    def __init__(self):
        self.query_patterns = {
            'mathematical': r'^[\d\s\+\-\*\/\(\)\=]*$',
            'unit_conversion': r'^convert\s+\d+(\.\d+)?\s+\w+\s+to\s+\w+$',
            'general_query': r'^[a-zA-Z0-9\s\?\.\,\!]+$'
        }
        
    def validate_query(self, query: str, query_type: str = 'general_query') -> bool:
        """
        Validate query string based on its expected type.
        
        Args:
            query: The query string to validate
            query_type: Type of query (mathematical, unit_conversion, general_query)
            
        Returns:
            bool: True if valid, raises ValidationError if invalid
            
        Raises:
            ValidationError: If query is invalid
        """
        if not query or not isinstance(query, str):
            raise ValidationError("Query must be a non-empty string")
            
        if query_type not in self.query_patterns:
            raise ValidationError(f"Unknown query type: {query_type}")
            
        pattern = self.query_patterns[query_type]
        if not re.match(pattern, query):
            raise ValidationError(
                f"Query format invalid for type {query_type}",
                details={'query': query, 'expected_pattern': pattern}
            )
        
        return True
        
    def validate_appid(self, appid: str) -> bool:
        """
        Validate Wolfram Alpha AppID format.
        
        Args:
            appid: The AppID to validate
            
        Returns:
            bool: True if valid, raises ValidationError if invalid
        """
        if not appid or not isinstance(appid, str):
            raise ValidationError("AppID must be a non-empty string")
            
        pattern = r'^[A-Z0-9-]{8,}$'
        if not re.match(pattern, appid):
            raise ValidationError("Invalid AppID format")
            
        return True
        
    def validate_parameters(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate optional API parameters.
        
        Args:
            params: Dictionary of parameter names and values
            
        Returns:
            Dict: Validated and sanitized parameters
            
        Raises:
            ValidationError: If any parameter is invalid
        """
        validated_params = {}
        
        # Define parameter validation rules
        validation_rules = {
            'format': lambda x: x in ['plaintext', 'image', 'mathml'],
            'units': lambda x: x in ['metric', 'imperial'],
            'timeout': lambda x: isinstance(x, (int, float)) and 0 < x <= 60,
            'width': lambda x: isinstance(x, int) and 0 < x <= 2000
        }
        
        for param_name, value in params.items():
            if param_name not in validation_rules:
                raise ValidationError(f"Unknown parameter: {param_name}")
                
            validator = validation_rules[param_name]
            if not validator(value):
                raise ValidationError(
                    f"Invalid value for parameter {param_name}",
                    details={'parameter': param_name, 'value': value}
                )
                
            validated_params[param_name] = value
            
        return validated_params
```

## Response Validation System

The response validator ensures API responses are complete and well-formed:

```python
# src/validation/response_validator.py

from typing import Dict, Optional, Union
import xml.etree.ElementTree as ET
from ..exceptions.api_exceptions import ResponseError

class ResponseValidator:
    """Validates responses from Wolfram Alpha API"""
    
    def __init__(self):
        self.required_elements = ['queryresult']
        self.required_attributes = ['success', 'error']
        
    def validate_xml_response(self, response_text: str) -> ET.Element:
        """
        Validate XML response from the API.
        
        Args:
            response_text: Raw XML response string
            
        Returns:
            ET.Element: Parsed XML root element
            
        Raises:
            ResponseError: If response is invalid
        """
        try:
            root = ET.fromstring(response_text)
        except ET.ParseError as e:
            raise ResponseError(
                "Invalid XML response",
                details={'parse_error': str(e)}
            )
            
        # Validate required elements
        for element in self.required_elements:
            if root.find(element) is None:
                raise ResponseError(
                    f"Missing required element: {element}",
                    details={'response': response_text}
                )
                
        # Validate required attributes
        for attr in self.required_attributes:
            if attr not in root.attrib:
                raise ResponseError(
                    f"Missing required attribute: {attr}",
                    details={'response': response_text}
                )
                
        return root
        
    def validate_pod_content(self, pod: ET.Element) -> bool:
        """
        Validate content of individual pods in the response.
        
        Args:
            pod: XML element representing a pod
            
        Returns:
            bool: True if valid, raises ResponseError if invalid
        """
        required_pod_attrs = ['title', 'id']
        for attr in required_pod_attrs:
            if attr not in pod.attrib:
                raise ResponseError(
                    f"Pod missing required attribute: {attr}",
                    details={'pod_id': pod.get('id', 'unknown')}
                )
                
        # Ensure pod has at least one subpod
        subpods = pod.findall('subpod')
        if not subpods:
            raise ResponseError(
                "Pod contains no subpods",
                details={'pod_id': pod.get('id')}
            )
            
        return True
```

## Logging Configuration

Proper logging is crucial for error tracking and debugging. Here's our logging configuration:

```yaml
# config/logging_config.yaml

version: 1
formatters:
  standard:
    format: '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
  error:
    format: '%(asctime)s - %(name)s - %(levelname)s - %(message)s - %(filename)s:%(lineno)d'

handlers:
  console:
    class: logging.StreamHandler
    level: INFO
    formatter: standard
    stream: ext://sys.stdout

  error_file:
    class: logging.FileHandler
    level: ERROR
    formatter: error
    filename: error.log

  debug_file:
    class: logging.FileHandler
    level: DEBUG
    formatter: standard
    filename: debug.log

loggers:
  wolfram_api:
    level: DEBUG
    handlers: [console, error_file, debug_file]
    propagate: no
```

## Implementation Example

Let's look at how these components work together:

```python
# examples/basic_error_handling.py

from src.validation.input_validator import InputValidator
from src.validation.response_validator import ResponseValidator
from src.exceptions.api_exceptions import ValidationError, ResponseError
import logging.config
import yaml
import requests

def setup_logging():
    """Initialize logging configuration"""
    with open('config/logging_config.yaml', 'r') as f:
        config = yaml.safe_load(f)
        logging.config.dictConfig(config)
    return logging.getLogger('wolfram_api')

def make_api_request(query: str, appid: str, **params):
    """
    Make an API request with full validation and error handling.
    
    Args:
        query: Query string
        appid: Wolfram Alpha AppID
        **params: Additional API parameters
        
    Returns:
        dict: Processed API response
        
    Raises:
        Various exceptions based on error type
    """
    logger = setup_logging()
    input_validator = InputValidator()
    response_validator = ResponseValidator()
    
    try:
        # Validate inputs
        input_validator.validate_query(query)
        input_validator.validate_appid(appid)
        validated_params = input_validator.validate_parameters(params)
        
        # Make API request
        response = requests.get(
            'http://api.wolframalpha.com/v1/query',
            params={'input': query, 'appid': appid, **validated_params}
        )
        response.raise_for_status()
        
        # Validate response
        root = response_validator.validate_xml_response(response.text)
        
        # Process successful response
        return {'success': True, 'data': root}
        
    except ValidationError as e:
        logger.error(f"Validation error: {e.message}", 
                    extra={'details': e.details})
        raise
        
    except ResponseError as e:
        logger.error(f"Response error: {e.message}", 
                    extra={'details': e.details})
        raise
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Request error: {str(e)}")
        raise
        
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        raise
```

Would you like me to proceed with Part 2 of the lesson, which covers advanced error handling patterns, cross-platform considerations, recovery strategies, and testing approaches?