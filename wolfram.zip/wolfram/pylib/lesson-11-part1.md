# Lesson 11: Integration Patterns with Wolfram Alpha API
## Part 1: Core Implementation and Architecture

## Lesson Overview

This first part focuses on building reusable integration patterns for the Wolfram Alpha API. We'll develop a flexible architecture that can be adapted for different frameworks and use cases while maintaining consistency and reliability.

## Prerequisites
- Completion of Lessons 1-10
- Understanding of design patterns
- Experience with Python packaging
- Knowledge of API integration patterns
- Familiarity with testing methodologies

## Lesson Duration
- 3 hours of direct instruction
- 2 hours of hands-on implementation
- 1 hour for testing and validation

## Project Structure

We'll implement a comprehensive integration framework:

```
wolfram_integration/
│
├── src/
│   ├── __init__.py
│   │
│   ├── core/
│   │   ├── __init__.py
│   │   ├── interface.py        # Base integration interfaces
│   │   ├── adapters.py         # Framework adapters
│   │   └── patterns.py         # Integration patterns
│   │
│   ├── frameworks/
│   │   ├── __init__.py
│   │   ├── flask_integration.py
│   │   ├── django_integration.py
│   │   ├── fastapi_integration.py
│   │   └── cli_integration.py
│   │
│   ├── patterns/
│   │   ├── __init__.py
│   │   ├── publisher.py        # Event publishing
│   │   ├── observer.py         # Event observation
│   │   └── factory.py          # Integration factory
│   │
│   └── utils/
│       ├── __init__.py
│       ├── validation.py       # Input validation
│       └── conversion.py       # Data conversion
│
├── examples/
│   ├── flask_example/
│   ├── django_example/
│   ├── fastapi_example/
│   └── cli_example/
│
└── tests/
    ├── __init__.py
    ├── unit/
    └── integration/
```

## Detailed Content

### 1. Core Integration Interface

First, let's create a robust interface that all framework integrations will implement.

In `src/core/interface.py`:
```python
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from dataclasses import dataclass

@dataclass
class IntegrationConfig:
    """Configuration for Wolfram Alpha integration"""
    app_id: str
    timeout: int = 30
    max_retries: int = 3
    cache_enabled: bool = True
    async_mode: bool = False

class WolframIntegrationBase(ABC):
    """Base interface for framework integrations"""
    
    def __init__(self, config: IntegrationConfig):
        self.config = config
        self._validate_config()
        self.initialize()
    
    @abstractmethod
    def initialize(self) -> None:
        """Initialize framework-specific components"""
        pass
    
    @abstractmethod
    async def query(self, 
                   input_query: str, 
                   context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Execute a Wolfram Alpha query"""
        pass
    
    @abstractmethod
    async def validate_response(self, 
                              response: Dict[str, Any]) -> bool:
        """Validate API response"""
        pass
    
    def _validate_config(self) -> None:
        """Validate integration configuration"""
        if not self.config.app_id:
            raise ValueError("AppID is required")
        if self.config.timeout < 1:
            raise ValueError("Timeout must be positive")
        if self.config.max_retries < 0:
            raise ValueError("Max retries cannot be negative")
```

### 2. Integration Patterns Implementation

Let's implement common integration patterns that can be reused across frameworks.

In `src/patterns/factory.py`:
```python
from typing import Type, Dict, Any
from ..core.interface import WolframIntegrationBase, IntegrationConfig

class IntegrationFactory:
    """Factory for creating framework-specific integrations"""
    
    _integrations: Dict[str, Type[WolframIntegrationBase]] = {}
    
    @classmethod
    def register(cls, 
                name: str, 
                integration_class: Type[WolframIntegrationBase]) -> None:
        """Register a new integration implementation"""
        if name in cls._integrations:
            raise ValueError(f"Integration {name} already registered")
        cls._integrations[name] = integration_class
    
    @classmethod
    def create(cls, 
              name: str, 
              config: IntegrationConfig) -> WolframIntegrationBase:
        """Create an integration instance"""
        if name not in cls._integrations:
            raise ValueError(f"Integration {name} not found")
        return cls._integrations[name](config)
    
    @classmethod
    def list_available(cls) -> Dict[str, str]:
        """List available integrations with descriptions"""
        return {
            name: integration.__doc__ or "No description"
            for name, integration in cls._integrations.items()
        }
```

In `src/patterns/observer.py`:
```python
from typing import Callable, Dict, Set, Any
from enum import Enum, auto

class IntegrationEvent(Enum):
    """Events that can be observed"""
    QUERY_START = auto()
    QUERY_SUCCESS = auto()
    QUERY_ERROR = auto()
    RESPONSE_VALIDATION = auto()
    CACHE_HIT = auto()
    CACHE_MISS = auto()

class IntegrationObserver:
    """Observer pattern for integration events"""
    
    def __init__(self):
        self._observers: Dict[IntegrationEvent, Set[Callable]] = {
            event: set() for event in IntegrationEvent
        }
    
    def subscribe(self, 
                 event: IntegrationEvent, 
                 callback: Callable) -> None:
        """Subscribe to an integration event"""
        self._observers[event].add(callback)
    
    def unsubscribe(self, 
                    event: IntegrationEvent, 
                    callback: Callable) -> None:
        """Unsubscribe from an integration event"""
        self._observers[event].discard(callback)
    
    async def notify(self, 
                    event: IntegrationEvent, 
                    data: Any) -> None:
        """Notify all observers of an event"""
        for callback in self._observers[event]:
            try:
                await callback(data)
            except Exception as e:
                logger.error(f"Observer error: {str(e)}")
```

### 3. Framework Adapters

Now let's implement framework-specific adapters that provide seamless integration.

In `src/core/adapters.py`:
```python
from typing import Any, Dict, Optional
from abc import ABC, abstractmethod
from .interface import WolframIntegrationBase, IntegrationConfig

class FrameworkAdapter(ABC):
    """Base adapter for framework integration"""
    
    def __init__(self, integration: WolframIntegrationBase):
        self.integration = integration
        self.initialize_adapter()
    
    @abstractmethod
    def initialize_adapter(self) -> None:
        """Initialize framework-specific adapter"""
        pass
    
    @abstractmethod
    async def adapt_request(self, 
                          request: Any) -> Dict[str, Any]:
        """Adapt framework request to integration format"""
        pass
    
    @abstractmethod
    async def adapt_response(self, 
                           response: Dict[str, Any]) -> Any:
        """Adapt integration response to framework format"""
        pass
    
    async def handle_request(self, request: Any) -> Any:
        """Handle framework request"""
        try:
            adapted_request = await self.adapt_request(request)
            result = await self.integration.query(adapted_request)
            return await self.adapt_response(result)
        except Exception as e:
            return await self.handle_error(e)
    
    @abstractmethod
    async def handle_error(self, error: Exception) -> Any:
        """Handle errors in framework-specific way"""
        pass
```

### 4. Validation and Conversion Utilities

Let's implement utilities for input validation and data conversion.

In `src/utils/validation.py`:
```python
from typing import Any, Dict, List, Optional
from dataclasses import dataclass
from enum import Enum

class ValidationLevel(Enum):
    STRICT = "strict"
    LENIENT = "lenient"
    CUSTOM = "custom"

@dataclass
class ValidationRule:
    """Rule for input validation"""
    field: str
    type: type
    required: bool = True
    validators: List[callable] = None
    default: Any = None

class InputValidator:
    """Validate integration inputs"""
    
    def __init__(self, 
                 level: ValidationLevel = ValidationLevel.STRICT,
                 custom_rules: Optional[List[ValidationRule]] = None):
        self.level = level
        self.rules = custom_rules or self._get_default_rules()
    
    def validate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate input data"""
        validated = {}
        
        for rule in self.rules:
            value = data.get(rule.field)
            
            if value is None:
                if rule.required:
                    if self.level == ValidationLevel.STRICT:
                        raise ValueError(f"Missing required field: {rule.field}")
                    value = rule.default
                else:
                    continue
            
            if not isinstance(value, rule.type):
                try:
                    value = rule.type(value)
                except (ValueError, TypeError):
                    raise ValueError(
                        f"Invalid type for {rule.field}. Expected {rule.type}"
                    )
            
            if rule.validators:
                for validator in rule.validators:
                    if not validator(value):
                        raise ValueError(
                            f"Validation failed for {rule.field}"
                        )
            
            validated[rule.field] = value
        
        return validated
```

## Hands-on Exercise

### Building a Framework Integration

Students will implement a complete framework integration that includes:

1. Creating a custom integration class
2. Implementing the observer pattern
3. Building framework-specific adapters
4. Adding validation rules
5. Creating conversion utilities

## Assessment Criteria

Students will be evaluated based on their ability to:

1. Implement proper integration patterns
2. Create reusable components
3. Handle framework-specific requirements
4. Implement proper error handling
5. Create comprehensive tests

Would you like me to proceed with creating the second artifact that covers specific framework implementations and advanced patterns?