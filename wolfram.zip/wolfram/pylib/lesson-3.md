# Lesson 3: Understanding the Base Engine

## Lesson Overview
This lesson delves into the core implementation of the Wolfram Alpha API engine. We'll explore the internals of the base engine implementation, focusing on query construction, URL formatting, response processing, and error handling. The lesson provides detailed implementations and best practices for creating a robust API client.

## Project Structure Focus
For this lesson, we'll primarily work with the following components:

```
wolfram_project/
├── src/
│   ├── engine/
│   │   ├── __init__.py
│   │   ├── base.py           # Base engine implementation
│   │   ├── query.py          # Query construction
│   │   ├── response.py       # Response processing
│   │   └── constants.py      # API constants
│   └── utils/
│       ├── url.py            # URL handling utilities
│       └── validators.py     # Input validation
```

## 1. Core Engine Implementation

The base engine serves as the foundation for all API interactions. Let's implement a robust and extensible base engine:

```python
# src/engine/base.py
from typing import Dict, Any, Optional
from urllib.parse import urljoin
import requests
from datetime import datetime
from ..utils.logger import LogManager
from ..utils.exceptions import WolframAPIError
from ..config.settings import Settings
from .constants import API_ENDPOINTS, DEFAULT_TIMEOUT

class WolframAlphaEngine:
    """
    Base engine for Wolfram Alpha API interactions.
    Handles core functionality including request management and response processing.
    """
    def __init__(
        self,
        app_id: str,
        settings: Optional[Settings] = None,
        logger: Optional[LogManager] = None
    ):
        self.app_id = app_id
        self.settings = settings or Settings.load_config()
        self.logger = logger or LogManager(self.settings.LOG_DIR)
        self.session = self._initialize_session()

    def _initialize_session(self) -> requests.Session:
        """Initialize and configure requests session"""
        session = requests.Session()
        session.headers.update({
            'User-Agent': f'WolframAlphaClient/Python/{self.settings.VERSION}',
            'Accept': 'application/json, application/xml',
        })
        return session

    def _build_url(self, endpoint: str) -> str:
        """Construct full API URL for given endpoint"""
        base_url = self.settings.API_BASE_URL
        return urljoin(base_url, endpoint)

    def _prepare_params(self, params: Dict[str, Any]) -> Dict[str, str]:
        """Prepare and validate request parameters"""
        prepared_params = {
            'appid': self.app_id,
            **{k: str(v) for k, v in params.items() if v is not None}
        }
        return prepared_params

    async def execute_request(
        self,
        endpoint: str,
        params: Dict[str, Any],
        timeout: Optional[int] = None
    ) -> requests.Response:
        """
        Execute API request with proper error handling and logging
        """
        url = self._build_url(endpoint)
        prepared_params = self._prepare_params(params)
        timeout = timeout or self.settings.API_TIMEOUT

        try:
            self.logger.get_app_logger().info(
                f"Executing request to {endpoint}",
                extra={
                    'params': prepared_params,
                    'timestamp': datetime.utcnow().isoformat()
                }
            )

            response = self.session.get(
                url,
                params=prepared_params,
                timeout=timeout
            )
            response.raise_for_status()
            return response

        except requests.exceptions.HTTPError as e:
            self.logger.get_error_logger().error(
                f"HTTP Error: {str(e)}",
                extra={'status_code': e.response.status_code}
            )
            raise WolframAPIError(f"HTTP Error: {str(e)}", str(e.response.status_code))

        except requests.exceptions.ConnectionError as e:
            self.logger.get_error_logger().error(f"Connection Error: {str(e)}")
            raise WolframAPIError("Failed to connect to API server")

        except requests.exceptions.Timeout as e:
            self.logger.get_error_logger().error(f"Timeout Error: {str(e)}")
            raise WolframAPIError("Request timed out")

        except Exception as e:
            self.logger.get_error_logger().error(
                f"Unexpected error: {str(e)}",
                exc_info=True
            )
            raise WolframAPIError(f"Unexpected error: {str(e)}")
```

## 2. Query Construction

Query construction is a critical component that ensures proper formatting and validation of API requests:

```python
# src/engine/query.py
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from urllib.parse import quote
from ..utils.validators import validate_query_input

@dataclass
class QueryOptions:
    """Configuration options for API queries"""
    format: str = "plaintext"
    units: Optional[str] = None
    timeout: Optional[int] = None
    scanner: Optional[str] = None
    width: Optional[int] = None
    maxwidth: Optional[int] = None
    plotwidth: Optional[int] = None
    mag: Optional[float] = None
    podtitle: Optional[List[str]] = None

class WolframAlphaQuery:
    """
    Handles construction and validation of Wolfram Alpha API queries
    """
    def __init__(
        self,
        input_query: str,
        options: Optional[QueryOptions] = None
    ):
        self.input_query = input_query
        self.options = options or QueryOptions()
        self._validate_input()

    def _validate_input(self):
        """Validate query input"""
        validate_query_input(self.input_query)

    def _encode_parameter(self, value: Any) -> str:
        """Encode parameter value for URL"""
        if isinstance(value, (list, tuple)):
            return ','.join(quote(str(item)) for item in value)
        return quote(str(value))

    def build_parameters(self) -> Dict[str, str]:
        """Build complete set of query parameters"""
        params = {'input': self.input_query}

        # Add optional parameters if they have values
        option_mapping = {
            'format': self.options.format,
            'units': self.options.units,
            'timeout': self.options.timeout,
            'scanner': self.options.scanner,
            'width': self.options.width,
            'maxwidth': self.options.maxwidth,
            'plotwidth': self.options.plotwidth,
            'mag': self.options.mag,
            'podtitle': self.options.podtitle,
        }

        for key, value in option_mapping.items():
            if value is not None:
                params[key] = self._encode_parameter(value)

        return params

    def to_url_parameters(self) -> str:
        """Convert query to URL parameter string"""
        params = self.build_parameters()
        return '&'.join(f"{k}={v}" for k, v in params.items())
```

## 3. Response Processing

Handling API responses requires careful parsing and error checking:

```python
# src/engine/response.py
from typing import Dict, Any, Optional, List
from xml.etree import ElementTree
import json
from dataclasses import dataclass

@dataclass
class PodContent:
    """Container for pod content data"""
    title: str
    plaintext: Optional[str]
    image_url: Optional[str]
    mathml: Optional[str]

@dataclass
class QueryResult:
    """Structured container for API response data"""
    success: bool
    error: Optional[str]
    pods: List[PodContent]
    timing: float
    datatypes: List[str]

class ResponseProcessor:
    """
    Handles parsing and processing of Wolfram Alpha API responses
    """
    def __init__(self, response_format: str = "default"):
        self.response_format = response_format

    def _parse_xml_response(self, content: str) -> QueryResult:
        """Parse XML response into structured format"""
        root = ElementTree.fromstring(content)
        
        # Check for success/error
        success = root.get('success') == 'true'
        error = root.find('error/msg').text if root.find('error/msg') is not None else None

        # Parse pods
        pods = []
        for pod in root.findall('pod'):
            pod_content = PodContent(
                title=pod.get('title', ''),
                plaintext=pod.find('subpod/plaintext').text if pod.find('subpod/plaintext') is not None else None,
                image_url=pod.find('subpod/img').get('src') if pod.find('subpod/img') is not None else None,
                mathml=pod.find('subpod/mathml').text if pod.find('subpod/mathml') is not None else None
            )
            pods.append(pod_content)

        # Parse additional metadata
        timing = float(root.get('timing', 0))
        datatypes = root.get('datatypes', '').split(',') if root.get('datatypes') else []

        return QueryResult(
            success=success,
            error=error,
            pods=pods,
            timing=timing,
            datatypes=datatypes
        )

    def _parse_json_response(self, content: str) -> QueryResult:
        """Parse JSON response into structured format"""
        data = json.loads(content)
        
        # Similar structure as XML parsing but for JSON format
        return QueryResult(
            success=data.get('success', False),
            error=data.get('error'),
            pods=[
                PodContent(
                    title=pod.get('title', ''),
                    plaintext=pod.get('subpods', [{}])[0].get('plaintext'),
                    image_url=pod.get('subpods', [{}])[0].get('img', {}).get('src'),
                    mathml=pod.get('subpods', [{}])[0].get('mathml')
                )
                for pod in data.get('pods', [])
            ],
            timing=float(data.get('timing', 0)),
            datatypes=data.get('datatypes', '').split(',') if data.get('datatypes') else []
        )

    def process_response(self, response_content: str, content_type: str) -> QueryResult:
        """Process API response based on content type"""
        if content_type == 'application/xml':
            return self._parse_xml_response(response_content)
        elif content_type == 'application/json':
            return self._parse_json_response(response_content)
        else:
            raise ValueError(f"Unsupported content type: {content_type}")
```

## 4. Constants and Configuration

Define API-specific constants and configurations:

```python
# src/engine/constants.py
from enum import Enum
from typing import Dict

class APIEndpoints(str, Enum):
    """API endpoint definitions"""
    QUERY = 'query'
    SIMPLE = 'simple'
    SHORT = 'short'
    SPOKEN = 'spoken'

class ResponseFormat(str, Enum):
    """Supported response formats"""
    PLAINTEXT = 'plaintext'
    IMAGE = 'image'
    MATHML = 'mathml'
    MINPUT = 'minput'
    MOUTPUT = 'moutput'

# API configuration constants
API_ENDPOINTS: Dict[str, str] = {
    'v2': 'http://api.wolframalpha.com/v2/',
    'v1': 'http://api.wolframalpha.com/v1/'
}

DEFAULT_TIMEOUT = 30
MAX_QUERY_LENGTH = 2048
SUPPORTED_FORMATS = ['plaintext', 'image', 'mathml', 'minput', 'moutput']
```

## 5. URL Handling Utilities

Create utilities for URL manipulation and validation:

```python
# src/utils/url.py
from typing import Dict, Any, Optional
from urllib.parse import urlencode, urlparse, parse_qs, ParseResult
from ..engine.constants import MAX_QUERY_LENGTH

class URLBuilder:
    """
    Utility class for building and manipulating API URLs
    """
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.parsed_url: Optional[ParseResult] = None
        self._parse_base_url()

    def _parse_base_url(self):
        """Parse and validate base URL"""
        self.parsed_url = urlparse(self.base_url)
        if not all([self.parsed_url.scheme, self.parsed_url.netloc]):
            raise ValueError("Invalid base URL format")

    def add_path(self, path: str) -> 'URLBuilder':
        """Add path segment to URL"""
        if self.parsed_url:
            current_path = self.parsed_url.path.rstrip('/')
            new_path = f"{current_path}/{path.lstrip('/')}"
            self.parsed_url = self.parsed_url._replace(path=new_path)
        return self

    def add_params(self, params: Dict[str, Any]) -> 'URLBuilder':
        """Add query parameters to URL"""
        if self.parsed_url:
            # Combine existing and new parameters
            existing_params = parse_qs(self.parsed_url.query)
            existing_params.update(params)
            
            # Create new query string
            query_string = urlencode(existing_params, doseq=True)
            
            # Validate query length
            if len(query_string) > MAX_QUERY_LENGTH:
                raise ValueError(f"Query length exceeds maximum of {MAX_QUERY_LENGTH} characters")
            
            self.parsed_url = self.parsed_url._replace(query=query_string)
        return self

    def build(self) -> str:
        """Build final URL string"""
        if not self.parsed_url:
            raise ValueError("URL has not been initialized")
        return self.parsed_url.geturl()
```

## Practical Exercises

1. Base Engine Implementation:
   - Create a complete working implementation of the base engine
   - Add proper error handling and logging
   - Implement request retry logic

2. Query Construction:
   - Build a query builder with parameter validation
   - Implement URL encoding and parameter formatting
   - Add support for different query types

3. Response Processing:
   - Create parsers for both XML and JSON responses
   - Implement error checking and validation
   - Add support for different response formats

4. Integration Testing:
   - Create comprehensive tests for the engine
   - Test different query types and responses
   - Verify error handling and logging

## Next Steps

In the next lesson, we'll explore XML processing and data structures in detail, focusing on handling complex response data from the Wolfram Alpha API. Students should practice with the current implementation and experiment with different query types and response formats.

## Additional Resources

1. Wolfram Alpha API Documentation
2. Python Requests Library Documentation
3. XML Processing in Python Guide
4. URL Handling Best Practices

Remember to refer to the official Wolfram Alpha API documentation for the most up-to-date information about endpoints and features.
