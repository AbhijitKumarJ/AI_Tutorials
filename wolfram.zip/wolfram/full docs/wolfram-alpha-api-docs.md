# Wolfram|Alpha Full Results API Documentation

## Overview

The Wolfram|Alpha Full Results API provides a web-based API that allows you to integrate Wolfram|Alpha's computational and presentation capabilities into web, mobile, desktop and enterprise applications. 

The API enables you to:
- Submit free-form queries similar to those on the Wolfram|Alpha website
- Receive results in various formats
- Access the majority of data available through the Wolfram|Alpha website

The API uses a standard REST protocol with HTTP GET requests. Results are returned as descriptive XML or JSON structures containing the requested content.

## Getting Started

### Prerequisites
1. Register a Wolfram ID and sign in at the Wolfram|Alpha Developer Portal
2. Obtain an AppID by clicking "Get an AppID" button
3. Create your application by providing:
   - Application name
   - Description  
   - Application type

### Making Your First Query

The base URL for all API queries is:
```
http://api.wolframalpha.com/v2/query
```

Every query requires two essential parameters:
1. `appid` - Your application ID
2. `input` - The URL-encoded query string

Example query for "population of France":
```
http://api.wolframalpha.com/v2/query?appid=DEMO&input=population%20of%20france
```

This returns an XML document containing informational elements (pods) related to the input. Here's a simplified example response:

```xml
<queryresult success="true" error="false" numpods="5" datatypes="Country">
  <pod title="Input interpretation" scanner="Identity" id="Input">...</pod>
  <pod title="Result" scanner="Data" id="Result" primary="true">
    <subpod>
      <plaintext>64.1 million people (world rank: 21st) (2014 estimate)</plaintext>
      <img src="..." alt="64.1 million people (world rank: 21st) (2014 estimate)" 
           width="313" height="18"/>
    </subpod>
  </pod>
  <!-- Additional pods... -->
</queryresult>
```

## Core Concepts

### Pods

Pods are the main output units in Wolfram|Alpha responses. Each pod contains a piece or category of information about the query. Key pod attributes include:

- `title` - Identifies the pod's contents
- `scanner` - Name of the computational system that produced the pod
- `id` - Unique identifier for selecting specific pods
- `position` - Intended display position (multiples of 100)
- `error` - Boolean indicating if an error occurred
- `numsubpods` - Number of subpod elements present

### Subpods

Subpods are containers for actual result content within pods. Each subpod can contain:

- `plaintext` - Text representation of the result
- `img` - Image representation with associated metadata
- `mathml` - Mathematical notation in MathML format
- Additional format-specific elements

### Output Formats

The API supports multiple output formats controlled by the `format` parameter:

- `plaintext` - Basic text representation
- `image` - GIF/JPEG visual representation 
- `mathml` - Mathematical expressions in MathML
- `sound` - Audio output (MIDI/WAV)
- `minput` - Wolfram Language input form
- `moutput` - Wolfram Language output form
- `cell` - Full Wolfram Language cell expression

Example specifying multiple formats:
```
&format=plaintext,image,mathml
```

### Result Types

The API can return results in two formats specified by the `output` parameter:

- `xml` (default) - Results in XML format
- `json` - Results in JSON format

## Query Parameters

### Basic Parameters

| Parameter | Description | Example Values | Default |
|-----------|-------------|----------------|---------|
| `input` | URL-encoded query text | "5+largest+countries" | Required |
| `appid` | Your application ID | "X7WEHY-W45KYJL3C9" | Required |
| `format` | Desired pod format | "image,plaintext" | "plaintext,image" |
| `output` | Overall result format | "xml", "json" | "xml" |

### Pod Selection Parameters

| Parameter | Description | Example Values |
|-----------|-------------|----------------|
| `includepodid` | Pods to include | "Result", "BasicInformation" |
| `excludepodid` | Pods to exclude | "DecimalApproximation" |
| `podtitle` | Pods to include by title | "Basic+Information" |
| `podindex` | Pods to include by index | "1,2,4" |
| `scanner` | Include pods from specific scanners | "Numeric", "Data" |

### Location Parameters

| Parameter | Description | Example Values |
|-----------|-------------|----------------|
| `ip` | Location by IP address | "192.168.1.1" |
| `latlong` | Location by coordinates | "40.42,-3.71" |
| `location` | Location by string | "Boston, MA" |

### Size Control Parameters

| Parameter | Description | Example Values | Default |
|-----------|-------------|----------------|---------|
| `width` | Text/table width limit | "200", "500" | 500 pixels |
| `maxwidth` | Maximum width for large objects | "200", "500" | 500 pixels |
| `plotwidth` | Plot/graphic width limit | "100", "200" | 200 pixels |
| `mag` | Content magnification | "0.5", "2.0" | 1.0 |

### Timeout Parameters

| Parameter | Description | Default (seconds) |
|-----------|-------------|-------------------|
| `scantimeout` | Scan stage timeout | 3.0 |
| `podtimeout` | Individual pod format timeout | 4.0 |
| `formattimeout` | Overall format stage timeout | 8.0 |
| `parsetimeout` | Parse stage timeout | 5.0 |
| `totaltimeout` | Total query timeout | 20.0 |

### Additional Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `reinterpret` | Allow query reinterpretation | false |
| `translation` | Allow translation to English | false |
| `ignorecase` | Ignore case in queries | false |
| `async` | Enable asynchronous results | false |
| `units` | Preferred measurement system | Based on location |

## Assumptions and Interpretations

### Understanding Assumptions

Wolfram|Alpha makes assumptions when analyzing queries to resolve ambiguities. For example:

- Word meanings (e.g., "pi" as math constant vs movie)
- Unit interpretations (e.g., "m" as meters vs minutes)
- Date formats (e.g., "12/5/1999" format)
- Mathematical interpretations

Assumptions appear in the XML response as:

```xml
<assumptions count="1">
  <assumption type="Clash" word="pi" template="Assuming ${word} is ${desc1}. Use as ${desc2} instead">
    <value name="NamedConstant" desc="a mathematical constant" input="*C.pi-_*NamedConstant-"/>
    <value name="Movie" desc="a movie" input="*C.pi-_*Movie-"/>
  </assumption>
</assumptions>
```

### Types of Assumptions

1. Categorical Assumptions:
   - `Clash` - Different interpretation categories
   - `SubCategory` - Similar results within a category
   - `Attribute` - Specific traits of results

2. Mathematical Assumptions:
   - `Unit` - Unit of measure interpretations
   - `AngleUnit` - Degree vs radian interpretations
   - `Function` - Mathematical function interpretations
   - `ListOrTimes` - List vs multiplication interpretation

3. Date/Time Assumptions:
   - `TimeAMOrPM` - AM/PM time interpretations
   - `DateOrder` - Date format interpretations

### Using Assumptions

To apply an assumption, use the `assumption` parameter with the input value from the assumption's XML:

```
&assumption=*C.pi-_*Movie-
```

Multiple assumptions can be combined in one query.

## Working with Results

### Success and Error Handling

The `queryresult` element contains key status attributes:

- `success` - Query was understood
- `error` - Processing error occurred
- `numpods` - Number of result pods
- `timing` - Processing time
- `timedout` - Timed-out components

### Error Types

Errors are indicated by `error="true"` and include:

```xml
<error>
  <code>2</code>
  <msg>Appid missing</msg>
</error>
```

Common error scenarios:
- Missing/invalid parameters
- Invalid AppID
- Internal processing errors

### Asynchronous Processing

Enable async processing with `async=true` to:
- Receive partial results quickly
- Get URLs for pending pods
- Control async timing thresholds

Example async pod:

```xml
<pod title="Weather history" async="http://api.wolframalpha.com/.../asyncPod.jsp?id=..."/>
```

### Recalculation

Use the `recalculate` URL provided in responses to:
- Retry timed-out calculations
- Get additional pods
- Extend processing time

## Best Practices

1. Error Handling
   - Always check success/error status
   - Handle timeouts gracefully
   - Provide user feedback for errors

2. Performance Optimization
   - Use pod selection parameters to limit results
   - Enable async processing for complex queries
   - Set appropriate timeout values

3. Result Processing
   - Parse results based on format type
   - Handle missing or null values
   - Validate assumption applications

4. User Experience
   - Provide feedback during async operations
   - Handle ambiguous queries with assumptions
   - Maintain query context

## Security Considerations

1. AppID Protection
   - Keep AppID confidential
   - Use signature parameter for sensitive applications
   - Monitor usage patterns

2. Error Exposure
   - Filter sensitive error messages
   - Validate all input parameters
   - Handle timeouts securely

## Further Resources

- [API Documentation](https://docs.wolframalpha.com/)
- [Developer Portal](https://developer.wolframalpha.com/)
- [Support Center](https://support.wolframalpha.com/)
