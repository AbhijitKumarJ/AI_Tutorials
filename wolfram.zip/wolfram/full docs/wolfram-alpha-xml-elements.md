# List of XML Result Elements

This section details the hierarchy and structure of XML results from the Full Results API. Note that some elements (e.g., `<states>`) can appear in multiple places, and not all elements will be returned in one result.

## Element Hierarchy

```xml
<queryresult>
  <languagemsg>
  <tips>
    <tip>
  <futuretopic>
  <pod>
    <subpod>
      <img>
      <imagemap>
        <rect>
      <plaintext>
      <mathml>
        <math>
      <sound>
      <minput>
      <moutput>
      <cell>
        <![CDATA[...]]>
      <states>
        <state>
      <info>
      <infos>
        <info>
  <error>
  <assumptions>
    <assumption>
  <examplepage>
  <warnings>
  <spellcheck>
  <delimiters>
  <translation>
  <reinterpret>
  <sources>
    <source>
  <generalization>
  <didyoumeans>
    <didyoumean>
```

## Main Elements Description

### `<queryresult>`

The root element containing the entire API result. Key attributes include:

- `success` - true/false depending on input understanding
- `error` - true/false for serious processing errors
- `numpods` - Number of pods in result
- `version` - API version specification
- `datatypes` - Categories of data represented
- `timing` - Wall-clock time for output generation
- `timedout` - Missing pods due to timeout
- `parsetiming` - Parsing phase time
- `parsedtimeout` - Whether parsing stage timed out
- `recalculate` - URL for query recalculation

Example:
```xml
<queryresult success="true" error="false" numpods="5" version="2.6" 
             datatypes="Country" timing="6.272" parsetiming="0.27">
```

### `<pod>`

Main output container. Attributes include:

- `title` - Pod identification and contents
- `error` - Processing error indicator
- `position` - Display position number
- `scanner` - Name of producing scanner
- `id` - Unique pod identifier
- `numsubpods` - Number of subpod elements

Example:
```xml
<pod title="Result" scanner="Data" id="Result" position="200" 
     error="false" numsubpods="1" primary="true">
```

### `<subpod>`

Contains results for a single subpod. Has a `title` attribute, usually empty for single subpods.

Example:
```xml
<subpod title="">
  <plaintext>64.1 million people</plaintext>
  <img src="..." alt="64.1 million people" width="313" height="18"/>
</subpod>
```

### `<img>`

HTML image elements for visual representation. Attributes:

- `src` - Image URL
- `alt` - Alternative text
- `title` - Descriptive title
- `width` - Image width in pixels
- `height` - Image height in pixels

### `<imagemap>`

HTML image maps for clickable visual elements. Contains `<rect>` subelements specifying clickable areas.

Example:
```xml
<imagemap>
  <rect left="12" top="8" right="39" bottom="28" 
        query="France+full+name" title="France full name"/>
</imagemap>
```

### `<plaintext>`

Text representation of a subpod. Contains no attributes or subelements.

Example:
```xml
<plaintext>64.1 million people (world rank: 21st)</plaintext>
```

### `<mathml>`

MathML representation of mathematical content. Opens with `<math>` and includes formatting subelements.

Example:
```xml
<mathml>
  <math xmlns="http://www.w3.org/1998/Math/MathML">
    <mrow>
      <mi>a</mi>
      <mo>+</mo>
      <mi>b</mi>
    </mrow>
  </math>
</mathml>
```

### `<sound>`

HTML sound elements for audio representation. Includes:
- URL to stored sound file
- MIME type (MIDI or WAV)

### `<minput>`

Wolfram Language input for result reproduction.

### `<moutput>`

Wolfram Language output representation.

### `<cell>`

Wolfram Language Cell expression wrapped in `<![CDATA[...]]>`.

### `<assumptions>`

Contains series of `<assumption>` elements defining query interpretations.

Example:
```xml
<assumptions count="1">
  <assumption type="Clash" word="pi" count="2">
    <value name="NamedConstant" desc="mathematical constant"/>
    <value name="Movie" desc="movie"/>
  </assumption>
</assumptions>
```

### `<assumption>`

Defines single assumption with attributes:
- `type` - Assumption classification
- `word` - Applied word/phrase
- `template` - Application statement
- `count` - Number of possible values

### `<states>`

Contains `<state>` or `<statelist>` elements for pod modifications.

### `<state>`

Pod state definition with:
- `name` attribute describing state
- `input` attribute for query modification

### `<warnings>`

Contains various warning types with respective subelements.

### `<spellcheck>`

Spelling reinterpretation warning with attributes:
- `word` - Original query word
- `suggestion` - Suggested spelling
- `text` - User message

### `<delimiters>`

Warning about mismatched brackets/parentheses.

### `<translation>`

Translation warning with attributes:
- `phrase` - Original phrase
- `trans` - Translated phrase
- `lang` - Source language
- `text` - User message

### `<reinterpret>`

Query reinterpretation warning with alternatives.

### `<error>`

Error information with:
- `code` - Error code number
- `msg` - Error description

### `<sources>`

Contains `<source>` elements defining reference links.

### `<infos>`

Contains `<info>` elements with pod information.

### `<languagemsg>`

Appears for unsupported language input.

### `<generalization>`

Indicates broader query availability.

### `<tips>`

Contains `<tip>` elements with query improvement suggestions.

### `<didyoumeans>`

Contains `<didyoumean>` elements suggesting alternative queries.

### `<futuretopic>`

Indicates topic under development.

### `<examplepage>`

Links to prepared example queries.