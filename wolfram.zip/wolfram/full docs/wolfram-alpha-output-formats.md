# Formatting Output

## The Output Parameter

By default, the Full Results API returns an XML document. You can modify this using the output parameter.

### JSON Output
Use `output=json`:
```
http://api.wolframalpha.com/v2/query?appid=DEMO&input=tides%20seattle&output=json
```

Example JSON response (Result pod):
```json
{
  "title": "Result",
  "scanner": "Tide",
  "id": "Result",
  "position": 200,
  "error": false,
  "numsubpods": 1,
  "primary": true,
  "subpods": [
    { ... }
  ]
}
```

## The Format Parameter

### Image Format
Returns GIF/JPEG images ready for webpage inclusion:
```
http://api.wolframalpha.com/v2/query?appid=DEMO&input=tides%20seattle&&format=image
```

Example response:
```xml
<pod title="Result" scanner="Tide" id="Result" position="200" error="false" numsubpods="1" primary="true">
  <subpod title="">
    <img src="http://www1.wolframalpha.com/Calculate/MSP/MSP2251baf4ff97adai0b200001b128d6ace53249f?
         MSPStoreType=image/gif&s=14"
         alt="Tuesday, November 3, 2015 | | | | low tide..."
         width="400" height="366"/>
  </subpod>
  <states count="5">...</states>
  <infos count="1">...</infos>
</pod>
```

### Imagemap Format
Provides HTML image maps for clickable areas:

Example pod with image map:
```xml
<pod title='Name' scanner='Data' id='Identifiers:CountryData'>
  <subpod title=''>
    <img src='http://www1.wolframalpha.com/Calculate/MSP/MSP93ff?MSStoreType=image/gif'
         alt='full name | French Republic'
         width='294' height='106' />
    <imagemap>
      <rect left='12' top='8' right='39' bottom='28'
            query='France+full+name'
            assumptions='ClashPrefs_*Country.France.CountryProperty.FullName-'
            title='France full name' />
      <!-- Additional clickable areas -->
    </imagemap>
  </subpod>
</pod>
```

### Plaintext Format
Provides text-only output:
```xml
<pod title="Result" scanner="Tide" id="Result">
  <subpod title="">
    <plaintext>
      Tuesday, November 3, 2015 | | | |
      low tide | 3:27 am PST (9 h 58 min ago) | +1.1 feet
      high tide | 11:02 am PST (2 h 23 min ago) | +11.2 feet
    </plaintext>
  </subpod>
</pod>
```

### MathML Format
For mathematical expressions:
```xml
<pod title="Statement" scanner="Data" id="StatementPod:FamousMathProblem">
  <subpod title="">
    <mathml>
      <math xmlns="http://www.w3.org/1998/Math/MathML">
        <mrow>
          <mtext>For a right triangle with legs</mtext>
          <mi>a</mi>
          <mtext>and</mtext>
          <mi>b</mi>
          <mtext>and hypotenuse</mtext>
          <mi>c</mi>
          <mrow>
            <msup>
              <mi>a</mi>
              <mn>2</mn>
            </msup>
            <mo>+</mo>
            <msup>
              <mi>b</mi>
              <mn>2</mn>
            </msup>
            <mo>=</mo>
            <msup>
              <mi>c</mi>
              <mn>2</mn>
            </msup>
          </mrow>
        </mrow>
      </math>
    </mathml>
  </subpod>
</pod>
```

### Sound Format
Returns audio data in MIDI or WAV format:
```xml
<pod title="Music notation" scanner="Music" id="MusicNotation">
  <sounds count="1">
    <sound url="http://www1.wolframalpha.com/Calculate/MSP/MSP3831c605804acbi0aeb000016c4402g20b8c038?
           MSPStoreType=audio/midi&s=13" 
           type="audio/midi"/>
  </sounds>
</pod>
```

### WAV Format
Specifically requests uncompressed WAV audio:
```xml
<pod title="Music notation" scanner="Music" id="MusicNotation">
  <sounds count="1">
    <sound url="http://www1.wolframalpha.com/Calculate/MSP/MSP731g35g30d3e5h09e600005bhcec0af7cf0g5e?
           MSPStoreType=audio/x-wav&s=12" 
           type="audio/x-wav"/>
  </sounds>
</pod>
```

### Wolfram Language Input
Returns Wolfram Language input expressions:
```xml
<pod title="Continued fraction" scanner="ContinuedFraction" id="ContinuedFraction">
  <subpod title="">
    <minput>ContinuedFraction[Pi, 27]</minput>
  </subpod>
</pod>
```

### Wolfram Language Output
Returns Wolfram Language output format:
```xml
<pod title="Continued fraction" scanner="ContinuedFraction" id="ContinuedFraction">
  <subpod title="">
    <moutput>
      {3, 7, 15, 1, 292, 1, 1, 1, 2, 1, 3, 1, 14, 2, 1, 1, 2, 2, 2, 2, 1, 84, 2, 1, 1, 15, 3}
    </moutput>
  </subpod>
</pod>
```

### Cell Format
Returns complete Wolfram Language Cell expressions:
```xml
<pod title="Continued fraction" scanner="ContinuedFraction" id="ContinuedFraction">
  <subpod title="">
    <cell compressed="false">
      <![CDATA[
        Cell[BoxData[FormBox[TagBox[GridBox[List[List[TemplateBox[List["\\"[\\"", "\\",
        3; 7, 15, 1, 292, 1, 1, 1, 2, 1, 3, 1, 14, 2, 1, 1, 2, 2, 2, 2, 1, 84, 2, 1, 1, 15,\\"", 
        "\\" \\[Ellipsis]]\\""], "RowDefault"]]]], ...]]
      ]]>
    </cell>
  </subpod>
</pod>
```

## Controlling Result Width

### Width Parameter
Controls text and table width:
```
&width=250
```

### Max Width Parameter
Sets maximum width while allowing content-based adjustments:
```
&width=100&maxwidth=200
```

### Plot Width Parameter
Controls width of plots and graphics:
```
&plotwidth=300
```

### Magnification Parameter
Controls content scaling without changing dimensions:
```
&mag=2.0
```

### Best Practices for Output Control

1. Choose appropriate formats based on content type
2. Use width parameters to optimize for display context
3. Consider combining formats for rich content
4. Handle format-specific error cases
5. Validate output before display
6. Cache image and sound resources when appropriate
7. Consider bandwidth implications of format choices