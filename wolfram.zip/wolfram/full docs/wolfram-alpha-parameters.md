# Parameter Reference

## Basic Parameters

| Parameter Name | Function | Sample Values | Default Values | Notes |
|---------------|----------|---------------|----------------|--------|
| input | URL-encoded text specifying the input string | "5+largest+countries", "Doppler%20shi", "pascal%27s%20triangle" | N/A (Queries without an input value will fail) | Required parameter |
| appid | An ID provided by Wolfram Research that identifies the application or organization making the request | X7WEHY-W45KYJL3C9 | N/A (Queries without an AppID will fail) | Required parameter |
| format | The desired format for individual result pods | "image", "imagemap", "plaintext", "minput", "moutput", "cell", "mathml", "sound", "wav" | Return basic text and image formats ("plaintext,image") | For multiple formats, separate values with a comma |
| output | The desired format for full results | "xml", "json" | Return an XML document | All possible values are listed in output formats section |

## Pod Selection

| Parameter Name | Function | Sample Values | Default Values | Notes |
|---------------|----------|---------------|----------------|--------|
| includepodid | Specifies a pod ID to include in the result | "Result", "BasicInformation:PeopleData", "DecimalApproximation" | All pods included | To specify multiple elements, use multiple instances of the parameter |
| excludepodid | Specifies a pod ID to exclude from the result | "Result", "BasicInformation:PeopleData", "DecimalApproximation" | No pods excluded | To specify multiple elements, use multiple instances of the parameter |
| podtitle | Specifies a pod title to include in the result | "Basic+Information", "Image", "Alternative%20representations" | All pods returned | Use * as a wildcard to match zero or more characters in pod titles |
| podindex | Specifies the index(es) of the pod(s) to return | "1", "7", "5,12,13" | All pods returned | To specify multiple elements, separate values with a comma |
| scanner | Specifies that only pods produced by the given scanner should be returned | "Numeric", "Data", "Traveling" | Pods from all scanners returned | To specify multiple elements, use multiple instances of the parameter |

## Location

| Parameter Name | Function | Sample Values | Default Values | Notes |
|---------------|----------|---------------|----------------|--------|
| ip | Specifies a custom query location based on an IP address | "192.168.1.1", "127.0.0.1" | Use caller's IP address for location | Only one location parameter may be used at a time. IPv4 and IPv6 addresses are supported |
| latlong | Specifies a custom query location based on a latitude/longitude pair | "40.42,-3.71", "40.11,-88.24", "0,0" | Use caller's IP address for location | Only one location parameter may be used at a time |
| location | Specifies a custom query location based on a string | "Boston, MA", "The North Pole", "Beijing" | Use caller's IP address for location | Only one location parameter may be used at a time |

## Size

| Parameter Name | Function | Sample Values | Default Values | Notes |
|---------------|----------|---------------|----------------|--------|
| width | Specify an approximate width limit for text and tables | "200", "500" | Width set at 500 pixels | This parameter does not affect plots or graphics |
| maxwidth | Specify an extended maximum width for large objects | "200", "500" | Width set at 500 pixels | This parameter does not affect plots or graphics |
| plotwidth | Specify an approximate width limit for plots and graphics | "100", "200" | Plot width set at 200 pixels | This parameter does not affect text or tables |
| mag | Specify magnification of objects within a pod | "0.5", "1.0", "2.0" | Magnification factor of 1.0 | Changing this parameter does not affect the overall size of pods |

## Timeouts/Async

| Parameter Name | Function | Sample Values | Default Values | Notes |
|---------------|----------|---------------|----------------|--------|
| scantimeout | The number of seconds to allow Wolfram|Alpha to compute results in the "scan" stage of processing | "0.5", "5.0" | Scan stage times out after 3.0 seconds | This parameter effectively limits the number and breadth of subtopics |
| podtimeout | The number of seconds to allow Wolfram|Alpha to spend in the "format" stage for any one pod | "0.5", "5.0" | Individual pods time out after 4.0 seconds | Use to prevent a single pod from dominating processing time |
| formattimeout | The number of seconds to allow Wolfram|Alpha to spend in the "format" stage for the entire collection of pods | "0.5", "5.0" | Format stage times out after 8.0 seconds | Balance between returning a few large results and numerous quick results |
| parsetimeout | The number of seconds to allow Wolfram|Alpha to spend in the "parsing" stage of processing | "0.5", "5.0" | Parsing stage times out after 5.0 seconds | Very few queries will exceed the default |
| totaltimeout | The total number of seconds to allow Wolfram|Alpha to spend on a query | "0.5", "5.0" | Queries time out after 20.0 seconds | Combine with other timeout parameters to define a last-resort time limit |
| async | Toggles asynchronous mode to allow partial results to return before all the pods are computed | "true", "false", "3.0" | Asynchronous mode disabled ("false") | Specifying a number sets the time limit (in seconds) for returning partial results |

## Miscellaneous

| Parameter Name | Function | Sample Values | Default Values | Notes |
|---------------|----------|---------------|----------------|--------|
| reinterpret | Whether to allow Wolfram|Alpha to reinterpret queries that would otherwise not be understood | "true", "false" | Do not reinterpret queries ("false") | Forces the API to decide among didyoumeans and similar XML results |
| translation | Whether to allow Wolfram|Alpha to try to translate simple queries into English | "true", "false" | Do not attempt translation ("false") | Translation attempts are displayed as warnings in XML results |
| ignorecase | Whether to force Wolfram|Alpha to ignore case in queries | "true", "false" | Do not ignore case ("false") | Useful for differentiating abbreviations, acronyms and titles |
| sig | A special signature that can be applied to guard against misuse of your AppID | N/A | No signature applied | For access to this feature, contact Wolfram Research |
| assumption | Specifies an assumption, such as the meaning of a word or the value of a formula variable | "*C.pi-_*Movie", "DateOrder_**Day.Month.Year--" | Assumptions made implicitly by the API | Values given by input properties of value subelements |
| podstate | Specifies a pod state change, which replaces a pod with a modified version | "WeatherCharts:WeatherData__Past+5+years" | Pod states generated implicitly | Specify consecutive state changes with the @ symbol |
| units | Lets you specify the preferred measurement system | "metric", "nonmetric" | Chosen based on caller's IP address | Using location parameters will affect the units displayed |