# Wolfram|Alpha APIs Overview Documentation
## Wolfram|Alpha Full Results API Reference

### Overview

The Wolfram|Alpha Full Results API provides a web-based API allowing the computational and presentation capabilities of Wolfram|Alpha to be integrated into web, mobile, desktop and enterprise applications.

The API allows clients to submit free-form queries similar to the queries one might enter at the Wolfram|Alpha website, and for the computed results to be returned in a variety of formats. It is implemented in a standard REST protocol using HTTP GET requests. Each result is returned as a descriptive XML or JSON structure wrapping the requested content format.

Although the majority of data available through the Wolfram|Alpha website is also available through this API, certain subjects may be restricted by default. To request access to additional topics, contact Wolfram Research.

### Getting Started

To start using the Full Results API, follow these basic steps:

#### 1. Signup and Login
Register a Wolfram ID and sign in at the Wolfram|Alpha Developer Portal.

#### 2. Obtaining an AppID
Click the "Get an AppID" button to start the app creation process. You'll need to provide:
- Application name
- Simple description 
- App type selection

#### 3. Sample Query
With your AppID, you can make your first query. The base URL for queries is:
```
http://api.wolframalpha.com/v2/query
```

Every query requires two pieces of information:
1. An AppID 
2. An input value

Example query structure:
```
http://api.wolframalpha.com/v2/query?appid=DEMO
```

To add a query for "population of France":
```
http://api.wolframalpha.com/v2/query?appid=DEMO&input=population%20of%20france
```

### Sample Response
Here's an example XML output for the "population of France" query (abbreviated):

```xml
<queryresult success="true" error="false" numpods="5" datatypes="Country"
timedout="Data,Percent,Unit,AtmosphericProperties,UnitInformation,Music,Geometry" timedoutpods=""
timing="6.272" parsetiming="0.27" parsetimedout="false" version="2.6">
  <pod title="Input interpretation" scanner="Identity" id="Input" position="100" error="false"
  numsubpods="1">...</pod>
  <pod title="Result" scanner="Data" id="Result" position="200" error="false" numsubpods="1"
  primary="true">
    <subpod title="">
      <plaintext>
      64.1 million people (world rank: 21st) (2014 estimate)
      </plaintext>
      <img src="http://www1.wolframalpha.com/Calculate/MSP/MSP291g37h8915724h4b800004ec2h0de24da9sbp?
      MSPStoreType=image/gif&s=12" alt="64.1 million people (world rank: 21st) (2014 estimate)" 
      title="64.1 million people (world rank: 21st) (2014 estimate)" width="313" height="18"/>
    </subpod>
  </pod>
  <pod title="Recent population history" scanner="Data" id="RecentHistory:Population:CountryData" 
  position="300" error="false" numsubpods="1">...</pod>
  <pod title="Long-term population history" scanner="Data" id="LongTermHistory:Population:CountryData"
  position="400" error="false" numsubpods="1">...</pod>
  <pod title="Demographics" scanner="Data" id="DemographicProperties:CountryData" position="500"
  error="false" numsubpods="1">...</pod>
  <warnings count="1">...</warnings>
  <sources count="1">...</sources>
</queryresult>

### Formatting Input
All URLs used to make queries must be URL encoded:
- Spaces represented as "%20"
- Backslashes represented as "%5c"

For mathematical queries, Wolfram|Alpha accepts input formatted using:
- Presentation LaTeX
- MathML

### Adding Parameters
You can add URL-encoded parameters to customize output. For example, to get only the "Result" pod:

```
http://api.wolframalpha.com/v2/query?appid=DEMO&input=population%20france&includepodid=Result
```

The response will contain only pods with that exact ID:

```xml
<queryresult success="true" error="false" numpods="1" datatypes="" timedout="" timedoutpods=""
timing="0.895" parsetiming="0.277" parsetimedout="false" recalculate=""
id="MSPa201c626hgh07fd2ee900003c1966c16708edi1" host="http://www1.wolframalpha.com" server="13">
  <pod title="Result" scanner="Data" id="Result" position="100" error="false" numsubpods="1"
  primary="true">
    <subpod title="">
      <plaintext>
      64.1 million people (world rank: 21st) (2014 estimate)
      </plaintext>
      <img src="http://www1.wolframalpha.com/Calculate/MSP/MSP221c626hgh07fd2ee900004eagdagf39fchhhg?
      MSPStoreType=image/gif&s=13"
      alt="64.1 million people (world rank: 21st) (2014 estimate)"
      title="64.1 million people (world rank: 21st) (2014 estimate)"
      width="313" height="18"/>
    </subpod>
  </pod>
  <sources count="1">...</sources>
</queryresult>
```

You can select which output type you prefer using the format parameter:

```
http://api.wolframalpha.com/v2/query?appid=DEMO&input=population%20france&includepodid=Result&format=plaintext
```

By using parameters in your queries, you can reduce the output to just the pieces you need.