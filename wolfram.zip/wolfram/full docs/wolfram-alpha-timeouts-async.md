# Timeouts and Asynchronous Behavior

## Understanding Processing Stages

Wolfram|Alpha computation occurs in three main stages:

1. Parse Stage
   - Interprets input into processable form
   - Controlled by `parsetimeout` parameter
   - Default: 5 seconds

2. Scan Stage
   - Hands off to subject-specific scanners
   - Produces pod data structures
   - Controlled by `scantimeout` parameter
   - Default: 3 seconds

3. Format Stage
   - Processes and renders pod expressions
   - Controlled by `podtimeout` and `formattimeout` parameters
   - Defaults: 4 seconds per pod, 8 seconds total

## Timeout Parameters

### Parse Timeout
```
&parsetimeout=5.0
```

Example timeout response:
```xml
<queryresult success="false" error="false" parsetimedout="true">
```

### Scan Timeout
```
&scantimeout=8.0
```

Example with timed-out scanners:
```xml
<queryresult success="true" error="false" timedout="PowerTower,Numeric,List,Factorial">
```

### Pod Timeout
```
&podtimeout=0.3
```

Example showing missed pods:
```xml
<queryresult success="true" error="false" timedoutpods="Latest recorded weather for Champaign%2C Illinois,Weather history & forecast">
```

### Format Timeout
```
&formattimeout=2.0
```

### Total Timeout
```
&totaltimeout=20.0
```

## Asynchronous Operation

Enable async processing with:
```
&async=true
```

### Async Response Structure
```xml
<queryresult success="true" error="false" numpods="7">
  <pod title="Input interpretation">...</pod>
  <pod title="Latest recorded weather" scanner="Data">...</pod>
  <pod title="Weather history & forecast" 
       async="http://www1.wolframalpha.com/api/v2/asyncPod.jsp?id=MSPa1061c679e3ea1d0h94h00005cfi845a23f3if9a"/>
</queryresult>
```

### Async Pod Retrieval
Fetching async pod content:
```xml
<pod title="Historical temperatures for December 1" scanner="Data">
  <subpod title="">
    <plaintext>
      low: 8 °F Dec 2002 | average high: 43 °F 
      average low: 28 °F | high: 63 °F Dec 2012
    </plaintext>
    <img src="..." />
  </subpod>
  <states count="2">...</states>
</pod>
```

### Async Timing Control
Set specific async timeout:
```
&async=0.2
```

## Recalculation

### Initial Short Timeout Query
```
http://api.wolframalpha.com/v2/query?appid=DEMO&input=pi&scantimeout=1.0
```

Response with recalculate URL:
```xml
<queryresult success="true" error="false" numpods="6" 
  timedout="Numeric,MathematicalFunctionData,Recognize"
  recalculate="http://www1.wolframalpha.com/api/v2/recalc.jsp?id=MSPa741bb3843hh8i9h3ad00001fh9feb817ad9e83">
```

### Recalculation Response
```xml
<queryresult success="true" error="false" numpods="2">
  <pod title="Series representations" scanner="MathematicalFunctionData" position="700">...</pod>
  <pod title="Integral representations" scanner="MathematicalFunctionData" position="800">...</pod>
</queryresult>
```

## Best Practices

### Timeout Management
1. Set appropriate timeouts based on query complexity
2. Use `scantimeout` to limit topic breadth
3. Use `podtimeout` to prevent single pod dominance
4. Balance `formattimeout` against result completeness
5. Use `totaltimeout` as last resort limit

### Async Implementation
1. Display initial results immediately
2. Load async pods in background
3. Show loading indicators for pending pods
4. Handle async failures gracefully
5. Consider connection stability

### Recalculation Strategy
1. Start with short timeouts
2. Use recalculate for additional content
3. Maintain result consistency
4. Handle position attributes correctly
5. Update interface incrementally

### Error Handling
1. Check timeout attributes
2. Monitor timed-out scanners
3. Track missing pods
4. Implement retry logic
5. Provide user feedback

### Performance Optimization
1. Use appropriate timeout values
2. Implement progressive loading
3. Cache results when possible
4. Balance completeness vs. speed
5. Monitor resource usage