# Using Assumptions and Pod States

## Assumptions Overview

Wolfram|Alpha makes numerous assumptions when analyzing queries to resolve ambiguities. Examples include:

- Word meanings (e.g., "pi" as mathematical constant vs. movie)
- Unit abbreviations (e.g., "m" as meters or minutes)
- Date formats (e.g., 12/13/2001 interpretation)
- Formula variables

### Structure of Assumptions

Assumptions appear in the XML response as `<assumptions>` elements. Example for "pi":

```xml
<assumptions count="1">
  <assumption type="Clash" word="pi" template="Assuming ${word} is ${desc1}. Use as ${desc2} instead" count="6">
    <value name="NamedConstant" desc="a mathematical constant" input="*C.pi-_*NamedConstant-"/>
    <value name="Character" desc="a character" input="*C.pi-_*Character-"/>
    <value name="Movie" desc="a movie" input="*C.pi-_*Movie-"/>
  </assumption>
</assumptions>
```

Each `<value>` element has:
- `name`: Internal identifier
- `desc`: User-friendly description
- `input`: Parameter value for assumption application

## Types of Assumptions

### 1. Categorical Assumptions

#### Clash
Generated when a word can represent different categories.
Example ("pi" query):
```xml
<assumption type="Clash" word="pi">
  <value name="NamedConstant" desc="a mathematical constant"/>
  <value name="Movie" desc="a movie"/>
</assumption>
```

#### MultiClash
For multiple overlapping string interpretations.
Example ("delta sigma" query):
```xml
<assumption type="MultiClash" word="">
  <value name="Financial" word="delta" desc="a financial entity"/>
  <value name="Variable" word="delta" desc="a variable"/>
</assumption>
```

#### SubCategory
For subcategories within same overall category.
Example ("hamburger" query):
```xml
<assumption type="SubCategory" word="hamburger">
  <value name="Hamburger" desc="hamburger"/>
  <value name="GroundBeefPatty" desc="ground beef patty"/>
</assumption>
```

#### Attribute
For modifying specific attributes of an entity.
Example (hamburger attributes):
```xml
<assumption type="Attribute" word="Hamburger">
  <value name="{Food:FoodSize -> Food:LargePatty}"/>
</assumption>
```

### 2. Mathematical Assumptions

#### Unit
For ambiguous unit abbreviations.
Example ("10 m" query):
```xml
<assumption type="Unit" word="m">
  <value name="Meters" desc="meters"/>
  <value name="Minutes" desc="minutes of time"/>
</assumption>
```

#### AngleUnit
For degree/radian ambiguity.
Example ("sin(30)" query):
```xml
<assumption type="AngleUnit">
  <value name="D" desc="degrees"/>
  <value name="R" desc="radians"/>
</assumption>
```

#### Function
For mathematical function interpretations.
Example ("log 20" query):
```xml
<assumption type="Function" word="log">
  <value name="Log" desc="natural logarithm"/>
  <value name="Log10" desc="base 10 logarithm"/>
</assumption>
```

### 3. Date and Time Assumptions

#### TimeAMOrPM
For time ambiguity.
Example ("3:00" query):
```xml
<assumption type="TimeAMOrPM">
  <value name="pm" desc="3:00 PM"/>
  <value name="am" desc="3:00 AM"/>
</assumption>
```

#### DateOrder
For date format interpretation.
Example ("12/5/1999" query):
```xml
<assumption type="DateOrder">
  <value name="MonthDayYear" desc="month/day/year"/>
  <value name="DayMonthYear" desc="day/month/year"/>
</assumption>
```

## Pod States

Pod states allow modification of pod content through button-like controls.

### Basic Pod States

Example from "pi" query:
```xml
<pod title="Decimal approximation">
  <states count="1">
    <state name="More digits" input="DecimalApproximation__More digits"/>
  </states>
</pod>
```

### State Changes

Apply state changes using `podstate` parameter:
```
&podstate=DecimalApproximation__More+digits
```

### Multiple State Changes

Chain state changes with "@" symbol:
```
&podstate=2@DecimalApproximation__More+digits
```

### Subpod States

Some states modify individual subpods:
```xml
<subpod title="Result">
  <states count="1">
    <state name="Show formula" input="SelfInductanceSingleLayerCircularCoil__Result_Show formula"/>
  </states>
</subpod>
```

## Applying Assumptions and States

### Using Assumptions

Add assumption parameter with input value:
```
&assumption=*C.pi-_*Movie-
```

Multiple assumptions can be combined:
```
&assumption=*C.pi-_*Movie-&assumption=DateOrder_**Day.Month.Year--
```

### Using Pod States

1. Basic state change:
```
&podstate=DecimalApproximation__More+digits
```

2. Multiple state changes:
```
&podstate=DecimalApproximation__More+digits&podstate=DecimalApproximation__Fewer+digits
```

3. Chained state changes:
```
&podstate=2@DecimalApproximation__More+digits
```

### Best Practices

1. Always check assumption validity before application
2. Use state changes incrementally
3. Verify results after assumption/state changes
4. Handle missing or invalid assumptions gracefully
5. Consider user location for unit assumptions
6. Maintain assumption context in multi-step queries