# Usage Examples and Common Patterns

## Basic Query Examples

### Mathematical Calculations
```http
http://api.wolframalpha.com/v1/result?appid=DEMO&i=2%2B2
```
Expected Response: "4"

### Unit Conversions
```http
http://api.wolframalpha.com/v1/result?appid=DEMO&i=convert+5+kilometers+to+miles
```
Expected Response: "3.10686 miles"

### Population Queries
```http
http://api.wolframalpha.com/v1/result?appid=DEMO&i=population+of+France
```
Expected Response: "67.39 million people (2020 estimate)"

### Distance Calculations
```http
http://api.wolframalpha.com/v1/result?appid=DEMO&i=distance+from+Paris+to+London
```
Expected Response: "342 kilometers"

## Advanced Usage Patterns

### Combining Multiple Parameters
```http
http://api.wolframalpha.com/v1/result?appid=DEMO&i=distance+to+moon&units=metric&timeout=10
```

### Scientific Calculations
```http
http://api.wolframalpha.com/v1/result?appid=DEMO&i=mass+of+electron
```
Expected Response: "9.1093837015(28)×10^-31 kg"

### Weather Information
```http
http://api.wolframalpha.com/v1/result?appid=DEMO&i=weather+in+Paris
```
Expected Response: "72°F, Partly cloudy" (varies by time)

## Common Use Cases

### Educational Applications
1. **Mathematical Problems**
   ```http
   http://api.wolframalpha.com/v1/result?appid=DEMO&i=solve+x%5E2%2B2x%2B1%3D0
   ```

2. **Scientific Constants**
   ```http
   http://api.wolframalpha.com/v1/result?appid=DEMO&i=speed+of+light
   ```

3. **Chemical Formulas**
   ```http
   http://api.wolframalpha.com/v1/result?appid=DEMO&i=molecular+weight+of+H2O
   ```

### Business Applications
1. **Currency Conversion**
   ```http
   http://api.wolframalpha.com/v1/result?appid=DEMO&i=convert+100+USD+to+EUR
   ```

2. **Market Data**
   ```http
   http://api.wolframalpha.com/v1/result?appid=DEMO&i=AAPL+stock+price
   ```

3. **Economic Indicators**
   ```http
   http://api.wolframalpha.com/v1/result?appid=DEMO&i=GDP+of+Germany
   ```

### Research Applications
1. **Statistical Data**
   ```http
   http://api.wolframalpha.com/v1/result?appid=DEMO&i=standard+deviation+of+%7B1%2C2%2C3%2C4%2C5%7D
   ```

2. **Historical Data**
   ```http
   http://api.wolframalpha.com/v1/result?appid=DEMO&i=population+of+London+in+1900
   ```

3. **Scientific Research**
   ```http
   http://api.wolframalpha.com/v1/result?appid=DEMO&i=half+life+of+uranium+235
   ```

## Implementation Patterns

### Error Handling Pattern
```python
def safe_query(query, retries=3):
    for attempt in range(retries):
        try:
            response = query_wolfram_alpha(query, APP_ID)
            return response
        except Exception as e:
            if attempt == retries - 1:
                raise
            time.sleep(2 ** attempt)  # Exponential backoff
```

### Caching Pattern
```python
import redis

class CachedWolframAPI:
    def __init__(self, app_id, redis_client):
        self.app_id = app_id
        self.redis = redis_client
        self.cache_ttl = 3600  # 1 hour
        
    def query(self, question):
        cache_key = f"wolfram:{question}"
        
        # Try cache first
        cached = self.redis.get(cache_key)
        if cached:
            return cached.decode('utf-8')
            
        # Make API call if not cached
        result = query_wolfram_alpha(question, self.app_id)
        
        # Cache the result
        self.redis.setex(cache_key, self.cache_ttl, result)
        return result
```

### Rate Limiting Pattern
```python
class RateLimitedAPI:
    def __init__(self, app_id, requests_per_minute=60):
        self.app_id = app_id
        self.requests_per_minute = requests_per_minute
        self.requests = []
        
    def query(self, question):
        self._check_rate_limit()
        return query_wolfram_alpha(question, self.app_id)
        
    def _check_rate_limit(self):
        now = time.time()
        minute_ago = now - 60
        
        # Remove old requests
        self.requests = [req_time for req_time in self.requests 
                        if req_time > minute_ago]
                        
        if len(self.requests) >= self.requests_per_minute:
            raise Exception("Rate limit exceeded")
            
        self.requests.append(now)
```

## Response Processing Patterns

### Numerical Processing
```python
def process_numerical_response(response):
    # Remove units and convert to float
    numeric_part = response.split()[0]
    try:
        return float(numeric_part)
    except ValueError:
        return None
```

### Unit Conversion
```python
def standardize_units(response, target_unit):
    result = query_wolfram_alpha(
        f"convert {response} to {target_unit}",
        APP_ID
    )
    return result
```

### Response Formatting
```python
def format_response(response, format_type):
    if format_type == 'json':
        return {'result': response}
    elif format_type == 'xml':
        return f'<result>{response}</result>'
    return response
```