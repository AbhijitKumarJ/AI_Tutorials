# Monitoring and Logging Guide

## Comprehensive Logging System

### Advanced Logger Implementation
```python
import logging
import json
from datetime import datetime
from typing import Dict, Any

class WolframAPILogger:
    """
    Advanced logging system for Wolfram Alpha API interactions
    """
    def __init__(self, log_file: str = "wolfram_api.log"):
        self.logger = logging.getLogger("WolframAPI")
        self.logger.setLevel(logging.INFO)
        
        # File handler
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.INFO)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)

    def log_request(self, query: str, params: Dict[str, Any]) -> None:
        """Log API request details"""
        log_data = {
            'timestamp': datetime.now().isoformat(),
            'event_type': 'request',
            'query': query,
            'parameters': params
        }
        self.logger.info(json.dumps(log_data))

    def log_response(self, query: str, response: str, 
                    duration: float) -> None:
        """Log API response details"""
        log_data = {
            'timestamp': datetime.now().isoformat(),
            'event_type': 'response',
            'query': query,
            'response': response,
            'duration_ms': duration * 1000
        }
        self.logger.info(json.dumps(log_data))

    def log_error(self, query: str, error: Exception, 
                 context: Dict[str, Any] = None) -> None:
        """Log error details"""
        log_data = {
            'timestamp': datetime.now().isoformat(),
            'event_type': 'error',
            'query': query,
            'error_type': type(error).__name__,
            'error_message': str(error),
            'context': context or {}
        }
        self.logger.error(json.dumps(log_data))
```

### Metrics Collection
```python
class APIMetricsCollector:
    """
    Collect and analyze API usage metrics
    """
    def __init__(self):
        self.metrics = {
            'requests': [],
            'response_times': [],
            'errors': [],
            'status_codes': {}
        }

    def record_request(self, timestamp: datetime, 
                      response_time: float, 
                      status_code: int) -> None:
        """Record request metrics"""
        self.metrics['requests'].append({
            'timestamp': timestamp,
            'response_time': response_time
        })
        self.metrics['response_times'].append(response_time)
        self.metrics['status_codes'][status_code] = \
            self.metrics['status_codes'].get(status_code, 0) + 1

    def get_average_response_time(self) -> float:
        """Calculate average response time"""
        if not self.metrics['response_times']:
            return 0
        return sum(self.metrics['response_times']) / \
               len(self.metrics['response_times'])

    def get_error_rate(self) -> float:
        """Calculate error rate"""
        total_requests = len(self.metrics['requests'])
        if not total_requests:
            return 0
        error_count = len(self.metrics['errors'])
        return (error_count / total_requests) * 100

    def generate_report(self) -> Dict[str, Any]:
        """Generate comprehensive metrics report"""
        return {
            'total_requests': len(self.metrics['requests']),
            'average_response_time': self.get_average_response_time(),
            'error_rate': self.get_error_rate(),
            'status_code_distribution': self.metrics['status_codes']
        }
```

## Performance Monitoring

### Response Time Tracking
```python
class PerformanceMonitor:
    """
    Monitor API performance metrics
    """
    def __init__(self):
        self.response_times = []
        self.slow_threshold_ms = 1000  # 1 second
        self.alert_threshold_ms = 2000  # 2 seconds

    def record_response_time(self, duration_ms: float) -> None:
        """Record and analyze response time"""
        self.response_times.append(duration_ms)
        
        if duration_ms > self.alert_threshold_ms:
            self._trigger_alert(duration_ms)
        elif duration_ms > self.slow_threshold_ms:
            self._log_slow_response(duration_ms)

    def get_performance_stats(self) -> Dict[str, float]:
        """Calculate performance statistics"""
        if not self.response_times:
            return {
                'avg': 0,
                'min': 0,
                'max': 0,
                'p95': 0,
                'p99': 0
            }

        sorted_times = sorted(self.response_times)
        return {
            'avg': sum(self.response_times) / len(self.response_times),
            'min': sorted_times[0],
            'max': sorted_times[-1],
            'p95': sorted_times[int(len(sorted_times) * 0.95)],
            'p99': sorted_times[int(len(sorted_times) * 0.99)]
        }

    def _trigger_alert(self, duration_ms: float) -> None:
        """Handle critical performance issues"""
        alert_data = {
            'timestamp': datetime.now().isoformat(),
            'duration_ms': duration_ms,
            'threshold_ms': self.alert_threshold_ms
        }
        # Implement alert mechanism (e.g., email, Slack)
        logging.error(f"Performance Alert: {json.dumps(alert_data)}")

    def _log_slow_response(self, duration_ms: float) -> None:
        """Log slow response times"""
        logging.warning(
            f"Slow response detected: {duration_ms}ms"
        )
```

## Health Monitoring

### API Health Check System
```python
class HealthMonitor:
    """
    Monitor API health and availability
    """
    def __init__(self, app_id: str):
        self.app_id = app_id
        self.health_checks = []
        self.last_check = None
        self.consecutive_failures = 0
        self.max_failures = 3

    async def check_health(self) -> Dict[str, Any]:
        """Perform health check"""
        try:
            start_time = time.time()
            # Simple test query
            response = await self.test_api()
            duration = time.time() - start_time

            health_status = {
                'status': 'healthy' if response else 'degraded',
                'timestamp': datetime.now().isoformat(),
                'response_time': duration,
                'consecutive_failures': self.consecutive_failures
            }

            self.health_checks.append(health_status)
            self.last_check = health_status
            self.consecutive_failures = 0

            return health_status

        except Exception as e:
            self.consecutive_failures += 1
            health_status = {
                'status': 'unhealthy',
                'timestamp': datetime.now().isoformat(),
                'error': str(e),
                'consecutive_failures': self.consecutive_failures
            }
            
            self.health_checks.append(health_status)
            self.last_check = health_status

            if self.consecutive_failures >= self.max_failures:
                await self._handle_critical_failure()

            return health_status

    async def test_api(self) -> bool:
        """Test API with simple query"""
        try:
            query = "2+2"
            response = await query_wolfram_alpha(query, self.app_id)
            return response == "4"
        except Exception as e:
            logging.error(f"Health check failed: {str(e)}")
            return False

    async def _handle_critical_failure(self) -> None:
        """Handle critical health issues"""
        alert_data = {
            'timestamp': datetime.now().isoformat(),
            'consecutive_failures': self.consecutive_failures,
            'last_check': self.last_check
        }
        # Implement critical failure handling
        logging.critical(f"Critical API failure: {json.dumps(alert_data)}")
```

## Alert System

### Alert Manager
```python
class AlertManager:
    """
    Manage and distribute system alerts
    """
    def __init__(self):
        self.alert_levels = {
            'INFO': 0,
            'WARNING': 1,
            'ERROR': 2,
            'CRITICAL': 3
        }
        self.alert_handlers = {
            'INFO': self._handle_info,
            'WARNING': self._handle_warning,
            'ERROR': self._handle_error,
            'CRITICAL': self._handle_critical
        }

    async def trigger_alert(self, level: str, 
                          message: str, 
                          context: Dict[str, Any] = None) -> None:
        """Trigger alert with appropriate handler"""
        if level not in self.alert_levels:
            raise ValueError(f"Invalid alert level: {level}")

        alert_data = {
            'timestamp': datetime.now().isoformat(),
            'level': level,
            'message': message,
            'context': context or {}
        }

        await self.alert_handlers[level](alert_data)

    async def _handle_info(self, alert_data: Dict[str, Any]) -> None:
        """Handle informational alerts"""
        logging.info(json.dumps(alert_data))

    async def _handle_warning(self, alert_data: Dict[str, Any]) -> None:
        """Handle warning alerts"""
        logging.warning(json.dumps(alert_data))
        # Implement notification system (e.g., email)

    async def _handle_error(self, alert_data: Dict[str, Any]) -> None:
        """Handle error alerts"""
        logging.error(json.dumps(alert_data))
        # Implement error notification system

    async def _handle_critical(self, alert_data: Dict[str, Any]) -> None:
        """Handle critical alerts"""
        logging.critical(json.dumps(alert_data))
        # Implement emergency notification system
```