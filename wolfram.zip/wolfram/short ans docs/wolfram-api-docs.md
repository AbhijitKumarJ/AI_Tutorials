# Wolfram|Alpha Short Answers API Documentation

## Overview
The Wolfram|Alpha Short Answers API is designed to deliver brief answers in the most basic format possible through a standard REST protocol using HTTP GET requests. This API returns a single plain text result directly from Wolfram|Alpha, typically taken from the Result pod of Wolfram|Alpha output.

### Key Points
- Returns single plain text results
- Implemented using REST protocol with HTTP GET requests
- May fail if no sufficiently short result is available
- Some subjects may be restricted by default
- Subject to API Terms of Use and Commercial Terms of Use

## Getting Started

### Registration and Authentication
1. **Sign Up Process**
   - Register for a Wolfram ID
   - Sign in to the Wolfram|Alpha Developer Portal

2. **Obtaining an AppID**
   - Click the "Get an AppID" button
   - Provide your application details:
     - Application name
     - Description
     - Select app type
   - Note: Each application requires its unique AppID

## Using the API

### Base URL
```
http://api.wolframalpha.com/v1/result
```

### Required Parameters
Every query needs two essential pieces of information:
1. **AppID** (using the `appid` parameter)
   ```
   http://api.wolframalpha.com/v1/result?appid=DEMO
   ```

2. **Input Value** (using the `i` parameter)
   - Must be URL-encoded
   - Example query: "How far is Los Angeles from New York?"
   ```
   http://api.wolframalpha.com/v1/result?appid=DEMO&i=How+far+is+Los+Angeles+from+New+York%3f
   ```

### URL Parameters and Options

#### 1. units
- Purpose: Select measurement system
- Values: 
  - `metric`
  - `imperial`
- Default: Based on user location
- Example:
  ```
  http://api.wolframalpha.com/v1/result?appid=DEMO&i=How+far+is+Los+Angeles+from+New+York%3f&units=metric
  ```

#### 2. timeout
- Purpose: Maximum processing time
- Value: Time in seconds
- Default: 5 seconds
- Note: May affect returned values
- Usage: Optimize response times

## Error Handling

### HTTP Status 501
- Indicates input interpretation failure
- Common causes:
  - Misspelled input
  - Poor formatting
  - Unintelligible queries
  - No sufficiently short result available
  - Restricted or uncovered topics

### HTTP Status 400
- Indicates missing input parameter
- Usually caused by incorrect `i` parameter syntax
- Solution: Verify input parameter syntax

### AppID Errors

#### Invalid AppID (Error 1)
- Cause: Invalid `appid` parameter
- Solutions:
  - Verify AppID spelling
  - Check parameter syntax

#### Missing AppID (Error 2)
- Cause: No `appid` parameter provided
- Solutions:
  - Ensure AppID is included
  - Verify parameter syntax

## Additional Resources
- FAQ
- Wolfram|Alpha APIs Overview
- Short Answers API Explorer
- Language Libraries

## Contact and Support
- Available for additional topic access requests
- Commercial licensing options
- Flexible monthly plans available

## Legal Information
© 2024 Wolfram Alpha LLC
- Terms of Use
- Privacy Policy
- Commercial Terms of Use

## Related Products
- Pro Mobile Apps
- API & Developer Solutions
- LLM Solutions
- Wolfram Language
- Mathematica
- Wolfram Demonstrations
- Wolfram for Education
- MathWorld