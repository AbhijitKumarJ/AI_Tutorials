# Deployment and Infrastructure Guide

## Container Deployment

### Docker Configuration

#### Dockerfile Example
```dockerfile
FROM python:3.9-slim

# Set working directory
WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Environment variables
ENV WOLFRAM_APP_ID=""
ENV API_PORT=8080
ENV LOG_LEVEL=INFO

# Expose port
EXPOSE 8080

# Start application
CMD ["python", "app.py"]
```

#### Docker Compose Configuration
```yaml
version: '3.8'

services:
  wolfram-api:
    build: .
    ports:
      - "8080:8080"
    environment:
      - WOLFRAM_APP_ID=${WOLFRAM_APP_ID}
      - REDIS_URL=redis://redis:6379
      - LOG_LEVEL=INFO
    depends_on:
      - redis
    volumes:
      - ./logs:/app/logs
    restart: unless-stopped

  redis:
    image: redis:alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    restart: unless-stopped

volumes:
  redis-data:
```

### Kubernetes Deployment

#### Deployment Configuration
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: wolfram-api
  namespace: production
spec:
  replicas: 3
  selector:
    matchLabels:
      app: wolfram-api
  template:
    metadata:
      labels:
        app: wolfram-api
    spec:
      containers:
      - name: wolfram-api
        image: wolfram-api:latest
        ports:
        - containerPort: 8080
        env:
        - name: WOLFRAM_APP_ID
          valueFrom:
            secretKeyRef:
              name: wolfram-secrets
              key: app-id
        resources:
          requests:
            cpu: "100m"
            memory: "256Mi"
          limits:
            cpu: "500m"
            memory: "512Mi"
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 5
```

#### Service Configuration
```yaml
apiVersion: v1
kind: Service
metadata:
  name: wolfram-api-service
  namespace: production
spec:
  selector:
    app: wolfram-api
  ports:
  - port: 80
    targetPort: 8080
  type: LoadBalancer
```

## Infrastructure Setup

### Load Balancer Configuration

#### Nginx Configuration
```nginx
upstream wolfram_api {
    least_conn;  # Load balancing method
    server api1.example.com:8080;
    server api2.example.com:8080;
    server api3.example.com:8080;
}

server {
    listen 80;
    server_name api.example.com;

    location / {
        proxy_pass http://wolfram_api;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;

        # Buffering
        proxy_buffering on;
        proxy_buffer_size 8k;
        proxy_buffers 8 8k;
    }

    # Health check endpoint
    location /health {
        access_log off;
        add_header Content-Type text/plain;
        return 200 'healthy';
    }
}
```

### SSL/TLS Configuration

#### Certificate Management
```bash
#!/bin/bash
# SSL certificate renewal script

# Variables
DOMAIN="api.example.com"
CERT_PATH="/etc/letsencrypt/live/$DOMAIN"
NGINX_CONF="/etc/nginx/sites-enabled/default"

# Renew certificate
certbot renew --quiet

# Check if renewal was successful
if [ $? -eq 0 ]; then
    # Reload Nginx
    nginx -t && systemctl reload nginx
    
    # Log success
    logger "SSL certificate renewed successfully for $DOMAIN"
else
    # Log failure
    logger "SSL certificate renewal failed for $DOMAIN"
    
    # Send alert
    ./send_alert.sh "SSL certificate renewal failed for $DOMAIN"
fi
```

## Monitoring Setup

### Prometheus Configuration
```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'wolfram-api'
    metrics_path: '/metrics'
    static_configs:
      - targets: ['localhost:8080']
    relabel_configs:
      - source_labels: [__address__]
        target_label: instance
        regex: '(.*):.*'
        replacement: '${1}'

  - job_name: 'node-exporter'
    static_configs:
      - targets: ['localhost:9100']
```

### Grafana Dashboard Configuration
```json
{
  "dashboard": {
    "id": null,
    "title": "Wolfram API Dashboard",
    "panels": [
      {
        "title": "Request Rate",
        "type": "graph",
        "datasource": "Prometheus",
        "targets": [
          {
            "expr": "rate(http_requests_total[5m])",
            "legendFormat": "{{method}} {{path}}"
          }
        ]
      },
      {
        "title": "Response Times",
        "type": "heatmap",
        "datasource": "Prometheus",
        "targets": [
          {
            "expr": "rate(http_request_duration_seconds_bucket[5m])",
            "legendFormat": "{{le}}"
          }
        ]
      }
    ]
  }
}
```

## Backup and Recovery

### Backup Strategy
```python
class BackupManager:
    """
    Manage API configuration and data backups
    """
    def __init__(self, backup_dir: str):
        self.backup_dir = backup_dir
        self.timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    async def create_backup(self) -> str:
        """Create a complete backup"""
        backup_path = f"{self.backup_dir}/backup_{self.timestamp}"
        try:
            # Backup configuration
            await self._backup_config(backup_path)
            
            # Backup cache data
            await self._backup_cache(backup_path)
            
            # Backup logs
            await self._backup_logs(backup_path)
            
            # Create backup manifest
            await self._create_manifest(backup_path)
            
            return backup_path
        except Exception as e:
            logging.error(f"Backup failed: {str(e)}")
            raise

    async def restore_backup(self, backup_path: str) -> None:
        """Restore from backup"""
        try:
            # Verify backup integrity
            if not await self._verify_backup(backup_path):
                raise ValueError("Backup verification failed")

            # Restore configuration
            await self._restore_config(backup_path)
            
            # Restore cache data
            await self._restore_cache(backup_path)
            
            logging.info(f"Backup restored successfully from {backup_path}")
        except Exception as e:
            logging.error(f"Restore failed: {str(e)}")
            raise

    async def _verify_backup(self, backup_path: str) -> bool:
        """Verify backup integrity"""
        try:
            manifest_path = f"{backup_path}/manifest.json"
            with open(manifest_path, 'r') as f:
                manifest = json.load(f)
            
            # Check all required files
            for file_info in manifest['files']:
                file_path = f"{backup_path}/{file_info['path']}"
                if not os.path.exists(file_path):
                    return False
                    
                # Verify file hash
                if not self._verify_file_hash(file_path, file_info['hash']):
                    return False
                    
            return True
        except Exception:
            return False

    def _verify_file_hash(self, file_path: str, expected_hash: str) -> bool:
        """Verify file integrity using SHA-256"""
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest() == expected_hash
```

## Disaster Recovery

### Recovery Procedures
```python
class DisasterRecovery:
    """
    Handle disaster recovery procedures
    """
    def __init__(self):
        self.recovery_steps = []
        self.status = "normal"

    async def initiate_recovery(self, incident_type: str) -> None:
        """Start recovery process"""
        self.status = "recovery_in_progress"
        
        try:
            # Log incident
            await self._log_incident(incident_type)
            
            # Execute recovery steps
            await self._execute_recovery_plan(incident_type)
            
            # Verify system status
            await self._verify_system_status()
            
            self.status = "normal"
            
        except Exception as e:
            self.status = "recovery_failed"
            logging.critical(f"Recovery failed: {str(e)}")
            raise

    async def _execute_recovery_plan(self, incident_type: str) -> None:
        """Execute recovery steps based on incident type"""
        recovery_plans = {
            'service_outage': self._handle_service_outage,
            'data_corruption': self._handle_data_corruption,
            'security_breach': self._handle_security_breach
        }
        
        if incident_type not in recovery_plans:
            raise ValueError(f"No recovery plan for incident type: {incident_type}")
            
        await recovery_plans[incident_type]()

    async def _verify_system_status(self) -> bool:
        """Verify system is functioning correctly"""
        checks = [
            self._verify_api_connectivity(),
            self._verify_data_integrity(),
            self._verify_security_measures()
        ]
        
        results = await asyncio.gather(*checks)
        return all(results)
```