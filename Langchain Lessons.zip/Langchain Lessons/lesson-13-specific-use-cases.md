# Lesson 13: LangChain for Specific Use Cases

## Overview

In this lesson, we'll explore how to apply LangChain to specific real-world use cases. We'll focus on building practical applications such as question-answering systems, summarization tools, and code analysis/generation utilities. We'll also cover how to deploy these applications across different platforms and customize LangChain for domain-specific needs.

## Learning Objectives

By the end of this lesson, you will be able to:

1. Build open-domain and closed-domain question-answering systems using LangChain
2. Implement extractive and abstractive summarization applications
3. Create code analysis and generation tools using LangChain
4. Deploy LangChain applications across different platforms (web apps, CLI tools)
5. Customize LangChain components for domain-specific applications

## File Structure

```
lesson-13/
│
├── question_answering/
│   ├── open_domain_qa.py
│   └── closed_domain_qa.py
│
├── summarization/
│   ├── extractive_summarization.py
│   └── abstractive_summarization.py
│
├── code_tools/
│   ├── code_analysis.py
│   └── code_generation.py
│
├── deployment/
│   ├── web_app.py
│   └── cli_tool.py
│
├── domain_specific/
│   └── custom_chain.py
│
├── utils/
│   ├── data_loader.py
│   └── evaluation.py
│
└── README.md
```

## Lesson Content

### 1. Question-Answering Systems

Question-answering (QA) systems are one of the most popular applications of language models. LangChain provides powerful tools to build both open-domain and closed-domain QA systems.

#### Open-Domain QA

Open-domain QA systems can answer questions on a wide range of topics without being limited to a specific knowledge base.

```python
# question_answering/open_domain_qa.py
from langchain.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain.vectorstores import Chroma
from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.document_loaders import TextLoader

# Load and preprocess the data
loader = TextLoader("path/to/your/text/file.txt")
documents = loader.load()
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
texts = text_splitter.split_documents(documents)

# Create vector store and retriever
embeddings = OpenAIEmbeddings()
vectorstore = Chroma.from_documents(texts, embeddings)
retriever = vectorstore.as_retriever()

# Create QA chain
llm = OpenAI(temperature=0)
qa_chain = RetrievalQA.from_chain_type(llm, retriever=retriever)

# Ask a question
query = "What is the capital of France?"
response = qa_chain.run(query)
print(response)
```

#### Closed-Domain QA

Closed-domain QA systems focus on answering questions within a specific domain or based on a particular set of documents.

```python
# question_answering/closed_domain_qa.py
from langchain.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.document_loaders import PyPDFLoader

# Load domain-specific documents
loader = PyPDFLoader("path/to/your/domain/specific/document.pdf")
documents = loader.load()
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
texts = text_splitter.split_documents(documents)

# Create vector store and retriever
embeddings = OpenAIEmbeddings()
vectorstore = FAISS.from_documents(texts, embeddings)
retriever = vectorstore.as_retriever()

# Create QA chain
llm = OpenAI(temperature=0)
qa_chain = RetrievalQA.from_chain_type(llm, retriever=retriever)

# Ask a domain-specific question
query = "What are the key features of our product?"
response = qa_chain.run(query)
print(response)
```

### 2. Summarization Applications

Summarization is another common use case for language models. LangChain supports both extractive and abstractive summarization techniques.

#### Extractive Summarization

Extractive summarization involves selecting the most important sentences or phrases from the original text to form a summary.

```python
# summarization/extractive_summarization.py
from langchain.llms import OpenAI
from langchain.chains.summarize import load_summarize_chain
from langchain.text_splitter import CharacterTextSplitter
from langchain.document_loaders import TextLoader

# Load and preprocess the document
loader = TextLoader("path/to/your/long/document.txt")
document = loader.load()
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
texts = text_splitter.split_documents(document)

# Create extractive summarization chain
llm = OpenAI(temperature=0)
chain = load_summarize_chain(llm, chain_type="map_reduce")

# Generate summary
summary = chain.run(texts)
print(summary)
```

#### Abstractive Summarization

Abstractive summarization generates a new summary that captures the essence of the original text but may use different words and phrases.

```python
# summarization/abstractive_summarization.py
from langchain.llms import OpenAI
from langchain.chains.summarize import load_summarize_chain
from langchain.text_splitter import CharacterTextSplitter
from langchain.document_loaders import TextLoader

# Load and preprocess the document
loader = TextLoader("path/to/your/long/document.txt")
document = loader.load()
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
texts = text_splitter.split_documents(document)

# Create abstractive summarization chain
llm = OpenAI(temperature=0.7)  # Higher temperature for more creativity
chain = load_summarize_chain(llm, chain_type="stuff")

# Generate summary
summary = chain.run(texts)
print(summary)
```

### 3. Code Analysis and Generation

LangChain can be used to build powerful tools for code analysis and generation.

#### Code Analysis

Here's an example of using LangChain to analyze Python code:

```python
# code_tools/code_analysis.py
from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

code_analysis_prompt = PromptTemplate(
    input_variables=["code"],
    template="""
    Analyze the following Python code and provide insights on:
    1. Code structure
    2. Potential bugs or issues
    3. Suggestions for improvement

    Code:
    {code}

    Analysis:
    """
)

llm = OpenAI(temperature=0)
code_analysis_chain = LLMChain(llm=llm, prompt=code_analysis_prompt)

# Example usage
python_code = """
def fibonacci(n):
    if n <= 1:
        return n
    else:
        return fibonacci(n-1) + fibonacci(n-2)

print(fibonacci(10))
"""

analysis = code_analysis_chain.run(code=python_code)
print(analysis)
```

#### Code Generation

LangChain can also be used to generate code based on natural language descriptions:

```python
# code_tools/code_generation.py
from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

code_generation_prompt = PromptTemplate(
    input_variables=["task"],
    template="""
    Generate Python code for the following task:
    {task}

    Please provide clean, efficient, and well-commented code.

    Python Code:
    ```python
    """
)

llm = OpenAI(temperature=0.7)
code_generation_chain = LLMChain(llm=llm, prompt=code_generation_prompt)

# Example usage
task = "Create a function that calculates the factorial of a given number."
generated_code = code_generation_chain.run(task=task)
print(generated_code)
```

### 4. Cross-Platform Deployment

LangChain applications can be deployed across various platforms. Here are examples of deploying as a web app and a CLI tool.

#### Web App Deployment

Using Flask to create a simple web interface for a LangChain application:

```python
# deployment/web_app.py
from flask import Flask, request, jsonify
from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

app = Flask(__name__)

llm = OpenAI(temperature=0.7)
prompt = PromptTemplate(
    input_variables=["topic"],
    template="Write a short story about {topic}."
)
story_chain = LLMChain(llm=llm, prompt=prompt)

@app.route('/generate_story', methods=['POST'])
def generate_story():
    topic = request.json['topic']
    story = story_chain.run(topic=topic)
    return jsonify({'story': story})

if __name__ == '__main__':
    app.run(debug=True)
```

#### CLI Tool Deployment

Creating a command-line interface for a LangChain application using Click:

```python
# deployment/cli_tool.py
import click
from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

llm = OpenAI(temperature=0.7)
prompt = PromptTemplate(
    input_variables=["topic"],
    template="Write a short story about {topic}."
)
story_chain = LLMChain(llm=llm, prompt=prompt)

@click.command()
@click.option('--topic', prompt='Enter a topic for the story', help='The topic of the story.')
def generate_story(topic):
    """Generate a short story based on the given topic."""
    story = story_chain.run(topic=topic)
    click.echo(story)

if __name__ == '__main__':
    generate_story()
```

### 5. Customizing LangChain for Domain-Specific Applications

LangChain can be customized for specific domains by creating custom components or adapting existing ones.

Here's an example of a custom chain for a medical diagnosis assistant:

```python
# domain_specific/custom_chain.py
from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field
from typing import List

class Diagnosis(BaseModel):
    possible_conditions: List[str] = Field(description="List of possible medical conditions")
    recommended_tests: List[str] = Field(description="List of recommended medical tests")
    advice: str = Field(description="General advice for the patient")

diagnosis_prompt = PromptTemplate(
    input_variables=["symptoms"],
    template="""
    As a medical diagnosis assistant, analyze the following symptoms and provide:
    1. A list of possible medical conditions
    2. Recommended medical tests
    3. General advice for the patient

    Symptoms: {symptoms}

    {format_instructions}
    """
)

parser = PydanticOutputParser(pydantic_object=Diagnosis)

llm = OpenAI(temperature=0.5)
diagnosis_chain = LLMChain(
    llm=llm,
    prompt=diagnosis_prompt,
    output_parser=parser
)

# Example usage
symptoms = "Persistent cough, fever, and fatigue for the past week"
result = diagnosis_chain.run(symptoms=symptoms, format_instructions=parser.get_format_instructions())
print(result)
```

## Exercises

1. Question-Answering Exercise:
   Build a closed-domain QA system for a specific topic of your choice (e.g., a company's FAQ, a scientific domain).

2. Summarization Exercise:
   Create a tool that summarizes news articles, comparing the results of extractive and abstractive summarization.

3. Code Analysis Exercise:
   Develop a LangChain application that analyzes GitHub repositories and provides code quality insights.

4. Deployment Exercise:
   Take one of the applications you've built in this course and deploy it as both a web app and a CLI tool.

5. Domain-Specific Exercise:
   Design and implement a custom LangChain application for a specific domain (e.g., legal document analysis, financial advice).

## Conclusion

In this lesson, we've explored how to apply LangChain to various real-world use cases, including question-answering systems, summarization tools, and code analysis/generation utilities. We've also covered cross-platform deployment strategies and how to customize LangChain for domain-specific applications.

These practical applications demonstrate the versatility and power of LangChain in solving complex language-related tasks. As you continue to work with LangChain, you'll discover even more ways to leverage its capabilities in your own projects and domains.

## Additional Resources

1. LangChain Documentation on Specific Tasks
2. Flask Documentation for Web App Development
3. Click Documentation for CLI Tool Creation
4. Research Papers on State-of-the-Art QA and Summarization Techniques
5. Domain-Specific AI Applications Case Studies

In the next lesson, we'll delve into evaluation and testing techniques for LangChain applications, ensuring that our AI systems are robust and reliable.

