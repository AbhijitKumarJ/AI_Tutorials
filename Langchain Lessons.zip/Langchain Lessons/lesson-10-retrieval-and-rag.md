# Lesson 10: Retrieval and Retrieval-Augmented Generation (RAG) in LangChain

## Lesson Overview

In this lesson, we'll explore Retrieval and Retrieval-Augmented Generation (RAG) in LangChain. These techniques are crucial for building advanced question-answering systems and improving the performance of language models on specific domains. We'll cover basic retrieval systems, RAG applications, and various strategies to optimize retrieval performance.

## Learning Objectives

By the end of this lesson, you should be able to:

1. Implement basic retrieval systems using LangChain
2. Understand the concept of Retrieval-Augmented Generation (RAG)
3. Build RAG applications that combine retrieval with language model generation
4. Optimize retrieval performance using various techniques
5. Deploy RAG systems across different platforms
6. Evaluate and improve the quality of RAG systems

## Lesson Outline

1. Introduction to Retrieval and RAG
2. Implementing Basic Retrieval Systems
3. Building RAG Applications
4. Optimizing Retrieval Performance
5. Cross-Platform Deployment of RAG Systems
6. Evaluating and Improving RAG Quality
7. Hands-on Project: Building an Advanced Q&A System with RAG
8. Summary and Next Steps

## Lesson Content

### 1. Introduction to Retrieval and RAG

Retrieval systems aim to find relevant information from a large corpus of documents based on a given query. Retrieval-Augmented Generation (RAG) takes this a step further by using the retrieved information to augment the input of a language model, allowing it to generate more accurate and contextually relevant responses.

**Key Concepts:**
- Information Retrieval basics
- Vector-based retrieval
- Context augmentation in language models
- Advantages of RAG over fine-tuning

### 2. Implementing Basic Retrieval Systems

Let's start by implementing a basic retrieval system using LangChain:

```python
from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.document_loaders import TextLoader
from langchain.text_splitter import CharacterTextSplitter

class BasicRetriever:
    def __init__(self, document_path: str):
        self.embeddings = OpenAIEmbeddings()
        self.vectorstore = self._create_vectorstore(document_path)
    
    def _create_vectorstore(self, document_path: str):
        loader = TextLoader(document_path)
        documents = loader.load()
        text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
        texts = text_splitter.split_documents(documents)
        return FAISS.from_documents(texts, self.embeddings)
    
    def retrieve(self, query: str, k: int = 5):
        return self.vectorstore.similarity_search(query, k=k)

# Usage
retriever = BasicRetriever("path/to/your/document.txt")
results = retriever.retrieve("What is machine learning?")
for doc in results:
    print(doc.page_content[:200] + "...")
```

### 3. Building RAG Applications

Now, let's implement a RAG application that combines retrieval with language model generation:

```python
from langchain.chat_models import ChatOpenAI
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate

class RAGApplication:
    def __init__(self, retriever: BasicRetriever):
        self.retriever = retriever
        self.llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0)
        self.qa_chain = self._create_qa_chain()
    
    def _create_qa_chain(self):
        prompt_template = """Use the following pieces of context to answer the question at the end. 
        If you don't know the answer, just say that you don't know, don't try to make up an answer.

        {context}

        Question: {question}
        Answer:"""
        PROMPT = PromptTemplate(
            template=prompt_template, input_variables=["context", "question"]
        )
        
        return RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",
            retriever=self.retriever.vectorstore.as_retriever(),
            chain_type_kwargs={"prompt": PROMPT}
        )
    
    def answer_question(self, question: str):
        return self.qa_chain.run(question)

# Usage
rag_app = RAGApplication(retriever)
answer = rag_app.answer_question("Explain the concept of neural networks in machine learning.")
print(answer)
```

### 4. Optimizing Retrieval Performance

To improve retrieval performance, we can implement various techniques:

1. **Hybrid Search**: Combine semantic search with keyword-based search

```python
from langchain.retrievers import BM25Retriever
from langchain.retrievers import EnsembleRetriever

class HybridRetriever:
    def __init__(self, vectorstore, documents):
        self.semantic_retriever = vectorstore.as_retriever()
        self.bm25_retriever = BM25Retriever.from_documents(documents)
        self.ensemble_retriever = EnsembleRetriever(
            retrievers=[self.semantic_retriever, self.bm25_retriever],
            weights=[0.5, 0.5]
        )
    
    def retrieve(self, query: str, k: int = 5):
        return self.ensemble_retriever.get_relevant_documents(query)

# Usage
hybrid_retriever = HybridRetriever(retriever.vectorstore, documents)
results = hybrid_retriever.retrieve("What are the applications of deep learning?")
```

2. **Re-ranking**: Implement a two-stage retrieval process with re-ranking

```python
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import LLMChainExtractor

class ReRankingRetriever:
    def __init__(self, vectorstore):
        base_retriever = vectorstore.as_retriever()
        compressor = LLMChainExtractor.from_llm(llm)
        self.retriever = ContextualCompressionRetriever(
            base_compressor=compressor,
            base_retriever=base_retriever
        )
    
    def retrieve(self, query: str):
        return self.retriever.get_relevant_documents(query)

# Usage
reranking_retriever = ReRankingRetriever(retriever.vectorstore)
results = reranking_retriever.retrieve("Explain the concept of transfer learning in AI.")
```

3. **Query Expansion**: Use language models to expand the original query

```python
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

class QueryExpansionRetriever:
    def __init__(self, vectorstore, llm):
        self.vectorstore = vectorstore
        self.llm = llm
        self.query_expansion_chain = self._create_query_expansion_chain()
    
    def _create_query_expansion_chain(self):
        prompt = PromptTemplate(
            input_variables=["question"],
            template="Expand the following question with relevant keywords and phrases:\n\nQuestion: {question}\n\nExpanded Question:"
        )
        return LLMChain(llm=self.llm, prompt=prompt)
    
    def retrieve(self, query: str, k: int = 5):
        expanded_query = self.query_expansion_chain.run(query)
        return self.vectorstore.similarity_search(expanded_query, k=k)

# Usage
query_expansion_retriever = QueryExpansionRetriever(retriever.vectorstore, ChatOpenAI())
results = query_expansion_retriever.retrieve("What is the impact of AI on healthcare?")
```

### 5. Cross-Platform Deployment of RAG Systems

When deploying RAG systems across different platforms, consider the following:

1. Containerization (e.g., Docker) for consistent environments
2. Cloud-based deployment options (AWS, GCP, Azure)
3. Serverless architectures for scalability

Here's an example of how to containerize a RAG application using Docker:

```dockerfile
# Dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["python", "rag_app.py"]
```

```python
# rag_app.py
import os
from flask import Flask, request, jsonify
from rag_system import RAGApplication, BasicRetriever

app = Flask(__name__)

# Initialize RAG system
retriever = BasicRetriever(os.environ.get("DOCUMENT_PATH", "default_document.txt"))
rag_app = RAGApplication(retriever)

@app.route("/answer", methods=["POST"])
def answer_question():
    data = request.json
    question = data.get("question")
    if not question:
        return jsonify({"error": "No question provided"}), 400
    
    answer = rag_app.answer_question(question)
    return jsonify({"answer": answer})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
```

To build and run the Docker container:

```bash
docker build -t rag-app .
docker run -p 8080:8080 -e DOCUMENT_PATH=/path/to/document.txt rag-app
```

### 6. Evaluating and Improving RAG Quality

To evaluate and improve the quality of RAG systems:

1. Implement metrics like relevance, coherence, and factual accuracy
2. Use human evaluation for qualitative assessment
3. Continuously update and refine the knowledge base

Here's an example of how to implement a simple evaluation metric:

```python
from langchain.evaluation.qa import QAEvalChain

class RAGEvaluator:
    def __init__(self, llm):
        self.eval_chain = QAEvalChain.from_llm(llm)
    
    def evaluate(self, examples, predictions):
        graded_outputs = self.eval_chain.evaluate(examples, predictions)
        return graded_outputs

# Usage
evaluator = RAGEvaluator(ChatOpenAI())
examples = [
    {"query": "What is machine learning?", "answer": "Machine learning is a subset of AI..."},
    {"query": "Explain neural networks.", "answer": "Neural networks are a type of machine learning model..."}
]
predictions = [
    {"query": "What is machine learning?", "result": rag_app.answer_question("What is machine learning?")},
    {"query": "Explain neural networks.", "result": rag_app.answer_question("Explain neural networks.")}
]
evaluation_results = evaluator.evaluate(examples, predictions)
print(evaluation_results)
```

### 7. Hands-on Project: Building an Advanced Q&A System with RAG

Let's build an advanced Q&A system that incorporates the techniques we've learned:

```python
import streamlit as st
from typing import List, Dict
from langchain.chat_models import ChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.document_loaders import DirectoryLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import LLMChainExtractor

class AdvancedRAGSystem:
    def __init__(self, documents_dir: str):
        self.llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0)
        self.embeddings = OpenAIEmbeddings()
        self.vectorstore = self._create_vectorstore(documents_dir)
        self.retriever = self._create_advanced_retriever()
        self.qa_chain = self._create_qa_chain()
    
    def _create_vectorstore(self, documents_dir: str):
        loader = DirectoryLoader(documents_dir, glob="**/*.txt")
        documents = loader.load()
        text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
        texts = text_splitter.split_documents(documents)
        return FAISS.from_documents(texts, self.embeddings)
    
    def _create_advanced_retriever(self):
        base_retriever = self.vectorstore.as_retriever(search_kwargs={"k": 10})
        compressor = LLMChainExtractor.from_llm(self.llm)
        return ContextualCompressionRetriever(
            base_compressor=compressor,
            base_retriever=base_retriever
        )
    
    def _create_qa_chain(self):
        prompt_template = """Use the following pieces of context to answer the question at the end. 
        If you don't know the answer, just say that you don't know, don't try to make up an answer.
        Always provide a brief explanation of your reasoning.

        {context}

        Question: {question}
        Answer:"""
        PROMPT = PromptTemplate(
            template=prompt_template, input_variables=["context", "question"]
        )
        
        return RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",
            retriever=self.retriever,
            chain_type_kwargs={"prompt": PROMPT}
        )
    
    def answer_question(self, question: str):
        return self.qa_chain.run(question)

# Streamlit app
st.title("Advanced Q&A System with RAG")

@st.cache(allow_output_mutation=True)
def load_rag_system():
    return AdvancedRAGSystem("./documents")

rag_system = load_rag_system()

question = st.text_input("Enter your question:")
if question:
    answer = rag_system.answer_question(question)
    st.write("Answer:", answer)

    st.subheader("Relevant Documents:")
    relevant_docs = rag_system.retriever.get_relevant_documents(question)
    for i, doc in enumerate(relevant_docs[:3], 1):
        st.write(f"{i}. {doc.page_content[:200]}...")
        st.write(f"   Source: {doc.metadata['source']}")
```

To run this Streamlit app, save it as `advanced_rag_app.py` and run:

```
streamlit run advanced_rag_app.py
```

### 8. Summary and Next Steps

In this lesson, we covered:
- The basics of retrieval systems and Retrieval-Augmented Generation (RAG)
- Implementing basic retrieval and RAG applications using LangChain
- Optimizing retrieval performance with techniques like hybrid search, re-ranking, and query expansion
- Cross-platform deployment considerations for RAG systems
- Evaluating and improving the quality of RAG systems
- Building an advanced Q&A system with RAG as a hands-on project

To further your understanding, try the following exercises:

1. Implement a domain-specific RAG system for a particular field (e.g., medical, legal, or financial)
2. Experiment with different retrieval methods and compare their performance
3. Develop a method to automatically update the knowledge base of your RAG system
4. Create a RAG system that can handle multi-modal inputs (text and images)
5. Implement a conversational interface for your RAG system to maintain context over multiple turns

In the next lesson, we'll explore Agents and Tools in LangChain, which will allow us to create even more sophisticated AI applications that can reason, plan, and interact with external systems.

## File Layout

For this lesson, you might organize your files as follows:

```
lesson_10/
│
├── retrievers/
│   ├── __init__.py
│   ├── basic_retriever.py
│   ├── hybrid_retriever.py
│   ├── reranking_retriever.py
│   └── query_expansion_retriever.py
│
├── rag/
│   ├── __init__.py
│   ├── rag_application.py
│   └── advanced_rag_system.py
│
├── evaluation/
│   ├── __init__.py
│   └── rag_evaluator.py
│
├── deployment/
│   ├── Dockerfile
│   └── rag_app.py
│
├── advanced_rag_app.py
├── requirements.txt
└── README.md
```

- `retrievers/`: Directory containing various retriever implementations
- `rag/`: Directory containing RAG application implementations
- `evaluation/`: Directory for evaluation-related code
- `deployment/`: Directory for deployment-related files
- `advanced_rag_app.py`: Streamlit app for the advanced Q&A system
- `requirements.txt`: List of required Python packages
- `README.md`: Instructions for setting up and running the code examples

Make sure to install the required packages by running `pip install -r requirements.txt` before running the code examples.