# Lesson 14: Evaluation and Testing in LangChain

## Overview

In this lesson, we'll explore the crucial aspects of evaluating and testing LangChain applications. We'll cover various evaluation metrics, benchmarking techniques, and testing strategies to ensure the reliability and effectiveness of your LangChain projects. We'll also dive into using LangSmith for tracing and debugging, and implement cross-platform testing strategies with CI/CD integration.

## Learning Objectives

By the end of this lesson, you will be able to:

1. Understand and implement evaluation metrics for LLM and Chain outputs
2. Create and use benchmarks for LangChain components
3. Implement unit and integration tests for LangChain applications
4. Use LangSmith for tracing and debugging LangChain applications
5. Implement cross-platform testing strategies and integrate with CI/CD pipelines
6. Perform A/B testing on LangChain components

## File Structure

```
lesson-14/
│
├── evaluation/
│   ├── metrics.py
│   └── benchmarks.py
│
├── testing/
│   ├── unit_tests.py
│   └── integration_tests.py
│
├── langsmith/
│   └── tracing_example.py
│
├── ci_cd/
│   ├── github_actions_config.yml
│   └── cross_platform_tests.py
│
├── ab_testing/
│   └── component_comparison.py
│
├── utils/
│   └── test_data_generator.py
│
└── README.md
```

## Lesson Content

### 1. Evaluation Metrics for LLM and Chain Outputs

Evaluating the performance of language models and chains is crucial for ensuring the quality of your LangChain applications. Let's explore some common evaluation metrics and how to implement them.

```python
# evaluation/metrics.py
from typing import List
from sklearn.metrics.pairwise import cosine_similarity
from nltk.translate.bleu_score import sentence_bleu
from rouge import Rouge

def calculate_perplexity(probabilities: List[float]) -> float:
    """
    Calculate the perplexity of a language model output.
    Lower perplexity indicates better performance.
    """
    return 2 ** (-sum(map(log2, probabilities)) / len(probabilities))

def semantic_similarity(text1: str, text2: str, embeddings_model) -> float:
    """
    Calculate the semantic similarity between two texts using cosine similarity of their embeddings.
    """
    embedding1 = embeddings_model.embed_query(text1)
    embedding2 = embeddings_model.embed_query(text2)
    return cosine_similarity([embedding1], [embedding2])[0][0]

def calculate_bleu_score(reference: List[str], candidate: str) -> float:
    """
    Calculate the BLEU score for a candidate text against a reference.
    """
    return sentence_bleu([reference.split()], candidate.split())

def calculate_rouge_scores(reference: str, candidate: str) -> dict:
    """
    Calculate ROUGE scores (ROUGE-1, ROUGE-2, ROUGE-L) for a candidate text against a reference.
    """
    rouge = Rouge()
    scores = rouge.get_scores(candidate, reference)[0]
    return {
        "rouge-1": scores["rouge-1"]["f"],
        "rouge-2": scores["rouge-2"]["f"],
        "rouge-l": scores["rouge-l"]["f"],
    }

# Example usage
from langchain.llms import OpenAI

llm = OpenAI()
reference = "The quick brown fox jumps over the lazy dog."
candidate = llm("Write a sentence about a fox and a dog.")

print(f"BLEU Score: {calculate_bleu_score(reference, candidate)}")
print(f"ROUGE Scores: {calculate_rouge_scores(reference, candidate)}")
```

### 2. Benchmarks for LangChain Components

Creating benchmarks for your LangChain components allows you to compare different models, chains, or configurations to find the best performing setup for your use case.

```python
# evaluation/benchmarks.py
import time
from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

def benchmark_llm(llm, prompts: List[str], num_runs: int = 5) -> dict:
    """
    Benchmark an LLM's performance across multiple prompts and runs.
    """
    results = {
        "total_time": 0,
        "avg_time_per_prompt": 0,
        "outputs": []
    }
    
    start_time = time.time()
    
    for prompt in prompts:
        prompt_results = []
        for _ in range(num_runs):
            run_start = time.time()
            output = llm(prompt)
            run_time = time.time() - run_start
            prompt_results.append({"output": output, "time": run_time})
        
        results["outputs"].append({
            "prompt": prompt,
            "results": prompt_results
        })
    
    total_time = time.time() - start_time
    results["total_time"] = total_time
    results["avg_time_per_prompt"] = total_time / (len(prompts) * num_runs)
    
    return results

# Example usage
llm = OpenAI()
prompts = [
    "Explain the theory of relativity in simple terms.",
    "Write a short story about a time traveler.",
    "Describe the process of photosynthesis."
]

benchmark_results = benchmark_llm(llm, prompts)
print(f"Average time per prompt: {benchmark_results['avg_time_per_prompt']:.2f} seconds")
```

### 3. Unit and Integration Tests

Implementing unit and integration tests for your LangChain applications helps ensure that individual components and the system as a whole are working correctly.

```python
# testing/unit_tests.py
import unittest
from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

class TestLLMChain(unittest.TestCase):
    def setUp(self):
        self.llm = OpenAI()
        self.prompt = PromptTemplate(
            input_variables=["topic"],
            template="Write a one-sentence summary about {topic}."
        )
        self.chain = LLMChain(llm=self.llm, prompt=self.prompt)

    def test_chain_output(self):
        result = self.chain.run(topic="artificial intelligence")
        self.assertIsInstance(result, str)
        self.assertTrue(len(result) > 0)
        self.assertTrue("artificial intelligence" in result.lower())

    def test_chain_multiple_inputs(self):
        results = self.chain.generate([{"topic": "climate change"}, {"topic": "space exploration"}])
        self.assertEqual(len(results.generations), 2)
        for gen in results.generations:
            self.assertTrue(len(gen) > 0)

if __name__ == '__main__':
    unittest.main()

# testing/integration_tests.py
import unittest
from langchain.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter

class TestRetrievalQA(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Set up a RetrievalQA chain for testing
        texts = [
            "The capital of France is Paris.",
            "London is the capital of England.",
            "Berlin is the capital of Germany."
        ]
        text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
        docs = text_splitter.create_documents(texts)
        embeddings = OpenAIEmbeddings()
        vectorstore = FAISS.from_documents(docs, embeddings)
        cls.retriever = vectorstore.as_retriever()
        cls.llm = OpenAI()
        cls.qa_chain = RetrievalQA.from_chain_type(cls.llm, retriever=cls.retriever)

    def test_qa_chain(self):
        query = "What is the capital of France?"
        result = self.qa_chain.run(query)
        self.assertIn("Paris", result)

    def test_qa_chain_unknown_info(self):
        query = "What is the capital of Spain?"
        result = self.qa_chain.run(query)
        self.assertNotIn("Madrid", result)  # Since we didn't provide this information

if __name__ == '__main__':
    unittest.main()
```

### 4. Using LangSmith for Tracing and Debugging

LangSmith is a powerful tool for tracing and debugging LangChain applications. It allows you to visualize the execution of your chains and identify performance bottlenecks or errors.

```python
# langsmith/tracing_example.py
import os
from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.callbacks import LangChainTracer
from langchain.callbacks.manager import CallbackManager

# Set up LangSmith
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_ENDPOINT"] = "https://api.smith.langchain.com"
os.environ["LANGCHAIN_API_KEY"] = "your-api-key"  # Replace with your actual API key

tracer = LangChainTracer()
callback_manager = CallbackManager([tracer])

# Create a chain with tracing
llm = OpenAI(temperature=0, callback_manager=callback_manager)
prompt = PromptTemplate(
    input_variables=["product"],
    template="What is a good name for a company that makes {product}?",
)
chain = LLMChain(llm=llm, prompt=prompt)

# Run the chain
chain.run(product="AI-powered toasters")

print("Check the LangSmith dashboard to see the trace of this run.")
```

### 5. Cross-Platform Testing and CI/CD Integration

Implementing cross-platform testing and integrating with CI/CD pipelines ensures that your LangChain applications work consistently across different environments.

```yaml
# ci_cd/github_actions_config.yml
name: LangChain Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        os: [ubuntu-latest, windows-latest, macOS-latest]
        python-version: [3.7, 3.8, 3.9]

    steps:
    - uses: actions/checkout@v2
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v2
      with:
        python-version: ${{ matrix.python-version }}
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Run tests
      run: |
        python -m unittest discover tests
      env:
        OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
```

```python
# ci_cd/cross_platform_tests.py
import unittest
import platform
from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

class CrossPlatformTests(unittest.TestCase):
    def setUp(self):
        self.llm = OpenAI()
        self.prompt = PromptTemplate(
            input_variables=["topic"],
            template="Write a one-sentence summary about {topic}."
        )
        self.chain = LLMChain(llm=self.llm, prompt=self.prompt)

    def test_chain_output_cross_platform(self):
        result = self.chain.run(topic="cross-platform development")
        self.assertIsInstance(result, str)
        self.assertTrue(len(result) > 0)
        
        # Platform-specific assertions
        if platform.system() == "Windows":
            # Windows-specific test
            self.assertTrue(len(result) < 500)  # Arbitrary limit for demonstration
        elif platform.system() == "Darwin":
            # macOS-specific test
            self.assertFalse(any(char.encode().isalpha() for char in result))
        else:
            # Linux or other platform test
            self.assertTrue(result.istitle())

if __name__ == '__main__':
    unittest.main()
```

### 6. A/B Testing LangChain Components

A/B testing allows you to compare different versions of LangChain components to determine which performs better for your specific use case.

```python
# ab_testing/component_comparison.py
import random
from typing import List, Callable
from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

def run_ab_test(
    component_a: Callable,
    component_b: Callable,
    test_cases: List[dict],
    evaluation_metric: Callable[[str, str], float],
    num_trials: int = 100
) -> dict:
    """
    Run an A/B test comparing two LangChain components.
    """
    results = {
        "a_wins": 0,
        "b_wins": 0,
        "ties": 0,
        "a_total_score": 0,
        "b_total_score": 0
    }
    
    for _ in range(num_trials):
        test_case = random.choice(test_cases)
        result_a = component_a(**test_case)
        result_b = component_b(**test_case)
        
        score_a = evaluation_metric(test_case.get("reference", ""), result_a)
        score_b = evaluation_metric(test_case.get("reference", ""), result_b)
        
        results["a_total_score"] += score_a
        results["b_total_score"] += score_b
        
        if score_a > score_b:
            results["a_wins"] += 1
        elif score_b > score_a:
            results["b_wins"] += 1
        else:
            results["ties"] += 1
    
    results["a_avg_score"] = results["a_total_score"] / num_trials
    results["b_avg_score"] = results["b_total_score"] / num_trials
    
    return results

# Example usage
llm_a = OpenAI(temperature=0)
llm_b = OpenAI(temperature=0.7)

prompt = PromptTemplate(
    input_variables=["topic"],
    template="Write a one-sentence summary about {topic}."
)

chain_a = LLMChain(llm=llm_a, prompt=prompt)
chain_b = LLMChain(llm=llm_b, prompt=prompt)

test_cases = [
    {"topic": "artificial intelligence"},
    {"topic": "climate change"},
    {"topic": "space exploration"},
]

from evaluation.metrics import calculate_rouge_scores

def evaluation_metric(reference: str, candidate: str) -> float:
    return calculate_rouge_scores(reference, candidate)["rouge-l"]

ab_test_results = run_ab_test(
    component_a=chain_a.run,
    component_b=chain_b.run,
    test_cases=test_cases,
    evaluation_metric=evaluation_metric
)

print(f"A/B Test Results: {ab_test_results}")
```

## Exercises

1. Evaluation Metrics Exercise:
   Implement a custom evaluation metric for a specific LangChain use case (e.g., factual accuracy for a QA system).

2. Benchmarking Exercise:
   Create a benchmark to compare the performance of different LLM providers (e.g., OpenAI vs. Anthropic) for a specific task.

3. Testing Exercise:
   Write a comprehensive test suite for a LangChain application you've built in a previous lesson.

4. LangSmith Exercise:
   Use LangSmith to trace and optimize a complex LangChain application, identifying and resolving performance bottlenecks.

5. CI/CD Exercise:
   Set up a GitHub Actions workflow to automatically run tests and deploy a LangChain application.

6. A/B Testing Exercise:
   Conduct an A/B test to compare two different prompt engineering strategies for a specific task.

## Conclusion

In this lesson, we've explored the crucial aspects of evaluating and testing LangChain applications. We've covered various evaluation metrics, benchmarking techniques, and testing strategies to ensure the reliability and effectiveness of your LangChain projects. We've also delved into using LangSmith for tracing and debugging, implemented cross-platform testing strategies with CI/CD integration, and explored A/B testing for LangChain components.

By incorporating these evaluation and testing practices into your LangChain development workflow, you'll be able to build more robust, reliable, and high-performing AI applications. Remember that evaluation and testing should be an ongoing process throughout the development lifecycle, helping you continually improve and refine your LangChain projects.

## Additional Resources

1. [LangChain Documentation on Testing](https://python.langchain.com/docs/guides/testing/)
2. [LangSmith Documentation](https://docs.smith.langchain.com/)
3. [GitHub Actions Documentation](https://docs.github.com/en/actions)
4. [Scientific Papers on LLM Evaluation Metrics](https://arxiv.org/abs/2102.01454)
5. [Best Practices for A/B Testing](https://www.optimizely.com/optimization-glossary/ab-testing/)

In the next lesson, we'll explore advanced LangChain techniques, including custom component creation and performance optimization strategies.

