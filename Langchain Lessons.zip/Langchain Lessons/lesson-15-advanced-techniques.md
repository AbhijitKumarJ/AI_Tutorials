# Lesson 15: Advanced LangChain Techniques

## Overview

In this lesson, we'll dive into advanced LangChain techniques that will allow you to create more sophisticated and efficient AI applications. We'll cover custom component creation, performance optimization strategies, integration with external APIs and services, advanced cross-platform deployment, and handling data privacy and security in LangChain applications.

## Learning Objectives

By the end of this lesson, you will be able to:

1. Create custom Chains and Agents by extending LangChain classes
2. Optimize LangChain applications for performance using caching and batching
3. Integrate external APIs and services with LangChain
4. Implement advanced cross-platform deployment strategies
5. Handle data privacy and security concerns in LangChain applications

## File Structure

```
lesson-15/
│
├── custom_components/
│   ├── custom_chain.py
│   └── custom_agent.py
│
├── optimization/
│   ├── caching.py
│   └── batching.py
│
├── external_integration/
│   └── api_integration.py
│
├── advanced_deployment/
│   ├── docker_config/
│   │   ├── Dockerfile
│   │   └── docker-compose.yml
│   └── kubernetes/
│       └── deployment.yaml
│
├── security/
│   └── data_privacy.py
│
└── README.md
```

## Lesson Content

### 1. Custom Chain and Agent Creation

LangChain allows you to create custom components by extending its base classes. This enables you to build specialized chains and agents tailored to your specific use cases.

#### Custom Chain

```python
# custom_components/custom_chain.py
from langchain.chains import LLMChain
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.callbacks import CallbackManager
from langchain.schema import BaseMemory
from typing import Dict, List, Any

class CustomMemory(BaseMemory):
    chat_history: List[str] = []

    def clear(self):
        self.chat_history = []

    @property
    def memory_variables(self) -> List[str]:
        return ["chat_history"]

    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, str]:
        return {"chat_history": "\n".join(self.chat_history)}

    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, str]) -> None:
        self.chat_history.append(f"Human: {inputs['human_input']}")
        self.chat_history.append(f"AI: {outputs['text']}")

class CustomChain(LLMChain):
    memory: CustomMemory = CustomMemory()

    @property
    def input_keys(self) -> List[str]:
        return ["human_input"]

    def _call(self, inputs: Dict[str, str], run_manager=None) -> Dict[str, str]:
        memory = self.memory.load_memory_variables({})
        prompt = self.prompt.format(human_input=inputs["human_input"], chat_history=memory["chat_history"])
        response = self.llm.generate([prompt], callbacks=run_manager.get_child() if run_manager else None)
        output = response.generations[0][0].text
        self.memory.save_context(inputs, {"text": output})
        return {"text": output}

# Example usage
llm = OpenAI(temperature=0.7)
prompt = PromptTemplate(
    input_variables=["human_input", "chat_history"],
    template="Chat History:\n{chat_history}\nHuman: {human_input}\nAI:"
)

custom_chain = CustomChain(llm=llm, prompt=prompt)

print(custom_chain.run(human_input="Hi, how are you?"))
print(custom_chain.run(human_input="What was my previous message?"))
```

#### Custom Agent

```python
# custom_components/custom_agent.py
from langchain.agents import Agent, AgentExecutor, LLMSingleActionAgent, AgentOutputParser
from langchain.prompts import StringPromptTemplate
from langchain import OpenAI, SerpAPIWrapper, LLMChain
from typing import List, Union
from langchain.schema import AgentAction, AgentFinish
import re

# Custom prompt template
class CustomPromptTemplate(StringPromptTemplate):
    template: str
    tools: List[Tool]

    def format(self, **kwargs) -> str:
        intermediate_steps = kwargs.pop("intermediate_steps")
        thoughts = ""
        for action, observation in intermediate_steps:
            thoughts += f"Action: {action.tool}\nAction Input: {action.tool_input}\nObservation: {observation}\nThought: "
        kwargs["agent_scratchpad"] = thoughts
        kwargs["tools"] = "\n".join([f"{tool.name}: {tool.description}" for tool in self.tools])
        kwargs["tool_names"] = ", ".join([tool.name for tool in self.tools])
        return self.template.format(**kwargs)

# Custom output parser
class CustomOutputParser(AgentOutputParser):
    def parse(self, llm_output: str) -> Union[AgentAction, AgentFinish]:
        if "Final Answer:" in llm_output:
            return AgentFinish(
                return_values={"output": llm_output.split("Final Answer:")[-1].strip()},
                log=llm_output,
            )
        regex = r"Action\s*\d*\s*:(.*?)\nAction\s*\d*\s*Input\s*\d*\s*:[\s]*(.*)"
        match = re.search(regex, llm_output, re.DOTALL)
        if not match:
            raise ValueError(f"Could not parse LLM output: `{llm_output}`")
        action = match.group(1).strip()
        action_input = match.group(2)
        return AgentAction(tool=action, tool_input=action_input.strip(" ").strip('"'), log=llm_output)

# Example usage
llm = OpenAI(temperature=0)
search = SerpAPIWrapper()
tools = [
    Tool(
        name="Search",
        func=search.run,
        description="useful for when you need to answer questions about current events"
    )
]

prompt = CustomPromptTemplate(
    template="You are an AI assistant that helps with research.\n{tools}\n{agent_scratchpad}Human: {human_input}\nAI:",
    tools=tools
)

output_parser = CustomOutputParser()

llm_chain = LLMChain(llm=llm, prompt=prompt)

agent = LLMSingleActionAgent(
    llm_chain=llm_chain,
    output_parser=output_parser,
    stop=["\nObservation:"],
    allowed_tools=[tool.name for tool in tools]
)

agent_executor = AgentExecutor.from_agent_and_tools(agent=agent, tools=tools, verbose=True)

agent_executor.run("What's the latest news about AI?")
```

### 2. Optimizing LangChain Applications

To improve the performance of your LangChain applications, you can implement caching and batching strategies.

#### Caching

```python
# optimization/caching.py
from langchain.cache import InMemoryCache
from langchain.llms import OpenAI
import langchain

langchain.llm_cache = InMemoryCache()

llm = OpenAI(temperature=0.9)

# First call will be slow
print(llm("What is the capital of France?"))

# Second call will be much faster due to caching
print(llm("What is the capital of France?"))

# You can also use other cache implementations, such as SQLiteCache or RedisCache
```

#### Batching

```python
# optimization/batching.py
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

llm = OpenAI(batch_size=5, max_tokens=1024)

prompt = PromptTemplate(
    input_variables=["topic"],
    template="Write a one-sentence summary about {topic}."
)

chain = LLMChain(llm=llm, prompt=prompt)

topics = ["artificial intelligence", "climate change", "quantum computing", "renewable energy", "blockchain"]

# This will be processed in a single API call
results = chain.generate(input_list=[{"topic": topic} for topic in topics])

for result in results.generations:
    print(result[0].text)
```

### 3. Integrating External APIs and Services

LangChain can be extended to work with various external APIs and services, allowing you to create more powerful and versatile applications.

```python
# external_integration/api_integration.py
import requests
from langchain.llms import OpenAI
from langchain.agents import Tool, AgentExecutor, LLMSingleActionAgent
from langchain.prompts import StringPromptTemplate
from langchain import LLMChain

# Example external API (Weather API)
def get_weather(location):
    # This is a mock function. In a real scenario, you would call an actual weather API.
    return f"The weather in {location} is sunny with a temperature of 25°C."

weather_tool = Tool(
    name="Weather",
    func=get_weather,
    description="Useful for getting weather information for a specific location"
)

# Example external service (Database)
class DatabaseService:
    def __init__(self):
        self.db = {}  # Mock database

    def query(self, query):
        # This is a mock function. In a real scenario, you would query an actual database.
        if query.lower().startswith("select"):
            return "Query result: " + str(self.db)
        elif query.lower().startswith("insert"):
            self.db["new_entry"] = "Some data"
            return "Insert successful"
        else:
            return "Invalid query"

db_service = DatabaseService()

db_tool = Tool(
    name="Database",
    func=db_service.query,
    description="Useful for querying or updating the database"
)

# Set up the agent
llm = OpenAI(temperature=0)

tools = [weather_tool, db_tool]

template = """You are an AI assistant that helps with weather information and database operations.
You have access to the following tools:

{tools}

Use the following format:

Question: the input question you must answer
Thought: you should always think about what to do
Action: the action to take, should be one of [{tool_names}]
Action Input: the input to the action
Observation: the result of the action
... (this Thought/Action/Action Input/Observation can repeat N times)
Thought: I now know the final answer
Final Answer: the final answer to the original input question

Question: {input}
{agent_scratchpad}"""

prompt = StringPromptTemplate(
    input_variables=["input", "tools", "tool_names", "agent_scratchpad"],
    template=template
)

llm_chain = LLMChain(llm=llm, prompt=prompt)

agent = LLMSingleActionAgent(
    llm_chain=llm_chain,
    allowed_tools=[tool.name for tool in tools]
)

agent_executor = AgentExecutor.from_agent_and_tools(agent=agent, tools=tools, verbose=True)

# Example usage
agent_executor.run("What's the weather in Paris and can you add this information to the database?")
```

### 4. Advanced Cross-Platform Deployment

For advanced deployment scenarios, you can use containerization and orchestration technologies like Docker and Kubernetes.

#### Docker Configuration

```dockerfile
# advanced_deployment/docker_config/Dockerfile
FROM python:3.9-slim-buster

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["python", "main.py"]
```

```yaml
# advanced_deployment/docker_config/docker-compose.yml
version: '3'
services:
  langchain_app:
    build: .
    ports:
      - "8000:8000"
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
  redis:
    image: "redis:alpine"
```

#### Kubernetes Deployment

```yaml
# advanced_deployment/kubernetes/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: langchain-app
spec:
  replicas: 3
  selector:
    matchLabels:
      app: langchain-app
  template:
    metadata:
      labels:
        app: langchain-app
    spec:
      containers:
      - name: langchain-app
        image: your-docker-registry/langchain-app:latest
        ports:
        - containerPort: 8000
        env:
        - name: OPENAI_API_KEY
          valueFrom:
            secretKeyRef:
              name: openai-api-key
              key: api-key
---
apiVersion: v1
kind: Service
metadata:
  name: langchain-app-service
spec:
  selector:
    app: langchain-app
  ports:
    - protocol: TCP
      port: 80
      targetPort: 8000
  type: LoadBalancer
```

### 5. Handling Data Privacy and Security

When working with LangChain applications, it's crucial to consider data privacy and security, especially when dealing with sensitive information.

```python
# security/data_privacy.py
import os
from cryptography.fernet import Fernet
from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

# Encryption key (in a real scenario, this should be securely stored)
ENCRYPTION_KEY = Fernet.generate_key()
cipher_suite = Fernet(ENCRYPTION_KEY)

def encrypt_data(data):
    return cipher_suite.encrypt(data.encode()).decode()

def decrypt_data(encrypted_data):
    return cipher_suite.decrypt(encrypted_data.encode()).decode()

class PrivacyAwareLLMChain(LLMChain):
    def _call(self, inputs: dict, run_manager=None) -> dict:
        # Encrypt sensitive input data
        encrypted_inputs = {k: encrypt_data(v) for k, v in inputs.items()}
        
        # Process with the LLM
        encrypted_output = super()._call(encrypted_inputs, run_manager)
        
        # Decrypt the output
        decrypted_output = {k: decrypt_data(v) for k, v in encrypted_output.items()}
        
        return decrypted_output

# Example usage
llm = OpenAI(temperature=0.7)
prompt = PromptTemplate(
    input_variables=["name", "age"],
    template="Generate a short bio for {name} who is {age} years old."
)

privacy_aware_chain = PrivacyAwareLLMChain(llm=llm, prompt=prompt)

# Sensitive data
name = "John Doe"
age = "30"

result = privacy_aware_chain.run(name=name, age=age)
print(result)
```

This example demonstrates a basic approach to handling sensitive data by encrypting inputs before processing and decrypting outputs afterward. In a production environment, you would want to use more robust security measures and follow best practices for key management.

## Exercises

1. Custom Component Exercise:
   Create a custom LangChain component that integrates with a specific API or service relevant to your use case.

2. Optimization Exercise:
   Implement a caching strategy for a LangChain application you've built in a previous lesson and measure the performance improvement.

3. External Integration Exercise:
   Build a LangChain agent that uses at least three different external APIs or services to accomplish a complex task.

4. Deployment Exercise:
   Set up a Kubernetes deployment for a LangChain application, including proper secrets management for API keys.

5. Security Exercise:
   Implement a data anonymization technique for a LangChain application that deals with personal information.

## Conclusion

In this lesson, we've explored advanced LangChain techniques that allow you to create more sophisticated, efficient, and secure AI applications. We've covered custom component creation, performance optimization strategies, integration with external APIs and services, advanced cross-platform deployment, and handling data privacy and security in LangChain applications.

These advanced techniques open up new possibilities for building complex, production-ready AI systems using LangChain. By mastering these concepts, you'll be able to tackle more challenging projects and create AI applications that are not only powerful but also performant and secure.

Remember that as you work with these advanced techniques, it's important to consider the specific requirements and constraints of your projects. Always prioritize security, especially when dealing with sensitive data or deploying applications in production environments.

## Additional Resources

1. [LangChain Documentation on Custom Chains](https://python.langchain.com/docs/modules/chains/how_to/custom_chain)
2. [Docker Documentation](https://docs.docker.com/)
3. [Kubernetes Documentation](https://kubernetes.io/docs/home/)
4. [OWASP Top 10 for Machine Learning](https://owasp.org/www-project-machine-learning-security-top-10/)
5. [Best Practices for API Security](https://curity.io/resources/learn/api-security-best-practices/)

In the next and final lesson of this course, we'll put everything we've learned together to build a comprehensive, real-world LangChain application that showcases the full potential of this powerful framework.

