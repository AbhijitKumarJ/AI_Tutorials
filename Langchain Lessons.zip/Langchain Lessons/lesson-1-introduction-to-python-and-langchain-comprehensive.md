# Lesson 1: Introduction to Python and LangChain

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand and use basic Python syntax and concepts
2. Set up a Python development environment on Windows, macOS, and Linux
3. Create and manage virtual environments
4. Install packages using pip
5. Understand the purpose and significance of LangChain in the AI/ML ecosystem
6. Install LangChain and its dependencies
7. Create a simple "Hello, World!" program using LangChain

## 1. Basic Python Syntax and Concepts

Python is a high-level, interpreted programming language known for its simplicity and readability. Let's explore its fundamental concepts:

### 1.1 Variables and Data Types

In Python, you don't need to declare the type of a variable explicitly. The interpreter infers the type based on the value assigned.

```python
# Integer
age = 25
print(f"Age: {age}, Type: {type(age)}")

# Float
height = 1.75
print(f"Height: {height}, Type: {type(height)}")

# String
name = "Alice"
print(f"Name: {name}, Type: {type(name)}")

# Boolean
is_student = True
print(f"Is Student: {is_student}, Type: {type(is_student)}")

# List (mutable sequence)
fruits = ["apple", "banana", "cherry"]
print(f"Fruits: {fruits}, Type: {type(fruits)}")

# Tuple (immutable sequence)
coordinates = (10, 20)
print(f"Coordinates: {coordinates}, Type: {type(coordinates)}")

# Dictionary (key-value pairs)
person = {"name": "Bob", "age": 30}
print(f"Person: {person}, Type: {type(person)}")
```

### 1.2 Control Structures

Control structures allow you to control the flow of your program.

#### If-else statements

```python
age = 18
if age >= 18:
    print("You are an adult")
elif age >= 13:
    print("You are a teenager")
else:
    print("You are a child")
```

#### For loops

For loops are used to iterate over a sequence (like a list, tuple, or string) or other iterable objects.

```python
fruits = ["apple", "banana", "cherry"]
for fruit in fruits:
    print(f"I like {fruit}")

# Using range()
for i in range(5):
    print(f"Number: {i}")
```

#### While loops

While loops repeat as long as a certain condition is true.

```python
count = 0
while count < 5:
    print(f"Count is {count}")
    count += 1
```

### 1.3 Functions

Functions are blocks of reusable code that perform a specific task.

```python
def greet(name):
    """This function greets the person passed in as a parameter"""
    return f"Hello, {name}!"

# Calling the function
message = greet("Alice")
print(message)

# Function with default parameter
def power(base, exponent=2):
    return base ** exponent

print(power(3))    # Output: 9
print(power(3, 3)) # Output: 27
```

### 1.4 List Comprehensions

List comprehensions provide a concise way to create lists.

```python
# Create a list of squares
squares = [x**2 for x in range(10)]
print(squares)

# Create a list of even numbers
evens = [x for x in range(20) if x % 2 == 0]
print(evens)
```

### 1.5 Exception Handling

Exception handling allows you to gracefully handle errors in your code.

```python
try:
    result = 10 / 0
except ZeroDivisionError:
    print("Error: Division by zero!")
finally:
    print("This is always executed")
```

## 2. Setting up a Python Environment

Setting up your Python environment correctly is crucial for a smooth development experience. Let's go through the process for different operating systems:

### 2.1 Windows

1. Download Python:
   - Go to https://www.python.org/downloads/windows/
   - Click on the latest Python 3 release
   - Download the Windows installer (64-bit or 32-bit depending on your system)

2. Install Python:
   - Run the installer
   - Check "Add Python to PATH"
   - Click "Install Now"

3. Verify installation:
   - Open Command Prompt
   - Type `python --version`
   - You should see the Python version number

### 2.2 macOS

macOS comes with Python pre-installed, but it's recommended to install a separate Python for development.

1. Install Homebrew (if not already installed):
   - Open Terminal
   - Run: `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`

2. Install Python using Homebrew:
   - In Terminal, run: `brew install python`

3. Verify installation:
   - In Terminal, type `python3 --version`
   - You should see the Python version number

### 2.3 Linux (Ubuntu)

Most Linux distributions come with Python pre-installed. To ensure you have the latest version:

1. Update package list:
   - Open Terminal
   - Run: `sudo apt update`

2. Install Python:
   - Run: `sudo apt install python3`

3. Verify installation:
   - In Terminal, type `python3 --version`
   - You should see the Python version number

## 3. Virtual Environments and Package Management

Virtual environments allow you to create isolated Python environments for your projects, ensuring that each project can have its own dependencies regardless of what dependencies every other project has.

### 3.1 Creating a Virtual Environment

#### Windows
```
python -m venv myenv
myenv\Scripts\activate
```

#### macOS and Linux
```
python3 -m venv myenv
source myenv/bin/activate
```

When activated, your command prompt should change to indicate the active environment.

### 3.2 Package Management with pip

pip is the package installer for Python. It allows you to install and manage additional packages that are not part of the Python standard library.

Install a package:
```
pip install package_name
```

Install a specific version:
```
pip install package_name==1.0.4
```

Install from a requirements file:
```
pip install -r requirements.txt
```

Create a requirements file:
```
pip freeze > requirements.txt
```

Upgrade a package:
```
pip install --upgrade package_name
```

Uninstall a package:
```
pip uninstall package_name
```

List installed packages:
```
pip list
```

## 4. Introduction to LangChain

LangChain is a framework for developing applications powered by language models. It provides a set of tools and abstractions that simplify the process of building complex, LLM-powered applications.

Key features of LangChain:

1. **Prompt management**: LangChain provides tools for creating, managing, and optimizing prompts for language models.

2. **LLM integration**: It offers a unified interface for working with various LLM providers, making it easy to switch between different models.

3. **Chain and Agent abstractions**: LangChain introduces high-level abstractions like Chains and Agents, which allow for the creation of complex, multi-step LLM applications.

4. **Memory**: It provides mechanisms for adding state to LLM applications, allowing them to remember and use information from previous interactions.

5. **Document loading and processing**: LangChain includes tools for loading documents from various sources and processing them for use with LLMs.

6. **Evaluation**: It offers tools for evaluating the performance of LLM applications.

7. **Extensibility**: LangChain is designed to be easily extensible, allowing developers to add custom components and integrations.

## 5. Installing LangChain and Dependencies

To get started with LangChain, you'll need to install it along with some dependencies. Make sure you're in your activated virtual environment, then run:

```
pip install langchain openai
```

This command installs LangChain and the OpenAI Python client, which we'll use for accessing GPT models.

Note: Depending on your specific use case, you may need to install additional packages. Always refer to the LangChain documentation for the most up-to-date installation instructions.

## 6. Your First LangChain "Hello, World!" Program

Let's create a simple LangChain application that uses an LLM to generate a greeting. Create a new file called `hello_langchain.py` with the following content:

```python
import os
from langchain_openai import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# Set your OpenAI API key
# It's better to set this as an environment variable
os.environ["OPENAI_API_KEY"] = "your-api-key-here"

# Initialize the language model
llm = OpenAI(temperature=0.7)

# Create a prompt template
prompt = PromptTemplate(
    input_variables=["name"],
    template="Create a personalized greeting for {name}."
)

# Create a chain
chain = LLMChain(llm=llm, prompt=prompt)

# Run the chain
name = input("Enter a name: ")
result = chain.run(name=name)
print(result)
```

This script does the following:

1. Imports necessary modules from LangChain and sets up the OpenAI API key.
2. Initializes an OpenAI language model with a temperature of 0.7 (controlling randomness).
3. Creates a PromptTemplate for generating personalized greetings.
4. Sets up an LLMChain that combines the language model and the prompt.
5. Takes a name as input and uses the chain to generate a personalized greeting.

To run the program:

1. Make sure you're in your virtual environment.
2. Replace "your-api-key-here" with your actual OpenAI API key.
3. Run the script: `python hello_langchain.py`

## File Layout

Your project directory should look like this:

```
project_root/
│
├── myenv/                 # Virtual environment
│
├── hello_langchain.py     # Your first LangChain program
│
└── requirements.txt       # List of project dependencies
```

## Exercises

1. **Basic Python**: Write a Python function that takes a list of numbers as input and returns the sum of all even numbers in the list.

2. **Control Structures**: Create a program that prints the Fibonacci sequence up to a given number n. Use a while loop for this exercise.

3. **Virtual Environments**: Create a new virtual environment, activate it, and install the `requests` library. Then, create a Python script that uses `requests` to fetch and print the content of a webpage.

4. **LangChain Prompt Template**: Modify the "Hello, World!" LangChain program to use a more complex prompt template. For example, create a template that generates a short story based on a character name and a setting.

5. **LangChain Chain**: Create a LangChain application that takes a topic as input, generates five facts about that topic using an LLM, and then uses another LLM call to summarize those facts into a brief paragraph.

## Conclusion

In this comprehensive lesson, we covered the basics of Python syntax and concepts, set up a Python development environment, learned about virtual environments and package management, and created our first LangChain application. We explored the fundamental building blocks of Python programming and got a taste of how LangChain can be used to create powerful language model applications.

In the next lesson, we'll dive deeper into Language Models and APIs, exploring how to interact with different LLM providers and understanding the basics of API communication.

