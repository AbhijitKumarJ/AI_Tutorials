# Lesson 3: LangChain Fundamentals: Components and Concepts

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand and utilize LangChain's core components: Prompts, LLMs, and Chains
2. Explain how these components interact within the LangChain framework
3. Use the LangChain Expression Language (LCEL) for component composition
4. Implement basic LangChain patterns and workflows: sequential, parallel, and conditional
5. Recognize and address cross-platform considerations for LangChain usage
6. Appreciate and leverage LangChain's modular architecture and extensibility

## 1. LangChain's Core Components

LangChain is built around three main components that work together to create powerful language model applications: Prompts, Language Models (LLMs), and Chains. Let's explore each of these in detail.

### 1.1 Prompts

Prompts are the input texts that guide the language model's output. In LangChain, prompts are managed using the `PromptTemplate` class, which allows for dynamic prompt generation.

Key features of `PromptTemplate`:
- Defines a template string with placeholders for variables
- Specifies the input variables required for the template
- Provides methods to format the template with actual values

Example:

```python
from langchain_core.prompts import PromptTemplate

# Define a simple prompt template
template = "Write a {adjective} poem about {subject}."
prompt = PromptTemplate(
    input_variables=["adjective", "subject"],
    template=template
)

# Format the prompt with specific values
formatted_prompt = prompt.format(adjective="whimsical", subject="artificial intelligence")
print(formatted_prompt)

# Output: Write a whimsical poem about artificial intelligence.
```

Advanced usage - Few-shot learning with examples:

```python
from langchain_core.prompts import FewShotPromptTemplate, PromptTemplate

# Define an example template
example_template = """
Input: {input}
Output: {output}
"""
example_prompt = PromptTemplate(
    input_variables=["input", "output"],
    template=example_template
)

# Define some examples
examples = [
    {"input": "Happy", "output": "Joyful"},
    {"input": "Sad", "output": "Melancholy"},
]

# Create the few-shot prompt template
few_shot_prompt = FewShotPromptTemplate(
    examples=examples,
    example_prompt=example_prompt,
    prefix="Given the input word, provide a synonym:\n\n",
    suffix="\nInput: {input}\nOutput:",
    input_variables=["input"],
    example_separator="\n\n"
)

# Format the few-shot prompt
print(few_shot_prompt.format(input="Angry"))
```

### 1.2 Language Models (LLMs)

LLMs are the core of LangChain. They process the prompts and generate responses. LangChain supports various LLM providers through a unified interface, allowing for easy switching between different models.

Example using OpenAI:

```python
from langchain_openai import OpenAI
import os

# Set up your API key
os.environ["OPENAI_API_KEY"] = "your-api-key-here"

# Initialize the LLM
llm = OpenAI(temperature=0.7)

# Generate a response
response = llm.invoke("Explain the concept of artificial intelligence in simple terms.")
print(response)
```

LangChain also supports other LLM providers, such as Hugging Face, Cohere, and Anthropic. Here's an example using Hugging Face:

```python
from langchain_community.llms import HuggingFaceHub
import os

# Set up your Hugging Face API token
os.environ["HUGGINGFACEHUB_API_TOKEN"] = "your-api-token-here"

# Initialize the LLM
llm = HuggingFaceHub(repo_id="gpt2", model_kwargs={"temperature": 0.7})

# Generate a response
response = llm.invoke("What is the capital of France?")
print(response)
```

### 1.3 Chains

Chains combine prompts, LLMs, and other components to create more complex workflows. The simplest chain is the `LLMChain`, which combines a prompt and an LLM.

Example:

```python
from langchain_core.prompts import PromptTemplate
from langchain_openai import OpenAI
from langchain.chains import LLMChain

# Initialize the LLM
llm = OpenAI(temperature=0.7)

# Create a prompt template
prompt = PromptTemplate(
    input_variables=["topic"],
    template="Write a short story about {topic}."
)

# Create an LLMChain
story_chain = LLMChain(llm=llm, prompt=prompt)

# Run the chain
result = story_chain.invoke({"topic": "a time-traveling robot"})
print(result["text"])
```

## 2. LangChain Expression Language (LCEL)

LCEL is a declarative way to compose LangChain components. It uses the `|` operator to chain components together, making it easy to create complex workflows.

Key features of LCEL:
- Intuitive composition of components
- Automatic input/output handling between components
- Support for parallel and conditional execution

Example:

```python
from langchain_core.prompts import PromptTemplate
from langchain_openai import OpenAI
from langchain_core.output_parsers import StrOutputParser

# Initialize components
prompt = PromptTemplate.from_template("Write a {adjective} poem about {subject}.")
llm = OpenAI(temperature=0.7)
output_parser = StrOutputParser()

# Compose the chain using LCEL
chain = prompt | llm | output_parser

# Run the chain
result = chain.invoke({"adjective": "whimsical", "subject": "artificial intelligence"})
print(result)
```

## 3. Basic LangChain Patterns and Workflows

LangChain supports various patterns and workflows to create complex applications. Let's explore some common patterns.

### 3.1 Sequential Chains

Sequential chains execute multiple steps in a predefined order.

Example:

```python
from langchain_core.prompts import PromptTemplate
from langchain_openai import OpenAI
from langchain.chains import SimpleSequentialChain, LLMChain

llm = OpenAI(temperature=0.7)

# First chain generates a movie title
title_template = "Generate a title for a {genre} movie."
title_prompt = PromptTemplate(template=title_template, input_variables=["genre"])
title_chain = LLMChain(llm=llm, prompt=title_prompt)

# Second chain generates a synopsis based on the title
synopsis_template = "Write a brief synopsis for a movie titled '{title}'."
synopsis_prompt = PromptTemplate(template=synopsis_template, input_variables=["title"])
synopsis_chain = LLMChain(llm=llm, prompt=synopsis_prompt)

# Combine the chains
movie_chain = SimpleSequentialChain(chains=[title_chain, synopsis_chain], verbose=True)

# Run the chain
result = movie_chain.invoke({"genre": "science fiction"})
print(result)
```

### 3.2 Parallel Chains

Parallel chains execute multiple steps concurrently and combine their results.

Example using LCEL:

```python
from langchain_core.prompts import PromptTemplate
from langchain_openai import OpenAI
from langchain_core.output_parsers import StrOutputParser

llm = OpenAI(temperature=0.7)

# Define two parallel chains
character_chain = (
    PromptTemplate.from_template("Create a character name for a {genre} story.") 
    | llm 
    | StrOutputParser()
)

setting_chain = (
    PromptTemplate.from_template("Describe a setting for a {genre} story.") 
    | llm 
    | StrOutputParser()
)

# Combine the results
def combine_results(inputs):
    character = character_chain.invoke(inputs)
    setting = setting_chain.invoke(inputs)
    return f"Character: {character}\nSetting: {setting}"

parallel_chain = {
    "character": character_chain,
    "setting": setting_chain
} | combine_results

# Run the chain
result = parallel_chain.invoke({"genre": "fantasy"})
print(result)
```

### 3.3 Conditional Chains

Conditional chains use the output of one step to determine the next step.

Example:

```python
from langchain_core.prompts import PromptTemplate
from langchain_openai import OpenAI
from langchain.chains import LLMChain
from langchain_core.output_parsers import StrOutputParser

llm = OpenAI(temperature=0.7)

# Chain to determine the mood of a given text
mood_chain = (
    PromptTemplate.from_template("Determine the mood of this text: {text}\nMood:") 
    | llm 
    | StrOutputParser()
)

# Chain to generate a response based on the mood
response_chain = LLMChain(
    llm=llm,
    prompt=PromptTemplate(
        template="Generate a {mood} response to: {text}",
        input_variables=["mood", "text"]
    )
)

# Conditional chain
def conditional_chain(text):
    mood = mood_chain.invoke({"text": text})
    return response_chain.invoke({"mood": mood, "text": text})

# Run the chain
user_input = "I just won the lottery!"
result = conditional_chain(user_input)
print(result["text"])
```

## 4. Cross-platform Considerations

When using LangChain across different platforms, keep the following considerations in mind:

1. File paths: Use `os.path.join()` for cross-platform compatibility.
2. Environment variables: Use `python-dotenv` to manage environment variables across platforms.
3. Dependencies: Maintain a `requirements.txt` file for consistent package management.
4. API keys: Use environment variables or secure configuration files to store API keys.

Example:

```python
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Use os.path.join for file paths
data_dir = os.path.join("data", "processed")

# Access API keys from environment variables
api_key = os.getenv("OPENAI_API_KEY")

# Use platform-independent file operations
with open(os.path.join(data_dir, "output.txt"), "w") as f:
    f.write("Cross-platform file writing")
```

## 5. LangChain's Modular Architecture and Extensibility

LangChain's modular design allows for easy extension and customization:

1. Custom Prompts: Create your own prompt templates.
2. Custom Chains: Build complex chains by combining existing components.
3. Custom Tools: Develop tools for specific tasks or integrations.
4. Custom Agents: Create specialized agents for particular domains.

Example of a custom prompt template:

```python
from langchain_core.prompts import BasePromptTemplate
from typing import List, Dict

class CustomPromptTemplate(BasePromptTemplate):
    template: str
    input_variables: List[str]

    def format(self, **kwargs) -> str:
        # Custom formatting logic here
        return self.template.format(**kwargs)

    def _get_default_output_parser(self):
        return None  # Or return a custom output parser

custom_prompt = CustomPromptTemplate(
    template="Generate a {adjective} story about {subject} in the style of {author}.",
    input_variables=["adjective", "subject", "author"]
)

formatted_prompt = custom_prompt.format(
    adjective="thrilling",
    subject="time travel",
    author="H.G. Wells"
)
print(formatted_prompt)
```

Example of a custom chain:

```python
from langchain.chains.base import Chain
from typing import Dict, List

class CustomChain(Chain):
    llm: OpenAI
    prompt: PromptTemplate

    @property
    def input_keys(self) -> List[str]:
        return self.prompt.input_variables

    @property
    def output_keys(self) -> List[str]:
        return ["result"]

    def _call(self, inputs: Dict[str, str]) -> Dict[str, str]:
        prompt = self.prompt.format(**inputs)
        response = self.llm(prompt)
        return {"result": response}

# Usage
custom_chain = CustomChain(
    llm=OpenAI(temperature=0.7),
    prompt=PromptTemplate(
        template="Translate the following English text to {language}: {text}",
        input_variables=["language", "text"]
    )
)

result = custom_chain.invoke({"language": "French", "text": "Hello, world!"})
print(result["result"])
```

## Exercises

1. Create a chain that generates a story outline, then expands each point into a paragraph. Use LCEL to compose the chain.

2. Implement a parallel chain that generates both a pro and con argument for a given topic, then combines them into a balanced summary.

3. Build a conditional chain that analyzes the sentiment of a given text, then generates a response based on whether the sentiment is positive, negative, or neutral.

4. Create a custom prompt template that includes both a system message and a user message. Use this template in a chain to generate responses for a specific task (e.g., a customer service chatbot).

5. Develop a simple chatbot using LangChain components. The chatbot should maintain conversation history and use it to generate contextually relevant responses. Implement the chatbot in a way that's easy to run on different platforms.

## Conclusion

In this comprehensive lesson, we explored the fundamental components of LangChain: Prompts, LLMs, and Chains. We learned how to use the LangChain Expression Language (LCEL) to compose these components and create various patterns and workflows. We also discussed cross-platform considerations and LangChain's extensibility, which allows for custom components and complex applications.

Understanding these concepts and patterns is crucial for building sophisticated LLM-powered applications with LangChain. In the next lesson, we'll dive deeper into working with Prompts and Templates, exploring advanced prompting techniques and best practices for prompt management.

