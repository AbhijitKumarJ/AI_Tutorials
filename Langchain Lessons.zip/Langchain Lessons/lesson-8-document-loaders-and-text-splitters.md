# Lesson 8: Document Loaders and Text Splitters in LangChain

## Lesson Overview

In this lesson, we'll explore Document Loaders and Text Splitters in LangChain. These components are crucial for working with various document types and preparing text data for use in language models and other NLP tasks. We'll cover how to load different document formats, split text effectively, and handle cross-platform issues related to file handling and encoding.

## Learning Objectives

By the end of this lesson, you should be able to:

1. Understand the purpose and importance of Document Loaders and Text Splitters in LangChain
2. Use different Document Loaders to load various file formats
3. Implement and customize Text Splitters for different use cases
4. Create custom Document Loaders for specialized file formats
5. Handle cross-platform file and encoding issues
6. Preprocess and clean loaded documents effectively

## Lesson Outline

1. Introduction to Document Loaders and Text Splitters
2. Working with Document Loaders
3. Understanding and Implementing Text Splitters
4. Creating Custom Document Loaders
5. Cross-Platform File Handling and Encoding
6. Document Preprocessing and Cleaning
7. Hands-on Project: Building a Multi-Format Document Processor
8. Summary and Next Steps

## Lesson Content

### 1. Introduction to Document Loaders and Text Splitters

Document Loaders and Text Splitters are essential components in LangChain for working with unstructured data:

- **Document Loaders**: These components load data from various sources and formats into a common Document structure that LangChain can work with.
- **Text Splitters**: These components split long texts into smaller, more manageable chunks that can be processed by language models or other NLP components.

**Key Concepts:**
- Unstructured data handling
- Document representation in LangChain
- Text chunking for efficient processing

### 2. Working with Document Loaders

LangChain provides a wide range of document loaders for different file formats and data sources. Let's explore some common ones:

```python
from langchain.document_loaders import (
    TextLoader,
    PDFMinerLoader,
    CSVLoader,
    JSONLoader,
    UnstructuredHTMLLoader
)
from langchain.document_loaders.base import Document

# Loading a text file
text_loader = TextLoader("sample.txt")
text_docs = text_loader.load()

# Loading a PDF file
pdf_loader = PDFMinerLoader("sample.pdf")
pdf_docs = pdf_loader.load()

# Loading a CSV file
csv_loader = CSVLoader("sample.csv")
csv_docs = csv_loader.load()

# Loading a JSON file
json_loader = JSONLoader("sample.json", jq_schema='.[]')
json_docs = json_loader.load()

# Loading an HTML file
html_loader = UnstructuredHTMLLoader("sample.html")
html_docs = html_loader.load()

# Printing the first document from each loader
for docs, name in [(text_docs, "Text"), (pdf_docs, "PDF"), (csv_docs, "CSV"), (json_docs, "JSON"), (html_docs, "HTML")]:
    print(f"{name} Document:")
    print(docs[0].page_content[:100])  # Print first 100 characters
    print(docs[0].metadata)
    print()
```

### 3. Understanding and Implementing Text Splitters

Text Splitters are used to break down large documents into smaller chunks. This is crucial for working with models that have input size limitations. LangChain offers various text splitting strategies:

```python
from langchain.text_splitter import (
    CharacterTextSplitter,
    RecursiveCharacterTextSplitter,
    TokenTextSplitter
)

# Sample text
long_text = """
LangChain is a framework for developing applications powered by language models... 
[imagine this is a very long text]
"""

# Character Text Splitter
char_splitter = CharacterTextSplitter(chunk_size=100, chunk_overlap=20)
char_split_docs = char_splitter.split_text(long_text)

# Recursive Character Text Splitter
recursive_splitter = RecursiveCharacterTextSplitter(chunk_size=100, chunk_overlap=20)
recursive_split_docs = recursive_splitter.split_text(long_text)

# Token Text Splitter
token_splitter = TokenTextSplitter(chunk_size=100, chunk_overlap=20)
token_split_docs = token_splitter.split_text(long_text)

# Comparing results
for split_docs, name in [(char_split_docs, "Character"), (recursive_split_docs, "Recursive"), (token_split_docs, "Token")]:
    print(f"{name} Splitter:")
    print(f"Number of chunks: {len(split_docs)}")
    print(f"First chunk: {split_docs[0][:50]}...")
    print()
```

### 4. Creating Custom Document Loaders

For specialized file formats or data sources, you may need to create custom document loaders. Here's an example of a custom loader for a hypothetical file format:

```python
from langchain.document_loaders.base import BaseLoader

class CustomFormatLoader(BaseLoader):
    def __init__(self, file_path):
        self.file_path = file_path
    
    def load(self):
        with open(self.file_path, 'r') as file:
            # Implement custom parsing logic here
            content = file.read()
            # For this example, let's assume the format is "KEY: VALUE" pairs
            parsed_content = {}
            for line in content.split('\n'):
                if ':' in line:
                    key, value = line.split(':', 1)
                    parsed_content[key.strip()] = value.strip()
        
        # Create a Document with the parsed content
        return [Document(
            page_content='\n'.join(f"{k}: {v}" for k, v in parsed_content.items()),
            metadata={"source": self.file_path}
        )]

# Usage
custom_loader = CustomFormatLoader("custom_format.txt")
custom_docs = custom_loader.load()
print(custom_docs[0].page_content)
```

### 5. Cross-Platform File Handling and Encoding

When working with files across different platforms, it's important to handle file paths and encodings correctly:

```python
import os
import sys

def load_file_cross_platform(file_path, encoding='utf-8'):
    # Normalize file path for the current operating system
    normalized_path = os.path.normpath(file_path)
    
    try:
        with open(normalized_path, 'r', encoding=encoding) as file:
            content = file.read()
        return content
    except UnicodeDecodeError:
        print(f"Error: Unable to decode file with {encoding} encoding.")
        print("Trying to detect encoding...")
        import chardet
        with open(normalized_path, 'rb') as file:
            raw_data = file.read()
        detected = chardet.detect(raw_data)
        print(f"Detected encoding: {detected['encoding']}")
        with open(normalized_path, 'r', encoding=detected['encoding']) as file:
            content = file.read()
        return content

# Usage
file_content = load_file_cross_platform("sample.txt")
print(file_content[:100])  # Print first 100 characters

# Platform-specific considerations
if sys.platform.startswith('win'):
    print("Running on Windows")
    # Windows-specific code
elif sys.platform.startswith('linux'):
    print("Running on Linux")
    # Linux-specific code
elif sys.platform.startswith('darwin'):
    print("Running on macOS")
    # macOS-specific code
```

### 6. Document Preprocessing and Cleaning

Before using loaded documents in NLP tasks, it's often necessary to preprocess and clean the text:

```python
import re
from bs4 import BeautifulSoup

def preprocess_text(text):
    # Remove HTML tags
    text = BeautifulSoup(text, "html.parser").get_text()
    
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    
    # Remove special characters and digits
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    
    # Convert to lowercase
    text = text.lower()
    
    return text

# Example usage
raw_text = """
<p>This is some <b>sample text</b> with HTML tags, special characters (@#$%),
and numbers (123). It also has    extra    spaces.</p>
"""

cleaned_text = preprocess_text(raw_text)
print("Original text:")
print(raw_text)
print("\nCleaned text:")
print(cleaned_text)
```

### 7. Hands-on Project: Building a Multi-Format Document Processor

Let's create a program that can process multiple document formats, split them into chunks, and prepare them for further NLP tasks:

```python
import os
from langchain.document_loaders import (
    TextLoader,
    PDFMinerLoader,
    CSVLoader,
    UnstructuredHTMLLoader
)
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document

class MultiFormatDocumentProcessor:
    def __init__(self, directory):
        self.directory = directory
        self.documents = []
        self.chunks = []
    
    def load_documents(self):
        for filename in os.listdir(self.directory):
            file_path = os.path.join(self.directory, filename)
            if filename.endswith('.txt'):
                loader = TextLoader(file_path)
            elif filename.endswith('.pdf'):
                loader = PDFMinerLoader(file_path)
            elif filename.endswith('.csv'):
                loader = CSVLoader(file_path)
            elif filename.endswith('.html'):
                loader = UnstructuredHTMLLoader(file_path)
            else:
                print(f"Unsupported file format: {filename}")
                continue
            
            self.documents.extend(loader.load())
    
    def split_documents(self, chunk_size=1000, chunk_overlap=200):
        splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        for doc in self.documents:
            self.chunks.extend(splitter.split_text(doc.page_content))
    
    def preprocess_chunks(self):
        self.chunks = [preprocess_text(chunk) for chunk in self.chunks]
    
    def process(self):
        self.load_documents()
        self.split_documents()
        self.preprocess_chunks()
        return self.chunks

# Usage
processor = MultiFormatDocumentProcessor("documents_directory")
processed_chunks = processor.process()

print(f"Processed {len(processed_chunks)} chunks")
print("Sample chunks:")
for chunk in processed_chunks[:3]:
    print(chunk[:100])
    print("---")
```

### 8. Summary and Next Steps

In this lesson, we covered:
- The purpose and importance of Document Loaders and Text Splitters
- How to use various Document Loaders for different file formats
- Implementing and customizing Text Splitters
- Creating custom Document Loaders for specialized formats
- Handling cross-platform file and encoding issues
- Preprocessing and cleaning loaded documents
- A hands-on project to build a multi-format document processor

To further your understanding, try the following exercises:

1. Implement a Document Loader for a file format not covered in this lesson (e.g., XML, EPUB)
2. Experiment with different Text Splitter settings and analyze their impact on downstream NLP tasks
3. Create a preprocessing pipeline that includes advanced NLP techniques like tokenization, stemming, or named entity recognition
4. Build a simple search engine using the processed documents and implement keyword-based retrieval

In the next lesson, we'll explore Vectorstores and Embeddings, which are crucial for efficient similarity search and retrieval in large document collections.

## File Layout

For this lesson, you might organize your files as follows:

```
lesson_8/
│
├── document_loaders/
│   ├── __init__.py
│   ├── text_loader.py
│   ├── pdf_loader.py
│   ├── csv_loader.py
│   ├── json_loader.py
│   └── html_loader.py
│
├── text_splitters/
│   ├── __init__.py
│   ├── character_splitter.py
│   ├── recursive_splitter.py
│   └── token_splitter.py
│
├── utils/
│   ├── __init__.py
│   ├── file_handling.py
│   └── text_preprocessing.py
│
├── custom_loader.py
├── multi_format_processor.py
├── main.py
├── requirements.txt
└── README.md
```

- `document_loaders/`: Directory containing various document loader implementations
- `text_splitters/`: Directory containing text splitter implementations
- `utils/`: Directory for utility functions like file handling and text preprocessing
- `custom_loader.py`: Example of a custom document loader
- `multi_format_processor.py`: The hands-on project implementation
- `main.py`: Script to run the multi-format document processor
- `requirements.txt`: List of required Python packages
- `README.md`: Instructions for setting up and running the code examples

Make sure to install the required packages by running `pip install -r requirements.txt` before running the code examples.

