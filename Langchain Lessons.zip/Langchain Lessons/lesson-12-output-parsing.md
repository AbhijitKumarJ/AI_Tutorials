# Lesson 12: Output Parsing and Structured Outputs

## Overview

In this lesson, we'll explore output parsing and structured outputs in LangChain. We'll learn how to extract meaningful, structured data from the raw text responses of language models, making it easier to integrate LLM outputs into our applications.

## Learning Objectives

By the end of this lesson, you will be able to:

1. Understand the importance of output parsing in LLM applications
2. Use various OutputParsers in LangChain
3. Create structured outputs from LLM responses
4. Implement error handling and validation for parsed outputs
5. Work with cross-platform serialization and deserialization of structured data
6. Integrate parsed outputs with downstream systems and databases

## File Structure

```
lesson-12/
│
├── examples/
│   ├── json_parser_example.py
│   ├── pydantic_parser_example.py
│   ├── list_parser_example.py
│   ├── custom_parser_example.py
│   └── structured_output_chain.py
│
├── exercises/
│   ├── basic_parsing_exercise.py
│   ├── error_handling_exercise.py
│   └── integration_exercise.py
│
├── utils/
│   ├── parser_utils.py
│   └── database_connector.py
│
└── README.md
```

## Lesson Content

### 1. Introduction to Output Parsing

Output parsing is a crucial step in working with language models. While LLMs are powerful in generating human-like text, we often need to extract specific information or structure from their outputs for use in our applications.

LangChain provides various OutputParsers that help us convert the raw text output from an LLM into structured data formats like JSON, lists, or custom objects.

### 2. Using OutputParsers in LangChain

LangChain offers several built-in OutputParsers:

a. StrOutputParser
b. JsonOutputParser
c. PydanticOutputParser
d. CommaSeparatedListOutputParser
e. DatetimeOutputParser

Let's look at some examples:

#### a. StrOutputParser

The simplest parser that just returns the raw string output.

```python
# examples/json_parser_example.py
from langchain.output_parsers import StrOutputParser
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI

llm = OpenAI(temperature=0)
prompt = PromptTemplate.from_template("Tell me a short joke about {topic}")
chain = prompt | llm | StrOutputParser()

response = chain.invoke({"topic": "programming"})
print(response)
```

#### b. JsonOutputParser

Parses the output into a JSON object.

```python
# examples/json_parser_example.py
from langchain.output_parsers import JsonOutputParser
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI

llm = OpenAI(temperature=0)
prompt = PromptTemplate.from_template(
    "Generate a JSON object with keys 'name' and 'age' for a fictional character."
)
chain = prompt | llm | JsonOutputParser()

response = chain.invoke({})
print(response)
```

#### c. PydanticOutputParser

Parses the output into a Pydantic model.

```python
# examples/pydantic_parser_example.py
from langchain.output_parsers import PydanticOutputParser
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI
from pydantic import BaseModel, Field

class Person(BaseModel):
    name: str = Field(description="The person's name")
    age: int = Field(description="The person's age")
    city: str = Field(description="The city where the person lives")

parser = PydanticOutputParser(pydantic_object=Person)

llm = OpenAI(temperature=0)
prompt = PromptTemplate.from_template(
    "Generate details for a fictional person.\n{format_instructions}\n"
)
chain = prompt.format_prompt(format_instructions=parser.get_format_instructions()) | llm | parser

response = chain.invoke({})
print(response)
```

### 3. Creating Structured Outputs from LLM Responses

To create structured outputs, we need to:

1. Define the desired output structure
2. Create a prompt that instructs the LLM to generate output in that structure
3. Use an appropriate OutputParser to extract the structured data

Here's an example of creating a structured output chain:

```python
# examples/structured_output_chain.py
from langchain.output_parsers import PydanticOutputParser
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI
from pydantic import BaseModel, Field
from typing import List

class Movie(BaseModel):
    title: str = Field(description="The title of the movie")
    director: str = Field(description="The director of the movie")
    year: int = Field(description="The year the movie was released")
    genres: List[str] = Field(description="A list of genres for the movie")

parser = PydanticOutputParser(pydantic_object=Movie)

llm = OpenAI(temperature=0.7)
prompt = PromptTemplate.from_template(
    "Generate details for a fictional movie.\n{format_instructions}\n"
)
chain = prompt.format_prompt(format_instructions=parser.get_format_instructions()) | llm | parser

response = chain.invoke({})
print(response)
```

### 4. Implementing Error Handling and Validation

Error handling is crucial when working with parsed outputs. Here are some strategies:

1. Use try-except blocks to catch parsing errors
2. Implement retry logic for failed parses
3. Validate parsed data against expected schemas

Example:

```python
# utils/parser_utils.py
from langchain.output_parsers import PydanticOutputParser
from pydantic import ValidationError

def safe_parse(parser: PydanticOutputParser, text: str, max_retries: int = 3):
    for i in range(max_retries):
        try:
            return parser.parse(text)
        except ValidationError as e:
            if i == max_retries - 1:
                raise e
            print(f"Parsing failed (attempt {i+1}/{max_retries}). Retrying...")
    raise Exception("Parsing failed after maximum retries")
```

### 5. Cross-platform Serialization and Deserialization

When working with structured data across different platforms, it's important to use serialization formats that are widely supported. JSON is a popular choice for its simplicity and cross-platform compatibility.

For more complex data structures, you might consider using Protocol Buffers or Apache Avro for efficient binary serialization.

Example of JSON serialization/deserialization:

```python
# utils/parser_utils.py
import json

def serialize_to_json(data):
    return json.dumps(data)

def deserialize_from_json(json_str):
    return json.loads(json_str)
```

### 6. Integrating Parsed Outputs with Downstream Systems

Parsed outputs can be easily integrated with databases, APIs, or other parts of your application. Here's an example of saving parsed data to a database:

```python
# utils/database_connector.py
import sqlite3
from pydantic import BaseModel

def save_to_database(data: BaseModel, table_name: str):
    conn = sqlite3.connect('example.db')
    cursor = conn.cursor()
    
    # Create table if it doesn't exist
    columns = ', '.join([f"{field} TEXT" for field in data.__fields__])
    cursor.execute(f"CREATE TABLE IF NOT EXISTS {table_name} ({columns})")
    
    # Insert data
    placeholders = ', '.join(['?' for _ in data.__fields__])
    values = tuple(getattr(data, field) for field in data.__fields__)
    cursor.execute(f"INSERT INTO {table_name} VALUES ({placeholders})", values)
    
    conn.commit()
    conn.close()
```

## Exercises

1. Basic Parsing Exercise:
   Create a chain that generates a list of todo items and parses it into a Python list.

2. Error Handling Exercise:
   Implement a robust parsing system that can handle and recover from common LLM output errors.

3. Integration Exercise:
   Build a chain that generates structured data about books, parses the output, and saves it to a SQLite database.

## Conclusion

Output parsing and structured outputs are essential for building robust LLM-powered applications. They allow us to bridge the gap between the flexible, text-based outputs of language models and the structured data our applications often require. By mastering these techniques, you'll be able to create more reliable and integrated AI systems.

## Additional Resources

1. LangChain OutputParsers Documentation
2. Pydantic Documentation
3. JSON Schema Specification
4. SQLite Python Tutorial

In the next lesson, we'll explore how to use LangChain for specific use cases, building on the output parsing techniques we've learned here.
