# Lesson 9: Vectorstores and Embeddings in LangChain

## Lesson Overview

In this lesson, we'll explore Vectorstores and Embeddings in LangChain. These components are crucial for efficient similarity search and retrieval in large document collections. We'll cover the concept of vector embeddings, how to use different vectorstores, and how to optimize their performance for various applications.

## Learning Objectives

By the end of this lesson, you should be able to:

1. Understand vector embeddings and their applications in NLP
2. Use different embedding models to create vector representations of text
3. Set up and use various vectorstores (FAISS, Chroma, Pinecone, etc.)
4. Implement efficient similarity search using vectorstores
5. Handle cross-platform deployment of vectorstore solutions
6. Optimize vectorstore performance through indexing and querying strategies

## Lesson Outline

1. Introduction to Vector Embeddings
2. Working with Embedding Models
3. Understanding and Implementing Vectorstores
4. Similarity Search and Retrieval
5. Cross-Platform Deployment of Vectorstores
6. Optimizing Vectorstore Performance
7. Hands-on Project: Building a Semantic Search Engine
8. Summary and Next Steps

## Lesson Content

### 1. Introduction to Vector Embeddings

Vector embeddings are numerical representations of text that capture semantic meaning. They allow us to perform mathematical operations on text, enabling tasks like similarity comparison and clustering.

**Key Concepts:**
- Dense vs. sparse vector representations
- Dimensionality of embeddings
- Semantic similarity in vector space

### 2. Working with Embedding Models

LangChain supports various embedding models. Let's explore how to use them:

```python
from langchain.embeddings import OpenAIEmbeddings, HuggingFaceEmbeddings
from langchain.embeddings.base import Embeddings

# OpenAI Embeddings
openai_embeddings = OpenAIEmbeddings()

# HuggingFace Embeddings
huggingface_embeddings = HuggingFaceEmbeddings()

# Function to demonstrate embedding generation
def generate_embeddings(text: str, embedding_model: Embeddings):
    embedding = embedding_model.embed_query(text)
    print(f"Embedding dimension: {len(embedding)}")
    print(f"First 5 values: {embedding[:5]}")

# Example usage
sample_text = "LangChain is a powerful framework for building AI applications."

print("OpenAI Embeddings:")
generate_embeddings(sample_text, openai_embeddings)

print("\nHuggingFace Embeddings:")
generate_embeddings(sample_text, huggingface_embeddings)
```

### 3. Understanding and Implementing Vectorstores

Vectorstores are databases designed to store and efficiently query vector embeddings. LangChain supports several vectorstore implementations:

```python
from langchain.vectorstores import FAISS, Chroma, Pinecone
from langchain.document_loaders import TextLoader
from langchain.text_splitter import CharacterTextSplitter

# Load and split a sample document
loader = TextLoader("sample_document.txt")
documents = loader.load()
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
texts = text_splitter.split_documents(documents)

# Initialize embedding model
embeddings = OpenAIEmbeddings()

# FAISS Vectorstore
faiss_vectorstore = FAISS.from_documents(texts, embeddings)

# Chroma Vectorstore
chroma_vectorstore = Chroma.from_documents(texts, embeddings)

# Pinecone Vectorstore (requires Pinecone account and API key)
import pinecone
pinecone.init(api_key="your-api-key", environment="your-environment")
pinecone_vectorstore = Pinecone.from_documents(texts, embeddings, index_name="langchain-demo")

# Save and load vectorstores (example with FAISS)
faiss_vectorstore.save_local("faiss_index")
loaded_vectorstore = FAISS.load_local("faiss_index", embeddings)
```

### 4. Similarity Search and Retrieval

Once we have a vectorstore, we can perform similarity searches:

```python
def perform_similarity_search(vectorstore, query: str, k: int = 5):
    results = vectorstore.similarity_search(query, k=k)
    print(f"Top {k} results for query: '{query}'")
    for i, doc in enumerate(results, 1):
        print(f"{i}. {doc.page_content[:100]}...")

# Example usage
query = "What is LangChain used for?"
perform_similarity_search(faiss_vectorstore, query)
```

### 5. Cross-Platform Deployment of Vectorstores

When deploying vectorstore solutions across different platforms, consider the following:

1. Cloud vs. Local deployment
2. Scalability and performance requirements
3. Data privacy and security concerns

Here's an example of a flexible vectorstore factory that can be used across platforms:

```python
from typing import Dict, Any
from langchain.vectorstores.base import VectorStore

class VectorstoreFactory:
    @staticmethod
    def create_vectorstore(store_type: str, texts: list, embeddings: Embeddings, **kwargs) -> VectorStore:
        if store_type == "faiss":
            return FAISS.from_documents(texts, embeddings, **kwargs)
        elif store_type == "chroma":
            return Chroma.from_documents(texts, embeddings, **kwargs)
        elif store_type == "pinecone":
            return Pinecone.from_documents(texts, embeddings, **kwargs)
        else:
            raise ValueError(f"Unsupported vectorstore type: {store_type}")

# Usage
config: Dict[str, Any] = {
    "store_type": "faiss",
    "persist_directory": "./vectorstore_data",
}

vectorstore = VectorstoreFactory.create_vectorstore(
    config["store_type"],
    texts,
    embeddings,
    persist_directory=config["persist_directory"]
)
```

### 6. Optimizing Vectorstore Performance

To optimize vectorstore performance, consider the following strategies:

1. Indexing techniques (e.g., hierarchical navigable small world for FAISS)
2. Approximate Nearest Neighbors (ANN) algorithms
3. Caching and precomputation
4. Batch processing for large-scale operations

Example of using HNSW index with FAISS:

```python
import faiss

def create_optimized_faiss_index(vectors, dimension):
    index = faiss.IndexHNSWFlat(dimension, 32)  # 32 is the number of neighbors for HNSW
    index.hnsw.efConstruction = 200  # Increase for higher accuracy, but slower indexing
    index.hnsw.efSearch = 128  # Increase for higher accuracy, but slower search
    index.add(vectors)
    return index

# Usage in LangChain
optimized_faiss_vectorstore = FAISS(embeddings.embed_query, create_optimized_faiss_index(embedded_vectors, dimension))
```

### 7. Hands-on Project: Building a Semantic Search Engine

Let's create a semantic search engine using LangChain's vectorstore capabilities:

```python
import streamlit as st
from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.document_loaders import DirectoryLoader
from langchain.text_splitter import CharacterTextSplitter

class SemanticSearchEngine:
    def __init__(self, documents_dir: str):
        self.embeddings = OpenAIEmbeddings()
        self.vectorstore = self._create_vectorstore(documents_dir)
    
    def _create_vectorstore(self, documents_dir: str):
        loader = DirectoryLoader(documents_dir, glob="**/*.txt")
        documents = loader.load()
        text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
        texts = text_splitter.split_documents(documents)
        return FAISS.from_documents(texts, self.embeddings)
    
    def search(self, query: str, k: int = 5):
        return self.vectorstore.similarity_search(query, k=k)

# Streamlit app
st.title("Semantic Search Engine")

# Initialize search engine
@st.cache(allow_output_mutation=True)
def load_search_engine():
    return SemanticSearchEngine("./documents")

search_engine = load_search_engine()

# Search interface
query = st.text_input("Enter your search query:")
if query:
    results = search_engine.search(query)
    st.subheader("Search Results:")
    for i, doc in enumerate(results, 1):
        st.write(f"{i}. {doc.page_content[:200]}...")
        st.write(f"   Source: {doc.metadata['source']}")
        st.write("---")
```

To run this Streamlit app, save it as `semantic_search_app.py` and run:

```
streamlit run semantic_search_app.py
```

### 8. Summary and Next Steps

In this lesson, we covered:
- The concept of vector embeddings and their importance in NLP
- How to use different embedding models in LangChain
- Setting up and using various vectorstores (FAISS, Chroma, Pinecone)
- Implementing similarity search and retrieval
- Cross-platform deployment considerations for vectorstores
- Optimizing vectorstore performance
- Building a semantic search engine as a hands-on project

To further your understanding, try the following exercises:

1. Experiment with different embedding models and compare their performance in similarity search tasks
2. Implement a multi-modal vectorstore that can handle both text and image embeddings
3. Create a document clustering system using vectorstore and K-means algorithm
4. Benchmark the performance of different vectorstores on a large dataset and optimize for speed and accuracy

In the next lesson, we'll explore Retrieval and Retrieval-Augmented Generation (RAG), building upon the concepts we've learned about vectorstores and embeddings.

## File Layout

For this lesson, you might organize your files as follows:

```
lesson_9/
│
├── embeddings/
│   ├── __init__.py
│   ├── openai_embeddings.py
│   └── huggingface_embeddings.py
│
├── vectorstores/
│   ├── __init__.py
│   ├── faiss_store.py
│   ├── chroma_store.py
│   └── pinecone_store.py
│
├── utils/
│   ├── __init__.py
│   ├── text_processing.py
│   └── performance_metrics.py
│
├── semantic_search_engine.py
├── vectorstore_factory.py
├── optimization_examples.py
├── semantic_search_app.py
├── requirements.txt
└── README.md
```

- `embeddings/`: Directory containing embedding model implementations
- `vectorstores/`: Directory containing vectorstore implementations
- `utils/`: Directory for utility functions like text processing and performance metrics
- `semantic_search_engine.py`: Core implementation of the semantic search engine
- `vectorstore_factory.py`: Factory class for creating vectorstores
- `optimization_examples.py`: Examples of vectorstore optimization techniques
- `semantic_search_app.py`: Streamlit app for the semantic search engine
- `requirements.txt`: List of required Python packages
- `README.md`: Instructions for setting up and running the code examples

Make sure to install the required packages by running `pip install -r requirements.txt` before running the code examples.

