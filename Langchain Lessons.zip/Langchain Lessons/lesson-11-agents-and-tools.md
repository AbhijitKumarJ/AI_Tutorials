# Lesson 11: Agents and Tools in LangChain

## Lesson Overview

In this lesson, we'll explore Agents and Tools in LangChain. These components allow us to create AI systems that can reason, plan, and interact with external resources to solve complex tasks. We'll cover different types of agents, how to create custom tools, and how to implement advanced agent architectures like ReAct.

## Learning Objectives

By the end of this lesson, you should be able to:

1. Understand the concept of Agents and their role in LangChain
2. Implement different types of LangChain Agents
3. Create custom tools for Agents to use
4. Implement ReAct agents for advanced reasoning and acting
5. Debug and monitor Agent behavior
6. Deploy Agent-based systems across different platforms

## Lesson Outline

1. Introduction to Agents and Tools
2. Understanding LangChain Agents
3. Creating Custom Tools
4. Implementing ReAct Agents
5. Debugging and Monitoring Agents
6. Cross-Platform Deployment of Agent Systems
7. Hands-on Project: Building a Multi-Tool Research Assistant
8. Summary and Next Steps

## Lesson Content

### 1. Introduction to Agents and Tools

Agents in LangChain are AI systems that use language models to determine which actions to take and in what order. Tools are functions that agents can use to interact with external systems or perform specific tasks.

**Key Concepts:**
- Agent architecture
- Decision-making in AI systems
- Tool usage and integration

### 2. Understanding LangChain Agents

LangChain provides several types of agents. Let's explore some of them:

```python
from langchain.agents import load_tools
from langchain.agents import initialize_agent
from langchain.agents import AgentType
from langchain.llms import OpenAI

# Initialize the language model
llm = OpenAI(temperature=0)

# Load some tools for the agent to use
tools = load_tools(["serpapi", "llm-math"], llm=llm)

# Initialize an agent with the tools, the language model, and the type of agent we want to use
agent = initialize_agent(tools, llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, verbose=True)

# Use the agent
agent.run("What was the high temperature in SF yesterday in Fahrenheit? What is that number raised to the .023 power?")
```

### 3. Creating Custom Tools

You can create custom tools for your agents to use. Here's an example:

```python
from langchain.tools import BaseTool
from pydantic import BaseModel, Field
import requests

class WeatherInput(BaseModel):
    city: str = Field(description="The city to get the weather for")

class WeatherTool(BaseTool):
    name = "weather"
    description = "Useful for getting the current weather in a city"
    args_schema = WeatherInput

    def _run(self, city: str):
        # This is a mock API call
        response = requests.get(f"https://api.weatherapi.com/v1/current.json?key=YOUR_API_KEY&q={city}")
        weather_data = response.json()
        return f"The current weather in {city} is {weather_data['current']['condition']['text']} with a temperature of {weather_data['current']['temp_c']}°C"

    def _arun(self, city: str):
        # This is the asynchronous version of the _run method
        raise NotImplementedError("WeatherTool does not support async")

# Use the custom tool
tools = [WeatherTool()]
agent = initialize_agent(tools, llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, verbose=True)
agent.run("What's the weather like in London?")
```

### 4. Implementing ReAct Agents

ReAct (Reasoning and Acting) is an advanced agent architecture that combines reasoning and acting. Here's how to implement a ReAct agent:

```python
from langchain.agents import Tool, AgentExecutor, LLMSingleActionAgent, AgentOutputParser
from langchain.prompts import StringPromptTemplate
from langchain import OpenAI, SerpAPIWrapper, LLMChain
from typing import List, Union
from langchain.schema import AgentAction, AgentFinish
import re

# Define custom tools
search = SerpAPIWrapper()
tools = [
    Tool(
        name = "Search",
        func=search.run,
        description="useful for when you need to answer questions about current events"
    )
]

# Set up the base template
template = """Answer the following questions as best you can, but speaking as a pirate might speak. You have access to the following tools:

{tools}

Use the following format:

Question: the input question you must answer
Thought: you should always think about what to do
Action: the action to take, should be one of [{tool_names}]
Action Input: the input to the action
Observation: the result of the action
... (this Thought/Action/Action Input/Observation can repeat N times)
Thought: I now know the final answer
Final Answer: the final answer to the original input question

Begin! Remember to speak as a pirate when giving your final answer. Use lots of "Arg"s

Question: {input}
{agent_scratchpad}"""

# Set up a prompt template
class CustomPromptTemplate(StringPromptTemplate):
    # The template to use
    template: str
    # The list of tools available
    tools: List[Tool]

    def format(self, **kwargs) -> str:
        # Get the intermediate steps (AgentAction, Observation tuples)
        # Format them in a particular way
        intermediate_steps = kwargs.pop("intermediate_steps")
        thoughts = ""
        for action, observation in intermediate_steps:
            thoughts += action.log
            thoughts += f"\nObservation: {observation}\nThought: "
        # Set the agent_scratchpad variable to that value
        kwargs["agent_scratchpad"] = thoughts
        # Create a tools variable from the list of tools provided
        kwargs["tools"] = "\n".join([f"{tool.name}: {tool.description}" for tool in self.tools])
        # Create a list of tool names for the tools provided
        kwargs["tool_names"] = ", ".join([tool.name for tool in self.tools])
        return self.template.format(**kwargs)

prompt = CustomPromptTemplate(
    template=template,
    tools=tools,
    # This omits the `agent_scratchpad`, `tools`, and `tool_names` variables because those are generated dynamically
    input_variables=["input", "intermediate_steps"]
)

class CustomOutputParser(AgentOutputParser):

    def parse(self, llm_output: str) -> Union[AgentAction, AgentFinish]:
        # Check if agent should finish
        if "Final Answer:" in llm_output:
            return AgentFinish(
                # Return values is generally always a dictionary with a single `output` key
                # It is not recommended to try anything else at the moment :)
                return_values={"output": llm_output.split("Final Answer:")[-1].strip()},
                log=llm_output,
            )
        # Parse out the action and action input
        regex = r"Action\s*\d*\s*:(.*?)\nAction\s*\d*\s*Input\s*\d*\s*:[\s]*(.*)"
        match = re.search(regex, llm_output, re.DOTALL)
        if not match:
            raise ValueError(f"Could not parse LLM output: `{llm_output}`")
        action = match.group(1).strip()
        action_input = match.group(2)
        # Return the action and action input
        return AgentAction(tool=action, tool_input=action_input.strip(" ").strip('"'), log=llm_output)

output_parser = CustomOutputParser()

llm = OpenAI(temperature=0)
# LLM chain consisting of the LLM and a prompt
llm_chain = LLMChain(llm=llm, prompt=prompt)

tool_names = [tool.name for tool in tools]
agent = LLMSingleActionAgent(
    llm_chain=llm_chain,
    output_parser=output_parser,
    stop=["\nObservation:"],
    allowed_tools=tool_names
)

agent_executor = AgentExecutor.from_agent_and_tools(agent=agent, tools=tools, verbose=True)

agent_executor.run("What is the current price of Bitcoin?")
```

### 5. Debugging and Monitoring Agents

Debugging and monitoring agents is crucial for understanding their behavior and improving their performance. Here are some techniques:

1. Use verbose output:
   Set `verbose=True` when initializing the agent to see its thought process.

2. Implement logging:
```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class LoggingAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    
    def plan(self, intermediate_steps, **kwargs):
        plan = super().plan(intermediate_steps, **kwargs)
        logger.info(f"Agent plan: {plan}")
        return plan
```

3. Use LangChain's built-in tracing:
```python
from langchain.callbacks import get_openai_callback

with get_openai_callback() as cb:
    result = agent.run("What is the weather in San Francisco?")
    print(f"Total Tokens: {cb.total_tokens}")
    print(f"Prompt Tokens: {cb.prompt_tokens}")
    print(f"Completion Tokens: {cb.completion_tokens}")
    print(f"Total Cost (USD): ${cb.total_cost}")
```

### 6. Cross-Platform Deployment of Agent Systems

When deploying agent systems across different platforms, consider:

1. Containerization (e.g., Docker) for consistent environments
2. Serverless deployment for scalability
3. API-based architecture for flexibility

Here's an example of a Flask API for an agent system:

```python
from flask import Flask, request, jsonify
from langchain.agents import initialize_agent, Tool
from langchain.llms import OpenAI

app = Flask(__name__)

# Initialize your agent here
llm = OpenAI(temperature=0)
tools = [...]  # Your tools here
agent = initialize_agent(tools, llm, agent="zero-shot-react-description", verbose=True)

@app.route('/agent', methods=['POST'])
def run_agent():
    data = request.json
    query = data.get('query')
    if not query:
        return jsonify({"error": "No query provided"}), 400
    
    try:
        result = agent.run(query)
        return jsonify({"result": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
```

### 7. Hands-on Project: Building a Multi-Tool Research Assistant

Let's create a research assistant that can search the web, analyze data, and generate summaries:

```python
import streamlit as st
from langchain.agents import initialize_agent, Tool
from langchain.llms import OpenAI
from langchain.utilities import SerpAPIWrapper, PythonREPL
from langchain.chains.summarize import load_summarize_chain

class ResearchAssistant:
    def __init__(self):
        self.llm = OpenAI(temperature=0)
        self.search = SerpAPIWrapper()
        self.python_repl = PythonREPL()
        self.summarize_chain = load_summarize_chain(self.llm, chain_type="map_reduce")
        
        self.tools = [
            Tool(
                name = "Search",
                func=self.search.run,
                description="useful for when you need to answer questions about current events"
            ),
            Tool(
                name = "Python REPL",
                func=self.python_repl.run,
                description="useful for when you need to run python code to perform calculations or data analysis"
            ),
            Tool(
                name = "Summarizer",
                func=self.summarize,
                description="useful for when you need to summarize large amounts of text"
            )
        ]
        
        self.agent = initialize_agent(self.tools, self.llm, agent="zero-shot-react-description", verbose=True)
    
    def summarize(self, text):
        docs = [Document(page_content=text)]
        summary = self.summarize_chain.run(docs)
        return summary
    
    def run(self, query):
        return self.agent.run(query)

# Streamlit UI
st.title("Multi-Tool Research Assistant")

query = st.text_input("Enter your research question:")
if query:
    assistant = ResearchAssistant()
    result = assistant







import streamlit as st
from langchain.agents import initialize_agent, Tool
from langchain.llms import OpenAI
from langchain.utilities import SerpAPIWrapper, PythonREPL
from langchain.chains.summarize import load_summarize_chain
from langchain.docstore.document import Document

class ResearchAssistant:
    def __init__(self):
        self.llm = OpenAI(temperature=0)
        self.search = SerpAPIWrapper()
        self.python_repl = PythonREPL()
        self.summarize_chain = load_summarize_chain(self.llm, chain_type="map_reduce")
        
        self.tools = [
            Tool(
                name = "Search",
                func=self.search.run,
                description="useful for when you need to answer questions about current events"
            ),
            Tool(
                name = "Python REPL",
                func=self.python_repl.run,
                description="useful for when you need to run python code to perform calculations or data analysis"
            ),
            Tool(
                name = "Summarizer",
                func=self.summarize,
                description="useful for when you need to summarize large amounts of text"
            )
        ]
        
        self.agent = initialize_agent(self.tools, self.llm, agent="zero-shot-react-description", verbose=True)
    
    def summarize(self, text):
        docs = [Document(page_content=text)]
        summary = self.summarize_chain.run(docs)
        return summary
    
    def run(self, query):
        return self.agent.run(query)

# Streamlit UI
st.title("Multi-Tool Research Assistant")

query = st.text_input("Enter your research question:")
if query:
    assistant = ResearchAssistant()
    result = assistant.run(query)
    st.write("Research Result:")
    st.write(result)

# Add some example questions
st.sidebar.header("Example Questions")
example_questions = [
    "What are the latest developments in renewable energy?",
    "Calculate the compound interest on $1000 invested for 5 years at 5% annual rate.",
    "Summarize the plot of the latest Star Wars movie."
]
for question in example_questions:
    if st.sidebar.button(question):
        st.text_input("Enter your research question:", value=question)
```

To run this Streamlit app, save it as `research_assistant_app.py` and run:

```
streamlit run research_assistant_app.py
```

This research assistant demonstrates the power of combining multiple tools with an agent. It can search the web for current information, perform calculations or data analysis using Python, and summarize large pieces of text. The Streamlit interface makes it easy for users to interact with the assistant and see the results of their queries.

### 8. Summary and Next Steps

In this lesson, we covered:
- The concept of Agents and Tools in LangChain
- Implementing different types of LangChain Agents
- Creating custom tools for specific tasks
- Implementing ReAct agents for advanced reasoning and acting
- Debugging and monitoring Agent behavior
- Cross-platform deployment considerations for Agent systems
- Building a multi-tool research assistant as a hands-on project

To further your understanding and skills with Agents and Tools, try the following exercises:

1. Create a custom agent that specializes in a specific domain (e.g., a financial advisor agent or a travel planning agent)
2. Implement a multi-agent system where different agents collaborate to solve complex tasks
3. Develop a tool that interacts with a specific API or service (e.g., a weather API or a stock market data service)
4. Create an agent that can learn and improve its performance over time by storing and analyzing its past interactions
5. Implement a conversational agent that can maintain context over multiple turns of dialogue

In the next lesson, we'll explore Output Parsing and Structured Outputs in LangChain, which will allow us to create more sophisticated and controlled outputs from our language models.

## File Layout

For this lesson, you might organize your files as follows:

```
lesson_11/
│
├── agents/
│   ├── __init__.py
│   ├── basic_agent.py
│   ├── react_agent.py
│   └── custom_agent.py
│
├── tools/
│   ├── __init__.py
│   ├── weather_tool.py
│   ├── calculator_tool.py
│   └── summarizer_tool.py
│
├── utils/
│   ├── __init__.py
│   └── agent_debugger.py
│
├── deployment/
│   ├── Dockerfile
│   └── agent_api.py
│
├── research_assistant_app.py
├── requirements.txt
└── README.md
```

- `agents/`: Directory containing various agent implementations
- `tools/`: Directory containing custom tool implementations
- `utils/`: Directory for utility functions, including debugging tools
- `deployment/`: Directory for deployment-related files
- `research_assistant_app.py`: Streamlit app for the multi-tool research assistant
- `requirements.txt`: List of required Python packages
- `README.md`: Instructions for setting up and running the code examples

Make sure to install the required packages by running `pip install -r requirements.txt` before running the code examples.

This lesson provides a comprehensive introduction to Agents and Tools in LangChain, covering both theoretical concepts and practical implementations. The hands-on project allows students to apply these concepts in building a useful application. By completing this lesson and the suggested exercises, you'll gain a solid foundation in creating intelligent, tool-using AI systems with LangChain.

