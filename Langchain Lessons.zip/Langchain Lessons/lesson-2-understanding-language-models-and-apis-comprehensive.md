# Lesson 2: Understanding Language Models and APIs

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand the concept and evolution of Large Language Models (LLMs)
2. Identify and compare popular LLM providers and their key features
3. Comprehend the basics of RESTful APIs, including endpoints, requests, and responses
4. Implement different authentication methods for API access
5. Set up and manage API keys securely
6. Make API calls to an LLM using Python

## 1. Introduction to Large Language Models (LLMs)

### 1.1 What are LLMs?

Large Language Models (LLMs) are advanced artificial intelligence systems trained on vast amounts of text data to understand and generate human-like text. These models use deep learning techniques, particularly transformer architectures, to process and generate language.

Key characteristics of LLMs:
- Trained on diverse text data from the internet, books, and other sources
- Can understand context and generate coherent, contextually relevant text
- Capable of performing a wide range of language tasks without task-specific training

Common applications of LLMs include:
- Text generation (e.g., content creation, chatbots)
- Question answering
- Text summarization
- Language translation
- Code generation
- Text classification
- Sentiment analysis

### 1.2 History and Evolution of LLMs

The development of LLMs has been a journey of increasing model size, complexity, and capabilities:

1. Early language models (1990s-2000s):
   - N-gram models
   - Rule-based systems
   - Limited in their ability to understand context

2. Neural network-based models (2010s):
   - Recurrent Neural Networks (RNNs)
   - Long Short-Term Memory (LSTM) networks
   - Improved ability to handle sequential data, but still limited in capturing long-range dependencies

3. Transformer architecture (2017):
   - Introduced in the paper "Attention is All You Need" by Vaswani et al.
   - Key innovation: self-attention mechanism
   - Allowed for parallel processing of input sequences
   - Significantly improved the ability to capture long-range dependencies

4. GPT (Generative Pre-trained Transformer) series (2018-present):
   - GPT-1 (2018): 117 million parameters
   - GPT-2 (2019): 1.5 billion parameters
   - GPT-3 (2020): 175 billion parameters
   - GPT-4 (2023): Parameter count not disclosed, but significantly more capable

5. BERT (Bidirectional Encoder Representations from Transformers) and variants (2018-present):
   - Introduced bidirectional context understanding
   - Led to significant improvements in various NLP tasks
   - Variants include RoBERTa, ALBERT, DistilBERT

6. Recent advancements:
   - Few-shot learning: ability to perform tasks with minimal examples
   - Instruction tuning: improved ability to follow specific instructions
   - Multi-modal models: combining text with other data types (e.g., images, audio)

### 1.3 Popular LLM Providers

Several companies and organizations provide access to state-of-the-art LLMs:

1. OpenAI
   - Models: GPT-3.5, GPT-4
   - Key features:
     - Powerful general-purpose language models
     - API access for developers
     - Fine-tuning capabilities
   - Use cases: chatbots, content generation, code assistance

2. Anthropic
   - Models: Claude
   - Key features:
     - Focus on AI safety and ethics
     - Long context windows (up to 100,000 tokens)
     - Designed to be more "honest" about its capabilities and limitations
   - Use cases: research, long-form content analysis, complex reasoning tasks

3. Google
   - Models: PaLM, BERT, T5
   - Key features:
     - Integration with Google Cloud services
     - Focus on research and pushing the boundaries of NLP
   - Use cases: sentiment analysis, language translation, text classification

4. Hugging Face
   - Models: Various open-source models (BERT, GPT-2, T5, etc.)
   - Key features:
     - Model hub with thousands of pre-trained models
     - Easy deployment and fine-tuning
     - Strong community support
   - Use cases: NLP research, custom model development, educational purposes

5. Cohere
   - Models: Command, Summarize
   - Key features:
     - Specialized models for specific tasks
     - Focus on enterprise applications
   - Use cases: text generation, summarization, semantic search

When choosing an LLM provider, consider factors such as:
- Model performance and capabilities
- API pricing and rate limits
- Ease of integration
- Available features (e.g., fine-tuning, model customization)
- Data privacy and security policies

## 2. API Basics

### 2.1 What is a RESTful API?

REST (Representational State Transfer) is an architectural style for designing networked applications. RESTful APIs use HTTP requests to perform CRUD (Create, Read, Update, Delete) operations on resources.

Key principles of RESTful APIs:
- Client-server architecture
- Statelessness
- Cacheability
- Uniform interface
- Layered system
- Code on demand (optional)

### 2.2 Key Concepts

1. Endpoints:
   - URLs that represent resources or actions
   - Example: `https://api.example.com/v1/users`

2. HTTP Methods:
   - GET: Retrieve a resource
   - POST: Create a new resource
   - PUT: Update an existing resource
   - DELETE: Remove a resource
   - PATCH: Partially update a resource

3. Request Headers:
   - Metadata about the request
   - Common headers:
     - Content-Type: Specifies the format of the request body
     - Authorization: Contains authentication credentials
     - Accept: Specifies the desired response format

4. Request Body:
   - Data sent to the server (usually in JSON format)
   - Used with POST, PUT, and PATCH requests

5. Response Status Codes:
   - Indicate the result of the request
   - Common status codes:
     - 200 OK: Successful request
     - 201 Created: Resource successfully created
     - 400 Bad Request: Invalid request syntax
     - 401 Unauthorized: Authentication required
     - 404 Not Found: Resource not found
     - 500 Internal Server Error: Server-side error

6. Response Body:
   - Data returned by the server (usually in JSON format)

### 2.3 Example API Request and Response

Here's an example of a simple API request and response using the `requests` library in Python:

```python
import requests

# Make a GET request
response = requests.get("https://api.example.com/v1/users/1")

# Check the status code
if response.status_code == 200:
    # Parse the JSON response
    user_data = response.json()
    print(f"User name: {user_data['name']}")
    print(f"User email: {user_data['email']}")
else:
    print(f"Error: {response.status_code}")
    print(response.text)

# Make a POST request
new_user = {
    "name": "John Doe",
    "email": "john@example.com"
}
response = requests.post("https://api.example.com/v1/users", json=new_user)

if response.status_code == 201:
    created_user = response.json()
    print(f"Created user with ID: {created_user['id']}")
else:
    print(f"Error: {response.status_code}")
    print(response.text)
```

## 3. Authentication Methods

API authentication ensures that only authorized users or applications can access the API. Common authentication methods include:

### 3.1 API Keys

API keys are simple string tokens included in the request header or as a query parameter.

Example using an API key in the header:

```python
import requests

api_key = "your_api_key_here"
headers = {"Authorization": f"Bearer {api_key}"}

response = requests.get("https://api.example.com/v1/data", headers=headers)
```

Example using an API key as a query parameter:

```python
import requests

api_key = "your_api_key_here"
params = {"api_key": api_key}

response = requests.get("https://api.example.com/v1/data", params=params)
```

### 3.2 OAuth 2.0

OAuth 2.0 is a more complex authentication protocol that involves obtaining access tokens. It's commonly used for third-party application authorization.

Example using the `requests_oauthlib` library:

```python
from requests_oauthlib import OAuth2Session

client_id = "your_client_id"
client_secret = "your_client_secret"
token_url = "https://api.example.com/oauth/token"

oauth = OAuth2Session(client_id)
token = oauth.fetch_token(token_url, client_secret=client_secret)

response = oauth.get("https://api.example.com/v1/data")
```

### 3.3 JWT (JSON Web Tokens)

JWTs are a compact, URL-safe means of representing claims to be transferred between two parties.

Example using the `pyjwt` library:

```python
import jwt
import requests

secret_key = "your_secret_key"
payload = {"user_id": 123, "exp": 1615377000}  # Expiration time

token = jwt.encode(payload, secret_key, algorithm="HS256")

headers = {"Authorization": f"Bearer {token}"}
response = requests.get("https://api.example.com/v1/data", headers=headers)
```

## 4. Setting Up API Keys Securely

Proper management of API keys is crucial for maintaining the security of your application.

### 4.1 Using Environment Variables

Store API keys in environment variables to keep them out of your code:

```python
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("API_KEY")
```

Create a `.env` file in your project root:

```
API_KEY=your_api_key_here
```

Add `.env` to your `.gitignore` file to prevent it from being committed to version control.

### 4.2 Using Configuration Files

Create a separate configuration file (e.g., `config.ini`) to store API keys:

```ini
[API]
key = your_api_key_here
```

Read the configuration file in your Python script:

```python
import configparser

config = configparser.ConfigParser()
config.read("config.ini")

api_key = config["API"]["key"]
```

### 4.3 Using a Secret Management Service

For production applications, consider using a secret management service like AWS Secrets Manager, Google Cloud Secret Manager, or HashiCorp Vault.

Example using AWS Secrets Manager:

```python
import boto3
from botocore.exceptions import ClientError

def get_secret():
    secret_name = "my_api_key"
    region_name = "us-west-2"

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        raise e

    return get_secret_value_response['SecretString']

api_key = get_secret()
```

## 5. Making Your First API Call to an LLM

Let's make an API call to OpenAI's GPT-3.5 model using the `openai` Python library:

```python
import openai
import os
from dotenv import load_dotenv

# Load API key from environment variable
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

# Make an API call to the LLM
def generate_text(prompt):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ]
        )
        return response.choices[0].message.content
    except openai.error.OpenAIError as e:
        print(f"An error occurred: {e}")
        return None

# Example usage
user_prompt = "Explain the concept of machine learning in simple terms."
result = generate_text(user_prompt)

if result:
    print("Generated text:")
    print(result)
```

This script does the following:
1. Loads the OpenAI API key from an environment variable
2. Defines a function `generate_text` that sends a request to the OpenAI API
3. Creates a chat completion using the GPT-3.5-turbo model
4. Handles potential API errors
5. Prints the generated text if successful

## Exercises

1. Sign up for an API key from OpenAI or another LLM provider of your choice. Set up the API key securely using environment variables.

2. Write a Python script that takes user input and sends it to an LLM API. Display the model's response. Implement error handling for cases such as invalid API keys or network issues.

3. Create a simple chatbot that maintains a conversation history. Send the history along with each new user input to the LLM API to maintain context. Allow the user to have a multi-turn conversation with the chatbot.

4. Implement a language translation tool using an LLM API. The tool should detect the input language, translate the text to a target language specified by the user, and display the result.

5. Choose two different LLM providers (e.g., OpenAI and Hugging Face). Create a script that sends the same prompt to both providers and compares their responses. Analyze the differences in output quality, response time, and ease of integration.

## Conclusion

In this comprehensive lesson, we explored the fundamentals of Large Language Models and how to interact with them using APIs. We covered the evolution of LLMs, popular providers, API basics, authentication methods, secure API key management, and made our first API call to an LLM.

Understanding these concepts is crucial for building sophisticated applications that leverage the power of LLMs. In the next lesson, we'll dive deeper into LangChain fundamentals, exploring its core components and how they interact to create powerful language model applications.

