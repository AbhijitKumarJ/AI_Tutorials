# Lesson 6: Building and Using Chains

## Table of Contents
1. [Introduction](#introduction)
2. [Lesson Objectives](#lesson-objectives)
3. [Prerequisites](#prerequisites)
4. [Understanding Chains in LangChain](#understanding-chains-in-langchain)
5. [Types of Chains](#types-of-chains)
6. [Building Simple Chains](#building-simple-chains)
7. [Advanced Chain Techniques](#advanced-chain-techniques)
8. [Debugging and Optimizing Chains](#debugging-and-optimizing-chains)
9. [Practical Exercise: Building a Multi-Step Analysis Chain](#practical-exercise-building-a-multi-step-analysis-chain)
10. [Conclusion and Next Steps](#conclusion-and-next-steps)
11. [File Layout](#file-layout)

## 1. Introduction

Welcome to Lesson 6 of our LangChain Mastery course. In this lesson, we'll explore the powerful concept of chains in LangChain. Chains allow you to combine multiple components of your AI application into a single, coherent workflow. This enables you to create more complex and sophisticated applications that can handle multi-step reasoning, data processing, and decision-making.

By the end of this lesson, you'll have a solid understanding of how to build and use chains, and you'll be able to create your own advanced AI applications using LangChain.

## 2. Lesson Objectives

By the end of this lesson, you will be able to:

1. Understand the concept and importance of chains in LangChain
2. Identify and use different types of chains for various use cases
3. Build simple chains using LLMs and prompts
4. Implement advanced chain techniques, including sequential and parallel execution
5. Debug and optimize chains for better performance
6. Create a multi-step analysis chain for a practical application

## 3. Prerequisites

Before starting this lesson, ensure you have:

- Completed Lesson 5: Integrating Language Models with LangChain
- A solid understanding of Python programming concepts
- Familiarity with LangChain basics, including LLMs, prompts, and output parsers
- Python 3.7+ installed on your system
- LangChain and required dependencies installed

## 4. Understanding Chains in LangChain

Chains in LangChain are a way to combine multiple components into a single, coherent application. They allow you to create a sequence of operations that can be executed together, passing the output of one step as the input to the next.

Key concepts:

- **Components**: Individual building blocks like LLMs, prompts, and tools
- **Input**: The initial data or query that starts the chain
- **Output**: The final result produced by the chain
- **Intermediate steps**: Operations that occur between input and output

Benefits of using chains:

1. Modularity: Easily combine and recombine different components
2. Reusability: Create reusable workflows for common tasks
3. Complexity management: Break down complex tasks into manageable steps
4. Flexibility: Adapt chains to different use cases and requirements

## 5. Types of Chains

LangChain offers several types of chains to suit different use cases:

1. **LLMChain**: The most basic type of chain, combining a prompt template with an LLM
2. **SequentialChain**: Executes multiple chains in a specific order
3. **SimpleSequentialChain**: A simplified version of SequentialChain where each step has a single input and output
4. **TransformChain**: Applies a custom transformation to the input
5. **RouterChain**: Dynamically selects which chain to use based on the input
6. **ConversationChain**: Maintains conversation history for chatbot-like applications
7. **RetrievalQAChain**: Combines document retrieval with question-answering capabilities

Let's explore each of these chain types in more detail:

### 5.1 LLMChain

```python
from langchain_openai import OpenAI
from langchain import PromptTemplate, LLMChain

llm = OpenAI(temperature=0.9)
prompt = PromptTemplate(
    input_variables=["product"],
    template="What is a good name for a company that makes {product}?",
)

chain = LLMChain(llm=llm, prompt=prompt)
print(chain.run("eco-friendly water bottles"))
```

### 5.2 SequentialChain

```python
from langchain_openai import OpenAI
from langchain import PromptTemplate, LLMChain, SequentialChain

llm = OpenAI(temperature=0.9)

# First chain
first_prompt = PromptTemplate(
    input_variables=["product"],
    template="What is a good name for a company that makes {product}?",
)
first_chain = LLMChain(llm=llm, prompt=first_prompt, output_key="company_name")

# Second chain
second_prompt = PromptTemplate(
    input_variables=["company_name"],
    template="Write a catchphrase for {company_name}.",
)
second_chain = LLMChain(llm=llm, prompt=second_prompt, output_key="catchphrase")

# Combine chains
overall_chain = SequentialChain(
    chains=[first_chain, second_chain],
    input_variables=["product"],
    output_variables=["company_name", "catchphrase"]
)

result = overall_chain({"product": "eco-friendly water bottles"})
print(f"Company Name: {result['company_name']}")
print(f"Catchphrase: {result['catchphrase']}")
```

### 5.3 SimpleSequentialChain

```python
from langchain_openai import OpenAI
from langchain import PromptTemplate, LLMChain, SimpleSequentialChain

llm = OpenAI(temperature=0.9)

# First chain
first_prompt = PromptTemplate(
    input_variables=["product"],
    template="What is a good name for a company that makes {product}?",
)
first_chain = LLMChain(llm=llm, prompt=first_prompt)

# Second chain
second_prompt = PromptTemplate(
    input_variables=["company_name"],
    template="Write a catchphrase for {company_name}.",
)
second_chain = LLMChain(llm=llm, prompt=second_prompt)

# Combine chains
overall_chain = SimpleSequentialChain(chains=[first_chain, second_chain], verbose=True)

result = overall_chain.run("eco-friendly water bottles")
print(result)
```

### 5.4 TransformChain

```python
from langchain_openai import OpenAI
from langchain import PromptTemplate, LLMChain, TransformChain, SequentialChain

def transform_func(inputs):
    text = inputs["text"]
    transformed_text = text.upper()
    return {"transformed_text": transformed_text}

transform_chain = TransformChain(
    input_variables=["text"],
    output_variables=["transformed_text"],
    transform=transform_func
)

llm = OpenAI(temperature=0.9)
prompt = PromptTemplate(
    input_variables=["transformed_text"],
    template="Summarize the following text:\n\n{transformed_text}",
)
llm_chain = LLMChain(llm=llm, prompt=prompt)

overall_chain = SequentialChain(
    chains=[transform_chain, llm_chain],
    input_variables=["text"],
    output_variables=["summary"]
)

result = overall_chain({"text": "LangChain is a powerful framework for building AI applications."})
print(result["summary"])
```

### 5.5 RouterChain

```python
from langchain_openai import OpenAI
from langchain.chains.router import MultiPromptChain
from langchain.chains.router.llm_router import LLMRouterChain, RouterOutputParser
from langchain.prompts import PromptTemplate

llm = OpenAI(temperature=0.9)

physics_template = """You are a very smart physics professor. \
You are great at answering questions about physics in a concise and easy to understand manner. \
When you don't know the answer to a question you admit that you don't know.

Here is a question:
{input}"""

math_template = """You are a very good mathematician. You are great at answering math questions. \
You are so good because you are able to break down hard problems into their component parts, \
answer the component parts, and then put them together to answer the broader question.

Here is a question:
{input}"""

prompt_infos = [
    {
        "name": "physics",
        "description": "Good for answering questions about physics",
        "prompt_template": physics_template
    },
    {
        "name": "math",
        "description": "Good for answering math questions",
        "prompt_template": math_template
    }
]

chain = MultiPromptChain.from_prompts(llm, prompt_infos, verbose=True)

print(chain.run("What is the speed of light?"))
print(chain.run("What is the derivative of x^2?"))
```

### 5.6 ConversationChain

```python
from langchain_openai import OpenAI
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferMemory

llm = OpenAI(temperature=0.9)
conversation = ConversationChain(
    llm=llm,
    memory=ConversationBufferMemory()
)

print(conversation.predict(input="Hi, my name is Bob"))
print(conversation.predict(input="What's my name?"))
print(conversation.predict(input="What's the weather like today?"))
```

### 5.7 RetrievalQAChain

```python
from langchain_openai import OpenAI
from langchain.chains import RetrievalQA
from langchain.document_loaders import TextLoader
from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.vectorstores import Chroma

# Load and preprocess the text
loader = TextLoader("path/to/your/document.txt")
documents = loader.load()
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
texts = text_splitter.split_documents(documents)

# Create a vector store
embeddings = OpenAIEmbeddings()
db = Chroma.from_documents(texts, embeddings)

# Create a retrieval chain
llm = OpenAI(temperature=0)
qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    chain_type="stuff",
    retriever=db.as_retriever()
)

query = "What is the main topic of this document?"
print(qa_chain.run(query))
```

## 6. Building Simple Chains

Now that we've seen examples of different chain types, let's focus on building simple chains step by step. We'll create an LLMChain that generates a company name and slogan based on a product description.

```python
from langchain_openai import OpenAI
from langchain import PromptTemplate, LLMChain, SequentialChain
from langchain.chains import SimpleSequentialChain

# Initialize the LLM
llm = OpenAI(temperature=0.7)

# Create the company name chain
name_prompt = PromptTemplate(
    input_variables=["product_description"],
    template="Create a creative company name for a company that makes {product_description}."
)
name_chain = LLMChain(llm=llm, prompt=name_prompt, output_key="company_name")

# Create the slogan chain
slogan_prompt = PromptTemplate(
    input_variables=["company_name", "product_description"],
    template="Create a catchy slogan for {company_name}, a company that makes {product_description}."
)
slogan_chain = LLMChain(llm=llm, prompt=slogan_prompt, output_key="slogan")

# Combine the chains
company_chain = SequentialChain(
    chains=[name_chain, slogan_chain],
    input_variables=["product_description"],
    output_variables=["company_name", "slogan"]
)

# Run the chain
result = company_chain({"product_description": "eco-friendly, reusable water bottles"})
print(f"Company Name: {result['company_name']}")
print(f"Slogan: {result['slogan']}")
```

This example demonstrates how to create a simple sequential chain that generates a company name and slogan based on a product description. You can expand on this concept to create more complex chains for various applications.

## 7. Advanced Chain Techniques

As you become more comfortable with basic chains, you can explore advanced techniques to create more powerful and flexible applications.

### 7.1 Parallel Chain Execution

Sometimes, you may want to execute multiple chains in parallel rather than sequentially. While LangChain doesn't have a built-in parallel chain, you can use Python's concurrent.futures module to achieve this:

```python
from concurrent.futures import ThreadPoolExecutor
from langchain_openai import OpenAI
from langchain import PromptTemplate, LLMChain

llm = OpenAI(temperature=0.7)

# Create multiple chains
chains = [
    LLMChain(llm=llm, prompt=PromptTemplate(template="Write a joke about {topic}", input_variables=["topic"])),
    LLMChain(llm=llm, prompt=PromptTemplate(template="Write a poem about {topic}", input_variables=["topic"])),
    LLMChain(llm=llm, prompt=PromptTemplate(template="Write a fact about {topic}", input_variables=["topic"]))
]

def run_chain(chain, topic):
    return chain.run(topic)

# Execute chains in parallel
with ThreadPoolExecutor() as executor:
    results = list(executor.map(run_chain, chains, ["cats"] * len(chains)))

for i, result in enumerate(results):
    print(f"Chain {i + 1} result: {result}\n")
```

### 7.2 Dynamic Chain Selection

You can create a system that dynamically selects which chain to use based on the input. This can be achieved using a RouterChain or by implementing your own routing logic:

```python
from langchain_openai import OpenAI
from langchain import PromptTemplate, LLMChain

llm = OpenAI(temperature=0.7)

# Create multiple chains
joke_chain = LLMChain(llm=llm, prompt=PromptTemplate(template="Write a joke about {topic}", input_variables=["topic"]))
poem_chain = LLMChain(llm=llm, prompt=PromptTemplate(template="Write a poem about {topic}", input_variables=["topic"]))
fact_chain = LLMChain(llm=llm, prompt=PromptTemplate(template="Write a fact about {topic}", input_variables=["topic"]))

def select_chain(user_input):
    if "joke" in user_input.lower():
        return joke_chain
    elif "poem" in user_input.lower():
        return poem_chain
    else:
        return fact_chain

# Example usage
user_input = input("What would you like me to generate? ")
topic = input("What topic should I use? ")

selected_chain = select_chain(user_input)
result = selected_chain.run(topic)

print(f"Generated content: {result}")
```

### 7.3 Custom Chain Components

You can create custom components to use in your chains, allowing for more flexibility and specialized functionality:

```python
from langchain.chains.base import Chain
from typing import Dict, List

class CustomChain(Chain):
    output_key: str = "output"  # The key to use for the output in the chain

    @property
    def input_keys(self) -> List[str]:
        return ["text"]  # The keys expected in the input dictionary

    @property
    def output_keys(self) -> List[str]:
        return [self.output_key]  # The keys returned in the output dictionary

    def _call(self, inputs: Dict[str, str]) -> Dict[str, str]:
        text = inputs["text"]
        # Custom logic here
        output = text.upper()  # For example, convert text to uppercase
        return {self.output_key: output}

# Usage
custom_chain = CustomChain()
result = custom_chain({"text": "Hello, World!"})
print(result)  # Output: {'output': 'HELLO, WORLD!'}
```

## 8. Debugging and Optimizing Chains

As your chains become more complex, debugging and optimization become crucial. Here are some techniques to help you debug and optimize your chains:

### 8.1 Verbose Mode

Most LangChain components support a `verbose` mode, which can help you understand what's happening at each step:

```python
from langchain_openai import OpenAI
from langchain import PromptTemplate, LLMChain

llm = OpenAI(temperature=0.7)
prompt = PromptTemplate(template="Tell me a {adjective} joke about {topic}", input_variables=["adjective", "topic"])
chain = LLMChain(llm=llm, prompt=prompt, verbose=True)

result = chain({"adjective": "silly", "topic": "programmer"})
print(result)
```

### 8.2 Intermediate Steps

For more complex chains, you can add callbacks or modify the chain to return intermediate steps:

```python
from langchain_openai import OpenAI
from langchain import PromptTemplate, LLMChain, SequentialChain

llm = OpenAI(temperature=0.7)

# First chain
first_prompt = PromptTemplate(
    input_variables=["product"],
    template="What is a good name for a company that makes {product}?",
)
first_chain = LLMChain(llm=llm, prompt=first_prompt, output_key="company_name")

# Second chain
second_prompt = PromptTemplate(
    input_variables=["company_name"],
    template="Write a catchphrase for {company_name}.",
)
second_chain = LLMChain(llm=llm, prompt=second_prompt, output_key="catchphrase")

# Combine chains
overall_chain = SequentialChain(
    chains=[first_chain, second_chain],
    input_variables=["product"],
    output_variables=["company_name", "catchphrase"],
    verbose=True
)

result = overall_chain({"product": "eco-friendly water bottles"})
print(f"Company Name: {result['company_name']}")
print(f"Catchphrase: {result['catchphrase']}")
```

### 8.3 Optimizing Chain Performance

To optimize your chains, consider the following techniques:

1. **Caching**: Implement caching for LLM calls to avoid redundant API requests.
2. **Batching**: Use batch processing when possible to reduce the number of API calls.
3. **Selective Chain Execution**: Only execute necessary chains based on the input or context.
4. **Efficient Prompt Design**: Optimize your prompts to get better results with fewer tokens.
5. **Use Appropriate Model Sizes**: Choose the right model size for your task to balance performance and cost.

Example of implementing caching:

```python
from langchain_openai import OpenAI
from langchain.cache import InMemoryCache
from langchain import PromptTemplate, LLMChain

# Set up caching
import langchain
langchain.llm_cache = InMemoryCache()

llm = OpenAI(temperature=0.7)
prompt = PromptTemplate(template="Tell me a {adjective} joke about {topic}", input_variables=["adjective", "topic"])
chain = LLMChain(llm=llm, prompt=prompt)

# First call (not cached)
result1 = chain({"adjective": "silly", "topic": "programmer"})
print("First call:", result1)

# Second call (cached)
result2 = chain({"adjective": "silly", "topic": "programmer"})
print("Second call:", result2)
```

## 9. Practical Exercise: Building a Multi-Step Analysis Chain

Let's put everything we've learned into practice by building a multi-step analysis chain. This chain will take a news article as input, summarize it, perform sentiment analysis, and generate a set of follow-up questions.

```python
from langchain_openai import OpenAI
from langchain import PromptTemplate, LLMChain, SequentialChain

llm = OpenAI(temperature=0.7)

# Summarization chain
summarize_prompt = PromptTemplate(
    input_variables=["text"],
    template="Summarize the following text in 2-3 sentences:\n\n{text}"
)
summarize_chain = LLMChain(llm=llm, prompt=summarize_prompt, output_key="summary")

# Sentiment analysis chain
sentiment_prompt = PromptTemplate(
    input_variables=["summary"],
    template="Analyze the sentiment of the following text. Respond with one word: positive, negative, or neutral.\n\n{summary}"
)
sentiment_chain = LLMChain(llm=llm, prompt=sentiment_prompt, output_key="sentiment")

# Follow-up questions chain
questions_prompt = PromptTemplate(
    input_variables=["summary", "sentiment"],
    template="Based on the following summary and its {sentiment} sentiment, generate 3 follow-up questions:\n\n{summary}"
)
questions_chain = LLMChain(llm=llm, prompt=questions_prompt, output_key="questions")

# Combine all chains
analysis_chain = SequentialChain(
    chains=[summarize_chain, sentiment_chain, questions_chain],
    input_variables=["text"],
    output_variables=["summary", "sentiment", "questions"],
    verbose=True
)

# Example usage
news_article = """
In a breakthrough announcement, scientists at CERN have unveiled compelling evidence for the existence of a new fundamental particle. This discovery, made using the Large Hadron Collider, could potentially revolutionize our understanding of the universe and the forces that govern it. While further research is needed to confirm the findings, the scientific community is abuzz with excitement about the implications of this potential new addition to the Standard Model of particle physics.
"""

result = analysis_chain({"text": news_article})

print("Summary:", result["summary"])
print("Sentiment:", result["sentiment"])
print("Follow-up Questions:", result["questions"])
```

This practical exercise demonstrates how to combine multiple chains to create a more complex analysis pipeline. You can further extend this example by adding error handling, implementing parallel processing for longer articles, or integrating it with a web scraping tool to analyze live news articles.

## 10. Conclusion and Next Steps

In this lesson, we've covered the fundamentals of building and using chains in LangChain. We've explored various types of chains, learned how to create simple and complex chains, and discussed advanced techniques for optimizing and debugging chains.

Key takeaways:
1. Chains allow you to combine multiple AI components into cohesive workflows.
2. Different types of chains (LLMChain, SequentialChain, RouterChain, etc.) serve various purposes.
3. Advanced techniques like parallel execution and dynamic chain selection can enhance your applications.
4. Debugging