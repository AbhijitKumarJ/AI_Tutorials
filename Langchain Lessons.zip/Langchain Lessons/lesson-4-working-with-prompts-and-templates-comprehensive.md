# Lesson 4: Working with Prompts and Templates

## Learning Objectives
By the end of this lesson, students will be able to:
1. Create and use PromptTemplates for dynamic prompt generation
2. Implement FewShotPromptTemplates for advanced prompting and in-context learning
3. Apply prompt management best practices, including version control and reusability
4. Handle cross-platform prompt storage and retrieval
5. Implement prompt optimization techniques and understand prompt engineering fundamentals

## 1. Creating and Using PromptTemplates

PromptTemplates are a key component in LangChain for creating dynamic prompts. They allow you to define a template with placeholders that can be filled in at runtime, making your prompts more flexible and reusable.

### 1.1 Basic PromptTemplates

Let's start with a simple PromptTemplate:

```python
from langchain_core.prompts import PromptTemplate

# Create a simple PromptTemplate
template = "Write a {tone} poem about {subject}."
prompt = PromptTemplate(
    input_variables=["tone", "subject"],
    template=template
)

# Use the template
formatted_prompt = prompt.format(tone="whimsical", subject="artificial intelligence")
print(formatted_prompt)
# Output: Write a whimsical poem about artificial intelligence.
```

In this example, we create a PromptTemplate with two input variables: `tone` and `subject`. The `format` method is used to fill in these variables with actual values.

### 1.2 Complex PromptTemplates

You can create more complex templates by combining multiple parts:

```python
from langchain_core.prompts import PromptTemplate

# Create separate templates for different parts of the prompt
context_template = PromptTemplate(
    input_variables=["setting"],
    template="In a world where {setting},"
)

character_template = PromptTemplate(
    input_variables=["name", "profession"],
    template="there is a person named {name} who works as a {profession}."
)

story_template = PromptTemplate(
    input_variables=["context", "character", "genre"],
    template="{context} {character} Write a short {genre} story about this character."
)

# Combine the templates
def create_story_prompt(setting, name, profession, genre):
    context = context_template.format(setting=setting)
    character = character_template.format(name=name, profession=profession)
    return story_template.format(context=context, character=character, genre=genre)

# Use the combined template
prompt = create_story_prompt(
    setting="technology has merged with nature",
    name="Alex",
    profession="bio-engineer",
    genre="science fiction"
)
print(prompt)
```

This example demonstrates how to combine multiple templates to create a more complex prompt structure.

### 1.3 ChatPromptTemplate

For chat-based models, LangChain provides the `ChatPromptTemplate`:

```python
from langchain_core.prompts import ChatPromptTemplate, HumanMessagePromptTemplate, SystemMessagePromptTemplate

# Create a chat prompt template
template = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template("You are a helpful assistant that translates {input_language} to {output_language}."),
    HumanMessagePromptTemplate.from_template("{text}")
])

# Use the template
chat_prompt = template.format_messages(input_language="English", output_language="French", text="I love programming.")
print(chat_prompt)
```

This creates a chat prompt with a system message and a human message, which is suitable for chat-based models like GPT-3.5 or GPT-4.

## 2. FewShotPromptTemplates

FewShotPromptTemplates allow you to include examples in your prompts, which can help guide the model's output by demonstrating the desired format or style.

```python
from langchain_core.prompts import FewShotPromptTemplate, PromptTemplate

# Define the example template
example_template = """
Input: {input}
Output: {output}
"""
example_prompt = PromptTemplate(
    input_variables=["input", "output"],
    template=example_template
)

# Define some examples
examples = [
    {"input": "What is the capital of France?", "output": "The capital of France is Paris."},
    {"input": "Who wrote Romeo and Juliet?", "output": "Romeo and Juliet was written by William Shakespeare."}
]

# Create the FewShotPromptTemplate
few_shot_prompt = FewShotPromptTemplate(
    examples=examples,
    example_prompt=example_prompt,
    prefix="Answer the following question in a complete sentence:",
    suffix="Input: {input}\nOutput:",
    input_variables=["input"],
    example_separator="\n\n"
)

# Use the FewShotPromptTemplate
question = "What is the largest planet in our solar system?"
print(few_shot_prompt.format(input=question))
```

This example creates a FewShotPromptTemplate that includes two example question-answer pairs. When used, it will format these examples along with the new input question, helping guide the model to answer in a similar style.

## 3. Prompt Management Best Practices

As your projects grow, managing prompts effectively becomes crucial. Here are some best practices:

### 3.1 Version Control

Use version control systems like Git to track changes in your prompts. Store prompts in separate files or a dedicated directory:

```
project_root/
│
├── prompts/
│   ├── story_prompts.py
│   ├── qa_prompts.py
│   └── analysis_prompts.py
│
├── main.py
└── requirements.txt
```

### 3.2 Reusability

Create a library of reusable prompts:

```python
# prompts/common_prompts.py

from langchain_core.prompts import PromptTemplate

SUMMARY_TEMPLATE = PromptTemplate(
    input_variables=["text"],
    template="Summarize the following text in 3 sentences:\n\n{text}"
)

TRANSLATION_TEMPLATE = PromptTemplate(
    input_variables=["text", "language"],
    template="Translate the following text to {language}:\n\n{text}"
)

# main.py

from prompts.common_prompts import SUMMARY_TEMPLATE, TRANSLATION_TEMPLATE

# Use the prompts
summary_prompt = SUMMARY_TEMPLATE.format(text="Your long text here...")
translation_prompt = TRANSLATION_TEMPLATE.format(text="Hello, world!", language="French")
```

### 3.3 Parameterization

Use configuration files to manage prompt parameters:

```python
# config.yaml
prompts:
  summary:
    template: "Summarize the following text in {sentence_count} sentences:\n\n{text}"
    sentence_count: 3
  translation:
    template: "Translate the following text to {language}:\n\n{text}"
    default_language: "Spanish"

# load_prompts.py
import yaml
from langchain_core.prompts import PromptTemplate

def load_prompts(config_file):
    with open(config_file, 'r') as file:
        config = yaml.safe_load(file)
    
    prompts = {}
    for key, value in config['prompts'].items():
        prompts[key] = PromptTemplate(
            input_variables=["text"] + list(set(value.keys()) - {"template"}),
            template=value['template']
        )
    
    return prompts

# Usage
prompts = load_prompts('config.yaml')
summary_prompt = prompts['summary'].format(text="Your text here", sentence_count=3)
```

## 4. Cross-platform Prompt Storage and Retrieval

When working with prompts across different platforms, consider the following approaches:

### 4.1 Local File System

Use `os.path` for cross-platform file paths:

```python
import os
from langchain_core.prompts import load_prompt

prompts_dir = os.path.join("prompts", "templates")
prompt_path = os.path.join(prompts_dir, "my_prompt.json")

prompt = load_prompt(prompt_path)
```

### 4.2 Cloud Storage

For cloud-based storage, consider using services like AWS S3 or Google Cloud Storage:

```python
from langchain_core.prompts import load_prompt
import boto3

s3 = boto3.client('s3')

def load_prompt_from_s3(bucket, key):
    response = s3.get_object(Bucket=bucket, Key=key)
    prompt_json = response['Body'].read().decode('utf-8')
    return load_prompt(prompt_json)

prompt = load_prompt_from_s3('my-prompt-bucket', 'prompts/my_prompt.json')
```

### 4.3 Database Storage

For more complex applications, consider storing prompts in a database:

```python
import json
from langchain_core.prompts import load_prompt
import psycopg2

def load_prompt_from_db(prompt_name):
    conn = psycopg2.connect("dbname=myapp user=myuser password=mypassword")
    cur = conn.cursor()
    cur.execute("SELECT prompt_json FROM prompts WHERE name = %s", (prompt_name,))
    prompt_json = cur.fetchone()[0]
    cur.close()
    conn.close()
    return load_prompt(json.dumps(prompt_json))

prompt = load_prompt_from_db('my_prompt')
```

## 5. Prompt Optimization Techniques

Optimizing prompts can significantly improve the quality of your LLM outputs. Here are some techniques:

### 5.1 Iterative Refinement

Continuously refine your prompts based on the model's output:

```python
from langchain_openai import OpenAI

llm = OpenAI(temperature=0.7)

initial_prompt = "Write a short story about a robot."
result = llm.invoke(initial_prompt)

# Analyze the result and refine the prompt
refined_prompt = f"""
Write a short story about a robot. Include the following elements:
1. The robot should have a unique personality trait
2. There should be a human character who interacts with the robot
3. The story should have an unexpected twist at the end

Initial attempt:
{result}

Please improve upon this story, incorporating the requested elements.
"""

improved_result = llm.invoke(refined_prompt)
print(improved_result)
```

### 5.2 A/B Testing

Compare different prompt variations to find the most effective one:

```python
from langchain_openai import OpenAI
from langchain_core.prompts import PromptTemplate

llm = OpenAI(temperature=0.7)

prompt_a = PromptTemplate(
    input_variables=["topic"],
    template="Write a brief explanation of {topic} for a 5-year-old."
)

prompt_b = PromptTemplate(
    input_variables=["topic"],
    template="Explain {topic} using simple words and fun analogies that a child would understand."
)

topic = "photosynthesis"

result_a = llm.invoke(prompt_a.format(topic=topic))
result_b = llm.invoke(prompt_b.format(topic=topic))

print("Prompt A result:")
print(result_a)
print("\nPrompt B result:")
print(result_b)

# Evaluate the results and choose the better prompt
```

### 5.3 Prompt Chaining

Break complex tasks into smaller, more manageable prompts:

```python
from langchain_openai import OpenAI
from langchain_core.prompts import PromptTemplate

llm = OpenAI(temperature=0.7)

# Step 1: Generate a character
character_prompt = PromptTemplate(
    input_variables=["profession"],
    template="Create a unique character who works as a {profession}. Describe their name, age, and one quirky trait."
)

# Step 2: Generate a setting
setting_prompt = PromptTemplate(
    input_variables=["character"],
    template="Describe an unusual workplace setting for the following character:\n{character}"
)

# Step 3: Generate a conflict
conflict_prompt = PromptTemplate(
    input_variables=["character", "setting"],
    template="Create a work-related conflict for the following character in the given setting:\nCharacter: {character}\nSetting: {setting}"
)

# Chain the prompts
character = llm.invoke(character_prompt.format(profession="librarian"))
setting = llm.invoke(setting_prompt.format(character=character))
conflict = llm.invoke(conflict_prompt.format(character=character, setting=setting))

print(f"Character: {character}")
print(f"Setting: {setting}")
print(f"Conflict: {conflict}")
```

## Exercises

1. Create a PromptTemplate for generating a recipe. Include placeholders for cuisine type, main ingredient, and dietary restrictions. Use this template to generate three different recipes.

2. Implement a FewShotPromptTemplate for classifying movie reviews as positive or negative. Include at least five examples in your prompt. Test it with various movie reviews and evaluate its performance.

3. Design a prompt management system that allows users to save, load, and version their prompts. Implement this system using local file storage and JSON serialization. Include functions for creating new prompts, updating existing ones, and retrieving prompts by version.

4. Create a prompt optimization pipeline that takes an initial prompt, generates a response, and then automatically refines the prompt based on the quality of the response. Use this pipeline to improve a prompt over three iterations. You may want to implement a simple scoring mechanism to evaluate response quality.

5. Develop a prompt chaining system for creating a short story. Break the story creation process into at least four steps (e.g., character creation, setting description, plot development, and conclusion). Use the output of each step as input for the next step. Implement error handling to manage potential issues in the chain.

## Conclusion

In this comprehensive lesson, we explored advanced techniques for working with prompts and templates in LangChain. We covered creating dynamic PromptTemplates, implementing FewShotPromptTemplates for in-context learning, and applying best practices for prompt management. We also discussed cross-platform considerations for prompt storage and retrieval, as well as techniques for prompt optimization.

Understanding these concepts and techniques is crucial for creating effective and efficient LLM-powered applications. Proper prompt engineering can significantly improve the quality and consistency of your model outputs, leading to more robust and reliable AI systems.

In the next lesson, we'll dive into integrating various Language Models with LangChain, exploring how to connect to different LLM providers and customize model parameters for optimal performance.

