# Lesson 7: Memory in LangChain

## Lesson Overview

In this lesson, we'll explore the concept of Memory in LangChain, which is crucial for building conversational AI systems and maintaining context across multiple interactions. We'll cover various types of memory, their implementations, and best practices for managing conversation history across different platforms.

## Learning Objectives

By the end of this lesson, you should be able to:

1. Understand the concept of Memory in LangChain and its importance
2. Implement different types of Memory for various use cases
3. Manage conversation history effectively across different platforms
4. Optimize memory usage for long conversations
5. Implement a simple chatbot with memory capabilities

## Lesson Outline

1. Introduction to Memory in LangChain
2. Types of Memory
3. Implementing Conversation Memory
4. Cross-Platform Persistence of Conversation History
5. Memory Management and Optimization
6. Hands-on Project: Building a Chatbot with Memory
7. Summary and Next Steps

## Lesson Content

### 1. Introduction to Memory in LangChain

Memory in LangChain allows AI models to maintain context across multiple interactions, simulating a more human-like conversation. Without memory, each interaction would be treated independently, leading to disjointed and forgetful exchanges.

**Key Concepts:**
- Stateful conversations
- Context retention
- Improved user experience

### 2. Types of Memory

LangChain provides several types of memory to suit different use cases:

a. ConversationBufferMemory
b. ConversationBufferWindowMemory
c. ConversationSummaryMemory
d. ConversationSummaryBufferMemory
e. ConversationTokenBufferMemory
f. ConversationEntityMemory

Let's explore each type with code examples:

```python
from langchain.memory import ConversationBufferMemory, ConversationBufferWindowMemory, ConversationSummaryMemory
from langchain.llms import OpenAI

# Initialize an LLM (you'll need to set up your OpenAI API key)
llm = OpenAI(temperature=0.9)

# ConversationBufferMemory
buffer_memory = ConversationBufferMemory()
buffer_memory.save_context({"input": "Hi"}, {"output": "Hello! How can I help you?"})
buffer_memory.save_context({"input": "What's my name?"}, {"output": "I'm sorry, but I don't have any information about your name. You haven't mentioned it in our conversation yet. Is there anything else I can help you with?"})
print(buffer_memory.load_memory_variables({}))

# ConversationBufferWindowMemory
window_memory = ConversationBufferWindowMemory(k=1)
window_memory.save_context({"input": "Hi"}, {"output": "Hello! How can I help you?"})
window_memory.save_context({"input": "What's my name?"}, {"output": "I'm sorry, but I don't have any information about your name. You haven't mentioned it in our conversation yet. Is there anything else I can help you with?"})
print(window_memory.load_memory_variables({}))

# ConversationSummaryMemory
summary_memory = ConversationSummaryMemory(llm=llm)
summary_memory.save_context({"input": "Hi"}, {"output": "Hello! How can I help you?"})
summary_memory.save_context({"input": "What's my name?"}, {"output": "I'm sorry, but I don't have any information about your name. You haven't mentioned it in our conversation yet. Is there anything else I can help you with?"})
print(summary_memory.load_memory_variables({}))
```

### 3. Implementing Conversation Memory

To implement conversation memory in a chatbot or interactive system, you'll typically follow these steps:

1. Choose an appropriate memory type
2. Initialize the memory object
3. Integrate the memory with your LLM or Chain
4. Save and load context during conversations

Here's an example of implementing a simple chatbot with ConversationBufferMemory:

```python
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferMemory
from langchain.llms import OpenAI

llm = OpenAI(temperature=0.9)
memory = ConversationBufferMemory()

conversation = ConversationChain(
    llm=llm,
    memory=memory,
    verbose=True
)

# Start the conversation
print(conversation.predict(input="Hi, I'm Alice!"))
print(conversation.predict(input="What's my name?"))
print(conversation.predict(input="What have we talked about so far?"))
```

### 4. Cross-Platform Persistence of Conversation History

When deploying chatbots across different platforms, it's important to consider how to persist conversation history. Here are some options:

a. Database Storage:
   - SQL databases (e.g., PostgreSQL, MySQL)
   - NoSQL databases (e.g., MongoDB, Redis)

b. File System Storage:
   - JSON files
   - Pickle files

Example of persisting memory to a JSON file:

```python
import json
from langchain.memory import ConversationBufferMemory

def save_memory_to_file(memory, filename):
    with open(filename, 'w') as f:
        json.dump(memory.chat_memory.messages, f, default=lambda o: o.__dict__, indent=2)

def load_memory_from_file(filename):
    with open(filename, 'r') as f:
        messages = json.load(f)
    memory = ConversationBufferMemory()
    memory.chat_memory.messages = messages
    return memory

# Usage
memory = ConversationBufferMemory()
# ... use the memory in your conversation ...
save_memory_to_file(memory, 'conversation_history.json')

# Later, load the memory
loaded_memory = load_memory_from_file('conversation_history.json')
```

### 5. Memory Management and Optimization

For long conversations, memory usage can become an issue. Here are some strategies to optimize memory:

a. Use windowed memory (ConversationBufferWindowMemory) to limit the context size
b. Implement ConversationSummaryMemory to keep a condensed version of the conversation
c. Periodically prune or archive old conversations
d. Use token-based memory management (ConversationTokenBufferMemory)

Example of using ConversationTokenBufferMemory:

```python
from langchain.memory import ConversationTokenBufferMemory
from langchain.llms import OpenAI

llm = OpenAI(temperature=0.9)

# Limit the memory to 1000 tokens
memory = ConversationTokenBufferMemory(llm=llm, max_token_limit=1000)

# Use this memory in your conversation chain
```

### 6. Hands-on Project: Building a Chatbot with Memory

Let's build a simple chatbot that remembers user information and can answer questions based on previous interactions.

```python
import os
from langchain.chains import ConversationChain
from langchain.memory import ConversationEntityMemory
from langchain.llms import OpenAI

# Set up your OpenAI API key
os.environ["OPENAI_API_KEY"] = "your-api-key-here"

# Initialize the language model
llm = OpenAI(temperature=0.9)

# Initialize the memory
memory = ConversationEntityMemory(llm=llm)

# Create the conversation chain
conversation = ConversationChain(
    llm=llm,
    memory=memory,
    verbose=True
)

# Function to run the chatbot
def run_chatbot():
    print("Chatbot: Hello! I'm a chatbot with memory. What's your name?")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ['exit', 'quit', 'bye']:
            print("Chatbot: Goodbye! It was nice talking to you.")
            break
        response = conversation.predict(input=user_input)
        print(f"Chatbot: {response}")

# Run the chatbot
run_chatbot()
```

This chatbot uses ConversationEntityMemory, which allows it to remember specific entities (like names) mentioned in the conversation.

### 7. Summary and Next Steps

In this lesson, we covered:
- The concept of Memory in LangChain
- Different types of Memory and their use cases
- Implementing conversation memory in chatbots
- Cross-platform persistence of conversation history
- Memory management and optimization techniques
- A hands-on project to build a chatbot with memory

To further your understanding, try the following exercises:

1. Implement a chatbot using different memory types and compare their performance
2. Create a chatbot that persists its memory to a database
3. Experiment with ConversationSummaryMemory and analyze how it affects the conversation quality
4. Build a multi-user chatbot system that maintains separate memory for each user

In the next lesson, we'll explore Document Loaders and Text Splitters, which are crucial for working with large text datasets in LangChain applications.

## File Layout

For this lesson, you might organize your files as follows:

```
lesson_7/
│
├── memory_examples.py
├── chatbot_with_memory.py
├── memory_persistence.py
├── requirements.txt
└── README.md
```

- `memory_examples.py`: Contains the code examples for different memory types
- `chatbot_with_memory.py`: The hands-on project chatbot implementation
- `memory_persistence.py`: Examples of persisting memory to files or databases
- `requirements.txt`: List of required Python packages
- `README.md`: Instructions for setting up and running the code examples

Make sure to install the required packages by running `pip install -r requirements.txt` before running the code examples.

