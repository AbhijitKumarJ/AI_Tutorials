# Lesson 5: Integrating Language Models with LangChain (Full Version)

## Table of Contents
1. [Introduction](#introduction)
2. [Lesson Objectives](#lesson-objectives)
3. [Prerequisites](#prerequisites)
4. [Connecting to Different LLM Providers](#connecting-to-different-llm-providers)
5. [LLM and ChatModel Classes](#llm-and-chatmodel-classes)
6. [Customizing LLM Parameters](#customizing-llm-parameters)
7. [Error Handling and Retry Logic](#error-handling-and-retry-logic)
8. [Streaming Responses](#streaming-responses)
9. [Practical Exercise](#practical-exercise)
10. [Conclusion and Next Steps](#conclusion-and-next-steps)
11. [File Layout](#file-layout)

## 1. Introduction

Welcome to Lesson 5 of our LangChain Mastery course. In this lesson, we'll dive deep into integrating various language models with LangChain. This is a crucial skill for building powerful AI applications, as it allows you to leverage the strengths of different language models and customize their behavior to suit your specific needs.

We'll cover everything from connecting to different LLM providers to handling streaming responses, with plenty of practical examples along the way. By the end of this lesson, you'll have a solid understanding of how to work with language models in LangChain and be ready to incorporate them into more complex applications.

Let's begin our journey into the world of language model integration!

## 2. Lesson Objectives

By the end of this lesson, you will be able to:

1. Connect to and use different LLM providers through LangChain
2. Understand and utilize LLM and ChatModel classes effectively
3. Customize LLM parameters to optimize model performance
4. Implement robust error handling and retry logic for API calls
5. Work with streaming responses from language models
6. Create a simple application that demonstrates these skills

## 3. Prerequisites

Before starting this lesson, ensure you have:

- Basic Python knowledge (variables, functions, classes)
- Understanding of LangChain fundamentals (from previous lessons)
- Familiarity with API concepts and usage
- Python 3.7+ installed on your system
- A code editor or IDE (e.g., VSCode, PyCharm)
- Git installed (optional, for version control)

## 4. Connecting to Different LLM Providers

### 4.1 Overview of Supported Providers

LangChain supports integration with various Language Model providers. The most commonly used ones include:

- OpenAI
- Anthropic
- Hugging Face
- Cohere
- AI21
- And many others

Each provider has its strengths and specific use cases. In this lesson, we'll focus on OpenAI, Anthropic, and Hugging Face, but the principles apply to other providers as well.

### 4.2 Setting Up Provider-Specific Packages

To use different LLM providers with LangChain, you'll need to install the appropriate packages. Open your terminal and run the following commands:

```bash
pip install langchain
pip install langchain-openai
pip install langchain-anthropic
pip install langchain-huggingface
```

These commands install LangChain and the necessary provider-specific packages.

### 4.3 Configuring API Keys

It's crucial to keep your API keys secure. We'll use environment variables to store our API keys. Create a file named `.env` in your project root and add your API keys:

```plaintext
OPENAI_API_KEY=your_openai_api_key_here
ANTHROPIC_API_KEY=your_anthropic_api_key_here
HUGGINGFACEHUB_API_TOKEN=your_huggingface_api_token_here
```

Now, let's create a Python script to load these environment variables:

```python
# config.py

import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
HUGGINGFACEHUB_API_TOKEN = os.getenv("HUGGINGFACEHUB_API_TOKEN")

def get_api_key(provider):
    """Get the API key for the specified provider."""
    if provider == "openai":
        return OPENAI_API_KEY
    elif provider == "anthropic":
        return ANTHROPIC_API_KEY
    elif provider == "huggingface":
        return HUGGINGFACEHUB_API_TOKEN
    else:
        raise ValueError(f"Unsupported provider: {provider}")
```

### 4.4 Connecting to Providers

Now that we have our API keys set up, let's connect to different LLM providers:

```python
# llm_providers.py

from langchain_openai import OpenAI
from langchain_anthropic import ChatAnthropic
from langchain_huggingface import HuggingFaceHub
from config import get_api_key

def get_llm(provider, **kwargs):
    """Get an LLM instance for the specified provider."""
    if provider == "openai":
        return OpenAI(api_key=get_api_key("openai"), **kwargs)
    elif provider == "anthropic":
        return ChatAnthropic(api_key=get_api_key("anthropic"), **kwargs)
    elif provider == "huggingface":
        return HuggingFaceHub(
            repo_id="google/flan-t5-xxl",
            huggingfacehub_api_token=get_api_key("huggingface"),
            **kwargs
        )
    else:
        raise ValueError(f"Unsupported provider: {provider}")

# Usage examples
llm_openai = get_llm("openai", temperature=0.7)
llm_anthropic = get_llm("anthropic", temperature=0.9)
llm_huggingface = get_llm("huggingface", model_kwargs={"temperature": 0.5, "max_length": 64})
```

This setup allows you to easily switch between different LLM providers and customize their parameters.

## 5. LLM and ChatModel Classes

LangChain provides two main classes for working with language models: LLM and ChatModel. Understanding the differences and use cases for each is crucial for effective integration.

### 5.1 LLM Class

The LLM class is designed for text completion models. These models take a string input and return a string output.

Key characteristics:
- Input and output are strings
- Suitable for general text generation tasks
- Used with models like OpenAI's GPT-3

Example usage:

```python
from langchain.llms import OpenAI

llm = OpenAI(temperature=0.9)
prompt = "What would be a good company name for a company that makes colorful socks?"
response = llm(prompt)
print(response)
```

### 5.2 ChatModel Class

The ChatModel class is designed for chat-based models. These models work with a series of messages as input and output.

Key characteristics:
- Input and output are lists of messages
- Suitable for conversational AI and multi-turn interactions
- Used with models like OpenAI's GPT-3.5-turbo and GPT-4

Example usage:

```python
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage, SystemMessage

chat = ChatOpenAI(temperature=0)
messages = [
    SystemMessage(content="You are a helpful assistant."),
    HumanMessage(content="What's the capital of France?")
]
response = chat(messages)
print(response.content)
```

### 5.3 Key Differences and Use Cases

1. Input/Output Format:
   - LLM: String in, string out
   - ChatModel: List of messages in, message out

2. Conversation History:
   - LLM: Requires manual management of conversation history
   - ChatModel: Naturally handles multi-turn conversations

3. Use Cases:
   - LLM: Text completion, generation, summarization
   - ChatModel: Chatbots, conversational AI, multi-turn Q&A

4. Available Methods:
   - Both classes support methods like `generate()` for batch processing
   - ChatModel has additional methods for handling chat-specific functionality

Understanding these differences will help you choose the right class for your specific use case.

## 6. Customizing LLM Parameters

Customizing LLM parameters allows you to fine-tune the behavior of the language model to suit your specific needs. Let's explore common parameters and how to use them effectively.

### 6.1 Common Parameters

1. **temperature** (float, 0-2):
   - Controls randomness in output
   - Lower values (e.g., 0.2) for more deterministic responses
   - Higher values (e.g., 0.8) for more creative and diverse responses

2. **max_tokens** (integer):
   - Limits the length of the generated text
   - Useful for controlling response size and API costs

3. **top_p** (float, 0-1):
   - Alternative to temperature for controlling randomness
   - Lower values (e.g., 0.1) for more focused sampling

4. **frequency_penalty** (float, -2.0 to 2.0):
   - Reduces repetition of token sequences
   - Positive values decrease the likelihood of repeating the same line

5. **presence_penalty** (float, -2.0 to 2.0):
   - Increases diversity by penalizing new tokens based on their presence in the text so far
   - Positive values increase the model's likelihood to talk about new topics

### 6.2 Provider-Specific Parameters

Different providers may have additional parameters:

- OpenAI:
  - `model_name`: Specifies which model to use (e.g., "text-davinci-003", "gpt-3.5-turbo")
  - `n`: Number of completions to generate
  - `stop`: Sequences where the API will stop generating further tokens

- Anthropic:
  - `model`: Specifies which model to use (e.g., "claude-2", "claude-instant-1")
  - `max_tokens_to_sample`: Similar to `max_tokens` in OpenAI

- Hugging Face:
  - `model_kwargs`: Dictionary of additional arguments to pass to the model

### 6.3 Example: Customizing OpenAI Parameters

Let's create a function that demonstrates how to customize OpenAI parameters:

```python
# llm_customization.py

from langchain_openai import OpenAI
from config import get_api_key

def create_custom_openai_llm(
    temperature=0.7,
    max_tokens=100,
    top_p=1,
    frequency_penalty=0,
    presence_penalty=0,
    model_name="text-davinci-003",
    n=1,
    stop=None
):
    """Create a customized OpenAI LLM instance."""
    return OpenAI(
        api_key=get_api_key("openai"),
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty,
        model_name=model_name,
        n=n,
        stop=stop
    )

# Usage example
llm = create_custom_openai_llm(
    temperature=0.9,
    max_tokens=150,
    frequency_penalty=0.2,
    model_name="gpt-3.5-turbo"
)

prompt = "Write a short story about a robot learning to love:"
response = llm(prompt)
print(response)
```

This function allows you to easily create customized OpenAI LLM instances with different parameters.

## 7. Error Handling and Retry Logic

When working with external APIs, it's crucial to implement robust error handling and retry logic. This ensures your application can gracefully handle issues like rate limiting, network errors, or temporary service outages.

### 7.1 Common API Errors

Some common errors you might encounter include:

1. Rate limiting: Exceeding the allowed number of requests per minute
2. Authentication errors: Invalid or expired API keys
3. Invalid requests: Malformed input or unsupported parameters
4. Network errors: Timeouts or connection issues
5. Service unavailability: Temporary outages or maintenance

### 7.2 Implementing Basic Error Handling

Let's create a basic error handling wrapper for our LLM calls:

```python
# error_handling.py

from langchain_openai import OpenAI
from openai import OpenAIError
from config import get_api_key

def call_llm_with_error_handling(prompt, llm=None):
    """Call LLM with basic error handling."""
    if llm is None:
        llm = OpenAI(api_key=get_api_key("openai"))

    try:
        response = llm(prompt)
        return response
    except OpenAIError as e:
        print(f"An error occurred: {e}")
        return None

# Usage example
result = call_llm_with_error_handling("Tell me a joke")
if result:
    print(result)
else:
    print("Failed to get a response from the LLM")
```

### 7.3 Implementing Retry Logic

For more robust error handling, we can implement retry logic with exponential backoff:

```python
# retry_logic.py

import time
from langchain_openai import OpenAI
from openai import OpenAIError
from config import get_api_key

def call_llm_with_retry(prompt, max_retries=3, initial_delay=1, backoff_factor=2, llm=None):
    """Call LLM with retry logic and exponential backoff."""
    if llm is None:
        llm = OpenAI(api_key=get_api_key("openai"))

    for attempt in range(max_retries):
        try:
            return llm(prompt)
        except OpenAIError as e:
            if attempt < max_retries - 1:
                delay = initial_delay * (backoff_factor ** attempt)
                print(f"Error occurred: {e}. Retrying in {delay} seconds...")
                time.sleep(delay)
            else:
                print(f"Failed after {max_retries} attempts: {e}")
                return None

# Usage example
result = call_llm_with_retry("Tell me a joke about programming")
if result:
    print(result)
else:
    print("Failed to get a response after multiple attempts")
```

This implementation uses exponential backoff, increasing the delay between retries to avoid overwhelming the API during periods of high load or temporary issues.

## 8. Streaming Responses

Streaming responses allow you to receive and process the LLM's output in real-time, as it's being generated. This can significantly improve the user experience for applications that require immediate feedback.

### 8.1 Understanding Streaming Responses

Benefits of streaming:
- Faster perceived response time
- Ability to process partial results
- Improved interactivity in applications

Use cases:
- Real-time chat interfaces
- Live text generation in writing assistants
- Progressive rendering in web applications

### 8.2 Implementing Streaming with OpenAI

Let's create a function that demonstrates how to use streaming with OpenAI:

```python
# streaming.py

from langchain_openai import OpenAI
from config import get_api_key

def stream_openai_response(prompt, temperature=0.7):
    """Stream response from OpenAI LLM."""
    llm = OpenAI(api_key=get_api_key("openai"), streaming=True, temperature=temperature)
    
    print("Streaming response:")
    for chunk in llm.stream(prompt):
        print(chunk, end="", flush=True)
    print("\nStreaming complete.")

# Usage example
stream_openai_response("Write a short story about a robot learning to love:")
```

### 8.3 Handling Streaming Responses in Applications

For more complex applications, you might want to use callbacks to handle streaming responses. Here's an example using a custom callback handler:

```python
# advanced_streaming.py

from langchain_openai import OpenAI
from langchain.callbacks.base import BaseCallbackHandler
from config import get_api_key

class StreamingCallbackHandler(BaseCallbackHandler):
    def on_llm_new_token(self, token: str, **kwargs) -> None:
        print(token, end="", flush=True)

def stream_with_callback(prompt, temperature=0.7):
    """Stream response using a callback handler."""
    llm = OpenAI(
        api_key=get_api_key("openai"),
        streaming=True,
        temperature=temperature,
        callbacks=[StreamingCallbackHandler()]
    )
    
    print("Streaming response with callback:")
    llm(prompt)
    print("\nStreaming complete.")

# Usage example
stream_with_callback("Write a poem about artificial intelligence:")
```

This approach gives you more control over how streaming responses are handled, allowing you to integrate them seamlessly into your applications.

## 9. Practical Exercise

Now that we've covered the key concepts of integrating language models with LangChain, let's put it all together in a practical exercise. We'll create a simple chatbot that can switch between different language models based on user input, handle errors gracefully, and support streaming responses.

```python
# chatbot.py

import time
from langchain_openai import OpenAI, ChatOpenAI
from langchain_anthropic import ChatAnthropic
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.schema import HumanMessage, SystemMessage
from config import get_api_key

class Chatbot:
    def __init__(self):
        self.llm = None
        self.chat_history = []

    def set_llm(self, provider, temperature=0.7):
        if provider == "openai":
            self.llm = OpenAI(api_key=get_api_key("openai"), temperature=temperature)
        elif provider == "openai_chat":
            self.llm = ChatOpenAI(api_key=get_api_key("openai"), temperature=temperature)
        elif provider == "anthropic":
            self.llm = ChatAnthropic(api_key=get_api_key("anthropic"), temperature=temperature)
        else:
            raise ValueError(f"Unsupported provider: {provider}")

    def chat(self, message, stream=False):
        if not self.llm:
            raise ValueError("Please set an LLM provider first using set_llm()")

        self.chat_history.append(HumanMessage(content=message))
        
        try:
            if stream:
                response = self._stream_response(message)
            else:
                response = self._get_response(message)
            
            self.chat_history.append(SystemMessage(content=response))
            return response
        except Exception as e:
            print(f"An error occurred: {e}")
            return "I'm sorry, I encountered an error. Please try again."

    def _get_response(self, message):
        return self.llm(self.chat_history).content

    def _stream_response(self, message):
        response = ""
        for chunk in self.llm.stream(self.chat_history):
            content = chunk.content if isinstance(chunk, SystemMessage) else chunk
            print(content, end="", flush=True)
            response += content
        print()  # New line after streaming
        return response

def main():
    chatbot = Chatbot()
    print("Welcome to the Multi-LLM Chatbot!")
    print("Available commands: ")
    print("  !openai - Switch to OpenAI")
    print("  !openai_chat - Switch to OpenAI ChatGPT")
    print("  !anthropic - Switch to Anthropic")
    print("  !stream - Toggle streaming mode")
    print("  !exit - Exit the chatbot")

    streaming = False

    while True:
        user_input = input("\nYou: ").strip()
        
        if user_input.lower() == "!exit":
            print("Goodbye!")
            break
        elif user_input.lower() == "!openai":
            chatbot.set_llm("openai")
            print("Switched to OpenAI")
        elif user_input.lower() == "!openai_chat":
            chatbot.set_llm("openai_chat")
            print("Switched to OpenAI ChatGPT")
        elif user_input.lower() == "!anthropic":
            chatbot.set_llm("anthropic")
            print("Switched to Anthropic")
        elif user_input.lower() == "!stream":
            streaming = not streaming
            print(f"Streaming mode: {'On' if streaming else 'Off'}")
        else:
            if not chatbot.llm:
                print("Please select an LLM provider first using !openai, !openai_chat, or !anthropic")
            else:
                response = chatbot.chat(user_input, stream=streaming)
                if not streaming:
                    print(f"\nChatbot: {response}")

if __name__ == "__main__":
    main()
```

This practical exercise brings together all the concepts we've covered in this lesson:
- Connecting to different LLM providers
- Using both LLM and ChatModel classes
- Customizing LLM parameters
- Implementing error handling
- Working with streaming responses

To run the chatbot, save the code in a file named `chatbot.py` and run it using Python. You can then interact with the chatbot, switch between different LLM providers, and toggle streaming mode.

## 10. Conclusion and Next Steps

In this lesson, we've covered the essential aspects of integrating language models with LangChain:

1. Connecting to different LLM providers
2. Understanding and using LLM and ChatModel classes
3. Customizing LLM parameters for optimal performance
4. Implementing error handling and retry logic
5. Working with streaming responses

These skills form the foundation for building more complex AI applications using LangChain. As you continue your journey, consider exploring the following topics:

- Advanced prompt engineering techniques
- Fine-tuning language models for specific tasks
- Integrating language models with other AI components (e.g., image recognition, speech processing)
- Building more complex conversational AI systems
- Optimizing performance and reducing API costs in production environments

In the next lesson, we'll dive into "Building and Using Chains," where you'll learn how to combine multiple components to create more powerful and flexible AI applications.

## 11. File Layout

Here's a suggested file layout for organizing the code from this lesson:

```
lesson_5/
│
├── .env                     # Environment variables (API keys)
├── requirements.txt         # Project dependencies
├── config.py                # Configuration and API key management
├── llm_providers.py         # LLM provider initialization
├── llm_customization.py     # LLM parameter customization
├── error_handling.py        # Basic error handling
├── retry_logic.py           # Retry logic implementation
├── streaming.py             # Basic streaming implementation
├── advanced_streaming.py    # Advanced streaming with callbacks
├── chatbot.py               # Practical exercise: Multi-LLM Chatbot
└── README.md                # Lesson overview and instructions
```

To use this project structure:

1. Create a new directory called `lesson_5`
2. Create each of the files listed above in the `lesson_5` directory
3. Copy the code snippets from this lesson into their respective files
4. Create a `requirements.txt` file with the following content:

   ```
   langchain
   langchain-openai
   langchain-anthropic
   langchain-huggingface
   python-dotenv
   ```

5. Create a `.env` file with your API keys (make sure to add this file to your `.gitignore` if using version control)
6. Create a `README.md` file with instructions on how to set up and run the code from this lesson

This file layout will help you keep your code organized and make it easier to navigate and maintain as you work through the lesson and build upon it in future projects.

