# Bonus Lesson 4: Cross-Platform Compatibility and Packaging

Welcome to the fourth bonus lesson in our final project series! In this lesson, we'll ensure our TaskMaster CLI tool works seamlessly across different operating systems and package it for easy distribution and installation.

## Ensuring Cross-Platform Compatibility

While we've been mindful of cross-platform issues throughout our development process, let's review and enhance our application to ensure it works well on Windows, macOS, and Linux.

### 1. File Paths

We're already using `pathlib.Path` for file operations, which handles path differences across operating systems. However, let's create a utility function to get the user's home directory for storing our application data. Create a new file `taskmaster/utils/paths.py`:

```python
from pathlib import Path

def get_data_dir():
    home = Path.home()
    if Path.home() == Path("/"):
        # For some Linux distros where HOME is not set
        import pwd, os
        home = Path(pwd.getpwuid(os.getuid()).pw_dir)
    return home / ".taskmaster"

def ensure_data_dir():
    data_dir = get_data_dir()
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir
```

Now, update `taskmaster/utils/database.py` to use this data directory:

```python
from pathlib import Path
from typing import List, Dict, Any
import json
from taskmaster.utils.paths import ensure_data_dir

class Database:
    def __init__(self, file_name: str = "taskmaster_data.json"):
        data_dir = ensure_data_dir()
        self.file_path = data_dir / file_name
        self.data: Dict[str, Any] = {"tasks": [], "projects": []}
        self.load()

    # ... (rest of the Database class remains the same)
```

### 2. Console Output

To handle terminals with limited capabilities, let's add a `--plain` option to our CLI. Update `taskmaster/cli.py`:

```python
import click
from rich.console import Console
from taskmaster.commands.task import task
from taskmaster.commands.project import project
from taskmaster.commands.view import view

console = Console()

@click.group()
@click.version_option(version="1.0.0")
@click.option("--plain", is_flag=True, help="Use plain text output instead of rich formatting")
@click.pass_context
def cli(ctx, plain):
    """TaskMaster: A comprehensive task management CLI tool."""
    ctx.ensure_object(dict)
    ctx.obj['plain'] = plain
    if plain:
        console.force_terminal = False
        console.force_jupyter = False
        console.force_interactive = False

cli.add_command(task)
cli.add_command(project)
cli.add_command(view)

if __name__ == "__main__":
    cli()
```

Now, update all commands that use Rich formatting to respect the `plain` option. For example, in `taskmaster/commands/task.py`:

```python
import click
from rich.console import Console
from rich.table import Table
from taskmaster.models.task import Task
from taskmaster.utils.database import db
from datetime import datetime
from prompt_toolkit import prompt
from prompt_toolkit.validation import Validator, ValidationError

console = Console()

# ... (previous code remains the same)

@task.command()
@click.pass_context
def list(ctx):
    """List all tasks."""
    tasks = db.get_tasks()
    projects = {p["id"]: p["name"] for p in db.get_projects()}
    
    if ctx.obj['plain']:
        for task in tasks:
            print(f"ID: {task['id']}")
            print(f"Title: {task['title']}")
            print(f"Due Date: {task['due_date'] if task['due_date'] else 'N/A'}")
            print(f"Priority: {task['priority']}")
            print(f"Completed: {'Yes' if task['completed'] else 'No'}")
            print(f"Project: {projects.get(task['project_id'], 'N/A')}")
            print("---")
    else:
        table = Table(title="Tasks")
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Title", style="magenta")
        table.add_column("Due Date", style="green")
        table.add_column("Priority", style="yellow")
        table.add_column("Completed", style="blue")
        table.add_column("Project", style="red")

        for task in tasks:
            table.add_row(
                str(task["id"]),
                task["title"],
                str(task["due_date"]) if task["due_date"] else "N/A",
                str(task["priority"]),
                "✓" if task["completed"] else "✗",
                projects.get(task["project_id"], "N/A")
            )

        console.print(table)

# ... (update other commands similarly)
```

### 3. Date and Time Handling

To handle date inputs more flexibly across different locales, let's use the `dateutil` library. First, install it:

```bash
pip install python-dateutil
```

Now, update the task creation in `taskmaster/commands/task.py`:

```python
from dateutil.parser import parse as parse_date
import pytz

# ... (previous imports remain the same)

@task.command()
def add():
    """Add a new task interactively."""
    title = prompt("Task title: ")
    description = prompt("Task description: ")
    due_date_str = prompt("Due date (e.g., '2023-12-31 23:59' or 'next friday 2pm', press enter to skip): ")
    try:
        due_date = parse_date(due_date_str) if due_date_str else None
        if due_date and due_date.tzinfo is None:
            due_date = pytz.utc.localize(due_date)
    except ValueError:
        console.print("[red]Invalid date format. Setting due date to None.[/red]")
        due_date = None
    
    priority = int(prompt("Priority (1-5): ", validator=IntegerValidator()))
    
    projects = db.get_projects()
    if projects:
        project_choices = "\n".join([f"{p['id']}: {p['name']}" for p in projects])
        project_id = int(prompt(f"Select a project ID (or 0 for no project):\n{project_choices}\nProject ID: "))
    else:
        project_id = 0

    task_id = len(db.get_tasks()) + 1
    new_task = Task(
        id=task_id,
        title=title,
        description=description,
        due_date=due_date,
        priority=priority,
        project_id=project_id if project_id != 0 else None
    )
    db.add_task(new_task.__dict__)
    console.print(f"[green]Task added successfully: {new_task}[/green]")

# ... (rest of the file remains the same)
```

### 4. Keyboard Interrupts

To handle keyboard interrupts gracefully across all platforms, wrap the main execution in a try-except block. Update `taskmaster/cli.py`:

```python
import click
from rich.console import Console
from taskmaster.commands.task import task
from taskmaster.commands.project import project
from taskmaster.commands.view import view

console = Console()

@click.group()
@click.version_option(version="1.0.0")
@click.option("--plain", is_flag=True, help="Use plain text output instead of rich formatting")
@click.pass_context
def cli(ctx, plain):
    """TaskMaster: A comprehensive task management CLI tool."""
    ctx.ensure_object(dict)
    ctx.obj['plain'] = plain
    if plain:
        console.force_terminal = False
        console.force_jupyter = False
        console.force_interactive = False

cli.add_command(task)
cli.add_command(project)
cli.add_command(view)

def main():
    try:
        cli()
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled by user.[/yellow]")
        return 1
    return 0

if __name__ == "__main__":
    exit(main())
```

## Packaging the Application

Now that we've ensured cross-platform compatibility, let's package our application for easy distribution and installation.

### 1. Update `setup.py`

Ensure your `setup.py` file is up-to-date with all dependencies:

```python
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="taskmaster-cli",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A comprehensive task management CLI tool",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/taskmaster",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "click",
        "rich",
        "prompt_toolkit",
        "pygments",
        "python-dateutil",
        "pytz",
    ],
    entry_points={
        "console_scripts": [
            "taskmaster=taskmaster.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
```

### 2. Create a `MANIFEST.in` file

Create a `MANIFEST.in` file in the root directory to include non-Python files:

```
include README.md
include LICENSE
recursive-include taskmaster/data *
```

### 3. Build the Package

Now, build your package:

```bash
python setup.py sdist bdist_wheel
```

This will create a `dist` directory with your package files.

### 4. Test the Package Locally

Install the package locally to test it:

```bash
pip install -e .
```

Now you should be able to run `taskmaster` from anywhere on your system.

### 5. Publish to PyPI (Optional)

If you want to make your package available to others, you can publish it to PyPI:

1. Install twine:
   ```bash
   pip install twine
   ```

2. Upload your package:
   ```bash
   twine upload dist/*
   ```

## Creating Executable Binaries

For users who prefer not to install Python or use pip, you can create standalone executable binaries using PyInstaller.

1. Install PyInstaller:
   ```bash
   pip install pyinstaller
   ```

2. Create the executable:
   ```bash
   pyinstaller --onefile --name taskmaster taskmaster/cli.py
   ```

This will create a `dist` directory containing a single executable file that users can run directly on their system without needing Python installed.

## Conclusion

In this lesson, we've enhanced our TaskMaster CLI tool to ensure cross-platform compatibility and packaged it for easy distribution. We've addressed issues related to file paths, console output, date handling, and keyboard interrupts. We've also prepared the application for distribution via PyPI and created standalone executables for users who prefer not to install Python.

In the final lesson, we'll focus on documentation, testing, and deployment strategies for our TaskMaster CLI tool.

Remember to commit your changes:

```bash
git add .
git commit -m "Ensure cross-platform compatibility and package the application"
```

</antArtifact>

Great progress! Now, let's move on to our final bonus lesson, where we'll focus on documentation, testing, and deployment strategies for our TaskMaster CLI tool.
