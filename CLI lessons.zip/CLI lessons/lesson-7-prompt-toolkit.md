# Lesson 7: Interactive Input with Prompt Toolkit

In this lesson, we'll explore Prompt Toolkit, a powerful library for building interactive command line applications. Prompt Toolkit allows you to create advanced input prompts with features like auto-completion, syntax highlighting, and multi-line editing.

## 1. Introduction to Prompt Toolkit

Prompt Toolkit is a library for building powerful interactive command line applications in Python. It's the library behind tools like IPython and provides a more powerful alternative to Python's built-in `input()` function.

### Key Features of Prompt Toolkit:

1. Syntax highlighting
2. Multi-line editing
3. Auto-completion
4. History
5. Key bindings
6. Ability to create full-screen applications

## 2. Installing Prompt Toolkit

Before we start, we need to install Prompt Toolkit. Use pip to install it:

```
pip install prompt_toolkit
```

This command works across Windows, macOS, and Linux.

## 3. Basic Prompt Toolkit Concepts

Before we dive into coding, let's understand some key concepts:

1. **Prompt Session**: The main object for creating prompts.
2. **Completer**: Provides auto-completion functionality.
3. **Lexer**: Handles syntax highlighting.
4. **Validator**: Validates user input.
5. **History**: Manages command history.

## 4. Creating a Simple CLI with Prompt Toolkit

Let's enhance our calculator application using Prompt Toolkit to create an interactive prompt.

### Project Structure:
```
prompt_toolkit_calculator/
│
├── calc.py
└── README.md
```

### calc.py
```python
from prompt_toolkit import PromptSession
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.lexers import PygmentsLexer
from prompt_toolkit.styles import Style
from pygments.lexers.python import PythonLexer

def calculate(expression):
    try:
        return eval(expression)
    except Exception as e:
        return f"Error: {str(e)}"

def main():
    session = PromptSession()
    completer = WordCompleter(['add', 'subtract', 'multiply', 'divide', 'exit'])
    style = Style.from_dict({
        'prompt': 'bg:#ansiblue #ansiwhite',
    })

    while True:
        try:
            user_input = session.prompt(
                'calculator> ',
                completer=completer,
                lexer=PygmentsLexer(PythonLexer),
                style=style
            )
        except KeyboardInterrupt:
            continue
        except EOFError:
            break

        if user_input.lower() == 'exit':
            break

        result = calculate(user_input)
        print(f"Result: {result}")

    print("Thank you for using the calculator!")

if __name__ == '__main__':
    main()
```

### Explanation:

1. We create a `PromptSession` object, which we'll use for our interactive prompt.
2. We define a `WordCompleter` with some basic calculator operations for auto-completion.
3. We use `PygmentsLexer` with `PythonLexer` for syntax highlighting of Python expressions.
4. We create a custom `Style` to change the appearance of our prompt.
5. In the main loop, we use `session.prompt()` to get user input with all these features enabled.
6. We use a simple `eval()` function to calculate results (Note: In a real-world application, you'd want to use a safer evaluation method).

### Usage:

To use this CLI, open a terminal, navigate to the `prompt_toolkit_calculator` directory, and run:

```
python calc.py
```

You'll see an interactive prompt where you can enter calculations. Try using auto-completion and entering multi-line expressions.

## 5. Cross-Platform Considerations with Prompt Toolkit

Prompt Toolkit is designed to work across different platforms, but there are some considerations:

1. **Input Handling**: Prompt Toolkit handles input differently on Windows compared to Unix-like systems. It automatically uses the appropriate backend.

2. **Color Support**: Color support can vary across terminals. Prompt Toolkit tries to detect color support, but you can force it:
   ```python
   from prompt_toolkit.output import ColorDepth
   session = PromptSession(color_depth=ColorDepth.TRUE_COLOR)
   ```

3. **Key Bindings**: Some key combinations might work differently across platforms. It's a good practice to provide alternative key bindings for important actions.

4. **Terminal Size**: Prompt Toolkit automatically detects the terminal size, but you can override it if needed:
   ```python
   from prompt_toolkit.application import Application
   from prompt_toolkit.output import Size
   app = Application(output=Size(rows=24, columns=80))
   ```

## 6. Advanced Prompt Toolkit Features

Let's expand our calculator to demonstrate some more advanced features of Prompt Toolkit:

### calc_advanced.py
```python
from prompt_toolkit import PromptSession
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.lexers import PygmentsLexer
from prompt_toolkit.styles import Style
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.validation import Validator, ValidationError
from pygments.lexers.python import PythonLexer
import math

def calculate(expression):
    try:
        # Add some basic math functions
        safe_dict = {
            'abs': abs, 'round': round,
            'math': math
        }
        return eval(expression, {"__builtins__": None}, safe_dict)
    except Exception as e:
        return f"Error: {str(e)}"

class CalculatorValidator(Validator):
    def validate(self, document):
        text = document.text
        if text and not any(text.startswith(op) for op in ['abs', 'round', 'math.']):
            if not text[0].isdigit() and text[0] not in '(-':
                raise ValidationError(message='Expression must start with a number, math function, or opening parenthesis')

def main():
    history = FileHistory('.calculator_history')
    session = PromptSession(history=history)
    
    completer = WordCompleter(['abs', 'round', 'math.sin', 'math.cos', 'math.tan', 'math.pi', 'exit'])
    
    style = Style.from_dict({
        'prompt': 'bg:#ansiblue #ansiwhite',
        'completion-menu.completion': 'bg:#008888 #ffffff',
        'completion-menu.completion.current': 'bg:#00aaaa #000000',
    })

    kb = KeyBindings()

    @kb.add('c-d')
    def _(event):
        " Exit when 'c-d' is pressed. "
        event.app.exit()

    validator = CalculatorValidator()

    while True:
        try:
            user_input = session.prompt(
                'calculator> ',
                completer=completer,
                lexer=PygmentsLexer(PythonLexer),
                auto_suggest=AutoSuggestFromHistory(),
                style=style,
                key_bindings=kb,
                validator=validator,
            )
        except KeyboardInterrupt:
            continue
        except EOFError:
            break

        if user_input.lower() == 'exit':
            break

        result = calculate(user_input)
        print(f"Result: {result}")

    print("Thank you for using the calculator!")

if __name__ == '__main__':
    main()
```

### New Features Explained:

1. **File History**: We're now saving command history to a file.
2. **Auto Suggest**: The prompt will now suggest completions based on history.
3. **Custom Key Bindings**: We've added a custom key binding to exit on Ctrl-D.
4. **Input Validation**: We've added a custom validator to check input before processing.
5. **Safe Eval**: We're using a safer version of eval by limiting the available functions.

### Usage Examples:

```
calculator> 2 + 2
calculator> math.sin(math.pi/2)
calculator> abs(-5)
calculator> round(3.14159, 2)
```

## 7. Creating Full-Screen Applications

Prompt Toolkit also allows you to create full-screen applications. Here's a simple example of a full-screen calculator:

```python
from prompt_toolkit import Application
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.layout.containers import VSplit, HSplit, Window
from prompt_toolkit.layout.controls import BufferControl, FormattedTextControl
from prompt_toolkit.layout.layout import Layout
from prompt_toolkit.key_binding import KeyBindings

def calculate(expression):
    try:
        return eval(expression)
    except Exception as e:
        return f"Error: {str(e)}"

# Create the main input buffer
input_buffer = Buffer()

# Create the output buffer
output_buffer = Buffer()

# Create the layout
layout = Layout(
    HSplit([
        Window(FormattedTextControl("Calculator (Press Ctrl-C to exit)"), height=1),
        Window(height=1, char="-"),
        Window(BufferControl(buffer=input_buffer)),
        Window(height=1, char="-"),
        Window(BufferControl(buffer=output_buffer)),
    ])
)

# Create key bindings
kb = KeyBindings()

@kb.add('enter')
def _(event):
    result = calculate(input_buffer.text)
    output_buffer.text = f"Result: {result}"
    input_buffer.text = ""

# Create and run the application
application = Application(
    layout=layout,
    key_bindings=kb,
    full_screen=True)

def main():
    application.run()

if __name__ == "__main__":
    main()
```

This creates a full-screen calculator application with separate input and output areas.

## Conclusion

In this lesson, we've explored Prompt Toolkit, a powerful library for creating interactive command line interfaces. We've covered basic usage, cross-platform considerations, and advanced features like auto-completion, syntax highlighting, input validation, and even full-screen applications. Prompt Toolkit provides an excellent way to enhance the user experience of your CLI applications across different operating systems.

## Exercise

1. Extend the calculator application to include a help command that displays information about available operations and functions.
2. Implement a feature to save calculations to a file and load them later.
3. Add custom syntax highlighting for mathematical expressions.
4. Create a multi-line input mode for entering complex expressions.
5. Implement a feature to plot simple functions using ASCII art in the full-screen mode.
6. Ensure all features work correctly on Windows, macOS, and Linux.

By completing this exercise, you'll gain hands-on experience in using Prompt Toolkit to create sophisticated, interactive CLI applications. You'll also practice integrating Prompt Toolkit with other Python libraries and ensuring cross-platform compatibility.
