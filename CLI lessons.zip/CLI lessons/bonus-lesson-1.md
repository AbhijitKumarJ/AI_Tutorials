# Bonus Lesson 1: Project Setup and Architecture

Welcome to the first bonus lesson in our final project series! In this lesson, we'll set up our project and design its architecture. We're going to build a comprehensive CLI tool called "TaskMaster" - a feature-rich task management application.

## Project Overview

TaskMaster will allow users to:
- Create, read, update, and delete tasks
- Organize tasks into projects
- Set priorities and due dates
- View tasks in various formats (list, calendar, Kanban board)
- Generate reports and statistics
- Sync tasks with a remote server (we'll simulate this)

## Setting Up the Project

Let's start by setting up our project structure. We'll use a modular approach to keep our code organized and maintainable.

First, create a new directory for our project:

```bash
mkdir taskmaster
cd taskmaster
```

Now, let's create our project structure:

```
taskmaster/
│
├── taskmaster/
│   ├── __init__.py
│   ├── cli.py
│   ├── commands/
│   │   ├── __init__.py
│   │   ├── task.py
│   │   ├── project.py
│   │   ├── view.py
│   │   └── report.py
│   ├── models/
│   │   ├── __init__.py
│   │   ├── task.py
│   │   └── project.py
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── database.py
│   │   ├── config.py
│   │   └── formatting.py
│   └── views/
│       ├── __init__.py
│       ├── list_view.py
│       ├── calendar_view.py
│       └── kanban_view.py
├── tests/
│   ├── __init__.py
│   ├── test_cli.py
│   ├── test_models.py
│   └── test_utils.py
├── docs/
│   └── README.md
├── setup.py
├── requirements.txt
└── .gitignore
```

Let's go through each component:

- `taskmaster/`: The main package directory.
  - `cli.py`: The entry point for our CLI application.
  - `commands/`: Submodules for different command groups.
  - `models/`: Data models for tasks and projects.
  - `utils/`: Utility functions and classes.
  - `views/`: Different view implementations.
- `tests/`: Directory for our test files.
- `docs/`: Documentation directory.
- `setup.py`: Script for packaging our application.
- `requirements.txt`: List of project dependencies.
- `.gitignore`: Specifies intentionally untracked files to ignore.

## Setting Up the Virtual Environment

Before we start coding, let's set up a virtual environment:

```bash
# On Windows
python -m venv venv
venv\Scripts\activate

# On macOS and Linux
python3 -m venv venv
source venv/bin/activate
```

## Installing Dependencies

Now, let's install the libraries we'll be using:

```bash
pip install click rich prompt_toolkit pygments
pip freeze > requirements.txt
```

## Implementing the Basic CLI Structure

Let's start by implementing the basic CLI structure in `taskmaster/cli.py`:

```python
import click
from rich.console import Console

console = Console()

@click.group()
@click.version_option(version="1.0.0")
def cli():
    """TaskMaster: A comprehensive task management CLI tool."""
    pass

@cli.command()
def hello():
    """A simple command to test the CLI."""
    console.print("[bold green]Hello from TaskMaster![/bold green]")

if __name__ == "__main__":
    cli()
```

This sets up a basic Click command group and includes a simple "hello" command to test our CLI.

## Creating the Entry Point

To make our CLI executable, we need to create an entry point. Update the `setup.py` file:

```python
from setuptools import setup, find_packages

setup(
    name="taskmaster",
    version="1.0.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "Click",
        "rich",
        "prompt_toolkit",
        "pygments",
    ],
    entry_points={
        "console_scripts": [
            "taskmaster=taskmaster.cli:cli",
        ],
    },
)
```

Now, install the package in editable mode:

```bash
pip install -e .
```

You can now run TaskMaster from anywhere in your system:

```bash
taskmaster --help
taskmaster hello
```

## Implementing the Task Model

Let's implement a basic Task model in `taskmaster/models/task.py`:

```python
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

@dataclass
class Task:
    id: int
    title: str
    description: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    due_date: Optional[datetime] = None
    completed: bool = False
    priority: int = 1  # 1 (lowest) to 5 (highest)
    project_id: Optional[int] = None

    def __str__(self):
        return f"{self.id}: {self.title} (Due: {self.due_date}, Priority: {self.priority})"
```

This `Task` class will be the foundation for our task management functionality.

## Conclusion

In this lesson, we've set up the basic structure for our TaskMaster CLI tool. We've created the project layout, set up the virtual environment, installed dependencies, and implemented a basic CLI structure using Click. We've also created a simple Task model that we'll build upon in the next lessons.

In the next lesson, we'll implement the core functionality for managing tasks, including creating, reading, updating, and deleting tasks.

Remember to commit your changes to version control:

```bash
git init
git add .
git commit -m "Initial project setup for TaskMaster CLI"
```

Next up: Implementing Core Functionality!

