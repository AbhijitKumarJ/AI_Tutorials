# Lesson 2: Getting Started with Argparse

## 1. Introduction to Argparse

Argparse is a built-in Python library that makes it easy to write user-friendly command-line interfaces. It automatically generates help and usage messages and issues errors when users give the program invalid arguments. Argparse is part of Python's standard library, which means it's available in all Python installations across Windows, macOS, and Linux.

### Key Features of Argparse:

1. Automatic help message generation
2. Support for positional and optional arguments
3. Ability to set default values for arguments
4. Type conversion of arguments
5. Support for sub-commands

## 2. Basic Argparse Concepts

Before we dive into coding, let's understand some key concepts:

1. **Parser**: The main object that holds all the information about how to parse the command line.
2. **Arguments**: The inputs your program expects from the user.
   - **Positional arguments**: Required inputs, identified by their position.
   - **Optional arguments**: Inputs that aren't required and are usually preceded by a dash (-) or double dash (--).
3. **Help messages**: Automatically generated explanations of how to use your program.

## 3. Creating a Simple CLI with Argparse

Let's create a calculator application that builds upon our previous example but uses argparse for more robust argument handling.

### Project Structure:
```
argparse_calculator/
│
├── calc.py
└── README.md
```

### calc.py
```python
import argparse
import sys

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b

def main():
    parser = argparse.ArgumentParser(description="A simple calculator CLI using argparse")
    parser.add_argument("operation", choices=['add', 'subtract', 'multiply', 'divide'],
                        help="The operation to perform")
    parser.add_argument("x", type=float, help="The first number")
    parser.add_argument("y", type=float, help="The second number")

    args = parser.parse_args()

    try:
        if args.operation == 'add':
            result = add(args.x, args.y)
        elif args.operation == 'subtract':
            result = subtract(args.x, args.y)
        elif args.operation == 'multiply':
            result = multiply(args.x, args.y)
        elif args.operation == 'divide':
            result = divide(args.x, args.y)
        
        print(f"Result: {result}")
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
```

### Explanation:

1. We import `argparse` along with `sys` for error handling.
2. We define our mathematical functions: `add`, `subtract`, `multiply`, and `divide`.
3. In the `main` function:
   - We create an `ArgumentParser` object with a description of our program.
   - We add arguments using `add_argument()`:
     - `operation` is a positional argument with choices.
     - `x` and `y` are positional arguments of type float.
   - We parse the arguments using `parse_args()`.
   - We use a try-except block to handle potential errors (like division by zero).
   - Based on the operation, we call the appropriate function and print the result.

### Usage:

To use this CLI, open a terminal, navigate to the `argparse_calculator` directory, and run commands like:

```
python calc.py add 5 3
python calc.py subtract 10 4
python calc.py multiply 2 6
python calc.py divide 15 3
```

Try running `python calc.py --help` to see the automatically generated help message.

## 4. Cross-Platform Considerations with Argparse

Argparse works consistently across Windows, macOS, and Linux, but there are a few things to keep in mind:

1. **Quoting Arguments**: On Windows Command Prompt, use double quotes for arguments with spaces. On PowerShell, macOS, and Linux, you can use single or double quotes.

   Windows CMD: `python calc.py add "5.5" "3.2"`
   PowerShell/macOS/Linux: `python calc.py add '5.5' '3.2'`

2. **File Paths**: When dealing with file paths as arguments, use `os.path` functions to ensure cross-platform compatibility.

3. **Shebang Line**: For Unix-like systems (macOS and Linux), you can add a shebang line at the top of your script to make it directly executable:

   ```python
   #!/usr/bin/env python3
   ```

   This doesn't affect Windows users but allows Unix users to run the script directly (after making it executable with `chmod +x calc.py`):

   ```
   ./calc.py add 5 3
   ```

4. **Console Output**: Argparse uses `sys.stderr` for error messages, which works consistently across platforms. However, if you need colored output, consider using a library like `colorama` for cross-platform support.

## 5. Advanced Argparse Features

Let's expand our calculator to demonstrate some more advanced features of argparse:

### calc_advanced.py
```python
import argparse
import sys
import os

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b

def power(a, b):
    return a ** b

def save_result(result, filename):
    with open(filename, 'w') as f:
        f.write(str(result))

def main():
    parser = argparse.ArgumentParser(description="An advanced calculator CLI using argparse")
    parser.add_argument("-v", "--verbose", action="store_true", help="Increase output verbosity")
    parser.add_argument("-o", "--output", help="Save result to a file")

    subparsers = parser.add_subparsers(dest="operation", required=True, help="Available operations")

    # Add subparser
    parser_add = subparsers.add_parser("add", help="Addition operation")
    parser_add.add_argument("x", type=float, help="The first number")
    parser_add.add_argument("y", type=float, help="The second number")

    # Subtract subparser
    parser_subtract = subparsers.add_parser("subtract", help="Subtraction operation")
    parser_subtract.add_argument("x", type=float, help="The first number")
    parser_subtract.add_argument("y", type=float, help="The second number")

    # Multiply subparser
    parser_multiply = subparsers.add_parser("multiply", help="Multiplication operation")
    parser_multiply.add_argument("numbers", type=float, nargs="+", help="Numbers to multiply")

    # Divide subparser
    parser_divide = subparsers.add_parser("divide", help="Division operation")
    parser_divide.add_argument("x", type=float, help="The numerator")
    parser_divide.add_argument("y", type=float, help="The denominator")

    # Power subparser
    parser_power = subparsers.add_parser("power", help="Exponentiation operation")
    parser_power.add_argument("base", type=float, help="The base")
    parser_power.add_argument("exponent", type=float, help="The exponent")

    args = parser.parse_args()

    try:
        if args.operation == 'add':
            result = add(args.x, args.y)
        elif args.operation == 'subtract':
            result = subtract(args.x, args.y)
        elif args.operation == 'multiply':
            result = multiply(*args.numbers)
        elif args.operation == 'divide':
            result = divide(args.x, args.y)
        elif args.operation == 'power':
            result = power(args.base, args.exponent)
        
        if args.verbose:
            print(f"Operation: {args.operation}")
            print(f"Inputs: {vars(args)}")
        print(f"Result: {result}")

        if args.output:
            save_result(result, args.output)
            print(f"Result saved to {os.path.abspath(args.output)}")

    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
```

### New Features Explained:

1. **Optional Arguments**: We've added `-v/--verbose` and `-o/--output` as optional arguments.
2. **Subparsers**: We've created subparsers for each operation, allowing for operation-specific arguments.
3. **Variable Number of Arguments**: The multiply operation now accepts any number of arguments using `nargs="+"`.
4. **Custom Actions**: The verbose flag uses `action="store_true"` to set a boolean value.
5. **File Output**: We've added the ability to save the result to a file, demonstrating how to handle file paths.

### Usage Examples:

```
python calc_advanced.py add 5 3 -v
python calc_advanced.py subtract 10 4 --output result.txt
python calc_advanced.py multiply 2 3 4 5
python calc_advanced.py divide 15 3
python calc_advanced.py power 2 3
```

## Conclusion

In this lesson, we've explored argparse, a powerful library for creating command-line interfaces in Python. We've covered basic usage, cross-platform considerations, and advanced features like subparsers and optional arguments. Argparse provides a robust foundation for building complex CLIs that work consistently across different operating systems.

## Exercise

1. Add a new operation to the advanced calculator (e.g., calculate the average of a list of numbers).
2. Implement an optional argument that allows the user to round the result to a specified number of decimal places.
3. Add a `--version` argument that prints the version of your calculator app.
4. Create a subparser for a "scientific" mode that includes operations like sin, cos, and log. (Hint: You may want to use the `math` module for these calculations.)

By completing this exercise, you'll gain practical experience in extending an argparse-based CLI and handling various types of arguments and operations.
