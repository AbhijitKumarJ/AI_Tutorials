# Lesson 1: Introduction to Command-Line Interfaces (CLIs) - Cross-Platform Perspective

## 1. What is a CLI?

A Command-Line Interface (CLI) is a text-based method of interacting with a computer's operating system or software applications. Instead of using a graphical user interface (GUI) with windows, buttons, and menus, users type commands into a terminal or console to perform tasks, manipulate files, or run programs.

### Example of a CLI vs GUI:

**CLI example** (listing files in a directory):
- Windows: `dir`
- macOS/Linux: `ls -l`

**GUI equivalent:**
- Open File Explorer (Windows) or Finder (macOS) or File Manager (Linux)
- Navigate to the desired folder
- View the contents in a window

## 2. The Evolution of User Interfaces

1. **Early days**: Text-based interfaces were the norm (1960s-1970s)
2. **GUI revolution**: Introduction of graphical interfaces (1980s-1990s)
3. **CLI renaissance**: Resurgence of CLI tools for developers and power users (2000s-present)

## 3. Advantages and Use Cases of CLIs

### Advantages:
1. **Speed**: Faster for experienced users
2. **Efficiency**: Can perform complex tasks with a single command
3. **Automation**: Easy to script and automate repetitive tasks
4. **Resource-friendly**: Requires fewer system resources than GUIs
5. **Remote access**: Easier to use over low-bandwidth connections

### Use Cases:
1. System administration
2. Software development
3. Data processing and analysis
4. Server management
5. Automated testing and deployment

## 4. Cross-Platform CLI Differences

Understanding the differences between CLI environments on Windows, macOS, and Linux is crucial for developing cross-platform CLI applications.

### 4.1 Command Shells

- **Windows**: Command Prompt (cmd.exe), PowerShell
- **macOS**: Terminal (bash, zsh)
- **Linux**: Various terminals (bash, zsh, fish, etc.)

### 4.2 Common Commands

| Operation | Windows | macOS/Linux |
|-----------|---------|-------------|
| List files | `dir` | `ls` |
| Change directory | `cd` | `cd` |
| Clear screen | `cls` | `clear` |
| Copy file | `copy` | `cp` |
| Move file | `move` | `mv` |
| Delete file | `del` | `rm` |
| Create directory | `mkdir` | `mkdir` |

### 4.3 File System Differences

- **Windows**: Uses backslashes (`\`) for file paths
  ```
  C:\Users\Username\Documents
  ```
- **macOS/Linux**: Uses forward slashes (`/`) for file paths
  ```
  /home/username/documents
  ```

### 4.4 Environment Variables

- **Windows**: Set with `set` command, access with `%VARIABLE%`
- **macOS/Linux**: Set with `export` command, access with `$VARIABLE`

## 5. Basic Python Concepts Review

Before we dive into creating CLIs, let's review some basic Python concepts that we'll be using throughout this course.

### 5.1 Functions

Functions are reusable blocks of code that perform a specific task.

```python
def greet(name):
    return f"Hello, {name}!"

print(greet("Alice"))  # Output: Hello, Alice!
```

### 5.2 Modules

Modules are Python files containing functions, classes, and variables that can be imported and used in other Python scripts.

```python
# In math_operations.py
def add(a, b):
    return a + b

# In main.py
import math_operations

result = math_operations.add(5, 3)
print(result)  # Output: 8
```

### 5.3 File I/O

File Input/Output operations allow you to read from and write to files on your computer.

```python
# Writing to a file
with open("example.txt", "w") as file:
    file.write("Hello, World!")

# Reading from a file
with open("example.txt", "r") as file:
    content = file.read()
    print(content)  # Output: Hello, World!
```

## 6. Creating a Simple Cross-Platform CLI with Built-in Python

Now, let's create a simple CLI application using Python's built-in features. We'll make a program that greets the user, performs basic arithmetic operations, and demonstrates cross-platform file path handling.

### Project Structure:
```
simple_cli/
│
├── simple_cli.py
└── README.md
```

### simple_cli.py
```python
import sys
import os

def greet(name):
    return f"Hello, {name}!"

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def get_platform_info():
    return f"Operating System: {os.name}\nPlatform: {sys.platform}"

def get_home_directory():
    return os.path.expanduser("~")

def main():
    if len(sys.argv) < 2:
        print("Usage: python simple_cli.py <command> [args]")
        print("Commands: greet, add, subtract, platform, home")
        sys.exit(1)

    command = sys.argv[1]

    if command == "greet":
        if len(sys.argv) != 3:
            print("Usage: python simple_cli.py greet <name>")
            sys.exit(1)
        name = sys.argv[2]
        print(greet(name))
    elif command == "add":
        if len(sys.argv) != 4:
            print("Usage: python simple_cli.py add <num1> <num2>")
            sys.exit(1)
        try:
            a = float(sys.argv[2])
            b = float(sys.argv[3])
            print(f"{a} + {b} = {add(a, b)}")
        except ValueError:
            print("Error: Please provide valid numbers")
            sys.exit(1)
    elif command == "subtract":
        if len(sys.argv) != 4:
            print("Usage: python simple_cli.py subtract <num1> <num2>")
            sys.exit(1)
        try:
            a = float(sys.argv[2])
            b = float(sys.argv[3])
            print(f"{a} - {b} = {subtract(a, b)}")
        except ValueError:
            print("Error: Please provide valid numbers")
            sys.exit(1)
    elif command == "platform":
        print(get_platform_info())
    elif command == "home":
        print(f"Your home directory is: {get_home_directory()}")
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)

if __name__ == "__main__":
    main()
```

### Explanation:

1. We import the `sys` module to access command-line arguments (`sys.argv`) and the `os` module for platform-specific operations.
2. We define functions for greeting, addition, subtraction, and platform-specific information.
3. The `get_home_directory()` function uses `os.path.expanduser("~")` which works across platforms to get the user's home directory.
4. In the `main` function:
   - We check if there are enough command-line arguments.
   - We parse the command (first argument) and call the appropriate function.
   - We handle errors such as invalid number of arguments or invalid input.
   - We include platform-specific commands to demonstrate cross-platform functionality.
5. The `if __name__ == "__main__":` block ensures that `main()` is only called when the script is run directly, not when imported as a module.

### Usage:

To use this CLI, open a terminal (Command Prompt or PowerShell on Windows, Terminal on macOS/Linux), navigate to the `simple_cli` directory, and run the following commands:

```
python simple_cli.py greet Alice
python simple_cli.py add 5 3
python simple_cli.py subtract 10 4
python simple_cli.py platform
python simple_cli.py home
```

This simple CLI demonstrates the basic structure of a command-line application that works across different platforms. It takes user input from the command line, processes it, and produces output, while also providing platform-specific information.

## Cross-Platform Considerations

1. **File Paths**: Use `os.path.join()` to create file paths instead of hardcoding slashes. This ensures compatibility across operating systems.

2. **Line Endings**: When working with text files, use `open(file, 'r', newline='')` to handle different line ending conventions (CRLF on Windows, LF on Unix-like systems).

3. **Environment Variables**: Use `os.environ.get('VARIABLE_NAME')` to access environment variables in a cross-platform manner.

4. **Executable Extensions**: On Windows, command-line applications often have a `.exe` extension, while on Unix-like systems they don't. Use `sys.executable` to get the path of the Python interpreter if you need to run Python scripts from within your application.

5. **Console Output**: Be aware that color and formatting support may vary between different terminals. Libraries like `colorama` can help provide consistent colored output across platforms.

## Conclusion

In this lesson, we've introduced the concept of Command-Line Interfaces, discussed their evolution and advantages, reviewed basic Python concepts, and created a simple cross-platform CLI application using built-in Python features. We've also highlighted key differences in CLI usage and implementation across Windows, macOS, and Linux.

As we progress through this course, we'll explore more advanced libraries and techniques for building sophisticated CLI applications that work seamlessly across different operating systems. In the next lesson, we'll dive into `argparse`, Python's built-in library for parsing command-line arguments, which will allow us to create more flexible and user-friendly CLIs.

## Exercise

1. Extend the `simple_cli.py` script to include two more mathematical operations: multiplication and division.
2. Add error handling for division by zero.
3. Implement a "help" command that displays information about all available commands.
4. Create a function that lists the contents of a directory, accounting for the differences between `dir` (Windows) and `ls` (macOS/Linux).

By completing this exercise, you'll gain hands-on experience in expanding a CLI application, handling edge cases, and dealing with platform-specific differences, which are crucial skills for cross-platform CLI development.
