# Lesson 11: Crafting Command Suites with Python Fire

Welcome to the eleventh lesson in our "Mastering Python CLI Libraries: From Novice to Expert" series! In this lesson, we'll explore Python Fire, a library that automatically generates command-line interfaces (CLIs) from Python objects. Python Fire offers a unique approach to creating CLIs, allowing you to quickly turn any Python object into a command-line tool.

## Table of Contents
1. [Introduction](#introduction)
2. [Project Setup](#project-setup)
3. [Basic Python Fire Usage](#basic-python-fire-usage)
4. [Creating a Command Suite](#creating-a-command-suite)
5. [Working with Classes](#working-with-classes)
6. [Nested Commands](#nested-commands)
7. [Handling Arguments and Flags](#handling-arguments-and-flags)
8. [Customizing Help Messages](#customizing-help-messages)
9. [Fire CLI Features](#fire-cli-features)
10. [Cross-Platform Considerations](#cross-platform-considerations)
11. [When to Use Python Fire](#when-to-use-python-fire)
12. [Conclusion](#conclusion)

## Introduction

Python Fire is a library that turns any Python object into a command-line interface with just a single call to `Fire()`. It's particularly useful for quickly prototyping CLIs or for creating command suites from existing Python code. While it may not offer the same level of customization as libraries like Click or Typer, its simplicity and flexibility make it an valuable tool in certain scenarios.

## Project Setup

Let's start by setting up our project. We'll create a new directory for this lesson and install the required packages.

```
python_fire_cli/
├── requirements.txt
├── basic_fire.py
├── command_suite.py
├── class_example.py
├── nested_commands.py
├── args_and_flags.py
├── custom_help.py
└── fire_features.py
```

First, create a new directory called `python_fire_cli` and navigate into it:

```bash
mkdir python_fire_cli
cd python_fire_cli
```

Now, create a `requirements.txt` file with the following content:

```
fire==0.5.0
```

Install the required package:

```bash
pip install -r requirements.txt
```

## Basic Python Fire Usage

Let's start with a simple example to understand the basics of Python Fire. Create a file named `basic_fire.py` with the following content:

```python
import fire

def hello(name="World"):
    return f"Hello {name}!"

def calculator(x, y):
    return {
        "sum": x + y,
        "difference": x - y,
        "product": x * y,
        "quotient": x / y if y != 0 else "Cannot divide by zero"
    }

if __name__ == '__main__':
    fire.Fire()
```

This script demonstrates basic usage of Python Fire. Run the script to test the automatically generated CLI:

```bash
python basic_fire.py hello
python basic_fire.py hello --name="Alice"
python basic_fire.py calculator 10 5
python basic_fire.py calculator --x=10 --y=5
```

Notice how Python Fire automatically creates a CLI for the functions in our script, handling arguments and named parameters.

## Creating a Command Suite

Python Fire makes it easy to create a suite of commands. Create a file named `command_suite.py` with the following content:

```python
import fire

class GitCommands:
    def status(self):
        return "Checking the status of the repository"

    def commit(self, message):
        return f"Committing changes with message: {message}"

    def push(self, remote="origin", branch="main"):
        return f"Pushing to {remote}/{branch}"

class DockerCommands:
    def build(self, tag):
        return f"Building Docker image with tag: {tag}"

    def run(self, image, port=None):
        if port:
            return f"Running Docker image {image} and mapping to port {port}"
        return f"Running Docker image {image}"

class CLI:
    def __init__(self):
        self.git = GitCommands()
        self.docker = DockerCommands()

if __name__ == '__main__':
    fire.Fire(CLI)
```

This script creates a command suite with `git` and `docker` subcommands. Run the script to test the command suite:

```bash
python command_suite.py git status
python command_suite.py git commit "Initial commit"
python command_suite.py git push
python command_suite.py docker build v1.0
python command_suite.py docker run myimage --port=8080
```

## Working with Classes

Python Fire can generate CLIs from class methods. Create a file named `class_example.py` with the following content:

```python
import fire

class TodoList:
    def __init__(self):
        self.todos = []

    def add(self, task):
        self.todos.append(task)
        return f"Added task: {task}"

    def list(self):
        return "\n".join(f"{i+1}. {task}" for i, task in enumerate(self.todos))

    def remove(self, index):
        if 1 <= index <= len(self.todos):
            task = self.todos.pop(index - 1)
            return f"Removed task: {task}"
        return "Invalid task index"

    def clear(self):
        self.todos.clear()
        return "All tasks cleared"

if __name__ == '__main__':
    fire.Fire(TodoList)
```

This script demonstrates how Python Fire can work with classes. Run the script to test the Todo List CLI:

```bash
python class_example.py add "Buy groceries"
python class_example.py add "Finish homework"
python class_example.py list
python class_example.py remove 1
python class_example.py list
python class_example.py clear
```

## Nested Commands

Python Fire can handle nested commands using class hierarchies. Create a file named `nested_commands.py` with the following content:

```python
import fire

class DatabaseCommands:
    class Tables:
        def list(self):
            return "Listing all tables"

        def describe(self, table_name):
            return f"Describing table: {table_name}"

    class Users:
        def create(self, username, email):
            return f"Creating user: {username} ({email})"

        def delete(self, user_id):
            return f"Deleting user with ID: {user_id}"

    def __init__(self):
        self.tables = self.Tables()
        self.users = self.Users()

    def connect(self, host, port=3306):
        return f"Connecting to database at {host}:{port}"

class CLI:
    def __init__(self):
        self.db = DatabaseCommands()

if __name__ == '__main__':
    fire.Fire(CLI)
```

This script demonstrates how to create nested commands using class hierarchies. Run the script to test the nested commands:

```bash
python nested_commands.py db connect localhost
python nested_commands.py db tables list
python nested_commands.py db tables describe users
python nested_commands.py db users create john john@example.com
python nested_commands.py db users delete 123
```

## Handling Arguments and Flags

Python Fire automatically handles arguments and flags, but you can also explicitly define them. Create a file named `args_and_flags.py` with the following content:

```python
import fire

def greet(name, enthusiastic=False, caps=False):
    greeting = f"Hello, {name}!"
    if enthusiastic:
        greeting += "!!"
    if caps:
        greeting = greeting.upper()
    return greeting

def repeat(text, times=1, separator=" "):
    return separator.join([text] * times)

class ArgsExample:
    def __init__(self):
        self.greet = greet
        self.repeat = repeat

if __name__ == '__main__':
    fire.Fire(ArgsExample)
```

This script shows how Python Fire handles different types of arguments and flags. Run the script to test argument and flag handling:

```bash
python args_and_flags.py greet Alice
python args_and_flags.py greet Bob --enthusiastic
python args_and_flags.py greet Charlie --caps
python args_and_flags.py greet David --enthusiastic --caps
python args_and_flags.py repeat "Hello" --times=3
python args_and_flags.py repeat "Hello" --times=3 --separator=", "
```

## Customizing Help Messages

While Python Fire generates help messages automatically, you can customize them using docstrings. Create a file named `custom_help.py` with the following content:

```python
import fire

class CustomHelp:
    """A sample CLI with custom help messages."""

    def hello(self, name="World"):
        """
        Greet someone by name.

        Args:
            name: The name of the person to greet (default: "World")
        
        Returns:
            A greeting message
        """
        return f"Hello, {name}!"

    def calculate(self, operation, x, y):
        """
        Perform a calculation on two numbers.

        Args:
            operation: The operation to perform (add, subtract, multiply, divide)
            x: The first number
            y: The second number
        
        Returns:
            The result of the calculation
        """
        if operation == "add":
            return x + y
        elif operation == "subtract":
            return x - y
        elif operation == "multiply":
            return x * y
        elif operation == "divide":
            return x / y if y != 0 else "Cannot divide by zero"
        else:
            return "Invalid operation"

if __name__ == '__main__':
    fire.Fire(CustomHelp)
```

This script demonstrates how to use docstrings to customize help messages. Run the script to see the custom help messages:

```bash
python custom_help.py --help
python custom_help.py hello --help
python custom_help.py calculate --help
```

## Fire CLI Features

Python Fire provides some built-in CLI features. Create a file named `fire_features.py` with the following content:

```python
import fire

class FireFeatures:
    def simple_command(self):
        return "This is a simple command"

    def command_with_args(self, arg1, arg2):
        return f"Arguments: {arg1}, {arg2}"

    def command_with_kwargs(self, **kwargs):
        return f"Keyword arguments: {kwargs}"

if __name__ == '__main__':
    fire.Fire(FireFeatures)
```

This script demonstrates some of Python Fire's built-in CLI features. Run the script with different Fire CLI features:

```bash
python fire_features.py -- --help
python fire_features.py simple-command -- --trace
python fire_features.py command-with-args 1 2 -- --verbose
python fire_features.py command-with-kwargs --key1=value1 --key2=value2
python fire_features.py -- --completion bash
```

## Cross-Platform Considerations

When developing CLI applications with Python Fire, keep these cross-platform considerations in mind:

1. File paths: Use `os.path` or `pathlib.Path` for handling file paths to ensure compatibility across different operating systems.

2. Environment variables: Access environment variables using `os.environ` for cross-platform compatibility.

3. Executables: If your application needs to run external commands, consider using the `subprocess` module with the `shell=True` parameter set to `False` for better cross-platform support.

4. Line endings: When reading or writing files, open them in text mode with universal newlines: `open(file, 'r', newline=None)` for reading, and `open(file, 'w', newline='')` for writing.

5. Console output: Be aware that different platforms may have different default encodings for console output. You may need to handle encoding explicitly in some cases.

6. Colored output: If you want to add colored output to your Fire CLI, consider using a cross-platform library like `colorama` to ensure consistent behavior across different operating systems.

## When to Use Python Fire

Python Fire is particularly useful in the following scenarios:

1. Rapid prototyping: Quickly create a CLI for existing Python code without writing additional interface code.

2. Exploratory data analysis: Turn data analysis scripts into interactive command-line tools for easy experimentation.

3. Converting libraries to CLIs: Easily expose library functionality as a command-line interface.

4. Creating simple admin tools: Quickly build internal tools for system administration or development tasks.

5. Learning and teaching: Use Fire to demonstrate how Python objects and functions work in an interactive CLI environment.

However, for more complex CLI applications that require fine-grained control over argument parsing, input validation, or custom formatting, you might prefer libraries like Click or Typer, which we covered in previous lessons.

## Conclusion

In this lesson, we've explored Python Fire and its capabilities for automatically generating command-line interfaces from Python objects. We've covered basic usage, creating command suites, working with classes, nested commands, handling arguments and flags, and customizing help messages.

Python Fire offers a unique approach to CLI development, allowing you to quickly turn any Python object into a command-line tool with minimal additional code. While it may not offer the same level of customization as other CLI libraries, its simplicity and flexibility make it a valuable tool in certain scenarios.

In the next lesson, we'll explore Docopt, another interesting library for creating command-line interfaces by parsing usage messages.
