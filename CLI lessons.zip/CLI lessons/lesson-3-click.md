# Lesson 3: Leveling Up with Click

## 1. Introduction to Click

Click (Command Line Interface Creation Kit) is a Python package for creating beautiful command line interfaces in a composable way with as little code as necessary. It's highly configurable but comes with sensible defaults out of the box.

### Key Features of Click:

1. Arbitrary nesting of commands
2. Automatic help page generation
3. Supports lazy loading of subcommands at runtime
4. Supports implementation of Unix/POSIX command line conventions
5. Extensively documented
6. Composable and easily extensible

## 2. Installing Click

Before we start, we need to install Click. It's not part of the Python standard library, so we'll use pip to install it:

```
pip install click
```

This command works across Windows, macOS, and Linux.

## 3. Basic Click Concepts

Before we dive into coding, let's understand some key concepts:

1. **Decorators**: Click uses decorators heavily to define commands and options.
2. **Command**: The main function that serves as the entry point for your CLI.
3. **Options**: Optional parameters that modify the behavior of a command.
4. **Arguments**: Required inputs for a command.
5. **Groups**: A way to organize multiple related commands.

## 4. Creating a Simple CLI with Click

Let's recreate our calculator application using Click. We'll start with a basic version and then expand it to show more features.

### Project Structure:
```
click_calculator/
│
├── calc.py
└── README.md
```

### calc.py
```python
import click

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        raise click.ClickException("Cannot divide by zero")
    return a / b

@click.group()
def cli():
    """A simple calculator CLI using Click"""
    pass

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
def add_cmd(x, y):
    """Add two numbers"""
    result = add(x, y)
    click.echo(f"Result: {result}")

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
def subtract_cmd(x, y):
    """Subtract two numbers"""
    result = subtract(x, y)
    click.echo(f"Result: {result}")

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
def multiply_cmd(x, y):
    """Multiply two numbers"""
    result = multiply(x, y)
    click.echo(f"Result: {result}")

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
def divide_cmd(x, y):
    """Divide two numbers"""
    try:
        result = divide(x, y)
        click.echo(f"Result: {result}")
    except click.ClickException as e:
        click.echo(str(e), err=True)

if __name__ == '__main__':
    cli()
```

### Explanation:

1. We import `click` at the beginning of our script.
2. We define our mathematical functions as before.
3. We use the `@click.group()` decorator to create a command group named `cli`.
4. Each operation is defined as a separate command using the `@cli.command()` decorator.
5. We use `@click.argument()` to define the inputs for each command.
6. Within each command function, we call our mathematical functions and use `click.echo()` to print the result.
7. We use `click.ClickException` for error handling in the divide function.
8. The `if __name__ == '__main__':` block calls our main `cli()` function.

### Usage:

To use this CLI, open a terminal, navigate to the `click_calculator` directory, and run commands like:

```
python calc.py add 5 3
python calc.py subtract 10 4
python calc.py multiply 2 6
python calc.py divide 15 3
```

Try running `python calc.py --help` to see the automatically generated help message.

## 5. Cross-Platform Considerations with Click

Click is designed to work consistently across different platforms, but there are still some considerations:

1. **Terminal Colors**: Click automatically detects color support, but you can force enable or disable it:
   ```python
   import click
   click.echo(click.style('Hello World!', fg='green'), color=True)
   ```

2. **File Paths**: Use `click.Path()` for handling file paths in a cross-platform manner:
   ```python
   @click.option('--file', type=click.Path(exists=True))
   ```

3. **Environment Variables**: Click can read option values from environment variables:
   ```python
   @click.option('--name', envvar='USER')
   ```

4. **Launching Editors**: Click provides a cross-platform way to launch editors:
   ```python
   click.edit(filename='test.txt')
   ```

## 6. Advanced Click Features

Let's expand our calculator to demonstrate some more advanced features of Click:

### calc_advanced.py
```python
import click
import os

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(numbers):
    result = 1
    for num in numbers:
        result *= num
    return result

def divide(a, b):
    if b == 0:
        raise click.ClickException("Cannot divide by zero")
    return a / b

def power(a, b):
    return a ** b

@click.group()
@click.version_option(version='1.0.0')
@click.option('--verbose', '-v', is_flag=True, help='Enables verbose mode')
@click.pass_context
def cli(ctx, verbose):
    """An advanced calculator CLI using Click"""
    ctx.ensure_object(dict)
    ctx.obj['VERBOSE'] = verbose

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
@click.option('--output', '-o', type=click.Path(), help='Save result to a file')
@click.pass_context
def add_cmd(ctx, x, y, output):
    """Add two numbers"""
    result = add(x, y)
    if ctx.obj['VERBOSE']:
        click.echo(f"Adding {x} and {y}")
    click.echo(f"Result: {result}")
    if output:
        with open(output, 'w') as f:
            f.write(str(result))
        click.echo(f"Result saved to {os.path.abspath(output)}")

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
@click.pass_context
def subtract_cmd(ctx, x, y):
    """Subtract two numbers"""
    result = subtract(x, y)
    if ctx.obj['VERBOSE']:
        click.echo(f"Subtracting {y} from {x}")
    click.echo(f"Result: {result}")

@cli.command()
@click.argument('numbers', type=float, nargs=-1, required=True)
@click.pass_context
def multiply_cmd(ctx, numbers):
    """Multiply a series of numbers"""
    result = multiply(numbers)
    if ctx.obj['VERBOSE']:
        click.echo(f"Multiplying {', '.join(map(str, numbers))}")
    click.echo(f"Result: {result}")

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
@click.pass_context
def divide_cmd(ctx, x, y):
    """Divide two numbers"""
    try:
        result = divide(x, y)
        if ctx.obj['VERBOSE']:
            click.echo(f"Dividing {x} by {y}")
        click.echo(f"Result: {result}")
    except click.ClickException as e:
        click.echo(str(e), err=True)

@cli.command()
@click.argument('base', type=float)
@click.argument('exponent', type=float)
@click.pass_context
def power_cmd(ctx, base, exponent):
    """Raise a number to a power"""
    result = power(base, exponent)
    if ctx.obj['VERBOSE']:
        click.echo(f"Raising {base} to the power of {exponent}")
    click.echo(f"Result: {result}")

if __name__ == '__main__':
    cli(obj={})
```

### New Features Explained:

1. **Version Option**: We've added a `--version` option using `@click.version_option()`.
2. **Global Options**: We've added a `--verbose` flag that applies to all commands.
3. **Context Object**: We use `@click.pass_context` to pass a context object between functions.
4. **Variable Number of Arguments**: The multiply command now accepts any number of arguments using `nargs=-1`.
5. **File Output**: We've added an option to save the result to a file in the add command.
6. **Custom Help Text**: Each command and the main group have custom help text.

### Usage Examples:

```
python calc_advanced.py --help
python calc_advanced.py --version
python calc_advanced.py add 5 3 -v
python calc_advanced.py subtract 10 4 --verbose
python calc_advanced.py multiply 2 3 4 5
python calc_advanced.py divide 15 3
python calc_advanced.py power 2 3
python calc_advanced.py add 5 3 --output result.txt
```

## Conclusion

In this lesson, we've explored Click, a powerful and user-friendly library for creating command-line interfaces in Python. We've covered basic usage, cross-platform considerations, and advanced features like command groups, options, and context objects. Click provides an intuitive and expressive way to build complex CLIs that work consistently across different operating systems.

## Exercise

1. Add a new command to the advanced calculator that calculates the average of a list of numbers.
2. Implement a global option that allows the user to round all results to a specified number of decimal places.
3. Create a new command group for "scientific" operations (sin, cos, log, etc.) and add it as a subcommand to the main CLI. (Hint: You may want to use the `math` module for these calculations.)
4. Add command aliases for common operations (e.g., 'a' for 'add', 's' for 'subtract').
5. Implement a `--quiet` option that suppresses all output except for errors. Make sure it works correctly with the `--verbose` option.

By completing this exercise, you'll gain hands-on experience in extending a Click-based CLI, working with nested command groups, and implementing various types of options and arguments.
