# Lesson 17: Real-world CLI Project

## Introduction

Welcome to the final lesson of our "Mastering Python CLI Libraries: From Novice to Expert" series! In this lesson, we'll apply everything we've learned to create a comprehensive, real-world CLI application. We'll build a powerful DevOps tool called "DevOpsHelper" that assists developers and operations teams in managing their development and deployment processes.

By the end of this lesson, you'll understand how to:

1. Plan and structure a complex CLI application
2. Implement advanced features using multiple libraries
3. Apply best practices in code organization, testing, and documentation
4. Create a user-friendly CLI interface for complex operations
5. Package and distribute a production-ready CLI tool

Let's start by outlining our DevOpsHelper project:

```
devopshelper/
│
├── devopshelper/
│   ├── __init__.py
│   ├── cli.py
│   ├── commands/
│   │   ├── __init__.py
│   │   ├── project.py
│   │   ├── environment.py
│   │   ├── deploy.py
│   │   ├── monitor.py
│   │   └── report.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── git_service.py
│   │   ├── docker_service.py
│   │   ├── aws_service.py
│   │   └── monitoring_service.py
│   ├── models/
│   │   ├── __init__.py
│   │   ├── project.py
│   │   ├── environment.py
│   │   └── deployment.py
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── config.py
│   │   ├── logger.py
│   │   └── exceptions.py
│   └── ui/
│       ├── __init__.py
│       └── prompts.py
│
├── tests/
│   ├── __init__.py
│   ├── test_cli.py
│   ├── test_commands/
│   ├── test_services/
│   └── test_models/
│
├── docs/
│   ├── index.md
│   ├── installation.md
│   ├── usage.md
│   └── api/
│
├── config.yaml
├── requirements.txt
├── setup.py
├── MANIFEST.in
├── README.md
├── CHANGELOG.md
├── LICENSE
└── .github/
    └── workflows/
        ├── ci.yml
        └── release.yml
```

Now, let's implement the core functionality of our DevOpsHelper.

## 1. Planning and Structuring the Application

Our DevOpsHelper will have the following main features:

1. Project management
2. Environment management
3. Deployment automation
4. Monitoring and alerting
5. Reporting

Let's start by implementing the core CLI structure in `devopshelper/cli.py`:

```python
import click
from rich.console import Console
from devopshelper.commands import project, environment, deploy, monitor, report
from devopshelper.utils.config import load_config
from devopshelper.utils.logger import setup_logger

console = Console()
config = load_config()
logger = setup_logger()

@click.group()
@click.version_option()
def cli():
    """DevOpsHelper - A comprehensive DevOps CLI tool."""
    pass

cli.add_command(project.project)
cli.add_command(environment.environment)
cli.add_command(deploy.deploy)
cli.add_command(monitor.monitor)
cli.add_command(report.report)

if __name__ == '__main__':
    cli()
```

## 2. Implementing Advanced Features

Let's implement the project management feature using Click, Rich, and SQLAlchemy. First, create `devopshelper/models/project.py`:

```python
from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class Project(Base):
    __tablename__ = 'projects'

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False, unique=True)
    repository_url = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<Project(id={self.id}, name='{self.name}')>"
```

Now, let's implement the project commands in `devopshelper/commands/project.py`:

```python
import click
from rich.table import Table
from rich.console import Console
from devopshelper.models.project import Project
from devopshelper.services.git_service import GitService
from devopshelper.utils.config import get_session

console = Console()
git_service = GitService()

@click.group()
def project():
    """Manage projects."""
    pass

@project.command()
@click.option('--name', prompt='Project name', help='Name of the project')
@click.option('--repo', prompt='Repository URL', help='Git repository URL')
def create(name, repo):
    """Create a new project."""
    session = get_session()
    
    if not git_service.is_valid_repo(repo):
        console.print(f"[bold red]Error:[/] Invalid repository URL: {repo}")
        return

    new_project = Project(name=name, repository_url=repo)
    session.add(new_project)
    session.commit()

    console.print(f"[bold green]Success:[/] Project '{name}' created.")

@project.command()
def list():
    """List all projects."""
    session = get_session()
    projects = session.query(Project).all()

    table = Table(title="Projects")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="magenta")
    table.add_column("Repository", style="green")
    table.add_column("Created At", style="yellow")

    for proj in projects:
        table.add_row(
            str(proj.id),
            proj.name,
            proj.repository_url,
            proj.created_at.strftime("%Y-%m-%d %H:%M:%S")
        )

    console.print(table)

# Implement update and delete commands here
```

## 3. Applying Best Practices

Let's apply some best practices by implementing proper error handling, logging, and configuration management. 

In `devopshelper/utils/exceptions.py`:

```python
class DevOpsHelperException(Exception):
    """Base exception for DevOpsHelper."""
    pass

class ProjectAlreadyExistsError(DevOpsHelperException):
    """Raised when trying to create a project that already exists."""
    pass

class InvalidRepositoryError(DevOpsHelperException):
    """Raised when an invalid repository URL is provided."""
    pass
```

Update `devopshelper/utils/config.py`:

```python
import os
import yaml
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

config_path = os.path.join(os.path.dirname(__file__), '..', '..', 'config.yaml')

def load_config():
    with open(config_path, 'r') as config_file:
        return yaml.safe_load(config_file)

config = load_config()

engine = create_engine(config['database']['url'])
Session = sessionmaker(bind=engine)

def get_session():
    return Session()
```

Now, let's update our `project.py` to use these best practices:

```python
import click
from rich.table import Table
from rich.console import Console
from devopshelper.models.project import Project
from devopshelper.services.git_service import GitService
from devopshelper.utils.config import get_session
from devopshelper.utils.exceptions import ProjectAlreadyExistsError, InvalidRepositoryError
from devopshelper.utils.logger import logger

console = Console()
git_service = GitService()

@click.group()
def project():
    """Manage projects."""
    pass

@project.command()
@click.option('--name', prompt='Project name', help='Name of the project')
@click.option('--repo', prompt='Repository URL', help='Git repository URL')
def create(name, repo):
    """Create a new project."""
    session = get_session()
    
    try:
        if not git_service.is_valid_repo(repo):
            raise InvalidRepositoryError(f"Invalid repository URL: {repo}")

        new_project = Project(name=name, repository_url=repo)
        session.add(new_project)
        session.commit()

        logger.info(f"Project created: {name}")
        console.print(f"[bold green]Success:[/] Project '{name}' created.")
    except ProjectAlreadyExistsError:
        logger.error(f"Attempted to create existing project: {name}")
        console.print(f"[bold red]Error:[/] Project '{name}' already exists.")
    except InvalidRepositoryError as e:
        logger.error(str(e))
        console.print(f"[bold red]Error:[/] {str(e)}")
    except Exception as e:
        logger.exception("Unexpected error during project creation")
        console.print(f"[bold red]Error:[/] An unexpected error occurred. Please check the logs.")
    finally:
        session.close()

# Update list, update, and delete commands similarly
```

## 4. Creating a User-friendly Interface

To make our CLI more user-friendly, let's implement some interactive prompts and progress bars. Update `devopshelper/ui/prompts.py`:

```python
from prompt_toolkit import prompt
from prompt_toolkit.completion import WordCompleter
from rich.progress import Progress

def get_project_details():
    name = prompt("Project name: ")
    repo = prompt("Repository URL: ")
    return name, repo

def confirm_action(message):
    return prompt(f"{message} (y/n): ").lower() == 'y'

def show_progress(message, num_steps):
    with Progress() as progress:
        task = progress.add_task(message, total=num_steps)
        while not progress.finished:
            yield
            progress.update(task, advance=1)
```

Now, let's update our `create` command to use these prompts:

```python
@project.command()
def create():
    """Create a new project."""
    name, repo = get_project_details()
    
    if confirm_action(f"Create project '{name}' with repository '{repo}'?"):
        session = get_session()
        
        try:
            for _ in show_progress("Creating project", 3):
                if not git_service.is_valid_repo(repo):
                    raise InvalidRepositoryError(f"Invalid repository URL: {repo}")

                new_project = Project(name=name, repository_url=repo)
                session.add(new_project)
                session.commit()

            logger.info(f"Project created: {name}")
            console.print(f"[bold green]Success:[/] Project '{name}' created.")
        except ProjectAlreadyExistsError:
            logger.error(f"Attempted to create existing project: {name}")
            console.print(f"[bold red]Error:[/] Project '{name}' already exists.")
        except InvalidRepositoryError as e:
            logger.error(str(e))
            console.print(f"[bold red]Error:[/] {str(e)}")
        except Exception as e:
            logger.exception("Unexpected error during project creation")
            console.print(f"[bold red]Error:[/] An unexpected error occurred. Please check the logs.")
        finally:
            session.close()
    else:
        console.print("Project creation cancelled.")
```

## 5. Packaging and Distribution

To package our DevOpsHelper for distribution, let's update our `setup.py`:

```python
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="devopshelper",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A comprehensive DevOps CLI tool",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/devopshelper",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "click",
        "rich",
        "prompt-toolkit",
        "sqlalchemy",
        "pyyaml",
        "gitpython",
    ],
    entry_points={
        "console_scripts": [
            "devopshelper=devopshelper.cli:cli",
        ],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
    ],
    python_requires=">=3.7",
)
```

Don't forget to create a `MANIFEST.in` file to include non-Python files:

```
include README.md
include LICENSE
include config.yaml
recursive-include devopshelper *.py
recursive-include docs *.md
```

## Conclusion

In this final lesson, we've created a real-world CLI project called DevOpsHelper, which demonstrates how to:

1. Plan and structure a complex CLI application
2. Implement advanced features using multiple libraries
3. Apply best practices in code organization, testing, and documentation
4. Create a user-friendly CLI interface for complex operations
5. Package and distribute a production-ready CLI tool

This project serves as a foundation that you can extend with more features, such as environment management, deployment automation, monitoring, and reporting.

## Exercise

1. Implement the remaining CRUD operations for the Project model (update and delete).
2. Add environment management functionality, including creating, listing, and deleting environments for projects.
3. Implement a basic deployment command that simulates deploying a project to an environment.
4. Create unit tests for all the implemented commands and services.
5. Write user documentation explaining how to install and use DevOpsHelper.

Congratulations on completing the "Mastering Python CLI Libraries: From Novice to Expert" series! You now have the knowledge and skills to create sophisticated, user-friendly, and maintainable CLI applications for real-world scenarios. Keep practicing and exploring new libraries and techniques to further enhance your CLI development skills. Happy coding!
