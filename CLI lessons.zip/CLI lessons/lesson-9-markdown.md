# Lesson 9: Syntax Highlighting with Pygments

Welcome to the ninth lesson in our "Mastering Python CLI Libraries: From Novice to Expert" series! In this lesson, we'll explore Pygments, a powerful syntax highlighting library for Python. We'll learn how to use Pygments to add color and style to code snippets in your command-line interfaces, making them more readable and user-friendly.

## Table of Contents
1. [Introduction](#introduction)
2. [Project Setup](#project-setup)
3. [Basic Syntax Highlighting](#basic-syntax-highlighting)
4. [Using Different Lexers](#using-different-lexers)
5. [Custom Lexers](#custom-lexers)
6. [Output Formats](#output-formats)
7. [Integrating with Rich](#integrating-with-rich)
8. [Integrating with Prompt Toolkit](#integrating-with-prompt-toolkit)
9. [Cross-Platform Considerations](#cross-platform-considerations)
10. [Conclusion](#conclusion)

## Introduction

Pygments is a versatile syntax highlighting library that supports a wide range of programming languages and markup formats. It can be used to add color and style to code snippets, making them easier to read and understand. This is particularly useful when creating CLI tools that display or work with source code.

## Project Setup

Let's start by setting up our project. We'll create a new directory for this lesson and install the required packages.

```
pygments_cli/
├── requirements.txt
├── basic_highlight.py
├── multiple_lexers.py
├── custom_lexer.py
├── output_formats.py
├── rich_integration.py
└── prompt_toolkit_integration.py
```

First, create a new directory called `pygments_cli` and navigate into it:

```bash
mkdir pygments_cli
cd pygments_cli
```

Now, create a `requirements.txt` file with the following content:

```
pygments==2.15.1
rich==13.3.5
prompt_toolkit==3.0.38
```

Install the required packages:

```bash
pip install -r requirements.txt
```

## Basic Syntax Highlighting

Let's start with a simple example of how to use Pygments for basic syntax highlighting. Create a file named `basic_highlight.py` with the following content:

```python
from pygments import highlight
from pygments.lexers import PythonLexer
from pygments.formatters import TerminalFormatter

code = """
def greet(name):
    print(f"Hello, {name}!")

greet("World")
"""

highlighted_code = highlight(code, PythonLexer(), TerminalFormatter())
print(highlighted_code)
```

This script demonstrates how to highlight Python code using Pygments. Run the script to see the highlighted output:

```bash
python basic_highlight.py
```

## Using Different Lexers

Pygments supports many programming languages and file formats. Let's create an example that allows the user to choose a language for highlighting. Create a file named `multiple_lexers.py` with the following content:

```python
from pygments import highlight
from pygments.lexers import get_lexer_by_name
from pygments.formatters import TerminalFormatter

languages = {
    'python': 'print("Hello, World!")',
    'javascript': 'console.log("Hello, World!");',
    'html': '<h1>Hello, World!</h1>',
    'css': 'body { background-color: #f0f0f0; }',
}

def highlight_code(language, code):
    lexer = get_lexer_by_name(language)
    return highlight(code, lexer, TerminalFormatter())

def main():
    print("Available languages:", ", ".join(languages.keys()))
    language = input("Enter a language: ").lower()
    
    if language in languages:
        code = languages[language]
        highlighted_code = highlight_code(language, code)
        print("\nHighlighted code:")
        print(highlighted_code)
    else:
        print("Language not supported.")

if __name__ == '__main__':
    main()
```

This script allows the user to choose a language and then highlights a sample code snippet in that language. Run the script to test different language highlighting:

```bash
python multiple_lexers.py
```

## Custom Lexers

Sometimes you might need to highlight a custom language or format. Pygments allows you to create custom lexers for such cases. Let's create a simple custom lexer for a hypothetical configuration file format. Create a file named `custom_lexer.py` with the following content:

```python
from pygments.lexer import RegexLexer
from pygments.token import *
from pygments import highlight
from pygments.formatters import TerminalFormatter

class ConfigLexer(RegexLexer):
    name = 'Config'
    aliases = ['config']
    filenames = ['*.cfg']

    tokens = {
        'root': [
            (r'#.*?\n', Comment),
            (r'\[.*?\]', Keyword),
            (r'(.*?)(=)(.*?)(\n)',
             bygroups(Name.Attribute, Operator, String, Text)),
        ]
    }

config_code = """
# Sample configuration file
[General]
name = My Application
version = 1.0.0

[Database]
host = localhost
port = 5432
"""

highlighted_config = highlight(config_code, ConfigLexer(), TerminalFormatter())
print(highlighted_config)
```

This script defines a custom lexer for a simple configuration file format and uses it to highlight a sample configuration. Run the script to see the custom highlighting:

```bash
python custom_lexer.py
```

## Output Formats

Pygments supports various output formats beyond terminal output. Let's explore HTML output, which can be useful for generating documentation or web-based tools. Create a file named `output_formats.py` with the following content:

```python
from pygments import highlight
from pygments.lexers import PythonLexer
from pygments.formatters import HtmlFormatter

code = """
def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)

print(factorial(5))
"""

html_code = highlight(code, PythonLexer(), HtmlFormatter(linenos=True, style='monokai'))
css = HtmlFormatter(style='monokai').get_style_defs('.highlight')

html_output = f"""
<html>
<head>
    <style>
        {css}
    </style>
</head>
<body>
    {html_code}
</body>
</html>
"""

with open('highlighted_code.html', 'w') as f:
    f.write(html_output)

print("HTML file 'highlighted_code.html' has been created.")
```

This script generates an HTML file with syntax-highlighted Python code. Run the script to create the HTML file:

```bash
python output_formats.py
```

After running the script, open the `highlighted_code.html` file in a web browser to see the result.

## Integrating with Rich

Rich, which we covered in previous lessons, has built-in support for Pygments. Let's create an example that uses Rich to display syntax-highlighted code. Create a file named `rich_integration.py` with the following content:

```python
from rich.console import Console
from rich.syntax import Syntax

console = Console()

code = """
def quicksort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quicksort(left) + middle + quicksort(right)

print(quicksort([3, 6, 8, 10, 1, 2, 1]))
"""

syntax = Syntax(code, "python", theme="monokai", line_numbers=True)
console.print(syntax)
```

This script uses Rich to display syntax-highlighted Python code with line numbers. Run the script to see the Rich-formatted output:

```bash
python rich_integration.py
```

## Integrating with Prompt Toolkit

We can also integrate Pygments with Prompt Toolkit to create syntax-highlighted prompts or text areas. Let's create an example that allows users to input Python code and see it highlighted in real-time. Create a file named `prompt_toolkit_integration.py` with the following content:

```python
from prompt_toolkit import PromptSession
from prompt_toolkit.lexers import PygmentsLexer
from pygments.lexers.python import PythonLexer
from prompt_toolkit.styles import Style
from pygments.styles import get_style_by_name

style = Style.from_pygments_dict(get_style_by_name('monokai').styles)

session = PromptSession(
    lexer=PygmentsLexer(PythonLexer),
    style=style,
    include_default_pygments_style=False
)

print("Enter Python code (press Ctrl+D to finish):")
lines = []
while True:
    try:
        line = session.prompt('... ')
        lines.append(line)
    except EOFError:
        break

code = '\n'.join(lines)
print("\nYou entered:")
print(code)
```

This script creates an interactive prompt that highlights Python code as you type. Run the script to test the syntax-highlighted input:

```bash
python prompt_toolkit_integration.py
```

## Cross-Platform Considerations

When using Pygments in your CLI applications, keep the following cross-platform considerations in mind:

1. Terminal color support: Not all terminals support the same number of colors. Use `TerminalFormatter(256)` for 256-color support, but be prepared to fall back to fewer colors if necessary.

2. Windows compatibility: On Windows, you may need to use `colorama` to enable ANSI color support in the terminal. Add `import colorama; colorama.init()` at the beginning of your script.

3. File encodings: When reading files to highlight, use `open(filename, 'r', encoding='utf-8')` to ensure proper handling of non-ASCII characters across platforms.

4. Line endings: Be aware that different platforms use different line endings (LF on Unix/Mac, CRLF on Windows). Use `open(filename, 'r', newline='')` to let Python handle line endings automatically.

5. Terminal size: Use `shutil.get_terminal_size()` to get the terminal size and adjust your output accordingly, as terminal dimensions may vary across platforms.

## Conclusion

In this lesson, we've explored Pygments and its capabilities for syntax highlighting in CLI applications. We've covered basic usage, custom lexers, different output formats, and integration with other libraries like Rich and Prompt Toolkit.

Syntax highlighting can greatly improve the readability and user experience of your CLI tools, especially when working with code or complex data structures. As you develop your applications, consider incorporating Pygments to make your output more visually appealing and easier to understand.

In the next lesson, we'll dive into Typer, a library that simplifies the process of building CLI applications using Python type hints.
