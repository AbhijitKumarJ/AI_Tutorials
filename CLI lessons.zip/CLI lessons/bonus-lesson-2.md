# Bonus Lesson 2: Implementing Core Functionality

Welcome to the second bonus lesson in our final project series! In this lesson, we'll implement the core functionality for our TaskMaster CLI tool, focusing on task management operations (CRUD - Create, Read, Update, Delete).

## Implementing the Database

Before we start implementing our commands, we need a way to persist our tasks. For simplicity, we'll use a JSON file as our database. Let's create a `Database` class in `taskmaster/utils/database.py`:

```python
import json
from pathlib import Path
from typing import List, Dict, Any

class Database:
    def __init__(self, file_path: str = "tasks.json"):
        self.file_path = Path(file_path)
        self.data: Dict[str, List[Dict[str, Any]]] = {"tasks": []}
        self.load()

    def load(self):
        if self.file_path.exists():
            with open(self.file_path, "r") as f:
                self.data = json.load(f)

    def save(self):
        with open(self.file_path, "w") as f:
            json.dump(self.data, f, indent=2)

    def add_task(self, task: Dict[str, Any]):
        self.data["tasks"].append(task)
        self.save()

    def get_tasks(self) -> List[Dict[str, Any]]:
        return self.data["tasks"]

    def update_task(self, task_id: int, updated_task: Dict[str, Any]):
        for i, task in enumerate(self.data["tasks"]):
            if task["id"] == task_id:
                self.data["tasks"][i] = updated_task
                self.save()
                return True
        return False

    def delete_task(self, task_id: int):
        self.data["tasks"] = [task for task in self.data["tasks"] if task["id"] != task_id]
        self.save()

db = Database()
```

This `Database` class provides methods for adding, retrieving, updating, and deleting tasks. It uses a JSON file for persistence.

## Implementing Task Commands

Now, let's implement the task management commands in `taskmaster/commands/task.py`:

```python
import click
from rich.console import Console
from rich.table import Table
from taskmaster.models.task import Task
from taskmaster.utils.database import db
from datetime import datetime

console = Console()

@click.group()
def task():
    """Manage tasks."""
    pass

@task.command()
@click.option("--title", prompt="Task title", help="Title of the task")
@click.option("--description", prompt="Task description", help="Description of the task")
@click.option("--due-date", type=click.DateTime(), help="Due date of the task (YYYY-MM-DD HH:MM:SS)")
@click.option("--priority", type=click.IntRange(1, 5), default=1, help="Priority of the task (1-5)")
def add(title, description, due_date, priority):
    """Add a new task."""
    task_id = len(db.get_tasks()) + 1
    new_task = Task(
        id=task_id,
        title=title,
        description=description,
        due_date=due_date,
        priority=priority
    )
    db.add_task(new_task.__dict__)
    console.print(f"[green]Task added successfully: {new_task}[/green]")

@task.command()
def list():
    """List all tasks."""
    tasks = db.get_tasks()
    table = Table(title="Tasks")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Title", style="magenta")
    table.add_column("Due Date", style="green")
    table.add_column("Priority", style="yellow")
    table.add_column("Completed", style="blue")

    for task in tasks:
        table.add_row(
            str(task["id"]),
            task["title"],
            str(task["due_date"]) if task["due_date"] else "N/A",
            str(task["priority"]),
            "✓" if task["completed"] else "✗"
        )

    console.print(table)

@task.command()
@click.argument("task_id", type=int)
@click.option("--title", help="New title of the task")
@click.option("--description", help="New description of the task")
@click.option("--due-date", type=click.DateTime(), help="New due date of the task (YYYY-MM-DD HH:MM:SS)")
@click.option("--priority", type=click.IntRange(1, 5), help="New priority of the task (1-5)")
@click.option("--completed/--not-completed", help="Mark task as completed or not completed")
def update(task_id, title, description, due_date, priority, completed):
    """Update a task."""
    tasks = db.get_tasks()
    task = next((task for task in tasks if task["id"] == task_id), None)
    if not task:
        console.print(f"[red]Task with ID {task_id} not found.[/red]")
        return

    if title:
        task["title"] = title
    if description:
        task["description"] = description
    if due_date:
        task["due_date"] = due_date.isoformat()
    if priority:
        task["priority"] = priority
    if completed is not None:
        task["completed"] = completed

    if db.update_task(task_id, task):
        console.print(f"[green]Task {task_id} updated successfully.[/green]")
    else:
        console.print(f"[red]Failed to update task {task_id}.[/red]")

@task.command()
@click.argument("task_id", type=int)
def delete(task_id):
    """Delete a task."""
    db.delete_task(task_id)
    console.print(f"[green]Task {task_id} deleted successfully.[/green]")

@task.command()
@click.argument("task_id", type=int)
def complete(task_id):
    """Mark a task as completed."""
    tasks = db.get_tasks()
    task = next((task for task in tasks if task["id"] == task_id), None)
    if not task:
        console.print(f"[red]Task with ID {task_id} not found.[/red]")
        return

    task["completed"] = True
    if db.update_task(task_id, task):
        console.print(f"[green]Task {task_id} marked as completed.[/green]")
    else:
        console.print(f"[red]Failed to mark task {task_id} as completed.[/red]")
```

Now, let's update our main `cli.py` file to include these new task commands:

```python
import click
from rich.console import Console
from taskmaster.commands.task import task

console = Console()

@click.group()
@click.version_option(version="1.0.0")
def cli():
    """TaskMaster: A comprehensive task management CLI tool."""
    pass

cli.add_command(task)

if __name__ == "__main__":
    cli()
```

## Testing Our New Functionality

Now that we've implemented our core task management functionality, let's test it out:

1. Add a new task:
   ```
   taskmaster task add --title "Complete project" --description "Finish the CLI project" --due-date "2023-12-31 23:59:59" --priority 3
   ```

2. List all tasks:
   ```
   taskmaster task list
   ```

3. Update a task:
   ```
   taskmaster task update 1 --title "Complete CLI project" --priority 4
   ```

4. Mark a task as completed:
   ```
   taskmaster task complete 1
   ```

5. Delete a task:
   ```
   taskmaster task delete 1
   ```

## Cross-Platform Considerations

Our current implementation should work across Windows, macOS, and Linux with minimal differences. However, there are a few things to keep in mind:

1. File paths: We're using `pathlib.Path`, which automatically handles path separators for different operating systems.

2. Date and time: We're using ISO format for dates, which is universally understood. However, when prompting for dates, users on different systems might expect different formats. In a more advanced version, we could detect the user's locale and adjust the date format accordingly.

3. Console output: We're using Rich for console output, which handles color and formatting across different terminals. However, some older Windows terminals might not support all features. Consider adding a `--no-color` option for users with limited terminal capabilities.

4. File permissions: When creating and modifying the JSON database file, ensure that the application has the necessary permissions. This is especially important on Unix-based systems (macOS and Linux).

## Conclusion

In this lesson, we've implemented the core functionality of our TaskMaster CLI tool. We've created commands for adding, listing, updating, and deleting tasks, and we've set up a simple JSON-based database for persistence.

In the next lesson, we'll add more advanced features and interactivity to our CLI tool, including project management and interactive prompts for task creation and updates.

Remember to commit your changes