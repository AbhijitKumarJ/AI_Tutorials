# Lesson 12: Simplified CLI Development with Docopt

Welcome to the twelfth lesson in our "Mastering Python CLI Libraries: From Novice to Expert" series! In this lesson, we'll explore Docopt, a command-line interface description language and a Python module that lets you create command-line interfaces from your program's help message. Docopt offers a unique approach to CLI development by emphasizing the importance of well-written documentation.

## Table of Contents
1. [Introduction](#introduction)
2. [Project Setup](#project-setup)
3. [Basic Docopt Usage](#basic-docopt-usage)
4. [Command Patterns](#command-patterns)
5. [Options and Arguments](#options-and-arguments)
6. [Subcommands](#subcommands)
7. [Repeating Arguments](#repeating-arguments)
8. [Default Values](#default-values)
9. [Combining with Type Checking](#combining-with-type-checking)
10. [Cross-Platform Considerations](#cross-platform-considerations)
11. [When to Use Docopt](#when-to-use-docopt)
12. [Conclusion](#conclusion)

## Introduction

Docopt is based on the idea that the best interface descriptions are well-written help messages. Instead of writing complex argument parsing code, you write a help message that adheres to certain conventions, and Docopt uses this to automatically generate a parser for your command-line interface. This approach encourages developers to create clear, comprehensive documentation for their CLIs.

## Project Setup

Let's start by setting up our project. We'll create a new directory for this lesson and install the required packages.

```
docopt_cli/
├── requirements.txt
├── basic_docopt.py
├── command_patterns.py
├── options_arguments.py
├── subcommands.py
├── repeating_arguments.py
├── default_values.py
└── type_checking.py
```

First, create a new directory called `docopt_cli` and navigate into it:

```bash
mkdir docopt_cli
cd docopt_cli
```

Now, create a `requirements.txt` file with the following content:

```
docopt==0.6.2
```

Install the required package:

```bash
pip install -r requirements.txt
```

## Basic Docopt Usage

Let's start with a simple example to understand the basics of Docopt. Create a file named `basic_docopt.py` with the following content:

```python
"""Naval Fate.

Usage:
  naval_fate.py ship new <name>...
  naval_fate.py ship <name> move <x> <y> [--speed=<kn>]
  naval_fate.py ship shoot <x> <y>
  naval_fate.py mine (set|remove) <x> <y> [--moored|--drifting]
  naval_fate.py -h | --help
  naval_fate.py --version

Options:
  -h --help     Show this screen.
  --version     Show version.
  --speed=<kn>  Speed in knots [default: 10].
  --moored      Moored (anchored) mine.
  --drifting    Drifting mine.
"""

from docopt import docopt

if __name__ == '__main__':
    arguments = docopt(__doc__, version='Naval Fate 2.0')
    print(arguments)
```

This script demonstrates basic usage of Docopt. The entire interface is defined in the docstring at the top of the file. Run the script to test the automatically generated CLI:

```bash
python basic_docopt.py --help
python basic_docopt.py ship new Titanic Carpathia
python basic_docopt.py ship Titanic move 10 20 --speed=5
python basic_docopt.py mine set 5 5 --moored
```

Notice how Docopt automatically parses the command-line arguments based on the usage patterns defined in the docstring.

## Command Patterns

Docopt allows you to define various command patterns. Create a file named `command_patterns.py` with the following content:

```python
"""Command Pattern Examples.

Usage:
  command_patterns.py foo
  command_patterns.py bar [<arg>]
  command_patterns.py baz <arg>...
  command_patterns.py qux (--alpha | --beta)
  command_patterns.py (-h | --help)

Options:
  -h --help     Show this screen.
  --alpha       Alpha option.
  --beta        Beta option.
"""

from docopt import docopt

if __name__ == '__main__':
    arguments = docopt(__doc__)
    print(arguments)
```

This script demonstrates different command patterns in Docopt. Run the script to test the various patterns:

```bash
python command_patterns.py foo
python command_patterns.py bar
python command_patterns.py bar argument
python command_patterns.py baz arg1 arg2 arg3
python command_patterns.py qux --alpha
python command_patterns.py qux --beta
```

## Options and Arguments

Docopt makes it easy to work with options and arguments. Create a file named `options_arguments.py` with the following content:

```python
"""Options and Arguments Example.

Usage:
  options_arguments.py [-v...] <input_file> <output_file>
  options_arguments.py (--left | --right) [--mirror] <input_file>
  options_arguments.py --cipher=<n> <input_file>
  options_arguments.py (-h | --help)

Options:
  -h --help        Show this screen.
  -v --verbose     Increase verbosity.
  --left           Left align.
  --right          Right align.
  --mirror         Mirror the input.
  --cipher=<n>     Cipher strength [default: 1].
"""

from docopt import docopt

if __name__ == '__main__':
    arguments = docopt(__doc__)
    print(arguments)

    # Example of how to use the parsed arguments
    if arguments['--verbose']:
        print(f"Verbosity level: {arguments['--verbose'].count(True)}")

    if arguments['<input_file>']:
        print(f"Input file: {arguments['<input_file>']}")

    if arguments['--cipher']:
        print(f"Cipher strength: {arguments['--cipher']}")
```

This script shows how to work with various options and arguments in Docopt. Run the script to test different combinations:

```bash
python options_arguments.py -vv input.txt output.txt
python options_arguments.py --left --mirror input.txt
python options_arguments.py --cipher=3 secret.txt
```

## Subcommands

Docopt can handle subcommands elegantly. Create a file named `subcommands.py` with the following content:

```python
"""Git-like CLI Example.

Usage:
  git_like.py clone <repo>
  git_like.py commit [-a] [-m <msg>]
  git_like.py push [<remote> [<branch>]]
  git_like.py status
  git_like.py (-h | --help)
  git_like.py --version

Options:
  -h --help     Show this screen.
  --version     Show version.
  -a            Add all changes.
  -m <msg>      Commit message.
"""

from docopt import docopt

def clone(repo):
    print(f"Cloning repository: {repo}")

def commit(add_all, message):
    if add_all:
        print("Adding all changes...")
    print(f"Committing with message: {message}")

def push(remote, branch):
    print(f"Pushing to {remote}/{branch}")

def status():
    print("Checking repository status...")

if __name__ == '__main__':
    arguments = docopt(__doc__, version='Git-like CLI 1.0')
    
    if arguments['clone']:
        clone(arguments['<repo>'])
    elif arguments['commit']:
        commit(arguments['-a'], arguments['-m'])
    elif arguments['push']:
        push(arguments['<remote>'] or 'origin', arguments['<branch>'] or 'master')
    elif arguments['status']:
        status()
```

This script demonstrates how to implement subcommands using Docopt. Run the script to test the subcommands:

```bash
python subcommands.py clone https://github.com/example/repo.git
python subcommands.py commit -a -m "Initial commit"
python subcommands.py push origin main
python subcommands.py status
```

## Repeating Arguments

Docopt can handle repeating arguments. Create a file named `repeating_arguments.py` with the following content:

```python
"""Repeating Arguments Example.

Usage:
  repeating_arguments.py move <from> <to>...
  repeating_arguments.py copy <src>... <dst>
  repeating_arguments.py (-h | --help)

Options:
  -h --help     Show this screen.
"""

from docopt import docopt

def move(source, destinations):
    print(f"Moving {source} to:")
    for dest in destinations:
        print(f"  - {dest}")

def copy(sources, destination):
    print(f"Copying to {destination}:")
    for src in sources:
        print(f"  - {src}")

if __name__ == '__main__':
    arguments = docopt(__doc__)
    
    if arguments['move']:
        move(arguments['<from>'], arguments['<to>'])
    elif arguments['copy']:
        copy(arguments['<src>'], arguments['<dst>'])
```

This script shows how to work with repeating arguments in Docopt. Run the script to test repeating arguments:

```bash
python repeating_arguments.py move file.txt dir1 dir2 dir3
python repeating_arguments.py copy file1.txt file2.txt file3.txt destination/
```

## Default Values

Docopt allows you to specify default values for options. Create a file named `default_values.py` with the following content:

```python
"""Default Values Example.

Usage:
  default_values.py [--count=<n>] <name>...
  default_values.py (-h | --help)

Options:
  -h --help     Show this screen.
  --count=<n>   Number of times to repeat [default: 1].
"""

from docopt import docopt

def greet(names, count):
    for name in names:
        for _ in range(count):
            print(f"Hello, {name}!")

if __name__ == '__main__':
    arguments = docopt(__doc__)
    
    names = arguments['<name>']
    count = int(arguments['--count'])
    
    greet(names, count)
```

This script demonstrates how to use default values in Docopt. Run the script to test default values:

```bash
python default_values.py Alice
python default_values.py --count=3 Bob Charlie
```

## Combining with Type Checking

While Docopt doesn't provide built-in type checking, you can combine it with Python's type hints for better type safety. Create a file named `type_checking.py` with the following content:

```python
"""Type Checking Example.

Usage:
  type_checking.py add <x> <y>
  type_checking.py multiply <x> <y>
  type_checking.py (-h | --help)

Options:
  -h --help     Show this screen.
"""

from docopt import docopt
from typing import Tuple, Union

def parse_arguments(doc) -> Tuple[str, Union[int, float], Union[int, float]]:
    arguments = docopt(doc)
    
    command = 'add' if arguments['add'] else 'multiply'
    try:
        x = int(arguments['<x>'])
    except ValueError:
        x = float(arguments['<x>'])
    
    try:
        y = int(arguments['<y>'])
    except ValueError:
        y = float(arguments['<y>'])
    
    return command, x, y

def add(x: Union[int, float], y: Union[int, float]) -> Union[int, float]:
    return x + y

def multiply(x: Union[int, float], y: Union[int, float]) -> Union[int, float]:
    return x * y

if __name__ == '__main__':
    command, x, y = parse_arguments(__doc__)
    
    if command == 'add':
        result = add(x, y)
    else:
        result = multiply(x, y)
    
    print(f"Result: {result}")
```

This script shows how to combine Docopt with type hints for better type safety. Run the script to test type checking:

```bash
python type_checking.py add 5 3
python type_checking.py multiply 2.5 4
```

## Cross-Platform Considerations

When developing CLI applications with Docopt, keep these cross-platform considerations in mind:

1. File paths: Use `os.path` or `pathlib.Path` for handling file paths to ensure compatibility across different operating systems.

2. Environment variables: Access environment variables using `os.environ` for cross-platform compatibility.

3. Executables: If your application needs to run external commands, consider using the `subprocess` module with the `shell=True` parameter set to `False` for better cross-platform support.

4. Line endings: When reading or writing files, open them in text mode with universal newlines: `open(file, 'r', newline=None)` for reading, and `open(file, 'w', newline='')` for writing.

5. Console output: Be aware that different platforms may have different default encodings for console output. You may need to handle encoding explicitly in some cases.

6. Colored output: If you want to add colored output to your Docopt CLI, consider using a cross-platform library like `colorama` to ensure consistent behavior across different operating systems.

## When to Use Docopt

Docopt is particularly useful in the following scenarios:

1. Documentation-driven development: When you want to start with a clear, human-readable description of your CLI's interface.

2. Simple to moderate complexity CLIs: For CLIs with straightforward argument structures and options.

3. Quick prototyping: Rapidly create a CLI for existing Python code without writing complex argument parsing logic.

4. Learning and teaching: Use Docopt to demonstrate how to create CLIs with a focus on good documentation practices.

However, for more complex CLI applications that require fine-grained control over argument parsing, input validation, or custom formatting, you might prefer libraries like Click or Typer, which we covered in previous lessons.

## Conclusion

In this lesson, we've explored Docopt and its unique approach to creating command-line interfaces from help messages. We've covered basic usage, command patterns, options and arguments, subcommands, repeating arguments, default values, and how to combine Docopt with type checking.

Docopt offers a simple and intuitive way to create CLIs by emphasizing the importance of well-written documentation. While it may not offer the same level of customization as other CLI libraries, its simplicity and focus on documentation make it a valuable tool in certain scenarios.

In the next lesson, we'll explore cross-platform considerations in more detail, ensuring that our CLI applications work consistently across different operating systems.
