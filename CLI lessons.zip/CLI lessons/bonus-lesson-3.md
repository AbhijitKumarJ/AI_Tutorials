# Bonus Lesson 3: Adding Advanced Features and Interactivity

Welcome to the third bonus lesson in our final project series! In this lesson, we'll enhance our TaskMaster CLI tool by adding project management, interactive prompts, and a Kanban board view.

## Implementing Project Management

First, let's add project management functionality. We'll update our database to handle projects and modify our task commands to associate tasks with projects.

Update `taskmaster/utils/database.py`:

```python
import json
from pathlib import Path
from typing import List, Dict, Any

class Database:
    def __init__(self, file_path: str = "taskmaster_data.json"):
        self.file_path = Path(file_path)
        self.data: Dict[str, Any] = {"tasks": [], "projects": []}
        self.load()

    def load(self):
        if self.file_path.exists():
            with open(self.file_path, "r") as f:
                self.data = json.load(f)

    def save(self):
        with open(self.file_path, "w") as f:
            json.dump(self.data, f, indent=2)

    # Task methods
    def add_task(self, task: Dict[str, Any]):
        self.data["tasks"].append(task)
        self.save()

    def get_tasks(self) -> List[Dict[str, Any]]:
        return self.data["tasks"]

    def update_task(self, task_id: int, updated_task: Dict[str, Any]):
        for i, task in enumerate(self.data["tasks"]):
            if task["id"] == task_id:
                self.data["tasks"][i] = updated_task
                self.save()
                return True
        return False

    def delete_task(self, task_id: int):
        self.data["tasks"] = [task for task in self.data["tasks"] if task["id"] != task_id]
        self.save()

    # Project methods
    def add_project(self, project: Dict[str, Any]):
        self.data["projects"].append(project)
        self.save()

    def get_projects(self) -> List[Dict[str, Any]]:
        return self.data["projects"]

    def update_project(self, project_id: int, updated_project: Dict[str, Any]):
        for i, project in enumerate(self.data["projects"]):
            if project["id"] == project_id:
                self.data["projects"][i] = updated_project
                self.save()
                return True
        return False

    def delete_project(self, project_id: int):
        self.data["projects"] = [project for project in self.data["projects"] if project["id"] != project_id]
        # Remove project association from tasks
        for task in self.data["tasks"]:
            if task["project_id"] == project_id:
                task["project_id"] = None
        self.save()

db = Database()
```

Now, let's create a new file `taskmaster/commands/project.py`:

```python
import click
from rich.console import Console
from rich.table import Table
from taskmaster.utils.database import db

console = Console()

@click.group()
def project():
    """Manage projects."""
    pass

@project.command()
@click.option("--name", prompt="Project name", help="Name of the project")
@click.option("--description", prompt="Project description", help="Description of the project")
def add(name, description):
    """Add a new project."""
    project_id = len(db.get_projects()) + 1
    new_project = {
        "id": project_id,
        "name": name,
        "description": description
    }
    db.add_project(new_project)
    console.print(f"[green]Project added successfully: {new_project['name']}[/green]")

@project.command()
def list():
    """List all projects."""
    projects = db.get_projects()
    table = Table(title="Projects")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="magenta")
    table.add_column("Description", style="yellow")

    for project in projects:
        table.add_row(
            str(project["id"]),
            project["name"],
            project["description"]
        )

    console.print(table)

@project.command()
@click.argument("project_id", type=int)
@click.option("--name", help="New name of the project")
@click.option("--description", help="New description of the project")
def update(project_id, name, description):
    """Update a project."""
    projects = db.get_projects()
    project = next((project for project in projects if project["id"] == project_id), None)
    if not project:
        console.print(f"[red]Project with ID {project_id} not found.[/red]")
        return

    if name:
        project["name"] = name
    if description:
        project["description"] = description

    if db.update_project(project_id, project):
        console.print(f"[green]Project {project_id} updated successfully.[/green]")
    else:
        console.print(f"[red]Failed to update project {project_id}.[/red]")

@project.command()
@click.argument("project_id", type=int)
def delete(project_id):
    """Delete a project."""
    db.delete_project(project_id)
    console.print(f"[green]Project {project_id} deleted successfully.[/green]")
```

Update `taskmaster/cli.py` to include the new project commands:

```python
import click
from rich.console import Console
from taskmaster.commands.task import task
from taskmaster.commands.project import project

console = Console()

@click.group()
@click.version_option(version="1.0.0")
def cli():
    """TaskMaster: A comprehensive task management CLI tool."""
    pass

cli.add_command(task)
cli.add_command(project)

if __name__ == "__main__":
    cli()
```

## Adding Interactive Prompts

Now, let's enhance our task creation process with interactive prompts using `prompt_toolkit`. Update `taskmaster/commands/task.py`:

```python
import click
from rich.console import Console
from rich.table import Table
from taskmaster.models.task import Task
from taskmaster.utils.database import db
from datetime import datetime
from prompt_toolkit import prompt
from prompt_toolkit.validation import Validator, ValidationError

console = Console()

class IntegerValidator(Validator):
    def validate(self, document):
        text = document.text
        if not text.isdigit() or int(text) < 1 or int(text) > 5:
            raise ValidationError(message="Please enter a number between 1 and 5")

@task.command()
def add():
    """Add a new task interactively."""
    title = prompt("Task title: ")
    description = prompt("Task description: ")
    due_date_str = prompt("Due date (YYYY-MM-DD HH:MM:SS, press enter to skip): ")
    due_date = datetime.strptime(due_date_str, "%Y-%m-%d %H:%M:%S") if due_date_str else None
    priority = int(prompt("Priority (1-5): ", validator=IntegerValidator()))
    
    projects = db.get_projects()
    if projects:
        project_choices = "\n".join([f"{p['id']}: {p['name']}" for p in projects])
        project_id = int(prompt(f"Select a project ID (or 0 for no project):\n{project_choices}\nProject ID: "))
    else:
        project_id = 0

    task_id = len(db.get_tasks()) + 1
    new_task = Task(
        id=task_id,
        title=title,
        description=description,
        due_date=due_date,
        priority=priority,
        project_id=project_id if project_id != 0 else None
    )
    db.add_task(new_task.__dict__)
    console.print(f"[green]Task added successfully: {new_task}[/green]")

# Update the list function to show project information
@task.command()
def list():
    """List all tasks."""
    tasks = db.get_tasks()
    projects = {p["id"]: p["name"] for p in db.get_projects()}
    table = Table(title="Tasks")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Title", style="magenta")
    table.add_column("Due Date", style="green")
    table.add_column("Priority", style="yellow")
    table.add_column("Completed", style="blue")
    table.add_column("Project", style="red")

    for task in tasks:
        table.add_row(
            str(task["id"]),
            task["title"],
            str(task["due_date"]) if task["due_date"] else "N/A",
            str(task["priority"]),
            "✓" if task["completed"] else "✗",
            projects.get(task["project_id"], "N/A")
        )

    console.print(table)

# ... (keep other existing functions)
```

## Implementing a Kanban Board View

Let's add a Kanban board view to visualize tasks. Create a new file `taskmaster/views/kanban_view.py`:

```python
from rich.console import Console
from rich.panel import Panel
from rich.columns import Columns
from taskmaster.utils.database import db

console = Console()

def kanban_view():
    tasks = db.get_tasks()
    projects = {p["id"]: p["name"] for p in db.get_projects()}

    todo = []
    in_progress = []
    done = []

    for task in tasks:
        task_str = f"[bold]{task['title']}[/bold]\n"
        task_str += f"Priority: {task['priority']}\n"
        task_str += f"Project: {projects.get(task['project_id'], 'N/A')}"
        
        if task["completed"]:
            done.append(Panel(task_str, expand=False))
        elif task["priority"] >= 4:
            in_progress.append(Panel(task_str, expand=False))
        else:
            todo.append(Panel(task_str, expand=False))

    console.print("[bold blue]Kanban Board[/bold blue]")
    console.print(Columns([
        Panel(Columns(todo, expand=True), title="To Do", expand=True),
        Panel(Columns(in_progress, expand=True), title="In Progress", expand=True),
        Panel(Columns(done, expand=True), title="Done", expand=True)
    ]))
```

Now, let's add a command to show the Kanban board. Update `taskmaster/commands/view.py`:

```python
import click
from taskmaster.views.kanban_view import kanban_view

@click.group()
def view():
    """View tasks in different formats."""
    pass

@view.command()
def kanban():
    """Show tasks in a Kanban board view."""
    kanban_view()
```

Update `taskmaster/cli.py` to include the new view command:

```python
import click
from rich.console import Console
from taskmaster.commands.task import task
from taskmaster.commands.project import project
from taskmaster.commands.view import view

console = Console()

@click.group()
@click.version_option(version="1.0.0")
def cli():
    """TaskMaster: A comprehensive task management CLI tool."""
    pass

cli.add_command(task)
cli.add_command(project)
cli.add_command(view)

if __name__ == "__main__":
    cli()
```

## Cross-Platform Considerations

1. Console output: The Rich library we're using for console output handles most cross-platform issues, but some older Windows terminals might not support all features. Consider adding a `--plain` option for users with limited terminal capabilities.

2. File paths: We're using `pathlib.Path` for file operations, which handles path differences across operating systems.

3. Date and time input: Different locales might use different date formats. Consider adding support for multiple date input formats or use a library like `dateutil` for more flexible date parsing.

4. Keyboard interrupts: On Windows, keyboard interrupts (Ctrl+C) might behave slightly differently. Ensure your application handles these gracefully across all platforms.

## Testing the New Features

Now you can test the new features:

1. Add a project:
   ```
   taskmaster project add
   ```

2. Add a task interactively, associating it with a project:
   ```
   taskmaster task add
   ```

3. List tasks (now showing project information):
   ```
   taskmaster task list
   ```

4. View the Kanban board:
   ```
   taskmaster view kanban
   ```

## Conclusion

In this lesson, we've significantly enhanced our TaskMaster CLI tool by adding project management, interactive task creation, and a Kanban board view. These features make the tool more user-friendly and provide better visualization of tasks and their status.

In the next lesson, we'll focus on cross-platform compatibility issues and package our application for distribution.

Remember to commit your changes:

```bash
git add .
git commit -m "Add project management, interactive prompts, and Kanban view"
```

