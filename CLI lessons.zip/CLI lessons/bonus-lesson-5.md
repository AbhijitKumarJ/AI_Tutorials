# Bonus Lesson 5: Documentation, Testing, and Deployment

Welcome to the final bonus lesson in our project series! In this lesson, we'll focus on creating comprehensive documentation, implementing thorough testing, and establishing a robust deployment strategy for our TaskMaster CLI tool.

## Documentation

Good documentation is crucial for the adoption and maintenance of your project. Let's create comprehensive documentation for TaskMaster.

### 1. README.md

Update the `README.md` file in the root directory of your project:

```markdown
# TaskMaster CLI

TaskMaster is a comprehensive task management CLI tool built with Python. It allows users to manage tasks and projects efficiently from the command line.

## Features

- Create, read, update, and delete tasks
- Organize tasks into projects
- Set priorities and due dates for tasks
- View tasks in various formats (list, Kanban board)
- Cross-platform compatibility (Windows, macOS, Linux)

## Installation

You can install TaskMaster using pip:

```
pip install taskmaster-cli
```

Or download the standalone executable from the [releases page](https://github.com/yourusername/taskmaster/releases).

## Usage

After installation, you can use TaskMaster by running the `taskmaster` command in your terminal:

```
taskmaster --help
```

For more detailed usage instructions, refer to the [User Guide](docs/user_guide.md).

## Development

To set up the development environment:

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/taskmaster.git
   cd taskmaster
   ```

2. Create a virtual environment and activate it:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
   ```

3. Install the development dependencies:
   ```
   pip install -r requirements-dev.txt
   ```

4. Install the package in editable mode:
   ```
   pip install -e .
   ```

For more information on contributing to TaskMaster, see [CONTRIBUTING.md](CONTRIBUTING.md).

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
```

### 2. User Guide

Create a `docs` directory and add a `user_guide.md` file:

```markdown
# TaskMaster User Guide

TaskMaster is a powerful CLI tool for managing your tasks and projects. This guide will walk you through its main features and usage.

## Table of Contents

1. [Installation](#installation)
2. [Basic Usage](#basic-usage)
3. [Task Management](#task-management)
4. [Project Management](#project-management)
5. [Views](#views)
6. [Configuration](#configuration)

## Installation

[Installation instructions here]

## Basic Usage

To see all available commands, run:

```
taskmaster --help
```

## Task Management

### Adding a Task

To add a new task interactively:

```
taskmaster task add
```

You'll be prompted to enter the task details.

### Listing Tasks

To list all tasks:

```
taskmaster task list
```

### Updating a Task

To update a task:

```
taskmaster task update <task_id> --title "New Title" --priority 3
```

### Completing a Task

To mark a task as completed:

```
taskmaster task complete <task_id>
```

### Deleting a Task

To delete a task:

```
taskmaster task delete <task_id>
```

## Project Management

[Project management instructions here]

## Views

### Kanban Board View

To view your tasks in a Kanban board:

```
taskmaster view kanban
```

## Configuration

[Configuration instructions here]
```

### 3. API Documentation

For larger projects, you might want to generate API documentation. You can use tools like Sphinx or MkDocs for this purpose. Here's a basic setup using Sphinx:

1. Install Sphinx:
   ```
   pip install sphinx
   ```

2. Set up Sphinx in your project directory:
   ```
   mkdir docs
   cd docs
   sphinx-quickstart
   ```

3. Configure `conf.py` to use autodoc:
   ```python
   # Add these lines to conf.py
   import os
   import sys
   sys.path.insert(0, os.path.abspath('..'))
   
   extensions = ['sphinx.ext.autodoc', 'sphinx.ext.napoleon']
   ```

4. Create API documentation files:
   ```
   sphinx-apidoc -o . ../taskmaster
   ```

5. Build the documentation:
   ```
   make html
   ```

## Testing

Implementing thorough testing is crucial for maintaining the quality and reliability of your code. Let's set up a testing framework and write some tests for TaskMaster.

### 1. Setting Up pytest

We'll use pytest for our testing framework. Install it along with some useful plugins:

```bash
pip install pytest pytest-cov pytest-mock
```

### 2. Writing Tests

Create a `tests` directory in your project root and add test files. Here's an example `tests/test_task.py`:

```python
import pytest
from taskmaster.models.task import Task
from taskmaster.utils.database import Database
from datetime import datetime, timezone

@pytest.fixture
def mock_db(tmp_path):
    db_file = tmp_path / "test_db.json"
    return Database(str(db_file))

def test_add_task(mock_db):
    task = Task(
        id=1,
        title="Test Task",
        description="This is a test task",
        due_date=datetime.now(timezone.utc),
        priority=3
    )
    mock_db.add_task(task.__dict__)
    tasks = mock_db.get_tasks()
    assert len(tasks) == 1
    assert tasks[0]["title"] == "Test Task"

def test_update_task(mock_db):
    task = Task(
        id=1,
        title="Original Task",
        description="This is the original task",
        due_date=datetime.now(timezone.utc),
        priority=3
    )
    mock_db.add_task(task.__dict__)
    
    updated_task = task.__dict__.copy()
    updated_task["title"] = "Updated Task"
    mock_db.update_task(1, updated_task)
    
    tasks = mock_db.get_tasks()
    assert len(tasks) == 1
    assert tasks[0]["title"] == "Updated Task"

def test_delete_task(mock_db):
    task = Task(
        id=1,
        title="Task to Delete",
        description="This task will be deleted",
        due_date=datetime.now(timezone.utc),
        priority=3
    )
    mock_db.add_task(task.__dict__)
    
    mock_db.delete_task(1)
    tasks = mock_db.get_tasks()
    assert len(tasks) == 0

def test_list_tasks(mock_db):
    for i in range(3):
        task = Task(
            id=i+1,
            title=f"Task {i+1}",
            description=f"This is task {i+1}",
            due_date=datetime.now(timezone.utc),
            priority=i+1
        )
        mock_db.add_task(task.__dict__)
    
    tasks = mock_db.get_tasks()
    assert len(tasks) == 3
    assert tasks[0]["title"] == "Task 1"
    assert tasks[1]["title"] == "Task 2"
    assert tasks[2]["title"] == "Task 3"
```

### 3. Testing CLI Commands

To test CLI commands, we can use the `CliRunner` provided by Click. Create a new file `tests/test_cli.py`:

```python
import pytest
from click.testing import CliRunner
from taskmaster.cli import cli

@pytest.fixture
def runner():
    return CliRunner()

def test_cli_task_add(runner):
    result = runner.invoke(cli, ['task', 'add'], input='Test Task\nTest Description\n\n3\n0\n')
    assert result.exit_code == 0
    assert 'Task added successfully' in result.output

def test_cli_task_list(runner):
    runner.invoke(cli, ['task', 'add'], input='Test Task\nTest Description\n\n3\n0\n')
    result = runner.invoke(cli, ['task', 'list'])
    assert result.exit_code == 0
    assert 'Test Task' in result.output

def test_cli_project_add(runner):
    result = runner.invoke(cli, ['project', 'add'], input='Test Project\nTest Project Description\n')
    assert result.exit_code == 0
    assert 'Project added successfully' in result.output

def test_cli_view_kanban(runner):
    runner.invoke(cli, ['task', 'add'], input='Test Task\nTest Description\n\n3\n0\n')
    result = runner.invoke(cli, ['view', 'kanban'])
    assert result.exit_code == 0
    assert 'Kanban Board' in result.output
```

### 4. Running Tests

To run the tests, use the following command:

```bash
pytest
```

To generate a coverage report:

```bash
pytest --cov=taskmaster
```

### 5. Continuous Integration

Set up continuous integration to automatically run tests when you push changes to your repository. For example, you can use GitHub Actions by creating a `.github/workflows/test.yml` file:

```yaml
name: Test

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: [3.7, 3.8, 3.9]

    steps:
    - uses: actions/checkout@v2
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v2
      with:
        python-version: ${{ matrix.python-version }}
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
        pip install -r requirements-dev.txt
    - name: Run tests
      run: |
        pytest --cov=taskmaster
    - name: Upload coverage to Codecov
      uses: codecov/codecov-action@v1
```

## Deployment

Now that we have our documentation and testing in place, let's discuss deployment strategies for TaskMaster.

### 1. PyPI Deployment

To make your package easily installable via pip, you can publish it to PyPI. Here's how to do it:

1. Make sure your `setup.py` is up-to-date.

2. Create a `~/.pypirc` file with your PyPI credentials:

   ```
   [pypi]
   username = your_username
   password = your_password
   ```

3. Build your package:

   ```bash
   python setup.py sdist bdist_wheel
   ```

4. Upload your package to PyPI:

   ```bash
   twine upload dist/*
   ```

### 2. GitHub Releases

For each new version of TaskMaster:

1. Update the version number in `setup.py`.

2. Create a new tag:

   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```

3. Create a new release on GitHub, attaching the built wheel file.

### 3. Automatic Deployment

You can automate the deployment process using GitHub Actions. Create a `.github/workflows/deploy.yml` file:

```yaml
name: Deploy

on:
  push:
    tags:
      - 'v*'

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.x'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install setuptools wheel twine
    - name: Build and publish
      env:
        TWINE_USERNAME: ${{ secrets.PYPI_USERNAME }}
        TWINE_PASSWORD: ${{ secrets.PYPI_PASSWORD }}
      run: |
        python setup.py sdist bdist_wheel
        twine upload dist/*
```

This workflow will automatically deploy your package to PyPI when you push a new tag.

### 4. Docker Deployment

For users who prefer to run TaskMaster in a container, you can provide a Dockerfile:

```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY . .

RUN pip install --no-cache-dir -r requirements.txt

RUN pip install .

ENTRYPOINT ["taskmaster"]
```

Build and run the Docker image:

```bash
docker build -t taskmaster .
docker run -it taskmaster
```

## Conclusion

Congratulations! You've now completed the final bonus lesson of our TaskMaster CLI project. We've covered:

1. Creating comprehensive documentation, including a README, user guide, and API docs.
2. Implementing thorough testing with pytest, including unit tests and CLI tests.
3. Setting up continuous integration with GitHub Actions.
4. Deploying the package to PyPI and creating GitHub releases.
5. Providing a Docker deployment option.

These practices will help ensure that TaskMaster is robust, well-documented, and easy for others to use and contribute to. Remember to keep your documentation and tests up-to-date as you continue to develop and improve TaskMaster.

As you move forward with your CLI development journey, consider exploring advanced topics such as plugin systems, configuration management, or integration with web services. Keep learning and happy coding!

</antArtifact>

This concludes our series of bonus lessons for the "Mastering Python CLI Libraries: From Novice to Expert" course. We've covered a wide range of topics, from basic CLI concepts to advanced features, cross-platform compatibility, testing, documentation, and deployment. The TaskMaster project serves as a comprehensive example of how to build a robust, user-friendly CLI tool using Python.

Here's a summary of what we've covered in these bonus lessons:

1. Project Setup and Architecture
2. Implementing Core Functionality
3. Adding Advanced Features and Interactivity
4. Cross-Platform Compatibility and Packaging
5. Documentation, Testing, and Deployment

These lessons have provided hands-on experience with various Python CLI libraries and best practices for CLI development. The skills and knowledge gained from this project can be applied to a wide range of CLI applications, from simple utilities to complex management tools.

Remember that the world of software development is constantly evolving, so it's important to stay updated with the latest trends, libraries, and best practices in CLI development. Continue to explore new libraries, contribute to open-source projects, and build your own tools to further enhance your skills.

Thank you for following along with this course, and best of luck in your future CLI development endeavors!