# Lesson 6: Advanced Rich Features

In this lesson, we'll dive deeper into Rich's advanced features, exploring how to create more sophisticated and interactive command-line interfaces. We'll build upon our calculator example, adding new functionalities and demonstrating advanced Rich concepts.

## 1. Console Output Capturing and Redirection

Rich allows you to capture console output and redirect it, which can be useful for logging or testing.

### Example: Capturing Console Output

```python
from rich.console import Console
from io import StringIO

console = Console()

# Capture output
string_io = StringIO()
console_file = Console(file=string_io)
console_file.print("[bold red]Hello[/bold red] World!")

# Get captured output as a string
output = string_io.getvalue()
print(output)  # Prints the captured output
```

## 2. Creating Custom Rich Renderable Objects

You can create your own objects that Rich can render, allowing for complex, custom output.

### Example: Custom Renderable Calculator Result

```python
from rich.console import Console, ConsoleOptions, RenderResult
from rich.panel import Panel
from rich.text import Text

class CalculatorResult:
    def __init__(self, operation, x, y, result):
        self.operation = operation
        self.x = x
        self.y = y
        self.result = result

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        if self.operation == 'add':
            color = "green"
            symbol = "+"
        elif self.operation == 'subtract':
            color = "red"
            symbol = "-"
        elif self.operation == 'multiply':
            color = "blue"
            symbol = "×"
        elif self.operation == 'divide':
            color = "yellow"
            symbol = "÷"
        else:
            color = "white"
            symbol = "?"

        result_text = Text(f"{self.x} {symbol} {self.y} = {self.result}")
        result_text.stylize(f"bold {color}")

        yield Panel(result_text, title=f"{self.operation.capitalize()} Result", border_style=color)

# Usage
console = Console()
result = CalculatorResult('add', 5, 3, 8)
console.print(result)
```

This example creates a custom `CalculatorResult` class that Rich can render with custom formatting.

## 3. Markdown and BBCode Rendering

Rich can render Markdown and BBCode directly in the terminal, which is great for displaying formatted documentation or user input.

### Example: Markdown Rendering

```python
from rich.console import Console
from rich.markdown import Markdown

console = Console()

markdown = """
# Calculator Help

Use the following commands:

- `add <x> <y>`: Add two numbers
- `subtract <x> <y>`: Subtract y from x
- `multiply <x> <y>`: Multiply two numbers
- `divide <x> <y>`: Divide x by y

**Note:** All arguments should be numbers.
"""

md = Markdown(markdown)
console.print(md)
```

## 4. Tree Structures and File Trees

Rich can display hierarchical data as tree structures, which is useful for showing file systems or any nested data.

### Example: Displaying Calculator Operations as a Tree

```python
from rich.console import Console
from rich.tree import Tree

console = Console()

tree = Tree("Calculator Operations")
basic = tree.add("Basic Operations")
basic.add("Add")
basic.add("Subtract")
basic.add("Multiply")
basic.add("Divide")

advanced = tree.add("Advanced Operations")
advanced.add("Power")
advanced.add("Square Root")
advanced.add("Logarithm")

console.print(tree)
```

## 5. Tracebacks and Exception Handling

Rich provides enhanced tracebacks that are more readable and informative than standard Python tracebacks.

### Example: Enhanced Exception Handling

```python
from rich.console import Console
from rich.traceback import install

install()  # Install rich traceback handler

console = Console()

def divide(x, y):
    return x / y

try:
    result = divide(10, 0)
except Exception:
    console.print_exception()
```

## 6. Live Display and Dynamic Content

Rich allows you to create live, updating displays, which is great for showing real-time data or progress.

### Example: Live Updating Calculator

```python
import time
import random
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

def generate_calculation():
    operations = ['+', '-', '*', '/']
    x = random.randint(1, 100)
    y = random.randint(1, 100)
    op = random.choice(operations)
    if op == '+':
        result = x + y
    elif op == '-':
        result = x - y
    elif op == '*':
        result = x * y
    else:
        result = x / y if y != 0 else "Error"
    return f"{x} {op} {y} = {result:.2f}"

with Live(refresh_per_second=4) as live:
    for _ in range(40):  # Show 40 calculations
        time.sleep(0.25)
        text = Text(generate_calculation(), style="bold magenta")
        live.update(Panel(text, title="Live Calculator", border_style="green"))
```

This example shows a live display of random calculations updating in real-time.

## 7. Advanced Formatting and Layout

Rich provides various tools for advanced formatting and layout, including columns, padding, and alignment.

### Example: Advanced Calculator Layout

```python
from rich.console import Console
from rich.layout import Layout
from rich.panel import Panel
from rich.text import Text

console = Console()

def make_layout() -> Layout:
    layout = Layout(name="root")
    layout.split(
        Layout(name="header", size=3),
        Layout(name="main", ratio=1),
        Layout(name="footer", size=3)
    )
    layout["main"].split_row(
        Layout(name="side"),
        Layout(name="body", ratio=2, minimum_size=60)
    )
    return layout

layout = make_layout()
layout["header"].update(Panel(Text("Advanced Calculator", style="bold magenta")))
layout["side"].update(Panel(Text("Operations:\n- Add\n- Subtract\n- Multiply\n- Divide", style="green")))
layout["body"].update(Panel(Text("Enter your calculation here", style="cyan")))
layout["footer"].update(Panel(Text("Press Ctrl+C to exit", style="red")))

console.print(layout)
```

This example demonstrates a more complex layout for a calculator interface.

## 8. Cross-Platform Considerations

When using these advanced Rich features, keep the following cross-platform considerations in mind:

1. **Terminal Size**: Rich tries to detect the terminal size, but it may not always be accurate across all platforms. You can manually set the size:
   ```python
   console = Console(width=80, height=24)
   ```

2. **Color Support**: While Rich auto-detects color support, some terminals may have limited color capabilities. You can always fall back to a simpler color scheme:
   ```python
   console = Console(color_system="standard")  # 16 colors
   ```

3. **Emoji and Unicode**: Support for emoji and certain Unicode characters can vary. Always test on target platforms and provide fallbacks:
   ```python
   console.print("✅" if console.emoji else "[green]OK[/green]")
   ```

4. **File Paths**: When displaying file trees or paths, use `os.path` to ensure correct path formatting across platforms:
   ```python
   import os
   console.print(os.path.join("folder", "subfolder", "file.txt"))
   ```

5. **Line Endings**: Rich handles line endings automatically, but be aware of potential issues when reading or writing files:
   ```python
   with open("file.txt", "r", newline="") as f:
       content = f.read()
   ```

## Conclusion

In this lesson, we've explored advanced features of Rich, including custom renderables, Markdown rendering, tree structures, enhanced exception handling, live displays, and advanced layouts. These features allow you to create sophisticated, interactive, and visually appealing command-line interfaces that work consistently across different operating systems.

## Exercise

Create an advanced version of our calculator application that incorporates the following:

1. A custom renderable for calculator results that displays the operation, operands, and result with appropriate styling.
2. A help command that renders Markdown-formatted documentation.
3. A "history" feature that displays past calculations in a tree structure.
4. Enhanced exception handling for division by zero and invalid inputs.
5. A live display that shows randomly generated calculations updating in real-time.
6. An advanced layout that includes a header, footer, operation list, and main calculation area.
7. Ensure all features work correctly on Windows, macOS, and Linux.

By completing this exercise, you'll gain hands-on experience with advanced Rich features, creating a sophisticated CLI application that provides a rich user experience across different platforms. This will solidify your understanding of both Rich and cross-platform CLI development.
