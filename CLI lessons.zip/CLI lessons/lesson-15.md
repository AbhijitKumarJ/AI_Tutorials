# Lesson 15: Testing and Packaging CLI Applications

## Introduction

Welcome to lesson 15 of our "Mastering Python CLI Libraries: From Novice to Expert" series! In this lesson, we'll focus on testing and packaging our TaskMaster CLI application. We'll cover unit testing, integration testing, packaging for PyPI distribution, creating installable scripts, and setting up continuous integration for our CLI app.

By the end of this lesson, you'll understand how to:

1. Write and run unit tests for CLI apps using pytest and click.testing
2. Perform integration testing with subprocess
3. Package your CLI app for PyPI distribution
4. Create installable scripts
5. Set up continuous integration for your CLI app

Let's start by updating our project structure to include tests and packaging files:

```
taskmaster/
│
├── taskmaster/
│   ├── __init__.py
│   ├── cli.py
│   ├── commands/
│   ├── models/
│   ├── utils/
│   └── ui/
│
├── tests/
│   ├── __init__.py
│   ├── conftest.py
│   ├── test_cli.py
│   ├── test_commands/
│   │   ├── __init__.py
│   │   ├── test_task.py
│   │   ├── test_project.py
│   │   └── test_report.py
│   └── test_models/
│       ├── __init__.py
│       ├── test_task.py
│       └── test_project.py
│
├── config.yaml
├── requirements.txt
├── setup.py
├── MANIFEST.in
├── README.md
├── LICENSE
└── .github/
    └── workflows/
        └── ci.yml
```

## 1. Unit Testing with pytest and click.testing

First, let's set up our testing environment. Add the following to your `requirements.txt` file:

```
pytest==7.3.1
pytest-cov==4.0.0
```

Now, let's create a `conftest.py` file in the `tests/` directory to set up our test fixtures:

```python
import pytest
from click.testing import CliRunner
from taskmaster.cli import cli
from taskmaster.utils.database import get_engine, get_session, Base
from taskmaster.utils.config import CONFIG

@pytest.fixture(scope="function")
def runner():
    return CliRunner()

@pytest.fixture(scope="function")
def test_app():
    # Use an in-memory SQLite database for testing
    CONFIG['database']['url'] = "sqlite:///:memory:"
    engine = get_engine(CONFIG['database']['url'])
    Base.metadata.create_all(engine)
    session = get_session(engine)
    
    yield cli
    
    session.close()
    Base.metadata.drop_all(engine)

@pytest.fixture(scope="function")
def test_session():
    engine = get_engine(CONFIG['database']['url'])
    session = get_session(engine)
    yield session
    session.close()
```

Now, let's write some unit tests for our task commands. Create a file `tests/test_commands/test_task.py`:

```python
import pytest
from taskmaster.models.task import Task

def test_add_task(runner, test_app, test_session):
    result = runner.invoke(test_app, ['task', 'add', '--title', 'Test Task', '--description', 'This is a test task'])
    assert result.exit_code == 0
    assert "Task 'Test Task' added successfully!" in result.output
    
    # Check if the task was actually added to the database
    tasks = test_session.query(Task).all()
    assert len(tasks) == 1
    assert tasks[0].title == 'Test Task'
    assert tasks[0].description == 'This is a test task'

def test_list_tasks(runner, test_app, test_session):
    # Add some tasks to the database
    test_session.add(Task(title='Task 1', status='Not Started'))
    test_session.add(Task(title='Task 2', status='In Progress'))
    test_session.commit()
    
    result = runner.invoke(test_app, ['task', 'list'])
    assert result.exit_code == 0
    assert 'Task 1' in result.output
    assert 'Task 2' in result.output
    assert 'Not Started' in result.output
    assert 'In Progress' in result.output

def test_list_tasks_with_status_filter(runner, test_app, test_session):
    test_session.add(Task(title='Task 1', status='Not Started'))
    test_session.add(Task(title='Task 2', status='In Progress'))
    test_session.commit()
    
    result = runner.invoke(test_app, ['task', 'list', '--status', 'Not Started'])
    assert result.exit_code == 0
    assert 'Task 1' in result.output
    assert 'Task 2' not in result.output
    assert 'Not Started' in result.output
    assert 'In Progress' not in result.output
```

To run the tests, use the following command:

```
pytest tests/ -v
```

## 2. Integration Testing with subprocess

While unit tests are great for testing individual components, integration tests help ensure that your CLI app works correctly as a whole. Let's create an integration test that runs our CLI app as a subprocess.

Create a new file `tests/test_integration.py`:

```python
import subprocess
import sys

def test_cli_integration():
    # Run the CLI app as a subprocess
    result = subprocess.run(
        [sys.executable, '-m', 'taskmaster.cli', 'task', 'add', '--title', 'Integration Test Task', '--description', 'This is an integration test'],
        capture_output=True,
        text=True
    )
    
    assert result.returncode == 0
    assert "Task 'Integration Test Task' added successfully!" in result.stdout
    
    # Now, let's check if we can list the task
    result = subprocess.run(
        [sys.executable, '-m', 'taskmaster.cli', 'task', 'list'],
        capture_output=True,
        text=True
    )
    
    assert result.returncode == 0
    assert 'Integration Test Task' in result.stdout
    assert 'This is an integration test' in result.stdout
```

## 3. Packaging for PyPI Distribution

To package our CLI app for PyPI distribution, we need to update our `setup.py` file and create a `MANIFEST.in` file.

Update `setup.py`:

```python
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="taskmaster-cli",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A CLI task management system",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/taskmaster",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "Click",
        "Rich",
        "prompt-toolkit",
        "PyYAML",
        "SQLAlchemy",
    ],
    entry_points={
        "console_scripts": [
            "taskmaster=taskmaster.cli:cli",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
    ],
    python_requires=">=3.7",
)
```

Create a `MANIFEST.in` file in the project root:

```
include README.md
include LICENSE
include config.yaml
recursive-include taskmaster *.py
```

To build your package, run:

```
python setup.py sdist bdist_wheel
```

This will create a `dist/` directory with your package files.

## 4. Creating Installable Scripts

We've already set up an installable script in our `setup.py` file using the `entry_points` parameter. This creates a `taskmaster` command that users can run after installing your package.

To test the installable script locally, you can use:

```
pip install -e .
```

This installs your package in "editable" mode, allowing you to make changes and immediately see their effects.

## 5. Continuous Integration for CLI Apps

Let's set up a GitHub Actions workflow for continuous integration. Create a file `.github/workflows/ci.yml`:

```yaml
name: TaskMaster CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: [3.7, 3.8, 3.9]

    steps:
    - uses: actions/checkout@v2
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v2
      with:
        python-version: ${{ matrix.python-version }}
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Run tests
      run: |
        pytest tests/ -v --cov=taskmaster
    - name: Upload coverage to Codecov
      uses: codecov/codecov-action@v1

  lint:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: 3.9
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install flake8
    - name: Run linter
      run: |
        flake8 taskmaster/ tests/
```

This workflow will run your tests on multiple Python versions and perform linting on your code whenever you push changes or create a pull request.

## Conclusion

In this lesson, we've covered the essential aspects of testing and packaging CLI applications:

1. Writing and running unit tests using pytest and click.testing
2. Performing integration tests with subprocess
3. Packaging the CLI app for PyPI distribution
4. Creating installable scripts
5. Setting up continuous integration with GitHub Actions

These practices will help ensure the quality and reliability of your CLI application, making it easier to maintain and distribute to users.

## Exercise

1. Write additional unit tests to cover all commands in your TaskMaster application.
2. Create more integration tests to ensure all major workflows in your CLI app work correctly.
3. Set up test coverage reporting and aim for at least 80% code coverage.
4. Create a mock PyPI account and try uploading your package to TestPyPI.
5. Extend the CI workflow to include automatic deployment to PyPI when a new release is tagged.

Remember to always test your application thoroughly before releasing it to users. Happy coding, and see you in the next lesson where we'll explore advanced topics and best practices for CLI applications!
