# Lesson 5: Enhancing Output with Rich

In this lesson, we'll explore Rich, a Python library for rich text and beautiful formatting in the terminal. Rich can add color and style to terminal output, render pretty tables, show syntax highlighted code, and much more.

## 1. Introduction to Rich

Rich is a Python library that makes it easy to add color and style to terminal output. It can also render pretty tables, syntax highlighted code, markdown, and more, right in your terminal.

### Key Features of Rich:

1. Colors and styles
2. Tables and panels
3. Syntax highlighting
4. Progress bars
5. Markdown rendering
6. Traceback formatting

## 2. Installing Rich

Before we start, we need to install Rich. Use pip to install it:

```
pip install rich
```

This command works across Windows, macOS, and Linux.

## 3. Basic Rich Concepts

Before we dive into coding, let's understand some key concepts:

1. **Console**: The main object used to print rich content to the terminal.
2. **Text**: A string-like object that can have style attributes.
3. **Panel**: A container for text with a border.
4. **Table**: A way to display tabular data.
5. **Syntax**: For displaying syntax-highlighted code.

## 4. Creating a Simple CLI with Rich

Let's enhance our calculator application using Rich to make the output more visually appealing and informative.

### Project Structure:
```
rich_calculator/
│
├── calc.py
└── README.md
```

### calc.py
```python
import click
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.table import Table

console = Console()

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        raise click.ClickException("Cannot divide by zero")
    return a / b

@click.group()
def cli():
    """A calculator CLI with rich output"""
    pass

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
def add_cmd(x, y):
    """Add two numbers"""
    result = add(x, y)
    text = Text(f"{x} + {y} = {result}")
    text.stylize("bold magenta")
    console.print(Panel(text, title="Addition Result", expand=False))

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
def subtract_cmd(x, y):
    """Subtract two numbers"""
    result = subtract(x, y)
    text = Text(f"{x} - {y} = {result}")
    text.stylize("bold cyan")
    console.print(Panel(text, title="Subtraction Result", expand=False))

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
def multiply_cmd(x, y):
    """Multiply two numbers"""
    result = multiply(x, y)
    text = Text(f"{x} * {y} = {result}")
    text.stylize("bold green")
    console.print(Panel(text, title="Multiplication Result", expand=False))

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
def divide_cmd(x, y):
    """Divide two numbers"""
    try:
        result = divide(x, y)
        text = Text(f"{x} / {y} = {result}")
        text.stylize("bold yellow")
        console.print(Panel(text, title="Division Result", expand=False))
    except click.ClickException as e:
        console.print(Panel(str(e), title="Error", style="bold red"))

@cli.command()
def table_cmd():
    """Display a table of operations"""
    table = Table(title="Calculator Operations")
    table.add_column("Operation", style="cyan")
    table.add_column("Description", style="magenta")
    table.add_column("Usage", style="green")
    
    table.add_row("add", "Addition", "calc.py add X Y")
    table.add_row("subtract", "Subtraction", "calc.py subtract X Y")
    table.add_row("multiply", "Multiplication", "calc.py multiply X Y")
    table.add_row("divide", "Division", "calc.py divide X Y")
    
    console.print(table)

if __name__ == '__main__':
    cli()
```

### Explanation:

1. We import necessary components from Rich: `Console`, `Panel`, `Text`, and `Table`.
2. We create a `Console` object, which we'll use to print rich output.
3. Each command now uses Rich to format its output:
   - Results are displayed in colored `Panel`s.
   - We use `Text` objects to apply styles to our output strings.
   - Error messages are displayed in red panels.
4. We added a new `table_cmd` that displays a table of available operations.

### Usage:

To use this CLI, open a terminal, navigate to the `rich_calculator` directory, and run commands like:

```
python calc.py add 5 3
python calc.py subtract 10 4
python calc.py multiply 2 6
python calc.py divide 15 3
python calc.py table
```

## 5. Cross-Platform Considerations with Rich

Rich is designed to work across different platforms, but there are some considerations:

1. **Color Support**: Rich automatically detects color support, but you can force it on or off:
   ```python
   console = Console(force_terminal=True)  # Force color on
   console = Console(no_color=True)  # Force color off
   ```

2. **Emoji Support**: Emoji rendering can vary across platforms. You can disable emoji:
   ```python
   console = Console(emoji=False)
   ```

3. **Terminal Size**: Rich tries to detect the terminal size, but you can set it manually:
   ```python
   console = Console(width=80, height=24)
   ```

4. **Windows Compatibility**: On Windows, you might need to enable ANSI color support:
   ```python
   import os
   os.system('color')
   ```

## 6. Advanced Rich Features

Let's expand our calculator to demonstrate some more advanced features of Rich:

### calc_advanced.py
```python
import click
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
from rich.syntax import Syntax
from rich.progress import Progress
from rich import print as rprint
import time

console = Console()

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        raise click.ClickException("Cannot divide by zero")
    return a / b

@click.group()
def cli():
    """An advanced calculator CLI with rich output"""
    pass

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
@click.option('--progress', is_flag=True, help="Show a progress bar")
def add_cmd(x, y, progress):
    """Add two numbers"""
    if progress:
        with Progress() as progress:
            task = progress.add_task("[green]Calculating...", total=100)
            for i in range(100):
                time.sleep(0.01)  # Simulate work
                progress.update(task, advance=1)
    result = add(x, y)
    text = Text(f"{x} + {y} = {result}")
    text.stylize("bold magenta")
    console.print(Panel(text, title="Addition Result", expand=False))

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
def subtract_cmd(x, y):
    """Subtract two numbers"""
    result = subtract(x, y)
    text = Text(f"{x} - {y} = {result}")
    text.stylize("bold cyan")
    console.print(Panel(text, title="Subtraction Result", expand=False))

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
def multiply_cmd(x, y):
    """Multiply two numbers"""
    result = multiply(x, y)
    text = Text(f"{x} * {y} = {result}")
    text.stylize("bold green")
    console.print(Panel(text, title="Multiplication Result", expand=False))

@cli.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
def divide_cmd(x, y):
    """Divide two numbers"""
    try:
        result = divide(x, y)
        text = Text(f"{x} / {y} = {result}")
        text.stylize("bold yellow")
        console.print(Panel(text, title="Division Result", expand=False))
    except click.ClickException as e:
        console.print(Panel(str(e), title="Error", style="bold red"))

@cli.command()
def table_cmd():
    """Display a table of operations"""
    table = Table(title="Calculator Operations")
    table.add_column("Operation", style="cyan")
    table.add_column("Description", style="magenta")
    table.add_column("Usage", style="green")
    
    table.add_row("add", "Addition", "calc.py add X Y")
    table.add_row("subtract", "Subtraction", "calc.py subtract X Y")
    table.add_row("multiply", "Multiplication", "calc.py multiply X Y")
    table.add_row("divide", "Division", "calc.py divide X Y")
    
    console.print(table)

@cli.command()
def demo_cmd():
    """Demonstrate various Rich features"""
    # Syntax highlighting
    code = '''
def fibonacci(n):
    if n <= 1:
        return n
    else:
        return fibonacci(n-1) + fibonacci(n-2)
    '''
    syntax = Syntax(code, "python", theme="monokai", line_numbers=True)
    console.print(Panel(syntax, title="Syntax Highlighting"))

    # Rich print
    rprint("[bold red]This is bold red[/bold red] and this is [blue underline]blue underlined[/blue underline].")

    # Table with emoji
    table = Table(title="Fruit Inventory")
    table.add_column("Fruit", style="cyan")
    table.add_column("Quantity", justify="right", style="green")
    table.add_row("🍎 Apple", "5")
    table.add_row("🍌 Banana", "3")
    table.add_row("🍇 Grape", "10")
    console.print(table)

if __name__ == '__main__':
    cli()
```

### New Features Explained:

1. **Progress Bar**: We've added a progress bar to the `add` command using Rich's `Progress` class.
2. **Syntax Highlighting**: The `demo_cmd` showcases syntax highlighting for Python code.
3. **Rich Print**: We demonstrate inline styling using Rich's `print` function.
4. **Emoji**: The fruit inventory table includes emoji, showcasing Rich's emoji support.

### Usage Examples:

```
python calc_advanced.py add 5 3 --progress
python calc_advanced.py subtract 10 4
python calc_advanced.py multiply 2 6
python calc_advanced.py divide 15 3
python calc_advanced.py table
python calc_advanced.py demo
```

## Conclusion

In this lesson, we've explored Rich, a powerful library for creating beautiful and informative terminal output. We've covered basic usage, cross-platform considerations, and advanced features like progress bars, syntax highlighting, and emoji support. Rich provides an excellent way to enhance the user experience of your CLI applications across different operating systems.

## Exercise

1. Extend the calculator application to include more operations (e.g., power, square root, logarithm).
2. Create a "history" command that displays the last 5 calculations in a Rich table, with different colors for different operations.
3. Implement a "help" command that uses Rich to display a beautifully formatted help message for each command, including syntax highlighting for usage examples.
4. Add a progress bar to all operations, with the progress speed proportional to the complexity of the calculation.
5. Create a "stats" command that displays various statistics about the calculator usage (e.g., most used operation, average result) in a Rich panel with a nested table.
6. Ensure all new features work correctly on Windows, macOS, and Linux.

By completing this exercise, you'll gain hands-on experience in using Rich to create visually appealing and informative CLI applications. You'll also practice integrating Rich with Click and ensuring cross-platform compatibility.
