# Lesson 4: Advanced Click Features

In this lesson, we'll dive deeper into Click's advanced features, exploring how to create more complex and powerful command-line interfaces. We'll build upon our calculator example, adding new functionalities and demonstrating advanced Click concepts.

## 1. Custom Parameter Types

Click allows you to create custom parameter types for more complex input validation and transformation.

### Example: Creating a Custom Range Type

Let's create a custom type that ensures a number is within a specified range:

```python
import click

class RangeType(click.ParamType):
    name = "range"

    def __init__(self, min=None, max=None):
        self.min = min
        self.max = max

    def convert(self, value, param, ctx):
        try:
            value = float(value)
        except ValueError:
            self.fail(f"{value} is not a valid number", param, ctx)
        
        if self.min is not None and value < self.min:
            self.fail(f"{value} is smaller than the minimum valid value {self.min}", param, ctx)
        if self.max is not None and value > self.max:
            self.fail(f"{value} is bigger than the maximum valid value {self.max}", param, ctx)
        
        return value

@click.command()
@click.argument('number', type=RangeType(0, 100))
def process_number(number):
    click.echo(f"The number is: {number}")

if __name__ == '__main__':
    process_number()
```

This custom type ensures that the input is a number between 0 and 100.

## 2. Command and Parameter Callbacks

Callbacks allow you to execute code before the command function is called. This can be useful for complex parameter processing or setup tasks.

### Example: Using Callbacks

```python
import click

def validate_operation(ctx, param, value):
    valid_operations = ['add', 'subtract', 'multiply', 'divide']
    if value.lower() not in valid_operations:
        raise click.BadParameter(f"Operation must be one of: {', '.join(valid_operations)}")
    return value.lower()

@click.command()
@click.option('--operation', callback=validate_operation, help='The operation to perform')
@click.argument('x', type=float)
@click.argument('y', type=float)
def calculate(operation, x, y):
    if operation == 'add':
        result = x + y
    elif operation == 'subtract':
        result = x - y
    elif operation == 'multiply':
        result = x * y
    elif operation == 'divide':
        result = x / y
    click.echo(f"Result: {result}")

if __name__ == '__main__':
    calculate()
```

This example uses a callback to validate the operation before the command function is called.

## 3. Dynamic Command Creation

Click allows you to create commands dynamically, which can be useful when you want to generate commands based on external data or configuration.

### Example: Dynamically Created Commands

```python
import click

@click.group()
def cli():
    pass

operations = {
    'add': lambda x, y: x + y,
    'subtract': lambda x, y: x - y,
    'multiply': lambda x, y: x * y,
    'divide': lambda x, y: x / y if y != 0 else "Cannot divide by zero"
}

for op_name, op_func in operations.items():
    @cli.command(name=op_name)
    @click.argument('x', type=float)
    @click.argument('y', type=float)
    def command_func(x, y, op_name=op_name, op_func=op_func):
        result = op_func(x, y)
        click.echo(f"Result of {op_name}: {result}")

if __name__ == '__main__':
    cli()
```

This script dynamically creates a command for each operation in the `operations` dictionary.

## 4. Testing Click Applications

Testing CLI applications is crucial for ensuring reliability. Click provides tools to make testing easier.

### Example: Testing a Click Application

First, let's create a simple Click application to test:

```python
# calculator.py
import click

@click.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
@click.option('--operation', default='add', help='Operation to perform')
def calculate(x, y, operation):
    if operation == 'add':
        result = x + y
    elif operation == 'subtract':
        result = x - y
    else:
        raise click.BadParameter("Invalid operation")
    click.echo(f"Result: {result}")

if __name__ == '__main__':
    calculate()
```

Now, let's create a test file:

```python
# test_calculator.py
from click.testing import CliRunner
from calculator import calculate

def test_calculate_add():
    runner = CliRunner()
    result = runner.invoke(calculate, ['5', '3'])
    assert result.exit_code == 0
    assert "Result: 8.0" in result.output

def test_calculate_subtract():
    runner = CliRunner()
    result = runner.invoke(calculate, ['10', '4', '--operation', 'subtract'])
    assert result.exit_code == 0
    assert "Result: 6.0" in result.output

def test_calculate_invalid_operation():
    runner = CliRunner()
    result = runner.invoke(calculate, ['5', '3', '--operation', 'multiply'])
    assert result.exit_code != 0
    assert "Invalid operation" in result.output
```

To run these tests, you'll need to install pytest (`pip install pytest`), then run `pytest test_calculator.py`.

## 5. Packaging Click Apps with setuptools

To distribute your Click application, you can use setuptools to create a package. Here's how to set it up:

### Project Structure:
```
my_calculator/
│
├── my_calculator/
│   ├── __init__.py
│   └── cli.py
├── tests/
│   └── test_cli.py
├── setup.py
└── README.md
```

### cli.py
```python
import click

@click.command()
@click.argument('x', type=float)
@click.argument('y', type=float)
@click.option('--operation', default='add', help='Operation to perform')
def calculate(x, y, operation):
    if operation == 'add':
        result = x + y
    elif operation == 'subtract':
        result = x - y
    else:
        raise click.BadParameter("Invalid operation")
    click.echo(f"Result: {result}")

if __name__ == '__main__':
    calculate()
```

### setup.py
```python
from setuptools import setup, find_packages

setup(
    name='my-calculator',
    version='0.1',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'Click',
    ],
    entry_points={
        'console_scripts': [
            'my-calculator=my_calculator.cli:calculate',
        ],
    },
)
```

To install your package locally for testing:

```
pip install -e .
```

Now you can run your CLI application from anywhere by typing `my-calculator` in the terminal.

## 6. Cross-Platform Considerations

When developing CLI applications with Click, keep these cross-platform considerations in mind:

1. **File Paths**: Use `click.Path()` for file path arguments to ensure proper handling across different operating systems.

2. **Environment Variables**: Click can read from environment variables, which work across platforms:

   ```python
   @click.option('--config', envvar='APP_CONFIG', type=click.Path())
   ```

3. **Colors and Styling**: Click automatically detects color support, but you can override it:

   ```python
   import click
   click.echo(click.style('Error!', fg='red'), color=sys.stderr.isatty())
   ```

4. **Launching Editors**: Use Click's `edit()` function for a cross-platform way to launch text editors:

   ```python
   content = click.edit('Edit this content')
   ```

5. **Prompting for Input**: Click's `prompt()` function works consistently across platforms:

   ```python
   name = click.prompt('Please enter your name', default='John Doe')
   ```

## Conclusion

In this lesson, we've explored advanced features of Click, including custom types, callbacks, dynamic command creation, testing, and packaging. We've also revisited cross-platform considerations to ensure our CLI applications work smoothly across different operating systems.

These advanced features allow you to create more sophisticated, user-friendly, and robust command-line interfaces. By mastering these concepts, you'll be able to develop professional-grade CLI applications that can handle complex scenarios and provide excellent user experiences.

## Exercise

1. Create a new Click application that manages a simple todo list. It should have the following commands:
   - `add`: Add a new task
   - `list`: List all tasks
   - `complete`: Mark a task as complete
   - `delete`: Delete a task

2. Implement a custom type for the task priority (High, Medium, Low).

3. Use callbacks to validate that task descriptions are not empty.

4. Implement a dynamic command creation for different categories of tasks (e.g., Work, Personal, Shopping).

5. Write tests for your application using the Click testing tools.

6. Package your application using setuptools so it can be installed with pip.

7. Ensure your application works correctly on Windows, macOS, and Linux (if you have access to these platforms).

By completing this exercise, you'll get hands-on experience with advanced Click features, testing, packaging, and cross-platform development. This will solidify your understanding and prepare you for building complex CLI applications in real-world scenarios.
