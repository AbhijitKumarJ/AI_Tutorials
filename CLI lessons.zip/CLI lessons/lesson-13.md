# Lesson 13: Cross-Platform Considerations

## Introduction

Welcome to lesson 13 of our "Mastering Python CLI Libraries: From Novice to Expert" series! In this lesson, we'll dive into the important topic of cross-platform considerations when developing command-line interface (CLI) applications. As a CLI developer, it's crucial to ensure that your application works seamlessly across different operating systems, primarily Windows, macOS, and Linux.

By the end of this lesson, you'll understand:
1. How to handle different operating systems
2. Console input/output differences
3. File system operations across platforms
4. Creating standalone executables with PyInstaller

Let's start by setting up our project structure:

```
cross_platform_cli/
│
├── src/
│   ├── __init__.py
│   ├── main.py
│   ├── file_operations.py
│   └── console_io.py
│
├── tests/
│   ├── __init__.py
│   ├── test_file_operations.py
│   └── test_console_io.py
│
├── requirements.txt
└── README.md
```

## 1. Handling Different Operating Systems

Python provides the `os` and `sys` modules, which are essential for writing cross-platform code. Let's look at how to use them to detect the operating system and adjust our code accordingly.

In `src/main.py`:

```python
import os
import sys

def get_operating_system():
    if sys.platform.startswith('win'):
        return 'Windows'
    elif sys.platform.startswith('darwin'):
        return 'macOS'
    elif sys.platform.startswith('linux'):
        return 'Linux'
    else:
        return 'Unknown'

def main():
    os_name = get_operating_system()
    print(f"Running on {os_name}")

    # OS-specific operations
    if os_name == 'Windows':
        print("Performing Windows-specific operations")
    elif os_name == 'macOS':
        print("Performing macOS-specific operations")
    elif os_name == 'Linux':
        print("Performing Linux-specific operations")
    else:
        print("Unsupported operating system")

if __name__ == "__main__":
    main()
```

This code demonstrates how to detect the operating system and perform specific actions based on the detected OS.

## 2. Console Input/Output Differences

Console input and output can vary across different operating systems, especially when it comes to color support and special characters. Let's create a module to handle these differences.

In `src/console_io.py`:

```python
import sys
import os

def clear_screen():
    if sys.platform.startswith('win'):
        os.system('cls')  # For Windows
    else:
        os.system('clear')  # For macOS and Linux

def print_colored(text, color):
    colors = {
        'red': '\033[91m',
        'green': '\033[92m',
        'yellow': '\033[93m',
        'blue': '\033[94m',
        'reset': '\033[0m'
    }
    
    if sys.platform.startswith('win'):
        # Windows doesn't support ANSI escape codes in the default console
        print(text)
    else:
        print(f"{colors.get(color, '')}{text}{colors['reset']}")

def get_input_with_arrow():
    if sys.platform.startswith('win'):
        arrow = '>'  # Windows Command Prompt doesn't support Unicode arrows
    else:
        arrow = '➜'  # Unicode arrow for macOS and Linux
    return input(f"{arrow} ")
```

This module provides functions for clearing the screen, printing colored text, and customizing input prompts based on the operating system.

## 3. File System Operations Across Platforms

File system operations can be tricky when working across different platforms due to differences in path separators and file permissions. Let's create a module to handle these operations in a cross-platform manner.

In `src/file_operations.py`:

```python
import os
import shutil

def create_directory(path):
    os.makedirs(path, exist_ok=True)

def write_file(path, content):
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)

def read_file(path):
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()

def delete_file(path):
    os.remove(path)

def copy_file(src, dst):
    shutil.copy2(src, dst)

def get_absolute_path(relative_path):
    return os.path.abspath(relative_path)

def join_paths(*paths):
    return os.path.join(*paths)
```

This module uses the `os` and `shutil` modules to perform file operations in a cross-platform manner. The `os.path` functions handle path separators correctly across different operating systems.

Now, let's update our `main.py` to use these modules:

```python
from console_io import clear_screen, print_colored, get_input_with_arrow
from file_operations import create_directory, write_file, read_file, delete_file, copy_file, get_absolute_path, join_paths

def main():
    clear_screen()
    print_colored("Welcome to the Cross-Platform CLI Demo!", "green")
    
    # File operations demo
    demo_dir = join_paths(get_absolute_path('.'), 'demo_files')
    create_directory(demo_dir)
    
    file_path = join_paths(demo_dir, 'test.txt')
    write_file(file_path, "Hello, Cross-Platform World!")
    
    content = read_file(file_path)
    print_colored(f"File content: {content}", "blue")
    
    copy_path = join_paths(demo_dir, 'test_copy.txt')
    copy_file(file_path, copy_path)
    
    print_colored("Files in the demo directory:", "yellow")
    for file in os.listdir(demo_dir):
        print(file)
    
    delete_file(file_path)
    delete_file(copy_path)
    os.rmdir(demo_dir)
    
    user_input = get_input_with_arrow()
    print_colored(f"You entered: {user_input}", "green")

if __name__ == "__main__":
    main()
```

## 4. Creating Standalone Executables with PyInstaller

PyInstaller is a powerful tool that allows you to create standalone executables from your Python scripts. This is particularly useful for distributing your CLI application to users who may not have Python installed on their systems.

First, install PyInstaller:

```
pip install pyinstaller
```

Now, let's create a standalone executable for our cross-platform CLI demo:

```
pyinstaller --onefile src/main.py
```

This command will create a `dist` directory containing the standalone executable. The `--onefile` option bundles everything into a single executable file.

### Platform-specific considerations for PyInstaller:

1. **Windows**:
   - The generated executable will have a `.exe` extension.
   - You may need to add your script to Windows Defender exclusions to avoid false positives.

2. **macOS**:
   - You may need to code sign your application for distribution.
   - Use `--windowed` option for GUI applications to prevent the terminal from opening.

3. **Linux**:
   - Ensure that the appropriate libraries are available on the target system.
   - You may need to set the executable bit after copying the file to another system.

## Conclusion

In this lesson, we've covered the essential aspects of creating cross-platform CLI applications in Python. We've learned how to:

1. Detect and handle different operating systems
2. Manage console input/output differences
3. Perform file system operations in a cross-platform manner
4. Create standalone executables using PyInstaller

Remember that testing your application on different operating systems is crucial to ensure compatibility. Always consider the target platforms when designing and implementing your CLI applications.

In the next lesson, we'll build upon these concepts to create a complete CLI application that works seamlessly across different operating systems.

## Exercise

1. Extend the `file_operations.py` module to include functions for listing directory contents and checking file permissions.
2. Create a simple CLI application that allows users to navigate their file system, create, read, and delete files. Ensure it works on Windows, macOS, and Linux.
3. Use PyInstaller to create standalone executables for your application on different operating systems. Test the executables to ensure they work correctly.

Happy coding, and see you in the next lesson!
