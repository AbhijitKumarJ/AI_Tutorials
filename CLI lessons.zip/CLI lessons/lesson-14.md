# Lesson 14: Building a Complete CLI Application

## Introduction

Welcome to lesson 14 of our "Mastering Python CLI Libraries: From Novice to Expert" series! In this lesson, we'll put everything we've learned so far into practice by building a complete CLI application. We'll create a task management system called "TaskMaster" that allows users to manage their tasks, projects, and deadlines from the command line.

By the end of this lesson, you'll understand how to:

1. Design a multi-command application
2. Combine multiple libraries (Click, Rich, and Prompt Toolkit)
3. Implement configuration files
4. Set up logging and error handling
5. Optimize performance

Let's start by setting up our project structure:

```
taskmaster/
│
├── taskmaster/
│   ├── __init__.py
│   ├── cli.py
│   ├── commands/
│   │   ├── __init__.py
│   │   ├── task.py
│   │   ├── project.py
│   │   └── report.py
│   ├── models/
│   │   ├── __init__.py
│   │   ├── task.py
│   │   └── project.py
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── config.py
│   │   ├── database.py
│   │   └── logger.py
│   └── ui/
│       ├── __init__.py
│       └── prompts.py
│
├── tests/
│   ├── __init__.py
│   ├── test_cli.py
│   ├── test_commands/
│   │   ├── __init__.py
│   │   ├── test_task.py
│   │   ├── test_project.py
│   │   └── test_report.py
│   └── test_models/
│       ├── __init__.py
│       ├── test_task.py
│       └── test_project.py
│
├── config.yaml
├── requirements.txt
├── setup.py
└── README.md
```

Now, let's implement each component of our TaskMaster application.

## 1. Setting up the project

First, let's create our `setup.py` file to make our project installable:

```python
from setuptools import setup, find_packages

setup(
    name="taskmaster",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "Click",
        "Rich",
        "prompt-toolkit",
        "PyYAML",
        "SQLAlchemy",
    ],
    entry_points={
        "console_scripts": [
            "taskmaster=taskmaster.cli:cli",
        ],
    },
)
```

Next, let's create our `requirements.txt` file:

```
Click==8.0.3
Rich==10.16.2
prompt-toolkit==3.0.24
PyYAML==6.0
SQLAlchemy==1.4.29
```

## 2. Implementing the core functionality

Let's start by implementing our data models. In `taskmaster/models/task.py`:

```python
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from taskmaster.utils.database import Base

class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True)
    title = Column(String, nullable=False)
    description = Column(String)
    due_date = Column(DateTime)
    status = Column(String, default="Not Started")
    project_id = Column(Integer, ForeignKey("projects.id"))

    project = relationship("Project", back_populates="tasks")

    def __repr__(self):
        return f"<Task(id={self.id}, title='{self.title}', status='{self.status}')>"
```

And in `taskmaster/models/project.py`:

```python
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from taskmaster.utils.database import Base

class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    description = Column(String)

    tasks = relationship("Task", back_populates="project")

    def __repr__(self):
        return f"<Project(id={self.id}, name='{self.name}')>"
```

Now, let's set up our database utility in `taskmaster/utils/database.py`:

```python
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

def get_engine(db_url):
    return create_engine(db_url)

def get_session(engine):
    Session = sessionmaker(bind=engine)
    return Session()
```

## 3. Implementing configuration

Let's create a configuration system using YAML. In `taskmaster/utils/config.py`:

```python
import os
import yaml

def load_config():
    config_path = os.path.join(os.path.dirname(__file__), '..', '..', 'config.yaml')
    with open(config_path, 'r') as config_file:
        return yaml.safe_load(config_file)

CONFIG = load_config()
```

And create a `config.yaml` file in the project root:

```yaml
database:
  url: "sqlite:///taskmaster.db"

logging:
  level: "INFO"
  file: "taskmaster.log"
```

## 4. Setting up logging

In `taskmaster/utils/logger.py`:

```python
import logging
from taskmaster.utils.config import CONFIG

def setup_logger():
    logging.basicConfig(
        level=CONFIG['logging']['level'],
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        filename=CONFIG['logging']['file']
    )
    return logging.getLogger(__name__)

logger = setup_logger()
```

## 5. Implementing commands

Now, let's implement our CLI commands. In `taskmaster/commands/task.py`:

```python
import click
from rich.console import Console
from rich.table import Table
from taskmaster.models.task import Task
from taskmaster.utils.database import get_engine, get_session
from taskmaster.utils.config import CONFIG
from taskmaster.utils.logger import logger

console = Console()

@click.group()
def task():
    """Manage tasks."""
    pass

@task.command()
@click.option('--title', prompt='Task title', help='Title of the task')
@click.option('--description', prompt='Task description', help='Description of the task')
@click.option('--due-date', type=click.DateTime(), help='Due date of the task (YYYY-MM-DD)')
@click.option('--project-id', type=int, help='ID of the project this task belongs to')
def add(title, description, due_date, project_id):
    """Add a new task."""
    engine = get_engine(CONFIG['database']['url'])
    session = get_session(engine)

    new_task = Task(title=title, description=description, due_date=due_date, project_id=project_id)
    session.add(new_task)
    session.commit()

    logger.info(f"Added new task: {new_task}")
    console.print(f"Task '{title}' added successfully!", style="bold green")

@task.command()
@click.option('--status', type=click.Choice(['Not Started', 'In Progress', 'Completed']))
def list(status):
    """List all tasks, optionally filtered by status."""
    engine = get_engine(CONFIG['database']['url'])
    session = get_session(engine)

    query = session.query(Task)
    if status:
        query = query.filter(Task.status == status)

    tasks = query.all()

    table = Table(title="Tasks")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Title", style="magenta")
    table.add_column("Status", style="green")
    table.add_column("Due Date", style="yellow")

    for task in tasks:
        table.add_row(
            str(task.id),
            task.title,
            task.status,
            task.due_date.strftime('%Y-%m-%d') if task.due_date else 'N/A'
        )

    console.print(table)

# Implement update and delete commands here
```

Similarly, implement project and report commands in their respective files.

## 6. Creating the main CLI entry point

In `taskmaster/cli.py`:

```python
import click
from taskmaster.commands import task, project, report

@click.group()
def cli():
    """TaskMaster - A CLI task management system."""
    pass

cli.add_command(task.task)
cli.add_command(project.project)
cli.add_command(report.report)

if __name__ == '__main__':
    cli()
```

## 7. Implementing interactive prompts

Let's add some interactive prompts using Prompt Toolkit. In `taskmaster/ui/prompts.py`:

```python
from prompt_toolkit import prompt
from prompt_toolkit.completion import WordCompleter

def get_task_details():
    title = prompt("Task title: ")
    description = prompt("Task description: ")
    due_date = prompt("Due date (YYYY-MM-DD): ")
    status_completer = WordCompleter(['Not Started', 'In Progress', 'Completed'])
    status = prompt("Status: ", completer=status_completer)

    return {
        'title': title,
        'description': description,
        'due_date': due_date,
        'status': status
    }
```

Update the `task.py` file to use this prompt:

```python
from taskmaster.ui.prompts import get_task_details

@task.command()
def add_interactive():
    """Add a new task interactively."""
    task_details = get_task_details()
    # Use the task_details to create a new task
    # ...
```

## 8. Performance Optimization

To optimize performance, we can implement caching for frequently accessed data and use database indexing. Add the following to your `Task` and `Project` models:

```python
from sqlalchemy import Index

class Task(Base):
    # ... existing code ...
    __table_args__ = (Index('ix_tasks_status', 'status'),)

class Project(Base):
    # ... existing code ...
    __table_args__ = (Index('ix_projects_name', 'name'),)
```

This adds indexes to the `status` column of the `tasks` table and the `name` column of the `projects` table, which can significantly speed up queries on these fields.

## Conclusion

In this lesson, we've built a complete CLI application called TaskMaster, which demonstrates how to:

1. Design a multi-command application using Click
2. Combine multiple libraries (Click, Rich, and Prompt Toolkit) for a better user experience
3. Implement configuration files using YAML
4. Set up logging for better debugging and monitoring
5. Use SQLAlchemy for database operations
6. Optimize performance with indexing

This application serves as a foundation that you can extend with more features, such as data visualization, export/import functionality, or integration with external services.

## Exercise

1. Implement the update and delete commands for tasks and projects.
2. Add a feature to set task priorities and sort tasks by priority.
3. Implement a simple reporting system that generates a summary of tasks and projects.
4. Add unit tests for the main functionalities of the application.
5. Create a user guide for the TaskMaster application, explaining how to use each command and feature.

Remember to test your application thoroughly on different operating systems to ensure cross-platform compatibility. Happy coding, and see you in the next lesson where we'll dive into testing and packaging CLI applications!
