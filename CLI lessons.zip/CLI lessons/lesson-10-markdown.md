# Lesson 10: Building Beautiful CLIs with Typer

Welcome to the tenth lesson in our "Mastering Python CLI Libraries: From Novice to Expert" series! In this lesson, we'll explore Typer, a modern library for building command-line interface (CLI) applications in Python. Typer is built on top of Click and leverages Python type hints to create intuitive and powerful CLIs with minimal code.

## Table of Contents
1. [Introduction](#introduction)
2. [Project Setup](#project-setup)
3. [Basic Typer Application](#basic-typer-application)
4. [Command Groups](#command-groups)
5. [Options and Arguments](#options-and-arguments)
6. [File Handling](#file-handling)
7. [Rich Integration](#rich-integration)
8. [Subcommands](#subcommands)
9. [Custom Types](#custom-types)
10. [Cross-Platform Considerations](#cross-platform-considerations)
11. [Conclusion](#conclusion)

## Introduction

Typer is designed to be easy to use, intuitive, and to help you create CLIs with Python type hints. It builds on top of Click, which we've covered in earlier lessons, but simplifies many aspects of CLI development. Typer is particularly well-suited for larger CLI applications with multiple commands and subcommands.

## Project Setup

Let's start by setting up our project. We'll create a new directory for this lesson and install the required packages.

```
typer_cli/
├── requirements.txt
├── basic_app.py
├── command_groups.py
├── options_arguments.py
├── file_handling.py
├── rich_integration.py
├── subcommands.py
└── custom_types.py
```

First, create a new directory called `typer_cli` and navigate into it:

```bash
mkdir typer_cli
cd typer_cli
```

Now, create a `requirements.txt` file with the following content:

```
typer==0.9.0
rich==13.3.5
```

Install the required packages:

```bash
pip install -r requirements.txt
```

## Basic Typer Application

Let's start with a simple Typer application to understand the basics. Create a file named `basic_app.py` with the following content:

```python
import typer

app = typer.Typer()

@app.command()
def hello(name: str = typer.Argument("World")):
    """
    Say hello to NAME (default is "World")
    """
    typer.echo(f"Hello {name}!")

@app.command()
def goodbye(name: str, formal: bool = False):
    """
    Say goodbye to NAME, with an option to be formal
    """
    if formal:
        typer.echo(f"Farewell, {name}. Have a good day.")
    else:
        typer.echo(f"Bye {name}!")

if __name__ == "__main__":
    app()
```

This script demonstrates a basic Typer application with two commands: `hello` and `goodbye`. Run the script to test the commands:

```bash
python basic_app.py hello
python basic_app.py hello Alice
python basic_app.py goodbye Bob
python basic_app.py goodbye Charlie --formal
```

## Command Groups

Typer allows you to organize your commands into groups, which is useful for larger applications. Create a file named `command_groups.py` with the following content:

```python
import typer

app = typer.Typer()
user_app = typer.Typer()
app.add_typer(user_app, name="user")

@app.command()
def main():
    """
    Welcome to the main application
    """
    typer.echo("Welcome to the main app!")

@user_app.command("create")
def user_create(name: str):
    """
    Create a new user
    """
    typer.echo(f"Creating user: {name}")

@user_app.command("delete")
def user_delete(name: str):
    """
    Delete a user
    """
    typer.echo(f"Deleting user: {name}")

if __name__ == "__main__":
    app()
```

This script demonstrates how to use command groups in Typer. Run the script to test the grouped commands:

```bash
python command_groups.py
python command_groups.py user create alice
python command_groups.py user delete bob
```

## Options and Arguments

Typer makes it easy to work with command-line options and arguments. Create a file named `options_arguments.py` with the following content:

```python
import typer

app = typer.Typer()

@app.command()
def greet(
    name: str = typer.Argument(..., help="The name of the person to greet"),
    count: int = typer.Option(1, "--count", "-c", help="Number of times to greet"),
    formal: bool = typer.Option(False, "--formal", "-f", help="Use formal greeting"),
):
    """
    Greet a person one or more times, with an option for formal greeting.
    """
    greeting = "Good day" if formal else "Hello"
    for _ in range(count):
        typer.echo(f"{greeting}, {name}!")

if __name__ == "__main__":
    app()
```

This script shows how to use arguments and options in Typer. Run the script to test different combinations of options and arguments:

```bash
python options_arguments.py Alice
python options_arguments.py Bob --count 3
python options_arguments.py Charlie -c 2 -f
```

## File Handling

Typer provides convenient ways to handle file input and output. Create a file named `file_handling.py` with the following content:

```python
import typer
from pathlib import Path
from typing import Optional

app = typer.Typer()

@app.command()
def process_file(
    input_file: Path = typer.Argument(..., help="Input file to process"),
    output_file: Optional[Path] = typer.Option(None, help="Output file (stdout if not specified)"),
):
    """
    Process a file and optionally write the result to another file.
    """
    try:
        content = input_file.read_text()
        processed_content = content.upper()  # Simple processing: convert to uppercase
        
        if output_file:
            output_file.write_text(processed_content)
            typer.echo(f"Processed content written to {output_file}")
        else:
            typer.echo(processed_content)
    except Exception as e:
        typer.echo(f"Error processing file: {e}", err=True)
        raise typer.Exit(code=1)

if __name__ == "__main__":
    app()
```

This script demonstrates file handling with Typer. To test it, first create a sample input file:

```bash
echo "Hello, World!" > input.txt
```

Then run the script:

```bash
python file_handling.py input.txt
python file_handling.py input.txt --output-file output.txt
```

## Rich Integration

Typer integrates well with Rich for beautiful console output. Create a file named `rich_integration.py` with the following content:

```python
import typer
from rich.console import Console
from rich.table import Table
from rich.progress import track
import time

app = typer.Typer()
console = Console()

@app.command()
def show_table():
    """
    Display a beautiful table using Rich
    """
    table = Table(title="Sample Data")
    table.add_column("Name", style="cyan")
    table.add_column("Age", style="magenta")
    table.add_column("City", style="green")

    table.add_row("Alice", "28", "New York")
    table.add_row("Bob", "35", "San Francisco")
    table.add_row("Charlie", "42", "London")

    console.print(table)

@app.command()
def progress_bar():
    """
    Display a progress bar using Rich
    """
    total = 100
    for _ in track(range(total), description="Processing..."):
        time.sleep(0.05)  # Simulate some work
    console.print("[bold green]Done![/bold green]")

if __name__ == "__main__":
    app()
```

This script shows how to integrate Rich with Typer for beautiful output. Run the script to see the Rich-formatted output:

```bash
python rich_integration.py show-table
python rich_integration.py progress-bar
```

## Subcommands

Typer makes it easy to create nested subcommands. Create a file named `subcommands.py` with the following content:

```python
import typer

app = typer.Typer()
db_app = typer.Typer()
app.add_typer(db_app, name="db")

@app.command()
def info():
    """
    Display general information about the application
    """
    typer.echo("This is a sample application with subcommands.")

@db_app.command("init")
def db_init():
    """
    Initialize the database
    """
    typer.echo("Initializing the database...")

@db_app.command("migrate")
def db_migrate(version: str):
    """
    Migrate the database to a specific version
    """
    typer.echo(f"Migrating database to version {version}")

if __name__ == "__main__":
    app()
```

This script demonstrates how to use nested subcommands in Typer. Run the script to test the subcommands:

```bash
python subcommands.py info
python subcommands.py db init
python subcommands.py db migrate 1.0
```

## Custom Types

Typer allows you to use custom types for your CLI arguments and options. Create a file named `custom_types.py` with the following content:

```python
import typer
from typing import List
from enum import Enum

app = typer.Typer()

class Color(str, Enum):
    red = "red"
    green = "green"
    blue = "blue"

def parse_point(value: str) -> tuple:
    try:
        x, y = map(int, value.split(','))
        return (x, y)
    except ValueError:
        raise typer.BadParameter("Point must be in format 'x,y'")

@app.command()
def process_colors(
    colors: List[Color] = typer.Option([], help="List of colors to process")
):
    """
    Process a list of colors
    """
    for color in colors:
        typer.echo(f"Processing color: {color.value}")

@app.command()
def move(
    point: tuple = typer.Option((0, 0), callback=parse_point, help="Point in 'x,y' format")
):
    """
    Move to a specific point
    """
    x, y = point
    typer.echo(f"Moving to point ({x}, {y})")

if __name__ == "__main__":
    app()
```

This script shows how to use custom types and type conversions in Typer. Run the script to test the custom types:

```bash
python custom_types.py process-colors --colors red blue green
python custom_types.py move --point 10,20
```

## Cross-Platform Considerations

When developing CLI applications with Typer, keep these cross-platform considerations in mind:

1. File paths: Use `pathlib.Path` for handling file paths, as it automatically uses the correct path separator for the current operating system.

2. Console output: Typer uses Click's `echo` function, which handles console encoding issues across platforms. Prefer `typer.echo()` over `print()`.

3. Colors and formatting: When using Rich for output, be aware that some Windows terminals may have limited color support. Test your application on different platforms to ensure compatibility.

4. Environment variables: Use `typer.Option(..., envvar="VARIABLE_NAME")` to allow setting options via environment variables, which works consistently across platforms.

5. Executable names: If your application has different entry point names on different platforms (e.g., `myapp` on Unix, `myapp.exe` on Windows), you can use `typer.Option(..., "-n", "--name", default=None)` and fall back to `sys.argv[0]` if not provided.

6. Line endings: When reading or writing files, open them in text mode with universal newlines: `open(file, 'r', newline=None)` for reading, and `open(file, 'w', newline='')` for writing.

## Conclusion

In this lesson, we've explored Typer and its capabilities for building beautiful and intuitive CLI applications. We've covered basic usage, command groups, options and arguments, file handling, Rich integration, subcommands, and custom types.

Typer simplifies many aspects of CLI development while providing powerful features and excellent integration with Python's type hinting system. As you develop your CLI applications, consider using Typer to create user-friendly and robust command-line tools.

In the next lesson, we'll explore Python Fire, another interesting library for automatically generating command-line interfaces from Python objects.
