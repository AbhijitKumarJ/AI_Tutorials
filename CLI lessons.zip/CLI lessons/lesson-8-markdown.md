# Lesson 8: Advanced Prompt Toolkit Features

Welcome to the eighth lesson in our "Mastering Python CLI Libraries: From Novice to Expert" series! In this lesson, we'll dive deeper into Prompt Toolkit, exploring advanced features that will allow you to create more sophisticated and user-friendly command-line interfaces.

## Table of Contents
1. [Introduction](#introduction)
2. [Project Setup](#project-setup)
3. [Custom Key Bindings](#custom-key-bindings)
4. [Interactive Menus](#interactive-menus)
5. [Full-Screen Applications](#full-screen-applications)
6. [Asynchronous Programming](#asynchronous-programming)
7. [Styling and Theming](#styling-and-theming)
8. [Cross-Platform Considerations](#cross-platform-considerations)
9. [Conclusion](#conclusion)

## Introduction

In our previous lesson, we introduced Prompt Toolkit and covered the basics of creating interactive prompts. Now, we'll explore more advanced features that will allow you to create highly customized and powerful command-line interfaces.

## Project Setup

Let's start by setting up our project. We'll create a new directory for this lesson and install the required packages.

```
advanced_prompt_toolkit/
├── requirements.txt
├── custom_bindings.py
├── interactive_menu.py
├── full_screen_app.py
├── async_prompt.py
└── styled_prompt.py
```

First, create a new directory called `advanced_prompt_toolkit` and navigate into it:

```bash
mkdir advanced_prompt_toolkit
cd advanced_prompt_toolkit
```

Now, create a `requirements.txt` file with the following content:

```
prompt_toolkit==3.0.38
```

Install the required packages:

```bash
pip install -r requirements.txt
```

## Custom Key Bindings

Custom key bindings allow you to create shortcuts and special behaviors in your CLI application. Let's create a simple example that demonstrates how to add custom key bindings.

Create a file named `custom_bindings.py` with the following content:

```python
from prompt_toolkit import PromptSession
from prompt_toolkit.keys import Keys
from prompt_toolkit.key_binding import KeyBindings

def main():
    kb = KeyBindings()

    @kb.add('c-t')
    def _(event):
        " Press 'ctrl-t' to insert the current time. "
        event.app.current_buffer.insert_text(' - ' + time.strftime('%H:%M:%S'))

    @kb.add(Keys.F4)
    def _(event):
        " Press F4 to exit. "
        event.app.exit()

    session = PromptSession(key_bindings=kb)

    while True:
        try:
            text = session.prompt('> ')
            print(f'You entered: {text}')
        except EOFError:
            break

if __name__ == '__main__':
    main()
```

In this example, we've added two custom key bindings:
1. Pressing Ctrl+T inserts the current time into the prompt.
2. Pressing F4 exits the application.

Run the script to test the custom key bindings:

```bash
python custom_bindings.py
```

## Interactive Menus

Interactive menus provide a user-friendly way to present options in your CLI. Let's create a simple menu system using Prompt Toolkit.

Create a file named `interactive_menu.py` with the following content:

```python
from prompt_toolkit import prompt
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.validation import Validator, ValidationError

class MenuValidator(Validator):
    def validate(self, document):
        text = document.text.lower()
        if text not in ('1', '2', '3', 'quit'):
            raise ValidationError(message='Please enter a valid option')

def main():
    menu_completer = WordCompleter(['1', '2', '3', 'quit'], ignore_case=True)
    
    while True:
        print("\nMain Menu:")
        print("1. Option One")
        print("2. Option Two")
        print("3. Option Three")
        print("Type 'quit' to exit")
        
        choice = prompt(
            '> ',
            completer=menu_completer,
            validator=MenuValidator(),
            validate_while_typing=False
        )
        
        if choice.lower() == 'quit':
            break
        elif choice == '1':
            print("You selected Option One")
        elif choice == '2':
            print("You selected Option Two")
        elif choice == '3':
            print("You selected Option Three")

if __name__ == '__main__':
    main()
```

This script creates an interactive menu with auto-completion and input validation. Run the script to test the menu:

```bash
python interactive_menu.py
```

## Full-Screen Applications

Prompt Toolkit allows you to create full-screen applications with complex layouts. Let's create a simple full-screen application that displays a clock and a text area.

Create a file named `full_screen_app.py` with the following content:

```python
from prompt_toolkit import Application
from prompt_toolkit.layout import Layout, HSplit, Window
from prompt_toolkit.widgets import TextArea
from prompt_toolkit.key_binding import KeyBindings
import time

def get_time():
    return time.strftime("%H:%M:%S")

def main():
    # Create the layout
    clock_window = Window(content=lambda: get_time())
    text_area = TextArea(text="Type here...")
    root_container = HSplit([clock_window, text_area])
    layout = Layout(root_container)

    # Create key bindings
    kb = KeyBindings()

    @kb.add('c-c')
    def _(event):
        " Press 'ctrl-c' to exit. "
        event.app.exit()

    # Create and run the application
    application = Application(
        layout=layout,
        key_bindings=kb,
        full_screen=True
    )
    application.run()

if __name__ == '__main__':
    main()
```

This script creates a full-screen application with a clock at the top and a text area below. Run the script to test the full-screen application:

```bash
python full_screen_app.py
```

## Asynchronous Programming

Prompt Toolkit supports asynchronous programming, which can be useful for handling long-running tasks or creating responsive interfaces. Let's create a simple asynchronous prompt that updates a counter while waiting for user input.

Create a file named `async_prompt.py` with the following content:

```python
import asyncio
from prompt_toolkit import PromptSession
from prompt_toolkit.patch_stdout import patch_stdout

async def counter():
    i = 0
    while True:
        print(f"Counter: {i}")
        i += 1
        await asyncio.sleep(1)

async def main():
    session = PromptSession()
    
    with patch_stdout():
        background_task = asyncio.create_task(counter())
        
        while True:
            try:
                result = await session.prompt_async("Enter something (or 'quit' to exit): ")
                if result.lower() == 'quit':
                    break
                print(f"You entered: {result}")
            except EOFError:
                break
    
    background_task.cancel()
    await background_task

if __name__ == '__main__':
    asyncio.run(main())
```

This script demonstrates how to create an asynchronous prompt that runs a background task (updating a counter) while waiting for user input. Run the script to test the asynchronous prompt:

```bash
python async_prompt.py
```

## Styling and Theming

Prompt Toolkit allows you to customize the appearance of your CLI application using styles and themes. Let's create a styled prompt with custom colors and formatting.

Create a file named `styled_prompt.py` with the following content:

```python
from prompt_toolkit import PromptSession
from prompt_toolkit.styles import Style

def main():
    style = Style.from_dict({
        'username': '#ansigreen bold',
        'at': '#ansiblue',
        'host': '#ansired bold',
        'path': '#ansiyellow',
        'prompt': '#ansimagenta',
    })

    session = PromptSession(
        message=[
            ('class:username', 'user'),
            ('class:at', '@'),
            ('class:host', 'localhost'),
            ('class:path', ' ~/projects'),
            ('class:prompt', ' $ '),
        ],
        style=style,
    )

    while True:
        try:
            text = session.prompt()
            print(f'You entered: {text}')
        except EOFError:
            break

if __name__ == '__main__':
    main()
```

This script creates a styled prompt that resembles a typical shell prompt with custom colors. Run the script to test the styled prompt:

```bash
python styled_prompt.py
```

## Cross-Platform Considerations

When developing CLI applications with Prompt Toolkit, it's important to consider cross-platform compatibility. Here are some tips for ensuring your application works well on Windows, macOS, and Linux:

1. Use `os.path` or `pathlib` for file system operations to ensure compatibility across different operating systems.

2. Be aware of terminal capabilities. Some features may not work in all terminals, especially on Windows. Use `prompt_toolkit.output.get_default_output()` to check terminal capabilities.

3. For full-screen applications, consider using `prompt_toolkit.application.Application(full_screen=True, mouse_support=True)` to enable mouse support on all platforms.

4. When using key bindings, be mindful of platform-specific keys. For example, some function keys may not be available on all platforms.

5. Use `prompt_toolkit.formatted_text.ANSI()` to handle ANSI escape sequences for colored output, which works across different platforms.

6. Test your application on multiple platforms to ensure consistent behavior.

## Conclusion

In this lesson, we've explored advanced features of Prompt Toolkit, including custom key bindings, interactive menus, full-screen applications, asynchronous programming, and styling. These features allow you to create sophisticated and user-friendly command-line interfaces.

As you continue to develop CLI applications, remember to consider cross-platform compatibility and test your applications on different operating systems.

In the next lesson, we'll explore syntax highlighting with Pygments and how to integrate it with Prompt Toolkit for even more powerful CLI applications.
