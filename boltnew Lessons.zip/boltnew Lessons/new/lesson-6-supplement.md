# Lesson 6 Supplement: Understanding Core Concepts and Advanced Topics

## Core Concepts Deep Dive

### 1. CSS Modules Fundamentals

#### 1.1 What Are CSS Modules?
CSS Modules is a CSS file in which all class names and animation names are scoped locally by default. In Bolt.new, we see this in files like `BaseChat.module.scss`:

```typescript
// How CSS Modules work under the hood
// Original file: BaseChat.module.scss
.BaseChat { ... }

// Gets transformed to something like:
.BaseChat_uniqueHash123 { ... }
```

#### 1.2 CSS Modules Integration with TypeScript
Bolt.new uses TypeScript declarations for CSS Modules:

```typescript
// CSS Module type declaration
declare module '*.module.scss' {
  const classes: { [key: string]: string };
  export default classes;
}

// Usage in components
import styles from './BaseChat.module.scss';
<div className={styles.BaseChat}>...</div>
```

### 2. SCSS (Sass) Fundamentals

#### 2.1 SCSS Nesting
Understanding how SCSS nesting works in Bolt.new:

```scss
// Example from variables.scss
.component {
  &__header {
    // Compiles to .component__header
    color: var(--bolt-elements-textPrimary);
    
    &--active {
      // Compiles to .component__header--active
      font-weight: bold;
    }
  }
  
  @media (min-width: 768px) {
    // Proper media query nesting
    &__header {
      font-size: 1.2rem;
    }
  }
}
```

#### 2.2 SCSS Variables vs CSS Custom Properties
Bolt.new uses both SCSS variables and CSS custom properties:

```scss
// SCSS Variables - Compile-time
$font-mono: ui-monospace, 'Fira Code', Menlo;
$code-font-size: 13px;

// CSS Custom Properties - Runtime
:root {
  --header-height: 54px;
  --chat-max-width: 37rem;
}

// When to use each:
// SCSS Variables: For values that won't change at runtime
// CSS Custom Properties: For themeable values and runtime changes
```

### 3. CSS Grid and Flexbox Deep Dive

#### 3.1 Flexbox in Bolt.new
Understanding the flexbox layouts used throughout the application:

```scss
// Common flexbox patterns in Bolt.new
.flex-container {
  display: flex;
  justify-content: space-between; // Horizontal spacing
  align-items: center; // Vertical alignment
  gap: 1rem; // Modern spacing between items
  
  // Flex grow/shrink patterns
  &__item {
    flex: 1 1 auto; // grow shrink basis
  }
  
  &__fixed {
    flex: 0 0 auto; // Don't grow or shrink
  }
}
```

#### 3.2 CSS Grid Implementation
Grid layouts in Bolt.new's workspace:

```scss
.workspace-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  grid-gap: 1rem;
  
  // Advanced grid areas
  grid-template-areas: 
    "header header"
    "sidebar main"
    "footer footer";
    
  @media (max-width: 768px) {
    grid-template-areas: 
      "header"
      "main"
      "sidebar"
      "footer";
  }
}
```

### 4. Advanced Animation Concepts

#### 4.1 Framer Motion Integration
Detailed look at how Framer Motion is used:

```typescript
// Advanced animation example from Workbench.client.tsx
const workbenchVariants = {
  closed: {
    width: 0,
    transition: {
      duration: 0.2,
      ease: cubicEasingFn,
    },
  },
  open: {
    width: 'var(--workbench-width)',
    transition: {
      duration: 0.2,
      ease: cubicEasingFn,
    },
  },
};

// Usage with TypeScript
interface AnimationProps {
  isOpen: boolean;
}

const AnimatedComponent = ({ isOpen }: AnimationProps) => (
  <motion.div
    initial="closed"
    animate={isOpen ? "open" : "closed"}
    variants={workbenchVariants}
  />
);
```

#### 4.2 CSS Transitions and Animations
Complex animation patterns:

```scss
// Transition mixing
@mixin transition-theme {
  transition: 
    background-color 150ms cubic-bezier(0.4, 0, 0.2, 1),
    border-color 150ms cubic-bezier(0.4, 0, 0.2, 1),
    color 150ms cubic-bezier(0.4, 0, 0.2, 1);
}

// Advanced keyframe animations
@keyframes slideInWithFade {
  0% {
    opacity: 0;
    transform: translateX(-20px);
  }
  
  50% {
    opacity: 0.5;
    transform: translateX(-10px);
  }
  
  100% {
    opacity: 1;
    transform: translateX(0);
  }
}
```

### 5. Advanced Accessibility Patterns

#### 5.1 Focus Management
Detailed focus management implementation:

```typescript
// Focus trap implementation
interface FocusTrapProps {
  active: boolean;
  children: React.ReactNode;
}

const FocusTrap = ({ active, children }: FocusTrapProps) => {
  const startRef = useRef<HTMLDivElement>(null);
  const endRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (active) {
      const handleTabKey = (e: KeyboardEvent) => {
        if (e.key === 'Tab') {
          // Focus management logic
        }
      };
      
      document.addEventListener('keydown', handleTabKey);
      return () => document.removeEventListener('keydown', handleTabKey);
    }
  }, [active]);
  
  return (
    <>
      <div tabIndex={0} ref={startRef} />
      {children}
      <div tabIndex={0} ref={endRef} />
    </>
  );
};
```

#### 5.2 Advanced ARIA Patterns
Complex ARIA implementations:

```typescript
// Composite widget pattern
const CompositeWidget = () => {
  const [activeId, setActiveId] = useState<string>();
  
  return (
    <div 
      role="toolbar"
      aria-label="Formatting options"
      aria-activedescendant={activeId}
    >
      <button
        id="bold"
        role="button"
        aria-pressed={isBold}
        aria-label="Bold"
        onClick={() => toggleBold()}
      />
      {/* More toolbar items */}
    </div>
  );
};
```

### 6. Performance Optimization Techniques

#### 6.1 CSS Containment
Using CSS containment for performance:

```scss
.contained-component {
  contain: content;
  contain: size layout paint;
}
```

#### 6.2 Will-change Usage
Proper implementation of will-change:

```scss
.animated-element {
  // Only add will-change when animation is about to start
  &--preparing {
    will-change: transform, opacity;
  }
  
  // Remove will-change after animation
  &--completed {
    will-change: auto;
  }
}
```

### 7. Advanced Theme Implementation

#### 7.1 Theme Switching Without Flicker
Implementation of flicker-free theme switching:

```typescript
// Theme switching with CSS Variables
const ThemeManager = () => {
  const [theme, setTheme] = useState<Theme>('light');
  
  useEffect(() => {
    // Prevent FOUC (Flash of Unstyled Content)
    document.documentElement.style.setProperty(
      'color-scheme',
      theme
    );
    
    const variables = getThemeVariables(theme);
    Object.entries(variables).forEach(([key, value]) => {
      document.documentElement.style.setProperty(key, value);
    });
  }, [theme]);
};
```

#### 7.2 Dynamic Theme Generation
Creating dynamic themes based on user preferences:

```typescript
// Dynamic theme generation
interface ThemeColors {
  primary: string;
  secondary: string;
  accent: string;
}

function generateTheme(baseColors: ThemeColors): Theme {
  return {
    light: generateLightVariant(baseColors),
    dark: generateDarkVariant(baseColors),
  };
}

// Usage
const userTheme = generateTheme({
  primary: '#1389FD',
  secondary: '#171717',
  accent: '#22C55E',
});
```

## Additional Resources and Best Practices

1. Browser Rendering Optimization
   - Understanding the critical rendering path
   - Paint and layout optimization
   - Composition and layers

2. Advanced CSS Techniques
   - Custom property fallbacks
   - Container queries
   - Logical properties

3. Modern CSS Features Used in Bolt.new
   - CSS Grid subgrid
   - :is() and :where() selectors
   - Container queries
   - Cascade layers

4. Debugging Tools and Techniques
   - Browser DevTools usage
   - Performance profiling
   - Layout debugging
   - Animation debugging

## Practical Exercises

1. Create a Theme System
   - Implement a complete theme switching system
   - Handle system preference changes
   - Manage theme persistence

2. Build Complex Layouts
   - Implement a responsive grid system
   - Create a dynamic sidebar
   - Build a resizable panel system

3. Optimize Performance
   - Analyze and optimize CSS
   - Implement efficient animations
   - Optimize render performance

## Knowledge Check

1. Explain the difference between CSS Modules and regular CSS
2. Describe the browser rendering pipeline
3. How does CSS containment improve performance?
4. What are the best practices for animation performance?
5. How do you implement proper focus management?

## Next Steps

After mastering these concepts, you should be able to:
1. Implement complex UI patterns efficiently
2. Create performant animations
3. Build accessible components
4. Optimize rendering performance
5. Create maintainable styling systems

This completes the supplementary material for Lesson 6. In the next lesson, we'll explore backend integration and API design.