# Lesson 1: Foundation and Architecture Overview

## Learning Objectives
By the end of this lesson, you will:
- Understand the complete project structure and organization of Bolt.new
- Master the core technologies used in the project
- Know how to set up the development environment
- Comprehend key configuration files and their purposes
- Grasp cross-platform considerations

## 1. Project Structure and Organization

### 1.1 Root Directory Layout
The project follows a well-organized structure with clear separation of concerns:

```
/
├── .github/          # GitHub-specific configurations and workflows
├── .husky/          # Git hooks for code quality
├── app/             # Main application code
├── functions/       # Serverless functions
├── icons/           # SVG icons
├── public/          # Static assets
└── types/           # Global TypeScript type definitions
```

### 1.2 Detailed Directory Analysis

#### The App Directory (`/app`)
The app directory contains the core application code and follows this structure:

```
app/
├── components/      # React components organized by feature
│   ├── chat/       # Chat-related components
│   ├── editor/     # Code editor components
│   ├── header/     # Header components
│   ├── sidebar/    # Sidebar components
│   ├── ui/         # Shared UI components
│   └── workbench/  # Workbench components
├── lib/            # Core libraries and utilities
├── routes/         # Application routes
├── styles/         # Global styles and themes
├── types/          # Application-specific types
└── utils/          # Utility functions
```

Key points about each directory:

1. **Components Directory** (`/app/components`)
   - Organized by feature rather than type
   - Each component has its own directory containing:
     * Main component file
     * Associated styles
     * Tests
     * Type definitions
   - Components follow a hierarchy from generic to specific
   - UI components are separated for reusability

2. **Library Directory** (`/app/lib`)
   - Contains core business logic
   - Handles state management
   - Manages external integrations
   - Implements core functionalities like:
     * WebContainer integration
     * LLM integration
     * File system management
     * Terminal emulation

3. **Routes Directory** (`/app/routes`)
   - Implements Remix's file-based routing
   - Each route handles:
     * Data loading
     * Actions
     * Component rendering
     * Error boundaries

4. **Styles Directory** (`/app/styles`)
   - Global style definitions
   - Theme configurations
   - CSS variables
   - Animation definitions
   - Layout utilities

## 2. Core Technologies

### 2.1 Primary Framework: Remix
Remix is used as the primary framework providing:
- Server-side rendering
- File-based routing
- Data loading
- Form handling
- Error boundaries
- Development server

### 2.2 WebContainer Technology
WebContainer is a crucial technology that:
- Provides in-browser Node.js environment
- Enables file system operations
- Allows package management
- Supports terminal emulation
- Handles process management

Key limitations to understand:
- Cannot run native binaries
- Limited to browser capabilities
- No direct file system access
- Memory constraints
- Network limitations

### 2.3 State Management
The project uses nanostores for state management because:
- Lightweight and efficient
- Works well with SSR
- Supports atomic updates
- Easy integration with React
- Good TypeScript support

### 2.4 TypeScript Integration
TypeScript is used throughout the project with:
- Strict type checking enabled
- Custom type definitions
- Interface-first development
- Generic type utilities
- Type inference optimization

## 3. Configuration Files

### 3.1 Package.json
```json
{
  "name": "bolt",
  "private": true,
  "type": "module",
  "scripts": {
    "deploy": "npm run build && wrangler pages deploy",
    "build": "remix vite:build",
    "dev": "remix vite:dev",
    "test": "vitest --run"
  }
}
```

The package.json configuration:
- Defines project metadata
- Lists dependencies
- Configures scripts
- Sets up development tools
- Manages build process

### 3.2 TypeScript Configuration (tsconfig.json)
```json
{
  "compilerOptions": {
    "lib": ["DOM", "DOM.Iterable", "ESNext"],
    "types": ["@remix-run/cloudflare", "vite/client"],
    "isolatedModules": true,
    "esModuleInterop": true,
    "jsx": "react-jsx",
    "module": "ESNext"
  }
}
```

Key TypeScript configurations:
- Strict type checking
- Modern JavaScript features
- React JSX support
- Module resolution
- Path aliases
- Type declarations

### 3.3 Environment Configuration (.env)
```env
GROQ_API_KEY=
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
OPEN_ROUTER_API_KEY=
GOOGLE_GENERATIVE_AI_API_KEY=
OLLAMA_API_BASE_URL=
VITE_LOG_LEVEL=debug
```

Environment variables manage:
- API keys for different services
- Configuration options
- Development settings
- Debug levels
- Service endpoints

## 4. Development Environment Setup

### 4.1 Prerequisites
- Node.js (v20.15.1 or later)
- pnpm (v9.4.0 or later)
- Git
- Chrome Canary (for local development)

### 4.2 Installation Steps
1. Clone the repository:
   ```bash
   git clone https://github.com/your/repository.git
   cd bolt.new
   ```

2. Install dependencies:
   ```bash
   pnpm install
   ```

3. Configure environment:
   - Copy .env.example to .env.local
   - Add required API keys
   - Configure development settings

4. Start development server:
   ```bash
   pnpm run dev
   ```

### 4.3 Development Tools
Essential tools for development:
- VSCode with recommended extensions
- Chrome DevTools for debugging
- React Developer Tools
- Network inspection tools
- Performance profiling tools

## 5. Cross-Platform Considerations

### 5.1 Operating System Compatibility
The project must work across:
- Windows
- macOS
- Linux
- Web browsers

Key considerations:
- File path handling
- Line endings
- File system operations
- Terminal emulation
- Process management

### 5.2 Browser Compatibility
Supported browsers:
- Chrome/Chromium (primary)
- Firefox
- Safari
- Edge

Browser-specific considerations:
- WebContainer support
- JavaScript features
- CSS compatibility
- Memory management
- Performance optimization

## 6. Project Best Practices

### 6.1 Code Organization
- Feature-based structure
- Clear separation of concerns
- Consistent naming conventions
- Proper type definitions
- Documentation standards

### 6.2 Development Workflow
- Git branching strategy
- Code review process
- Testing requirements
- Documentation updates
- Version control

## Practice Exercises

1. Environment Setup:
   - Set up complete development environment
   - Configure all required tools
   - Test the installation

2. Project Structure:
   - Create a new component
   - Add necessary files
   - Follow project conventions

3. Configuration:
   - Modify TypeScript configuration
   - Add environment variables
   - Update build scripts

## Knowledge Check
1. Explain the project's directory structure
2. Describe the role of WebContainer
3. List key configuration files
4. Outline cross-platform considerations
5. Describe the development setup process

## Additional Resources
- Remix documentation
- WebContainer API reference
- TypeScript handbook
- React documentation
- Development tools guides

