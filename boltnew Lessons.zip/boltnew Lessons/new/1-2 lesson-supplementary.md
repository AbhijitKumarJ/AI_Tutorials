# Supplementary Lesson: Core Concepts and Fundamentals

## Learning Objectives
This lesson explains fundamental concepts that were assumed in Lessons 1 and 2. You'll learn:

**React Fundamentals**: Understanding of React concepts used throughout the project.
**TypeScript Basics**: Core TypeScript concepts essential for the codebase.
**Modern JavaScript Features**: ES6+ features heavily used in the project.
**Web Development Concepts**: Key web development patterns and practices.

## 1. React Core Concepts

### 1.1 React Components and JSX

JSX is a syntax extension for JavaScript that lets you write HTML-like code in JavaScript:

```typescript
// Basic JSX Example
const element = <h1>Hello, World!</h1>;

// JSX with Expressions
const name = "User";
const element = <h1>Hello, {name}</h1>;

// Multiline JSX
const element = (
  <div>
    <h1>Title</h1>
    <p>Content</p>
  </div>
);
```

Understanding JSX Rules:
1. All tags must be closed (self-closing or paired)
2. Fragment syntax when no wrapper is needed
3. className instead of class for CSS classes
4. JavaScript expressions in curly braces
5. Attributes use camelCase naming

### 1.2 React Hooks Explained

React Hooks are functions that let you use state and other React features in functional components:

**useState Hook**
```typescript
// Basic useState example
function Counter() {
  const [count, setCount] = useState(0);
  
  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>
        Increment
      </button>
    </div>
  );
}
```

useState provides:
- Current state value
- State setter function
- Initial state setting
- State updates scheduling

**useEffect Hook**
```typescript
// Side effects handling
function UserProfile({ userId }) {
  const [user, setUser] = useState(null);
  
  useEffect(() => {
    // Effect will run after render
    async function fetchUser() {
      const response = await fetch(`/api/users/${userId}`);
      const data = await response.json();
      setUser(data);
    }
    
    fetchUser();
    
    // Cleanup function
    return () => {
      // Cleanup code here
    };
  }, [userId]); // Dependency array
  
  return (
    <div>
      {user ? <UserInfo user={user} /> : <Loading />}
    </div>
  );
}
```

useEffect concepts:
- Effect timing and execution
- Cleanup function purpose
- Dependency array usage
- Common patterns and pitfalls

### 1.3 React Refs and ForwardRefs

Refs provide direct access to DOM elements or React components:

```typescript
// Basic ref usage
function TextInput() {
  const inputRef = useRef<HTMLInputElement>(null);
  
  useEffect(() => {
    // Direct DOM access
    inputRef.current?.focus();
  }, []);
  
  return <input ref={inputRef} type="text" />;
}

// ForwardRef example
const CustomInput = forwardRef<HTMLInputElement, InputProps>(
  (props, ref) => {
    return (
      <input
        ref={ref}
        {...props}
        className="custom-input"
      />
    );
  }
);
```

Ref concepts:
- When to use refs
- Ref vs state
- ForwardRef purpose
- Ref limitations

## 2. TypeScript Fundamentals

### 2.1 Type System Basics

TypeScript adds static typing to JavaScript:

```typescript
// Basic types
let name: string = "John";
let age: number = 30;
let isActive: boolean = true;
let numbers: number[] = [1, 2, 3];
let tuple: [string, number] = ["John", 30];

// Object types
interface User {
  name: string;
  age: number;
  email?: string; // Optional property
}

// Function types
function greet(user: User): string {
  return `Hello, ${user.name}`;
}
```

Type System Features:
- Type inference
- Type assertions
- Union types
- Intersection types
- Type guards

### 2.2 Generic Types

Generics provide type-safe reusable components:

```typescript
// Generic function
function identity<T>(value: T): T {
  return value;
}

// Generic interface
interface Container<T> {
  value: T;
  setValue: (newValue: T) => void;
}

// Generic component
function List<T>({ items, renderItem }: {
  items: T[];
  renderItem: (item: T) => React.ReactNode;
}) {
  return (
    <ul>
      {items.map((item, index) => (
        <li key={index}>{renderItem(item)}</li>
      ))}
    </ul>
  );
}
```

Generic Concepts:
- Type parameters
- Constraints
- Default types
- Generic interfaces
- Generic classes

### 2.3 Advanced Types

TypeScript provides powerful type manipulation:

```typescript
// Mapped types
type Readonly<T> = {
  readonly [P in keyof T]: T[P];
};

// Conditional types
type NonNullable<T> = T extends null | undefined ? never : T;

// Utility types
interface User {
  id: number;
  name: string;
  email: string;
}

type UserPartial = Partial<User>; // All properties optional
type UserReadonly = Readonly<User>; // All properties readonly
type UserPick = Pick<User, 'id' | 'name'>; // Only selected properties
```

Advanced Type Features:
- Mapped types
- Conditional types
- Template literal types
- Index types
- Utility types

## 3. Modern JavaScript Features

### 3.1 ES6+ Features

Modern JavaScript features used extensively:

```typescript
// Destructuring
const { name, age } = user;
const [first, ...rest] = array;

// Spread operator
const newArray = [...oldArray, newItem];
const newObject = { ...oldObject, newProp: value };

// Arrow functions
const add = (a: number, b: number): number => a + b;

// Template literals
const message = `Hello, ${name}!`;

// Optional chaining
const value = obj?.prop?.nested;

// Nullish coalescing
const result = value ?? defaultValue;
```

### 3.2 Async Programming

Modern asynchronous JavaScript patterns:

```typescript
// Promises
function fetchData(): Promise<Data> {
  return fetch('/api/data')
    .then(response => response.json())
    .catch(error => console.error(error));
}

// Async/Await
async function fetchUserData(): Promise<UserData> {
  try {
    const response = await fetch('/api/user');
    const data = await response.json();
    return data;
  } catch (error) {
    console.error(error);
    throw error;
  }
}

// Promise.all example
async function fetchMultiple(): Promise<[UserData, Settings]> {
  const [userData, settings] = await Promise.all([
    fetchUserData(),
    fetchSettings()
  ]);
  return [userData, settings];
}
```

## 4. Web Development Patterns

### 4.1 Module System

Understanding ES Modules:

```typescript
// Named exports
export const util = { ... };
export function helper() { ... }

// Default export
export default class MainComponent { ... }

// Import syntax
import MainComponent, { util, helper } from './module';
import * as moduleExports from './module';
```

### 4.2 Browser APIs

Modern browser APIs used in the project:

```typescript
// Intersection Observer
const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        // Element is visible
      }
    });
  },
  { threshold: 0.5 }
);

// Fetch API
const response = await fetch('/api/data', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(data)
});

// Web Storage
localStorage.setItem('key', value);
const value = localStorage.getItem('key');

// Web Workers
const worker = new Worker('worker.js');
worker.postMessage(data);
worker.onmessage = (event) => {
  // Handle message
};
```

## Practice Exercises

### Exercise 1: TypeScript Fundamentals
Implement a generic data structure:

```typescript
// TODO: Implement a type-safe queue
class Queue<T> {
  // Implementation should include:
  // - Type-safe enqueue and dequeue
  // - Length property
  // - isEmpty method
  // - Clear method
}
```

### Exercise 2: React Patterns
Implement a custom hook:

```typescript
// TODO: Implement a useLocalStorage hook
function useLocalStorage<T>(
  key: string,
  initialValue: T
): [T, (value: T) => void] {
  // Implementation should:
  // - Store and retrieve values from localStorage
  // - Handle JSON serialization
  // - Provide type safety
  // - Include error handling
}
```

## Knowledge Check Questions

1. Explain React's Component Lifecycle:
   - How do hooks replace lifecycle methods?
   - What is the execution order of effects?
   - How are cleanup functions used?
   - When should you use layout effects?

2. Describe TypeScript's Type System:
   - How does type inference work?
   - What are union and intersection types?
   - How do generics provide type safety?
   - What are utility types?

3. Explain Modern JavaScript Features:
   - How do promises work?
   - What is the event loop?
   - How does async/await work internally?
   - What are modules and how do they work?

## Additional Resources

1. React Documentation:
   - [React Hooks](https://reactjs.org/docs/hooks-intro.html)
   - [React TypeScript](https://react-typescript-cheatsheet.netlify.app/)

2. TypeScript Documentation:
   - [TypeScript Handbook](https://www.typescriptlang.org/docs/handbook/intro.html)
   - [TypeScript Deep Dive](https://basarat.gitbook.io/typescript/)

3. JavaScript Resources:
   - [MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
   - [JavaScript.info](https://javascript.info/)

This supplementary lesson provides the foundational knowledge needed to fully understand the concepts covered in Lessons 1 and 2. It's recommended to review these concepts thoroughly before proceeding with subsequent lessons.
