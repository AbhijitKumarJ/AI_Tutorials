# Lesson 4: File System and Editor Implementation

## Table of Contents
1. Introduction
2. WebContainer File System Architecture
3. File System Implementation
4. Editor Implementation
5. Code Organization and File Layout
6. Practical Exercises
7. Advanced Topics
8. Common Pitfalls and Solutions

## 1. Introduction

In this lesson, we dive deep into the file system and editor implementation in Bolt.new. The file system is a crucial component that allows for in-browser file operations through WebContainer technology, while the editor provides a sophisticated interface for code modification using CodeMirror.

## 2. WebContainer File System Architecture

### 2.1 Core Components

The file system in Bolt.new is built on WebContainer's virtual file system, which provides a Unix-like file system interface in the browser. The implementation is primarily handled through these key files:

```
app/
└── lib/
    ├── stores/
    │   ├── files.ts       # Main file system store
    │   └── editor.ts      # Editor state management
    └── webcontainer/
        └── index.ts       # WebContainer initialization
```

### 2.2 File System Store

The file system store (files.ts) manages the state of all files and folders. It provides key functionalities:

1. File Operations
   - Creation, reading, updating, and deletion of files
   - Directory operations
   - File watching and change detection
   - Binary vs text file handling

2. State Management
   - File tree representation
   - Modified files tracking
   - File content caching

## 3. File System Implementation

### 3.1 File Map Structure

Files are stored in a FileMap structure that represents the entire file system:

```typescript
export interface File {
  type: 'file';
  content: string;
  isBinary: boolean;
}

export interface Folder {
  type: 'folder';
}

type Dirent = File | Folder;
export type FileMap = Record<string, Dirent | undefined>;
```

### 3.2 File Operations

Key file operations are implemented in the FilesStore class:

1. File Reading:
```typescript
async getFile(filePath: string) {
  const dirent = this.files.get()[filePath];
  if (dirent?.type !== 'file') {
    return undefined;
  }
  return dirent;
}
```

2. File Writing:
```typescript
async saveFile(filePath: string, content: string) {
  const webcontainer = await this.#webcontainer;
  try {
    const relativePath = nodePath.relative(webcontainer.workdir, filePath);
    await webcontainer.fs.writeFile(relativePath, content);
    this.files.setKey(filePath, { 
      type: 'file', 
      content, 
      isBinary: false 
    });
  } catch (error) {
    logger.error('Failed to update file content\n\n', error);
    throw error;
  }
}
```

## 4. Editor Implementation

### 4.1 CodeMirror Integration

The editor is implemented using CodeMirror 6, providing features like:
- Syntax highlighting
- Auto-completion
- Multiple language support
- Theme support
- Search and replace

Key files for editor implementation:

```
app/
└── components/
    └── editor/
        └── codemirror/
            ├── CodeMirrorEditor.tsx    # Main editor component
            ├── languages.ts            # Language support
            ├── cm-theme.ts            # Theme configuration
            └── indent.ts              # Indentation handling
```

### 4.2 Editor State Management

The editor state is managed through the EditorStore class which handles:

1. Document Management:
```typescript
export interface EditorDocument {
  value: string;
  filePath: string;
  scroll?: ScrollPosition;
}

export class EditorStore {
  documents: MapStore<EditorDocuments>;
  selectedFile: SelectedFile;
  
  setDocuments(files: FileMap) {
    // Implementation of document state management
  }
}
```

2. Cursor and Selection:
```typescript
interface ScrollPosition {
  top: number;
  left: number;
}
```

## 5. Code Organization and File Layout

The complete file system and editor implementation spans across multiple directories:

```
app/
├── components/
│   └── editor/
│       └── codemirror/
│           ├── BinaryContent.tsx
│           ├── CodeMirrorEditor.tsx
│           ├── cm-theme.ts
│           ├── indent.ts
│           └── languages.ts
├── lib/
│   ├── stores/
│   │   ├── editor.ts
│   │   └── files.ts
│   └── webcontainer/
│       └── index.ts
└── utils/
    └── diff.ts
```

## 6. Practical Exercises

### Exercise 1: Implementing File Operations
Create a basic file system handler that can:
1. Create new files
2. Read file contents
3. Update existing files
4. Delete files
5. Handle binary vs text files

### Exercise 2: Building a Basic Editor
Implement a simplified version of the editor that includes:
1. Basic text editing
2. Syntax highlighting
3. File saving
4. Cursor position maintenance

## 7. Advanced Topics

### 7.1 Binary File Handling

Binary file detection and handling is implemented using the istextorbinary library:

```typescript
function isBinaryFile(buffer: Uint8Array | undefined) {
  if (buffer === undefined) {
    return false;
  }
  return getEncoding(convertToBuffer(buffer), { 
    chunkLength: 100 
  }) === 'binary';
}
```

### 7.2 File Watching and Synchronization

File watching is implemented using WebContainer's watchPaths API:

```typescript
webcontainer.internal.watchPaths(
  { 
    include: [`${WORK_DIR}/**`], 
    exclude: ['**/node_modules', '.git'], 
    includeContent: true 
  },
  bufferWatchEvents(100, this.#processEventBuffer.bind(this))
);
```

### 7.3 Memory Management

Strategies for handling large files and memory constraints:
1. Chunked file loading
2. Content streaming
3. Garbage collection optimization
4. Cache management

## 8. Common Pitfalls and Solutions

### 8.1 Path Handling
Problem: Inconsistent path separators across platforms
Solution: Use path normalization:

```typescript
const normalizedPath = nodePath.normalize(filePath);
```

### 8.2 File Encoding
Problem: Incorrect file encoding detection
Solution: Implement robust encoding detection:

```typescript
const utf8TextDecoder = new TextDecoder('utf8', { 
  fatal: true 
});

function decodeFileContent(buffer?: Uint8Array) {
  if (!buffer || buffer.byteLength === 0) {
    return '';
  }
  try {
    return utf8TextDecoder.decode(buffer);
  } catch (error) {
    console.log(error);
    return '';
  }
}
```

### 8.3 Performance
Problem: Slow file operations with large files
Solution: Implement chunked operations and caching:

```typescript
async function readLargeFile(filePath: string) {
  const CHUNK_SIZE = 1024 * 1024; // 1MB chunks
  let content = '';
  let offset = 0;
  
  while (true) {
    const chunk = await readFileChunk(filePath, offset, CHUNK_SIZE);
    if (!chunk) break;
    content += chunk;
    offset += CHUNK_SIZE;
  }
  
  return content;
}
```

## Conclusion

This lesson covered the intricate details of file system and editor implementation in Bolt.new. Understanding these components is crucial for:
1. Managing file operations in the browser
2. Providing a seamless editing experience
3. Handling different file types and encodings
4. Maintaining performance with large files
5. Implementing cross-platform compatibility

In the next lesson, we'll explore terminal and process management, building upon the file system knowledge gained here.
