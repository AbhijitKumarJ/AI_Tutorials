# Lesson 3 Supplementary: Core Concepts and Implementation Details

## 1. Foundational Streaming Concepts

### 1.1 Web Streams API
The chat system heavily relies on the Web Streams API. Here's a detailed explanation of key concepts:

#### ReadableStream
A ReadableStream represents a source of data that can be read chunk by chunk. In Bolt.new, it's used for handling streaming responses from LLMs.

```typescript
// Example of basic ReadableStream usage
const stream = new ReadableStream({
  start(controller) {
    // Called when stream starts
    controller.enqueue('First chunk');
    controller.enqueue('Second chunk');
    controller.close();
  },
  pull(controller) {
    // Called when consumer wants more data
  },
  cancel() {
    // Called if stream is canceled
  }
});
```

#### TransformStream
TransformStream is used to modify streaming data as it passes through. Bolt.new uses it for processing LLM responses:

```typescript
// Example TransformStream for processing LLM chunks
const transformStream = new TransformStream({
  transform(chunk, controller) {
    // Process the chunk (e.g., parse JSON, filter content)
    const processedChunk = processChunk(chunk);
    controller.enqueue(processedChunk);
  }
});
```

### 1.2 Streaming States
Understanding streaming states is crucial for proper stream management:

```typescript
interface StreamState {
  // Current position in the stream
  position: number;
  // Whether we're currently processing an artifact
  insideArtifact: boolean;
  // Whether we're inside an action block
  insideAction: boolean;
  // Current artifact being processed
  currentArtifact?: BoltArtifactData;
  // Current action being processed
  currentAction: BoltActionData;
  // Counter for action IDs
  actionId: number;
}
```

## 2. Message Processing Architecture

### 2.1 Token Management
LLM responses are processed token by token. Here's how token management works:

```typescript
interface TokenManager {
  // Maximum tokens allowed per response
  maxTokens: number;
  // Current token count
  currentTokens: number;
  // Token buffer for partial tokens
  tokenBuffer: string;
  
  // Process incoming tokens
  processTokens(chunk: string): ProcessedTokens;
  // Handle token overflow
  handleOverflow(): void;
  // Reset token state
  reset(): void;
}

class TokenProcessor implements TokenManager {
  constructor(private maxTokens: number) {
    this.currentTokens = 0;
    this.tokenBuffer = '';
  }

  processTokens(chunk: string): ProcessedTokens {
    // Join with buffer from previous chunk
    const text = this.tokenBuffer + chunk;
    
    // Split into complete tokens
    const tokens = text.split(/(\s+)/);
    
    // Save last partial token
    this.tokenBuffer = tokens.pop() || '';
    
    return {
      tokens: tokens,
      complete: this.tokenBuffer === ''
    };
  }
}
```

### 2.2 Message State Management
Messages go through several states during processing:

```typescript
enum MessageState {
  // Initial state when message is created
  PENDING = 'pending',
  // Message is being streamed
  STREAMING = 'streaming',
  // Message is complete
  COMPLETE = 'complete',
  // Message processing failed
  FAILED = 'failed'
}

interface MessageContext {
  // Unique message identifier
  id: string;
  // Current state
  state: MessageState;
  // Message content
  content: string;
  // Processing metadata
  metadata: MessageMetadata;
  // Error information if failed
  error?: Error;
}
```

## 3. LLM Provider Integration Details

### 3.1 Provider Interface
Each LLM provider must implement a common interface:

```typescript
interface LLMProvider {
  // Initialize provider with configuration
  initialize(config: ProviderConfig): Promise<void>;
  
  // Get completion without streaming
  complete(prompt: string, options: CompletionOptions): Promise<string>;
  
  // Get streaming completion
  streamComplete(prompt: string, options: CompletionOptions): ReadableStream;
  
  // Handle provider-specific errors
  handleError(error: unknown): Error;
  
  // Clean up resources
  dispose(): Promise<void>;
}

interface ProviderConfig {
  // API key for authentication
  apiKey: string;
  // Base URL for API requests
  baseUrl?: string;
  // Model configuration
  model: ModelConfig;
  // Request timeout
  timeout?: number;
  // Retry configuration
  retry?: RetryConfig;
}
```

### 3.2 Provider Rate Limiting
Sophisticated rate limiting is implemented for each provider:

```typescript
class ProviderRateLimiter {
  private requestCount: number = 0;
  private resetTime: number;
  private readonly maxRequests: number;
  private readonly timeWindow: number;

  constructor(maxRequests: number, timeWindowMs: number) {
    this.maxRequests = maxRequests;
    this.timeWindow = timeWindowMs;
    this.resetTime = Date.now() + timeWindowMs;
  }

  async acquireToken(): Promise<boolean> {
    const now = Date.now();
    
    if (now > this.resetTime) {
      this.requestCount = 0;
      this.resetTime = now + this.timeWindow;
    }

    if (this.requestCount >= this.maxRequests) {
      return false;
    }

    this.requestCount++;
    return true;
  }
}
```

## 4. Artifact System Architecture

### 4.1 Artifact Structure
Artifacts have a complex structure for managing code and actions:

```typescript
interface Artifact {
  // Unique identifier
  id: string;
  // Display title
  title: string;
  // List of actions to perform
  actions: Action[];
  // Artifact metadata
  metadata: ArtifactMetadata;
  // Current state
  state: ArtifactState;
  // Parent message ID
  messageId: string;
}

interface Action {
  // Action type (file/shell)
  type: ActionType;
  // Action content
  content: string;
  // Action state
  state: ActionState;
  // Error if failed
  error?: Error;
}

interface ArtifactMetadata {
  // Creation timestamp
  created: number;
  // Last modified timestamp
  modified: number;
  // Creator information
  creator: string;
  // Version information
  version: string;
}
```

### 4.2 Artifact Processing Pipeline
The artifact processing pipeline handles creation and execution:

```typescript
class ArtifactProcessor {
  // Process new artifact
  async processArtifact(artifact: Artifact): Promise<void> {
    // Validate artifact structure
    this.validateArtifact(artifact);
    
    // Process each action sequentially
    for (const action of artifact.actions) {
      try {
        await this.processAction(action);
        action.state = ActionState.COMPLETE;
      } catch (error) {
        action.state = ActionState.FAILED;
        action.error = error as Error;
        break;
      }
    }
  }

  // Validate artifact structure
  private validateArtifact(artifact: Artifact): void {
    if (!artifact.id || !artifact.title) {
      throw new Error('Invalid artifact structure');
    }
    
    if (!Array.isArray(artifact.actions)) {
      throw new Error('Invalid actions structure');
    }
  }

  // Process individual action
  private async processAction(action: Action): Promise<void> {
    switch (action.type) {
      case 'file':
        await this.processFileAction(action);
        break;
      case 'shell':
        await this.processShellAction(action);
        break;
      default:
        throw new Error(`Unknown action type: ${action.type}`);
    }
  }
}
```

## 5. Cross-Cutting Concerns

### 5.1 Error Recovery Strategies
Comprehensive error recovery is implemented:

```typescript
class ErrorRecovery {
  // Attempt to recover from stream error
  async recoverStream(error: Error): Promise<ReadableStream | null> {
    // Try different recovery strategies
    const strategies = [
      this.retryStrategy,
      this.fallbackProviderStrategy,
      this.degradedModeStrategy
    ];
    
    for (const strategy of strategies) {
      try {
        const result = await strategy();
        if (result) return result;
      } catch {
        continue;
      }
    }
    
    return null;
  }

  // Recovery strategy implementations
  private async retryStrategy(): Promise<ReadableStream | null> {
    // Implement retry logic
  }
  
  private async fallbackProviderStrategy(): Promise<ReadableStream | null> {
    // Switch to fallback provider
  }
  
  private async degradedModeStrategy(): Promise<ReadableStream | null> {
    // Run in degraded mode
  }
}
```

### 5.2 Performance Optimization
Various performance optimizations are implemented:

```typescript
interface PerformanceOptimizer {
  // Chunk size optimization
  optimizeChunkSize(currentSize: number): number;
  
  // Stream buffer optimization
  optimizeBuffer(usage: BufferUsage): void;
  
  // Memory usage optimization
  optimizeMemory(stats: MemoryStats): void;
}

class StreamOptimizer implements PerformanceOptimizer {
  // Adapt chunk size based on performance metrics
  optimizeChunkSize(currentSize: number): number {
    const metrics = this.getPerformanceMetrics();
    return this.calculateOptimalChunkSize(currentSize, metrics);
  }
  
  // Optimize buffer based on usage patterns
  optimizeBuffer(usage: BufferUsage): void {
    if (usage.fillRate > usage.drainRate) {
      this.increaseBufferSize();
    } else {
      this.decreaseBufferSize();
    }
  }
}
```

## 6. Testing Strategies

### 6.1 Unit Testing Streams
Proper stream testing requires specific approaches:

```typescript
// Example stream test helper
class StreamTestHelper {
  // Create test stream with predefined content
  static createTestStream(content: string[]): ReadableStream {
    return new ReadableStream({
      start(controller) {
        content.forEach(chunk => controller.enqueue(chunk));
        controller.close();
      }
    });
  }
  
  // Collect stream content for testing
  static async collectStream(stream: ReadableStream): Promise<string[]> {
    const reader = stream.getReader();
    const chunks: string[] = [];
    
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
    }
    
    return chunks;
  }
}
```

### 6.2 Integration Testing
Testing provider integration requires careful consideration:

```typescript
class ProviderIntegrationTest {
  // Test provider initialization
  async testInitialization(): Promise<void> {
    const provider = new TestProvider();
    await provider.initialize({
      apiKey: 'test-key',
      model: 'test-model'
    });
    
    // Verify provider state
    assert(provider.isInitialized());
  }
  
  // Test streaming completion
  async testStreaming(): Promise<void> {
    const provider = new TestProvider();
    const stream = await provider.streamComplete('test prompt');
    
    // Verify stream content
    const content = await StreamTestHelper.collectStream(stream);
    assert(content.length > 0);
  }
}
```

## Practice Exercises

1. Implement a custom TransformStream for processing LLM responses
2. Create a rate limiter for a new provider
3. Build an artifact validator
4. Implement stream error recovery
5. Write tests for stream processing

## Knowledge Check Questions

1. Explain the relationship between ReadableStream and TransformStream
2. Describe token management strategies for different providers
3. Detail the artifact processing pipeline
4. Explain error recovery mechanisms
5. Describe performance optimization techniques

Remember: These concepts build upon each other and form the foundation for understanding Bolt.new's LLM integration system.
