# Lesson 6: UI/UX Components and Styling in Bolt.new

## Lesson Overview
In this comprehensive lesson, we'll dive deep into the UI/UX components and styling architecture of Bolt.new. We'll explore how the application achieves its modern, responsive design while maintaining consistency and performance across different platforms.

## Prerequisites
- Basic understanding of React and TypeScript
- Familiarity with CSS and SCSS
- Understanding of modern CSS features
- Basic knowledge of CSS Modules
- Understanding of theming concepts

## 1. Styling Architecture Overview

### 1.1 Directory Structure
The styling architecture in Bolt.new follows a well-organized structure:

```
app/
├── styles/
│   ├── animations.scss       # Global animations
│   ├── index.scss           # Main stylesheet
│   ├── variables.scss       # CSS variables and theming
│   ├── z-index.scss         # Z-index management
│   └── components/          # Component-specific styles
│       ├── code.scss        
│       ├── editor.scss
│       ├── resize-handle.scss
│       ├── terminal.scss
│       └── toast.scss
```

### 1.2 CSS Modules Implementation
Bolt.new uses CSS Modules for component-specific styling. Let's look at how this is implemented:

```typescript
// Example: BaseChat.module.scss
.BaseChat {
  &[data-chat-visible='false'] {
    --workbench-inner-width: 100%;
    --workbench-left: 0;

    .Chat {
      --at-apply: bolt-ease-cubic-bezier;
      transition-property: transform, opacity;
      transition-duration: 0.3s;
      will-change: transform, opacity;
      transform: translateX(-50%);
      opacity: 0;
    }
  }
}
```

The CSS Modules approach provides several benefits:
1. Local scope for styles, preventing conflicts
2. Clear relationship between components and their styles
3. Better maintainability and refactoring capabilities
4. Type safety when using styles in TypeScript

## 2. Theming System

### 2.1 Theme Store Implementation
The theme system uses a centralized store (themeStore.ts) to manage application-wide theming:

```typescript
// app/lib/stores/theme.ts
export type Theme = 'dark' | 'light';
export const themeStore = atom<Theme>(initStore());

export function toggleTheme() {
  const currentTheme = themeStore.get();
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  themeStore.set(newTheme);
  localStorage.setItem(kTheme, newTheme);
  document.querySelector('html')?.setAttribute('data-theme', newTheme);
}
```

### 2.2 CSS Variables for Theming
The application uses CSS variables extensively for theming. These are defined in variables.scss:

```scss
:root[data-theme='light'] {
  --bolt-elements-borderColor: theme('colors.alpha.gray.10');
  --bolt-elements-borderColorActive: theme('colors.accent.600');
  --bolt-elements-bg-depth-1: theme('colors.white');
  // ... more variables
}

:root[data-theme='dark'] {
  --bolt-elements-borderColor: theme('colors.alpha.white.10');
  --bolt-elements-borderColorActive: theme('colors.accent.500');
  --bolt-elements-bg-depth-1: theme('colors.gray.950');
  // ... more variables
}
```

## 3. Component Architecture

### 3.1 Base Components
Let's examine the structure of base components that form the foundation of the UI:

```typescript
// Example: IconButton.tsx
interface IconButtonProps {
  size?: IconSize;
  className?: string;
  iconClassName?: string;
  disabled?: boolean;
  onClick?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
}

export const IconButton = memo(({
  size = 'xl',
  className,
  iconClassName,
  disabled = false,
  onClick,
  children,
}: IconButtonProps) => {
  // Implementation
});
```

### 3.2 Layout Components
The application uses a sophisticated layout system with components like:
- PanelHeader
- Dialog
- BaseChat
- Workbench

Each layout component is designed to be:
1. Responsive to different screen sizes
2. Accessible
3. Performant
4. Theme-aware

## 4. Animation System

### 4.1 Animation Implementation
Animations are implemented using a combination of:
- CSS transitions
- Framer Motion for complex animations
- CSS keyframes for simple animations

Example from animations.scss:
```scss
.animated {
  animation-fill-mode: both;
  animation-duration: var(--animate-duration, 0.2s);
  animation-timing-function: cubic-bezier(0, 0, 0.2, 1);

  &.fadeInRight {
    animation-name: fadeInRight;
  }
}

@keyframes fadeInRight {
  from {
    opacity: 0;
    transform: translate3d(100%, 0, 0);
  }
  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
}
```

## 5. Responsive Design

### 5.1 Mobile-First Approach
The application uses a mobile-first approach with responsive breakpoints:

```scss
// Base mobile styles
.component {
  width: 100%;
  padding: 1rem;
}

// Tablet and up
@media (min-width: 768px) {
  .component {
    width: 50%;
    padding: 2rem;
  }
}

// Desktop
@media (min-width: 1024px) {
  .component {
    width: 33.333%;
    padding: 3rem;
  }
}
```

### 5.2 Responsive Layout Implementation
The layout system uses CSS Grid and Flexbox for responsive behavior:

```typescript
// Example: Workbench.client.tsx
<div className={classNames(
  'relative flex flex-col h-full w-full overflow-hidden',
  {
    'bg-bolt-elements-background-depth-1': !chat.started,
    'border-bolt-elements-borderColor': chat.started,
  }
)}>
```

## 6. Accessibility Implementation

### 6.1 Keyboard Navigation
The application implements robust keyboard navigation:
- Focus management
- Skip links
- ARIA attributes
- Keyboard shortcuts

### 6.2 ARIA Implementation
Example of ARIA implementation:

```typescript
// Dialog.tsx
<DialogContent
  className={classNames(
    'fixed top-[50%] left-[50%] z-max max-h-[85vh]',
    'w-[90vw] max-w-[450px] translate-x-[-50%] translate-y-[-50%]'
  )}
  role="dialog"
  aria-modal="true"
  aria-labelledby="dialog-title"
>
```

## 7. Performance Optimization

### 7.1 Code Splitting
The application uses code splitting for better performance:
- Dynamic imports for large components
- Lazy loading of routes
- Component memoization

### 7.2 CSS Optimization
CSS optimization techniques include:
- Critical CSS extraction
- CSS Modules code splitting
- Minimal CSS-in-JS usage
- Efficient use of CSS variables

## Practical Exercises

1. Theme Implementation Exercise:
   - Create a new theme variant
   - Implement theme switching
   - Add new theme variables

2. Component Creation Exercise:
   - Build a new UI component
   - Implement responsive design
   - Add animations
   - Ensure accessibility

3. Performance Optimization Exercise:
   - Analyze component rendering
   - Implement performance improvements
   - Measure impact of changes

## Knowledge Check

1. Explain how the theming system works in Bolt.new
2. Describe the CSS Modules implementation
3. How are animations handled in the application?
4. What accessibility features are implemented?
5. How is responsive design achieved?

## Additional Resources

1. CSS Modules Documentation
2. Framer Motion API Reference
3. ARIA Best Practices
4. CSS Custom Properties Guide
5. React Performance Optimization Guide

## Next Steps

After completing this lesson, you should:
1. Understand the styling architecture of Bolt.new
2. Be able to implement new components
3. Know how to work with the theming system
4. Understand accessibility requirements
5. Be able to optimize component performance

In the next lesson, we'll explore backend integration and API design.
