# Supplementary Lesson: Core Concepts and Prerequisites

## Overview
This supplementary lesson covers fundamental concepts that were assumed in Lessons 9 and 10. We'll explore these concepts in detail and provide concrete examples of their implementation in the Bolt.new codebase.

## 1. Core TypeScript Concepts

### 1.1 Generics
Generics are extensively used in the codebase for type-safe components and functions:

```typescript
// Example from app/utils/react.ts
export const genericMemo: <T extends keyof JSX.IntrinsicElements | React.JSXElementConstructor<any>>(
  component: T,
  propsAreEqual?: (prevProps: React.ComponentProps<T>, nextProps: React.ComponentProps<T>) => boolean,
) => T & { displayName?: string } = memo;

// Usage in stores
type MapStore<T> = Store<Record<string, T>>;
type WritableAtom<T> = Store<T>;
```

### 1.2 Type Assertions and Guards
Understanding type assertions and guards is crucial for the codebase:

```typescript
// Type Guards Example
function isFileAction(action: BoltAction): action is FileAction {
  return action.type === 'file';
}

// Type Assertions Example
const filesystem = (webcontainer.fs as unknown) as FileSystemAPI;
```

## 2. WebContainer API Concepts

### 2.1 WebContainer Basics
WebContainer provides a browser-based development environment:

```typescript
// Located in app/lib/webcontainer/index.ts
export let webcontainer: Promise<WebContainer> = new Promise(() => {
  // noop for ssr
});

if (!import.meta.env.SSR) {
  webcontainer = Promise.resolve()
    .then(() => {
      return WebContainer.boot({
        workdirName: WORK_DIR_NAME
      });
    })
    .then((webcontainer) => {
      webcontainerContext.loaded = true;
      return webcontainer;
    });
}
```

### 2.2 File System Operations
Understanding WebContainer's file system API:

```typescript
// Example of file system operations
export class FilesStore {
  async writeFile(path: string, content: string) {
    const webcontainer = await this.#webcontainer;
    
    try {
      // Create directory if needed
      const dir = nodePath.dirname(path);
      await webcontainer.fs.mkdir(dir, { recursive: true });
      
      // Write file
      await webcontainer.fs.writeFile(path, content);
      
    } catch (error) {
      console.error('Failed to write file:', error);
      throw error;
    }
  }

  async readFile(path: string): Promise<string> {
    const webcontainer = await this.#webcontainer;
    
    try {
      const data = await webcontainer.fs.readFile(path);
      return new TextDecoder().decode(data);
    } catch (error) {
      console.error('Failed to read file:', error);
      throw error;
    }
  }
}
```

## 3. React Concepts

### 3.1 React.memo and Performance
Understanding memoization in React components:

```typescript
// Example from app/components/chat/AssistantMessage.tsx
export const AssistantMessage = memo(({ content }: AssistantMessageProps) => {
  return (
    <div className="overflow-hidden w-full">
      <Markdown html>{content}</Markdown>
    </div>
  );
});

// Custom comparison function example
const MemoizedComponent = memo(Component, (prevProps, nextProps) => {
  return prevProps.id === nextProps.id && 
         prevProps.value === nextProps.value;
});
```

### 3.2 React Refs and ForwardRef
Usage of refs and forwardRef in the codebase:

```typescript
// Example from app/components/workbench/terminal/Terminal.tsx
export const Terminal = memo(
  forwardRef<TerminalRef, TerminalProps>(({
    className, 
    theme, 
    readonly, 
    onTerminalReady, 
    onTerminalResize
  }, ref) => {
    const terminalElementRef = useRef<HTMLDivElement>(null);
    const terminalRef = useRef<XTerm>();

    useImperativeHandle(ref, () => ({
      reloadStyles: () => {
        const terminal = terminalRef.current!;
        terminal.options.theme = getTerminalTheme(
          readonly ? { cursor: '#00000000' } : {}
        );
      },
    }), []);

    // ... rest of implementation
  })
);
```

## 4. Store Management Concepts

### 4.1 Nanostores Architecture
Understanding how nanostores work in the codebase:

```typescript
// Example from app/lib/stores/workbench.ts
export class WorkbenchStore {
  #previewsStore = new PreviewsStore(webcontainer);
  #filesStore = new FilesStore(webcontainer);
  #editorStore = new EditorStore(this.#filesStore);
  #terminalStore = new TerminalStore(webcontainer);

  artifacts: Artifacts = import.meta.hot?.data.artifacts ?? map({});
  showWorkbench: WritableAtom<boolean> = atom(false);
  currentView: WritableAtom<WorkbenchViewType> = atom('code');
  
  // Computed values example
  get previews() {
    return this.#previewsStore.previews;
  }

  // State updates
  setShowWorkbench(show: boolean) {
    this.showWorkbench.set(show);
  }
}
```

### 4.2 Store Persistence
Understanding how state is persisted:

```typescript
// Example of store persistence
export const themeStore = atom<Theme>(initStore());

function initStore() {
  if (!import.meta.env.SSR) {
    const persistedTheme = localStorage.getItem(kTheme) as Theme;
    const themeAttribute = document
      .querySelector('html')
      ?.getAttribute('data-theme');

    return persistedTheme ?? 
           (themeAttribute as Theme) ?? 
           DEFAULT_THEME;
  }

  return DEFAULT_THEME;
}
```

## 5. Advanced Docker Concepts

### 5.1 Multi-Stage Builds
Understanding multi-stage Docker builds:

```dockerfile
# Base stage with common dependencies
FROM node:20.18.0 AS base
WORKDIR /app
COPY package.json pnpm-lock.yaml ./
RUN corepack enable pnpm && pnpm install

# Development stage
FROM base AS bolt-ai-development
COPY . .
ENV NODE_ENV=development
CMD pnpm run dev --host

# Production stage
FROM base AS bolt-ai-production
COPY . .
RUN npm run build
ENV NODE_ENV=production
CMD [ "pnpm", "run", "dockerstart"]
```

### 5.2 Docker Volume Management
Understanding Docker volumes for development:

```yaml
# docker-compose.yaml volume configuration
volumes:
  - type: bind
    source: .
    target: /app
    consistency: cached
  - /app/node_modules
```

## 6. Advanced Security Concepts

### 6.1 CORS and Security Headers
Understanding security header implementation:

```typescript
// Security headers implementation
export default async function handleRequest(
  request: Request,
  responseStatusCode: number,
  responseHeaders: Headers,
) {
  // CORS headers
  responseHeaders.set(
    'Access-Control-Allow-Origin', 
    getAllowedOrigins()
  );
  
  // Security headers
  responseHeaders.set(
    'Cross-Origin-Embedder-Policy', 
    'require-corp'
  );
  responseHeaders.set(
    'Cross-Origin-Opener-Policy', 
    'same-origin'
  );
  responseHeaders.set(
    'Content-Security-Policy',
    getContentSecurityPolicy()
  );
  
  return new Response(body, {
    headers: responseHeaders,
    status: responseStatusCode,
  });
}
```

### 6.2 API Key Rotation
Understanding API key management:

```typescript
// API key management system
export class APIKeyManager {
  private static instance: APIKeyManager;
  private keys: Map<string, string> = new Map();
  private rotationSchedule: Map<string, number> = new Map();

  static getInstance(): APIKeyManager {
    if (!APIKeyManager.instance) {
      APIKeyManager.instance = new APIKeyManager();
    }
    return APIKeyManager.instance;
  }

  async rotateKey(provider: string): Promise<void> {
    // Implementation of key rotation logic
    const newKey = await this.generateNewKey(provider);
    this.keys.set(provider, newKey);
    this.scheduleNextRotation(provider);
  }

  private scheduleNextRotation(provider: string) {
    const nextRotation = Date.now() + 
      this.getRotationInterval(provider);
    this.rotationSchedule.set(provider, nextRotation);
  }
}
```

## Practical Exercises

### Exercise 1: Implement Custom Store
Create a custom store with persistence:

```typescript
// Implement a persisted store
class PersistedStore<T> {
  private store: WritableAtom<T>;
  private key: string;

  constructor(key: string, defaultValue: T) {
    this.key = key;
    this.store = atom<T>(this.loadInitialValue(defaultValue));
  }

  private loadInitialValue(defaultValue: T): T {
    if (typeof window === 'undefined') return defaultValue;
    
    const stored = localStorage.getItem(this.key);
    return stored ? JSON.parse(stored) : defaultValue;
  }

  get value(): T {
    return this.store.get();
  }

  set(value: T): void {
    this.store.set(value);
    if (typeof window !== 'undefined') {
      localStorage.setItem(this.key, JSON.stringify(value));
    }
  }
}
```

### Exercise 2: Implement Security Middleware
Create security middleware:

```typescript
// Implement security middleware
function createSecurityMiddleware() {
  return async (
    request: Request, 
    next: () => Promise<Response>
  ) => {
    const response = await next();
    const headers = new Headers(response.headers);

    // Add security headers
    headers.set('X-Content-Type-Options', 'nosniff');
    headers.set('X-Frame-Options', 'DENY');
    headers.set('X-XSS-Protection', '1; mode=block');

    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers
    });
  };
}
```

## Knowledge Check Questions

1. Explain how TypeScript generics are used in the store implementation.
2. Describe the WebContainer file system API and its limitations.
3. How does React.memo improve performance in the codebase?
4. Explain the nanostores architecture and its benefits.
5. Describe the multi-stage Docker build process.
6. How are security headers implemented and why are they important?

## Additional Resources

1. TypeScript Advanced Types Documentation
2. WebContainer API Documentation
3. React Performance Optimization Guide
4. Docker Multi-Stage Build Guide
5. Web Security Headers Documentation

## Next Steps

After completing this supplementary lesson, you should:
1. Have a deeper understanding of TypeScript features used in the codebase
2. Understand WebContainer's capabilities and limitations
3. Know how to implement and optimize React components
4. Be familiar with store management patterns
5. Understand security best practices
6. Be able to implement Docker multi-stage builds

This supplementary lesson completes any knowledge gaps from the previous lessons and provides a solid foundation for working with the Bolt.new codebase.
