# Supplementary Lesson: Foundational Concepts

## Table of Contents
1. WebContainer Fundamentals
2. State Management with Nanostores
3. React Concepts Used
4. Terminal and PTY Basics
5. File System Fundamentals
6. TypeScript Advanced Concepts
7. Stream Processing
8. Memory Management

## 1. WebContainer Fundamentals

### 1.1 What is WebContainer?

WebContainer is a browser-based runtime environment that enables running Node.js applications directly in the browser. Key concepts:

```typescript
// Example of WebContainer initialization
const webcontainer = await WebContainer.boot({
  workdirName: 'project'
});
```

### 1.2 WebContainer Architecture

```
Browser
└── WebContainer
    ├── Virtual File System
    ├── Process Management
    └── Network Stack
```

Key features explained:
1. **Sandboxed Environment**: WebContainer runs in a secure, isolated context
2. **Virtual File System**: In-memory file system that mimics Unix-like behavior
3. **Process Management**: Ability to spawn and manage processes in browser

## 2. State Management with Nanostores

### 2.1 Nanostores Basics

Nanostores is a lightweight state management solution used throughout Bolt.new:

```typescript
// Basic store creation
import { atom, map } from 'nanostores';

// Atom for simple values
const countStore = atom<number>(0);

// Map for complex objects
const userStore = map<{
  name: string;
  preferences: Record<string, unknown>;
}>({
  name: '',
  preferences: {}
});
```

### 2.2 Store Composition

```typescript
// Computed stores
import { computed } from 'nanostores';

const filesStore = map<Record<string, File>>({});
const selectedFileStore = atom<string | undefined>();

// Computed store that depends on both stores
const currentFile = computed(
  [filesStore, selectedFileStore],
  (files, selected) => selected ? files[selected] : undefined
);
```

## 3. React Concepts Used

### 3.1 React Refs and ForwardRef

```typescript
// ForwardRef usage in terminal component
import { forwardRef, useRef, useImperativeHandle } from 'react';

interface TerminalRef {
  reloadStyles: () => void;
}

interface TerminalProps {
  theme: Theme;
}

export const Terminal = forwardRef<TerminalRef, TerminalProps>(
  (props, ref) => {
    const terminalRef = useRef<XTerm>();

    useImperativeHandle(ref, () => ({
      reloadStyles: () => {
        terminalRef.current?.reloadStyles();
      }
    }));

    return <div ref={terminalRef} />;
  }
);
```

### 3.2 React Effects and Cleanup

```typescript
// Effect with cleanup in terminal
useEffect(() => {
  const terminal = new Terminal();
  terminal.open(containerRef.current!);

  // Cleanup function
  return () => {
    terminal.dispose();
  };
}, []);
```

## 4. Terminal and PTY Basics

### 4.1 Pseudo Terminal (PTY) Concepts

A PTY is a pseudo or virtual terminal that provides a bidirectional communication channel:

```typescript
interface PTYInterface {
  stdin: WritableStream;   // Input to terminal
  stdout: ReadableStream;  // Output from terminal
  stderr: ReadableStream;  // Error output
  resize: (cols: number, rows: number) => void;
  kill: () => void;
}

// Basic PTY implementation concept
class BasicPTY implements PTYInterface {
  private process: any;
  
  constructor(command: string, args: string[]) {
    // Initialize process
    this.process = spawn(command, args, {
      encoding: 'utf-8',
      env: process.env
    });
  }

  resize(cols: number, rows: number) {
    this.process.resize(cols, rows);
  }

  kill() {
    this.process.kill();
  }
}
```

### 4.2 ANSI Escape Sequences

Terminal color and formatting are controlled by ANSI escape sequences:

```typescript
const ANSIEscapes = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  // Colors
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  // Background colors
  bgRed: '\x1b[41m',
  bgGreen: '\x1b[42m',
  bgYellow: '\x1b[43m',
};

// Usage example
function formatOutput(text: string, color: string): string {
  return `${ANSIEscapes[color]}${text}${ANSIEscapes.reset}`;
}
```

## 5. File System Fundamentals

### 5.1 Virtual File System Structure

```typescript
// Basic virtual file system structure
interface VFSNode {
  type: 'file' | 'directory';
  name: string;
  content?: Uint8Array;
  children?: Map<string, VFSNode>;
  parent?: VFSNode;
  metadata: {
    created: number;
    modified: number;
    permissions: number;
  };
}

class VirtualFileSystem {
  private root: VFSNode;
  
  constructor() {
    this.root = {
      type: 'directory',
      name: '/',
      children: new Map(),
      metadata: {
        created: Date.now(),
        modified: Date.now(),
        permissions: 0o755
      }
    };
  }

  // File system operations
  async writeFile(path: string, content: Uint8Array) {
    const node = this.createNode(path, 'file');
    node.content = content;
    node.metadata.modified = Date.now();
  }

  async readFile(path: string): Promise<Uint8Array> {
    const node = this.findNode(path);
    if (node?.type !== 'file') throw new Error('Not a file');
    return node.content ?? new Uint8Array();
  }
}
```

### 5.2 File Watchers

```typescript
// File watching system
interface FileWatcher {
  onCreated: (path: string) => void;
  onModified: (path: string) => void;
  onDeleted: (path: string) => void;
}

class FileWatcherImplementation {
  private watchers: Set<FileWatcher> = new Set();

  watch(watcher: FileWatcher) {
    this.watchers.add(watcher);
    return {
      unsubscribe: () => {
        this.watchers.delete(watcher);
      }
    };
  }

  notifyChange(type: 'created' | 'modified' | 'deleted', path: string) {
    this.watchers.forEach(watcher => {
      switch (type) {
        case 'created':
          watcher.onCreated(path);
          break;
        case 'modified':
          watcher.onModified(path);
          break;
        case 'deleted':
          watcher.onDeleted(path);
          break;
      }
    });
  }
}
```

## 6. TypeScript Advanced Concepts

### 6.1 Mapped Types

```typescript
// Mapped types used in store implementations
type ReadonlyStore<T> = {
  readonly [K in keyof T]: T[K];
};

type Nullable<T> = {
  [K in keyof T]: T[K] | null;
};

// Usage example
interface FileState {
  content: string;
  modified: boolean;
  position: number;
}

type ReadonlyFileState = ReadonlyStore<FileState>;
type NullableFileState = Nullable<FileState>;
```

### 6.2 Conditional Types and Inference

```typescript
// Conditional types used in utility functions
type IsFile<T> = T extends { type: 'file' } ? true : false;
type ExtractContent<T> = T extends { content: infer C } ? C : never;

// Type predicates
function isFileNode(node: Node): node is FileNode {
  return node.type === 'file';
}

// Generic constraints
function getNodeContent<T extends { content?: unknown }>(
  node: T
): ExtractContent<T> | undefined {
  return node.content as ExtractContent<T>;
}
```

## 7. Stream Processing

### 7.1 Browser Streams API

```typescript
// Stream processing in terminal output
class TerminalOutputStream {
  private encoder = new TextEncoder();
  private decoder = new TextDecoder();

  createOutputStream() {
    return new TransformStream({
      transform: (chunk, controller) => {
        // Process incoming data
        const text = this.decoder.decode(chunk);
        const processed = this.processANSI(text);
        controller.enqueue(this.encoder.encode(processed));
      }
    });
  }

  private processANSI(text: string): string {
    // Process ANSI escape sequences
    return text.replace(/\x1b\[(.*?)m/g, (match, p1) => {
      // Convert ANSI to HTML/CSS
      return this.convertANSIToStyle(p1);
    });
  }
}
```

### 7.2 Backpressure Handling

```typescript
class BufferedStream {
  private buffer: any[] = [];
  private processing = false;
  private maxBufferSize = 1000;

  async write(chunk: any) {
    if (this.buffer.length >= this.maxBufferSize) {
      // Handle backpressure
      await this.waitForBuffer();
    }
    
    this.buffer.push(chunk);
    if (!this.processing) {
      this.processBuffer();
    }
  }

  private async waitForBuffer() {
    return new Promise<void>(resolve => {
      const interval = setInterval(() => {
        if (this.buffer.length < this.maxBufferSize) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    });
  }

  private async processBuffer() {
    this.processing = true;
    while (this.buffer.length > 0) {
      const chunk = this.buffer.shift();
      await this.processChunk(chunk);
    }
    this.processing = false;
  }
}
```

## 8. Memory Management

### 8.1 Memory Monitoring

```typescript
class MemoryMonitor {
  private memoryLimit = 500 * 1024 * 1024; // 500MB
  private warningThreshold = 0.8; // 80%

  checkMemoryUsage() {
    if ('performance' in window) {
      const memory = (performance as any).memory;
      if (memory) {
        const usage = memory.usedJSHeapSize;
        const percentage = usage / this.memoryLimit;

        if (percentage > this.warningThreshold) {
          this.handleHighMemoryUsage(usage);
        }
      }
    }
  }

  private handleHighMemoryUsage(usage: number) {
    console.warn(`High memory usage: ${usage / 1024 / 1024}MB`);
    // Implement memory cleanup strategies
    this.cleanupUnusedResources();
  }

  private cleanupUnusedResources() {
    // Implement cleanup logic
    // For example, clear file caches, dispose unused terminals
  }
}
```

### 8.2 Resource Cleanup

```typescript
class ResourceManager {
  private resources = new Map<string, Disposable>();

  register(id: string, resource: Disposable) {
    this.resources.set(id, resource);
  }

  dispose(id: string) {
    const resource = this.resources.get(id);
    if (resource) {
      resource.dispose();
      this.resources.delete(id);
    }
  }

  disposeAll() {
    this.resources.forEach(resource => resource.dispose());
    this.resources.clear();
  }
}

// Usage in component
class Component {
  private resourceManager = new ResourceManager();

  initializeResource() {
    const resource = new ExpensiveResource();
    this.resourceManager.register('main', resource);
  }

  cleanup() {
    this.resourceManager.disposeAll();
  }
}
```

## Conclusion

This supplementary lesson covered the fundamental concepts that were assumed knowledge in Lessons 4 and 5. Understanding these concepts is crucial for:

1. Building robust file system implementations
2. Managing terminal state and processes
3. Implementing efficient stream processing
4. Handling memory and resource management
5. Using TypeScript's advanced type system
6. Working with WebContainer effectively

These concepts form the foundation for building complex browser-based development environments like Bolt.new.
