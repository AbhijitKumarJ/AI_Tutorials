# Lesson 3: LLM Integration and Chat System

## Learning Objectives
Students completing this lesson will gain comprehensive understanding of:

**LLM Integration**: Master how Bolt.new integrates with various Language Learning Models (LLMs), including implementation details and best practices.

**Chat System Architecture**: Understand the complete chat system implementation, including message handling, streaming, and state management.

**Provider Integration**: Learn how different AI providers are integrated and managed within the system.

**Error Handling**: Comprehensive understanding of error handling strategies across different providers and scenarios.

## 1. LLM Integration Architecture

### 1.1 Provider Management System

The system implements a flexible provider management architecture:

```typescript
// app/lib/.server/llm/api-key.ts
export function getAPIKey(cloudflareEnv: Env, provider: string) {
  switch (provider) {
    case 'Anthropic':
      return env.ANTHROPIC_API_KEY || cloudflareEnv.ANTHROPIC_API_KEY;
    case 'OpenAI':
      return env.OPENAI_API_KEY || cloudflareEnv.OPENAI_API_KEY;
    case 'Google':
      return env.GOOGLE_GENERATIVE_AI_API_KEY || cloudflareEnv.GOOGLE_GENERATIVE_AI_API_KEY;
    case 'Groq':
      return env.GROQ_API_KEY || cloudflareEnv.GROQ_API_KEY;
    case 'OpenRouter':
      return env.OPEN_ROUTER_API_KEY || cloudflareEnv.OPEN_ROUTER_API_KEY;
    case 'Deepseek':
      return env.DEEPSEEK_API_KEY || cloudflareEnv.DEEPSEEK_API_KEY
    case 'Mistral':
      return env.MISTRAL_API_KEY || cloudflareEnv.MISTRAL_API_KEY;        
    case "OpenAILike":
      return env.OPENAI_LIKE_API_KEY || cloudflareEnv.OPENAI_LIKE_API_KEY;
    default:
      return "";
  }
}
```

This system provides:
1. Flexible API key management
2. Environment-aware configuration
3. Provider-specific handling
4. Fallback mechanisms
5. Type safety for providers

### 1.2 Model Configuration

Model configuration is managed through a centralized system:

```typescript
// app/utils/constants.ts
export const MODEL_LIST: ModelInfo[] = [
  { 
    name: 'claude-3-5-sonnet-20240620',
    label: 'Claude 3.5 Sonnet',
    provider: 'Anthropic'
  },
  { 
    name: 'gpt-4-turbo',
    label: 'GPT-4 Turbo',
    provider: 'OpenAI' 
  },
  // Additional models...
];

export async function getOllamaModels(): Promise<ModelInfo[]> {
  try {
    const base_url = import.meta.env.OLLAMA_API_BASE_URL || "http://localhost:11434";
    const response = await fetch(`${base_url}/api/tags`);
    const data = await response.json() as OllamaApiResponse;

    return data.models.map((model: OllamaModel) => ({
      name: model.name,
      label: `${model.name} (${model.details.parameter_size})`,
      provider: 'Ollama',
    }));
  } catch (e) {
    return [];
  }
}
```

This configuration provides:
1. Centralized model management
2. Dynamic model loading
3. Provider-specific customization
4. Type-safe model information
5. Error handling for model loading

## 2. Chat System Implementation

### 2.1 Message Processing

The chat system implements sophisticated message processing:

```typescript
// app/lib/runtime/message-parser.ts
export class StreamingMessageParser {
  #messages = new Map<string, MessageState>();

  parse(messageId: string, input: string) {
    let state = this.#messages.get(messageId);

    if (!state) {
      state = {
        position: 0,
        insideAction: false,
        insideArtifact: false,
        currentAction: { content: '' },
        actionId: 0,
      };

      this.#messages.set(messageId, state);
    }

    let output = '';
    let i = state.position;
    let earlyBreak = false;

    while (i < input.length) {
      if (state.insideArtifact) {
        // Artifact processing logic
        const currentArtifact = state.currentArtifact;

        if (currentArtifact === undefined) {
          unreachable('Artifact not initialized');
        }

        if (state.insideAction) {
          // Action processing logic
          const closeIndex = input.indexOf(ARTIFACT_ACTION_TAG_CLOSE, i);

          const currentAction = state.currentAction;

          if (closeIndex !== -1) {
            currentAction.content += input.slice(i, closeIndex);
            // Process action completion
          }
        }
      }
      // Additional processing logic...
    }

    state.position = i;
    return output;
  }
}
```

The parser implements:
1. Streaming message handling
2. State management per message
3. Artifact detection and processing
4. Action handling
5. Error recovery

### 2.2 Stream Management

The system implements a sophisticated streaming mechanism:

```typescript
// app/lib/.server/llm/switchable-stream.ts
export default class SwitchableStream extends TransformStream {
  private _controller: TransformStreamDefaultController | null = null;
  private _currentReader: ReadableStreamDefaultReader | null = null;
  private _switches = 0;

  constructor() {
    let controllerRef: TransformStreamDefaultController | undefined;

    super({
      start(controller) {
        controllerRef = controller;
      },
    });

    if (controllerRef === undefined) {
      throw new Error('Controller not properly initialized');
    }

    this._controller = controllerRef;
  }

  async switchSource(newStream: ReadableStream) {
    if (this._currentReader) {
      await this._currentReader.cancel();
    }

    this._currentReader = newStream.getReader();
    this._pumpStream();
    this._switches++;
  }

  private async _pumpStream() {
    if (!this._currentReader || !this._controller) {
      throw new Error('Stream is not properly initialized');
    }

    try {
      while (true) {
        const { done, value } = await this._currentReader.read();

        if (done) {
          break;
        }

        this._controller.enqueue(value);
      }
    } catch (error) {
      console.log(error);
      this._controller.error(error);
    }
  }
}
```

This implementation provides:
1. Stream switching capability
2. Error handling
3. Resource cleanup
4. Stream state management
5. Performance optimization

## 3. Provider Integration

### 3.1 Provider-Specific Implementation

Each provider has specific implementation details:

```typescript
// app/lib/.server/llm/model.ts
export function getAnthropicModel(apiKey: string, model: string) {
  const anthropic = createAnthropic({
    apiKey,
  });

  return anthropic(model);
}

export function getOpenAIModel(apiKey: string, model: string) {
  const openai = createOpenAI({
    apiKey,
  });

  return openai(model);
}

export function getMistralModel(apiKey: string, model: string) {
  const mistral = createMistral({
    apiKey
  });

  return mistral(model);
}

export function getModel(provider: string, model: string, env: Env) {
  const apiKey = getAPIKey(env, provider);
  const baseURL = getBaseURL(env, provider);

  switch (provider) {
    case 'Anthropic':
      return getAnthropicModel(apiKey, model);
    case 'OpenAI':
      return getOpenAIModel(apiKey, model);
    case 'Mistral':
      return getMistralModel(apiKey, model);
    // Additional providers...
    default:
      return getOllamaModel(baseURL, model);
  }
}
```

This implementation provides:
1. Provider-specific configuration
2. Model instantiation
3. API key management
4. Error handling
5. Type safety

### 3.2 Prompt Management

The system implements sophisticated prompt management:

```typescript
// app/lib/.server/llm/prompts.ts
export const getSystemPrompt = (cwd: string = WORK_DIR) => `
You are Bolt, an expert AI assistant and exceptional senior software developer with vast knowledge across multiple programming languages, frameworks, and best practices.

<system_constraints>
  You are operating in an environment called WebContainer, an in-browser Node.js runtime that emulates a Linux system to some degree. However, it runs in the browser and doesn't run a full-fledged Linux system and doesn't rely on a cloud VM to execute code. All code is executed in the browser. It comes with a shell that emulates zsh. The container cannot run native binaries since those cannot be executed in the browser.

  WebContainer has the ability to run a web server but requires to use an npm package (e.g., Vite, servor, serve, http-server) or use the Node.js APIs to implement a web server.

  IMPORTANT: Git is NOT available.

  IMPORTANT: Prefer writing Node.js scripts instead of shell scripts.

  Available shell commands:
    File Operations:
      - cat: Display file contents
      - cp: Copy files/directories
      - ls: List directory contents
      - mkdir: Create directory
      - mv: Move/rename files
      - rm: Remove files
      - rmdir: Remove empty directories
      - touch: Create empty file
</system_constraints>

<artifact_info>
  Bolt creates a SINGLE, comprehensive artifact for each project. The artifact contains all necessary steps and components, including:

  - Shell commands to run including dependencies to install
  - Files to create and their contents
  - Folders to create if necessary

  <artifact_instructions>
    1. CRITICAL: Think HOLISTICALLY and COMPREHENSIVELY BEFORE creating an artifact
    2. IMPORTANT: When receiving file modifications, ALWAYS use the latest file modifications
    3. The current working directory is \`${cwd}\`
    4. Wrap content in opening and closing \`<boltArtifact>\` tags
    5. Add a title and unique identifier
    6. Use \`<boltAction>\` tags for specific actions
    7. Add appropriate type attributes
    8. Order actions logically
    9. Install dependencies FIRST
    10. CRITICAL: Always provide FULL, updated content
  </artifact_instructions>
</artifact_info>
`;
```

This implementation provides:
1. Structured prompt design
2. System constraints definition
3. Artifact handling instructions
4. Working directory management
5. Action specification

## 4. Error Handling and Recovery

### 4.1 Error Management System

```typescript
// app/lib/runtime/error-handler.ts
export class ErrorHandler {
  static async handleStreamError(error: unknown): Promise<Response> {
    console.error('Stream error:', error);

    if (error instanceof ApiError) {
      return new Response(null, {
        status: error.status,
        statusText: error.message
      });
    }

    if (error instanceof NetworkError) {
      return new Response(null, {
        status: 503,
        statusText: 'Service Unavailable'
      });
    }

    return new Response(null, {
      status: 500,
      statusText: 'Internal Server Error'
    });
  }

  static handleProviderError(error: unknown, provider: string) {
    console.error(`${provider} error:`, error);

    if (error instanceof RateLimitError) {
      return new Error(`${provider} rate limit exceeded`);
    }

    if (error instanceof AuthenticationError) {
      return new Error(`${provider} authentication failed`);
    }

    return new Error(`${provider} request failed`);
  }
}
```

This system provides:
1. Error categorization
2. Provider-specific handling
3. Stream error management
4. Rate limiting handling
5. Authentication error handling

## Practice Exercises

### Exercise 1: Implement Custom Provider
Create a new provider integration:

```typescript
// TODO: Implement custom provider
interface CustomProvider {
  // Add provider configuration
  apiKey: string;
  baseUrl: string;
  models: string[];
  
  // Add provider methods
  initialize(): Promise<void>;
  getCompletion(prompt: string): Promise<string>;
  streamCompletion(prompt: string): ReadableStream;
}
```

### Exercise 2: Enhance Message Parser
Improve the message parser:

```typescript
// TODO: Implement enhanced parser
class EnhancedMessageParser extends StreamingMessageParser {
  // Add features:
  // 1. Message validation
  // 2. Content sanitization
  // 3. Metadata extraction
  // 4. Performance optimization
  // 5. Error recovery
}
```

## Knowledge Check Questions

1. Explain the LLM integration architecture:
   - How are different providers integrated?
   - What is the model selection process?
   - How is streaming implemented?
   - How are errors handled?

2. Describe the chat system implementation:
   - How are messages processed?
   - How is state managed?
   - How is streaming handled?
   - How are artifacts handled?

3. Explain provider management:
   - How are API keys managed?
   - How are models configured?
   - How are provider-specific features handled?
   - How is error handling implemented?

## Additional Resources

1. API Documentation:
   - [OpenAI API](https://platform.openai.com/docs/api-reference)
   - [Anthropic API](https://console.anthropic.com/docs)
   - [Mistral AI](https://docs.mistral.ai)

2. Streaming Resources:
   - [Web Streams API](https://developer.mozilla.org/en-US/docs/Web/API/Streams_API)
   - [Node.js Streams](https://nodejs.org/api/stream.html)

3. Error Handling:
   - [Error Handling Best Practices](https://www.typescriptlang.org/docs/handbook/error-handling.html)
   - [Stream Error Handling](https://developer.mozilla.org/en-US/docs/Web/API/Streams_API/Error_handling)

This concludes Lesson 3, providing a comprehensive understanding of Bolt.new's LLM integration and chat system. The next lesson will focus on File System and Editor Implementation.

