# Supplementary Lesson: Understanding Core Concepts from Lessons 7 & 8

## Lesson Overview
This supplementary lesson explains the fundamental concepts that were assumed as prerequisite knowledge in Lessons 7 (Backend Integration and API Design) and 8 (Testing and Development Workflows).

## 1. Understanding Streams and Streaming Responses

### 1.1 What are Streams?
A stream is a sequence of data made available over time rather than all at once. Think of it like watching a video on YouTube - you don't download the entire video before starting; it plays as data arrives.

### 1.2 SwitchableStream Implementation
The SwitchableStream class used in Bolt.new:

```typescript
export default class SwitchableStream extends TransformStream {
  private _controller: TransformStreamDefaultController | null = null;
  private _currentReader: ReadableStreamDefaultReader | null = null;
  private _switches = 0;

  constructor() {
    let controllerRef: TransformStreamDefaultController | undefined;

    // Set up the transform stream controller
    super({
      start(controller) {
        controllerRef = controller;
      },
    });

    if (controllerRef === undefined) {
      throw new Error('Controller not properly initialized');
    }

    this._controller = controllerRef;
  }

  // Method to switch the source of the stream
  async switchSource(newStream: ReadableStream) {
    // Cancel current reader if exists
    if (this._currentReader) {
      await this._currentReader.cancel();
    }

    // Get reader from new stream
    this._currentReader = newStream.getReader();
    this._pumpStream();
    this._switches++;
  }

  private async _pumpStream() {
    if (!this._currentReader || !this._controller) {
      throw new Error('Stream is not properly initialized');
    }

    try {
      while (true) {
        const { done, value } = await this._currentReader.read();
        
        if (done) {
          break;
        }

        this._controller.enqueue(value);
      }
    } catch (error) {
      console.log(error);
      this._controller.error(error);
    }
  }
}
```

This implementation allows:
1. Continuous data flow control
2. Switching between different data sources
3. Proper error handling
4. Memory efficiency

## 2. Remix Core Concepts

### 2.1 Understanding Remix Architecture
Remix is a full-stack web framework that uses React. Key concepts include:

#### Loaders
Loaders are server-side functions that load data for components:

```typescript
// Example loader
export async function loader({ params }: LoaderFunctionArgs) {
  // Fetch data before component renders
  const data = await getData(params.id);
  return json(data);
}

// Using loader data in component
function Component() {
  const data = useLoaderData<typeof loader>();
  return <div>{data.title}</div>;
}
```

#### Actions
Actions handle data mutations:

```typescript
// Example action
export async function action({ request }: ActionFunctionArgs) {
  // Get form data
  const formData = await request.formData();
  
  // Process the data
  const result = await processData(formData);
  
  // Return response
  return json(result);
}
```

### 2.2 Server-Side Rendering (SSR)
SSR renders React components on the server first:

```typescript
// entry.server.tsx explanation
export default async function handleRequest(
  request: Request,
  responseStatusCode: number,
  responseHeaders: Headers,
  remixContext: EntryContext,
) {
  // Create stream for rendering
  const stream = await renderToReadableStream(
    <RemixServer context={remixContext} url={request.url} />,
    {
      // When there's an error during rendering
      onError(error: unknown) {
        responseStatusCode = 500;
        console.error(error);
      },
      // Called when React finishes rendering
      onAllReady() {
        // Can start sending the HTML to the client
      },
    }
  );

  return new Response(stream, {
    headers: { 'Content-Type': 'text/html' },
    status: responseStatusCode,
  });
}
```

## 3. Testing Concepts

### 3.1 Test Types Explained

#### Unit Tests
Tests individual functions or components in isolation:

```typescript
describe('normalizePath', () => {
  it('should handle Windows paths', () => {
    const input = 'C:\\Users\\test\\file.txt';
    const expected = 'C:/Users/test/file.txt';
    expect(normalizePath(input)).toBe(expected);
  });
});
```

#### Integration Tests
Tests multiple components working together:

```typescript
describe('ChatSystem', () => {
  it('should process messages and update UI', async () => {
    // Setup test environment
    const { container } = render(<ChatComponent />);
    
    // Simulate user input
    await userEvent.type(
      screen.getByRole('textbox'),
      'Hello, World!'
    );
    
    // Verify the entire flow
    expect(await screen.findByText('Response')).toBeInTheDocument();
  });
});
```

#### Snapshot Tests
Captures rendered output and compares against saved version:

```typescript
it('renders message correctly', () => {
  const tree = renderer
    .create(<Message text="Hello" />)
    .toJSON();
  expect(tree).toMatchSnapshot();
});
```

### 3.2 Test Double Concepts

#### Mocks
Replace real implementations with test versions:

```typescript
// Mock example
jest.mock('./database', () => ({
  query: jest.fn().mockResolvedValue([{ id: 1, name: 'Test' }])
}));

// Using mock in test
test('fetches data', async () => {
  const result = await getData();
  expect(result).toEqual([{ id: 1, name: 'Test' }]);
});
```

#### Stubs
Provide predetermined responses:

```typescript
// Stub example
const apiStub = {
  fetchData: () => Promise.resolve({ success: true })
};

test('handles API response', async () => {
  const component = new MyComponent(apiStub);
  const result = await component.processData();
  expect(result.success).toBe(true);
});
```

## 4. Docker Concepts

### 4.1 Multi-stage Builds
Builds that use multiple stages to optimize the final image:

```dockerfile
# Build stage
FROM node:20 AS builder
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

# Production stage
FROM node:20-slim
WORKDIR /app
COPY --from=builder /app/dist ./dist
COPY package*.json ./
RUN npm install --production
CMD ["npm", "start"]
```

### 4.2 Docker Compose Networks
Understanding how services communicate:

```yaml
services:
  frontend:
    build: ./frontend
    networks:
      - app-network
  
  backend:
    build: ./backend
    networks:
      - app-network
      - db-network
  
  database:
    image: postgres
    networks:
      - db-network

networks:
  app-network:
  db-network:
```

## 5. Performance Concepts

### 5.1 Code Splitting
Splitting code into loadable chunks:

```typescript
// Before code splitting
import { HugeComponent } from './HugeComponent';

// After code splitting
const HugeComponent = React.lazy(() => 
  import('./HugeComponent')
);

function App() {
  return (
    <Suspense fallback={<Loading />}>
      <HugeComponent />
    </Suspense>
  );
}
```

### 5.2 Bundle Analysis
Understanding and optimizing bundle size:

```typescript
// vite.config.ts with bundle analysis
import { visualizer } from 'rollup-plugin-visualizer';

export default defineConfig({
  plugins: [
    visualizer({
      open: true,
      gzipSize: true,
      brotliSize: true,
    }),
  ],
});
```

## 6. Development Environment Concepts

### 6.1 Environment Variables
Managing different environments:

```typescript
// .env.development
API_URL=http://localhost:3000
DEBUG=true

// .env.production
API_URL=https://api.production.com
DEBUG=false

// Using environment variables
const apiUrl = process.env.API_URL;
const debug = process.env.DEBUG === 'true';
```

### 6.2 Hot Module Replacement (HMR)
Understanding how HMR works:

```typescript
// vite.config.ts HMR configuration
export default defineConfig({
  server: {
    hmr: {
      overlay: true,
      port: 24678,
      protocol: 'ws',
    },
  },
});
```

## Knowledge Check Questions

1. What is the difference between a stream and a regular HTTP response?
2. How does Remix's loader differ from a regular API endpoint?
3. What are the benefits of multi-stage Docker builds?
4. Why is code splitting important for performance?
5. How does HMR improve the development experience?

## Additional Resources

1. [Web Streams API Documentation](https://developer.mozilla.org/en-US/docs/Web/API/Streams_API)
2. [Remix Concepts Deep Dive](https://remix.run/docs/en/main/guides/philosophy)
3. [Docker Multi-stage Builds](https://docs.docker.com/build/building/multi-stage/)
4. [React Code-Splitting Guide](https://reactjs.org/docs/code-splitting.html)
5. [Vite HMR Guide](https://vitejs.dev/guide/features.html#hot-module-replacement)

## Next Steps

After understanding these concepts, you should:
1. Review Lessons 7 and 8 again
2. Practice implementing each concept in isolation
3. Combine concepts in small projects
4. Explore advanced features of each technology
5. Contribute to the Bolt.new codebase
