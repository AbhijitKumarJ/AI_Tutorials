# Lesson 10: Production Deployment and DevOps

## Lesson Overview
In this final lesson, we'll explore the deployment processes, DevOps practices, and production considerations for the Bolt.new codebase. We'll cover Docker deployment, cloud services integration, monitoring, and security best practices.

## Prerequisites
- Complete understanding of Lessons 1-9
- Basic Docker knowledge
- Understanding of cloud services (particularly Cloudflare)
- Familiarity with CI/CD concepts
- Basic understanding of security principles

## 1. Build Process Understanding

### 1.1 Build Architecture
The build process in Bolt.new is orchestrated through several key configuration files:

```plaintext
/
├── package.json           # Main build scripts and dependencies
├── vite.config.ts        # Vite configuration for build process
├── tsconfig.json         # TypeScript configuration
├── wrangler.toml         # Cloudflare Workers configuration
├── docker-compose.yaml   # Docker composition setup
└── Dockerfile           # Docker build configuration
```

### 1.2 Build Scripts Analysis
Let's examine the key build scripts from package.json:

```json
{
  "scripts": {
    "deploy": "npm run build && wrangler pages deploy",
    "build": "remix vite:build",
    "dev": "remix vite:dev",
    "start": "bindings=$(./bindings.sh) && wrangler pages dev ./build/client $bindings",
    "dockerstart": "bindings=$(./bindings.sh) && wrangler pages dev ./build/client $bindings --ip 0.0.0.0 --port 5173 --no-show-interactive-dev-session",
    "dockerbuild:prod": "docker build -t bolt-ai:production bolt-ai:latest --target bolt-ai-production .",
    "dockerbuild": "docker build -t bolt-ai:development -t bolt-ai:latest --target bolt-ai-development ."
  }
}
```

### 1.3 Environment Configuration
The environment configuration is managed through multiple files:

```typescript
// Located in app/utils/constants.ts
export const WORK_DIR_NAME = 'project';
export const WORK_DIR = `/home/${WORK_DIR_NAME}`;
export const MAX_TOKENS = 8000;
export const DEFAULT_MODEL = 'claude-3-sonnet-20240229';

// Environment variables configuration
interface Env {
  ANTHROPIC_API_KEY: string;
  OPENAI_API_KEY: string;
  GROQ_API_KEY: string;
  OPEN_ROUTER_API_KEY: string;
  OLLAMA_API_BASE_URL: string;
  OPENAI_LIKE_API_KEY: string;
  OPENAI_LIKE_API_BASE_URL: string;
  DEEPSEEK_API_KEY: string;
}
```

## 2. Docker Deployment Configuration

### 2.1 Docker Setup
The Docker configuration is designed to support both development and production environments:

```dockerfile
# Dockerfile
ARG BASE=node:20.18.0
FROM ${BASE} AS base

WORKDIR /app

# Install dependencies
COPY package.json pnpm-lock.yaml ./
RUN corepack enable pnpm && pnpm install

# Copy source code
COPY . .
EXPOSE 5173

# Production image
FROM base AS bolt-ai-production
ARG GROQ_API_KEY
ARG OPENAI_API_KEY
ARG ANTHROPIC_API_KEY
# ... other API keys

ENV WRANGLER_SEND_METRICS=false \
    GROQ_API_KEY=${GROQ_API_KEY} \
    OPENAI_API_KEY=${OPENAI_API_KEY} \
    # ... other environment variables

RUN npm run build
CMD [ "pnpm", "run", "dockerstart"]

# Development image
FROM base AS bolt-ai-development
# ... development-specific configuration
```

### 2.2 Docker Compose Configuration
The docker-compose.yaml file orchestrates the services:

```yaml
services:
  bolt-ai:
    image: bolt-ai:production
    build:
      context: .
      dockerfile: Dockerfile
      target: bolt-ai-production
    ports:
      - "5173:5173"
    env_file: ".env.local"
    environment:
      - NODE_ENV=production
      - COMPOSE_PROFILES=production
      # ... other environment variables
    command: pnpm run dockerstart
    profiles:
      - production

  bolt-ai-dev:
    image: bolt-ai:development
    build:
      target: bolt-ai-development
    environment:
      - NODE_ENV=development
      # ... development environment variables
    volumes:
      - type: bind
        source: .
        target: /app
        consistency: cached
      - /app/node_modules
    ports:
      - "5173:5173"
    command: pnpm run dev --host 0.0.0.0
    profiles: ["development", "default"]
```

## 3. Security Implementation

### 3.1 API Key Management
Secure handling of API keys:

```typescript
// Located in app/lib/.server/llm/api-key.ts
export function getAPIKey(cloudflareEnv: Env, provider: string) {
  switch (provider) {
    case 'Anthropic':
      return env.ANTHROPIC_API_KEY || cloudflareEnv.ANTHROPIC_API_KEY;
    case 'OpenAI':
      return env.OPENAI_API_KEY || cloudflareEnv.OPENAI_API_KEY;
    // ... other providers
    default:
      return "";
  }
}
```

### 3.2 Security Headers
Implementation of security headers:

```typescript
// Located in app/entry.server.tsx
export default async function handleRequest(
  request: Request,
  responseStatusCode: number,
  responseHeaders: Headers,
  remixContext: EntryContext,
) {
  // ... response handling

  // Security headers
  responseHeaders.set('Cross-Origin-Embedder-Policy', 'require-corp');
  responseHeaders.set('Cross-Origin-Opener-Policy', 'same-origin');
  
  return new Response(body, {
    headers: responseHeaders,
    status: responseStatusCode,
  });
}
```

## 4. Monitoring and Logging

### 4.1 Logging Implementation
The logging system is implemented with different levels of detail:

```typescript
// Located in app/utils/logger.ts
export type DebugLevel = 'trace' | 'debug' | 'info' | 'warn' | 'error';

export const logger: Logger = {
  trace: (...messages: any[]) => log('trace', undefined, messages),
  debug: (...messages: any[]) => log('debug', undefined, messages),
  info: (...messages: any[]) => log('info', undefined, messages),
  warn: (...messages: any[]) => log('warn', undefined, messages),
  error: (...messages: any[]) => log('error', undefined, messages),
  setLevel,
};

export function createScopedLogger(scope: string): Logger {
  return {
    trace: (...messages: any[]) => log('trace', scope, messages),
    debug: (...messages: any[]) => log('debug', scope, messages),
    // ... other log levels
  };
}
```

### 4.2 Performance Monitoring
Implementation of performance tracking:

```typescript
// Located in app/utils/performance.ts
export class PerformanceMonitor {
  private static instance: PerformanceMonitor;
  private metrics: Map<string, number[]> = new Map();

  static getInstance(): PerformanceMonitor {
    if (!PerformanceMonitor.instance) {
      PerformanceMonitor.instance = new PerformanceMonitor();
    }
    return PerformanceMonitor.instance;
  }

  trackMetric(name: string, value: number) {
    const existing = this.metrics.get(name) || [];
    this.metrics.set(name, [...existing, value]);
  }

  getMetrics() {
    return Object.fromEntries(
      Array.from(this.metrics.entries()).map(([key, values]) => [
        key,
        {
          average: values.reduce((a, b) => a + b, 0) / values.length,
          max: Math.max(...values),
          min: Math.min(...values),
          count: values.length
        }
      ])
    );
  }
}
```

## 5. Deployment Strategies

### 5.1 Cloudflare Pages Deployment
Configuration for Cloudflare Pages deployment:

```typescript
// Located in wrangler.toml
name = "bolt"
compatibility_flags = ["nodejs_compat"]
compatibility_date = "2024-07-01"
pages_build_output_dir = "./build/client"
send_metrics = false
```

### 5.2 Environment-Specific Configurations

```typescript
// Located in app/lib/.server/llm/constants.ts
export const MAX_TOKENS = 8000;
export const MAX_RESPONSE_SEGMENTS = 2;

// Different configurations based on environment
export const getEnvironmentConfig = (env: string) => {
  switch (env) {
    case 'production':
      return {
        maxTokens: MAX_TOKENS,
        maxResponseSegments: MAX_RESPONSE_SEGMENTS,
        caching: true,
        logging: 'error',
      };
    case 'staging':
      return {
        maxTokens: MAX_TOKENS,
        maxResponseSegments: MAX_RESPONSE_SEGMENTS,
        caching: true,
        logging: 'warn',
      };
    default:
      return {
        maxTokens: MAX_TOKENS,
        maxResponseSegments: MAX_RESPONSE_SEGMENTS,
        caching: false,
        logging: 'debug',
      };
  }
};
```

## Practical Exercises

### Exercise 1: Set Up Local Development Environment
Configure a complete local development environment:

```bash
# Clone repository
git clone https://github.com/your-username/bolt.new.git

# Install dependencies
pnpm install

# Set up environment variables
cp .env.example .env.local

# Start development server
pnpm run dev
```

### Exercise 2: Deploy to Production
Implement a production deployment:

```bash
# Build production image
pnpm run dockerbuild:prod

# Deploy to production
docker-compose --profile production up -d

# Monitor logs
docker-compose logs -f bolt-ai
```

## Knowledge Check Questions

1. Explain the difference between development and production Docker configurations.
2. How does the environment variable management work across different deployment environments?
3. What security measures are implemented in the production environment?
4. How is logging implemented across different environments?
5. Describe the deployment process to Cloudflare Pages.

## Additional Resources

1. Docker Documentation
2. Cloudflare Pages Documentation
3. Security Best Practices Guide
4. Monitoring and Logging Strategies
5. Performance Optimization Guidelines

## Next Steps

After completing this lesson, you should:
1. Understand the complete deployment process
2. Be able to manage different deployment environments
3. Know how to implement security measures
4. Understand monitoring and logging
5. Be able to troubleshoot deployment issues

This concludes the course on Bolt.new codebase. You should now have a comprehensive understanding of the entire system, from development to production deployment.
