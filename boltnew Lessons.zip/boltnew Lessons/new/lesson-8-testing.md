# Lesson 8: Testing and Development Workflows in Bolt.new

## Lesson Overview
This lesson covers the comprehensive testing strategy and development workflows implemented in Bolt.new. We'll explore the testing infrastructure, continuous integration, development processes, and performance optimization techniques.

## Key Learning Objectives
By the end of this lesson, you will understand:
- The testing architecture in Bolt.new
- Development workflow patterns
- Docker implementation and containerization
- Debugging strategies
- Performance optimization techniques
- Cross-platform testing considerations

## 1. Testing Strategy and Implementation

### 1.1 Testing Infrastructure
The testing setup in Bolt.new uses Vitest for unit and integration testing. Let's examine the key testing files:

```
project-root/
├── package.json           # Test configurations
├── tsconfig.json         # TypeScript configuration
└── app/
    └── lib/
        └── runtime/
            ├── message-parser.spec.ts    # Test file
            └── __snapshots__/           # Snapshot tests
                └── message-parser.spec.ts.snap
```

### 1.2 Test Configuration
Package.json test configuration:
```json
{
  "scripts": {
    "test": "vitest --run",
    "test:watch": "vitest",
    "typecheck": "tsc",
    "lint": "eslint --cache --cache-location ./node_modules/.cache/eslint .",
    "lint:fix": "npm run lint -- --fix"
  }
}
```

### 1.3 Example Test Implementation
Message parser test implementation (`message-parser.spec.ts`):

```typescript
describe('StreamingMessageParser', () => {
  it.each<[string | string[], ExpectedResult | string]>([
    ['Foo bar', 'Foo bar'],
    ['Foo bar <', 'Foo bar '],
    ['Foo bar <p', 'Foo bar <p'],
    [['Foo bar <', 's', 'p', 'an>some text</span>'], 'Foo bar <span>some text</span>'],
  ])('should correctly parse chunks and strip out bolt artifacts (%#)', (input, expected) => {
    runTest(input, expected);
  });

  describe('valid artifacts with actions', () => {
    it.each<[string | string[], ExpectedResult | string]>([
      [
        'Before <boltArtifact title="Some title" id="artifact_1"><boltAction type="shell">npm install</boltAction></boltArtifact> After',
        {
          output: 'Before  After',
          callbacks: { onArtifactOpen: 1, onArtifactClose: 1, onActionOpen: 1, onActionClose: 1 },
        },
      ]
    ])('should correctly parse chunks and strip out bolt artifacts (%#)', (input, expected) => {
      runTest(input, expected);
    });
  });
});
```

### 1.4 Snapshot Testing
Snapshot tests are used for UI components and complex data structures:

```typescript
exports[`StreamingMessageParser > valid artifacts with actions > should correctly parse chunks and strip out bolt artifacts (0) > onActionClose 1`] = `
{
  "action": {
    "content": "npm install",
    "type": "shell",
  },
  "actionId": "0",
  "artifactId": "artifact_1",
  "messageId": "message_1",
}
`;
```

## 2. Development Workflows

### 2.1 Local Development Setup
The development environment is configured using Vite and Remix:

```typescript
// vite.config.ts
export default defineConfig((config) => {
  return {
    build: {
      target: 'esnext',
    },
    plugins: [
      nodePolyfills({
        include: ['path', 'buffer'],
      }),
      config.mode !== 'test' && remixCloudflareDevProxy(),
      remixVitePlugin({
        future: {
          v3_fetcherPersist: true,
          v3_relativeSplatPath: true,
          v3_throwAbortReason: true,
        },
      }),
      UnoCSS(),
      tsconfigPaths(),
      chrome129IssuePlugin(),
      config.mode === 'production' && optimizeCssModules({ apply: 'build' }),
    ]
  };
});
```

### 2.2 Development Scripts
Key development scripts from package.json:

```json
{
  "scripts": {
    "dev": "remix vite:dev",
    "build": "remix vite:build",
    "preview": "pnpm run build && pnpm run start",
    "deploy": "npm run build && wrangler pages deploy",
    "start": "bindings=$(./bindings.sh) && wrangler pages dev ./build/client $bindings"
  }
}
```

## 3. Docker Implementation

### 3.1 Dockerfile Configuration
The multi-stage Dockerfile for development and production:

```dockerfile
ARG BASE=node:20.18.0
FROM ${BASE} AS base

WORKDIR /app

# Install dependencies
COPY package.json pnpm-lock.yaml ./
RUN corepack enable pnpm && pnpm install

# Copy source code
COPY . .
EXPOSE 5173

# Production image
FROM base AS bolt-ai-production
ARG GROQ_API_KEY
ARG OPENAI_API_KEY
ARG ANTHROPIC_API_KEY
# ... other API keys

ENV WRANGLER_SEND_METRICS=false \
    GROQ_API_KEY=${GROQ_API_KEY} \
    OPENAI_API_KEY=${OPENAI_API_KEY} \
    ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}

RUN mkdir -p /root/.config/.wrangler && \
    echo '{"enabled":false}' > /root/.config/.wrangler/metrics.json

RUN npm run build
CMD [ "pnpm", "run", "dockerstart"]

# Development image
FROM base AS bolt-ai-development
# ... development configuration
```

### 3.2 Docker Compose Configuration
Docker Compose setup for different environments:

```yaml
services:
  bolt-ai:
    image: bolt-ai:production
    build:
      context: .
      dockerfile: Dockerfile
      target: bolt-ai-production
    ports:
      - "5173:5173"
    env_file: ".env.local"
    environment:
      - NODE_ENV=production
      # ... other environment variables
    command: pnpm run dockerstart
    profiles:
      - production

  bolt-ai-dev:
    image: bolt-ai:development
    build:
      target: bolt-ai-development
    environment:
      - NODE_ENV=development
      # ... development environment variables
    volumes:
      - type: bind
        source: .
        target: /app
        consistency: cached
      - /app/node_modules
    ports:
      - "5173:5173"
    command: pnpm run dev --host 0.0.0.0
    profiles: ["development", "default"]
```

## 4. Debugging Strategies

### 4.1 Logger Implementation
Custom logger implementation for different environments:

```typescript
export type DebugLevel = 'trace' | 'debug' | 'info' | 'warn' | 'error';

export const logger: Logger = {
  trace: (...messages: any[]) => log('trace', undefined, messages),
  debug: (...messages: any[]) => log('debug', undefined, messages),
  info: (...messages: any[]) => log('info', undefined, messages),
  warn: (...messages: any[]) => log('warn', undefined, messages),
  error: (...messages: any[]) => log('error', undefined, messages),
  setLevel,
};

export function createScopedLogger(scope: string): Logger {
  return {
    trace: (...messages: any[]) => log('trace', scope, messages),
    debug: (...messages: any[]) => log('debug', scope, messages),
    info: (...messages: any[]) => log('info', scope, messages),
    warn: (...messages: any[]) => log('warn', scope, messages),
    error: (...messages: any[]) => log('error', scope, messages),
    setLevel,
  };
}
```

### 4.2 Development Tools Integration
VSCode integration and debugging configuration:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "chrome",
      "request": "launch",
      "name": "Debug Bolt.new",
      "url": "http://localhost:5173",
      "webRoot": "${workspaceFolder}"
    }
  ]
}
```

## 5. Performance Optimization

### 5.1 Code Splitting
Implementation of dynamic imports and code splitting:

```typescript
const CodeMirrorEditor = React.lazy(() => import('./CodeMirrorEditor'));

function Editor() {
  return (
    <Suspense fallback={<Loading />}>
      <CodeMirrorEditor />
    </Suspense>
  );
}
```

### 5.2 Asset Optimization
Asset optimization configuration in Vite:

```typescript
export default defineConfig({
  build: {
    target: 'esnext',
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          // Other chunk configurations
        }
      }
    }
  }
});
```

## 6. Cross-Platform Testing

### 6.1 Platform-Specific Tests
Example of platform-specific test implementation:

```typescript
describe('Platform-specific behavior', () => {
  it('handles file paths correctly on Windows', () => {
    const path = 'C:\\Users\\test\\file.txt';
    expect(normalizePath(path)).toBe('C:/Users/test/file.txt');
  });

  it('handles file paths correctly on Unix', () => {
    const path = '/home/user/file.txt';
    expect(normalizePath(path)).toBe('/home/user/file.txt');
  });
});
```

## Practical Exercises

1. Create a New Test Suite
```typescript
describe('FileSystem Operations', () => {
  beforeEach(() => {
    // Setup test environment
  });

  afterEach(() => {
    // Cleanup
  });

  it('creates files correctly', async () => {
    // Test implementation
  });
});
```

2. Implement Performance Monitoring
```typescript
function measurePerformance(operation: () => void) {
  const start = performance.now();
  operation();
  const end = performance.now();
  console.log(`Operation took ${end - start}ms`);
}
```

## Common Pitfalls and Solutions

1. Test Environment Setup
   - Pitfall: Inconsistent test environments
   - Solution: Use Docker for consistent testing environments

2. Performance Testing
   - Pitfall: Unreliable performance metrics
   - Solution: Implement benchmarking with multiple runs

3. Cross-Platform Issues
   - Pitfall: Platform-specific bugs
   - Solution: Implement platform detection and specific handling

## Knowledge Check Questions

1. How does Bolt.new handle test isolation?
2. What strategies are used for performance optimization?
3. How are development workflows organized?
4. What role does Docker play in the development process?
5. How are cross-platform testing issues addressed?

## Additional Resources

1. [Vitest Documentation](https://vitest.dev/)
2. [Docker Documentation](https://docs.docker.com/)
3. [Remix Development Guide](https://remix.run/docs/en/main/guides/development)
4. [Performance Optimization Guide](https://web.dev/fast)

## Next Steps

After completing this lesson, you should:
1. Understand Bolt.new's testing strategy
2. Be able to implement new tests
3. Know how to use the development tools
4. Understand performance optimization techniques
5. Be familiar with cross-platform testing

The next lesson will cover advanced features and extensions, building upon the testing and development knowledge gained in this lesson.
