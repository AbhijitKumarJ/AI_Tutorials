# Lesson 2: Core Components and State Management

## Learning Objectives
Students completing this lesson will gain comprehensive understanding of:

**Component Architecture**: Master Bolt.new's component architecture, understanding how components are organized, communicate, and work together to create a cohesive application.

**State Management**: Learn the implementation of state management using nanostores, understanding how state flows through the application and best practices for state updates.

**TypeScript Integration**: Develop deep knowledge of TypeScript's role in component development, including type safety, interfaces, and advanced type patterns.

**Performance Optimization**: Understand how to optimize component performance through proper state management, memoization, and efficient rendering strategies.

## 1. Component Architecture

### 1.1 Component Organization
Bolt.new uses a feature-based component organization strategy. Let's examine each major component category:

#### Chat Components
The chat system is implemented through several specialized components that work together:

**BaseChat Component**
```typescript
// app/components/chat/BaseChat.tsx
export const BaseChat = React.forwardRef<HTMLDivElement, BaseChatProps>(
  ({
    textareaRef,
    messageRef,
    scrollRef,
    showChat = true,
    chatStarted = false,
    isStreaming = false,
    messages,
    input = '',
    model,
    setModel,
    sendMessage,
    handleInputChange,
    enhancePrompt,
    handleStop,
  }, ref) => {
    const TEXTAREA_MAX_HEIGHT = chatStarted ? 400 : 200;

    return (
      <div
        ref={ref}
        className={classNames(
          styles.BaseChat,
          'relative flex h-full w-full overflow-hidden'
        )}
        data-chat-visible={showChat}
      >
        <ClientOnly>{() => <Menu />}</ClientOnly>
        <div ref={scrollRef} className="flex overflow-y-auto w-full h-full">
          <div className={classNames(styles.Chat, 'flex flex-col flex-grow min-w-[var(--chat-min-width)] h-full')}>
            {/* Chat implementation details */}
          </div>
        </div>
      </div>
    );
  }
);
```

This component demonstrates several key architectural patterns:
1. **Forwarded Refs**: Uses React.forwardRef for DOM access
2. **Flexible Props**: Comprehensive prop interface for customization
3. **Conditional Rendering**: Adapts to chat state
4. **Style Composition**: Combines module styles with utility classes
5. **Client-Side Components**: Uses ClientOnly for browser-specific features

**Messages Component**
```typescript
// app/components/chat/Messages.tsx
export const Messages = React.forwardRef<HTMLDivElement, MessagesProps>(
  (props: MessagesProps, ref) => {
    const { id, isStreaming = false, messages = [] } = props;

    return (
      <div id={id} ref={ref} className={props.className}>
        {messages.map((message, index) => {
          const { role, content } = message;
          const isUserMessage = role === 'user';
          const isFirst = index === 0;
          const isLast = index === messages.length - 1;

          return (
            <div
              key={index}
              className={classNames('flex gap-4 p-6 w-full rounded-[calc(0.75rem-1px)]', {
                'bg-bolt-elements-messages-background': isUserMessage || !isStreaming || (isStreaming && !isLast),
                'bg-gradient-to-b from-bolt-elements-messages-background from-30% to-transparent':
                  isStreaming && isLast,
                'mt-4': !isFirst,
              })}
            >
              {/* Message rendering logic */}
            </div>
          );
        })}
      </div>
    );
  }
);
```

This component showcases:
1. **Message Rendering**: Efficient message display logic
2. **Streaming Support**: Handles real-time message updates
3. **Visual Feedback**: Dynamic styling for different states
4. **Performance Optimization**: Efficient rendering of large message lists

### 1.2 Editor Components

The editor system provides a full-featured development environment:

**CodeMirrorEditor Component**
```typescript
// app/components/editor/codemirror/CodeMirrorEditor.tsx
export const CodeMirrorEditor = memo(
  ({
    id,
    doc,
    debounceScroll = 100,
    debounceChange = 150,
    autoFocusOnDocumentChange = false,
    editable = true,
    onScroll,
    onChange,
    onSave,
    theme,
    settings,
    className = '',
  }: Props) => {
    const [languageCompartment] = useState(new Compartment());
    const containerRef = useRef<HTMLDivElement>(null);
    const viewRef = useRef<EditorView>();

    useEffect(() => {
      const onUpdate = debounce((update: EditorUpdate) => {
        onChange?.(update);
      }, debounceChange);

      const view = new EditorView({
        parent: containerRef.current!,
        dispatchTransactions(transactions) {
          const previousSelection = view.state.selection;
          view.update(transactions);
          const newSelection = view.state.selection;

          // Handle selection changes and updates
          if (selectionChanged || contentChanged) {
            onUpdate({
              selection: view.state.selection,
              content: view.state.doc.toString(),
            });
          }
        },
      });

      viewRef.current = view;

      return () => {
        view.destroy();
      };
    }, []);

    // Additional implementation details...

    return (
      <div className={classNames('relative h-full', className)}>
        {doc?.isBinary && <BinaryContent />}
        <div className="h-full overflow-hidden" ref={containerRef} />
      </div>
    );
  }
);
```

This editor implementation demonstrates:
1. **Complex State Management**: Handles editor state and updates
2. **Performance Optimization**: Debounced updates and memoization
3. **Cleanup Handling**: Proper resource cleanup in useEffect
4. **Binary File Support**: Special handling for binary content
5. **Theme Integration**: Dynamic theme support

## 2. State Management

### 2.1 Store Implementation

Bolt.new uses nanostores for state management. Let's examine the implementation:

**Chat Store**
```typescript
// app/lib/stores/chat.ts
import { map } from 'nanostores';

export const chatStore = map({
  started: false,
  aborted: false,
  showChat: true,
});
```

**Workbench Store**
```typescript
// app/lib/stores/workbench.ts
export class WorkbenchStore {
  #previewsStore = new PreviewsStore(webcontainer);
  #filesStore = new FilesStore(webcontainer);
  #editorStore = new EditorStore(this.#filesStore);
  #terminalStore = new TerminalStore(webcontainer);

  artifacts: Artifacts = map({});
  showWorkbench: WritableAtom<boolean> = atom(false);
  currentView: WritableAtom<WorkbenchViewType> = atom('code');
  unsavedFiles: WritableAtom<Set<string>> = atom(new Set<string>());

  constructor() {
    // Store initialization
  }

  async saveFile(filePath: string) {
    const documents = this.#editorStore.documents.get();
    const document = documents[filePath];

    if (document === undefined) {
      return;
    }

    await this.#filesStore.saveFile(filePath, document.value);

    const newUnsavedFiles = new Set(this.unsavedFiles.get());
    newUnsavedFiles.delete(filePath);

    this.unsavedFiles.set(newUnsavedFiles);
  }

  // Additional methods...
}
```

This store architecture demonstrates:
1. **Encapsulation**: Private fields with public methods
2. **State Composition**: Multiple specialized stores
3. **Atomic Updates**: Granular state changes
4. **Type Safety**: Strong typing throughout
5. **Resource Management**: Proper cleanup and initialization

### 2.2 Custom Hooks

Custom hooks encapsulate complex behaviors:

**useMessageParser Hook**
```typescript
// app/lib/hooks/useMessageParser.ts
export function useMessageParser() {
  const [parsedMessages, setParsedMessages] = useState<{ [key: number]: string }>({});

  const parseMessages = useCallback((messages: Message[], isLoading: boolean) => {
    let reset = false;

    if (import.meta.env.DEV && !isLoading) {
      reset = true;
      messageParser.reset();
    }

    for (const [index, message] of messages.entries()) {
      if (message.role === 'assistant') {
        const newParsedContent = messageParser.parse(message.id, message.content);

        setParsedMessages((prevParsed) => ({
          ...prevParsed,
          [index]: !reset ? (prevParsed[index] || '') + newParsedContent : newParsedContent,
        }));
      }
    }
  }, []);

  return { parsedMessages, parseMessages };
}
```

This hook demonstrates:
1. **State Management**: Efficient message state handling
2. **Memoization**: UseCallback for stable functions
3. **Development Support**: Special dev mode handling
4. **Performance Optimization**: Incremental updates
5. **Type Safety**: Strong typing throughout

## 3. TypeScript Integration

### 3.1 Type Definitions

The project uses comprehensive type definitions:

**Component Props**
```typescript
// app/types/components.ts
export interface BaseChatProps {
  textareaRef?: React.RefObject<HTMLTextAreaElement>;
  messageRef?: RefCallback<HTMLDivElement>;
  scrollRef?: RefCallback<HTMLDivElement>;
  showChat?: boolean;
  chatStarted?: boolean;
  isStreaming?: boolean;
  messages?: Message[];
  input?: string;
  model: string;
  setModel: (model: string) => void;
  handleStop?: () => void;
  sendMessage?: (event: React.UIEvent, messageInput?: string) => void;
  handleInputChange?: (event: React.ChangeEvent<HTMLTextAreaElement>) => void;
  enhancePrompt?: () => void;
}
```

**Store Types**
```typescript
// app/types/stores.ts
export interface FileMap {
  [path: string]: Dirent | undefined;
}

export interface PreviewInfo {
  port: number;
  ready: boolean;
  baseUrl: string;
}

export type WorkbenchViewType = 'code' | 'preview';
```

### 3.2 Type Utilities

The project includes useful type utilities:

```typescript
// app/utils/types.ts
export type Nullable<T> = T | null;
export type Optional<T> = T | undefined;

export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export function assertNever(x: never): never {
  throw new Error('Unexpected object: ' + x);
}
```

## 4. Performance Optimization

### 4.1 Memoization Strategies

The project uses various memoization techniques:

```typescript
// Example of component memoization
export const MessageList = memo(({ messages }: MessageListProps) => {
  return (
    <div>
      {messages.map((message) => (
        <Message
          key={message.id}
          content={message.content}
        />
      ))}
    </div>
  );
});

// Example of computed values
const computedValue = computed(
  [baseStore, dependencyStore],
  (baseValue, dependency) => {
    // Expensive computation
    return expensiveOperation(baseValue, dependency);
  }
);
```

### 4.2 Rendering Optimization

```typescript
// Example of optimized rendering
export function OptimizedList({ items }: ListProps) {
  const [visibleItems, setVisibleItems] = useState<ListItem[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            // Load more items
            loadMoreItems();
          }
        });
      },
      { threshold: 0.5 }
    );

    return () => observer.disconnect();
  }, []);

  return (
    <div className="virtualized-list">
      {visibleItems.map((item) => (
        <ListItem
          key={item.id}
          data={item}
        />
      ))}
    </div>
  );
}
```

## Practice Exercises

### Exercise 1: Create a Custom Store
Implement a custom store for managing application themes:

```typescript
// Implementation task
export class ThemeStore {
  // TODO: Implement theme store with:
  // 1. Theme state management
  // 2. Theme switching functionality
  // 3. Theme persistence
  // 4. System theme detection
  // 5. Event subscription
}
```

### Exercise 2: Optimize Component Rendering
Improve the performance of a message list component:

```typescript
// Implementation task
export function MessageList({ messages }: MessageListProps) {
  // TODO: Implement optimized message list with:
  // 1. Virtual scrolling
  // 2. Memoization
  // 3. Lazy loading
  // 4. Performance monitoring
  // 5. Error boundaries
}
```

## Knowledge Check Questions

1. Explain the role of nanostores in state management:
   - How does it differ from other state management solutions?
   - What are its advantages and disadvantages?
   - How does it handle async state updates?
   - How does it integrate with React components?

2. Describe the component architecture:
   - How are components organized?
   - What patterns are used for component communication?
   - How is state shared between components?
   - How are side effects managed?

3. Explain the performance optimization strategies:
   - What memoization techniques are used?
   - How is rendering optimized?
   - What are the key performance metrics?
   - How is performance monitored?

## Additional Resources

1. Documentation:
   - [Nanostores Documentation](https://github.com/nanostores/nanostores)
   - [React Performance](https://reactjs.org/docs/optimizing-performance.html)
   - [TypeScript Handbook](https://www.typescriptlang.org/docs/handbook/intro.html)

2. Tools:
   - [React DevTools](https://chrome.google.com/webstore/detail/react-developer-tools)
   - [Performance Profiler](https://developer.chrome.com/docs/devtools/performance)
   - [TypeScript Playground](https://www.typescriptlang.org/play)

This concludes Lesson 2, providing a comprehensive understanding of Bolt.new's component architecture and state management. The next lesson will focus on LLM Integration and the Chat System.
