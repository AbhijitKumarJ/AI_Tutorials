# Lesson 5: Terminal and Process Management

## Table of Contents
1. Introduction
2. Terminal Architecture Overview
3. Terminal Implementation Details
4. Process Management
5. Code Organization and File Layout
6. Practical Exercises
7. Advanced Topics
8. Troubleshooting and Best Practices

## 1. Introduction

This lesson explores the terminal and process management implementation in Bolt.new. The terminal component provides a browser-based command-line interface that closely mimics native terminal behavior. We'll examine how processes are managed within WebContainer's constraints and how the terminal interface is implemented using xterm.js.

## 2. Terminal Architecture Overview

### 2.1 Core Components

The terminal implementation in Bolt.new is structured around several key files:

```
app/
├── components/
│   └── workbench/
│       └── terminal/
│           ├── Terminal.tsx       # Main terminal component
│           └── theme.ts          # Terminal theming
├── lib/
│   └── stores/
│       └── terminal.ts           # Terminal state management
└── types/
    └── terminal.ts              # Terminal type definitions
```

### 2.2 Terminal Store Structure

The terminal store manages terminal instances and their states:

```typescript
export class TerminalStore {
  #webcontainer: Promise<WebContainer>;
  #terminals: Array<{ 
    terminal: ITerminal; 
    process: WebContainerProcess 
  }> = [];

  showTerminal: WritableAtom<boolean>;

  constructor(webcontainerPromise: Promise<WebContainer>) {
    this.#webcontainer = webcontainerPromise;
  }
}
```

## 3. Terminal Implementation Details

### 3.1 Terminal Component

The main terminal component (Terminal.tsx) integrates xterm.js with WebContainer:

```typescript
export interface TerminalProps {
  className?: string;
  theme: Theme;
  readonly?: boolean;
  onTerminalReady?: (terminal: XTerm) => void;
  onTerminalResize?: (cols: number, rows: number) => void;
}

export const Terminal = memo(
  forwardRef<TerminalRef, TerminalProps>(({
    className,
    theme,
    readonly,
    onTerminalReady,
    onTerminalResize
  }, ref) => {
    const terminalElementRef = useRef<HTMLDivElement>(null);
    const terminalRef = useRef<XTerm>();

    useEffect(() => {
      const element = terminalElementRef.current!;
      const fitAddon = new FitAddon();
      const webLinksAddon = new WebLinksAddon();

      const terminal = new XTerm({
        cursorBlink: true,
        convertEol: true,
        disableStdin: readonly,
        theme: getTerminalTheme(readonly ? { 
          cursor: '#00000000' 
        } : {}),
        fontSize: 12,
        fontFamily: 'Menlo, courier-new, courier, monospace',
      });

      terminalRef.current = terminal;
      terminal.loadAddon(fitAddon);
      terminal.loadAddon(webLinksAddon);
      terminal.open(element);

      // Handle terminal resizing
      const resizeObserver = new ResizeObserver(() => {
        fitAddon.fit();
        onTerminalResize?.(terminal.cols, terminal.rows);
      });

      resizeObserver.observe(element);
      onTerminalReady?.(terminal);

      return () => {
        resizeObserver.disconnect();
        terminal.dispose();
      };
    }, []);
    
    // ... rest of implementation
  })
);
```

### 3.2 Terminal Theming

Theme implementation (theme.ts):

```typescript
export function getTerminalTheme(overrides?: ITheme): ITheme {
  return {
    cursor: cssVar('--bolt-elements-terminal-cursorColor'),
    cursorAccent: cssVar('--bolt-elements-terminal-cursorColorAccent'),
    foreground: cssVar('--bolt-elements-terminal-textColor'),
    background: cssVar('--bolt-elements-terminal-backgroundColor'),
    selectionBackground: cssVar('--bolt-elements-terminal-selection-backgroundColor'),
    selectionForeground: cssVar('--bolt-elements-terminal-selection-textColor'),
    // ANSI colors
    black: cssVar('--bolt-terminal-color-black'),
    red: cssVar('--bolt-terminal-color-red'),
    green: cssVar('--bolt-terminal-color-green'),
    yellow: cssVar('--bolt-terminal-color-yellow'),
    blue: cssVar('--bolt-terminal-color-blue'),
    magenta: cssVar('--bolt-terminal-color-magenta'),
    cyan: cssVar('--bolt-terminal-color-cyan'),
    white: cssVar('--bolt-terminal-color-white'),
    ...overrides,
  };
}
```

## 4. Process Management

### 4.1 Shell Process Implementation

Process management is handled through WebContainer's shell implementation:

```typescript
export async function newShellProcess(
  webcontainer: WebContainer, 
  terminal: ITerminal
) {
  const args: string[] = [];
  
  // Spawn JSH process with fallback dimensions
  const process = await webcontainer.spawn('/bin/jsh', ['--osc', ...args], {
    terminal: {
      cols: terminal.cols ?? 80,
      rows: terminal.rows ?? 15,
    },
  });

  const input = process.input.getWriter();
  const output = process.output;
  const jshReady = withResolvers<void>();
  let isInteractive = false;

  output.pipeTo(
    new WritableStream({
      write(data) {
        if (!isInteractive) {
          const [, osc] = data.match(/\x1b\]654;([^\x07]+)\x07/) || [];
          if (osc === 'interactive') {
            isInteractive = true;
            jshReady.resolve();
          }
        }
        terminal.write(data);
      },
    })
  );

  terminal.onData((data) => {
    if (isInteractive) {
      input.write(data);
    }
  });

  await jshReady.promise;
  return process;
}
```

### 4.2 Process Management in TerminalStore

The TerminalStore handles process lifecycle:

```typescript
export class TerminalStore {
  async attachTerminal(terminal: ITerminal) {
    try {
      const shellProcess = await newShellProcess(
        await this.#webcontainer, 
        terminal
      );
      this.#terminals.push({ terminal, process: shellProcess });
    } catch (error: any) {
      terminal.write(
        coloredText.red('Failed to spawn shell\n\n') + 
        error.message
      );
      return;
    }
  }

  onTerminalResize(cols: number, rows: number) {
    for (const { process } of this.#terminals) {
      process.resize({ cols, rows });
    }
  }
}
```

## 5. Code Organization and File Layout

Complete file structure for terminal implementation:

```
app/
├── components/
│   └── workbench/
│       └── terminal/
│           ├── Terminal.tsx
│           └── theme.ts
├── lib/
│   ├── stores/
│   │   └── terminal.ts
│   └── utils/
│       ├── shell.ts
│       └── terminal.ts
├── styles/
│   └── components/
│       └── terminal.scss
└── types/
    └── terminal.ts
```

## 6. Practical Exercises

### Exercise 1: Basic Terminal Implementation
Create a simplified terminal that can:
1. Accept user input
2. Display output
3. Handle basic commands
4. Implement command history

### Exercise 2: Process Management
Implement basic process management features:
1. Process spawning
2. Process termination
3. Input/output handling
4. Error handling

## 7. Advanced Topics

### 7.1 Terminal Multiplexing

Implementation of multiple terminal instances:

```typescript
export class TerminalManager {
  private terminals: Map<string, Terminal> = new Map();

  createTerminal(id: string): Terminal {
    const terminal = new Terminal({
      cols: 80,
      rows: 24,
      // ... other options
    });
    this.terminals.set(id, terminal);
    return terminal;
  }

  destroyTerminal(id: string) {
    const terminal = this.terminals.get(id);
    if (terminal) {
      terminal.dispose();
      this.terminals.delete(id);
    }
  }
}
```

### 7.2 Terminal State Persistence

Implementing terminal state persistence:

```typescript
interface TerminalState {
  history: string[];
  cwd: string;
  env: Record<string, string>;
}

class PersistentTerminal {
  private state: TerminalState;

  saveState() {
    localStorage.setItem('terminal_state', JSON.stringify(this.state));
  }

  restoreState() {
    const saved = localStorage.getItem('terminal_state');
    if (saved) {
      this.state = JSON.parse(saved);
      this.applyState();
    }
  }

  private applyState() {
    // Restore terminal state
    this.setWorkingDirectory(this.state.cwd);
    this.setEnvironmentVariables(this.state.env);
    this.restoreHistory(this.state.history);
  }
}
```

### 7.3 Terminal Styling and Customization

Custom terminal styling implementation:

```typescript
const terminalStyles = {
  base: {
    background: '#1E1E1E',
    foreground: '#D4D4D4',
    cursor: '#FFFFFF',
    selection: '#264F78',
  },
  ansi: {
    black: '#000000',
    red: '#CD3131',
    green: '#0DBC79',
    yellow: '#E5E510',
    blue: '#2472C8',
    magenta: '#BC3FBC',
    cyan: '#11A8CD',
    white: '#E5E5E5',
  },
};
```

## 8. Troubleshooting and Best Practices

### 8.1 Common Issues and Solutions

1. Process Hanging
```typescript
function handleHungProcess(process: WebContainerProcess) {
  const timeout = setTimeout(() => {
    if (process.connected) {
      process.kill();
      console.error('Process terminated due to timeout');
    }
  }, 30000);

  process.on('exit', () => {
    clearTimeout(timeout);
  });
}
```

2. Memory Leaks
```typescript
class TerminalManager {
  dispose() {
    // Clean up all terminals
    for (const terminal of this.terminals.values()) {
      terminal.dispose();
    }
    this.terminals.clear();
    
    // Remove event listeners
    this.removeEventListeners();
  }
}
```

### 8.2 Performance Optimization

1. Output Buffering
```typescript
class OutputBuffer {
  private buffer: string[] = [];
  private flushTimeout: number | null = null;

  append(data: string) {
    this.buffer.push(data);
    this.scheduleFlush();
  }

  private scheduleFlush() {
    if (!this.flushTimeout) {
      this.flushTimeout = window.setTimeout(() => {
        this.flush();
      }, 16);
    }
  }

  private flush() {
    const data = this.buffer.join('');
    this.terminal.write(data);
    this.buffer = [];
    this.flushTimeout = null;
  }
}
```

2. Resource Management
```typescript
class ResourceManager {
  private resources: Set<Disposable> = new Set();

  track(resource: Disposable) {
    this.resources.add(resource);
    return {
      dispose: () => {
        resource.dispose();
        this.resources.delete(resource);
      }
    };
  }

  dispose() {
    for (const resource of this.resources) {
      resource.dispose();
    }
    this.resources.clear();
  }
}
```

## Conclusion

This lesson covered the intricate details of terminal and process management in Bolt.new. Key takeaways include:

1. Understanding terminal emulation in the browser
2. Process management within WebContainer constraints
3. Implementing robust I/O handling
4. Managing terminal state and persistence
5. Handling multiple terminal instances
6. Performance optimization techniques
7. Resource management and cleanup

The next lesson will focus on UI/UX Components and Styling, building upon the terminal interface knowledge gained here.
