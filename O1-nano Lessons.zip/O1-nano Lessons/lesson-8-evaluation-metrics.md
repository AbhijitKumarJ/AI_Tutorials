# Lesson 8: Evaluation and Metrics

## Introduction

In this lesson, we will delve into the critical process of evaluating the O1-nano model and understanding the metrics used to measure its performance. Proper evaluation is crucial for assessing the model's capabilities, tracking its progress during training, and comparing it with other models or benchmarks. We'll explore how to generate and solve arithmetic problems for evaluation, implement and interpret various metrics, and discuss the importance of logging and visualizing these metrics. Additionally, we'll cover cross-platform considerations for model serialization and loading, ensuring that our evaluation process is robust and reproducible across different environments.

## Lesson Objectives

By the end of this lesson, you will be able to:

1. Implement a comprehensive evaluation process for the O1-nano model
2. Understand and calculate key performance metrics for language models
3. Design and use a logging system for tracking model performance over time
4. Visualize training progress and model performance using appropriate tools
5. Implement cross-platform compatible methods for model serialization and loading
6. Critically analyze the strengths and limitations of different evaluation approaches

## File Structure

Before we begin, let's review the relevant file structure for this lesson:

```
o1-nano/
│
├── train.py
├── test.py (focus for this lesson)
├── evaluate.py (new file we'll create)
├── README.md
└── o1_model.pth (generated after training)
```

While we'll primarily focus on creating a new `evaluate.py` file, we'll also make modifications to `train.py` and `test.py` to incorporate our evaluation methods.

## 1. Implementing the Evaluation Process

The evaluation process for the O1-nano model involves generating arithmetic problems, using the model to solve these problems, and then assessing the correctness of the model's solutions. Let's start by implementing this process in our new `evaluate.py` file:

```python
import torch
from train import O1Model, vocab, tokenize, detokenize
from test import load_model
import random

def generate_arithmetic_problem():
    operations = ['+', '-', '*', '/']
    op = random.choice(operations)
    
    if op in ['+', '-']:
        a, b = random.randint(1, 100), random.randint(1, 100)
    else:
        a, b = random.randint(1, 10), random.randint(1, 10)
    
    if op == '+':
        result = a + b
        problem = f"Calculate the sum of {a} and {b}"
    elif op == '-':
        result = a - b
        problem = f"Calculate the difference between {a} and {b}"
    elif op == '*':
        result = a * b
        problem = f"Calculate the product of {a} and {b}"
    else:
        if b != 0:
            result = a // b
            problem = f"Calculate the quotient of {a} and {b}"
        else:
            return generate_arithmetic_problem()  # Recursively try again if division by zero
    
    return problem, result

def evaluate_model(model, num_problems=100):
    model.eval()
    correct = 0
    total = 0
    
    with torch.no_grad():
        for _ in range(num_problems):
            problem, true_result = generate_arithmetic_problem()
            input_ids = torch.tensor([tokenize(problem)])
            
            completion_tokens, _, _ = model.generate_completion(input_ids, max_new_tokens=50)
            generated_text = detokenize(completion_tokens)
            
            try:
                # Extract the numerical answer from the generated text
                generated_result = int(generated_text.split()[-1])
                if generated_result == true_result:
                    correct += 1
                total += 1
            except ValueError:
                # If we can't extract a numerical answer, count it as incorrect
                total += 1
    
    accuracy = correct / total if total > 0 else 0
    return accuracy

if __name__ == "__main__":
    model_path = "o1_model.pth"
    model = load_model(model_path)
    accuracy = evaluate_model(model)
    print(f"Model accuracy on arithmetic problems: {accuracy:.2f}")
```

This implementation includes several key components:

1. **Problem Generation**: The `generate_arithmetic_problem` function creates random arithmetic problems of varying difficulty. It ensures that we don't generate division by zero problems.

2. **Model Evaluation**: The `evaluate_model` function generates a specified number of problems, uses the model to solve each problem, and calculates the accuracy of the model's solutions.

3. **Answer Extraction**: We extract the numerical answer from the model's generated text. This assumes that the model outputs its final answer as the last token in its response.

4. **Error Handling**: We include error handling to deal with cases where the model might not output a valid numerical answer.

This evaluation process provides a basic measure of the model's performance on arithmetic problems. However, it's important to note that this is just one aspect of the model's capabilities, and a more comprehensive evaluation would include a wider range of problem types and metrics.

## 2. Implementing and Interpreting Metrics

While accuracy is a useful metric, it doesn't provide a complete picture of the model's performance. Let's expand our evaluation to include additional metrics:

```python
from collections import defaultdict

def evaluate_model_extended(model, num_problems=100):
    model.eval()
    metrics = defaultdict(int)
    operation_metrics = defaultdict(lambda: defaultdict(int))
    
    with torch.no_grad():
        for _ in range(num_problems):
            problem, true_result = generate_arithmetic_problem()
            operation = problem.split()[3]  # Extracts operation type from the problem string
            input_ids = torch.tensor([tokenize(problem)])
            
            completion_tokens, reasoning_tokens, _ = model.generate_completion(input_ids, max_new_tokens=50)
            generated_text = detokenize(completion_tokens)
            reasoning_text = detokenize(reasoning_tokens)
            
            try:
                generated_result = int(generated_text.split()[-1])
                if generated_result == true_result:
                    metrics['correct'] += 1
                    operation_metrics[operation]['correct'] += 1
                else:
                    metrics['incorrect'] += 1
                    operation_metrics[operation]['incorrect'] += 1
                
                metrics['total'] += 1
                operation_metrics[operation]['total'] += 1
                
                # Measure reasoning quality
                if len(reasoning_text.split()) > 5:  # Arbitrary threshold for "good" reasoning
                    metrics['good_reasoning'] += 1
                
                # Measure response time (placeholder - would need actual timing in practice)
                metrics['total_tokens'] += len(completion_tokens) + len(reasoning_tokens)
                
            except ValueError:
                metrics['invalid'] += 1
                operation_metrics[operation]['invalid'] += 1
    
    # Calculate aggregate metrics
    metrics['accuracy'] = metrics['correct'] / metrics['total'] if metrics['total'] > 0 else 0
    metrics['reasoning_rate'] = metrics['good_reasoning'] / metrics['total'] if metrics['total'] > 0 else 0
    metrics['avg_tokens'] = metrics['total_tokens'] / metrics['total'] if metrics['total'] > 0 else 0
    
    for operation in operation_metrics:
        op_total = operation_metrics[operation]['total']
        if op_total > 0:
            operation_metrics[operation]['accuracy'] = operation_metrics[operation]['correct'] / op_total
    
    return metrics, operation_metrics

# Usage
model_path = "o1_model.pth"
model = load_model(model_path)
metrics, operation_metrics = evaluate_model_extended(model)

print("Overall Metrics:")
for metric, value in metrics.items():
    print(f"{metric}: {value:.2f}")

print("\nMetrics by Operation:")
for operation, op_metrics in operation_metrics.items():
    print(f"{operation}:")
    for metric, value in op_metrics.items():
        print(f"  {metric}: {value:.2f}")
```

This extended evaluation implements several additional metrics:

1. **Accuracy by Operation**: We track the model's performance separately for each arithmetic operation, allowing us to identify if the model struggles with particular types of problems.

2. **Reasoning Quality**: We use a simple heuristic (length of reasoning text) to estimate the quality of the model's reasoning. This could be expanded to more sophisticated measures in a real-world scenario.

3. **Response Length**: We track the total number of tokens (both completion and reasoning) generated by the model, which can be used as a proxy for response time and computational efficiency.

4. **Invalid Response Rate**: We track how often the model produces responses that can't be interpreted as valid numerical answers.

Interpreting these metrics allows us to gain a more nuanced understanding of the model's performance:

- **Overall Accuracy**: This gives us a general sense of how well the model performs across all problem types.
- **Operation-Specific Accuracy**: This helps identify if the model is significantly better or worse at certain types of problems, which could inform future training or architectural decisions.
- **Reasoning Rate**: This metric gives us insight into how often the model is producing substantive reasoning steps, which is a key feature of the O1-nano model.
- **Average Tokens**: This metric can help us understand the efficiency of the model. A lower number might indicate more concise responses, while a higher number could suggest more detailed reasoning (or potentially, verbosity).
- **Invalid Rate**: A high invalid rate might indicate that the model is struggling to format its responses correctly, which could be addressed through further training or prompt engineering.

## 3. Logging and Visualizing Training Progress

To track the model's performance over time during training, we need to implement a logging system and visualization tools. Let's modify our `train.py` file to include logging, and create a new function to visualize the results:

```python
# In train.py

import json
from datetime import datetime

def log_metrics(metrics, epoch):
    log_entry = {
        "epoch": epoch,
        "timestamp": datetime.now().isoformat(),
        "metrics": metrics
    }
    
    with open("training_log.jsonl", "a") as f:
        f.write(json.dumps(log_entry) + "\n")

# Modify the training loop to include logging
def train_o1_model(model, optimizer, num_epochs, batch_size):
    # ... (existing code)
    
    for epoch in range(num_epochs):
        # ... (training steps)
        
        if epoch % 10 == 0:
            metrics = evaluate_model(model, batch_size)
            log_metrics(metrics, epoch)
        
    # ... (rest of the function)

# In a new file, visualize.py

import json
import matplotlib.pyplot as plt

def visualize_training_progress():
    epochs = []
    accuracies = []
    reasoning_rates = []
    
    with open("training_log.jsonl", "r") as f:
        for line in f:
            entry = json.loads(line)
            epochs.append(entry["epoch"])
            accuracies.append(entry["metrics"]["accuracy"])
            reasoning_rates.append(entry["metrics"]["reasoning_rate"])
    
    plt.figure(figsize=(12, 6))
    plt.plot(epochs, accuracies, label="Accuracy")
    plt.plot(epochs, reasoning_rates, label="Reasoning Rate")
    plt.xlabel("Epoch")
    plt.ylabel("Metric Value")
    plt.title("O1-nano Training Progress")
    plt.legend()
    plt.grid(True)
    plt.savefig("training_progress.png")
    plt.show()

if __name__ == "__main__":
    visualize_training_progress()
```

This implementation adds several key components:

1. **Metric Logging**: We create a `log_metrics` function that saves each set of metrics as a JSON object in a JSONL (JSON Lines) file. This format is easy to append to and parse later.

2. **Regular Evaluation**: We modify the training loop to evaluate the model and log metrics every 10 epochs. This interval can be adjusted based on the total number of epochs and the desired granularity of logging.

3. **Visualization**: We create a separate script to read the log file and create a plot of accuracy and reasoning rate over time. This visual representation makes it easy to see trends in the model's performance during training.

By implementing this logging and visualization system, we can:

- Track the model's progress over time
- Identify plateaus or drops in performance that might indicate issues with training
- Compare different training runs or model configurations
- Provide clear, visual evidence of the model's improvement to stakeholders

## 4. Cross-Platform Considerations for Model Serialization

Ensuring that our model can be saved and loaded consistently across different platforms is crucial for reproducibility and practical deployment. Let's implement robust serialization and deserialization methods:

```python
# In train.py

import torch
import os

def save_model(model, optimizer, epoch, loss, path):
    checkpoint = {
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "epoch": epoch,
        "loss": loss
    }
    torch.save(checkpoint, path)

def load_model(path, model, optimizer=None):
    checkpoint = torch.load(path, map_location=torch.device('cpu'))
    model.load_state_dict(checkpoint["model_state_dict"])
    if optimizer is not None:
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
    return checkpoint["epoch"], checkpoint["loss"]

# Modify the training loop to include checkpointing
def train_o1_model(model, optimizer, num_epochs, batch_size):
    # ... (existing code)
    
    for epoch in range(num_epochs):
        # ... (training steps)
        
        if epoch % 10 == 0:
            metrics = evaluate_model(model, batch_size)
            log_metrics(metrics, epoch)
            save_model(model, optimizer, epoch, loss, f"o1_model_epoch_{epoch}.pth")
        
    # ... (rest of the function)

# In test.py

def load_model_for_inference(model_path):
    # Infer model parameters from the state dict
    state_dict = torch.load(model_path, map_location=torch.device('cpu'))
    
    d_model = state_dict["embed.weight"].shape[1]
    num_layers = max([int(key.split('.')[1]) for key in state_dict.keys() if key.startswith('transformer_layers.')]) + 1
    nhead = state_dict['transformer_layers.0.self_attn.in_proj_weight'].shape[0] // (3 * d_model)
    
    model = O1Model(vocab_size, d_model, nhead, num_layers)
    model.load_state_dict(state_dict)
    model.eval()
    return model
```

This implementation addresses several important considerations:

1. **Comprehensive Checkpointing**: We save not just the model parameters, but also the optimizer state, current epoch, and loss. This allows for resuming training from a checkpoint if needed.

2. **Regular Saving**: We save model checkpoints every 10 epochs, allowing us to recover from unexpected interruptions and analyze the model at different stages of training.

3. **Device-Agnostic Loading**: We use `map_location=torch.device('cpu')` when loading the model, ensuring that it can be loaded on any device, regardless of where it was trained.

4. **Parameter Inference**: In the `load_model_for_inference` function, we infer the model's architecture parameters from the saved state dictionary. This allows us to load the model without needing to specify its exact configuration, making it more robust to changes in the model architecture.

5. **Evaluation Mode**: We explicitly set the model to evaluation mode after loading for inference, ensuring that it behaves correctly (e.g., dropout layers are disabled).

These methods ensure that our model can be reliably saved, loaded, and used across different platforms and environments.

By implementing these cross-platform serialization methods, we ensure that:

- The model can be easily shared and reproduced across different systems.
- Training can be resumed from checkpoints if interrupted.
- The model can be deployed for inference on various platforms without needing to specify its exact architecture.
- We have a robust system for versioning and comparing different stages of model training.

## Conclusion

In this lesson, we've explored the crucial aspects of evaluating and tracking the performance of the O1-nano model. We've implemented a comprehensive evaluation process that goes beyond simple accuracy, including metrics for reasoning quality, operation-specific performance, and response efficiency. We've also developed a system for logging these metrics during training and visualizing the model's progress over time.

Furthermore, we've addressed the important consideration of cross-platform compatibility in model serialization and deserialization. This ensures that our model can be reliably saved, shared, and loaded across different environments, which is crucial for both research reproducibility and practical deployment.

By mastering these evaluation and metric tracking techniques, you'll be better equipped to understand your model's strengths and weaknesses, make informed decisions about model architecture and training strategies, and communicate your model's performance to stakeholders.

## Exercises

1. Implement a more sophisticated measure of reasoning quality. Instead of just using the length of the reasoning text, try to assess the logical coherence of the steps. How might you approach this problem?

2. Extend the evaluation to include more complex mathematical problems beyond simple arithmetic. How would you generate these problems and assess the model's performance on them?

3. Create a confusion matrix for the arithmetic operations. This would show not just overall accuracy, but what kinds of mistakes the model tends to make (e.g., confusing addition and multiplication).

4. Implement a system for comparing two different versions of the model. This should load two model checkpoints and run a comparative evaluation, highlighting areas where one model outperforms the other.

5. Extend the visualization script to create more detailed plots. For example, you could create separate plots for each arithmetic operation, or create a heatmap showing the model's performance across different number ranges.

6. Research and implement one or more standard NLP evaluation metrics that might be applicable to this task, such as BLEU score for assessing the quality of generated explanations.

By completing these exercises, you'll gain hands-on experience with advanced evaluation techniques and deepen your understanding of how to assess and improve complex language models like O1-nano.

