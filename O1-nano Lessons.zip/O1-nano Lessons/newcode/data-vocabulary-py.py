from typing import Dict, List, Tuple

# Define vocabulary
vocab: Dict[str, int] = {
    '<pad>': 0, '<sos>': 1, '<eos>': 2, 'Step:': 3, '+': 4, '-': 5, '*': 6, '/': 7, '=': 8,
    '0': 9, '1': 10, '2': 11, '3': 12, '4': 13, '5': 14, '6': 15, '7': 16, '8': 17, '9': 18,
    'if': 19, 'then': 20, 'else': 21, 'greater': 22, 'less': 23, 'equal': 24,
    'Calculate': 25, 'the': 26, 'sum': 27, 'of': 28, 'and': 29,
    'difference': 30, 'between': 31, 'product': 32, 'quotient': 33,
    'First,': 34, 'Next,': 35, 'Finally,': 36, 'result': 37, 'is': 38,
    '<subtask>': 39
}

inv_vocab: Dict[int, str] = {v: k for k, v in vocab.items()}

def tokenize(text: str) -> List[int]:
    """
    Convert a string of text into a list of token indices.
    
    Args:
        text (str): The input text to tokenize.
    
    Returns:
        List[int]: A list of token indices.
    """
    return [vocab.get(token, vocab['<pad>']) for token in text.strip().split()]

def detokenize(indices: List[int]) -> str:
    """
    Convert a list of token indices back into a string of text.
    
    Args:
        indices (List[int]): A list of token indices.
    
    Returns:
        str: The detokenized text.
    """
    return ' '.join([inv_vocab.get(idx, ' ') for idx in indices])

def load_vocabulary() -> Tuple[Dict[str, int], int]:
    """
    Load the vocabulary and return it along with its size.
    
    Returns:
        Tuple[Dict[str, int], int]: A tuple containing the vocabulary dictionary and its size.
    """
    return vocab, len(vocab)
