import torch
from typing import List
from data.vocabulary import detokenize

def compute_reward(state: torch.Tensor, target_result: int) -> torch.Tensor:
    """
    Compute the reward for a given state and target result.
    
    Args:
        state (torch.Tensor): The current state (token sequence).
        target_result (int): The expected result of the arithmetic operation.
    
    Returns:
        torch.Tensor: The computed reward.
    """
    generated_tokens = state[:, -1].cpu().numpy()
    rewards = []
    for tokens in generated_tokens:
        try:
            generated_text = detokenize(tokens)
            if "result is" in generated_text:
                result_str = generated_text.split("result is")[-1].strip()
                result = int(result_str) if result_str.isdigit() else float(result_str)
                if abs(result - target_result) < 1e-6:  # Allow for small floating-point differences
                    rewards.append(1.0)
                elif abs(result - target_result) < 5:  # Close answer
                    rewards.append(0.5)
                elif abs(result - target_result) < 10:  # Somewhat close answer
                    rewards.append(0.2)
                else:
                    rewards.append(-0.2)
            else:
                rewards.append(0.0)  # Neutral reward for incomplete answers
        except:
            rewards.append(-0.5)  # Penalize malformed outputs
    return torch.tensor(rewards)

def set_seed(seed: int):
    """
    Set the random seed for reproducibility.
    
    Args:
        seed (int): The seed value to use.
    """
    import random
    import numpy as np
    import torch
    
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

def count_parameters(model: torch.nn.Module) -> int:
    """
    Count the number of trainable parameters in a PyTorch model.
    
    Args:
        model (torch.nn.Module): The PyTorch model to analyze.
    
    Returns:
        int: The number of trainable parameters.
    """
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def generate_subtasks(task: str) -> List[str]:
    """
    Generate subtasks for a given arithmetic task.
    
    Args:
        task (str): The main arithmetic task.
    
    Returns:
        List[str]: A list of subtasks.
    """
    words = task.split()
    operation = words[3]  # "sum", "difference", "product", or "quotient"
    a, b = map(int, words[-3::2])
    
    subtasks = [
        f"Identify the numbers: {a} and {b}",
        f"Recall the definition of {operation}",
    ]
    
    if operation == "sum":
        subtasks.append(f"Add {a} and {b}")
    elif operation == "difference":
        subtasks.append(f"Subtract {b} from {a}")
    elif operation == "product":
        subtasks.append(f"Multiply {a} by {b}")
    elif operation == "quotient":
        subtasks.append(f"Divide {a} by {b}")
    
    subtasks.append("Format the final answer")
    
    return subtasks

def format_time(seconds: float) -> str:
    """
    Format a time duration in seconds to a human-readable string.
    
    Args:
        seconds (float): Time duration in seconds.
    
    Returns:
        str: Formatted time string.
    """
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"

def save_checkpoint(model: torch.nn.Module, optimizer: torch.optim.Optimizer, epoch: int, path: str):
    """
    Save a checkpoint of the model and optimizer state.
    
    Args:
        model (torch.nn.Module): The model to save.
        optimizer (torch.optim.Optimizer): The optimizer to save.
        epoch (int): The current epoch number.
        path (str): The path to save the checkpoint.
    """
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
    }, path)

def load_checkpoint(model: torch.nn.Module, optimizer: torch.optim.Optimizer, path: str) -> int:
    """
    Load a checkpoint of the model and optimizer state.
    
    Args:
        model (torch.nn.Module): The model to load into.
        optimizer (torch.optim.Optimizer): The optimizer to load into.
        path (str): The path to load the checkpoint from.
    
    Returns:
        int: The epoch number of the loaded checkpoint.
    """
    checkpoint = torch.load(path)
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    return checkpoint['epoch']
