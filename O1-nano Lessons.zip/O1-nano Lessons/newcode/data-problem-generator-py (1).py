import random
from typing import Tuple

def generate_arithmetic_problem() -> Tuple[str, int]:
    """
    Generate a random arithmetic problem and its result.
    
    Returns:
        Tuple[str, int]: A tuple containing the problem statement and the result.
    """
    operations = ['+', '-', '*', '/']
    op = random.choice(operations)
    
    while True:
        if op in ['+', '-']:
            a, b = random.randint(1, 100), random.randint(1, 100)
        else:
            a, b = random.randint(1, 10), random.randint(1, 10)
        
        if op == '+':
            result = a + b
            problem = f"Calculate the sum of {a} and {b}"
        elif op == '-':
            result = a - b
            problem = f"Calculate the difference between {a} and {b}"
        elif op == '*':
            result = a * b
            problem = f"Calculate the product of {a} and {b}"
        else:
            if b != 0:  # Avoid division by zero
                result = a // b
                problem = f"Calculate the quotient of {a} and {b}"
            else:
                continue  # Try again if b is zero
        
        return problem, result

def generate_reasoning_chain(problem: str, result: int) -> str:
    """
    Generate a reasoning chain for solving the given arithmetic problem.
    
    Args:
        problem (str): The arithmetic problem statement.
        result (int): The correct result of the problem.
    
    Returns:
        str: A string containing the reasoning chain for solving the problem.
    """
    words = problem.split()
    operation = words[3]  # "sum", "difference", "product", or "quotient"
    
    if operation == "sum":
        a, b = map(int, words[-3::2])
        chain = f"Step: First, we identify the numbers: {a} and {b}. "
        chain += f"Next, we add these numbers: {a} + {b}. "
        chain += f"Finally, we get the result: The sum is {result}."
    elif operation == "difference":
        a, b = map(int, words[-3::2])
        chain = f"Step: First, we identify the numbers: {a} and {b}. "
        chain += f"Next, we subtract the second number from the first: {a} - {b}. "
        chain += f"Finally, we get the result: The difference is {result}."
    elif operation == "product":
        a, b = map(int, words[-3::2])
        chain = f"Step: First, we identify the numbers: {a} and {b}. "
        chain += f"Next, we multiply these numbers: {a} * {b}. "
        chain += f"Finally, we get the result: The product is {result}."
    else:  # quotient
        a, b = map(int, words[-3::2])
        chain = f"Step: First, we identify the numbers: {a} and {b}. "
        chain += f"Next, we divide the first number by the second: {a} / {b}. "
        chain += f"Finally, we get the result: The quotient is {result}."
    
    return chain

def generate_problem_and_reasoning() -> Tuple[str, int, str]:
    """
    Generate an arithmetic problem, its result, and a reasoning chain.
    
    Returns:
        Tuple[str, int, str]: A tuple containing the problem statement, the result, and the reasoning chain.
    """
    problem, result = generate_arithmetic_problem()
    reasoning_chain = generate_reasoning_chain(problem, result)
    return problem, result, reasoning_chain
