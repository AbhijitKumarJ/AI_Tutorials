import torch
import torch.optim as optim
from typing import Dict, Any
from tqdm import tqdm

from core.model import O1Model
from data.problem_generator import generate_problem_and_reasoning
from data.vocabulary import tokenize
from training.ppo import PPO
from utils.helpers import compute_reward
from evaluation.evaluator import Evaluator

class Trainer:
    def __init__(self, model: O1Model, config: Dict[str, Any]):
        self.model = model
        self.config = config
        self.optimizer = optim.Adam(model.parameters(), lr=config['learning_rate'])
        self.ppo = PPO(model, self.optimizer, **config['ppo_params'])
        self.evaluator = Evaluator(model, config)

    def train(self):
        """
        Main training loop for the O1Model.
        """
        for epoch in tqdm(range(self.config['num_epochs']), desc="Training"):
            # Generate a batch of arithmetic problems
            states, actions, rewards, old_log_probs, values = self.collect_trajectories(self.config['batch_size'])
            
            # Supervised learning step
            sl_loss = self.supervised_finetuning_loss(states, actions)
            self.optimizer.zero_grad()
            sl_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
        
            # Reinforcement learning step
            self.ppo.update(states, actions, old_log_probs, rewards, values)
        
            # Evaluation and logging
            if epoch % self.config['eval_interval'] == 0:
                metrics = self.evaluator.evaluate(self.config['eval_samples'])
                self.log_metrics(metrics, epoch)
            
            # Dynamic curriculum learning
            if epoch % self.config['curriculum_interval'] == 0:
                self.adjust_problem_difficulty(epoch)

        # Save the final model
        torch.save(self.model.state_dict(), self.config['model_save_path'])

    def collect_trajectories(self, batch_size: int):
        """
        Collect trajectories for training.
        
        Args:
            batch_size (int): Number of trajectories to collect.
        
        Returns:
            Tuple containing states, actions, rewards, log probabilities, and values.
        """
        states = []
        actions = []
        rewards = []
        log_probs = []
        values = []

        for _ in range(batch_size):
            problem, result, _ = generate_problem_and_reasoning()
            input_ids = torch.tensor([tokenize(problem)])
            
            completion_tokens, reasoning_tokens, _ = self.model.generate_completion(input_ids, max_new_tokens=50)
            
            state = torch.cat([input_ids, torch.tensor([completion_tokens])], dim=1)
            action = torch.tensor(completion_tokens)
            
            with torch.no_grad():
                _, value = self.model(state, generate_reasoning=False)
            
            reward = compute_reward(state, result)
            
            states.append(state)
            actions.append(action)
            rewards.append(reward)
            log_probs.append(self.model.sample_token(self.model(state)[0][:, -1, :]).log_prob(action[-1]))
            values.append(value[:, -1])

        return (torch.cat(states, dim=0), torch.stack(actions), 
                torch.cat(rewards), torch.cat(log_probs), torch.cat(values))

    def supervised_finetuning_loss(self, states: torch.Tensor, actions: torch.Tensor) -> torch.Tensor:
        """
        Compute the supervised finetuning loss.
        
        Args:
            states (torch.Tensor): Input states.
            actions (torch.Tensor): Target actions.
        
        Returns:
            torch.Tensor: The computed loss.
        """
        logits, _ = self.model(states, generate_reasoning=False)
        return torch.nn.functional.cross_entropy(logits.view(-1, logits.size(-1)), actions.view(-1))

    def log_metrics(self, metrics: Dict[str, float], epoch: int):
        """
        Log training metrics.
        
        Args:
            metrics (Dict[str, float]): Dictionary of metric names and values.
            epoch (int): Current training epoch.
        """
        print(f"Epoch {epoch} Metrics:")
        for name, value in metrics.items():
            print(f"  {name}: {value:.4f}")

    def adjust_problem_difficulty(self, epoch: int):
        """
        Adjust the difficulty of generated problems based on training progress.
        
        Args:
            epoch (int): Current training epoch.
        """
        # This is a placeholder implementation. You might want to implement a more sophisticated
        # difficulty adjustment based on model performance and training progress.
        if epoch < self.config['curriculum_thresholds'][0]:
            self.config['problem_difficulty'] = 'easy'
        elif epoch < self.config['curriculum_thresholds'][1]:
            self.config['problem_difficulty'] = 'medium'
        else:
            self.config['problem_difficulty'] = 'hard'
