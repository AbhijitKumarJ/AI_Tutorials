import random
from typing import Tuple

def generate_arithmetic_problem() -> Tuple[str, int]:
    """
    Generate a random arithmetic problem and its result.
    
    Returns:
        Tuple[str