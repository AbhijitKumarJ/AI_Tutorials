import argparse
import torch
from config.config import Config
from core.model import O1Model
from data.vocabulary import load_vocabulary
from training.trainer import Trainer
from evaluation.evaluator import Evaluator

def parse_arguments():
    parser = argparse.ArgumentParser(description="Train and evaluate the O1-nano model")
    parser.add_argument("--mode", choices=["train", "evaluate"], default="train", help="Mode of operation")
    parser.add_argument("--config", default="config/config.py", help="Path to the configuration file")
    parser.add_argument("--model_path", help="Path to a saved model for evaluation")
    return parser.parse_args()

def main():
    args = parse_arguments()
    config = Config(args.config)

    # Load vocabulary
    vocab, vocab_size = load_vocabulary()

    # Initialize model
    model = O1Model(vocab_size, config.d_model, config.nhead, config.num_layers)

    if args.mode == "train":
        trainer = Trainer(model, config)
        trainer.train()
    elif args.mode == "evaluate":
        if args.model_path:
            model.load_state_dict(torch.load(args.model_path))
        else:
            raise ValueError("Model path must be provided for evaluation mode")
        
        evaluator = Evaluator(model, config)
        metrics = evaluator.evaluate()
        print(f"Evaluation metrics: {metrics}")

if __name__ == "__main__":
    main()
