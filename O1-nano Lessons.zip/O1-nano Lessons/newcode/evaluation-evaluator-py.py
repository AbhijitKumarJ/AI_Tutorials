import torch
from typing import Dict, Any
from tqdm import tqdm

from core.model import O1Model
from data.problem_generator import generate_problem_and_reasoning
from data.vocabulary import tokenize
from utils.helpers import compute_reward

class Evaluator:
    def __init__(self, model: O1Model, config: Dict[str, Any]):
        self.model = model
        self.config = config

    def evaluate(self, num_samples: int) -> Dict[str, float]:
        """
        Evaluate the model on a set of generated problems.
        
        Args:
            num_samples (int): Number of samples to evaluate.
        
        Returns:
            Dict[str, float]: A dictionary of evaluation metrics.
        """
        self.model.eval()
        total_reward = 0
        correct_predictions = 0
        valid_samples = 0

        with torch.no_grad():
            for _ in tqdm(range(