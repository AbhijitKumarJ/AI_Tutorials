from typing import Dict, Any

class Config:
    def __init__(self):
        self.model_params: Dict[str, Any] = {
            "vocab_size": 40,  # This should match the size of your vocabulary
            "d_model": 128,
            "nhead": 8,
            "num_layers": 4,
            "dropout": 0.1,
        }
        
        self.training_params: Dict[str, Any] = {
            "num_epochs": 500,
            "batch_size": 64,
            "learning_rate": 5e-4,
            "max_grad_norm": 1.0,
            "warmup_steps": 1000,
            "eval_interval": 10,
            "curriculum_interval": 50,
            "curriculum_thresholds": [100, 300],
        }
        
        self.ppo_params: Dict[str, Any] = {
            "clip_epsilon": 0.2,
            "value_coef": 0.5,
            "entropy_coef": 0.01,
            "gamma": 0.99,
            "lambda_": 0.95,
            "ppo_epochs": 5,
        }
        
        self.data_params: Dict[str, Any] = {
            "max_problem_length": 50,
            "max_reasoning_length": 100,
            "initial_difficulty": "easy",
        }
        
        self.eval_params: Dict[str, Any] = {
            "eval_samples": 100,
            "test_samples": 1000,
        }
        
        self.misc_params: Dict[str, Any] = {
            "seed": 42,
            "device": "cuda" if torch.cuda.is_available() else "cpu",
            "model_save_path": "o1_model.pth",
            "log_dir": "logs",
        }

    def get_config(self) -> Dict[str, Any]:
        """
        Get the full configuration as a dictionary.
        
        Returns:
            Dict[str, Any]: The complete configuration dictionary.
        """
        return {
            "model_params": self.model_params,
            "training_params": self.training_params,
            "ppo_params": self.ppo_params,
            "data_params": self.data_params,
            "eval_params": self.eval_params,
            "misc_params": self.misc_params,
        }

    def update_config(self, updates: Dict[str, Any]):
        """
        Update the configuration with new values.
        
        Args:
            updates (Dict[str, Any]): A dictionary of configuration updates.
        """
        for key, value in updates.items():
            if hasattr(self, key):
                getattr(self, key).update(value)
            else:
                setattr(self, key, value)

    def __getitem__(self, key: str