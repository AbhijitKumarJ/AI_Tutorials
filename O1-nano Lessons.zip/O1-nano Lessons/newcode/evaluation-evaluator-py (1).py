import torch
from typing import Dict, Any, List
from tqdm import tqdm

from core.model import O1Model
from data.problem_generator import generate_problem_and_reasoning
from data.vocabulary import tokenize, detokenize
from utils.helpers import compute_reward

class Evaluator:
    def __init__(self, model: O1Model, config: Dict[str, Any]):
        self.model = model
        self.config = config

    def evaluate(self, num_samples: int) -> Dict[str, float]:
        """
        Evaluate the model on a set of generated problems.
        
        Args:
            num_samples (int): Number of samples to evaluate.
        
        Returns:
            Dict[str, float]: A dictionary of evaluation metrics.
        """
        self.model.eval()
        total_reward = 0
        correct_predictions = 0
        valid_samples = 0
        reasoning_scores = []

        with torch.no_grad():
            for _ in tqdm(range(num_samples), desc="Evaluating"):
                try:
                    problem, result, expected_reasoning = generate_problem_and_reasoning()
                    input_ids = torch.tensor([tokenize(problem)])
                    
                    completion_tokens, reasoning_tokens, subtasks = self.model.generate_completion(input_ids, max_new_tokens=50)
                    
                    if completion_tokens:
                        generated_answer = self.extract_answer(completion_tokens)
                        reward = compute_reward(torch.tensor([completion_tokens]), result)
                        total_reward += reward
                        
                        if generated_answer == result:
                            correct_predictions += 1
                        
                        reasoning_score = self.evaluate_reasoning(reasoning_tokens, expected_reasoning)
                        reasoning_scores.append(reasoning_score)
                        
                        valid_samples += 1
                    else:
                        print(f"Warning: Empty output for problem: {problem}")
                except Exception as e:
                    print(f"Error during evaluation: {e}")

        avg_reward = total_reward / valid_samples if valid_samples > 0 else 0
        accuracy = correct_predictions / valid_samples if valid_samples > 0 else 0
        avg_reasoning_score = sum(reasoning_scores) / len(reasoning_scores) if reasoning_scores else 0

        return {
            "average_reward": avg_reward,
            "accuracy": accuracy,
            "valid_samples": valid_samples,
            "average_reasoning_score": avg_reasoning_score
        }

    def extract_answer(self, completion_tokens: List[int]) -> int:
        """
        Extract the numerical answer from the completion tokens.
        
        Args:
            completion_tokens (List[int]): List of token indices representing the model's output.
        
        Returns:
            int: The extracted numerical answer.
        """
        completion_text = detokenize(completion_tokens)
        try:
            # Assume the answer is the last number in the completion
            numbers = [int(word) for word in completion_text.split() if word.isdigit()]
            return numbers[-1] if numbers else None
        except:
            return None

    def evaluate_reasoning(self, reasoning_tokens: List[int], expected_reasoning: str) -> float:
        """
        Evaluate the quality of the model's reasoning compared to the expected reasoning.
        
        Args:
            reasoning_tokens (List[int]): List of token indices representing the model's reasoning.
            expected_reasoning (str): The expected reasoning string.
        
        Returns:
            float: A score between 0 and 1 indicating the quality of the reasoning.
        """
        generated_reasoning = detokenize(reasoning_tokens)
        
        # This is a simple implementation. You might want to use more sophisticated
        # methods like semantic similarity or fuzzy matching for better evaluation.
        expected_steps = set(expected_reasoning.lower().split())
        generated_steps = set(generated_reasoning.lower().split())
        
        common_steps = expected_steps.intersection(generated_steps)
        
        return len(common_steps) / len(expected_steps)

    def analyze_errors(self, num_samples: int) -> Dict[str, Any]:
        """
        Analyze the types of errors made by the model.
        
        Args:
            num_samples (int): Number of samples to analyze.
        
        Returns:
            Dict[str, Any]: A dictionary containing error analysis metrics.
        """
        error_types = {
            "arithmetic": 0,
            "reasoning": 0,
            "incomplete": 0,
            "other": 0
        }
        
        with torch.no_grad():
            for _ in tqdm(range(num_samples), desc="Analyzing errors"):
                problem, result, expected_reasoning = generate_problem_and_reasoning()
                input_ids = torch.tensor([tokenize(problem)])
                
                completion_tokens, reasoning_tokens, _ = self.model.generate_completion(input_ids, max_new_tokens=50)
                
                if not completion_tokens:
                    error_types["incomplete"] += 1
                    continue
                
                generated_answer = self.extract_answer(completion_tokens)
                
                if generated_answer != result:
                    if self.is_arithmetic_error(problem, generated_answer, result):
                        error_types["arithmetic"] += 1
                    elif self.evaluate_reasoning(reasoning_tokens, expected_reasoning) < 0.5:
                        error_types["reasoning"] += 1
                    else:
                        error_types["other"] += 1
        
        total_errors = sum(error_types.values())
        error_percentages = {k: v / total_errors * 100 for k, v in error_types.items()}
        
        return {
            "error_counts": error_types,
            "error_percentages": error_percentages
        }

    def is_arithmetic_error(self, problem: str, generated_answer: int, correct_answer: int) -> bool:
        """
        Determine if the error is due to incorrect arithmetic.
        
        Args:
            problem (str): The original problem statement.
            generated_answer (int): The answer generated by the model.
            correct_answer (int): The correct answer.
        
        Returns:
            bool: True if the error is arithmetic, False otherwise.
        """
        # This is a simple check. You might want to implement more sophisticated logic.
        operation = problem.split()[3]  # "sum", "difference", "product", or "quotient"
        numbers = [int(word) for word in problem.split() if word.isdigit()]
        
        if operation == "sum" and generated_answer == sum(numbers):
            return True
        elif operation == "difference" and generated_answer == abs(numbers[0] - numbers[1]):
            return True
        elif operation == "product" and generated_answer == numbers[0] * numbers[1]:
            return True
        elif operation == "quotient" and numbers[1] != 0 and generated_answer == numbers[0] // numbers[1]:
            return True
        
        return False
