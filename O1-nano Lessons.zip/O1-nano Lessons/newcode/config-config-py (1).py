import torch
import json
from typing import Dict, Any

class Config:
    def __init__(self):
        self.model_params: Dict[str, Any] = {
            "vocab_size": 40,  # This should match the size of your vocabulary
            "d_model": 128,
            "nhead": 8,
            "num_layers": 4,
            "dropout": 0.1,
        }
        
        self.training_params: Dict[str, Any] = {
            "num_epochs": 500,
            "batch_size": 64,
            "learning_rate": 5e-4,
            "max_grad_norm": 1.0,
            "warmup_steps": 1000,
            "eval_interval": 10,
            "curriculum_interval": 50,
            "curriculum_thresholds": [100, 300],
        }
        
        self.ppo_params: Dict[str, Any] = {
            "clip_epsilon": 0.2,
            "value_coef": 0.5,
            "entropy_coef": 0.01,
            "gamma": 0.99,
            "lambda_": 0.95,
            "ppo_epochs": 5,
        }
        
        self.data_params: Dict[str, Any] = {
            "max_problem_length": 50,
            "max_reasoning_length": 100,
            "initial_difficulty": "easy",
        }
        
        self.eval_params: Dict[str, Any] = {
            "eval_samples": 100,
            "test_samples": 1000,
        }
        
        self.misc_params: Dict[str, Any] = {
            "seed": 42,
            "device": "cuda" if torch.cuda.is_available() else "cpu",
            "model_save_path": "o1_model.pth",
            "log_dir": "logs",
        }

    def get_config(self) -> Dict[str, Any]:
        """
        Get the full configuration as a dictionary.
        
        Returns:
            Dict[str, Any]: The complete configuration dictionary.
        """
        return {
            "model_params": self.model_params,
            "training_params": self.training_params,
            "ppo_params": self.ppo_params,
            "data_params": self.data_params,
            "eval_params": self.eval_params,
            "misc_params": self.misc_params,
        }

    def update_config(self, updates: Dict[str, Any]):
        """
        Update the configuration with new values.
        
        Args:
            updates (Dict[str, Any]): A dictionary of configuration updates.
        """
        for key, value in updates.items():
            if hasattr(self, key):
                getattr(self, key).update(value)
            else:
                setattr(self, key, value)

    def __getitem__(self, key: str) -> Any:
        """
        Allow dictionary-style access to configuration parameters.
        
        Args:
            key (str): The configuration key to access.
        
        Returns:
            Any: The value associated with the given key.
        
        Raises:
            KeyError: If the key is not found in any configuration section.
        """
        for section in [self.model_params, self.training_params, self.ppo_params, 
                        self.data_params, self.eval_params, self.misc_params]:
            if key in section:
                return section[key]
        raise KeyError(f"Configuration key '{key}' not found")

    def __setitem__(self, key: str, value: Any):
        """
        Allow dictionary-style setting of configuration parameters.
        
        Args:
            key (str): The configuration key to set.
            value (Any): The value to set for the given key.
        
        Raises:
            KeyError: If the key is not found in any configuration section.
        """
        for section in [self.model_params, self.training_params, self.ppo_params, 
                        self.data_params, self.eval_params, self.misc_params]:
            if key in section:
                section[key] = value
                return
        raise KeyError(f"Configuration key '{key}' not found")

    def save_config(self, filepath: str):
        """
        Save the configuration to a JSON file.
        
        Args:
            filepath (str): The path to save the configuration file.
        """
        with open(filepath, 'w') as f:
            json.dump(self.get_config(), f, indent=4)

    def load_config(self, filepath: str):
        """
        Load the configuration from a JSON file.
        
        Args:
            filepath (str): The path to load the configuration file from.
        """
        with open(filepath, 'r') as f:
            config_dict = json.load(f)
        self.update_config(config_dict)

    def print_config(self):
        """
        Print the configuration in a readable format.
        """
        print("O1-nano Configuration:")
        for section_name, section in self.get_config().items():
            print(f"\n{section_name.upper()}:")
            for key, value in section.items():
                print(f"  {key}: {value}")

    def get_model_args(self) -> Dict[str, Any]:
        """
        Get the arguments needed to initialize the O1Model.
        
        Returns:
            Dict[str, Any]: A dictionary of model initialization arguments.
        """
        return {
            "vocab_size": self.model_params["vocab_size"],
            "d_model": self.model_params["d_model"],
            "nhead": self.model_params["nhead"],
            "num_layers": self.model_params["num_layers"],
        }

    def get_optimizer_args(self) -> Dict[str, Any]:
        """
        Get the arguments needed to initialize the optimizer.
        
        Returns:
            Dict[str, Any]: A dictionary of optimizer initialization arguments.
        """
        return {
            "lr": self.training_params["learning_rate"],
        }

    def get_ppo_args(self) -> Dict[str, Any]:
        """
        Get the arguments needed to initialize the PPO algorithm.
        
        Returns:
            Dict[str, Any]: A dictionary of PPO initialization arguments.
        """
        return self.ppo_params

# Example usage:
if __name__ == "__main__":
    config = Config()
    print("Default configuration:")
    config.print_config()

    print("\nUpdating batch size:")
    config['batch_size'] = 128
    print(f"New batch size: {config['batch_size']}")

    print("\nSaving configuration to 'config.json'")
    config.save_config('config.json')

    print("\nLoading configuration from 'config.json'")
    new_config = Config()
    new_config.load_config('config.json')
    new_config.print_config()
