# Lesson 4: The O1Model Architecture

## 1. Detailed Walkthrough of the O1Model Class

The O1Model class is the core of the O1-nano project, implementing the main architecture of the language model. This class integrates various components we've discussed in previous lessons to create a powerful model capable of processing input sequences and generating outputs with reasoning capabilities. Let's break down the class and examine its components in detail.

### 1.1 Class Definition and Initialization

The O1Model class is defined as follows:

```python
class O1Model(nn.Module):
    def __init__(self, vocab_size, d_model, nhead, num_layers, is_mini=False):
        super(O1Model, self).__init__()
        self.vocab_size = vocab_size
        self.d_model = d_model
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_encoder = PositionalEncoding(d_model)
        self.transformer_layers = nn.ModuleList([TransformerBlock(d_model, nhead) for _ in range(num_layers)])
        self.completion_decoder = nn.Linear(d_model, vocab_size)
        self.reasoning_decoder = nn.Linear(d_model, vocab_size)
        self.value_head = nn.Linear(d_model, 1)
        self.subtask_head = nn.Linear(d_model, 1)
        self.is_mini = is_mini
        self.max_reasoning_tokens = 1000
```

Let's examine each component:

1. **Embedding Layer**: `self.embed = nn.Embedding(vocab_size, d_model)`
   - This layer converts input token IDs into dense vector representations.
   - `vocab_size` is the number of unique tokens in the vocabulary.
   - `d_model` is the dimensionality of the embedding space.

2. **Positional Encoding**: `self.pos_encoder = PositionalEncoding(d_model)`
   - This component adds information about the position of tokens in the sequence.
   - It's crucial for the model to understand the order of tokens, as the self-attention mechanism itself is permutation-invariant.

3. **Transformer Layers**: `self.transformer_layers = nn.ModuleList([TransformerBlock(d_model, nhead) for _ in range(num_layers)])`
   - This creates a stack of transformer blocks, each containing self-attention and feedforward layers.
   - `num_layers` determines the depth of the model.
   - `nhead` is the number of attention heads in each transformer block.

4. **Decoders**: 
   - `self.completion_decoder = nn.Linear(d_model, vocab_size)`
   - `self.reasoning_decoder = nn.Linear(d_model, vocab_size)`
   - These linear layers convert the transformer's output back into the vocabulary space.
   - The completion decoder is used for generating the final output, while the reasoning decoder is used for generating internal reasoning steps.

5. **Value Head**: `self.value_head = nn.Linear(d_model, 1)`
   - This component is used in reinforcement learning to estimate the value of the current state.

6. **Subtask Head**: `self.subtask_head = nn.Linear(d_model, 1)`
   - This is used to determine when to generate subtasks during the reasoning process.

7. **Other Attributes**:
   - `self.is_mini`: A flag to indicate if this is the "mini" version of the model.
   - `self.max_reasoning_tokens`: Limits the number of reasoning tokens to prevent excessive computation.

### 1.2 Embedding Layer and Positional Encoding

The embedding layer and positional encoding work together to create meaningful input representations for the transformer layers.

#### 1.2.1 Implementation of Embedding Layer

The embedding layer is a simple lookup table that converts token IDs to dense vectors:

```python
self.embed = nn.Embedding(vocab_size, d_model)
```

When an input sequence of token IDs is passed through this layer, each ID is replaced by its corresponding vector representation.

#### 1.2.2 Implementation of PositionalEncoding Class

The PositionalEncoding class is defined as follows:

```python
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        return x + self.pe[:, :x.size(1)]
```

This class creates sinusoidal position encodings, which are added to the input embeddings. The key points are:

- It generates a matrix of shape (max_len, d_model) where each row corresponds to a position and each column to a dimension.
- The encoding uses sine and cosine functions of different frequencies for different dimensions.
- During the forward pass, it adds these encodings to the input, providing positional information.

### 1.3 Transformer Layers

The transformer layers are the heart of the O1Model. They process the input sequence and capture complex patterns and relationships.

```python
self.transformer_layers = nn.ModuleList([TransformerBlock(d_model, nhead) for _ in range(num_layers)])
```

Each TransformerBlock, as we discussed in the previous lesson, contains:
- Multi-head self-attention mechanism
- Feedforward neural network
- Layer normalization and residual connections

The use of `nn.ModuleList` allows for an arbitrary number of layers to be stacked, controlled by the `num_layers` parameter.

### 1.4 Completion and Reasoning Decoders

The O1Model uses two separate decoders:

1. Completion Decoder: `self.completion_decoder = nn.Linear(d_model, vocab_size)`
   - This decoder is used to generate the final output of the model.
   - It maps the transformer's output back to the vocabulary space, allowing the model to predict the next token in the sequence.

2. Reasoning Decoder: `self.reasoning_decoder = nn.Linear(d_model, vocab_size)`
   - This decoder is used for generating internal reasoning steps.
   - It allows the model to produce explanations or intermediate steps in its reasoning process.

The use of separate decoders for completion and reasoning is a key feature of the O1Model, enabling it to distinguish between its final outputs and its internal thought process.

## 2. Understanding the Forward Pass

The forward pass of the O1Model processes input sequences and generates outputs. Let's examine the `forward` method in detail:

```python
def forward(self, src, reasoning_tokens=None, generate_reasoning=True):
    if src.dim() == 1:
        src = src.unsqueeze(0)
    elif src.dim() == 3:
        src = src.squeeze(1)
    
    if src.size(1) == 0:
        print(f"Warning: Empty input tensor in forward pass. Shape: {src.shape}")
        batch_size = src.size(0)
        return torch.zeros(batch_size, 1, self.vocab_size), torch.zeros(batch_size, 1, self.vocab_size), torch.zeros(batch_size, 1)
    
    src = self.embed(src)
    if reasoning_tokens is not None:
        reasoning_embeddings = self.embed(reasoning_tokens)
        src = torch.cat([src, reasoning_embeddings], dim=1)
    
    src = self.pos_encoder(src)
    
    for layer in self.transformer_layers:
        src = layer(src)
    
    completion_logits = self.completion_decoder(src)
    values = self.value_head(src).squeeze(-1)
    
    if generate_reasoning:
        reasoning_logits = self.reasoning_decoder(src)
        return completion_logits, reasoning_logits, values
    else:
        return completion_logits, values
```

Let's break down this method step by step:

1. **Input Handling**: 
   - The method first ensures that the input `src` has the correct shape (batch_size, sequence_length).
   - It also includes a check for empty input tensors to prevent errors.

2. **Embedding**: 
   - The input tokens are embedded using the embedding layer: `src = self.embed(src)`.
   - If reasoning tokens are provided, they are also embedded and concatenated to the main input.

3. **Positional Encoding**: 
   - Positional information is added to the embeddings: `src = self.pos_encoder(src)`.

4. **Transformer Layers**: 
   - The embedded and position-encoded input is then passed through each transformer layer sequentially.

5. **Decoding**: 
   - The output of the transformer layers is passed through the completion decoder to get the final output logits.
   - The value head is also applied to get state value estimates for reinforcement learning.

6. **Reasoning Generation**: 
   - If `generate_reasoning` is True, the reasoning decoder is also applied to generate reasoning logits.

7. **Output**: 
   - The method returns the completion logits, reasoning logits (if generated), and value estimates.

This forward pass allows the model to process input sequences, generate completions, produce reasoning steps, and estimate state values, all in a single pass through the network.

## 3. Generating Completions and Managing the Context Window

The O1Model includes a `generate_completion` method for generating outputs based on an input sequence. This method implements the model's inference process, including the management of the context window.

### 3.1 Implementation of generate_completion Method

Let's examine the `generate_completion` method:

```python
def generate_completion(self, input_ids, max_new_tokens, num_paths=3):
    max_tokens = MAX_OUTPUT_TOKENS_MINI if self.is_mini else MAX_OUTPUT_TOKENS_PREVIEW
    max_new_tokens = min(max_new_tokens, max_tokens)
    
    if input_ids.dim() == 1:
        input_ids = input_ids.unsqueeze(0)
    elif input_ids.dim() == 3:
        input_ids = input_ids.squeeze(1)
    
    paths = []
    for _ in range(num_paths):
        generated = input_ids.clone()
        reasoning_tokens = torch.tensor([], dtype=torch.long, device=input_ids.device)
        completion_tokens = []
        subtasks = []
        
        for _ in range(max_new_tokens):
            if generated.size(1) + reasoning_tokens.size(0) >= CONTEXT_WINDOW_SIZE:
                break
            
            completion_logits, reasoning_logits, values = self(generated, reasoning_tokens)
            
            if completion_logits.numel() == 0:
                print(f"Warning: completion_logits is empty. Input shape: {generated.shape}")
                break
            
            next_token_logits = completion_logits[:, -1, :]
            next_token = self.sample_token(next_token_logits)
            
            reasoning_token = self.sample_token(reasoning_logits[:, -1, :])
            reasoning_tokens = torch.cat([reasoning_tokens, reasoning_token.unsqueeze(0)])
            
            if reasoning_tokens.size(0) > self.max_reasoning_tokens:
                reasoning_tokens = reasoning_tokens[-self.max_reasoning_tokens:]
            
            last_hidden = self.embed(generated[:, -1])
            subtask_prob = torch.sigmoid(self.subtask_head(last_hidden))
            if subtask_prob > 0.5:
                subtask = self.generate_subtask(generated, reasoning_tokens)
                subtasks.append(subtask)
                generated = torch.cat([generated, torch.tensor([[vocab['<subtask>']]]).to(generated.device)], dim=1)
            else:
                generated = torch.cat([generated, next_token.unsqueeze(1)], dim=1)
                completion_tokens.append(next_token.item())
            
            if self.should_revise_reasoning():
                generated, reasoning_tokens = self.revise_reasoning(generated, reasoning_tokens)
            
            if next_token.item() == vocab['<eos>']:
                break
        
        paths.append((completion_tokens, reasoning_tokens.tolist(), subtasks))
    
    if not paths:
        print("Warning: No valid paths generated")
        return [], [], []
    
    rewards = [self.compute_reward(p[0], p[1], p[2]) for p in paths]
    best_path = paths[rewards.index(max(rewards))]
    
    return best_path[0], best_path[1], best_path[2]
```

This method implements several key features of the O1Model:

1. **Multiple Reasoning Paths**: The method generates multiple potential paths (`num_paths`) and selects the best one based on computed rewards.

2. **Token Generation**: It generates both completion tokens (visible output) and reasoning tokens (internal thought process).

3. **Subtask Generation**: The model can decide to generate subtasks during the completion process.

4. **Reasoning Revision**: The model can revise its reasoning process during generation.

5. **Context Window Management**: The method ensures that the total number of tokens (input + generated) doesn't exceed the maximum context window size.

### 3.2 Techniques for Efficient Context Window Management

The O1Model employs several techniques to manage its large context window efficiently:

1. **Token Limit**: The method enforces a maximum token limit (`max_tokens`) based on whether it's the mini or preview version of the model.

2. **Reasoning Token Management**: The number of reasoning tokens is capped at `self.max_reasoning_tokens` to prevent excessive computation.

3. **Context Window Size Check**: The generation process stops if the total number of tokens (input + generated + reasoning) reaches the `CONTEXT_WINDOW_SIZE`.

4. **Efficient Tensor Operations**: The method uses efficient PyTorch operations like `cat` and `unsqueeze` to manipulate tensors without unnecessary copying.

5. **Early Stopping**: The generation process stops if an end-of-sequence token is generated or if the completion logits become empty.

These techniques allow the O1Model to handle long input sequences and generate lengthy outputs while maintaining computational efficiency.

In conclusion, this lesson has provided a detailed exploration of the O1Model architecture, including its components, forward pass, and completion generation process. We've examined how the model integrates various neural network concepts, implements chain-of-thought reasoning, and manages its large context window. Understanding these aspects is crucial for working with, modifying, or extending the O1-nano project. In the next lesson, we'll delve into the training process and data generation techniques used to teach this model its impressive reasoning capabilities.

