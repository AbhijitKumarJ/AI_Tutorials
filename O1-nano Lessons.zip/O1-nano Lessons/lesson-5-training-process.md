# Lesson 5: Training Process and Data Generation

## Introduction

In this lesson, we'll dive deep into the training process of the O1-nano model and explore how data is generated for training. We'll examine the intricate balance between supervised learning and reinforcement learning, understand how arithmetic problems are generated, and delve into the implementation of loss functions. This lesson will provide you with a comprehensive understanding of how the O1-nano model learns to solve arithmetic problems while developing reasoning capabilities.

## Lesson Objectives

By the end of this lesson, you will be able to:

1. Understand the overall training loop of the O1-nano model
2. Explain the process of generating arithmetic problems and reasoning chains
3. Implement and analyze the supervised learning component
4. Grasp the fundamentals of reinforcement learning as applied to the O1-nano model

## File Structure

Before we begin, let's review the file structure of our project:

```
o1-nano/
│
├── train.py
├── test.py
├── README.md
└── o1_model.pth (generated after training)
```

Our focus for this lesson will primarily be on the `train.py` file, where the training process and data generation are implemented.

## 1. Overview of the Training Loop

The training loop is the heart of our model's learning process. It's implemented in the `train_o1_model` function within `train.py`. Let's break down this function to understand its components:

```python
def train_o1_model(model, optimizer, num_epochs, batch_size):
    ppo = PPO(model, optimizer)
    
    for epoch in range(num_epochs):
        # Generate a batch of arithmetic problems
        states, actions, rewards, old_log_probs, values = collect_trajectories(model, batch_size)
        
        # Supervised learning step
        sl_loss = supervised_finetuning_loss(model, (states, actions))
        optimizer.zero_grad()
        sl_loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
    
        # Reinforcement learning step
        ppo.update(states, actions, old_log_probs, rewards, values)
    
        # Evaluation and logging
        if epoch % 10 == 0:
            metrics = evaluate_model(model, batch_size)
            log_metrics(metrics, epoch)

        print(f'Epoch {epoch} completed')
            
        # Dynamic curriculum learning
        if epoch % 50 == 0:
            adjust_problem_difficulty(epoch)
```

This function encapsulates several key components:

1. **Initialization**: We create a PPO (Proximal Policy Optimization) object, which will handle the reinforcement learning updates.

2. **Epoch Loop**: The training process is divided into epochs, allowing for iterative improvement of the model.

3. **Data Generation**: In each epoch, we generate a batch of arithmetic problems using the `collect_trajectories` function.

4. **Supervised Learning**: We perform a supervised learning step using the generated data, computing the loss and updating the model parameters.

5. **Reinforcement Learning**: We use the PPO algorithm to update the model based on the rewards obtained from solving the arithmetic problems.

6. **Evaluation and Logging**: Every 10 epochs, we evaluate the model's performance and log the metrics.

7. **Dynamic Curriculum**: Every 50 epochs, we adjust the difficulty of the problems, implementing a form of curriculum learning.

This combination of supervised and reinforcement learning is a key feature of the O1-nano model, allowing it to learn both from direct examples and from the outcomes of its own actions.

## 2. Generating Arithmetic Problems and Reasoning Chains

The O1-nano model learns on arithmetic problems that are dynamically generated during training. This is done through two main functions: `generate_arithmetic_problem` and `generate_reasoning_chain`.

Let's examine the `generate_arithmetic_problem` function:

```python
def generate_arithmetic_problem():
    operations = ['+', '-', '*', '/']
    op = random.choice(operations)
    
    while True:
        if op in ['+', '-']:
            a, b = random.randint(1, 100), random.randint(1, 100)
        else:
            a, b = random.randint(1, 10), random.randint(1, 10)
        
        if op == '+':
            result = a + b
            problem = f"Calculate the sum of {a} and {b}"
        elif op == '-':
            result = a - b
            problem = f"Calculate the difference between {a} and {b}"
        elif op == '*':
            result = a * b
            problem = f"Calculate the product of {a} and {b}"
        else:
            if b != 0:  # Avoid division by zero
                result = a // b
                problem = f"Calculate the quotient of {a} and {b}"
            else:
                continue  # Try again if b is zero
        
        if problem and result:
            return problem, result
```

This function does the following:

1. Randomly selects an operation (+, -, *, /)
2. Generates appropriate random numbers based on the operation
3. Constructs a problem statement and calculates the result
4. Handles edge cases like division by zero

The `generate_reasoning_chain` function then takes this problem and result to create a step-by-step reasoning chain:

```python
def generate_reasoning_chain(problem, result):
    words = problem.split()
    operation = words[3]  # "sum", "difference", "product", or "quotient"
    
    if operation == "sum":
        a, b = map(int, words[-3::2])
        chain = f"Step: First, we identify the numbers: {a} and {b}. "
        chain += f"Next, we add these numbers: {a} + {b}. "
        chain += f"Finally, we get the result: The sum is {result}."
    elif operation == "difference":
        a, b = map(int, words[-3::2])
        chain = f"Step: First, we identify the numbers: {a} and {b}. "
        chain += f"Next, we subtract the second number from the first: {a} - {b}. "
        chain += f"Finally, we get the result: The difference is {result}."
    elif operation == "product":
        a, b = map(int, words[-3::2])
        chain = f"Step: First, we identify the numbers: {a} and {b}. "
        chain += f"Next, we multiply these numbers: {a} * {b}. "
        chain += f"Finally, we get the result: The product is {result}."
    else:  # quotient
        a, b = map(int, words[-3::2])
        chain = f"Step: First, we identify the numbers: {a} and {b}. "
        chain += f"Next, we divide the first number by the second: {a} / {b}. "
        chain += f"Finally, we get the result: The quotient is {result}."
    
    return chain
```

This function creates a natural language description of the problem-solving process, which serves as the target output for our model to learn from. By generating both the problem and the reasoning chain, we provide the model with input-output pairs that demonstrate not just the final answer, but also the step-by-step reasoning process.

## 3. Implementing Supervised Learning

The supervised learning component of our training process is implemented in the `supervised_finetuning_loss` function:

```python
def supervised_finetuning_loss(model, batch):
    states, actions = batch
    logits, _ = model(states, generate_reasoning=False)
    
    # Reshape logits to [batch_size * sequence_length, vocab_size]
    batch_size, seq_length, vocab_size = logits.shape
    logits = logits.view(-1, vocab_size)
    
    # Reshape actions to [batch_size * sequence_length]
    target_ids = actions.view(-1)
    
    # Ensure logits and target_ids have the same length
    min_length = min(logits.size(0), target_ids.size(0))
    logits = logits[:min_length]
    target_ids = target_ids[:min_length]
    
    # Compute loss only on non-padded tokens
    non_pad_mask = target_ids != vocab['<pad>']
    logits = logits[non_pad_mask]
    target_ids = target_ids[non_pad_mask]
    
    loss = F.cross_entropy(logits, target_ids)
    return loss
```

This function performs several important steps:

1. It passes the input states through the model to get logits (predictions).
2. It reshapes the logits and target actions to align them properly.
3. It ensures that logits and target_ids have the same length, handling any discrepancies.
4. It computes the loss only on non-padded tokens, ignoring padding in the sequences.
5. Finally, it computes the cross-entropy loss between the predictions and the targets.

The supervised learning step teaches the model to generate the correct tokens for solving arithmetic problems and explaining the reasoning process. This is crucial for the model to learn the basic structure and language of arithmetic problem-solving.

## 4. Introduction to Reinforcement Learning Concepts

While we'll dive deeper into reinforcement learning in the next lesson, it's important to understand the basic concepts as they apply to our O1-nano model. The reinforcement learning component is implemented using the Proximal Policy Optimization (PPO) algorithm.

Key concepts in our reinforcement learning setup include:

1. **Policy**: The strategy that the model uses to generate tokens. In our case, this is represented by the probabilities the model assigns to each token in the vocabulary.

2. **Value Function**: An estimate of the expected cumulative reward from a given state. This is used to compute advantages, which help in determining how much better or worse an action is compared to the average action.

3. **Rewards**: Numerical feedback given to the model based on its performance. In our case, rewards are computed based on the correctness of the generated solution.

4. **Trajectories**: Sequences of states, actions, and rewards that the model experiences as it generates solutions to problems.

The `collect_trajectories` function is responsible for generating these trajectories:

```python
def collect_trajectories(model, batch_size):
    states = []
    actions = []
    rewards = []
    log_probs = []
    values = []

    max_state_length = 40

    for _ in range(batch_size):
        problem, result = generate_arithmetic_problem()
        reasoning_chain = generate_reasoning_chain(problem, result)
        
        input_ids = torch.tensor([tokenize(problem)])
        target_ids = torch.tensor([tokenize(reasoning_chain)])
        
        state = input_ids
        action_sequence = torch.full((1, max_state_length), vocab['<pad>'], dtype=torch.long)

        for t in range(max_state_length):
            if state.size(1) > max_state_length:
                state = state[:, :max_state_length]
            elif state.size(1) < max_state_length:
                padding = torch.full((1, max_state_length - state.size(1)), vocab['<pad>'], dtype=state.dtype)
                state = torch.cat([state, padding], dim=1)

            with torch.no_grad():
                logits, _, value = model(state)
                probs = F.softmax(logits[:, -1, :], dim=-1)
                dist = Categorical(probs)
                action = dist.sample()
                log_prob = dist.log_prob(action)

            action_sequence[0, t] = action.item()
            log_probs.append(log_prob)
            values.append(value[:, -1])

            state = torch.cat([state[:, :-1], action.unsqueeze(1)], dim=1)

            reward = compute_reward(state, result)
            rewards.append(reward)

            if action.item() == vocab['<eos>']:
                break

        states.append(state)
        actions.append(action_sequence)

    states = torch.cat(states, dim=0)
    actions = torch.cat(actions, dim=0)
    rewards = torch.cat(rewards, dim=0)
    log_probs = torch.cat(log_probs, dim=0)
    values = torch.cat(values, dim=0)

    return states, actions, rewards, log_probs, values
```

This function generates a batch of trajectories by:

1. Generating arithmetic problems and their corresponding reasoning chains
2. Passing the problems through the model to generate solutions
3. Computing rewards based on the generated solutions
4. Collecting the states, actions, rewards, log probabilities, and value estimates

These trajectories are then used in the PPO update step to improve the model's policy and value function.

## Conclusion

In this lesson, we've explored the training process of the O1-nano model, including data generation, supervised learning, and an introduction to reinforcement learning concepts. We've seen how arithmetic problems are generated and turned into reasoning chains, how the supervised loss is computed, and how trajectories are collected for reinforcement learning.

In the next lesson, we'll dive deeper into the PPO algorithm and how it's implemented in our model. We'll explore the details of the policy and value networks, the computation of advantages, and the process of updating the model using PPO.

## Exercises

1. Implement a function to generate more complex arithmetic problems involving multiple operations. How would you modify the `generate_reasoning_chain` function to handle these more complex problems?

2. Experiment with different reward functions in the `compute_reward` function. How might you reward partial correctness or penalize inefficient solutions?

3. Implement a function to visualize the training progress using the metrics logged in `log_metrics`. Consider using a library like matplotlib to create graphs of loss and reward over time.

4. Modify the `collect_trajectories` function to handle a variable maximum sequence length. How might this affect the training process and model performance?

5. Research and implement an alternative curriculum learning strategy in the `adjust_problem_difficulty` function. How might a more gradual or adaptive difficulty adjustment affect the model's learning?

By completing these exercises, you'll gain a deeper understanding of the training process and be better prepared for the more advanced concepts we'll cover in the next lesson on reinforcement learning with PPO.
