# Lesson 2: Python Fundamentals for O1-nano

## 1. Review of Essential Python Concepts Used in the Project

The O1-nano project utilizes several advanced Python concepts. Understanding these concepts is crucial for comprehending the project's structure and implementation. Let's dive into each of these concepts and see how they are applied in the O1-nano codebase.

### 1.1 Classes and Object-Oriented Programming

Object-Oriented Programming (OOP) is a programming paradigm that organizes code into objects, which are instances of classes. Classes encapsulate data and behavior, promoting code reusability and modularity.

#### Deep Dive into the Use of Classes in O1Model and TransformerBlock

In the O1-nano project, classes are extensively used to structure the model architecture. Let's examine two key classes:

1. **O1Model Class**

The `O1Model` class is the heart of the project, representing the entire model architecture. Here's a breakdown of its structure:

```python
class O1Model(nn.Module):
    def __init__(self, vocab_size, d_model, nhead, num_layers, is_mini=False):
        super(O1Model, self).__init__()
        self.vocab_size = vocab_size
        self.d_model = d_model
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_encoder = PositionalEncoding(d_model)
        self.transformer_layers = nn.ModuleList([TransformerBlock(d_model, nhead) for _ in range(num_layers)])
        self.completion_decoder = nn.Linear(d_model, vocab_size)
        self.reasoning_decoder = nn.Linear(d_model, vocab_size)
        self.value_head = nn.Linear(d_model, 1)
        self.subtask_head = nn.Linear(d_model, 1)
        self.is_mini = is_mini
        self.max_reasoning_tokens = 1000
```

This class encapsulates:
- The model's architectural components (embedding layer, positional encoding, transformer layers, etc.)
- Model parameters (vocabulary size, model dimension, number of heads, etc.)
- Methods for forward pass, completion generation, and other functionalities

2. **TransformerBlock Class**

The `TransformerBlock` class represents a single transformer layer:

```python
class TransformerBlock(nn.Module):
    def __init__(self, d_model, nhead, dim_feedforward=2048, dropout=0.1):
        super(TransformerBlock, self).__init__()
        self.self_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=True)
        self.feed_forward = nn.Sequential(
            nn.Linear(d_model, dim_feedforward),
            nn.ReLU(),
            nn.Linear(dim_feedforward, d_model)
        )
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        # Implementation of forward pass
```

This class encapsulates:
- The components of a transformer block (self-attention, feed-forward network, layer normalization)
- The forward pass logic for a single transformer layer

By using classes, the project achieves:
- Modularity: Each component (model, transformer block) is self-contained and can be easily modified or replaced.
- Reusability: The `TransformerBlock` class can be instantiated multiple times to create a deep transformer architecture.
- Clarity: The class structure provides a clear organization of the model's components and their interactions.

### 1.2 Decorators and Their Usage (@nn.Module)

Decorators in Python are a way to modify or enhance functions or classes without directly changing their source code. In the O1-nano project, the most prominent decorator used is `@nn.Module`, which comes from PyTorch.

#### Understanding PyTorch's nn.Module and Its Significance

The `nn.Module` is a base class provided by PyTorch for all neural network modules. When a class inherits from `nn.Module`, it gains several important functionalities:

1. **Automatic Parameter Management**: Any `nn.Parameter` or other `nn.Module` instance defined as class attributes are automatically registered and can be easily accessed or modified.

2. **Device Movement**: The `.to(device)` method allows easy movement of the entire model and its parameters between devices (e.g., CPU to GPU).

3. **Training Mode Toggle**: The `.train()` and `.eval()` methods allow switching between training and evaluation modes, which is crucial for layers like Dropout and BatchNorm.

4. **Recursive Application**: Operations like parameter initialization can be applied recursively to all submodules.

Here's how `nn.Module` is used in the O1-nano project:

```python
class O1Model(nn.Module):
    def __init__(self, vocab_size, d_model, nhead, num_layers, is_mini=False):
        super(O1Model, self).__init__()
        # ... (initialization code)

    def forward(self, src, reasoning_tokens=None, generate_reasoning=True):
        # ... (forward pass implementation)
```

By inheriting from `nn.Module`, the `O1Model` class becomes a proper PyTorch module, integrating seamlessly with PyTorch's ecosystem of tools and optimizers.

### 1.3 List Comprehensions and Dictionary Operations

Python's list comprehensions and dictionary operations provide concise and efficient ways to manipulate data structures. These features are used extensively in the O1-nano project for tasks such as vocabulary creation and token manipulation.

#### Examples from Vocabulary Creation and Token Manipulation

1. **Vocabulary Creation**

The project uses a dictionary to create a mapping between tokens and their integer representations:

```python
vocab = {
    '<pad>': 0, '<sos>': 1, '<eos>': 2, 'Step:': 3, '+': 4, '-': 5, '*': 6, '/': 7, '=': 8,
    '0': 9, '1': 10, '2': 11, '3': 12, '4': 13, '5': 14, '6': 15, '7': 16, '8': 17, '9': 18,
    # ... (more tokens)
}
```

An inverse vocabulary is created using a dictionary comprehension:

```python
inv_vocab = {v: k for k, v in vocab.items()}
```

This creates a new dictionary where the keys and values of the original `vocab` dictionary are swapped.

2. **Tokenization**

The `tokenize` function uses a list comprehension with dictionary lookup:

```python
def tokenize(text):
    return [vocab.get(token, vocab['<pad>']) for token in text.strip().split()]
```

This function splits the input text into tokens and looks up each token in the `vocab` dictionary, defaulting to the padding token if not found.

3. **Detokenization**

The `detokenize` function also uses a list comprehension with dictionary lookup:

```python
def detokenize(indices):
    return ' '.join([inv_vocab.get(idx, ' ') for idx in indices])
```

This function converts a list of token indices back into a string of tokens, using the inverse vocabulary.

These operations demonstrate how Python's built-in data structures and comprehensions can be used to efficiently process and manipulate tokens, which is a crucial part of natural language processing tasks.

### 1.4 Working with Tensors in PyTorch

PyTorch's tensor operations form the backbone of all computations in the O1-nano project. Understanding how to create, manipulate, and perform operations on tensors is crucial for working with PyTorch models.

#### Tensor Creation, Manipulation, and Basic Operations

1. **Tensor Creation**

Tensors can be created from Python lists or numpy arrays:

```python
# From list
input_ids = torch.tensor([tokenize(problem)])

# From numpy array
import numpy as np
numpy_array = np.random.rand(3, 4)
tensor = torch.from_numpy(numpy_array)
```

2. **Tensor Manipulation**

Tensors can be reshaped, concatenated, and sliced:

```python
# Reshaping
x = torch.randn(4, 4)
y = x.view(16)  # Flattens the tensor
z = x.view(-1, 8)  # -1 is inferred from other dimensions

# Concatenation
a = torch.randn(4, 3)
b = torch.randn(4, 3)
c = torch.cat([a, b], dim=1)  # Concatenate along dimension 1

# Slicing
d = torch.randn(4, 5)
print(d[:, 1])  # Prints the second column
```

3. **Basic Operations**

PyTorch supports a wide range of mathematical operations:

```python
# Element-wise operations
a = torch.randn(4, 4)
b = torch.randn(4, 4)
c = a + b
d = a * b

# Matrix multiplication
e = torch.mm(a, b)

# Reduction operations
f = torch.sum(a, dim=1)
g = torch.mean(a, dim=0)
```

In the O1-nano project, tensor operations are used extensively. For example, in the `forward` method of the `O1Model` class:

```python
src = self.embed(src)
if reasoning_tokens is not None:
    reasoning_embeddings = self.embed(reasoning_tokens)
    src = torch.cat([src, reasoning_embeddings], dim=1)

src = self.pos_encoder(src)

for layer in self.transformer_layers:
    src = layer(src)

completion_logits = self.completion_decoder(src)
values = self.value_head(src).squeeze(-1)
```

Here, we see tensor operations such as embedding lookup, concatenation, and application of various layers, all of which involve tensor manipulations.

## 2. Understanding the Custom Vocabulary and Tokenization

The O1-nano project uses a custom vocabulary and tokenization system tailored for arithmetic operations. This system is crucial for converting between human-readable text and the numerical representations that the model can process.

### 2.1 Detailed Explanation of the Vocab Dictionary

The `vocab` dictionary in the project maps tokens (strings) to unique integer IDs. This mapping includes:

1. Special tokens:
   - `<pad>`: Used for padding sequences to a fixed length (ID: 0)
   - `<sos>`: Start of sequence token (ID: 1)
   - `<eos>`: End of sequence token (ID: 2)

2. Arithmetic operators: `+`, `-`, `*`, `/`, `=`

3. Digits: `0` through `9`

4. Words and phrases commonly used in arithmetic problems:
   - `Step:`: Used to denote steps in the reasoning process
   - `if`, `then`, `else`: For conditional statements
   - `greater`, `less`, `equal`: For comparisons
   - Words like `Calculate`, `the`, `sum`, `of`, `and`, `difference`, `between`, `product`, `quotient`
   - Sequence markers: `First,`, `Next,`, `Finally,`

5. A special token for subtask generation: `<subtask>`

Here's a snippet of the vocabulary definition:

```python
vocab = {
    '<pad>': 0, '<sos>': 1, '<eos>': 2, 'Step:': 3, '+': 4, '-': 5, '*': 6, '/': 7, '=': 8,
    '0': 9, '1': 10, '2': 11, '3': 12, '4': 13, '5': 14, '6': 15, '7': 16, '8': 17, '9': 18,
    'if': 19, 'then': 20, 'else': 21, 'greater': 22, 'less': 23, 'equal': 24,
    'Calculate': 25, 'the': 26, 'sum': 27, 'of': 28, 'and': 29,
    'difference': 30, 'between': 31, 'product': 32, 'quotient': 33,
    'First,': 34, 'Next,': 35, 'Finally,': 36, 'result': 37, 'is': 38,
    '<subtask>': 39
}
```

This vocabulary is designed to cover all the necessary tokens for generating and solving simple arithmetic problems, as well as explaining the reasoning process.

### 2.2 Implementation of Tokenize and Detokenize Functions

The project implements two key functions for converting between text and token IDs:

1. **Tokenize Function**

```python
def tokenize(text):
    return [vocab.get(token, vocab['<pad>']) for token in text.strip().split()]
```

This function takes a string of text as input and returns a list of token IDs. It works as follows:
- The input text is stripped of leading/trailing whitespace and split into individual tokens.
- Each token is looked up in the `vocab` dictionary.
- If a token is not found in the vocabulary, it's replaced with the ID for the `<pad>` token.

For example:
```python
text = "Calculate the sum of 5 and 7"
token_ids = tokenize(text)
# token_ids might be [25, 26, 27, 28, 14, 29, 16]
```

2. **Detokenize Function**

```python
def detokenize(indices):
    return ' '.join([inv_vocab.get(idx, ' ') for idx in indices])
```

This function takes a list of token IDs and returns the corresponding text. It works as follows:
- Each ID is looked up in the `inv_vocab` dictionary (the inverse of `vocab`).
- If an ID is not found in the inverse vocabulary, it's replaced with a space.
- The resulting tokens are joined with spaces to form the final string.

For example:
```python
token_ids = [25, 26, 27, 28, 14, 29, 16]
text = detokenize(token_ids)
# text would be "Calculate the sum of 5 and 7"
```

These functions are crucial for the model's operation:
- `tokenize` is used to convert input problems into a format the model can process.
- `detokenize` is used to convert the model's output back into human-readable text.

The use of a custom vocabulary and these tokenization functions allows the O1-nano model to work with a specific, constrained language tailored to arithmetic problems. This specialization enables the model to focus on the task at hand without the complexity of handling a full natural language vocabulary.

In conclusion, this lesson has covered the essential Python concepts used in the O1-nano project, including classes and object-oriented programming, decorators, list comprehensions and dictionary operations, and working with PyTorch tensors. We've also delved into the custom vocabulary and tokenization system used in the project. Understanding these fundamentals is crucial for working with and extending the O1-nano model. In the next lesson, we'll explore the neural network basics and PyTorch foundations that form the backbone of the model's architecture.

