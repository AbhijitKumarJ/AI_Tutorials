# Lesson 3: Neural Network Basics and PyTorch Foundations

## 1. Introduction to Neural Networks and Their Components

Neural networks are a class of machine learning models inspired by the structure and function of biological neural networks. They are composed of interconnected nodes (neurons) organized in layers, capable of learning complex patterns from data. Understanding the basic components and concepts of neural networks is crucial for working with advanced models like O1-nano.

### 1.1 Neurons

A neuron is the fundamental unit of a neural network. It takes one or more inputs, applies a transformation to these inputs, and produces an output. In artificial neural networks, a neuron typically performs the following operations:

1. Weighted Sum: Multiply each input by a weight and sum the results.
2. Bias Addition: Add a bias term to the weighted sum.
3. Activation: Apply a non-linear activation function to the result.

Mathematically, this can be expressed as:

```
output = activation_function(sum(weight_i * input_i) + bias)
```

In PyTorch, a single neuron can be implemented using the `nn.Linear` module followed by an activation function:

```python
import torch.nn as nn

class Neuron(nn.Module):
    def __init__(self, input_size):
        super(Neuron, self).__init__()
        self.linear = nn.Linear(input_size, 1)
        self.activation = nn.ReLU()

    def forward(self, x):
        return self.activation(self.linear(x))
```

### 1.2 Layers

Layers in neural networks are collections of neurons that operate on the same input. The most common types of layers used in the O1-nano project are:

1. **Fully Connected (Dense) Layers**: Each neuron in this layer is connected to every neuron in the previous layer. In PyTorch, this is implemented using `nn.Linear`.

2. **Embedding Layers**: These layers transform discrete inputs (like words or tokens) into dense vector representations. In the O1-nano project, `nn.Embedding` is used to create token embeddings.

3. **Multi-Head Attention Layers**: These are key components of transformer architectures, allowing the model to focus on different parts of the input. In PyTorch, this is implemented using `nn.MultiheadAttention`.

Here's an example of how these layers are used in the O1Model class:

```python
class O1Model(nn.Module):
    def __init__(self, vocab_size, d_model, nhead, num_layers):
        super(O1Model, self).__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.transformer_layers = nn.ModuleList([TransformerBlock(d_model, nhead) for _ in range(num_layers)])
        self.completion_decoder = nn.Linear(d_model, vocab_size)
```

### 1.3 Activation Functions

Activation functions introduce non-linearity into neural networks, allowing them to learn complex patterns. Common activation functions include:

1. **ReLU (Rectified Linear Unit)**: f(x) = max(0, x)
2. **Sigmoid**: f(x) = 1 / (1 + e^(-x))
3. **Tanh**: f(x) = (e^x - e^(-x)) / (e^x + e^(-x))

In the O1-nano project, ReLU is commonly used in the feed-forward networks within transformer blocks:

```python
class TransformerBlock(nn.Module):
    def __init__(self, d_model, nhead, dim_feedforward=2048, dropout=0.1):
        # ...
        self.feed_forward = nn.Sequential(
            nn.Linear(d_model, dim_feedforward),
            nn.ReLU(),
            nn.Linear(dim_feedforward, d_model)
        )
        # ...
```

### 1.4 Feedforward and Backpropagation Concepts

Neural networks learn through two main processes: feedforward propagation and backpropagation.

1. **Feedforward Propagation**: This is the process of passing input data through the network to generate predictions. It involves sequential computation through the layers of the network, from input to output.

2. **Backpropagation**: This is the process of calculating gradients of the loss function with respect to the network's parameters, and using these gradients to update the parameters. It involves propagating the error backward through the network.

In PyTorch, these processes are handled automatically when you define a model, specify a loss function, and call `backward()` on the loss. Here's a simple example:

```python
# Assuming 'model' is an instance of O1Model
optimizer = torch.optim.Adam(model.parameters())
criterion = nn.CrossEntropyLoss()

# Feedforward
outputs = model(inputs)
loss = criterion(outputs, targets)

# Backpropagation
optimizer.zero_grad()
loss.backward()
optimizer.step()
```

Understanding these concepts is crucial for grasping how neural networks learn and how to train them effectively.

## 2. PyTorch Basics

PyTorch is a popular deep learning framework that provides a rich set of tools for building and training neural networks. It's the foundation of the O1-nano project, so understanding its core concepts is essential.

### 2.1 Tensors and Operations

Tensors are the fundamental data structure in PyTorch. They are multi-dimensional arrays that can be operated on efficiently, especially on GPUs.

#### Creation, Indexing, Reshaping

1. **Creation**:
   ```python
   # From Python list
   x = torch.tensor([1, 2, 3])
   
   # With specific data type
   y = torch.tensor([1.0, 2.0, 3.0], dtype=torch.float32)
   
   # Initialized with zeros or ones
   z = torch.zeros(3, 4)
   w = torch.ones(2, 3, 4)
   ```

2. **Indexing**:
   ```python
   x = torch.randn(3, 4)
   print(x[0])  # First row
   print(x[:, 1])  # Second column
   print(x[0, 1])  # Element at first row, second column
   ```

3. **Reshaping**:
   ```python
   x = torch.randn(12)
   y = x.view(3, 4)  # Reshape to 3x4
   z = x.view(-1, 6)  # Automatically determine one dimension
   ```

In the O1-nano project, tensor operations are used extensively, such as in the `forward` method of the `O1Model` class:

```python
def forward(self, src, reasoning_tokens=None, generate_reasoning=True):
    src = self.embed(src)
    if reasoning_tokens is not None:
        reasoning_embeddings = self.embed(reasoning_tokens)
        src = torch.cat([src, reasoning_embeddings], dim=1)
    # ...
```

### 2.2 Autograd and Backpropagation

PyTorch's autograd system provides automatic differentiation for all operations on tensors. This is crucial for implementing backpropagation in neural networks.

#### Computational Graphs, Gradients

1. **Computational Graphs**: PyTorch builds a dynamic computational graph as operations are performed on tensors. This graph is used to compute gradients during backpropagation.

2. **Gradients**: When you call `backward()` on a scalar tensor (usually the loss), PyTorch computes the gradients of this tensor with respect to all tensors in the computational graph that have `requires_grad=True`.

Here's a simple example:

```python
x = torch.tensor([1.0, 2.0, 3.0], requires_grad=True)
y = x ** 2
z = y.mean()

z.backward()
print(x.grad)  # Prints the gradient of z with respect to x
```

In the O1-nano project, gradients are computed and used to update the model's parameters during training:

```python
loss = criterion(outputs, targets)
optimizer.zero_grad()
loss.backward()
optimizer.step()
```

### 2.3 Building Neural Network Layers

PyTorch provides a `nn` module with a wide range of pre-defined layers for building neural networks.

#### Linear, Embedding, LayerNorm

1. **Linear (Fully Connected) Layer**:
   ```python
   linear = nn.Linear(in_features, out_features)
   ```
   This creates a linear transformation: y = xA^T + b

2. **Embedding Layer**:
   ```python
   embedding = nn.Embedding(num_embeddings, embedding_dim)
   ```
   This layer is used to create dense vector representations of discrete inputs, like words or tokens.

3. **Layer Normalization**:
   ```python
   layer_norm = nn.LayerNorm(normalized_shape)
   ```
   This normalizes the inputs across the features, which can help stabilize and speed up training.

In the O1-nano project, these layers are used to construct the model architecture:

```python
class O1Model(nn.Module):
    def __init__(self, vocab_size, d_model, nhead, num_layers):
        super(O1Model, self).__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_encoder = PositionalEncoding(d_model)
        self.transformer_layers = nn.ModuleList([TransformerBlock(d_model, nhead) for _ in range(num_layers)])
        self.completion_decoder = nn.Linear(d_model, vocab_size)
        # ...

class TransformerBlock(nn.Module):
    def __init__(self, d_model, nhead, dim_feedforward=2048, dropout=0.1):
        super(TransformerBlock, self).__init__()
        self.self_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=True)
        self.feed_forward = nn.Sequential(
            nn.Linear(d_model, dim_feedforward),
            nn.ReLU(),
            nn.Linear(dim_feedforward, d_model)
        )
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        # ...
```

## 3. Understanding the TransformerBlock Class

The `TransformerBlock` class in the O1-nano project implements a single layer of the transformer architecture. Understanding this class is crucial as it forms the core of the model's ability to process and reason about input sequences.

### 3.1 Multi-head Attention Mechanism

Multi-head attention is a key innovation in transformer architectures. It allows the model to jointly attend to information from different representation subspaces at different positions.

In the `TransformerBlock` class, multi-head attention is implemented using PyTorch's `nn.MultiheadAttention`:

```python
self.self_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=True)
```

The multi-head attention mechanism works as follows:

1. The input is linearly projected to create queries, keys, and values.
2. Attention is computed independently for each head:
   - Compute dot products of query with all keys
   - Scale and apply a softmax to get attention weights
   - Apply attention weights to values
3. The outputs from all heads are concatenated and linearly projected to produce the final output.

This allows the model to capture different types of relationships in the input sequence simultaneously.

### 3.2 Feedforward Neural Networks in Transformers

After the multi-head attention layer, each transformer block includes a position-wise feedforward neural network. This network consists of two linear transformations with a ReLU activation in between:

```python
self.feed_forward = nn.Sequential(
    nn.Linear(d_model, dim_feedforward),
    nn.ReLU(),
    nn.Linear(dim_feedforward, d_model)
)
```

This feedforward network allows the model to process the attended information and introduce non-linearity into the transformer block.

### 3.3 Residual Connections and Layer Normalization

Transformer blocks use residual connections (or skip connections) and layer normalization to facilitate training of deep networks:

```python
def forward(self, x):
    attn_output, _ = self.self_attn(x, x, x)
    x = x + self.dropout(attn_output)
    x = self.norm1(x)
    ff_output = self.feed_forward(x)
    x = x + self.dropout(ff_output)
    x = self.norm2(x)
    return x
```

1. **Residual Connections**: The input to each sub-layer (attention and feedforward) is added to its output. This helps in training deep networks by providing a direct path for gradients to flow.

2. **Layer Normalization**: Applied after each sub-layer, layer normalization helps stabilize the activations, which can speed up training and improve generalization.

These techniques work together to enable the training of deep transformer networks, allowing them to capture complex patterns in the input data.

In conclusion, this lesson has covered the fundamental concepts of neural networks and their implementation in PyTorch, with a focus on the components used in the O1-nano project. We've explored the basics of neurons, layers, and activation functions, as well as key PyTorch concepts like tensors, autograd, and neural network modules. Finally, we've taken a deep dive into the `TransformerBlock` class, which forms the core of the O1-nano model's architecture. Understanding these concepts is crucial for working with and extending the O1-nano model. In the next lesson, we'll explore the overall architecture of the O1Model in more detail.

