# Lesson 7: Crew Orchestration Techniques

## Lesson Objectives
By the end of this lesson, students will be able to:
1. Manage multiple agents in a crew, including their roles, interactions, and potential conflicts
2. Implement different process types (sequential, hierarchical) with examples
3. Use planners for complex workflows (task decomposition, priority management)
4. Handle crew outputs and results effectively
5. Implement custom manager agents for advanced orchestration
6. Configure crew-level settings (memory, embeddings, telemetry)

## File Structure
```
project_root/
│
├── crews/
│   ├── __init__.py
│   ├── basic_crew.py
│   ├── hierarchical_crew.py
│   └── custom_manager_crew.py
│
├── agents/
│   ├── __init__.py
│   ├── specialist_agents.py
│   └── manager_agent.py
│
├── planners/
│   ├── __init__.py
│   └── workflow_planner.py
│
├── utils/
│   ├── __init__.py
│   ├── output_handlers.py
│   └── telemetry.py
│
├── main.py
└── requirements.txt
```

## 1. Managing Multiple Agents in a Crew

When orchestrating a crew of AI agents, it's crucial to define clear roles, manage interactions, and handle potential conflicts:

```python
# agents/specialist_agents.py
from crewai import Agent

researcher = Agent(
    role="Research Specialist",
    goal="Conduct thorough research on given topics",
    backstory="You are a seasoned researcher with a keen eye for detail and a knack for finding obscure information."
)

writer = Agent(
    role="Content Writer",
    goal="Create engaging and informative content based on research findings",
    backstory="You are a skilled writer with a talent for turning complex information into compelling narratives."
)

editor = Agent(
    role="Content Editor",
    goal="Ensure all content is accurate, well-structured, and meets quality standards",
    backstory="You are a meticulous editor with years of experience in refining and perfecting written content."
)

# crews/basic_crew.py
from crewai import Crew
from agents.specialist_agents import researcher, writer, editor

content_creation_crew = Crew(
    agents=[researcher, writer, editor],
    tasks=[
        Task(description="Research the latest trends in AI", agent=researcher),
        Task(description="Write a comprehensive article on AI trends", agent=writer),
        Task(description="Edit and refine the AI trends article", agent=editor)
    ],
    verbose=True  # Enable verbose mode to see agent interactions
)
```

Best practices for managing multiple agents:
- Clearly define each agent's role and responsibilities
- Ensure tasks are appropriately assigned to agents based on their specialties
- Use the `verbose` mode to monitor agent interactions and identify any conflicts
- Implement a hierarchical structure for complex workflows with many agents

## 2. Implementing Different Process Types

CrewAI supports different process types for crew execution. Let's explore sequential and hierarchical processes:

```python
# crews/basic_crew.py
from crewai import Crew, Process

# Sequential Process
sequential_crew = Crew(
    agents=[researcher, writer, editor],
    tasks=[task1, task2, task3],
    process=Process.sequential
)

# crews/hierarchical_crew.py
from crewai import Crew, Process
from agents.manager_agent import project_manager

# Hierarchical Process
hierarchical_crew = Crew(
    agents=[researcher, writer, editor, project_manager],
    tasks=[task1, task2, task3],
    process=Process.hierarchical,
    manager_agent=project_manager
)
```

The sequential process executes tasks in order, while the hierarchical process uses a manager agent to oversee task allocation and execution.

## 3. Using Planners for Complex Workflows

For more complex workflows, you can implement a planner to decompose tasks and manage priorities:

```python
# planners/workflow_planner.py
from crewai import Agent, Task

class WorkflowPlanner(Agent):
    def plan_workflow(self, main_task):
        subtasks = self.decompose_task(main_task)
        prioritized_tasks = self.prioritize_tasks(subtasks)
        return prioritized_tasks

    def decompose_task(self, task):
        # Implement logic to break down the task into smaller subtasks
        pass

    def prioritize_tasks(self, tasks):
        # Implement logic to prioritize tasks based on importance and dependencies
        pass

# main.py
from crewai import Crew
from planners.workflow_planner import WorkflowPlanner

planner = WorkflowPlanner(
    role="Workflow Planner",
    goal="Optimize task execution for maximum efficiency",
    backstory="You are an expert in project management and workflow optimization."
)

main_task = Task(description="Create a comprehensive marketing campaign for a new product launch")
planned_tasks = planner.plan_workflow(main_task)

planned_crew = Crew(
    agents=[researcher, writer, designer, social_media_specialist],
    tasks=planned_tasks
)

result = planned_crew.kickoff()
```

## 4. Handling Crew Outputs and Results

Effective management of crew outputs is crucial for utilizing the results of your AI workflows:

```python
# utils/output_handlers.py
import json

def save_to_json(crew_output, filename):
    with open(filename, 'w') as f:
        json.dump(crew_output, f, indent=2)

def generate_report(crew_output):
    report = "Crew Execution Report\n"
    report += "=====================\n\n"
    for task in crew_output.tasks:
        report += f"Task: {task.description}\n"
        report += f"Agent: {task.agent.role}\n"
        report += f"Output: {task.output}\n\n"
    return report

# main.py
from crews.basic_crew import content_creation_crew
from utils.output_handlers import save_to_json, generate_report

result = content_creation_crew.kickoff()

# Save raw output to JSON
save_to_json(result, 'crew_output.json')

# Generate and print a formatted report
report = generate_report(result)
print(report)
```

## 5. Implementing Custom Manager Agents

For advanced orchestration, you can create custom manager agents:

```python
# agents/manager_agent.py
from crewai import Agent

class ProjectManagerAgent(Agent):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def assign_task(self, task, available_agents):
        # Implement logic to assign tasks to the most suitable agent
        pass

    def evaluate_output(self, task_output):
        # Implement logic to evaluate task outputs and provide feedback
        pass

    def handle_conflicts(self, conflicting_agents):
        # Implement logic to resolve conflicts between agents
        pass

# crews/custom_manager_crew.py
from crewai import Crew
from agents.manager_agent import ProjectManagerAgent

project_manager = ProjectManagerAgent(
    role="Project Manager",
    goal="Ensure smooth execution of the project and optimal resource allocation",
    backstory="You are a seasoned project manager with a track record of delivering complex projects on time and within budget."
)

custom_managed_crew = Crew(
    agents=[researcher, writer, editor],
    tasks=[task1, task2, task3],
    manager_agent=project_manager,
    process=Process.hierarchical
)
```

## 6. Crew-level Configurations

Configure advanced settings at the crew level for enhanced performance:

```python
# main.py
from crewai import Crew
from langchain.embeddings import OpenAIEmbeddings

crew_with_advanced_config = Crew(
    agents=[agent1, agent2, agent3],
    tasks=[task1, task2, task3],
    process=Process.sequential,
    memory=True,  # Enable memory for the entire crew
    embedder=OpenAIEmbeddings(),  # Use custom embeddings for memory
    telemetry=False,  # Disable telemetry for privacy
    verbose=True,  # Enable verbose mode for detailed logs
    max_rpm=60,  # Set maximum requests per minute
    share_crew=True,  # Share anonymized crew data with CrewAI developers
)

result = crew_with_advanced_config.kickoff()
```

## Practical Exercise

Design a complex CrewAI project that incorporates all the concepts we've covered:

1. Create a crew for a full-scale digital marketing campaign, including researchers, content creators, designers, and social media specialists.
2. Implement a custom project manager agent to oversee the campaign execution.
3. Use a planner to break down the main campaign goal into smaller, prioritized tasks.
4. Implement both sequential and hierarchical processes for different phases of the campaign.
5. Handle the crew's output by generating a comprehensive report and storing results in a structured format.
6. Configure advanced crew-level settings, including memory and custom embeddings.

## Conclusion

In this lesson, we've explored advanced crew orchestration techniques in CrewAI. By mastering these concepts, you can create sophisticated AI teams capable of handling complex, real-world projects. Remember to carefully consider the interactions between agents, choose the appropriate process type for your workflow, and leverage custom manager agents and planners for optimal results.

## Additional Resources
- [CrewAI GitHub Repository](https://github.com/joaomdmoura/crewAI)
- [LangChain Documentation on Memory](https://python.langchain.com/docs/modules/memory/)
- [OpenAI Embeddings Documentation](https://platform.openai.com/docs/guides/embeddings)
