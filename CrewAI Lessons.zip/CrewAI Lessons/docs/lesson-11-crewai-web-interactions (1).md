goal="Scrape websites ethically and efficiently",
    backstory="You are an AI committed to responsible web scraping practices",
    verbose=True
)

# Create a task for ethical scraping
ethical_scrape_task = Task(
    description="Ethically scrape the content from https://example.com/about",
    agent=respectful_agent
)

# Create and run the crew
crew = Crew(agents=[respectful_agent], tasks=[ethical_scrape_task])
result = crew.kickoff()
print(result)
```

## Handling JavaScript-rendered Content

Many modern websites use JavaScript to render content dynamically. To handle such cases, we can use a headless browser like Playwright. Here's an example of how to integrate Playwright with our CrewAI agent:

```python
# web_scraping/dynamic_content_scraper.py
from playwright.sync_api import sync_playwright
from crewai import Agent, Task, Crew

class DynamicContentScraperAgent(Agent):
    def scrape_dynamic_content(self, url, selector):
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(url)
            page.wait_for_selector(selector)
            content = page.inner_text(selector)
            browser.close()
            return content

# Create a dynamic content scraper agent
dynamic_scraper = DynamicContentScraperAgent(
    role="Dynamic Content Scraper",
    goal="Extract content from JavaScript-rendered websites",
    backstory="You are an AI specialized in scraping modern, dynamic websites",
    verbose=True
)

# Create a task for dynamic scraping
dynamic_scrape_task = Task(
    description="Scrape the dynamically loaded content from https://example.com/dynamic-page",
    agent=dynamic_scraper
)

# Create and run the crew
crew = Crew(agents=[dynamic_scraper], tasks=[dynamic_scrape_task])
result = crew.kickoff()
print(result)
```

## Implementing a Custom Search Engine

Let's create a custom search engine that combines web scraping with natural language processing to provide more contextual search results:

```python
# search_tools/custom_search.py
import requests
from bs4 import BeautifulSoup
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from crewai import Agent, Task, Crew

class CustomSearchAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.vectorizer = TfidfVectorizer()

    def search(self, query, urls):
        documents = []
        for url in urls:
            response = requests.get(url)
            soup = BeautifulSoup(response.text, 'html.parser')
            documents.append(soup.get_text())
        
        # Vectorize documents and query
        tfidf_matrix = self.vectorizer.fit_transform(documents)
        query_vector = self.vectorizer.transform([query])
        
        # Calculate similarity
        similarities = cosine_similarity(query_vector, tfidf_matrix).flatten()
        
        # Return the most relevant document
        most_relevant_index = similarities.argmax()
        return urls[most_relevant_index], similarities[most_relevant_index]

# Create a custom search agent
custom_search_agent = CustomSearchAgent(
    role="Custom Search Engine",
    goal="Provide relevant search results based on content similarity",
    backstory="You are an AI that combines web scraping with NLP for intelligent searching",
    verbose=True
)

# Create a task for custom search
custom_search_task = Task(
    description="Find the most relevant page about 'machine learning' from a list of URLs",
    agent=custom_search_agent
)

# Create and run the crew
crew = Crew(agents=[custom_search_agent], tasks=[custom_search_task])
result = crew.kickoff()
print(result)
```

## Conclusion

In this lesson, we've explored various aspects of web interactions using CrewAI. We've covered web scraping techniques, from basic to advanced, including handling dynamic content. We've implemented search functionalities, worked with different types of APIs, and created custom web-based tools. Throughout the lesson, we've emphasized the importance of ethical and efficient web scraping practices.

By leveraging these techniques, you can create powerful CrewAI agents capable of interacting with the web, gathering information, and performing complex tasks that involve web-based data.

## Exercises

1. Create a CrewAI agent that scrapes a news website and summarizes the top stories of the day.
2. Implement a custom search engine that searches across multiple websites and ranks results based on relevance to the query.
3. Develop a CrewAI agent that interacts with a RESTful API to perform CRUD operations on a resource.
4. Create a web monitoring tool that checks a list of websites for changes and reports any updates.
5. Implement a CrewAI agent that uses Selenium or Playwright to interact with a web application, filling out forms and navigating through multiple pages.

## Additional Resources

- Beautiful Soup Documentation: [https://www.crummy.com/software/BeautifulSoup/bs4/doc/](https://www.crummy.com/software/BeautifulSoup/bs4/doc/)
- Requests Library Documentation: [https://docs.python-requests.org/en/latest/](https://docs.python-requests.org/en/latest/)
- Selenium with Python Documentation: [https://selenium-python.readthedocs.io/](https://selenium-python.readthedocs.io/)
- Playwright Python Documentation: [https://playwright.dev/python/](https://playwright.dev/python/)
- "Web Scraping with Python" by Ryan Mitchell: [Book Link]
- "Mining the Social Web" by Matthew A. Russell & Mikhail Klassen: [Book Link]

Remember to always respect website terms of service, robots.txt files, and practice ethical web scraping. Happy coding!

