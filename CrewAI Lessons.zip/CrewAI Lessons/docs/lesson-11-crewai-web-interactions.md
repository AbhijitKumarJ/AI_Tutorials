# Lesson 11: CrewAI for Web Interactions

## Lesson Overview
In this lesson, we'll explore how to use CrewAI for various web interactions. We'll cover web scraping, implementing search functionalities, working with APIs and external data sources, handling dynamic web content, implementing web-based tools, and best practices for respectful and efficient web scraping.

## File Structure
```
project_root/
│
├── web_scraping/
│   ├── basic_scraper.py
│   ├── advanced_scraper.py
│   └── dynamic_content_scraper.py
│
├── search_tools/
│   ├── google_search.py
│   ├── github_search.py
│   └── custom_search.py
│
├── api_interactions/
│   ├── rest_api_client.py
│   └── graphql_client.py
│
├── web_tools/
│   ├── website_search_tool.py
│   └── content_extraction_tool.py
│
├── utils/
│   └── scraping_utils.py
│
├── config/
│   └── scraping_config.yaml
│
├── requirements.txt
└── main.py
```

## 1. Web Scraping with CrewAI

### Basic Web Scraping

Let's start with a basic web scraping example using the `requests` and `BeautifulSoup` libraries:

```python
# web_scraping/basic_scraper.py
import requests
from bs4 import BeautifulSoup
from crewai import Agent, Task, Crew

class WebScraperAgent(Agent):
    def scrape_website(self, url):
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        return soup.get_text()

# Create a web scraper agent
scraper_agent = WebScraperAgent(
    role="Web Scraper",
    goal="Extract information from websites",
    backstory="You are an AI specialized in gathering data from the web",
    verbose=True
)

# Create a task for web scraping
scrape_task = Task(
    description="Scrape the content from https://example.com",
    agent=scraper_agent
)

# Create and run the crew
crew = Crew(agents=[scraper_agent], tasks=[scrape_task])
result = crew.kickoff()
print(result)
```

### Advanced Web Scraping

For more complex websites, we can use Selenium to handle JavaScript-rendered content:

```python
# web_scraping/advanced_scraper.py
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from crewai import Agent, Task, Crew

class AdvancedScraperAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        self.driver = webdriver.Chrome(options=chrome_options)

    def scrape_dynamic_website(self, url, target_element):
        self.driver.get(url)
        element = WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, target_element))
        )
        return element.text

    def __del__(self):
        self.driver.quit()

# Create an advanced scraper agent
advanced_scraper = AdvancedScraperAgent(
    role="Advanced Web Scraper",
    goal="Extract information from dynamic websites",
    backstory="You are an AI capable of scraping complex, JavaScript-rendered websites",
    verbose=True
)

# Create a task for advanced web scraping
scrape_task = Task(
    description="Scrape the dynamically loaded content from https://example.com/dynamic",
    agent=advanced_scraper
)

# Create and run the crew
crew = Crew(agents=[advanced_scraper], tasks=[scrape_task])
result = crew.kickoff()
print(result)
```

## 2. Implementing Search Functionalities

### Google Search

We can integrate Google search functionality using the `googlesearch-python` library:

```python
# search_tools/google_search.py
from googlesearch import search
from crewai import Agent, Task, Crew

class GoogleSearchAgent(Agent):
    def perform_search(self, query, num_results=5):
        results = []
        for j in search(query, num_results=num_results):
            results.append(j)
        return results

# Create a Google search agent
google_agent = GoogleSearchAgent(
    role="Google Search Expert",
    goal="Find relevant information on the web",
    backstory="You are an AI specialized in using Google to find information",
    verbose=True
)

# Create a task for Google search
search_task = Task(
    description="Find the top 5 resources about 'artificial intelligence in healthcare'",
    agent=google_agent
)

# Create and run the crew
crew = Crew(agents=[google_agent], tasks=[search_task])
result = crew.kickoff()
print(result)
```

### GitHub Search

For searching GitHub repositories, we can use the GitHub API:

```python
# search_tools/github_search.py
import requests
from crewai import Agent, Task, Crew

class GitHubSearchAgent(Agent):
    def search_github(self, query, sort='stars', order='desc'):
        url = f"https://api.github.com/search/repositories?q={query}&sort={sort}&order={order}"
        response = requests.get(url)
        return response.json()['items'][:5]  # Return top 5 results

# Create a GitHub search agent
github_agent = GitHubSearchAgent(
    role="GitHub Search Expert",
    goal="Find relevant repositories on GitHub",
    backstory="You are an AI specialized in searching GitHub for code and projects",
    verbose=True
)

# Create a task for GitHub search
search_task = Task(
    description="Find the top 5 most starred Python machine learning repositories on GitHub",
    agent=github_agent
)

# Create and run the crew
crew = Crew(agents=[github_agent], tasks=[search_task])
result = crew.kickoff()
print(result)
```

## 3. Working with APIs and External Data Sources

### RESTful API Interaction

Here's an example of how to interact with a RESTful API:

```python
# api_interactions/rest_api_client.py
import requests
from crewai import Agent, Task, Crew

class RESTAPIAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.base_url = "https://api.example.com/v1"
        self.api_key = "your_api_key_here"

    def get_data(self, endpoint):
        headers = {"Authorization": f"Bearer {self.api_key}"}
        response = requests.get(f"{self.base_url}/{endpoint}", headers=headers)
        return response.json()

    def post_data(self, endpoint, data):
        headers = {"Authorization": f"Bearer {self.api_key}"}
        response = requests.post(f"{self.base_url}/{endpoint}", json=data, headers=headers)
        return response.json()

# Create a REST API agent
api_agent = RESTAPIAgent(
    role="API Interaction Expert",
    goal="Interact with external APIs to fetch and send data",
    backstory="You are an AI specialized in working with RESTful APIs",
    verbose=True
)

# Create tasks for API interaction
get_task = Task(
    description="Fetch user data from the API",
    agent=api_agent
)

post_task = Task(
    description="Create a new user record via the API",
    agent=api_agent
)

# Create and run the crew
crew = Crew(agents=[api_agent], tasks=[get_task, post_task])
results = crew.kickoff()
for result in results:
    print(result)
```

### GraphQL API Interaction

For GraphQL APIs, we can use the `gql` library:

```python
# api_interactions/graphql_client.py
from gql import gql, Client
from gql.transport.requests import RequestsHTTPTransport
from crewai import Agent, Task, Crew

class GraphQLAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        transport = RequestsHTTPTransport(url='https://api.example.com/graphql')
        self.client = Client(transport=transport, fetch_schema_from_transport=True)

    def execute_query(self, query, variables=None):
        return self.client.execute(gql(query), variable_values=variables)

# Create a GraphQL agent
graphql_agent = GraphQLAgent(
    role="GraphQL Expert",
    goal="Interact with GraphQL APIs to fetch and mutate data",
    backstory="You are an AI specialized in working with GraphQL APIs",
    verbose=True
)

# Create a task for GraphQL query
query_task = Task(
    description="Fetch the list of all users and their email addresses",
    agent=graphql_agent
)

# Create and run the crew
crew = Crew(agents=[graphql_agent], tasks=[query_task])
result = crew.kickoff()
print(result)
```

## 4. Handling Dynamic Web Content

To handle dynamic web content, we can use Playwright, which supports multiple browsers and provides a high-level API:

```python
# web_scraping/dynamic_content_scraper.py
from playwright.sync_api import sync_playwright
from crewai import Agent, Task, Crew

class DynamicContentAgent(Agent):
    def scrape_dynamic_content(self, url, selector):
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(url)
            page.wait_for_selector(selector)
            content = page.inner_text(selector)
            browser.close()
            return content

# Create a dynamic content scraper agent
dynamic_agent = DynamicContentAgent(
    role="Dynamic Content Expert",
    goal="Extract information from dynamically loaded web pages",
    backstory="You are an AI specialized in scraping JavaScript-rendered content",
    verbose=True
)

# Create a task for dynamic content scraping
dynamic_task = Task(
    description="Scrape the dynamically loaded content from https://example.com/dynamic-page",
    agent=dynamic_agent
)

# Create and run the crew
crew = Crew(agents=[dynamic_agent], tasks=[dynamic_task])
result = crew.kickoff()
print(result)
```

## 5. Implementing Web-based Tools

### Website Search Tool

Let's create a tool that searches within a specific website:

```python
# web_tools/website_search_tool.py
import requests
from bs4 import BeautifulSoup
from crewai import Agent, Task, Crew

class WebsiteSearchTool(Agent):
    def search_website(self, url, query):
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        results = soup.find_all(text=lambda text: query.lower() in text.lower())
        return [result.strip() for result in results]

# Create a website search agent
website_search_agent = WebsiteSearchTool(
    role="Website Content Searcher",
    goal="Search for specific content within websites",
    backstory="You are an AI specialized in finding information on web pages",
    verbose=True
)

# Create a task for website search
search_task = Task(
    description="Search for 'machine learning' on https://example.com",
    agent=website_search_agent
)

# Create and run the crew
crew = Crew(agents=[website_search_agent], tasks=[search_task])
result = crew.kickoff()
print(result)
```

### Content Extraction Tool

Here's a tool for extracting specific content from web pages:

```python
# web_tools/content_extraction_tool.py
import requests
from bs4 import BeautifulSoup
from crewai import Agent, Task, Crew

class ContentExtractionTool(Agent):
    def extract_content(self, url, tag, class_name=None):
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        if class_name:
            elements = soup.find_all(tag, class_=class_name)
        else:
            elements = soup.find_all(tag)
        return [element.get_text().strip() for element in elements]

# Create a content extraction agent
extraction_agent = ContentExtractionTool(
    role="Content Extractor",
    goal="Extract specific content from web pages",
    backstory="You are an AI specialized in parsing and extracting web page content",
    verbose=True
)

# Create a task for content extraction
extraction_task = Task(
    description="Extract all paragraph content from https://example.com",
    agent=extraction_agent
)

# Create and run the crew
crew = Crew(agents=[extraction_agent], tasks=[extraction_task])
result = crew.kickoff()
print(result)
```

## 6. Best Practices for Respectful and Efficient Web Scraping

When performing web scraping, it's crucial to follow best practices to ensure respectful and efficient interactions with websites. Here are some key considerations:

1. **Respect robots.txt**: Always check and adhere to the rules specified in a website's robots.txt file.

2. **Implement rate limiting**: Avoid overwhelming servers by implementing delays between requests.

3. **Use appropriate headers**: Set user-agent headers to identify your bot and provide contact information.

4. **Handle errors gracefully**: Implement proper error handling and retries for failed requests.

5. **Cache results**: Store scraped data to reduce unnecessary repeat requests.

Let's implement these best practices in a utility module:

```python
# utils/scraping_utils.py
import time
import requests
from urllib.robotparser import RobotFileParser

class RespectfulScraper:
    def __init__(self, base_url, user_agent):
        self.base_url = base_url
        self.user_agent = user_agent
        self.robot_parser = RobotFileParser()
        self.robot_parser.set_url(f"{base_url}/robots.txt")
        self.robot_parser.read()
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": user_agent})

    def can_fetch(self, url):
        return self.robot_parser.can_fetch(self.user_agent, url)

    def get(self, url, delay=1):
        if not self.can_fetch(url):
            raise PermissionError(f"Scraping not allowed for {url}")
        time.sleep(delay)
        return self.session.get(url)

# Usage in an agent
from crewai import Agent, Task, Crew

class RespectfulScraperAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.scraper = RespectfulScraper(
            base_url="https://example.com",
            user_agent="CrewAI Bot (https://github.com/your-repo)"
        )

    def scrape_respectfully(self, url):
        try:
            response = self.scraper.get(url)
            return response.text
        except PermissionError as e:
            return str(e)

# Create a respectful scraper agent
respectful_agent = RespectfulScraperAgent(
    role="Ethical Web Scraper",
    