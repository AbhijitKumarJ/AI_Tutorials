# Lesson 6: Task Management and Execution

## Lesson Objectives
By the end of this lesson, students will be able to:
1. Design effective tasks using best practices and patterns
2. Use context and chain tasks for complex workflows
3. Implement callbacks and asynchronous execution
4. Handle errors and perform validation in tasks
5. Create conditional tasks and decision-making processes
6. Optimize task execution with parallel processing

## File Structure
```
project_root/
│
├── tasks/
│   ├── __init__.py
│   ├── basic_tasks.py
│   ├── complex_tasks.py
│   ├── conditional_tasks.py
│   └── async_tasks.py
│
├── utils/
│   ├── __init__.py
│   ├── callbacks.py
│   └── validators.py
│
├── workflows/
│   ├── __init__.py
│   └── parallel_workflow.py
│
├── main.py
└── requirements.txt
```

## 1. Designing Effective Tasks

Tasks in CrewAI are the building blocks of your AI workflows. Here are some best practices for designing effective tasks:

```python
# tasks/basic_tasks.py
from crewai import Task

# Clear and specific task description
research_task = Task(
    description="Conduct a comprehensive literature review on the latest advancements in quantum computing, focusing on publications from the last two years.",
    expected_output="A 500-word summary of key findings, highlighting major breakthroughs and potential applications.",
    agent=researcher_agent
)

# Task with time constraint
time_sensitive_task = Task(
    description="Monitor and analyze real-time stock market data for the next 30 minutes, identifying any unusual patterns or significant price movements.",
    expected_output="A brief report of notable market activities and potential trading opportunities.",
    agent=financial_analyst_agent,
    max_execution_time=1800  # 30 minutes in seconds
)
```

Best Practices:
- Be specific about the task requirements and expected output
- Break complex tasks into smaller, manageable sub-tasks
- Include relevant context or background information
- Set clear evaluation criteria for task completion

## 2. Using Context and Chaining Tasks

For complex workflows, you can use task context and chaining to create dependencies and information flow between tasks:

```python
# tasks/complex_tasks.py
from crewai import Task

data_collection_task = Task(
    description="Collect and preprocess dataset X from our data warehouse.",
    expected_output="A cleaned and normalized dataset ready for analysis.",
    agent=data_engineer_agent
)

analysis_task = Task(
    description="Perform exploratory data analysis on the preprocessed dataset.",
    expected_output="A comprehensive report of data insights and visualizations.",
    agent=data_analyst_agent,
    context=[data_collection_task]  # This task depends on the output of data_collection_task
)

report_writing_task = Task(
    description="Write a detailed report summarizing the findings from the data analysis.",
    expected_output="A 10-page report with executive summary, methodology, results, and recommendations.",
    agent=report_writer_agent,
    context=[analysis_task]  # This task depends on the output of analysis_task
)
```

By using the `context` parameter, you ensure that tasks have access to the outputs of their predecessor tasks.

## 3. Implementing Callbacks and Asynchronous Execution

Callbacks allow you to perform actions at specific points during task execution, while asynchronous execution enables non-blocking task processing:

```python
# utils/callbacks.py
def task_started_callback(task):
    print(f"Task '{task.description[:30]}...' has started.")

def task_completed_callback(task):
    print(f"Task '{task.description[:30]}...' has completed.")

# tasks/async_tasks.py
import asyncio
from crewai import Task

async_task = Task(
    description="Perform a long-running data processing operation.",
    expected_output="Processed data results.",
    agent=data_processor_agent,
    async_execution=True,
    callbacks={
        "on_start": task_started_callback,
        "on_end": task_completed_callback
    }
)

# main.py
import asyncio
from crewai import Crew

async def main():
    crew = Crew(
        agents=[data_processor_agent],
        tasks=[async_task]
    )
    result = await crew.kickoff_async()
    print(result)

asyncio.run(main())
```

## 4. Error Handling and Validation in Tasks

Implementing proper error handling and validation ensures robustness in your CrewAI workflows:

```python
# utils/validators.py
import json

def validate_json_output(output):
    try:
        json.loads(output)
        return True
    except json.JSONDecodeError:
        return False

# tasks/basic_tasks.py
from crewai import Task
from utils.validators import validate_json_output

json_task = Task(
    description="Generate a JSON object containing user profile information.",
    expected_output="A valid JSON object with user data.",
    agent=json_generator_agent,
    output_value_function=validate_json_output
)

# Implementing error handling
try:
    result = json_task.execute()
    if result:
        print("Task completed successfully.")
    else:
        print("Task output validation failed.")
except Exception as e:
    print(f"An error occurred during task execution: {str(e)}")
```

## 5. Creating Conditional Tasks and Decision-Making Processes

Conditional tasks allow for dynamic workflow adjustments based on intermediate results:

```python
# tasks/conditional_tasks.py
from crewai import Task, ConditionalTask
from pydantic import BaseModel

class SentimentAnalysisOutput(BaseModel):
    sentiment: str
    score: float

def is_positive_sentiment(output):
    return output.sentiment == "positive" and output.score > 0.7

sentiment_analysis_task = Task(
    description="Analyze the sentiment of the given product review.",
    expected_output="Sentiment analysis results.",
    agent=nlp_agent,
    output_pydantic=SentimentAnalysisOutput
)

positive_response_task = Task(
    description="Draft a thank you message to the customer for their positive review.",
    expected_output="A personalized thank you message.",
    agent=customer_service_agent
)

improvement_task = Task(
    description="Analyze the review for product improvement suggestions.",
    expected_output="A list of potential product enhancements based on the review.",
    agent=product_manager_agent
)

conditional_task = ConditionalTask(
    description="Respond to customer review based on sentiment analysis.",
    condition=is_positive_sentiment,
    positive_task=positive_response_task,
    negative_task=improvement_task,
    context=[sentiment_analysis_task]
)
```

## 6. Optimizing Task Execution with Parallel Processing

For improved performance, you can execute independent tasks in parallel:

```python
# workflows/parallel_workflow.py
from crewai import Crew, Process
from tasks.basic_tasks import task1, task2, task3

parallel_crew = Crew(
    agents=[agent1, agent2, agent3],
    tasks=[task1, task2, task3],
    process=Process.parallel,
    max_concurrent_tasks=3
)

# main.py
from workflows.parallel_workflow import parallel_crew

results = parallel_crew.kickoff()
for result in results:
    print(f"Task result: {result}")
```

## Practical Exercise

Design a complex workflow that incorporates all the concepts we've covered:

1. Create a series of tasks for a social media content creation process (research, content writing, image generation, posting).
2. Implement task chaining to ensure proper information flow between tasks.
3. Add conditional tasks to handle different content types (text post vs. image post).
4. Implement error handling and validation for each task.
5. Use callbacks to log the progress of each task.
6. Optimize the workflow by identifying tasks that can be executed in parallel.

## Conclusion

In this lesson, we've explored advanced task management and execution techniques in CrewAI. By mastering these concepts, you can create sophisticated AI workflows capable of handling complex, real-world scenarios. Remember to always consider the dependencies between tasks, implement proper error handling, and optimize for performance when designing your CrewAI projects.

## Additional Resources
- [CrewAI Tasks Documentation](https://github.com/joaomdmoura/crewAI/blob/main/docs/task.md)
- [Asynchronous Programming in Python](https://docs.python.org/3/library/asyncio.html)
- [Pydantic Documentation](https://docs.pydantic.dev/)
