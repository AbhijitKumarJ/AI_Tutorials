# Lesson 9: Memory Systems and State Management

## Lesson Overview
In this lesson, we'll dive deep into CrewAI's memory systems and state management capabilities. We'll explore how to implement various types of memory, manage state across tasks and agents, and optimize memory performance using different embedding providers.

## File Structure
```
project_root/
│
├── memory_examples/
│   ├── short_term_memory.py
│   ├── long_term_memory.py
│   ├── entity_memory.py
│   ├── state_management.py
│   └── custom_storage.py
│
├── config/
│   └── memory_config.yaml
│
├── requirements.txt
└── main.py
```

## 1. Understanding CrewAI's Memory Components

CrewAI's memory system is designed to enhance the capabilities of AI agents by allowing them to retain and utilize information across interactions. The main components are:

- Short-term Memory: Temporarily stores recent interactions and outcomes.
- Long-term Memory: Preserves valuable insights and learnings from past executions.
- Entity Memory: Captures and organizes information about specific entities encountered during tasks.
- Contextual Memory: Maintains the context of interactions by combining short-term, long-term, and entity memory.

Let's explore each of these in detail.

## 2. Implementing Short-term Memory

Short-term memory in CrewAI uses RAG (Retrieval-Augmented Generation) to store and retrieve recent information. Here's how to implement it:

```python
# memory_examples/short_term_memory.py
from crewai import Agent, Task, Crew
from crewai.memory import ShortTermMemory

# Initialize short-term memory
short_term_memory = ShortTermMemory()

# Create an agent with short-term memory
agent = Agent(
    role="Researcher",
    goal="Conduct research on AI topics",
    backstory="You are an AI researcher with expertise in machine learning",
    memory=short_term_memory
)

# Create a task
task = Task(
    description="Research the latest advancements in natural language processing",
    agent=agent
)

# Create a crew with memory enabled
crew = Crew(
    agents=[agent],
    tasks=[task],
    memory=True
)

# Run the crew
result = crew.kickoff()
print(result)
```

## 3. Implementing Long-term Memory

Long-term memory allows agents to retain information across multiple executions. Here's an example:

```python
# memory_examples/long_term_memory.py
from crewai import Agent, Task, Crew
from crewai.memory import LongTermMemory

# Initialize long-term memory
long_term_memory = LongTermMemory()

# Create an agent with long-term memory
agent = Agent(
    role="Data Analyst",
    goal="Analyze historical data trends",
    backstory="You are a data analyst with years of experience in pattern recognition",
    memory=long_term_memory
)

# Create a task
task = Task(
    description="Analyze stock market trends over the past decade",
    agent=agent
)

# Create a crew with memory enabled
crew = Crew(
    agents=[agent],
    tasks=[task],
    memory=True
)

# Run the crew multiple times to demonstrate long-term memory
for _ in range(3):
    result = crew.kickoff()
    print(result)
```

## 4. Utilizing Entity Memory

Entity memory helps agents remember specific entities and their attributes. Here's how to implement it:

```python
# memory_examples/entity_memory.py
from crewai import Agent, Task, Crew
from crewai.memory import EntityMemory

# Initialize entity memory
entity_memory = EntityMemory()

# Create an agent with entity memory
agent = Agent(
    role="Customer Service Representative",
    goal="Provide personalized customer support",
    backstory="You are a customer service expert with a knack for remembering customer details",
    memory=entity_memory
)

# Create a task
task = Task(
    description="Assist a returning customer with their inquiry",
    agent=agent
)

# Create a crew with memory enabled
crew = Crew(
    agents=[agent],
    tasks=[task],
    memory=True
)

# Run the crew
result = crew.kickoff()
print(result)
```

## 5. Managing State Across Tasks and Agents

State management is crucial for maintaining consistency across multiple tasks and agents. Here's an example of how to implement state management:

```python
# memory_examples/state_management.py
from crewai import Agent, Task, Crew
from crewai.memory import CrewState

# Initialize crew state
crew_state = CrewState()

# Create agents
researcher = Agent(
    role="Researcher",
    goal="Gather information on AI trends",
    backstory="You are an AI research specialist",
    state=crew_state
)

analyst = Agent(
    role="Data Analyst",
    goal="Analyze AI trend data",
    backstory="You are a data analyst specializing in AI market trends",
    state=crew_state
)

# Create tasks
research_task = Task(
    description="Research current AI trends in the market",
    agent=researcher
)

analysis_task = Task(
    description="Analyze the gathered AI trend data",
    agent=analyst
)

# Create a crew with shared state
crew = Crew(
    agents=[researcher, analyst],
    tasks=[research_task, analysis_task],
    state=crew_state
)

# Run the crew
result = crew.kickoff()
print(result)
```

## 6. Configuring Different Embedding Providers

CrewAI supports various embedding providers for memory systems. Here's how to configure different providers:

```yaml
# config/memory_config.yaml
embeddings:
  openai:
    provider: "openai"
    model: "text-embedding-ada-002"
  
  google:
    provider: "google"
    model: "models/embedding-001"
    task_type: "retrieval_document"

  custom:
    provider: "custom"
    model_path: "/path/to/custom/model"
```

To use these configurations in your code:

```python
# main.py
import yaml
from crewai import Agent, Crew
from crewai.memory import ShortTermMemory

# Load embedding configurations
with open('config/memory_config.yaml', 'r') as file:
    config = yaml.safe_load(file)

# Initialize memory with specific embedding provider
memory = ShortTermMemory(embeddings=config['embeddings']['openai'])

# Create an agent with the configured memory
agent = Agent(
    role="AI Researcher",
    goal="Conduct cutting-edge AI research",
    backstory="You are a leading AI researcher pushing the boundaries of machine learning",
    memory=memory
)

# Create a crew with the agent
crew = Crew(
    agents=[agent],
    tasks=[...],  # Define your tasks here
    memory=True
)

# Run the crew
result = crew.kickoff()
print(result)
```

## 7. Implementing Custom Storage Solutions

For advanced use cases, you might want to implement a custom storage solution for memory persistence. Here's an example using SQLite:

```python
# memory_examples/custom_storage.py
import sqlite3
from crewai.memory import BaseMemoryStorage

class SQLiteMemoryStorage(BaseMemoryStorage):
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS memory
            (key TEXT PRIMARY KEY, value TEXT)
        ''')
        self.conn.commit()

    def get(self, key):
        self.cursor.execute("SELECT value FROM memory WHERE key = ?", (key,))
        result = self.cursor.fetchone()
        return result[0] if result else None

    def set(self, key, value):
        self.cursor.execute("INSERT OR REPLACE INTO memory (key, value) VALUES (?, ?)",
                            (key, value))
        self.conn.commit()

    def delete(self, key):
        self.cursor.execute("DELETE FROM memory WHERE key = ?", (key,))
        self.conn.commit()

# Usage
custom_storage = SQLiteMemoryStorage('memory.db')
memory = ShortTermMemory(storage=custom_storage)

agent = Agent(
    role="Data Scientist",
    goal="Analyze large datasets efficiently",
    backstory="You are a data scientist with expertise in big data analytics",
    memory=memory
)

# ... (continue with crew and task creation)
```

## Conclusion

In this lesson, we've explored CrewAI's memory systems and state management capabilities in depth. We've covered how to implement short-term, long-term, and entity memory, manage state across tasks and agents, configure different embedding providers, and even create custom storage solutions.

By leveraging these memory and state management features, you can create more intelligent and context-aware AI agents that can retain information and make better decisions over time.

## Exercises

1. Implement a crew with multiple agents that share information using short-term memory.
2. Create a long-running task that demonstrates the benefits of long-term memory across multiple executions.
3. Build a customer support bot that uses entity memory to remember customer preferences and past interactions.
4. Implement a custom embedding provider and use it with CrewAI's memory systems.
5. Create a complex workflow that requires state management across multiple agents and tasks.

## Additional Resources

- CrewAI Memory Documentation: [Link to official docs]
- Embeddings in NLP: A Comprehensive Guide: [Link to resource]
- State Management Patterns in AI Systems: [Link to article]
- Advanced RAG Techniques for AI Memory Systems: [Link to tutorial]

