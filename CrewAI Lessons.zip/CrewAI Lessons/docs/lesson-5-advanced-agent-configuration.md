# Lesson 5: Advanced Agent Configuration

## Lesson Objectives
By the end of this lesson, students will be able to:
1. Customize agent attributes for optimal performance
2. Implement and integrate various tools and language models
3. Manage delegation and autonomy between agents
4. Optimize agent performance using caching and rate limiting
5. Configure agent memory and context window management
6. Implement custom prompt templates and system messages

## File Structure
```
project_root/
│
├── agents/
│   ├── __init__.py
│   ├── custom_agent.py
│   └── agent_config.py
│
├── tools/
│   ├── __init__.py
│   └── custom_tools.py
│
├── templates/
│   ├── prompts.py
│   └── system_messages.py
│
├── main.py
└── requirements.txt
```

## 1. Customizing Agent Attributes

Agents in CrewAI can be fine-tuned using various attributes to optimize their performance and behavior. Let's explore the key customizable attributes:

```python
# agents/custom_agent.py
from crewai import Agent

custom_agent = Agent(
    role="Data Analyst",
    goal="Analyze complex datasets and provide insights",
    backstory="You are a seasoned data analyst with 10 years of experience in big data.",
    verbose=True,
    allow_delegation=True,
    max_iter=10,
    max_rpm=30,
    memory=True,
    cache=True
)
```

- `verbose`: When set to `True`, provides detailed logs of the agent's actions and thought processes.
- `allow_delegation`: Enables the agent to delegate tasks to other agents when set to `True`.
- `max_iter`: Limits the maximum number of iterations an agent can perform for a single task.
- `max_rpm`: Sets the maximum number of requests per minute to avoid rate limiting issues.
- `memory`: Enables the agent to retain information across tasks when set to `True`.
- `cache`: Allows the agent to cache results for improved performance.

## 2. Implementing Tools and LLM Integration

CrewAI agents can be equipped with various tools and integrated with different language models to enhance their capabilities.

### Tool Implementation

```python
# tools/custom_tools.py
from crewai_tools import BaseTool

class AdvancedDataAnalysisTool(BaseTool):
    name: str = "Advanced Data Analysis Tool"
    description: str = "Performs complex data analysis using machine learning algorithms."

    def _run(self, data: str) -> str:
        # Implement advanced data analysis logic here
        return "Analysis results"

# agents/custom_agent.py
from crewai import Agent
from tools.custom_tools import AdvancedDataAnalysisTool

data_analyst = Agent(
    role="Data Analyst",
    goal="Perform advanced data analysis",
    backstory="Expert in machine learning and data science",
    tools=[AdvancedDataAnalysisTool()],
)
```

### LLM Integration

CrewAI supports various LLM providers. Here's an example of integrating with OpenAI's GPT-4:

```python
# agents/agent_config.py
from crewai import Agent
from langchain_openai import ChatOpenAI

gpt4_agent = Agent(
    role="AI Researcher",
    goal="Conduct cutting-edge AI research",
    backstory="You are at the forefront of AI development.",
    llm=ChatOpenAI(model="gpt-4"),
)
```

## 3. Handling Delegation and Autonomy

CrewAI agents can be configured to work collaboratively, delegating tasks when necessary:

```python
# main.py
from crewai import Agent, Crew, Task

researcher = Agent(
    role="Researcher",
    goal="Gather and analyze data",
    allow_delegation=True,
)

writer = Agent(
    role="Writer",
    goal="Create compelling content",
    allow_delegation=True,
)

research_task = Task(
    description="Conduct in-depth research on AI trends",
    agent=researcher,
)

writing_task = Task(
    description="Write a comprehensive report on AI trends",
    agent=writer,
)

crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, writing_task],
    process="hierarchical",  # Enables more complex task delegation
)

result = crew.kickoff()
```

## 4. Optimizing Performance with Caching and RPM Limits

Implement caching and rate limiting to optimize agent performance:

```python
# agents/agent_config.py
from crewai import Agent

optimized_agent = Agent(
    role="Fast Responder",
    goal="Provide quick and accurate responses",
    cache=True,  # Enable result caching
    max_rpm=60,  # Set maximum requests per minute
)
```

## 5. Configuring Agent Memory and Context Window Management

Enhance agent capabilities with memory configuration:

```python
# agents/agent_config.py
from crewai import Agent, Crew

agent_with_memory = Agent(
    role="Historian",
    goal="Maintain and recall historical context",
    memory=True,
)

crew_with_memory = Crew(
    agents=[agent_with_memory],
    tasks=[...],
    memory=True,
    respect_context_window=True,
)
```

The `respect_context_window=True` setting ensures that the agent maintains context within the limits of the LLM's context window.

## 6. Implementing Custom Prompt Templates and System Messages

Customize agent behavior with specific prompts and system messages:

```python
# templates/prompts.py
CUSTOM_PROMPT_TEMPLATE = """
You are a {role} with the goal to {goal}.
Your backstory: {backstory}

Current task: {task}

Please provide your response:
"""

# templates/system_messages.py
CUSTOM_SYSTEM_MESSAGE = """
You are an AI agent designed to {goal}. Always maintain a professional tone and focus on accuracy.
"""

# agents/custom_agent.py
from crewai import Agent
from templates.prompts import CUSTOM_PROMPT_TEMPLATE
from templates.system_messages import CUSTOM_SYSTEM_MESSAGE

customized_agent = Agent(
    role="Customer Support Specialist",
    goal="Provide exceptional customer service",
    backstory="You have 5 years of experience in high-end retail customer support.",
    prompt_template=CUSTOM_PROMPT_TEMPLATE,
    system_template=CUSTOM_SYSTEM_MESSAGE,
)
```

## Practical Exercise

Create a CrewAI project that implements a team of agents with advanced configurations:

1. A research agent with custom tools and GPT-4 integration
2. A data analysis agent with optimized performance settings
3. A report writing agent with custom prompt templates

Ensure the agents can delegate tasks and use memory effectively to complete a complex analysis and reporting task.

## Conclusion

In this lesson, we've explored advanced agent configuration techniques in CrewAI. By mastering these concepts, you can create highly customized and efficient AI agents capable of handling complex tasks and workflows. Remember to experiment with different configurations to find the optimal setup for your specific use cases.

## Additional Resources
- [CrewAI Official Documentation](https://github.com/joaomdmoura/crewAI)
- [LangChain Integration Guide](https://python.langchain.com/docs/integrations/crewai)
- [OpenAI API Documentation](https://platform.openai.com/docs/api-reference)
