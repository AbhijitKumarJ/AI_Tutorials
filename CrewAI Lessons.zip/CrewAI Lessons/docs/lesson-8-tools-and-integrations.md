# Lesson 8: Tools and Integrations

## Lesson Objectives
By the end of this lesson, students will be able to:
1. Understand and utilize built-in CrewAI tools
2. Integrate external tools (LangChain, LlamaIndex) with CrewAI
3. Create custom tools for specific needs
4. Apply best practices for tool selection and usage
5. Implement tool caching and error handling
6. Explore advanced tool features (delegation, forced output)

## File Structure
```
project_root/
│
├── tools/
│   ├── __init__.py
│   ├── built_in_tools.py
│   ├── langchain_tools.py
│   ├── llamaindex_tools.py
│   └── custom_tools.py
│
├── agents/
│   ├── __init__.py
│   └── tool_using_agents.py
│
├── utils/
│   ├── __init__.py
│   ├── tool_cache.py
│   └── error_handler.py
│
├── main.py
└── requirements.txt
```

## 1. Built-in CrewAI Tools

CrewAI provides a set of built-in tools that can be easily integrated into your agents. Let's explore some of these tools:

```python
# tools/built_in_tools.py
from crewai_tools import (
    FileReadTool,
    DirectoryReadTool,
    SerperDevTool,
    WebsiteSearchTool,
    CSVSearchTool
)

# File reading tool
file_reader = FileReadTool()

# Directory reading tool
dir_reader = DirectoryReadTool()

# Web search tool using Serper API
web_searcher = SerperDevTool()

# Website content search tool
website_searcher = WebsiteSearchTool()

# CSV search tool
csv_searcher = CSVSearchTool()

# agents/tool_using_agents.py
from crewai import Agent
from tools.built_in_tools import file_reader, web_searcher

researcher = Agent(
    role="Research Specialist",
    goal="Gather comprehensive information on given topics",
    backstory="You are an expert researcher with access to various information sources.",
    tools=[file_reader, web_searcher]
)
```

These built-in tools provide a solid foundation for common tasks like file operations, web searching, and data analysis.

## 2. Integrating External Tools (LangChain, LlamaIndex)

CrewAI can be extended with tools from other libraries like LangChain and LlamaIndex:

```python
# tools/langchain_tools.py
from langchain.agents import load_tools
from langchain.llms import OpenAI

llm = OpenAI(temperature=0)
langchain_tools = load_tools(["wikipedia", "llm-math"], llm=llm)

# tools/llamaindex_tools.py
from llama_index import GPTVectorStoreIndex, SimpleDirectoryReader
from crewai_tools import LlamaIndexTool

documents = SimpleDirectoryReader('data').load_data()
index = GPTVectorStoreIndex.from_documents(documents)
llamaindex_tool = LlamaIndexTool.from_vector_store(index, "Knowledgebase Lookup", "Search the company knowledgebase")

# agents/tool_using_agents.py
from crewai import Agent
from tools.langchain_tools import langchain_tools
from tools.llamaindex_tools import llamaindex_tool

advanced_researcher = Agent(
    role="Advanced Research Specialist",
    goal="Conduct in-depth research using a variety of sources and tools",
    backstory="You are a highly skilled researcher with access to advanced research tools and databases.",
    tools=[*langchain_tools, llamaindex_tool]
)
```

By integrating these external tools, you can significantly enhance the capabilities of your CrewAI agents.

## 3. Creating Custom Tools

For specific needs, you can create custom tools:

```python
# tools/custom_tools.py
from crewai_tools import BaseTool
import requests

class WeatherTool(BaseTool):
    name = "Weather Information Tool"
    description = "Get current weather information for a specific location"

    def _run(self, location: str) -> str:
        api_key = "your_weather_api_key"
        base_url = "http://api.openweathermap.org/data/2.5/weather"
        
        params = {
            "q": location,
            "appid": api_key,
            "units": "metric"
        }
        
        response = requests.get(base_url, params=params)
        data = response.json()
        
        if response.status_code == 200:
            temp = data["main"]["temp"]
            description = data["weather"][0]["description"]
            return f"The current weather in {location} is {description} with a temperature of {temp}°C."
        else:
            return f"Unable to fetch weather information for {location}."

# agents/tool_using_agents.py
from crewai import Agent
from tools.custom_tools import WeatherTool

weather_reporter = Agent(
    role="Weather Reporter",
    goal="Provide accurate and timely weather information",
    backstory="You are a meteorologist with years of experience in weather forecasting.",
    tools=[WeatherTool()]
)
```

Custom tools allow you to extend CrewAI's functionality to meet your specific project requirements.

## 4. Best Practices for Tool Selection and Usage

When selecting and using tools in CrewAI, consider the following best practices:

1. **Relevance**: Choose tools that are directly relevant to the agent's role and tasks.
2. **Efficiency**: Prefer tools that can perform tasks quickly and with minimal resource usage.
3. **Reliability**: Use tools from trusted sources and with good documentation.
4. **Scalability**: Consider how well the tools will perform as your project grows.
5. **Integration**: Ensure that the tools can be easily integrated into your CrewAI workflow.

Example of applying these practices:

```python
# main.py
from crewai import Crew, Task
from agents.tool_using_agents import researcher, advanced_researcher, weather_reporter

research_task = Task(
    description="Research the impact of climate change on weather patterns in major cities",
    agent=advanced_researcher
)

weather_report_task = Task(
    description="Provide a weather report for New York, London, and Tokyo",
    agent=weather_reporter
)

climate_crew = Crew(
    agents=[advanced_researcher, weather_reporter],
    tasks=[research_task, weather_report_task]
)

result = climate_crew.kickoff()
```

## 5. Implementing Tool Caching and Error Handling

To optimize performance and improve reliability, implement caching and error handling for your tools:

```python
# utils/tool_cache.py
from functools import lru_cache

@lru_cache(maxsize=100)
def cached_tool_execution(tool, *args, **kwargs):
    return tool._run(*args, **kwargs)

# utils/error_handler.py
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def handle_tool_error(tool_name, error):
    logger.error(f"Error occurred while using {tool_name}: {str(error)}")
    return f"An error occurred while using {tool_name}. Please try again later."

# tools/custom_tools.py
from crewai_tools import BaseTool
from utils.tool_cache import cached_tool_execution
from utils.error_handler import handle_tool_error

class CachedWeatherTool(BaseTool):
    name = "Cached Weather Information Tool"
    description = "Get current weather information for a specific location with caching"

    def _run(self, location: str) -> str:
        try:
            return cached_tool_execution(self._fetch_weather, location)
        except Exception as e:
            return handle_tool_error(self.name, e)

    def _fetch_weather(self, location: str) -> str:
        # Implement the weather fetching logic here
        pass
```

By implementing caching and error handling, you can improve the performance and reliability of your tools.

## 6. Advanced Tool Features (Delegation, Forced Output)

CrewAI supports advanced features like tool delegation and forced output:

```python
# tools/custom_tools.py
from crewai_tools import BaseTool

class DelegatingTool(BaseTool):
    name = "Task Delegation Tool"
    description = "Delegate tasks to other agents in the crew"

    def _run(self, task: str, agent_role: str) -> str:
        # Implement logic to delegate the task to the specified agent
        return f"Task '{task}' delegated to {agent_role}"

class ForcedOutputTool(BaseTool):
    name = "Forced Output Tool"
    description = "Force a specific output for a task"

    def _run(self, output: str) -> str:
        return output

# agents/tool_using_agents.py
from crewai import Agent
from tools.custom_tools import DelegatingTool, ForcedOutputTool

manager_agent = Agent(
    role="Project Manager",
    goal="Oversee project execution and delegate tasks efficiently",
    backstory="You are an experienced project manager known for your delegation skills.",
    tools=[DelegatingTool()]
)

quality_control_agent = Agent(
    role="Quality Control Specialist",
    goal="Ensure all outputs meet the required standards",
    backstory="You have a keen eye for detail and the authority to enforce quality standards.",
    tools=[ForcedOutputTool()]
)
```

These advanced features allow for more complex and flexible workflows in your CrewAI projects.

## Practical Exercise

Create a CrewAI project that incorporates various tools and integrations:

1. Develop a research crew that uses built-in tools, LangChain tools, and a custom tool.
2. Implement caching and error handling for all tools.
3. Create a manager agent that can delegate tasks to other agents using the DelegatingTool.
4. Use the ForcedOutputTool with a quality control agent to ensure outputs meet certain criteria.
5. Design a workflow that demonstrates the effective use of all these tools and features.

## Conclusion

In this lesson, we've explored the wide range of tools and integrations available in CrewAI. By leveraging built-in tools, integrating external libraries, and creating custom tools, you can significantly enhance the capabilities of your AI agents. Remember to apply best practices in tool selection and usage, implement caching and error handling for improved performance, and explore advanced features like delegation and forced output to create more sophisticated AI workflows.

## Additional Resources
- [CrewAI Tools Documentation](https://github.com/joaomdmoura/crewAI-tools)
- [LangChain Tools Documentation](https://python.langchain.com/docs/modules/agents/tools/)
- [LlamaIndex Documentation](https://gpt-index.readthedocs.io/en/latest/)
- [Python Caching with functools](https://docs.python.org/3/library/functools.html#functools.lru_cache)
