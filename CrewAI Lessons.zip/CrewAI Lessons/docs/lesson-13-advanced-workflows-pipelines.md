# Lesson 13: Advanced Workflows and Pipelines

## Lesson Overview
In this lesson, we'll explore how to create complex, multi-stage AI workflows with CrewAI. We'll cover implementing conditional logic in pipelines, using routers for dynamic task allocation, optimizing performance in large-scale projects, implementing error recovery and retry mechanisms, and creating reusable workflow templates.

## File Structure
```
project_root/
│
├── workflows/
│   ├── multi_stage_workflow.py
│   ├── conditional_pipeline.py
│   └── dynamic_router.py
│
├── optimizations/
│   ├── caching.py
│   └── distributed_processing.py
│
├── error_handling/
│   └── retry_mechanism.py
│
├── templates/
│   └── reusable_workflow.py
│
├── config/
│   └── workflow_config.yaml
│
├── requirements.txt
└── main.py
```

## 1. Creating Complex, Multi-stage AI Workflows

Let's start by creating a complex, multi-stage workflow using CrewAI:

```python
# workflows/multi_stage_workflow.py
from crewai import Agent, Task, Crew, Process

class DataAnalysisWorkflow:
    def __init__(self):
        self.data_collector = Agent(
            role="Data Collector",
            goal="Collect and prepare data for analysis",
            backstory="You are an expert in data collection and preparation"
        )
        
        self.data_analyst = Agent(
            role="Data Analyst",
            goal="Analyze data and extract insights",
            backstory="You are a skilled data analyst with expertise in statistical analysis"
        )
        
        self.report_writer = Agent(
            role="Report Writer",
            goal="Create comprehensive reports based on data analysis",
            backstory="You are a professional report writer with a knack for clear communication"
        )

    def run(self, dataset_url):
        collect_task = Task(
            description=f"Collect and prepare data from {dataset_url}",
            agent=self.data_collector
        )

        analyze_task = Task(
            description="Perform statistical analysis on the collected data",
            agent=self.data_analyst
        )

        report_task = Task(
            description="Create a comprehensive report based on the data analysis",
            agent=self.report_writer
        )

        crew = Crew(
            agents=[self.data_collector, self.data_analyst, self.report_writer],
            tasks=[collect_task, analyze_task, report_task],
            process=Process.sequential
        )

        result = crew.kickoff()
        return result

# main.py
from workflows.multi_stage_workflow import DataAnalysisWorkflow

workflow = DataAnalysisWorkflow()
result = workflow.run("https://example.com/dataset.csv")
print(result)
```

## 2. Implementing Conditional Logic in Pipelines

Now, let's implement a pipeline with conditional logic:

```python
# workflows/conditional_pipeline.py
from crewai import Agent, Task, Crew, Process

class ConditionalPipeline:
    def __init__(self):
        self.data_validator = Agent(
            role="Data Validator",
            goal="Validate data quality and completeness",
            backstory="You are a meticulous data quality expert"
        )
        
        self.data_cleaner = Agent(
            role="Data Cleaner",
            goal="Clean and preprocess data",
            backstory="You are skilled in data cleaning and preprocessing techniques"
        )
        
        self.data_analyzer = Agent(
            role="Data Analyzer",
            goal="Perform in-depth data analysis",
            backstory="You are an experienced data analyst"
        )

    def run(self, dataset_url):
        validation_task = Task(
            description=f"Validate the data from {dataset_url}",
            agent=self.data_validator
        )

        crew = Crew(
            agents=[self.data_validator, self.data_cleaner, self.data_analyzer],
            tasks=[validation_task],
            process=Process.sequential
        )

        validation_result = crew.kickoff()

        if "VALID" in validation_result.upper():
            analysis_task = Task(
                description="Perform in-depth analysis on the validated data",
                agent=self.data_analyzer
            )
            crew.tasks = [analysis_task]
            return crew.kickoff()
        else:
            cleaning_task = Task(
                description="Clean and preprocess the invalid data",
                agent=self.data_cleaner
            )
            crew.tasks = [cleaning_task]
            cleaning_result = crew.kickoff()
            
            analysis_task = Task(
                description="Perform in-depth analysis on the cleaned data",
                agent=self.data_analyzer
            )
            crew.tasks = [analysis_task]
            return crew.kickoff()

# main.py
from workflows.conditional_pipeline import ConditionalPipeline

pipeline = ConditionalPipeline()
result = pipeline.run("https://example.com/dataset.csv")
print(result)
```

## 3. Using Routers for Dynamic Task Allocation

Let's implement a router for dynamic task allocation:

```python
# workflows/dynamic_router.py
from crewai import Agent, Task, Crew, Process

class TaskRouter:
    def __init__(self):
        self.text_analyzer = Agent(
            role="Text Analyzer",
            goal="Analyze and process textual data",
            backstory="You are an expert in natural language processing"
        )
        
        self.image_analyzer = Agent(
            role="Image Analyzer",
            goal="Analyze and process image data",
            backstory="You are skilled in computer vision and image processing"
        )
        
        self.numerical_analyzer = Agent(
            role="Numerical Analyzer",
            goal="Analyze and process numerical data",
            backstory="You are an expert in statistical analysis of numerical data"
        )

    def route_task(self, data_type, data):
        if data_type == "text":
            task = Task(
                description=f"Analyze the following text data: {data[:100]}...",
                agent=self.text_analyzer
            )
        elif data_type == "image":
            task = Task(
                description=f"Analyze the image at URL: {data}",
                agent=self.image_analyzer
            )
        elif data_type == "numerical":
            task = Task(
                description=f"Perform statistical analysis on the numerical data: {data[:100]}...",
                agent=self.numerical_analyzer
            )
        else:
            raise ValueError(f"Unsupported data type: {data_type}")

        crew = Crew(
            agents=[self.text_analyzer, self.image_analyzer, self.numerical_analyzer],
            tasks=[task],
            process=Process.sequential
        )

        return crew.kickoff()

# main.py
from workflows.dynamic_router import TaskRouter

router = TaskRouter()

text_result = router.route_task("text", "This is a sample text for analysis.")
image_result = router.route_task("image", "https://example.com/image.jpg")
numerical_result = router.route_task("numerical", "[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]")

print("Text Analysis Result:", text_result)
print("Image Analysis Result:", image_result)
print("Numerical Analysis Result:", numerical_result)
```

## 4. Optimizing Performance in Large-scale Projects

For large-scale projects, we can implement caching and distributed processing:

```python
# optimizations/caching.py
import hashlib
import pickle
from functools import wraps

def cache_result(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Create a unique key based on function name and arguments
        key = hashlib.md5(f"{func.__name__}{str(args)}{str(kwargs)}".encode()).hexdigest()
        
        try:
            with open(f"cache/{key}.pkl", "rb") as f:
                return pickle.load(f)
        except FileNotFoundError:
            result = func(*args, **kwargs)
            with open(f"cache/{key}.pkl", "wb") as f:
                pickle.dump(result, f)
            return result
    return wrapper

# optimizations/distributed_processing.py
from multiprocessing import Pool

def distributed_process(func, data_list, num_processes=4):
    with Pool(num_processes) as p:
        results = p.map(func, data_list)
    return results

# Example usage in a CrewAI agent
from crewai import Agent, Task

class OptimizedAgent(Agent):
    @cache_result
    def expensive_operation(self, data):
        # Simulating an expensive operation
        import time
        time.sleep(5)
        return f"Processed: {data}"

    def process_batch(self, data_list):
        return distributed_process(self.expensive_operation, data_list)

# main.py
optimized_agent = OptimizedAgent(
    role="Optimized Processor",
    goal="Process large amounts of data efficiently",
    backstory="You are an AI optimized for high-performance data processing"
)

task = Task(
    description="Process this list of data efficiently: ['data1', 'data2', 'data3', 'data4']",
    agent=optimized_agent
)

crew = Crew(agents=[optimized_agent], tasks=[task])
result = crew.kickoff()
print(result)
```

## 5. Implementing Error Recovery and Retry Mechanisms

Let's implement a retry mechanism for error recovery:

```python
# error_handling/retry_mechanism.py
import time
from functools import wraps

def retry(max_attempts=3, delay=1):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            attempts = 0
            while attempts < max_attempts:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    attempts += 1
                    if attempts == max_attempts:
                        raise e
                    time.sleep(delay)
        return wrapper
    return decorator

# Example usage in a CrewAI agent
from crewai import Agent, Task

class ReliableAgent(Agent):
    @retry(max_attempts=3, delay=2)
    def unstable_operation(self, data):
        # Simulating an unstable operation that might fail
        import random
        if random.random() < 0.5:
            raise Exception("Random failure occurred")
        return f"Successfully processed: {data}"

# main.py
reliable_agent = ReliableAgent(
    role="Reliable Processor",
    goal="Process data with high reliability",
    backstory="You are an AI designed to handle unstable operations reliably"
)

task = Task(
    description="Process this potentially unstable data: 'sensitive_data'",
    agent=reliable_agent
)

crew = Crew(agents=[reliable_agent], tasks=[task])
result = crew.kickoff()
print(result)
```

## 6. Creating Reusable Workflow Templates

Finally, let's create a reusable workflow template:

```python
# templates/reusable_workflow.py
from crewai import Agent, Task, Crew, Process

class ReusableWorkflow:
    def __init__(self, stages):
        self.stages = stages
        self.agents = {}
        self.tasks = []

    def add_agent(self, stage, agent):
        if stage not in self.stages:
            raise ValueError(f"Invalid stage: {stage}")
        self.agents[stage] = agent

    def add_task(self, stage, description):
        if stage not in self.stages:
            raise ValueError(f"Invalid stage: {stage}")
        if stage not in self.agents:
            raise ValueError(f"No agent defined for stage: {stage}")
        self.tasks.append(Task(description=description, agent=self.agents[stage]))

    def run(self):
        crew = Crew(
            agents=list(self.agents.values()),
            tasks=self.tasks,
            process=Process.sequential
        )
        return crew.kickoff()

# Example usage
# main.py
workflow = ReusableWorkflow(['collect', 'analyze', 'report'])

collector = Agent(
    role="Data Collector",
    goal="Collect data efficiently",
    backstory="You are an expert in data collection"
)
workflow.add_agent('collect', collector)

analyst = Agent(
    role="Data Analyst",
    goal="Analyze data thoroughly",
    backstory="You are a skilled data analyst"
)
workflow.add_agent('analyze', analyst)

reporter = Agent(
    role="Report Writer",
    goal="Create clear and concise reports",
    backstory="You are a professional report writer"
)
workflow.add_agent('report', reporter)

workflow.add_task('collect', "Collect data from https://example.com/api")
workflow.add_task('analyze', "Perform statistical analysis on the collected data")
workflow.add_task('report', "Create a comprehensive report based on the analysis")

result = workflow.run()
print(result)
```

## Conclusion

In this lesson, we've explored advanced workflows and pipelines in CrewAI. We've covered creating complex multi-stage workflows, implementing conditional logic, using routers for dynamic task allocation, optimizing performance with caching and distributed processing, implementing error recovery mechanisms, and creating reusable workflow templates.

These advanced techniques allow you to build sophisticated, efficient, and reliable AI systems using CrewAI. By leveraging these concepts, you can create workflows that are not only powerful but also flexible and maintainable.

## Exercises

1. Create a multi-stage workflow that involves data collection, preprocessing, analysis, and visualization. Use conditional logic to determine whether data cleaning is necessary based on a quality check.

2. Implement a dynamic router that can handle various types of data (text, image, audio) and route them to appropriate specialized agents for processing.

3. Optimize a large-scale data processing pipeline by implementing caching for expensive operations and using distributed processing for batch tasks.

4. Develop a fault-tolerant workflow that can recover from common errors (e.g., network failures, API rate limits) using retry mechanisms and error handling.

5. Design a reusable workflow template for a common business process (e.g., customer onboarding, product recommendation, sentiment analysis) that can be easily customized for different use cases.

## Additional Resources

- CrewAI Documentation on Advanced Workflows: [Link to docs]
- "Building Machine Learning Pipelines" by Hannes Hapke & Catherine Nelson: [Book Link]
- "Designing Data-Intensive Applications" by Martin Kleppmann: [Book Link]
- Apache Airflow Documentation (for inspiration on workflow management): [https://airflow.apache.org/docs/](https://airflow.apache.org/docs/)
- Luigi Documentation (another workflow management tool): [https://luigi.readthedocs.io/en/stable/](https://luigi.readthedocs.io/en/stable/)

Remember that when building complex workflows and pipelines, it's important to consider factors such as modularity, scalability, and maintainability. Always test your workflows thoroughly and monitor their performance in production environments. Happy building with CrewAI!

