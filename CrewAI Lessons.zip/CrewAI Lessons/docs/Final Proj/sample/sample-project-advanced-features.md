## Phase 2 (Continued): Advanced Features and Integrations

### Week 3: Advanced Development

1. Implement Hierarchical Process

Create a manager agent to orchestrate the news analysis process:

```python
# src/agents/manager_agent.py
from crewai import Agent
from src.tasks.collect_news_task import CollectNewsTask
from src.tasks.analyze_sentiment_task import AnalyzeSentimentTask
from src.tasks.identify_trends_task import IdentifyTrendsTask
from src.tasks.generate_summary_task import GenerateSummaryTask

class ManagerAgent(Agent):
    def __init__(self):
        super().__init__(
            name="News Analysis Manager",
            role="Orchestrate the news analysis process",
            goal="Ensure efficient and comprehensive news analysis",
            backstory="I am an AI manager responsible for coordinating various agents to produce high-quality news analysis.",
            verbose=True
        )

    def analyze_news(self, topics, timeframe):
        collect_task = CollectNewsTask()
        sentiment_task = AnalyzeSentimentTask()
        trends_task = IdentifyTrendsTask()
        summary_task = GenerateSummaryTask()

        news = self.execute_task(collect_task, topics=topics, timeframe=timeframe)
        sentiment = self.execute_task(sentiment_task, news=news)
        trends = self.execute_task(trends_task, news=news)
        summary = self.execute_task(summary_task, news=news, sentiment=sentiment, trends=trends)

        return summary
```

2. Implement Task Delegation

Example of task delegation in the Trend Identifier Agent:

```python
# src/agents/trend_identifier.py
from crewai import Agent
from crewai_tools import NLPTool, DatabaseTool

class TrendIdentifierAgent(Agent):
    def __init__(self):
        super().__init__(
            name="Trend Identifier",
            role="Identify trends in news data",
            goal="Discover and report on emerging trends across news topics",
            backstory="I am an AI agent specialized in pattern recognition and trend analysis in large datasets.",
            tools=[NLPTool(), DatabaseTool()],
            verbose=True
        )

    def identify_trends(self, news):
        # Delegate topic modeling to NLP tool
        topics = self.tools['NLPTool'].run(news, task="topic_modeling")
        
        # Delegate historical comparison to Database tool
        historical_data = self.tools['DatabaseTool'].run(action="fetch_historical_trends")
        
        # Analyze current topics against historical data
        trends = self.compare_topics(topics, historical_data)
        
        return trends

    def compare_topics(self, current_topics, historical_data):
        # Implementation of trend comparison logic
        pass
```

3. Integrate External APIs

Enhance the News Collector Agent with API integration:

```python
# src/agents/news_collector.py
import requests
from crewai import Agent
from src.config import NEWS_API_KEY, GUARDIAN_API_KEY

class NewsCollectorAgent(Agent):
    def __init__(self):
        super().__init__(
            name="News Collector",
            role="Collect and aggregate news from various sources",
            goal="Provide a comprehensive and diverse set of news articles",
            backstory="I am an AI agent specialized in gathering news from multiple sources efficiently and without bias.",
            verbose=True
        )

    def collect_news(self, topics, timeframe):
        news_api_articles = self._fetch_from_news_api(topics, timeframe)
        guardian_articles = self._fetch_from_guardian(topics, timeframe)
        return news_api_articles + guardian_articles

    def _fetch_from_news_api(self, topics, timeframe):
        url = f"https://newsapi.org/v2/everything?q={topics}&from={timeframe}&sortBy=publishedAt&apiKey={NEWS_API_KEY}"
        response = requests.get(url)
        return response.json()['articles']

    def _fetch_from_guardian(self, topics, timeframe):
        url = f"https://content.guardianapis.com/search?q={topics}&from-date={timeframe}&api-key={GUARDIAN_API_KEY}"
        response = requests.get(url)
        return response.json()['response']['results']
```

4. Develop Memory System

Implement a memory system for the User Preference Manager:

```python
# src/agents/user_preference_manager.py
from crewai import Agent
from crewai_tools import DatabaseTool

class UserPreferenceManagerAgent(Agent):
    def __init__(self):
        super().__init__(
            name="User Preference Manager",
            role="Manage and apply user preferences",
            goal="Personalize news content based on user behavior and explicit preferences",
            backstory="I am an AI agent dedicated to understanding and applying user preferences to enhance the news experience.",
            tools=[DatabaseTool()],
            verbose=True
        )

    def update_user_preferences(self, user_id, interaction_data):
        current_preferences = self.tools['DatabaseTool'].run(action="fetch_user_preferences", user_id=user_id)
        updated_preferences = self._analyze_interaction(current_preferences, interaction_data)
        self.tools['DatabaseTool'].run(action="update_user_preferences", user_id=user_id, preferences=updated_preferences)
        return updated_preferences

    def _analyze_interaction(self, current_preferences, interaction_data):
        # Implementation of preference analysis logic
        pass

    def apply_preferences(self, user_id, news_items):
        preferences = self.tools['DatabaseTool'].run(action="fetch_user_preferences", user_id=user_id)
        personalized_news = self._personalize_news(news_items, preferences)
        return personalized_news

    def _personalize_news(self, news_items, preferences):
        # Implementation of news personalization logic
        pass
```

5. Enhance User Interface

Improve the Flask application with personalized news feeds:

```python
# src/main.py
from flask import Flask, render_template, request, session
from src.agents.manager_agent import ManagerAgent
from src.agents.user_preference_manager import UserPreferenceManagerAgent

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Set a secret key for session management

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/news', methods=['POST'])
def get_news():
    topics = request.form.get('topics')
    user_id = session.get('user_id', 'default_user')  # Use session for user identification
    
    manager = ManagerAgent()
    preference_manager = UserPreferenceManagerAgent()
    
    news_summary = manager.analyze_news(topics, "1d")
    personalized_news = preference_manager.apply_preferences(user_id, news_summary)
    
    # Update user preferences based on this interaction
    preference_manager.update_user_preferences(user_id, {'searched_topics': topics})
    
    return render_template('news.html', summary=personalized_news)

if __name__ == '__main__':
    app.run(debug=True)
```

These advanced features demonstrate the power of CrewAI in creating a sophisticated, multi-agent system that can handle complex tasks such as personalized news aggregation and analysis. The hierarchical