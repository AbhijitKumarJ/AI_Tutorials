## Phase 2 (Continued): Advanced Features and Integrations

### Week 3 (Continued): Advanced Development

6. Implement Logging and Error Handling

Create a custom logger and error handling mechanism:

```python
# src/utils/logger.py
import logging
from logging.handlers import RotatingFileHandler

def setup_logger(name, log_file, level=logging.INFO):
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    
    handler = RotatingFileHandler(log_file, maxBytes=10000000, backupCount=5)
    handler.setFormatter(formatter)
    
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)
    
    return logger

# Usage in other files:
# from src.utils.logger import setup_logger
# logger = setup_logger('agent_name', 'logs/agent_name.log')
```

Implement error handling in the Manager Agent:

```python
# src/agents/manager_agent.py
from src.utils.logger import setup_logger
import traceback

class ManagerAgent(Agent):
    def __init__(self):
        super().__init__(
            name="News Analysis Manager",
            role="Orchestrate the news analysis process",
            goal="Ensure efficient and comprehensive news analysis",
            backstory="I am an AI manager responsible for coordinating various agents to produce high-quality news analysis.",
            verbose=True
        )
        self.logger = setup_logger('manager_agent', 'logs/manager_agent.log')

    def analyze_news(self, topics, timeframe):
        try:
            collect_task = CollectNewsTask()
            sentiment_task = AnalyzeSentimentTask()
            trends_task = IdentifyTrendsTask()
            summary_task = GenerateSummaryTask()

            news = self.execute_task(collect_task, topics=topics, timeframe=timeframe)
            self.logger.info(f"Collected {len(news)} news articles")

            sentiment = self.execute_task(sentiment_task, news=news)
            self.logger.info("Completed sentiment analysis")

            trends = self.execute_task(trends_task, news=news)
            self.logger.info("Identified trends in news data")

            summary = self.execute_task(summary_task, news=news, sentiment=sentiment, trends=trends)
            self.logger.info("Generated final news summary")

            return summary
        except Exception as e:
            self.logger.error(f"Error in analyze_news: {str(e)}")
            self.logger.error(traceback.format_exc())
            raise
```

7. Implement Caching Mechanism

Create a caching decorator for API calls:

```python
# src/utils/cache.py
import functools
import pickle
from datetime import datetime, timedelta

def timed_lru_cache(seconds: int, maxsize: int = 128):
    def wrapper_cache(func):
        func = functools.lru_cache(maxsize=maxsize)(func)
        func.lifetime = timedelta(seconds=seconds)
        func.expiration = datetime.utcnow() + func.lifetime

        @functools.wraps(func)
        def wrapped_func(*args, **kwargs):
            if datetime.utcnow() >= func.expiration:
                func.cache_clear()
                func.expiration = datetime.utcnow() + func.lifetime

            return func(*args, **kwargs)

        return wrapped_func

    return wrapper_cache

# Usage in NewsCollectorAgent:
# from src.utils.cache import timed_lru_cache

class NewsCollectorAgent(Agent):
    # ...

    @timed_lru_cache(seconds=3600)  # Cache API results for 1 hour
    def _fetch_from_news_api(self, topics, timeframe):
        # API call implementation
        pass
```

8. Implement Ethical AI Features

Add a module for detecting potential misinformation:

```python
# src/utils/fact_checker.py
import requests
from src.utils.logger import setup_logger

class FactChecker:
    def __init__(self):
        self.logger = setup_logger('fact_checker', 'logs/fact_checker.log')

    def check_claim(self, claim):
        # This is a placeholder. In a real implementation, you would use a fact-checking API or service
        api_url = "https://factcheckingapi.com/check"
        try:
            response = requests.post(api_url, json={"claim": claim})
            result = response.json()
            self.logger.info(f"Fact check completed for claim: {claim[:50]}...")
            return result['veracity_score']
        except Exception as e:
            self.logger.error(f"Error in fact checking: {str(e)}")
            return None

# Usage in SummaryGeneratorAgent:
from src.utils.fact_checker import FactChecker

class SummaryGeneratorAgent(Agent):
    def __init__(self):
        super().__init__(
            name="Summary Generator",
            role="Generate concise and accurate news summaries",
            goal="Provide users with clear, factual, and unbiased news summaries",
            backstory="I am an AI agent dedicated to distilling complex news into accessible summaries while maintaining accuracy and neutrality.",
            tools=[NLPTool(), FactChecker()],
            verbose=True
        )

    def generate_summary(self, news, sentiment, trends):
        summary = self._create_initial_summary(news, sentiment, trends)
        fact_checker = FactChecker()
        
        for key_point in summary['key_points']:
            veracity_score = fact_checker.check_claim(key_point)
            if veracity_score is not None and veracity_score < 0.7:
                key_point += " (This claim may require further verification)"
        
        return summary
```

9. Finalize User Interface

Enhance the Flask application with error handling and ethical considerations:

```python
# src/main.py
from flask import Flask, render_template, request, session, jsonify
from src.agents.manager_agent import ManagerAgent
from src.agents.user_preference_manager import UserPreferenceManagerAgent
from src.utils.logger import setup_logger

app = Flask(__name__)
app.secret_key = 'your_secret_key'
logger = setup_logger('flask_app', 'logs/flask_app.log')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/news', methods=['POST'])
def get_news():
    try:
        topics = request.form.get('topics')
        user_id = session.get('user_id', 'default_user')
        
        manager = ManagerAgent()
        preference_manager = UserPreferenceManagerAgent()
        
        news_summary = manager.analyze_news(topics, "1d")
        personalized_news = preference_manager.apply_preferences(user_id, news_summary)
        
        preference_manager.update_user_preferences(user_id, {'searched_topics': topics})
        
        return render_template('news.html', summary=personalized_news)
    except Exception as e:
        logger.error(f"Error in get_news: {str(e)}")
        return jsonify({"error": "An error occurred while processing your request"}), 500

@app.route('/feedback', methods=['POST'])
def submit_feedback():
    try:
        feedback = request.form.get('feedback')
        article_id = request.form.get('article_id')
        user_id = session.get('user_id', 'default_user')
        
        preference_manager = UserPreferenceManagerAgent()
        preference_manager.update_user_preferences(user_id, {'feedback': {article_id: feedback}})
        
        return jsonify({"message": "Feedback submitted successfully"}), 200
    except Exception as e:
        logger.error(f"Error in submit_feedback: {str(e)}")
        return jsonify({"error": "An error occurred while submitting feedback"}), 500

if __name__ == '__main__':
    app.run(debug=True)
```

This completes the advanced features and integrations phase of our sample project. We've implemented error handling, logging, caching, ethical AI considerations, and enhanced the user interface. These additions make the AI-Powered News Aggregator and Analyzer more robust, efficient, and responsible in its operations.

The next steps would involve thorough testing, documentation, and preparing for the final presentation. This sample project demonstrates the powerful capabilities of CrewAI in creating a sophisticated, multi-agent system that can handle complex real-world tasks while addressing important concerns such as accuracy, efficiency, and ethical considerations.
