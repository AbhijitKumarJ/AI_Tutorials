# Lesson 4: Creating Your First CrewAI Project

## Lesson Objectives
By the end of this lesson, students will be able to:
1. Set up a basic CrewAI project structure
2. Define agents with specific roles and goals (with multiple examples)
3. Create tasks for your agents (simple to complex)
4. Assemble a crew and run your first kickoff
5. Analyze the output and understand the execution flow
6. Troubleshoot common first-time user issues

## 1. Setting up a Basic CrewAI Project Structure

Let's start by creating a basic project structure for our CrewAI project:

```
crewai_project/
│
├── main.py
├── requirements.txt
│
├── agents/
│   ├── __init__.py
│   ├── researcher.py
│   ├── writer.py
│   └── editor.py
│
├── tasks/
│   ├── __init__.py
│   ├── research_task.py
│   ├── writing_task.py
│   └── editing_task.py
│
└── tools/
    ├── __init__.py
    └── web_search_tool.py
```

Create this directory structure in your preferred location. We'll populate these files as we progress through the lesson.

## 2. Defining Agents with Specific Roles and Goals

Let's create three agents with distinct roles and goals. We'll implement these in separate files within the `agents/` directory.

### researcher.py
```python
from crewai import Agent
from tools.web_search_tool import WebSearchTool

class ResearcherAgent(Agent):
    def __init__(self):
        super().__init__(
            role='Research Specialist',
            goal='Conduct thorough research on given topics and provide accurate, up-to-date information',
            backstory='You are an experienced researcher with a keen eye for detail and a passion for uncovering hard-to-find information. Your background in data analysis and critical thinking allows you to quickly identify reliable sources and synthesize complex information.',
            verbose=True,
            allow_delegation=False,
            tools=[WebSearchTool()]
        )
```

### writer.py
```python
from crewai import Agent

class WriterAgent(Agent):
    def __init__(self):
        super().__init__(
            role='Content Writer',
            goal='Create engaging and informative content based on provided research',
            backstory='You are a talented writer with a knack for turning complex information into compelling narratives. Your background in journalism and creative writing allows you to craft content that is both informative and captivating to a wide audience.',
            verbose=True,
            allow_delegation=False
        )
```

### editor.py
```python
from crewai import Agent

class EditorAgent(Agent):
    def __init__(self):
        super().__init__(
            role='Content Editor',
            goal='Review and refine content for clarity, accuracy, and engagement',
            backstory='You are a seasoned editor with years of experience in polishing written content. Your attention to detail, understanding of various writing styles, and commitment to maintaining high editorial standards make you an invaluable part of any content creation team.',
            verbose=True,
            allow_delegation=False
        )
```

## 3. Creating Tasks for Your Agents

Now, let's create tasks for each of our agents. We'll implement these in separate files within the `tasks/` directory.

### research_task.py
```python
from crewai import Task
from agents.researcher import ResearcherAgent

class ResearchTask(Task):
    def __init__(self, topic):
        super().__init__(
            description=f"Conduct comprehensive research on the topic: {topic}. Focus on recent developments, key players, and potential future trends. Compile your findings into a well-structured report.",
            agent=ResearcherAgent(),
            expected_output="A detailed research report (800-1000 words) covering recent developments, key players, and future trends related to the given topic."
        )
```

### writing_task.py
```python
from crewai import Task
from agents.writer import WriterAgent

class WritingTask(Task):
    def __init__(self, topic, research_output):
        super().__init__(
            description=f"Using the provided research, write an engaging blog post about {topic}. Ensure the content is informative, well-structured, and appealing to a general audience.",
            agent=WriterAgent(),
            expected_output="A 1200-1500 word blog post that effectively communicates the key points from the research in an engaging and accessible manner.",
            context=[research_output]
        )
```

### editing_task.py
```python
from crewai import Task
from agents.editor import EditorAgent

class EditingTask(Task):
    def __init__(self, writing_output):
        super().__init__(
            description="Review and edit the provided blog post. Focus on improving clarity, coherence, and engagement. Ensure the content is free of errors and aligns with high editorial standards.",
            agent=EditorAgent(),
            expected_output="A polished, error-free version of the blog post with improved clarity, coherence, and engagement.",
            context=[writing_output]
        )
```

## 4. Assembling a Crew and Running Your First Kickoff

Now that we have our agents and tasks defined, let's assemble them into a crew and run our first CrewAI project. We'll do this in our `main.py` file:

```python
from crewai import Crew
from crewai.process import Process
from tasks.research_task import ResearchTask
from tasks.writing_task import WritingTask
from tasks.editing_task import EditingTask

def main():
    # Define the topic
    topic = "The Impact of Artificial Intelligence on Healthcare"

    # Create tasks
    research_task = ResearchTask(topic)
    writing_task = WritingTask(topic, research_task)
    editing_task = EditingTask(writing_task)

    # Assemble the crew
    content_creation_crew = Crew(
        agents=[research_task.agent, writing_task.agent, editing_task.agent],
        tasks=[research_task, writing_task, editing_task],
        process=Process.sequential,
        verbose=2  # To get a detailed output of the process
    )

    # Run the crew
    result = content_creation_crew.kickoff()

    print("\nFinal Result:")
    print(result)

if __name__ == "__main__":
    main()
```

To run your first CrewAI project, execute the following command in your terminal:

```bash
python main.py
```

## 5. Analyzing the Output and Understanding the Execution Flow

As your crew runs, you'll see detailed output in your console due to the `verbose=2` setting. This output will show you:

1. Which agent is currently active
2. What task the agent is working on
3. The agent's thought process and actions
4. The output of each task

The execution flow follows this pattern:
1. The ResearcherAgent conducts research on the given topic
2. The WriterAgent uses the research to create a blog post
3. The EditorAgent reviews and refines the blog post

Each agent's output becomes the input (context) for the next agent in the sequence.

## 6. Troubleshooting Common First-Time User Issues

Here are some common issues you might encounter and how to resolve them:

1. **ImportError: No module named 'crewai'**
   - Solution: Ensure you've installed CrewAI. Run `pip install crewai`.

2. **API Key errors**
   - Solution: Make sure you've set up your API keys for any external services (e.g., OpenAI) as environment variables.

3. **Unexpected agent behavior**
   - Solution: Review your agent definitions, ensuring roles, goals, and backstories are clear and specific.

4. **Task outputs not meeting expectations**
   - Solution: Refine your task descriptions and expected outputs. Be as specific as possible.

5. **Errors related to tools**
   - Solution: Ensure all required tools are properly imported and initialized.

6. **Process hanging or taking too long**
   - Solution: Check your internet connection. Consider using a faster LLM or optimizing your tasks.

## Conclusion

Congratulations! You've now created and run your first CrewAI project. You've learned how to set up a project structure, define agents with specific roles and goals, create tasks, assemble a crew, and run your first kickoff. You've also gained insights into analyzing the output and troubleshooting common issues.

In the next lesson, we'll explore more advanced agent configurations and dive deeper into optimizing your CrewAI workflows.

## Additional Resources
- CrewAI Documentation: https://docs.crewai.com/
- OpenAI API Documentation: https://platform.openai.com/docs/api-reference
- Python asyncio for handling asynchronous operations: https://docs.python.org/3/library/asyncio.html

## Practice Exercises
1. Modify the existing project to include a fourth agent (e.g., a Fact Checker) and an additional task.
2. Experiment with different LLMs for each agent and compare the results.
3. Implement error handling in your main.py to gracefully handle potential issues during execution.
4. Create a new CrewAI project for a different use case (e.g., market analysis, product development) using the concepts learned in this lesson.

