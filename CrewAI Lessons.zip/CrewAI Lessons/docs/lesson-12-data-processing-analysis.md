# Lesson 12: Data Processing and Analysis with CrewAI

## Lesson Overview
In this lesson, we'll explore how to use CrewAI for data processing and analysis tasks. We'll cover using CrewAI for data extraction and transformation (ETL processes), implementing database interactions, creating data analysis workflows, visualizing results, implementing natural language querying for databases, and handling large datasets.

## File Structure
```
project_root/
│
├── etl/
│   ├── extractor.py
│   ├── transformer.py
│   └── loader.py
│
├── database/
│   ├── mysql_handler.py
│   ├── postgresql_handler.py
│   └── mongodb_handler.py
│
├── analysis/
│   ├── pandas_analysis.py
│   └── numpy_analysis.py
│
├── visualization/
│   ├── matplotlib_visualizer.py
│   └── seaborn_visualizer.py
│
├── nl_query/
│   └── nl_to_sql.py
│
├── large_data/
│   └── data_chunker.py
│
├── config/
│   └── database_config.yaml
│
├── requirements.txt
└── main.py
```

## 1. Data Extraction and Transformation (ETL Processes)

Let's start by creating a simple ETL process using CrewAI:

```python
# etl/extractor.py
import pandas as pd
from crewai import Agent, Task

class DataExtractorAgent(Agent):
    def extract_data(self, source):
        if source.endswith('.csv'):
            return pd.read_csv(source)
        elif source.endswith('.json'):
            return pd.read_json(source)
        else:
            raise ValueError("Unsupported file format")

# etl/transformer.py
class DataTransformerAgent(Agent):
    def transform_data(self, data):
        # Example transformation: convert to uppercase
        return data.applymap(lambda x: x.upper() if isinstance(x, str) else x)

# etl/loader.py
class DataLoaderAgent(Agent):
    def load_data(self, data, destination):
        if destination.endswith('.csv'):
            data.to_csv(destination, index=False)
        elif destination.endswith('.json'):
            data.to_json(destination, orient='records')
        else:
            raise ValueError("Unsupported file format")

# main.py
from crewai import Crew, Task
from etl.extractor import DataExtractorAgent
from etl.transformer import DataTransformerAgent
from etl.loader import DataLoaderAgent

extractor = DataExtractorAgent(
    role="Data Extractor",
    goal="Extract data from various sources",
    backstory="You are an AI specialized in extracting data from different file formats"
)

transformer = DataTransformerAgent(
    role="Data Transformer",
    goal="Transform and clean extracted data",
    backstory="You are an AI expert in data cleaning and transformation"
)

loader = DataLoaderAgent(
    role="Data Loader",
    goal="Load processed data into specified destinations",
    backstory="You are an AI specialized in efficiently storing processed data"
)

extract_task = Task(
    description="Extract data from 'input.csv'",
    agent=extractor
)

transform_task = Task(
    description="Transform the extracted data",
    agent=transformer
)

load_task = Task(
    description="Load the transformed data to 'output.json'",
    agent=loader
)

crew = Crew(
    agents=[extractor, transformer, loader],
    tasks=[extract_task, transform_task, load_task],
    verbose=True
)

result = crew.kickoff()
print(result)
```

## 2. Implementing Database Interactions

Let's implement database interactions for MySQL, PostgreSQL, and MongoDB:

```python
# database/mysql_handler.py
import mysql.connector
from crewai import Agent, Task

class MySQLAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.connection = mysql.connector.connect(
            host="localhost",
            user="your_username",
            password="your_password",
            database="your_database"
        )
        self.cursor = self.connection.cursor()

    def execute_query(self, query):
        self.cursor.execute(query)
        return self.cursor.fetchall()

    def __del__(self):
        self.cursor.close()
        self.connection.close()

# database/postgresql_handler.py
import psycopg2
from crewai import Agent, Task

class PostgreSQLAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.connection = psycopg2.connect(
            host="localhost",
            database="your_database",
            user="your_username",
            password="your_password"
        )
        self.cursor = self.connection.cursor()

    def execute_query(self, query):
        self.cursor.execute(query)
        return self.cursor.fetchall()

    def __del__(self):
        self.cursor.close()
        self.connection.close()

# database/mongodb_handler.py
from pymongo import MongoClient
from crewai import Agent, Task

class MongoDBAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.client = MongoClient('mongodb://localhost:27017/')
        self.db = self.client['your_database']

    def execute_query(self, collection, query):
        return list(self.db[collection].find(query))

    def __del__(self):
        self.client.close()

# main.py
from crewai import Crew, Task
from database.mysql_handler import MySQLAgent
from database.postgresql_handler import PostgreSQLAgent
from database.mongodb_handler import MongoDBAgent

mysql_agent = MySQLAgent(
    role="MySQL Expert",
    goal="Interact with MySQL databases",
    backstory="You are an AI specialized in MySQL database operations"
)

postgres_agent = PostgreSQLAgent(
    role="PostgreSQL Expert",
    goal="Interact with PostgreSQL databases",
    backstory="You are an AI specialized in PostgreSQL database operations"
)

mongodb_agent = MongoDBAgent(
    role="MongoDB Expert",
    goal="Interact with MongoDB databases",
    backstory="You are an AI specialized in MongoDB database operations"
)

mysql_task = Task(
    description="Fetch all users from the 'users' table in MySQL",
    agent=mysql_agent
)

postgres_task = Task(
    description="Get the average age of users from the 'users' table in PostgreSQL",
    agent=postgres_agent
)

mongodb_task = Task(
    description="Find all documents in the 'products' collection where price > 100 in MongoDB",
    agent=mongodb_agent
)

crew = Crew(
    agents=[mysql_agent, postgres_agent, mongodb_agent],
    tasks=[mysql_task, postgres_task, mongodb_task],
    verbose=True
)

results = crew.kickoff()
for result in results:
    print(result)
```

## 3. Creating Data Analysis Workflows with CrewAI

Let's create a data analysis workflow using pandas:

```python
# analysis/pandas_analysis.py
import pandas as pd
from crewai import Agent, Task

class PandasAnalysisAgent(Agent):
    def analyze_data(self, data_path):
        df = pd.read_csv(data_path)
        
        # Example analysis tasks
        summary = df.describe()
        correlation = df.corr()
        missing_values = df.isnull().sum()
        
        return {
            "summary": summary,
            "correlation": correlation,
            "missing_values": missing_values
        }

# main.py
from crewai import Crew, Task
from analysis.pandas_analysis import PandasAnalysisAgent

pandas_agent = PandasAnalysisAgent(
    role="Data Analyst",
    goal="Perform comprehensive data analysis",
    backstory="You are an AI specialized in data analysis using pandas"
)

analysis_task = Task(
    description="Analyze the dataset in 'data.csv' and provide summary statistics, correlation matrix, and missing value count",
    agent=pandas_agent
)

crew = Crew(
    agents=[pandas_agent],
    tasks=[analysis_task],
    verbose=True
)

result = crew.kickoff()
print(result)
```

## 4. Visualizing Results and Generating Reports

Let's create agents for data visualization using matplotlib and seaborn:

```python
# visualization/matplotlib_visualizer.py
import matplotlib.pyplot as plt
import pandas as pd
from crewai import Agent, Task

class MatplotlibVisualizerAgent(Agent):
    def create_visualization(self, data_path, output_path):
        df = pd.read_csv(data_path)
        
        plt.figure(figsize=(10, 6))
        plt.scatter(df['x'], df['y'])
        plt.title('Scatter Plot')
        plt.xlabel('X Axis')
        plt.ylabel('Y Axis')
        plt.savefig(output_path)
        plt.close()
        
        return f"Visualization saved to {output_path}"

# visualization/seaborn_visualizer.py
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
from crewai import Agent, Task

class SeabornVisualizerAgent(Agent):
    def create_visualization(self, data_path, output_path):
        df = pd.read_csv(data_path)
        
        plt.figure(figsize=(10, 6))
        sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
        plt.title('Correlation Heatmap')
        plt.savefig(output_path)
        plt.close()
        
        return f"Visualization saved to {output_path}"

# main.py
from crewai import Crew, Task
from visualization.matplotlib_visualizer import MatplotlibVisualizerAgent
from visualization.seaborn_visualizer import SeabornVisualizerAgent

matplotlib_agent = MatplotlibVisualizerAgent(
    role="Matplotlib Visualizer",
    goal="Create visualizations using Matplotlib",
    backstory="You are an AI specialized in creating data visualizations with Matplotlib"
)

seaborn_agent = SeabornVisualizerAgent(
    role="Seaborn Visualizer",
    goal="Create advanced visualizations using Seaborn",
    backstory="You are an AI specialized in creating sophisticated data visualizations with Seaborn"
)

matplotlib_task = Task(
    description="Create a scatter plot from 'data.csv' and save it as 'scatter_plot.png'",
    agent=matplotlib_agent
)

seaborn_task = Task(
    description="Create a correlation heatmap from 'data.csv' and save it as 'heatmap.png'",
    agent=seaborn_agent
)

crew = Crew(
    agents=[matplotlib_agent, seaborn_agent],
    tasks=[matplotlib_task, seaborn_task],
    verbose=True
)

results = crew.kickoff()
for result in results:
    print(result)
```

## 5. Implementing Natural Language Querying for Databases

Let's create an agent that can convert natural language queries to SQL:

```python
# nl_query/nl_to_sql.py
from crewai import Agent, Task
import openai

class NLtoSQLAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        openai.api_key = "your_openai_api_key"

    def convert_nl_to_sql(self, natural_language_query, table_schema):
        prompt = f"""
        Given the following table schema:
        {table_schema}

        Convert this natural language query to SQL:
        {natural_language_query}

        SQL query:
        """
        
        response = openai.Completion.create(
            engine="text-davinci-002",
            prompt=prompt,
            max_tokens=150
        )
        
        return response.choices[0].text.strip()

# main.py
from crewai import Crew, Task
from nl_query.nl_to_sql import NLtoSQLAgent

nl_to_sql_agent = NLtoSQLAgent(
    role="NL to SQL Converter",
    goal="Convert natural language queries to SQL",
    backstory="You are an AI specialized in translating natural language to SQL queries"
)

conversion_task = Task(
    description="Convert the query 'Find all customers who made a purchase last month' to SQL, given the schema: customers(id, name, email), orders(id, customer_id, order_date, total_amount)",
    agent=nl_to_sql_agent
)

crew = Crew(
    agents=[nl_to_sql_agent],
    tasks=[conversion_task],
    verbose=True
)

result = crew.kickoff()
print(result)
```

## 6. Handling Large Datasets and Optimizing for Performance

When dealing with large datasets, it's important to implement strategies for efficient processing. Let's create an agent that can handle large datasets by chunking:

```python
# large_data/data_chunker.py
import pandas as pd
from crewai import Agent, Task

class LargeDataHandler(Agent):
    def process_large_dataset(self, file_path, chunk_size=10000):
        total_rows = 0
        processed_chunks = 0
        
        for chunk in pd.read_csv(file_path, chunksize=chunk_size):
            # Process each chunk (example: calculate mean of a column)
            mean = chunk['some_column'].mean()
            total_rows += len(chunk)
            processed_chunks += 1
            
            yield f"Processed chunk {processed_chunks}. Mean of 'some_column': {mean}"
        
        yield f"Finished processing {total_rows} rows in {processed_chunks} chunks"

# main.py
from crewai import Crew, Task
from large_data.data_chunker import LargeDataHandler

large_data_agent = LargeDataHandler(
    role="Large Data Processor",
    goal="Efficiently process large datasets",
    backstory="You are an AI specialized in handling and analyzing large volumes of data"
)

large_data_task = Task(
    description="Process the large dataset in 'big_data.csv' in chunks and calculate the mean of 'some_column' for each chunk",
    agent=large_data_agent
)

crew = Crew(
    agents=[large_data_agent],
    tasks=[large_data_task],
    verbose=True
)

result = crew.kickoff()
print(result)
```

## Conclusion

In this lesson, we've explored various aspects of data processing and analysis using CrewAI. We've covered ETL processes, database interactions with different types of databases, data analysis workflows using pandas, data visualization with matplotlib and seaborn, natural language querying for databases, and techniques for handling large datasets.

By leveraging these techniques, you can create powerful CrewAI agents capable of performing complex data processing and analysis tasks, from data extraction and transformation to visualization and reporting.

## Exercises

1. Create a CrewAI agent that performs a complete ETL process: extract data from a CSV file, transform it (e.g., clean missing values, normalize data), and load it into a SQLite database.

2. Implement a CrewAI agent that connects to a PostgreSQL database, performs a complex query involving multiple joins, and visualizes the results using seaborn.

3. Develop a natural language interface for querying a database. The agent should be able to take a natural language question, convert it to SQL, execute the query, and return the results in a human-readable format.

4. Create a CrewAI agent that can handle time series data: load a large time series dataset, perform resampling and aggregation, and create a forecast using a simple model like ARIMA.

5. Implement a data quality assessment agent that can analyze a dataset, identify potential issues (e.g., outliers, missing values, inconsistent data types), and generate a comprehensive data quality report.

## Additional Resources

- Pandas Documentation: [https://pandas.pydata.org/docs/](https://pandas.pydata.org/docs/)
- Matplotlib Documentation: [https://matplotlib.org/stable/contents.html](https://matplotlib.org/stable/contents.html)
- Seaborn Documentation: [https://seaborn.pydata.org/](https://seaborn.pydata.org/)
- SQLAlchemy Documentation: [https://docs.sqlalchemy.org/en/14/](https://docs.sqlalchemy.org/en/14/)
- "Python for Data Analysis" by Wes McKinney: [Book Link]
- "Hands-On Machine Learning with Scikit-Learn, Keras, and TensorFlow" by Aurélien Géron: [Book Link]

Remember to always handle data responsibly, respect data privacy regulations, and ensure the security of sensitive information when working with real-world datasets. Happy data processing and analysis with CrewAI!

