# Lesson 15: Deployment and Scaling

## Lesson Overview
In this lesson, we'll explore how to deploy CrewAI projects in various environments, scale CrewAI applications for production use, manage API keys and sensitive information, implement best practices for maintaining CrewAI projects, set up monitoring and alerting for production deployments, and explore serverless deployment options for CrewAI.

## File Structure
```
project_root/
│
├── deployment/
│   ├── docker/
│   │   ├── Dockerfile
│   │   └── docker-compose.yml
│   ├── kubernetes/
│   │   ├── deployment.yaml
│   │   └── service.yaml
│   └── serverless/
│       └── serverless.yml
│
├── scaling/
│   ├── load_balancer.py
│   └── worker.py
│
├── monitoring/
│   ├── prometheus.yml
│   └── grafana_dashboard.json
│
├── secrets/
│   └── secrets_manager.py
│
├── maintenance/
│   └── update_script.py
│
├── requirements.txt
└── main.py
```

## 1. Deploying CrewAI Projects in Various Environments

### Docker Deployment

Let's start by creating a Dockerfile for our CrewAI project:

```dockerfile
# deployment/docker/Dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["python", "main.py"]
```

And a docker-compose file for easy deployment:

```yaml
# deployment/docker/docker-compose.yml
version: '3'
services:
  crewai-app:
    build: .
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
    ports:
      - "8000:8000"
```

To deploy using Docker:

```bash
docker-compose up --build
```

### Kubernetes Deployment

For Kubernetes deployment, we'll create a deployment and service YAML:

```yaml
# deployment/kubernetes/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: crewai-deployment
spec:
  replicas: 3
  selector:
    matchLabels:
      app: crewai
  template:
    metadata:
      labels:
        app: crewai
    spec:
      containers:
      - name: crewai
        image: your-docker-registry/crewai-app:latest
        env:
        - name: OPENAI_API_KEY
          valueFrom:
            secretKeyRef:
              name: crewai-secrets
              key: openai-api-key
```

```yaml
# deployment/kubernetes/service.yaml
apiVersion: v1
kind: Service
metadata:
  name: crewai-service
spec:
  selector:
    app: crewai
  ports:
    - protocol: TCP
      port: 80
      targetPort: 8000
  type: LoadBalancer
```

To deploy to Kubernetes:

```bash
kubectl apply -f deployment/kubernetes/
```

## 2. Scaling CrewAI Applications for Production Use

To scale CrewAI applications, we can implement a load balancer and worker system:

```python
# scaling/load_balancer.py
import random
from flask import Flask, request, jsonify

app = Flask(__name__)

workers = ["http://worker1:8000", "http://worker2:8000", "http://worker3:8000"]

@app.route('/process', methods=['POST'])
def process():
    worker = random.choice(workers)
    # Forward request to chosen worker
    # Implement request forwarding logic here
    return jsonify({"status": "processing", "worker": worker})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)

# scaling/worker.py
from flask import Flask, request, jsonify
from crewai import Agent, Task, Crew

app = Flask(__name__)

@app.route('/process', methods=['POST'])
def process():
    data = request.json
    # Process the task using CrewAI
    # Implement CrewAI logic here
    return jsonify({"status": "completed", "result": "Task result"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
```

## 3. Managing API Keys and Sensitive Information

For managing sensitive information, we can use a secrets manager:

```python
# secrets/secrets_manager.py
import os
from google.cloud import secretmanager

def get_secret(secret_name):
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{os.environ['GOOGLE_CLOUD_PROJECT']}/secrets/{secret_name}/versions/latest"
    response = client.access_secret_version(request={"name": name})
    return response.payload.data.decode("UTF-8")

# Usage
openai_api_key = get_secret("openai-api-key")
```

## 4. Best Practices for Maintaining CrewAI Projects

Here's a script for updating CrewAI and its dependencies:

```python
# maintenance/update_script.py
import subprocess
import sys

def update_crewai():
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "crewai"])
        print("CrewAI updated successfully!")
    except subprocess.CalledProcessError:
        print("Failed to update CrewAI.")

def update_dependencies():
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "-r", "requirements.txt"])
        print("Dependencies updated successfully!")
    except subprocess.CalledProcessError:
        print("Failed to update dependencies.")

if __name__ == "__main__":
    update_crewai()
    update_dependencies()
```

## 5. Monitoring and Alerting for Production Deployments

We can use Prometheus and Grafana for monitoring. Here's a basic Prometheus configuration:

```yaml
# monitoring/prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'crewai'
    static_configs:
      - targets: ['localhost:8000']
```

And a sample Grafana dashboard configuration:

```json
# monitoring/grafana_dashboard.json
{
  "dashboard": {
    "id": null,
    "title": "CrewAI Dashboard",
    "panels": [
      {
        "title": "Task Completion Rate",
        "type": "graph",
        "datasource": "Prometheus",
        "targets": [
          {
            "expr": "rate(crewai_tasks_completed_total[5m])",
            "legendFormat": "Tasks Completed"
          }
        ]
      }
    ]
  }
}
```

## 6. Serverless Deployment Options for CrewAI

For serverless deployment, we can use AWS Lambda with the Serverless Framework:

```yaml
# deployment/serverless/serverless.yml
service: crewai-serverless

provider:
  name: aws
  runtime: python3.9
  stage: ${opt:stage, 'dev'}
  region: ${opt:region, 'us-east-1'}

functions:
  process:
    handler: main.process
    events:
      - http:
          path: process
          method: post

plugins:
  - serverless-python-requirements

custom:
  pythonRequirements:
    dockerizePip: true
```

To deploy the serverless function:

```bash
serverless deploy
```

## Conclusion

In this lesson, we've covered various aspects of deploying and scaling CrewAI projects. We've explored deployment options including Docker and Kubernetes, implemented scaling strategies, managed sensitive information, established best practices for maintenance, set up monitoring and alerting, and looked at serverless deployment options.

By applying these deployment and scaling techniques, you can ensure that your CrewAI projects are production-ready, scalable, and maintainable. Remember that the specific deployment strategy you choose should align with your project requirements, expected load, and infrastructure preferences.

## Exercises

1. Deploy a CrewAI project using Docker and test its performance under different load conditions.

2. Implement a Kubernetes deployment for a CrewAI application and set up auto-scaling based on CPU usage.

3. Develop a comprehensive monitoring solution for a CrewAI project, including custom metrics for task completion rates and agent performance.

4. Create a CI/CD pipeline for a CrewAI project that includes automated testing, dependency updates, and deployment to a cloud platform.

5. Implement a serverless CrewAI application using AWS Lambda or Google Cloud Functions, and test its performance and cost-effectiveness.

## Additional Resources

- Docker Documentation: [https://docs.docker.com/](https://docs.docker.com/)
- Kubernetes Documentation: [https://kubernetes.io/docs/home/](https://kubernetes.io/docs/home/)
- Prometheus Documentation: [https://prometheus.io/docs/introduction/overview/](https://prometheus.io/docs/introduction/overview/)
- Grafana Documentation: [https://grafana.com/docs/](https://grafana.com/docs/)
- Serverless Framework Documentation: [https://www.serverless.com/framework/docs/](https://www.serverless.com/framework/docs/)
- "Designing Distributed Systems" by Brendan Burns: [Book Link]
- "Site Reliability Engineering" by Niall Richard Murphy, Betsy Beyer, Chris Jones & Jennifer Petoff: [Book Link]

Remember that deploying and scaling AI systems comes with unique challenges, including managing model versions, handling increased computational requirements, and ensuring consistent performance across distributed systems. Regularly review and update your deployment strategies as your CrewAI projects evolve and as new best practices emerge in the field of AI system deployment.

