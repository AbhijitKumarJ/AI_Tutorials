# Lesson 14: Testing and Debugging CrewAI Projects

## Lesson Overview
In this lesson, we'll explore techniques for testing and debugging CrewAI projects. We'll cover implementing unit tests for agents and tasks, debugging techniques for CrewAI workflows, using logging and observability tools, performance profiling and optimization techniques, implementing integration tests, and best practices for test-driven development in AI projects.

## File Structure
```
project_root/
│
├── tests/
│   ├── unit/
│   │   ├── test_agents.py
│   │   └── test_tasks.py
│   ├── integration/
│   │   └── test_workflows.py
│   └── conftest.py
│
├── debugging/
│   ├── logger.py
│   └── profiler.py
│
├── observability/
│   ├── agentops_integration.py
│   └── langtrace_integration.py
│
├── src/
│   ├── agents/
│   ├── tasks/
│   └── workflows/
│
├── requirements.txt
└── main.py
```

## 1. Implementing Unit Tests for Agents and Tasks

Let's start by implementing unit tests for our agents and tasks using pytest:

```python
# tests/unit/test_agents.py
import pytest
from crewai import Agent
from unittest.mock import Mock

def test_agent_creation():
    agent = Agent(
        role="Test Agent",
        goal="Perform tests",
        backstory="You are an AI designed for testing"
    )
    assert agent.role == "Test Agent"
    assert agent.goal == "Perform tests"
    assert agent.backstory == "You are an AI designed for testing"

def test_agent_task_execution():
    agent = Agent(
        role="Test Agent",
        goal="Perform tests",
        backstory="You are an AI designed for testing"
    )
    mock_task = Mock()
    mock_task.description = "Test task"
    result = agent.execute_task(mock_task)
    assert result is not None

# tests/unit/test_tasks.py
import pytest
from crewai import Task, Agent

def test_task_creation():
    agent = Agent(role="Test Agent", goal="Test Goal", backstory="Test Backstory")
    task = Task(description="Test Task", agent=agent)
    assert task.description == "Test Task"
    assert task.agent == agent

def test_task_execution():
    agent = Agent(role="Test Agent", goal="Test Goal", backstory="Test Backstory")
    task = Task(description="Test Task", agent=agent)
    result = task.execute()
    assert result is not None
```

To run these tests, you can use the pytest command:

```
pytest tests/unit
```

## 2. Debugging Techniques for CrewAI Workflows

For debugging CrewAI workflows, we can implement a custom logger:

```python
# debugging/logger.py
import logging

class CrewAILogger:
    def __init__(self, name, level=logging.INFO):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(level)
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

    def debug(self, message):
        self.logger.debug(message)

    def info(self, message):
        self.logger.info(message)

    def warning(self, message):
        self.logger.warning(message)

    def error(self, message):
        self.logger.error(message)

# Usage in a CrewAI agent
from crewai import Agent, Task
from debugging.logger import CrewAILogger

class DebuggableAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.logger = CrewAILogger(self.role)

    def execute_task(self, task):
        self.logger.info(f"Starting task: {task.description}")
        result = super().execute_task(task)
        self.logger.info(f"Completed task: {task.description}")
        return result

# main.py
debuggable_agent = DebuggableAgent(
    role="Debuggable Agent",
    goal="Perform tasks with detailed logging",
    backstory="You are an AI agent with advanced debugging capabilities"
)

task = Task(
    description="Perform a sample task for debugging",
    agent=debuggable_agent
)

crew = Crew(agents=[debuggable_agent], tasks=[task])
result = crew.kickoff()
print(result)
```

## 3. Using Logging and Observability Tools

For advanced logging and observability, we can integrate tools like AgentOps and Langtrace:

```python
# observability/agentops_integration.py
import agentops
from crewai import Agent, Task, Crew

agentops.init()

class ObservableAgent(Agent):
    def execute_task(self, task):
        with agentops.context() as ctx:
            ctx.log(f"Starting task: {task.description}")
            result = super().execute_task(task)
            ctx.log(f"Completed task: {task.description}")
            return result

# observability/langtrace_integration.py
from langtrace_python_sdk import langtrace
from crewai import Agent, Task, Crew

langtrace.init(api_key='<LANGTRACE_API_KEY>')

class TracedAgent(Agent):
    def execute_task(self, task):
        with langtrace.trace(f"Task: {task.description}") as span:
            result = super().execute_task(task)
            span.set_tag("result_length", len(result))
            return result

# main.py
observable_agent = ObservableAgent(
    role="Observable Agent",
    goal="Perform tasks with advanced observability",
    backstory="You are an AI agent with integrated observability features"
)

traced_agent = TracedAgent(
    role="Traced Agent",
    goal="Perform tasks with detailed tracing",
    backstory="You are an AI agent with integrated tracing capabilities"
)

task1 = Task(description="Perform an observable task", agent=observable_agent)
task2 = Task(description="Perform a traced task", agent=traced_agent)

crew = Crew(agents=[observable_agent, traced_agent], tasks=[task1, task2])
results = crew.kickoff()
for result in results:
    print(result)
```

## 4. Performance Profiling and Optimization Techniques

For performance profiling, we can use the cProfile module:

```python
# debugging/profiler.py
import cProfile
import pstats
import io

def profile(func):
    def wrapper(*args, **kwargs):
        pr = cProfile.Profile()
        pr.enable()
        result = func(*args, **kwargs)
        pr.disable()
        s = io.StringIO()
        ps = pstats.Stats(pr, stream=s).sort_stats('cumulative')
        ps.print_stats()
        print(s.getvalue())
        return result
    return wrapper

# Usage in a CrewAI agent
from crewai import Agent, Task
from debugging.profiler import profile

class ProfilableAgent(Agent):
    @profile
    def execute_task(self, task):
        return super().execute_task(task)

# main.py
profilable_agent = ProfilableAgent(
    role="Profilable Agent",
    goal="Perform tasks with performance profiling",
    backstory="You are an AI agent with integrated performance profiling"
)

task = Task(
    description="Perform a sample task for profiling",
    agent=profilable_agent
)

crew = Crew(agents=[profilable_agent], tasks=[task])
result = crew.kickoff()
print(result)
```

## 5. Implementing Integration Tests

Let's implement integration tests for our CrewAI workflows:

```python
# tests/integration/test_workflows.py
import pytest
from crewai import Agent, Task, Crew, Process

def test_simple_workflow():
    agent1 = Agent(role="Agent 1", goal="Perform Task 1", backstory="Test Agent 1")
    agent2 = Agent(role="Agent 2", goal="Perform Task 2", backstory="Test Agent 2")

    task1 = Task(description="Task 1", agent=agent1)
    task2 = Task(description="Task 2", agent=agent2)

    crew = Crew(
        agents=[agent1, agent2],
        tasks=[task1, task2],
        process=Process.sequential
    )

    results = crew.kickoff()
    assert len(results) == 2
    assert all(result is not None for result in results)

def test_conditional_workflow():
    class ConditionalAgent(Agent):
        def execute_task(self, task):
            if "condition" in task.description:
                return "Condition met"
            return "Condition not met"

    agent = ConditionalAgent(role="Conditional Agent", goal="Test conditions", backstory="Test Agent")

    task1 = Task(description="Task with condition", agent=agent)
    task2 = Task(description="Task without condition", agent=agent)

    crew = Crew(
        agents=[agent],
        tasks=[task1, task2],
        process=Process.sequential
    )

    results = crew.kickoff()
    assert results[0] == "Condition met"
    assert results[1] == "Condition not met"

# Run integration tests
pytest tests/integration
```

## 6. Best Practices for Test-Driven Development in AI Projects

When applying Test-Driven Development (TDD) to AI projects, especially those using CrewAI, consider the following best practices:

1. **Start with clear specifications**: Define the expected behavior of your agents and tasks before implementation.

2. **Write tests for deterministic behavior**: Focus on testing aspects of your AI system that should produce consistent results.

3. **Use mocks for external dependencies**: When testing agents that interact with external services or APIs, use mocks to simulate these interactions.

4. **Test edge cases**: Include tests for extreme or unusual inputs to ensure your AI system handles them gracefully.

5. **Implement continuous integration**: Set up automated testing pipelines to run your tests on every code change.

6. **Monitor and update tests**: As your AI system evolves, continuously update and add new tests to maintain coverage.

Here's an example of how to apply these practices:

```python
# tests/unit/test_ai_agent.py
import pytest
from unittest.mock import Mock
from crewai import Agent, Task

def test_ai_agent_response():
    mock_llm = Mock()
    mock_llm.generate.return_value = "Mocked AI response"

    agent = Agent(
        role="Test AI",
        goal="Provide consistent responses",
        backstory="You are an AI for testing",
        llm=mock_llm
    )

    task = Task(description="Provide a test response", agent=agent)
    result = agent.execute_task(task)

    assert result == "Mocked AI response"
    mock_llm.generate.assert_called_once()

def test_ai_agent_error_handling():
    mock_llm = Mock()
    mock_llm.generate.side_effect = Exception("API Error")

    agent = Agent(
        role="Error Handling AI",
        goal="Handle errors gracefully",
        backstory="You are an AI that tests error scenarios",
        llm=mock_llm
    )

    task = Task(description="Trigger an error", agent=agent)
    
    with pytest.raises(Exception) as exc_info:
        agent.execute_task(task)
    
    assert str(exc_info.value) == "API Error"

# Add more tests for edge cases, different agent configurations, etc.
```

## Conclusion

In this lesson, we've explored various aspects of testing and debugging CrewAI projects. We've covered unit testing for agents and tasks, debugging techniques using custom loggers, integrating observability tools, performance profiling, implementing integration tests, and best practices for test-driven development in AI projects.

By applying these testing and debugging techniques, you can ensure that your CrewAI projects are robust, performant, and maintainable. Remember that testing AI systems can be challenging due to their often non-deterministic nature, so focus on testing the aspects of your system that should produce consistent results and use mocking techniques for external dependencies.

## Exercises

1. Implement a comprehensive suite of unit tests for a complex CrewAI agent that uses multiple tools and has conditional logic in its task execution.

2. Create a debugging tool that allows you to step through a CrewAI workflow, examining the state of agents and tasks at each step.

3. Integrate a third-party observability tool (e.g., Prometheus, Grafana) with CrewAI to monitor the performance and behavior of your AI agents in real-time.

4. Develop a performance optimization strategy for a large-scale CrewAI project, including profiling, identifying bottlenecks, and implementing optimizations.

5. Design and implement a set of integration tests for a multi-stage CrewAI workflow that involves data processing, analysis, and reporting.

## Additional Resources

- Pytest Documentation: [https://docs.pytest.org/](https://docs.pytest.org/)
- Python Debugging with pdb: [https://docs.python.org/3/library/pdb.html](https://docs.python.org/3/library/pdb.html)
- AgentOps Documentation: [https://docs.agentops.ai/](https://docs.agentops.ai/)
- Langtrace Documentation: [https://docs.langtrace.ai/](https://docs.langtrace.ai/)
- "Python Testing with pytest" by Brian Okken: [Book Link]
- "The Art of Unit Testing" by Roy Osherove: [Book Link]

Remember that testing and debugging AI systems is an ongoing process. As your CrewAI projects evolve and grow in complexity, continually refine your testing strategies and debugging techniques to ensure the reliability and performance of your AI agents and workflows.

