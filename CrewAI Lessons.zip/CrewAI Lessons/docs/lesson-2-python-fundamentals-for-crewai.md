# Lesson 2: Python Fundamentals for CrewAI

## Lesson Objectives
By the end of this lesson, students will be able to:
1. Understand and use basic Python syntax and data structures
2. Write and use functions, including lambda expressions and decorators
3. Apply object-oriented programming concepts in Python
4. Create and manage virtual environments
5. Install CrewAI and its dependencies
6. Manage packages using pip and requirements.txt

## 1. Basic Python Syntax and Data Structures

### Variables and Data Types
Python is a dynamically typed language. Common data types include:
- Integers: `x = 5`
- Floats: `y = 3.14`
- Strings: `name = "CrewAI"`
- Booleans: `is_active = True`

### Lists
Lists are ordered, mutable sequences:
```python
fruits = ["apple", "banana", "cherry"]
fruits.append("date")
print(fruits[0])  # Output: apple
```

### Dictionaries
Dictionaries are key-value pairs:
```python
agent = {
    "name": "Researcher",
    "role": "Data Analyst",
    "skills": ["python", "data analysis"]
}
print(agent["name"])  # Output: Researcher
```

### Sets
Sets are unordered collections of unique elements:
```python
unique_numbers = {1, 2, 3, 4, 5, 5}  # Note: 5 is only included once
print(unique_numbers)  # Output: {1, 2, 3, 4, 5}
```

### Control Flow
Python uses indentation for code blocks:

```python
if condition:
    # do something
elif another_condition:
    # do something else
else:
    # do this instead

for item in iterable:
    # process item

while condition:
    # do something repeatedly
```

## 2. Functions, Lambda Expressions, and Decorators

### Functions
Define functions using the `def` keyword:

```python
def greet(name):
    return f"Hello, {name}!"

print(greet("CrewAI"))  # Output: Hello, CrewAI!
```

### Lambda Expressions
Lambda functions are anonymous, inline functions:

```python
square = lambda x: x**2
print(square(4))  # Output: 16
```

### Decorators
Decorators modify the behavior of functions or classes:

```python
def log_function(func):
    def wrapper(*args, **kwargs):
        print(f"Calling function: {func.__name__}")
        result = func(*args, **kwargs)
        print(f"Function {func.__name__} completed")
        return result
    return wrapper

@log_function
def add(a, b):
    return a + b

print(add(3, 5))
# Output:
# Calling function: add
# Function add completed
# 8
```

## 3. Object-Oriented Programming Basics

### Classes and Objects
Define a class using the `class` keyword:

```python
class Agent:
    def __init__(self, name, role):
        self.name = name
        self.role = role

    def introduce(self):
        return f"I'm {self.name}, a {self.role}."

researcher = Agent("Alice", "Researcher")
print(researcher.introduce())  # Output: I'm Alice, a Researcher.
```

### Inheritance
Inheritance allows a class to inherit attributes and methods from another class:

```python
class SpecializedAgent(Agent):
    def __init__(self, name, role, specialty):
        super().__init__(name, role)
        self.specialty = specialty

    def introduce(self):
        return f"{super().introduce()} I specialize in {self.specialty}."

data_analyst = SpecializedAgent("Bob", "Data Analyst", "machine learning")
print(data_analyst.introduce())
# Output: I'm Bob, a Data Analyst. I specialize in machine learning.
```

### Polymorphism
Polymorphism allows objects of different classes to be treated as objects of a common base class:

```python
def get_introduction(agent):
    return agent.introduce()

print(get_introduction(researcher))
print(get_introduction(data_analyst))
```

## 4. Working with Virtual Environments

Virtual environments isolate project dependencies, preventing conflicts between different projects.

### Creating a Virtual Environment
```bash
python -m venv crewai_env
```

### Activating the Virtual Environment
- Windows: `crewai_env\Scripts\activate`
- macOS/Linux: `source crewai_env/bin/activate`

### Deactivating the Virtual Environment
```bash
deactivate
```

## 5. Installing CrewAI and its Dependencies

With your virtual environment activated:

```bash
pip install crewai
```

This command installs CrewAI and its required dependencies.

## 6. Package Management with pip and requirements.txt

### Installing Packages
```bash
pip install package_name
```

### Generating requirements.txt
```bash
pip freeze > requirements.txt
```

### Installing from requirements.txt
```bash
pip install -r requirements.txt
```

## Project Structure

After setting up your environment and installing CrewAI, your project structure might look like this:

```
crewai_project/
│
├── crewai_env/
├── .gitignore
├── README.md
├── requirements.txt
├── main.py
│
├── agents/
│   ├── __init__.py
│   └── researcher.py
│
├── tasks/
│   ├── __init__.py
│   └── research_task.py
│
└── tools/
    ├── __init__.py
    └── web_search.py
```

## Example CrewAI Script

Here's a simple CrewAI script to demonstrate the concepts we've learned:

```python
# main.py
from crewai import Agent, Task, Crew
from crewai.tools import SerperDevTool

# Create a search tool
search_tool = SerperDevTool()

# Create an agent
researcher = Agent(
    role='Senior Researcher',
    goal='Conduct thorough research on given topics',
    backstory='You are an experienced researcher with expertise in various fields',
    verbose=True,
    allow_delegation=False,
    tools=[search_tool]
)

# Create a task
research_task = Task(
    description='Research the latest advancements in AI and summarize the findings',
    agent=researcher
)

# Create a crew
research_crew = Crew(
    agents=[researcher],
    tasks=[research_task],
    verbose=2
)

# Run the crew
result = research_crew.kickoff()

print(result)
```

## Conclusion

In this lesson, we've covered essential Python fundamentals that are crucial for working with CrewAI. We've explored basic syntax, data structures, functions, object-oriented programming concepts, and package management. In the next lesson, we'll dive deeper into CrewAI's core concepts and start building more complex AI agent systems.

## Additional Resources
- Python Official Tutorial: https://docs.python.org/3/tutorial/
- Real Python (Python Tutorials): https://realpython.com/
- CrewAI Documentation: https://docs.crewai.com/

## Practice Exercises
1. Create a `CustomAgent` class that inherits from CrewAI's `Agent` class and adds a new method `analyze_data()`.
2. Write a decorator that measures and prints the execution time of a function.
3. Create a requirements.txt file for a CrewAI project and install the dependencies in a new virtual environment.
4. Modify the example CrewAI script to include two agents that collaborate on a task.

