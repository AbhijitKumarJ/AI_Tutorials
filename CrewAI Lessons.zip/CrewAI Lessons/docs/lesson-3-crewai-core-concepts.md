# Lesson 3: CrewAI Core Concepts

## Lesson Objectives
By the end of this lesson, students will be able to:
1. Understand and implement Agents with roles, goals, and backstories
2. Define and structure Tasks for AI workflows
3. Assemble and manage Crews of AI agents
4. Differentiate between Sequential and Hierarchical processes
5. Comprehend the CrewAI architecture and component interactions
6. Understand how CrewAI integrates with language models (LLMs)

## 1. Agents: Roles, Goals, and Backstories in Detail

Agents are the fundamental building blocks of CrewAI. They represent individual AI entities with specific roles, goals, and backstories.

### Roles
An agent's role defines its primary function within the crew. Examples include:
- Researcher
- Writer
- Data Analyst
- Project Manager

### Goals
Goals provide direction for the agent's actions. They should be specific and aligned with the agent's role. For example:
- "Conduct thorough research on renewable energy technologies"
- "Write engaging blog posts on AI advancements"

### Backstories
Backstories add depth to agents, influencing their behavior and decision-making. A well-crafted backstory might include:
- Educational background
- Work experience
- Personal motivations

### Implementing an Agent

```python
from crewai import Agent

researcher = Agent(
    role="Senior Research Analyst",
    goal="Conduct in-depth analysis on emerging tech trends",
    backstory="You have a Ph.D. in Computer Science and have been tracking tech innovations for over a decade. Your analyses are known for their accuracy and foresight.",
    verbose=True,
    allow_delegation=False
)
```

## 2. Tasks: Defining and Structuring AI Workflows

Tasks represent specific actions or objectives for agents to complete. They are the building blocks of AI workflows in CrewAI.

### Key Components of a Task
- Description: Clear instructions for the agent
- Expected Output: The desired result of the task
- Agent Assignment: The agent responsible for the task

### Implementing a Task

```python
from crewai import Task

research_task = Task(
    description="Analyze the impact of quantum computing on cryptography over the next 5 years. Provide a detailed report with key findings and potential implications.",
    expected_output="A comprehensive 500-word report on quantum computing's impact on cryptography",
    agent=researcher
)
```

## 3. Crews: Assembling and Managing AI Teams

Crews are collections of agents working together to accomplish a set of tasks. They represent the highest level of organization in CrewAI.

### Key Aspects of Crews
- Agent Composition: The set of agents in the crew
- Task List: The tasks to be completed
- Process: The workflow for task execution (Sequential or Hierarchical)

### Implementing a Crew

```python
from crewai import Crew
from crewai.process import Process

tech_analysis_crew = Crew(
    agents=[researcher, writer, data_analyst],
    tasks=[research_task, writing_task, analysis_task],
    process=Process.sequential,
    verbose=2
)

result = tech_analysis_crew.kickoff()
```

## 4. Processes: Sequential vs. Hierarchical

CrewAI supports two main types of processes for task execution: Sequential and Hierarchical.

### Sequential Process
Tasks are executed in a predefined order, with each task starting after the previous one completes.

```python
crew = Crew(
    agents=[agent1, agent2, agent3],
    tasks=[task1, task2, task3],
    process=Process.sequential
)
```

### Hierarchical Process
A manager agent oversees task distribution and execution, allowing for more complex workflows and dynamic task allocation.

```python
from crewai import Agent

manager = Agent(
    role="Project Manager",
    goal="Oversee the efficient completion of all tasks",
    backstory="You have years of experience managing complex projects and teams."
)

crew = Crew(
    agents=[manager, agent1, agent2, agent3],
    tasks=[task1, task2, task3],
    process=Process.hierarchical,
    manager_agent=manager
)
```

## 5. Understanding the CrewAI Architecture and Component Interactions

CrewAI's architecture is designed to facilitate flexible and scalable AI agent interactions. Here's a high-level overview:

1. Agents: Individual AI entities with specific roles and capabilities
2. Tasks: Units of work to be performed by agents
3. Crews: Orchestrators that manage agents and tasks
4. Processes: Workflow patterns for task execution
5. Tools: External capabilities that agents can use (e.g., web searching, data analysis)
6. Memory: System for storing and retrieving information across interactions

### Component Interactions
- Crews coordinate the overall workflow
- Agents execute tasks using their assigned tools and capabilities
- Tasks define the specific actions to be taken
- Processes determine how tasks are distributed and executed
- Memory allows for information persistence across tasks and agents

## 6. CrewAI's Integration with Language Models (LLMs)

CrewAI is designed to work with various Language Models (LLMs) to power its agents' capabilities.

### Supported LLM Providers
- OpenAI (default)
- Anthropic
- Google AI
- Local models (e.g., using Ollama)

### Configuring LLMs for Agents

```python
from crewai import Agent
from langchain_openai import ChatOpenAI

custom_llm = ChatOpenAI(model_name="gpt-4")

agent_with_custom_llm = Agent(
    role="Specialized Analyst",
    goal="Provide expert analysis in a specific domain",
    backstory="You are an AI with deep expertise in a particular field.",
    llm=custom_llm
)
```

### LLM Integration Benefits
- Flexible model selection based on task requirements
- Ability to use specialized models for specific agents or tasks
- Support for both cloud-based and local LLMs

## Project Structure

A typical CrewAI project structure incorporating these concepts might look like this:

```
crewai_project/
│
├── main.py
├── requirements.txt
│
├── agents/
│   ├── __init__.py
│   ├── researcher.py
│   ├── writer.py
│   └── analyst.py
│
├── tasks/
│   ├── __init__.py
│   ├── research_task.py
│   ├── writing_task.py
│   └── analysis_task.py
│
├── crews/
│   ├── __init__.py
│   └── tech_analysis_crew.py
│
└── tools/
    ├── __init__.py
    └── custom_search_tool.py
```

## Example: Putting It All Together

Here's an example that demonstrates how to use these core concepts together:

```python
# main.py
from crewai import Agent, Task, Crew
from crewai.process import Process
from crewai_tools import SerperDevTool

# Create tools
search_tool = SerperDevTool()

# Create agents
researcher = Agent(
    role="Tech Researcher",
    goal="Uncover the latest advancements in AI",
    backstory="You're a seasoned tech researcher with a keen eye for breakthrough technologies.",
    verbose=True,
    allow_delegation=False,
    tools=[search_tool]
)

writer = Agent(
    role="Tech Writer",
    goal="Create engaging content about AI advancements",
    backstory="You're a skilled writer with a talent for making complex topics accessible to a wide audience.",
    verbose=True,
    allow_delegation=False
)

# Create tasks
research_task = Task(
    description="Research the top 3 breakthroughs in AI in the past year. Focus on practical applications and potential impact.",
    expected_output="A detailed report on the top 3 AI breakthroughs, including their applications and potential impact.",
    agent=researcher
)

writing_task = Task(
    description="Using the research report, write a blog post about the most exciting AI advancements. Make it engaging for a general audience.",
    expected_output="An 800-word blog post highlighting the most exciting recent AI advancements.",
    agent=writer
)

# Create crew
ai_news_crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, writing_task],
    process=Process.sequential,
    verbose=2
)

# Run the crew
result = ai_news_crew.kickoff()

print(result)
```

## Conclusion

In this lesson, we've covered the core concepts of CrewAI: Agents, Tasks, Crews, and Processes. We've also explored how these components interact and integrate with Language Models. Understanding these concepts is crucial for building effective AI workflows with CrewAI. In the next lesson, we'll dive into creating your first CrewAI project, applying these concepts in a practical scenario.

## Additional Resources
- CrewAI Documentation: https://docs.crewai.com/
- LangChain (for LLM integration): https://python.langchain.com/en/latest/index.html
- Hugging Face Transformers (for working with various LLMs): https://huggingface.co/transformers/

## Practice Exercises
1. Create a crew with three agents (Researcher, Analyst, and Writer) to produce a comprehensive report on a topic of your choice.
2. Implement a hierarchical process in a crew, with a manager agent overseeing task distribution.
3. Integrate a different LLM (e.g., Anthropic's Claude) into one of your agents and observe how it affects the agent's performance.
4. Design a custom tool for one of your agents (e.g., a data visualization tool) and incorporate it into a task.

