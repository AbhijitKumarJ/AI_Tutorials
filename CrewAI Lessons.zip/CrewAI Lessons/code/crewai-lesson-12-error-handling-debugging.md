# Lesson 12: Error Handling and Debugging

## Introduction
Error handling and debugging are crucial skills for developing robust and reliable CrewAI applications. In this lesson, we'll explore common errors, implement effective error handling strategies, and learn debugging techniques specific to CrewAI projects.

## Table of Contents
1. Common Errors in CrewAI Applications
2. Implementing Robust Error Handling
3. Debugging Techniques for CrewAI Projects
4. Logging and Telemetry
5. Graceful Degradation and Failure Recovery
6. Best Practices for Error Management

## 1. Common Errors in CrewAI Applications

Before we dive into error handling strategies, let's look at some common errors you might encounter in CrewAI applications:

### a. Configuration Errors
These occur when there are issues with the YAML configuration files or when required environment variables are missing.

Example:
```python
from crewai import Crew
from yaml import YAMLError

try:
    crew = Crew.from_config("config.yaml")
except YAMLError as e:
    print(f"Error in YAML configuration: {e}")
except KeyError as e:
    print(f"Missing required configuration key: {e}")
```

### b. Agent Initialization Errors
These can happen when creating agents with invalid parameters or when required dependencies are missing.

Example:
```python
from crewai import Agent
from crewai.exceptions import AgentInitializationError

try:
    agent = Agent(name="Researcher", llm="non_existent_model")
except AgentInitializationError as e:
    print(f"Failed to initialize agent: {e}")
```

### c. Task Execution Errors
These occur during task execution, often due to issues with tool usage or LLM interactions.

Example:
```python
from crewai import Task
from crewai.exceptions import TaskExecutionError

try:
    result = task.execute()
except TaskExecutionError as e:
    print(f"Task execution failed: {e}")
```

### d. Memory-related Errors
These can happen when there are issues with memory storage or retrieval.

Example:
```python
from crewai.memory import Memory
from crewai.exceptions import MemoryError

try:
    memory = Memory()
    memory.save("key", "value")
except MemoryError as e:
    print(f"Memory operation failed: {e}")
```

### e. API Rate Limit Errors
These occur when you exceed the rate limits of external APIs, such as LLM providers.

Example:
```python
from crewai.llm import OpenAILLM
from openai import RateLimitError

try:
    llm = OpenAILLM()
    response = llm.generate("Prompt")
except RateLimitError as e:
    print(f"API rate limit exceeded: {e}")
```

## 2. Implementing Robust Error Handling

To create reliable CrewAI applications, it's essential to implement robust error handling at various levels:

### a. Agent-level Error Handling

Create a custom agent class that handles errors gracefully:

```python
from crewai import Agent
from crewai.exceptions import AgentError

class RobustAgent(Agent):
    def execute_task(self, task):
        try:
            return super().execute_task(task)
        except AgentError as e:
            print(f"Agent {self.name} encountered an error: {e}")
            return f"Error: {str(e)}"
```

### b. Task-level Error Handling

Implement a task wrapper that catches and logs errors:

```python
from crewai import Task
from crewai.exceptions import TaskError

def execute_task_safely(task):
    try:
        return task.execute()
    except TaskError as e:
        print(f"Task '{task.name}' failed: {e}")
        return None
```

### c. Crew-level Error Handling

Create a custom crew class with error handling:

```python
from crewai import Crew
from crewai.exceptions import CrewError

class RobustCrew(Crew):
    def kickoff(self):
        try:
            return super().kickoff()
        except CrewError as e:
            print(f"Crew execution failed: {e}")
            return None
```

## 3. Debugging Techniques for CrewAI Projects

Debugging CrewAI projects requires a combination of standard Python debugging techniques and CrewAI-specific approaches:

### a. Using Python's built-in debugger (pdb)

Insert breakpoints in your code to pause execution and inspect variables:

```python
import pdb

def my_crewai_function():
    # ... some code ...
    pdb.set_trace()  # Execution will pause here
    # ... more code ...
```

### b. CrewAI's Verbose Mode

Enable verbose mode for detailed logging:

```python
from crewai import Crew

crew = Crew(
    agents=[...],
    tasks=[...],
    verbose=True  # Enable verbose mode
)
```

### c. Mocking External Dependencies

Use the `unittest.mock` module to isolate CrewAI components for testing:

```python
from unittest.mock import patch
from crewai import Agent

def test_agent_execution():
    with patch('crewai.llm.OpenAILLM.generate') as mock_generate:
        mock_generate.return_value = "Mocked LLM response"
        agent = Agent(name="TestAgent", llm="gpt-3.5-turbo")
        result = agent.execute_task(...)
        assert "Mocked LLM response" in result
```

## 4. Logging and Telemetry

Implement comprehensive logging and telemetry to aid in debugging and monitoring:

### a. Setting up Logging

Use Python's built-in logging module:

```python
import logging

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# In your CrewAI application
logger.debug("Initializing crew")
logger.info("Task completed successfully")
logger.error("An error occurred", exc_info=True)
```

### b. Implementing Telemetry

Use CrewAI's built-in telemetry features:

```python
from crewai import Crew
from crewai.telemetry import Telemetry

telemetry = Telemetry()

crew = Crew(
    agents=[...],
    tasks=[...],
    telemetry=telemetry
)

# After crew execution
telemetry_data = telemetry.get_data()
print(f"Total tokens used: {telemetry_data['total_tokens']}")
print(f"Execution time: {telemetry_data['execution_time']} seconds")
```

## 5. Graceful Degradation and Failure Recovery

Implement strategies for graceful degradation and failure recovery:

### a. Retry Mechanism

Create a retry decorator for functions that might fail due to transient issues:

```python
import time
from functools import wraps

def retry(max_attempts=3, delay=1):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            attempts = 0
            while attempts < max_attempts:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    attempts += 1
                    if attempts == max_attempts:
                        raise e
                    time.sleep(delay)
        return wrapper
    return decorator

@retry(max_attempts=3, delay=2)
def execute_task_with_retry(task):
    return task.execute()
```

### b. Fallback Mechanisms

Implement fallback strategies for critical components:

```python
from crewai.llm import OpenAILLM, AnthropicLLM

class FallbackLLM:
    def __init__(self):
        self.primary_llm = OpenAILLM()
        self.fallback_llm = AnthropicLLM()

    def generate(self, prompt):
        try:
            return self.primary_llm.generate(prompt)
        except Exception as e:
            print(f"Primary LLM failed: {e}. Falling back to secondary LLM.")
            return self.fallback_llm.generate(prompt)
```

## 6. Best Practices for Error Management in AI-driven Applications

1. **Expect the Unexpected**: Always assume that any operation can fail, especially when dealing with external services or AI models.

2. **Graceful Degradation**: Design your application to continue functioning, albeit with reduced capabilities, when encountering errors.

3. **Detailed Logging**: Implement comprehensive logging to capture context and state when errors occur.

4. **User-Friendly Error Messages**: Provide clear, actionable error messages to end-users while logging detailed information for developers.

5. **Monitoring and Alerts**: Set up monitoring and alert systems to catch and notify about critical errors in production.

6. **Regular Testing**: Continuously test your error handling code, including simulating various failure scenarios.

7. **Learn from Errors**: Analyze errors and exceptions to improve your application's robustness over time.

## Conclusion

Effective error handling and debugging are crucial for building reliable CrewAI applications. By understanding common errors, implementing robust error handling strategies, and utilizing debugging techniques specific to CrewAI, you can create more resilient AI-driven systems. Remember to leverage logging, telemetry, and best practices for comprehensive error management in your projects.

## File Layout

Here's a typical file layout for a CrewAI project with robust error handling:

```
my_crewai_project/
│
├── config/
│   └── config.yaml
│
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   └── robust_agent.py
│   │
│   ├── tasks/
│   │   ├── __init__.py
│   │   └── task_wrapper.py
│   │
│   ├── crews/
│   │   ├── __init__.py
│   │   └── robust_crew.py
│   │
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── error_handling.py
│   │   └── logging_config.py
│   │
│   └── main.py
│
├── tests/
│   ├── test_agents.py
│   ├── test_tasks.py
│   └── test_crews.py
│
├── .env
├── requirements.txt
└── README.md
```

This structure organizes your code into logical components, separating concerns and making it easier to implement and maintain robust error handling throughout your CrewAI application.
