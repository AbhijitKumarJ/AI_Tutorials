# Lesson 6: Building and Managing Crews in CrewAI

## Introduction

In this lesson, we'll explore the concept of Crews in CrewAI. A Crew is a group of agents working together to accomplish complex tasks. Understanding how to build and manage crews effectively is crucial for creating powerful AI-driven systems capable of handling sophisticated workflows.

## File Structure

Before we dive in, let's look at a typical file structure for a CrewAI project that includes crew definitions:

```
my_crewai_project/
│
├── src/
│   ├── my_project/
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── crew.py
│   │   ├── agents/
│   │   │   ├── __init__.py
│   │   │   ├── researcher.py
│   │   │   └── writer.py
│   │   ├── tasks/
│   │   │   ├── __init__.py
│   │   │   ├── research_task.py
│   │   │   └── writing_task.py
│   │   └── config/
│   │       ├── crew.yaml
│   │       ├── agents.yaml
│   │       └── tasks.yaml
│   └── tools/
│       └── custom_tool.py
├── tests/
│   └── test_crew.py
├── .env
├── pyproject.toml
└── README.md
```

In this structure, we define the crew in `crew.py`, with individual agents and tasks in their respective directories.

## Creating a Crew Instance

The first step in building a crew is creating a `Crew` instance. This is typically done in your main script or in a dedicated crew file.

Example in `src/my_project/crew.py`:

```python
from crewai import Crew, Agent, Task, Process

class ResearchCrew(Crew):
    def __init__(self):
        researcher = Agent(
            role="Researcher",
            goal="Conduct thorough research on given topics",
            backstory="You are an experienced researcher with expertise in various fields."
        )
        
        writer = Agent(
            role="Technical Writer",
            goal="Create clear and concise reports based on research findings",
            backstory="You are a skilled technical writer with a knack for explaining complex topics."
        )
        
        research_task = Task(
            description="Research the latest advancements in quantum computing",
            agent=researcher
        )
        
        writing_task = Task(
            description="Write a comprehensive report on quantum computing advancements",
            agent=writer
        )
        
        super().__init__(
            agents=[researcher, writer],
            tasks=[research_task, writing_task],
            process=Process.sequential,
            verbose=True
        )

# Usage
crew = ResearchCrew()
result = crew.kickoff()
```

## Configuring Crew Parameters

When creating a Crew, you can configure various parameters to control its behavior:

1. `process`: Defines how tasks are executed (sequential or hierarchical).
2. `verbose`: Enables detailed logging of crew operations.
3. `max_rpm`: Sets the maximum requests per minute to respect API rate limits.
4. `memory`: Enables crew-level memory for information sharing between agents.

Example with additional configuration:

```python
from crewai import Crew, Process

crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, writing_task],
    process=Process.sequential,
    verbose=True,
    max_rpm=10,
    memory=True
)
```

## Adding Agents and Tasks to a Crew

There are multiple ways to add agents and tasks to a crew:

1. During initialization (as shown above)
2. Using the `add_agent()` and `add_task()` methods
3. Loading from configuration files

### Using add methods:

```python
crew = Crew()
crew.add_agent(researcher)
crew.add_agent(writer)
crew.add_task(research_task)
crew.add_task(writing_task)
```

### Loading from configuration files:

You can define your agents and tasks in YAML files and load them into your crew.

Example `config/crew.yaml`:

```yaml
name: Research Crew
description: A crew for conducting research and writing reports
process: sequential
verbose: true
max_rpm: 10
memory: true
```

Example `config/agents.yaml`:

```yaml
researcher:
  role: Researcher
  goal: Conduct thorough research on given topics
  backstory: You are an experienced researcher with expertise in various fields.

writer:
  role: Technical Writer
  goal: Create clear and concise reports based on research findings
  backstory: You are a skilled technical writer with a knack for explaining complex topics.
```

Example `config/tasks.yaml`:

```yaml
research_task:
  description: Research the latest advancements in quantum computing
  agent: researcher

writing_task:
  description: Write a comprehensive report on quantum computing advancements
  agent: writer
```

Loading the configuration:

```python
import yaml
from crewai import Crew, Agent, Task

def load_config(file_path):
    with open(file_path, 'r') as file:
        return yaml.safe_load(file)

crew_config = load_config('config/crew.yaml')
agents_config = load_config('config/agents.yaml')
tasks_config = load_config('config/tasks.yaml')

agents = [Agent(**config) for config in agents_config.values()]
tasks = [Task(**config) for config in tasks_config.values()]

crew = Crew(agents=agents, tasks=tasks, **crew_config)
```

## Understanding Crew Execution Flow

The execution flow of a crew depends on the `process` parameter:

1. `Process.sequential`: Tasks are executed in the order they were added to the crew.
2. `Process.hierarchical`: A manager agent oversees the execution and can delegate tasks.

### Sequential Process:

```python
crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, writing_task],
    process=Process.sequential
)
result = crew.kickoff()
```

In this case, `research_task` will be completed before `writing_task` begins.

### Hierarchical Process:

```python
from crewai import Agent

manager = Agent(
    role="Project Manager",
    goal="Oversee the research and writing process",
    backstory="You are an experienced project manager with a background in scientific research."
)

crew = Crew(
    agents=[manager, researcher, writer],
    tasks=[research_task, writing_task],
    process=Process.hierarchical,
    manager_llm="gpt-4"  # Specify a powerful LLM for the manager
)
result = crew.kickoff()
```

In hierarchical mode, the manager agent will coordinate the execution of tasks, potentially reassigning or breaking them down as needed.

## Implementing Crew-level Callbacks and Event Handling

Crew-level callbacks allow you to execute custom logic at specific points during the crew's execution.

Example:

```python
def on_crew_start(crew):
    print(f"Crew '{crew.name}' has started its operation.")

def on_crew_end(crew, result):
    print(f"Crew '{crew.name}' has completed its tasks.")
    print(f"Final result: {result}")

crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, writing_task],
    on_start=on_crew_start,
    on_end=on_crew_end
)
```

For more granular control, you can use the event system:

```python
from crewai.events import on

@on("crew.start")
def handle_crew_start(crew):
    print(f"Crew '{crew.name}' is starting.")

@on("task.start")
def handle_task_start(task):
    print(f"Task '{task.description}' is starting.")

@on("task.end")
def handle_task_end(task, output):
    print(f"Task '{task.description}' has ended.")
    print(f"Output: {output}")

# These event handlers will be called automatically during crew execution
```

## Best Practices for Crew Composition and Management

1. **Clear Role Definition**: Ensure each agent in the crew has a well-defined role and goal.
2. **Task Alignment**: Match tasks to the most suitable agents based on their capabilities.
3. **Balanced Workload**: Distribute tasks evenly among agents to optimize performance.
4. **Effective Communication**: Use crew-level memory and well-structured tasks to facilitate information sharing between agents.
5. **Error Handling**: Implement robust error handling at the crew level to manage failures in individual tasks or agents.
6. **Scalability**: Design crews that can scale by adding more agents or tasks as needed.
7. **Monitoring and Logging**: Use the verbose mode and custom callbacks to monitor crew performance and debug issues.

## Testing Crews

Writing tests for your crews ensures they behave as expected. Here's an example of how to test a crew:

In `tests/test_crew.py`:

```python
import pytest
from crewai import Crew, Agent, Task, Process

def test_research_crew():
    researcher = Agent(role="Researcher", goal="Conduct research")
    writer = Agent(role="Writer", goal="Write reports")
    
    research_task = Task(description="Research quantum computing", agent=researcher)
    writing_task = Task(description="Write quantum computing report", agent=writer)
    
    crew = Crew(
        agents=[researcher, writer],
        tasks=[research_task, writing_task],
        process=Process.sequential
    )
    
    assert len(crew.agents) == 2
    assert len(crew.tasks) == 2
    assert crew.process == Process.sequential

    # You can also test the crew's execution, but this might require mocking the LLM calls
    # result = crew.kickoff()
    # assert isinstance(result, str)
    # assert "quantum computing" in result.lower()

@pytest.mark.asyncio
async def test_async_crew_execution():
    # Similar setup to the above test
    crew = ResearchCrew()  # Assuming ResearchCrew is your Crew subclass
    result = await crew.kickoff_async()
    assert result is not None
    # Add more assertions based on expected output
```

## Conclusion

Building and managing crews effectively is key to creating powerful AI systems with CrewAI. By understanding how to configure crews, add agents and tasks, and control the execution flow, you can create sophisticated AI workflows capable of handling complex, multi-step processes.

## Exercises

1. Create a crew with at least three agents and five tasks. Implement both sequential and hierarchical processes and compare the results.
2. Design a crew that uses crew-level memory to share information between tasks. Demonstrate how this improves the overall output.
3. Implement custom callbacks for crew start, task completion, and crew end. Use these to create a detailed log of the crew's operation.
4. Create a crew that can dynamically add tasks based on the output of previous tasks. (Hint: You might need to use the hierarchical process for this.)
5. Write a comprehensive test suite for a crew, including tests for individual agents, tasks, and the overall crew execution.

Remember to test your crews thoroughly in various scenarios to ensure they can handle different inputs and potential errors gracefully.

