# Lesson 7: Advanced Task Management in CrewAI

## Introduction

In this lesson, we'll dive deep into advanced task management techniques in CrewAI. We'll explore how to create complex task workflows, handle dependencies, and implement sophisticated error handling strategies. This knowledge will enable you to build more robust and flexible AI-driven systems capable of handling intricate, real-world scenarios.

## File Structure

Before we begin, let's look at a typical file structure for a CrewAI project that includes advanced task management:

```
my_crewai_project/
│
├── src/
│   ├── my_project/
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── crew.py
│   │   ├── tasks/
│   │   │   ├── __init__.py
│   │   │   ├── base_task.py
│   │   │   ├── conditional_task.py
│   │   │   ├── data_analysis_task.py
│   │   │   └── report_generation_task.py
│   │   ├── agents/
│   │   │   ├── __init__.py
│   │   │   ├── analyst.py
│   │   │   └── reporter.py
│   │   └── config/
│   │       ├── tasks.yaml
│   │       └── agents.yaml
│   └── tools/
│       ├── __init__.py
│       └── data_processing_tool.py
├── tests/
│   └── test_advanced_tasks.py
├── .env
├── pyproject.toml
└── README.md
```

In this structure, we have separate files for different types of tasks, including a base task and a conditional task.

## Working with Conditional Tasks

Conditional tasks allow you to create dynamic workflows that adapt based on the output of previous tasks or other conditions.

Example in `src/my_project/tasks/conditional_task.py`:

```python
from crewai import Task
from crewai.tasks.conditional_task import ConditionalTask

class DataAnalysisTask(Task):
    def __init__(self, description, agent):
        super().__init__(description=description, agent=agent)

    def execute(self):
        # Simulate data analysis
        result = "Data analysis complete. Anomalies detected."
        return result

class DetailedAnalysisTask(ConditionalTask):
    def __init__(self, description, agent):
        condition = lambda output: "anomalies detected" in output.lower()
        super().__init__(description=description, agent=agent, condition=condition)

    def execute(self):
        return "Detailed analysis of anomalies completed."

# Usage
analyst = Agent(role="Data Analyst", goal="Analyze data thoroughly")
initial_analysis = DataAnalysisTask("Perform initial data analysis", analyst)
detailed_analysis = DetailedAnalysisTask("Perform detailed analysis if anomalies are detected", analyst)

crew = Crew(
    agents=[analyst],
    tasks=[initial_analysis, detailed_analysis],
    process=Process.sequential
)

result = crew.kickoff()
```

In this example, the `DetailedAnalysisTask` will only be executed if the condition (presence of anomalies) is met in the output of the `DataAnalysisTask`.

## Implementing Task Dependencies and Context Sharing

CrewAI allows you to create complex task workflows by defining dependencies between tasks and sharing context.

Example in `src/my_project/tasks/data_analysis_task.py`:

```python
from crewai import Task

class DataCollectionTask(Task):
    def __init__(self, description, agent):
        super().__init__(description=description, agent=agent)

    def execute(self):
        # Simulate data collection
        return "Collected data: [sample data]"

class DataAnalysisTask(Task):
    def __init__(self, description, agent, data_collection_task):
        super().__init__(description=description, agent=agent)
        self.context = [data_collection_task]

    def execute(self):
        collected_data = self.context[0].output
        # Analyze the collected data
        return f"Analysis results based on: {collected_data}"

# Usage
data_collector = Agent(role="Data Collector", goal="Collect accurate data")
analyst = Agent(role="Data Analyst", goal="Analyze data thoroughly")

collection_task = DataCollectionTask("Collect relevant data", data_collector)
analysis_task = DataAnalysisTask("Analyze collected data", analyst, collection_task)

crew = Crew(
    agents=[data_collector, analyst],
    tasks=[collection_task, analysis_task],
    process=Process.sequential
)

result = crew.kickoff()
```

In this example, the `DataAnalysisTask` depends on the output of the `DataCollectionTask`, which is passed as context.

## Handling Complex Task Outputs and Conversions

For tasks that produce or require complex data structures, you can use Pydantic models to ensure type safety and easy data manipulation.

Example in `src/my_project/tasks/report_generation_task.py`:

```python
from pydantic import BaseModel, Field
from typing import List
from crewai import Task

class AnalysisResult(BaseModel):
    key_findings: List[str] = Field(description="List of key findings from the analysis")
    anomalies: List[str] = Field(description="List of detected anomalies")
    confidence_score: float = Field(description="Overall confidence score of the analysis")

class ReportGenerationTask(Task):
    def __init__(self, description, agent):
        super().__init__(description=description, agent=agent, output_pydantic=AnalysisResult)

    def execute(self):
        # Simulate report generation
        return AnalysisResult(
            key_findings=["Finding 1", "Finding 2"],
            anomalies=["Anomaly A", "Anomaly B"],
            confidence_score=0.85
        )

# Usage
reporter = Agent(role="Report Generator", goal="Generate comprehensive reports")
report_task = ReportGenerationTask("Generate analysis report", reporter)

crew = Crew(agents=[reporter], tasks=[report_task])
result = crew.kickoff()

# Access the structured output
print(f"Confidence Score: {result.pydantic.confidence_score}")
for finding in result.pydantic.key_findings:
    print(f"- {finding}")
```

This approach ensures that the task output adheres to a predefined structure, making it easier to work with in subsequent tasks or external systems.

## Task Chaining and Sequential vs. Parallel Execution

CrewAI supports both sequential and parallel task execution, allowing for complex workflows.

Example of task chaining with both sequential and parallel execution:

```python
from crewai import Crew, Process

# Define your tasks: task1, task2, task3, task4, task5

# Sequential execution
sequential_crew = Crew(
    tasks=[task1, task2, task3, task4, task5],
    process=Process.sequential
)

# Parallel execution with sequential steps
parallel_crew = Crew(
    tasks=[
        task1,
        [task2, task3],  # These tasks will run in parallel
        task4,
        task5
    ],
    process=Process.sequential
)

# Kickoff both crews
sequential_result = sequential_crew.kickoff()
parallel_result = parallel_crew.kickoff()
```

In the parallel execution example, `task2` and `task3` will run concurrently, potentially improving overall execution time.

## Error Handling and Recovery Strategies for Tasks

Implementing robust error handling is crucial for creating resilient AI workflows. Here's an example of how to implement error handling and recovery in CrewAI tasks:

```python
import logging
from crewai import Task

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RobustDataAnalysisTask(Task):
    def __init__(self, description, agent, max_retries=3):
        super().__init__(description=description, agent=agent)
        self.max_retries = max_retries

    def execute(self):
        for attempt in range(self.max_retries):
            try:
                # Attempt to perform the analysis
                result = self._perform_analysis()
                return result
            except Exception as e:
                logger.warning(f"Attempt {attempt + 1} failed: {str(e)}")
                if attempt == self.max_retries - 1:
                    logger.error("All retry attempts exhausted. Falling back to safe default.")
                    return self._fallback_analysis()

    def _perform_analysis(self):
        # Simulating an analysis that might fail
        if random.random() < 0.5:
            raise Exception("Analysis failed due to data inconsistency")
        return "Analysis completed successfully"

    def _fallback_analysis(self):
        return "Fallback analysis: Unable to complete full analysis due to errors"

# Usage
analyst = Agent(role="Data Analyst", goal="Perform robust data analysis")
robust_task = RobustDataAnalysisTask("Perform data analysis with error handling", analyst)

crew = Crew(agents=[analyst], tasks=[robust_task])
result = crew.kickoff()
```

This implementation includes retry logic and a fallback mechanism to ensure that the task always produces a result, even in the face of errors.

## Best Practices for Designing Complex Task Workflows

1. **Modularity**: Break complex workflows into smaller, manageable tasks.
2. **Clear Dependencies**: Explicitly define task dependencies and ensure proper context sharing.
3. **Error Resilience**: Implement comprehensive error handling and recovery mechanisms.
4. **Scalability**: Design tasks that can scale with increasing data or complexity.
5. **Observability**: Add logging and monitoring to track task progress and diagnose issues.
6. **Flexibility**: Use conditional tasks to create adaptive workflows.
7. **Type Safety**: Utilize Pydantic models for complex inputs and outputs to ensure data integrity.
8. **Performance Optimization**: Use parallel execution where appropriate to improve efficiency.

## Testing Advanced Task Workflows

Writing tests for advanced task workflows ensures that your complex logic works as expected. Here's an example of how to test a conditional task workflow:

In `tests/test_advanced_tasks.py`:

```python
import pytest
from crewai import Crew, Agent
from my_project.tasks.conditional_task import DataAnalysisTask, DetailedAnalysisTask

@pytest.fixture
def analyst():
    return Agent(role="Data Analyst", goal="Analyze data thoroughly")

def test_conditional_task_workflow(analyst):
    initial_analysis = DataAnalysisTask("Perform initial data analysis", analyst)
    detailed_analysis = DetailedAnalysisTask("Perform detailed analysis if anomalies are detected", analyst)

    crew = Crew(
        agents=[analyst],
        tasks=[initial_analysis, detailed_analysis],
        process=Process.sequential
    )

    result = crew.kickoff()

    assert "Data analysis complete" in result
    assert "Detailed analysis" in result  # This assertion checks if the conditional task was executed

@pytest.mark.asyncio
async def test_parallel_task_execution():
    # Set up parallel tasks
    task1 = Task("Task 1", some_agent)
    task2 = Task("Task 2", some_agent)
    task3 = Task("Task 3", some_agent)

    crew = Crew(
        agents=[some_agent],
        tasks=[task1, [task2, task3]],  # task2 and task3 will run in parallel
        process=Process.sequential
    )

    result = await crew.kickoff_async()

    # Add assertions to check if all tasks were completed
    assert "Task 1 completed" in result
    assert "Task 2 completed" in result
    assert "Task 3 completed" in result

```

These tests verify that your conditional tasks and parallel execution are working as expected.

## Conclusion

Advanced task management in CrewAI allows you to create sophisticated, adaptive AI workflows. By mastering conditional tasks, dependencies, error handling, and complex data structures, you can build robust systems capable of handling real-world complexities. Remember to always design with modularity, scalability, and observability in mind to create maintainable and efficient AI-driven applications.

## Exercises

1. Create a workflow with at least five tasks, including at least two conditional tasks. Ensure that the flow adapts based on the output of previous tasks.
2. Implement a task that uses a custom tool to process data, and chain it with subsequent tasks that depend on its output.
3. Design a parallel task execution workflow where some tasks run concurrently while others remain sequential. Measure the performance improvement compared to a fully sequential workflow.
4. Create a task that handles a complex data structure using Pydantic models for both input and output. Implement error handling for cases where the input doesn't match the expected structure.
5. Implement a robust error handling strategy for a series of tasks, including retries, fallbacks, and logging. Test this implementation by intentionally introducing errors and observing the recovery process.

Remember to thoroughly test your implementations, considering various scenarios and edge cases to ensure your advanced task management strategies are robust and reliable.

