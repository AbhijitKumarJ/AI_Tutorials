# Lesson 17: CrewAI CLI and Deployment

## Introduction

In this lesson, we'll explore the CrewAI Command Line Interface (CLI) and various deployment strategies for CrewAI applications. We'll cover how to use the CLI for project management, running CrewAI applications, and deploying them in different environments. This knowledge is crucial for efficiently managing CrewAI projects and ensuring smooth operation in production settings.

## 1. CrewAI Command Line Interface (CLI)

The CrewAI CLI provides a set of commands to help manage and run CrewAI projects. Let's explore the available commands and their usage.

### Installation

The CrewAI CLI is included when you install CrewAI. If you haven't installed CrewAI yet, you can do so using pip:

```bash
pip install crewai
```

### Available Commands

To see all available commands, run:

```bash
crewai --help
```

Here's an overview of the main commands:

1. **create**: Create a new crew, pipeline, or flow
2. **version**: Show the installed version of CrewAI
3. **train**: Train the crew
4. **replay**: Replay the crew execution from a specific task
5. **log-tasks-outputs**: Retrieve latest crew.kickoff() task outputs
6. **reset-memories**: Reset the crew memories
7. **test**: Test the crew and evaluate the results
8. **install**: Install the Crew
9. **run**: Run the Crew
10. **deploy**: Deploy-related commands
11. **tool**: Tool Repository related commands

Let's explore some of these commands in detail:

#### Creating a New Crew

To create a new crew project:

```bash
crewai create crew my_new_crew
```

This command will create a new directory with the following structure:

```
my_new_crew/
├── src/
│   └── my_new_crew/
│       ├── __init__.py
│       ├── main.py
│       ├── crew.py
│       ├── tools/
│       │   ├── __init__.py
│       │   └── custom_tool.py
│       └── config/
│           ├── agents.yaml
│           └── tasks.yaml
├── tests/
├── .env
├── .gitignore
├── pyproject.toml
└── README.md
```

#### Running a Crew

To run your CrewAI project:

```bash
crewai run
```

This command will execute the `run_crew()` function in your `main.py` file.

#### Training a Crew

To train your crew:

```bash
crewai train -n 5 -f trained_data.pkl
```

This will run the training process for 5 iterations and save the trained data to `trained_data.pkl`.

#### Testing a Crew

To test and evaluate your crew:

```bash
crewai test -n 3 -m gpt-4
```

This will run 3 test iterations using the GPT-4 model for evaluation.

#### Deploying a Crew

To deploy your crew (assuming you've set up deployment configurations):

```bash
crewai deploy push
```

We'll cover deployment in more detail later in this lesson.

## 2. Deploying CrewAI Applications

Deploying CrewAI applications involves several considerations, including environment setup, scalability, and monitoring. Let's explore different deployment options and best practices.

### Environment Setup

Before deploying, ensure your CrewAI application is properly configured for the target environment:

1. **Environment Variables**: Use environment variables for sensitive information like API keys. In your production environment, set these variables securely.

```python
import os

api_key = os.environ.get('CREWAI_API_KEY')
```

2. **Configuration Files**: Use separate configuration files for different environments (development, staging, production).

Example `config.yaml`:

```yaml
development:
  log_level: DEBUG
  max_concurrent_tasks: 5

production:
  log_level: INFO
  max_concurrent_tasks: 20
```

Load the configuration based on the environment:

```python
import yaml
import os

env = os.environ.get('CREWAI_ENV', 'development')

with open('config.yaml', 'r') as f:
    config = yaml.safe_load(f)[env]
```

### Deployment Options

#### 1. Traditional Server Deployment

For smaller-scale applications, you can deploy CrewAI on a traditional server:

1. Set up a virtual environment on your server:

```bash
python -m venv crewai_env
source crewai_env/bin/activate
```

2. Install CrewAI and dependencies:

```bash
pip install -r requirements.txt
```

3. Set up environment variables:

```bash
export CREWAI_API_KEY=your_api_key_here
export CREWAI_ENV=production
```

4. Run your CrewAI application:

```bash
python main.py
```

Consider using a process manager like `supervisord` to keep your application running and manage logs.

#### 2. Containerization with Docker

Containerizing your CrewAI application with Docker ensures consistency across different environments:

1. Create a `Dockerfile`:

```dockerfile
FROM python:3.10-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

ENV CREWAI_ENV=production

CMD ["python", "main.py"]
```

2. Build and run the Docker image:

```bash
docker build -t crewai-app .
docker run -e CREWAI_API_KEY=your_api_key_here crewai-app
```

#### 3. Cloud Platform Deployment

For scalable deployments, consider using cloud platforms like AWS, Google Cloud, or Azure. Here's an example using AWS Elastic Beanstalk:

1. Install the Elastic Beanstalk CLI:

```bash
pip install awsebcli
```

2. Initialize your Elastic Beanstalk application:

```bash
eb init -p python-3.10 crewai-app
```

3. Create an Elastic Beanstalk environment:

```bash
eb create crewai-app-env
```

4. Deploy your application:

```bash
eb deploy
```

Remember to configure environment variables in the Elastic Beanstalk console.

### Scalability Considerations

As your CrewAI application grows, consider these scalability strategies:

1. **Horizontal Scaling**: Use container orchestration tools like Kubernetes to manage multiple instances of your application.

2. **Task Queue**: Implement a task queue system (e.g., Celery with Redis) for handling long-running CrewAI tasks asynchronously.

3. **Caching**: Implement caching mechanisms to reduce redundant computations and API calls.

4. **Database Optimization**: If your CrewAI application uses a database, optimize queries and consider using read replicas for heavy read operations.

## 3. Continuous Integration and Continuous Deployment (CI/CD)

Implementing a CI/CD pipeline ensures smooth and consistent deployment of your CrewAI application. Here's an example using GitHub Actions:

1. Create a `.github/workflows/deploy.yml` file in your repository:

```yaml
name: Deploy CrewAI Application

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.10'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Run tests
      run: python -m unittest discover tests
    - name: Deploy to production
      if: success()
      run: |
        # Add your deployment commands here
        # For example, if using AWS Elastic Beanstalk:
        # pip install awsebcli
        # eb deploy
      env:
        AWS_ACCESS_KEY_ID: ${{ secrets.AWS_ACCESS_KEY_ID }}
        AWS_SECRET_ACCESS_KEY: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
```

This workflow will run tests and deploy your application whenever changes are pushed to the main branch.

## 4. Monitoring and Logging

Proper monitoring and logging are crucial for maintaining a healthy CrewAI application in production:

1. **Application Logging**: Use Python's logging module to log important events and errors:

```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def run_crew():
    try:
        crew.kickoff()
        logger.info("Crew execution completed successfully")
    except Exception as e:
        logger.error(f"Crew execution failed: {str(e)}")
```

2. **Centralized Logging**: Use a centralized logging system like ELK Stack (Elasticsearch, Logstash, Kibana) or Cloud-based solutions like AWS CloudWatch Logs.

3. **Performance Monitoring**: Implement application performance monitoring (APM) tools like New Relic or Datadog to track your CrewAI application's performance.

4. **Custom Metrics**: Track custom metrics relevant to your CrewAI application, such as task completion rates, agent performance, etc.

```python
from prometheus_client import Counter, Histogram

task_counter = Counter('crewai_tasks_total', 'Total number of CrewAI tasks executed')
task_duration = Histogram('crewai_task_duration_seconds', 'Duration of CrewAI tasks')

def run_task():
    task_counter.inc()
    with task_duration.time():
        # Execute task
        pass
```

5. **Alerting**: Set up alerts for critical issues or performance thresholds to ensure quick response to problems.

## 5. Security Considerations

When deploying CrewAI applications, keep these security considerations in mind:

1. **API Key Management**: Never hardcode API keys. Use environment variables or secret management systems.

2. **Input Validation**: Validate and sanitize all inputs to prevent injection attacks.

3. **Rate Limiting**: Implement rate limiting to prevent abuse of your CrewAI application.

4. **Network Security**: Use firewalls and VPCs to control access to your application and its resources.

5. **Regular Updates**: Keep CrewAI and all dependencies up to date to patch security vulnerabilities.

## 6. Best Practices for Managing CrewAI Applications in Production

1. **Version Control**: Use Git for version control and maintain a clear branching strategy (e.g., GitFlow).

2. **Documentation**: Maintain comprehensive documentation, including deployment procedures, configuration options, and troubleshooting guides.

3. **Backup and Disaster Recovery**: Implement regular backups of your application data and have a disaster recovery plan in place.

4. **Staging Environment**: Always test changes in a staging environment that mirrors production before deploying.

5. **Rollback Plan**: Have a clear rollback plan in case a deployment introduces critical issues.

6. **Performance Tuning**: Regularly analyze and optimize your CrewAI application's performance based on production metrics.

7. **Compliance**: Ensure your deployment meets any relevant compliance requirements (e.g., GDPR, HIPAA).

## Conclusion

Deploying CrewAI applications requires careful consideration of various factors, from environment setup to monitoring and security. By leveraging the CrewAI CLI, implementing robust deployment strategies, and following best practices, you can ensure that your CrewAI applications run smoothly and efficiently in production environments.

In the next lesson, we'll explore real-world applications and case studies of CrewAI, building upon the deployment knowledge gained here to understand how CrewAI is used in production scenarios.
