# Lesson 18: Real-World Applications and Case Studies of CrewAI

## Introduction

In this lesson, we'll explore real-world applications of CrewAI, analyze their architecture and design patterns, and walk through the process of implementing a complete CrewAI project. We'll also discuss how to handle common challenges in production scenarios and integrate CrewAI with existing systems. This practical approach will help you understand how to apply CrewAI concepts in real-world situations.

## 1. Analyzing Real-World CrewAI Projects

Let's examine three real-world applications of CrewAI and analyze their architecture and design patterns.

### Case Study 1: Automated Customer Support System

#### Overview
A large e-commerce company implemented CrewAI to create an automated customer support system that can handle a wide range of customer inquiries, from order tracking to product recommendations.

#### Architecture

```
[Customer Input] -> [Intent Classifier Agent]
                           |
                           v
    [Order Tracking Agent] <- -> [Product Recommendation Agent]
                           |
                           v
    [Refund Processing Agent] <- -> [Escalation Agent]
                           |
                           v
                   [Response Generator Agent]
```

#### Key Components
1. **Intent Classifier Agent**: Determines the type of customer inquiry.
2. **Specialized Agents**: Handle specific tasks (order tracking, recommendations, refunds).
3. **Escalation Agent**: Determines when to involve human support.
4. **Response Generator Agent**: Formulates the final response to the customer.

#### Design Patterns
- **Pipeline Pattern**: Customer inquiries flow through a series of specialized agents.
- **Hierarchical Decision Making**: The Intent Classifier Agent delegates to specialized agents.
- **Feedback Loop**: Agents can request additional information or escalate if needed.

#### Code Snippet (Intent Classifier Agent)

```python
from crewai import Agent, Task

class IntentClassifierAgent(Agent):
    def __init__(self):
        super().__init__(
            role="Intent Classifier",
            goal="Accurately determine the intent of customer inquiries",
            backstory="You are an AI with expertise in natural language processing and customer service.",
        )

    def classify_intent(self, customer_inquiry):
        task = Task(
            description=f"Classify the intent of the following customer inquiry: '{customer_inquiry}'",
            expected_output="The intent category (e.g., 'order_tracking', 'product_recommendation', 'refund_request', 'general_inquiry')",
        )
        return self.execute_task(task)

# Usage
classifier = IntentClassifierAgent()
intent = classifier.classify_intent("Where is my order #12345?")
print(f"Classified Intent: {intent}")
```

### Case Study 2: Automated Financial Analysis and Reporting

#### Overview
A financial services firm implemented CrewAI to automate the process of analyzing market data, generating financial reports, and providing investment recommendations.

#### Architecture

```
[Data Collection Agent] -> [Data Preprocessing Agent]
                                   |
                                   v
[Market Analysis Agent] <- -> [Financial Modeling Agent]
                                   |
                                   v
[Report Generation Agent] <- -> [Investment Recommendation Agent]
                                   |
                                   v
                           [Compliance Check Agent]
```

#### Key Components
1. **Data Collection Agent**: Gathers financial data from various sources.
2. **Data Preprocessing Agent**: Cleans and normalizes the collected data.
3. **Market Analysis Agent**: Performs market trend analysis.
4. **Financial Modeling Agent**: Creates financial models based on the analyzed data.
5. **Report Generation Agent**: Compiles findings into comprehensive reports.
6. **Investment Recommendation Agent**: Generates investment suggestions.
7. **Compliance Check Agent**: Ensures all outputs comply with financial regulations.

#### Design Patterns
- **Data Pipeline**: Data flows through collection, preprocessing, and analysis stages.
- **Expert System**: Specialized agents for different aspects of financial analysis.
- **Validation Chain**: Compliance checks are performed as the final step.

#### Code Snippet (Financial Modeling Agent)

```python
from crewai import Agent, Task
import pandas as pd

class FinancialModelingAgent(Agent):
    def __init__(self):
        super().__init__(
            role="Financial Modeler",
            goal="Create accurate financial models based on market data",
            backstory="You are an expert in financial modeling with years of experience in the financial industry.",
        )

    def create_financial_model(self, market_data: pd.DataFrame):
        task = Task(
            description="Create a financial model based on the provided market data. Include projections for the next quarter.",
            expected_output="A JSON string containing the financial model results, including revenue projections, cost estimates, and profit margins.",
        )
        return self.execute_task(task, context=market_data.to_json())

# Usage
modeling_agent = FinancialModelingAgent()
market_data = pd.DataFrame({"date": ["2023-01-01", "2023-01-02"], "close_price": [100, 101]})
model_results = modeling_agent.create_financial_model(market_data)
print(f"Financial Model Results: {model_results}")
```

### Case Study 3: Automated Content Creation and Marketing Campaign Management

#### Overview
A digital marketing agency used CrewAI to create an automated system for content creation, social media management, and marketing campaign optimization.

#### Architecture

```
[Content Ideation Agent] -> [Content Creation Agent]
              ^                      |
              |                      v
[Trend Analysis Agent] <- [Social Media posting Agent]
              ^                      |
              |                      v
  [Analytics Agent] <- [Campaign Optimization Agent]
```

#### Key Components
1. **Trend Analysis Agent**: Identifies current trends and popular topics.
2. **Content Ideation Agent**: Generates content ideas based on trends and brand guidelines.
3. **Content Creation Agent**: Produces various types of content (blog posts, social media updates, etc.).
4. **Social Media Posting Agent**: Manages posting schedules and interactions across platforms.
5. **Analytics Agent**: Tracks performance metrics of content and campaigns.
6. **Campaign Optimization Agent**: Adjusts strategies based on performance data.

#### Design Patterns
- **Feedback Loop**: Analytics inform trend analysis and content ideation.
- **Task Specialization**: Each agent focuses on a specific aspect of the marketing process.
- **Iterative Optimization**: Campaigns are continuously refined based on performance data.

#### Code Snippet (Content Creation Agent)

```python
from crewai import Agent, Task

class ContentCreationAgent(Agent):
    def __init__(self):
        super().__init__(
            role="Content Creator",
            goal="Create engaging and relevant content for various platforms",
            backstory="You are a versatile content creator with expertise in writing for different mediums and audiences.",
        )

    def create_content(self, topic: str, platform: str, word_count: int):
        task = Task(
            description=f"Create a {platform} post about '{topic}' in approximately {word_count} words.",
            expected_output="The complete text of the content piece, optimized for the specified platform.",
        )
        return self.execute_task(task)

# Usage
creator = ContentCreationAgent()
blog_post = creator.create_content("The Impact of AI on Digital Marketing", "blog", 500)
print(f"Generated Blog Post: {blog_post[:100]}...")  # Print first 100 characters
```

## 2. Implementing a Complete CrewAI Project

Now, let's walk through the process of implementing a complete CrewAI project for a real-world scenario: an Automated Research Assistant for academic purposes.

### Project Overview
The Automated Research Assistant will help researchers gather information, analyze papers, and generate summaries and bibliographies.

### Step 1: Project Setup

First, set up your CrewAI project structure:

```
research_assistant/
├── src/
│   └── research_assistant/
│       ├── __init__.py
│       ├── main.py
│       ├── crew.py
│       ├── agents/
│       │   ├── __init__.py
│       │   ├── search_agent.py
│       │   ├── analysis_agent.py
│       │   └── writing_agent.py
│       ├── tools/
│       │   ├── __init__.py
│       │   ├── search_tool.py
│       │   └── pdf_extractor.py
│       └── config/
│           ├── agents.yaml
│           └── tasks.yaml
├── tests/
├── .env
├── .gitignore
├── pyproject.toml
└── README.md
```

### Step 2: Implement Agents

Create specialized agents for different aspects of the research process. Here's an example of the `SearchAgent`:

```python
# src/research_assistant/agents/search_agent.py
from crewai import Agent
from research_assistant.tools.search_tool import SearchTool

class SearchAgent(Agent):
    def __init__(self):
        super().__init__(
            role="Research Search Specialist",
            goal="Find relevant academic papers and resources",
            backstory="You are an AI with extensive knowledge of academic databases and search techniques.",
            tools=[SearchTool()],
        )

    def search_papers(self, query: str, max_results: int = 5):
        task = self.create_task(
            description=f"Search for academic papers related to: {query}. Return top {max_results} results.",
            expected_output="A list of dictionaries, each containing 'title', 'authors', 'publication_date', and 'summary' of the paper.",
        )
        return self.execute_task(task)
```

Implement similar agents for analysis and writing in their respective files.

### Step 3: Implement Tools

Create custom tools to extend the capabilities of your agents. Here's an example of the `SearchTool`:

```python
# src/research_assistant/tools/search_tool.py
from crewai import Tool
import requests

class SearchTool(Tool):
    def __init__(self):
        super().__init__(
            name="Academic Search",
            description="Search for academic papers in research databases",
            func=self.search,
        )

    def search(self, query: str, max_results: int = 5):
        # Implement actual search logic here, e.g., using an API
        # This is a simplified example
        response = requests.get(f"https://api.example.com/search?q={query}&max={max_results}")
        return response.json()
```

### Step 4: Configure Agents and Tasks

Set up your `agents.yaml` and `tasks.yaml` files:

```yaml
# src/research_assistant/config/agents.yaml
search_agent:
  role: "Research Search Specialist"
  goal: "Find relevant academic papers and resources"
  backstory: "You are an AI with extensive knowledge of academic databases and search techniques."

analysis_agent:
  role: "Research Analysis Expert"
  goal: "Analyze and synthesize information from academic papers"
  backstory: "You are an AI with a deep understanding of various research methodologies and analytical techniques."

writing_agent:
  role: "Academic Writing Specialist"
  goal: "Generate well-structured summaries and bibliographies"
  backstory: "You are an AI with expertise in academic writing styles and formatting."
```

```yaml
# src/research_assistant/config/tasks.yaml
search_task:
  description: "Search for academic papers on the given topic"
  expected_output: "A list of relevant academic papers with their summaries"
  agent: search_agent

analysis_task:
  description: "Analyze the content of the found papers and extract key information"
  expected_output: "A comprehensive analysis of the papers, including main findings and methodologies"
  agent: analysis_agent

writing_task:
  description: "Generate a summary report and bibliography based on the analyzed papers"
  expected_output: "A well-structured summary report and a properly formatted bibliography"
  agent: writing_agent
```

### Step 5: Implement the Crew

Create the main crew that will orchestrate the research process:

```python
# src/research_assistant/crew.py
from crewai import Crew, Process
from research_assistant.agents.search_agent import SearchAgent
from research_assistant.agents.analysis_agent import AnalysisAgent
from research_assistant.agents.writing_agent import WritingAgent

class ResearchAssistantCrew(Crew):
    def __init__(self):
        self.search_agent = SearchAgent()
        self.analysis_agent = AnalysisAgent()
        self.writing_agent = WritingAgent()

        super().__init__(
            agents=[self.search_agent, self.analysis_agent, self.writing_agent],
            tasks=self.get_tasks(),
            process=Process.sequential,
            verbose=True,
        )

    def get_tasks(self):
        return [
            self.create_task(
                description="Search for academic papers on the given topic",
                agent=self.search_agent,
            ),
            self.create_task(
                description="Analyze the content of the found papers and extract key information",
                agent=self.analysis_agent,
            ),
            self.create_task(
                description="Generate a summary report and bibliography based on the analyzed papers",
                agent=self.writing_agent,
            ),
        ]
```

### Step 6: Implement the Main Execution Script

Create the main script to run your CrewAI project:

```python
# src/research_assistant/main.py
from research_assistant.crew import ResearchAssistantCrew

def main():
    crew = ResearchAssistantCrew()
    result = crew.kickoff(inputs={"topic": "Impact of AI on healthcare"})
    print("Research Assistant Results:")
    print(result)

if __name__ == "__main__":
    main()
```

### Step 7: Run and Iterate

Run your CrewAI project and iterate based on the results:

```bash
python -m research_assistant.main
```

## 3. Handling Real-World Challenges

When implementing CrewAI in production scenarios, you may encounter various challenges. Here are some common issues and strategies to address them:

### Scalability
- **Challenge**: Handling a large number of concurrent requests or processing large datasets.
- **Solution**: Implement a task queue system (e.g., Celery with Redis) to manage asynchronous tasks and distribute workload across multiple workers.

```python
from celery import Celery
from research_assistant.crew import ResearchAssistantCrew

app = Celery('research_tasks', broker='redis://localhost:6379/0')

@app.task
def run_research(topic):
    crew = ResearchAssistantCrew()
    return crew.kickoff(inputs={"topic": topic})

# Usage
result = run_research.delay("Impact of AI on healthcare")
```

### Error Handling and Resilience
- **Challenge**: Ensuring the system can handle failures gracefully and recover from errors.
- **Solution**: Implement robust error handling, retry mechanisms, and circuit breakers.

```python
from tenacity import retry, stop_after_attempt, wait_exponential

class ResilienceAgent(Agent):
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    def execute_task_with_retry(self, task):
        try:
            return self.execute_task(task)
        except Exception as e:
            logging.error(f"Task execution failed: {str(e)}")
            raise
```

### Performance Optimization
- **Challenge**: Ensuring quick response times and efficient resource utilization.
- **Solution**: Implement caching mechanisms, optimize database queries, and use profiling tools to identify bottlenecks.

```python
from functools import lru_cache

class CachedSearchAgent(Agent):
    @lru_cache(maxsize=100)
    def cached_search(self, query):
        return self.search_papers(query)

    def search_papers(self, query):
        # Implement search logic here
        pass
```

### Data Privacy and Security
- **Challenge**: Ensuring sensitive data is protected and complying with data protection regulations.
- **Solution**: Implement encryption, access controls, and data anonymization techniques.

```python
from cryptography.fernet import Fernet

class SecureAgent(Agent):
    def __init__(self, encryption_key):
        super().__init__()
        self.fernet = Fernet(encryption_key)

    def process_sensitive_data(self, data):
        encrypted_data = self.fernet.encrypt(data.encode())
        # Process the encrypted data
        decrypted_result = self.fernet.decrypt(processed_result).decode()
        return decrypted_result
```

## 4. Integrating CrewAI with Existing Systems

To maximize the value of CrewAI in real-world scenarios, it's often necessary to integrate it with existing systems and workflows. Here are some strategies for effective integration:

### API Integration
Create RESTful APIs to allow existing systems to interact with your CrewAI application:

```python
from flask import Flask, request, jsonify
from research_assistant.crew import ResearchAssistantCrew

app = Flask(__name__)

@app.route('/research', methods=['POST'])
def conduct_research():
    topic = request.json['topic']
    crew = ResearchAssistantCrew()
    result = crew.kickoff(inputs={"topic": topic})
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
```

### Database Integration
Connect CrewAI to your existing databases to access and store data:

```python
import sqlite3
from crewai import Agent, Task

class DatabaseIntegratedAgent(Agent):
    def __init__(self, db_path):
        super().__init__()
        self.db_path = db_path

    def execute_query(self, query):
        task = Task(
            description=f"Execute the following SQL query and analyze the results: {query}",
            expected_output="A summary of the query results and any insights gained.",
        )
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(query)
            results = cursor.fetchall()
        
        return self.execute_task(task, context=str(results))

# Usage
db_agent = DatabaseIntegratedAgent('path/to/your/database.db')
insights = db_agent.execute_query("SELECT * FROM research_papers WHERE topic = 'AI'")
print(insights)
```

### Message Queue Integration
Use message queues to handle asynchronous communication between CrewAI and other systems:

```python
import pika
from research_assistant.crew import ResearchAssistantCrew

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()
channel.queue_declare(queue='research_tasks')

def callback(ch, method, properties, body):
    topic = body.decode()
    crew = ResearchAssistantCrew()
    result = crew.kickoff(inputs={"topic": topic})
    # Send result back to another queue or system
    channel.basic_publish(exchange='', routing_key='research_results', body=str(result))

channel.basic_consume(queue='research_tasks', on_message_callback=callback, auto_ack=True)
channel.start_consuming()
```

## 5. Best Practices for Project Architecture and Design in Production Scenarios

When deploying CrewAI projects in production, consider the following best practices:

1. **Modular Design**: Structure your project into modular components (agents, tasks, tools) for easier maintenance and scalability.

2. **Configuration Management**: Use configuration files or environment variables for settings that may change between environments.

3. **Logging and Monitoring**: Implement comprehensive logging and monitoring to track performance and identify issues quickly.

4. **Versioning**: Use semantic versioning for your CrewAI project and its components to manage updates and dependencies effectively.

5. **Testing**: Implement unit tests, integration tests, and end-to-end tests to ensure reliability:

```python
import unittest
from unittest.mock import patch
from research_assistant.agents.search_agent import SearchAgent

class TestSearchAgent(unittest.TestCase):
    def setUp(self):
        self.agent = SearchAgent()

    @patch('research_assistant.tools.search_tool.SearchTool.search')
    def test_search_papers(self, mock_search):
        mock_search.return_value = [{"title": "Test Paper", "authors": ["John Doe"]}]
        result = self.agent.search_papers("AI", max_results=1)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['title'], "Test Paper")

if __name__ == '__main__':
    unittest.main()
```

6. **Documentation**: Maintain clear and up-to-date documentation for your CrewAI project, including API references, deployment procedures, and usage examples.

7. **Continuous Integration/Continuous Deployment (CI/CD)**: Implement CI/CD pipelines to automate testing and deployment processes.

8. **Scalability Planning**: Design your architecture to be scalable from the start, considering future growth in data volume and user base.

9. **Security Best Practices**: Implement security measures such as input validation, authentication, and authorization to protect your CrewAI application and its data.

10. **Performance Optimization**: Regularly profile and optimize your CrewAI application, focusing on areas like database queries, API calls, and computational tasks.

## Conclusion

Real-world applications of CrewAI demonstrate its potential to revolutionize various industries by automating complex workflows and decision-making processes. By analyzing case studies, implementing a complete project, and addressing common challenges, you've gained practical insights into deploying CrewAI in production environments.

Remember that successful implementation of CrewAI projects requires a combination of technical expertise, domain knowledge, and continuous refinement based on real-world feedback. As you apply these concepts to your own projects, focus on creating modular, scalable, and maintainable solutions that can adapt to changing requirements and growing demands.

In the next lesson, we'll explore how to contribute to the CrewAI project itself, allowing you to not only use the framework but also help shape its future development.
