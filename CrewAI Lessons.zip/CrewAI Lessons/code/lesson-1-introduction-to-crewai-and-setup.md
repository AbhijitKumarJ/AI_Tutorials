# Lesson 1: Introduction to CrewAI and Setup

## 1. What is CrewAI and its purpose in AI-driven automation

CrewAI is an innovative framework designed to orchestrate role-playing AI agents, enabling them to collaborate and solve complex tasks. Its primary purpose is to facilitate AI-driven automation by creating a structured environment where multiple AI agents can work together, each with its own specialized role and capabilities.

Key features of CrewAI:
- Multi-agent collaboration
- Role-based task execution
- Flexible integration with various AI models and tools
- Scalable architecture for complex problem-solving

CrewAI aims to bridge the gap between single-agent AI systems and more complex, human-like problem-solving approaches. By allowing multiple AI agents to work together, CrewAI can tackle tasks that require diverse skills, knowledge, and perspectives.

## 2. The concept of multi-agent systems and their advantages

Multi-agent systems (MAS) are a paradigm in artificial intelligence where multiple intelligent agents interact to solve problems that are difficult or impossible for a single agent to solve. CrewAI leverages this concept to create more robust and versatile AI solutions.

Advantages of multi-agent systems in CrewAI:

1. Division of labor: Tasks can be distributed among specialized agents, leading to more efficient problem-solving.
2. Diverse perspectives: Different agents can approach problems from various angles, potentially leading to more creative solutions.
3. Scalability: Complex problems can be broken down into smaller, manageable tasks for individual agents.
4. Robustness: If one agent fails, others can potentially compensate, increasing system reliability.
5. Flexibility: New agents with different capabilities can be added to the system as needed.

Example scenario:
Imagine a content creation task where one agent researches a topic, another writes the content, and a third edits and proofreads. This division of labor allows for more specialized and higher-quality output compared to a single agent trying to perform all these tasks.

## 3. System requirements for different operating systems (Windows, macOS, Linux)

CrewAI is designed to be cross-platform, but there are some specific requirements for each operating system:

### Windows:
- Windows 10 or later (64-bit)
- Python 3.10 or higher (64-bit)
- Microsoft Visual C++ Redistributable (latest version)
- Git for Windows (for version control and installation)

### macOS:
- macOS 10.15 (Catalina) or later
- Python 3.10 or higher
- Xcode Command Line Tools (for compilation of certain dependencies)
- Homebrew (recommended for package management)

### Linux:
- Any modern Linux distribution (Ubuntu 20.04+, Fedora 32+, etc.)
- Python 3.10 or higher
- Development tools (gcc, make, etc.) for compiling dependencies

Common requirements for all platforms:
- Minimum 4GB RAM (8GB or more recommended for larger projects)
- 1GB free disk space
- Internet connection for downloading dependencies and accessing AI services

## 4. Setting up the development environment (Python 3.10+, pip, virtual environments)

Let's go through the process of setting up a development environment for CrewAI:

1. Install Python:
   - Windows: Download and install from python.org
   - macOS: Use Homebrew: `brew install python@3.10`
   - Linux: Use package manager, e.g., `sudo apt install python3.10`

2. Verify Python installation:
   ```
   python --version
   ```

3. Ensure pip is installed and up to date:
   ```
   python -m ensurepip --upgrade
   ```

4. Install virtualenv:
   ```
   pip install virtualenv
   ```

5. Create a new directory for your CrewAI project:
   ```
   mkdir crewai_project
   cd crewai_project
   ```

6. Create a virtual environment:
   ```
   python -m venv crewai_env
   ```

7. Activate the virtual environment:
   - Windows: `crewai_env\Scripts\activate`
   - macOS/Linux: `source crewai_env/bin/activate`

Your terminal prompt should now indicate that the virtual environment is active.

## 5. Installing CrewAI and its dependencies

Now that we have our virtual environment set up, let's install CrewAI and its dependencies:

1. Upgrade pip within the virtual environment:
   ```
   pip install --upgrade pip
   ```

2. Install CrewAI:
   ```
   pip install crewai
   ```

3. Install additional dependencies (may vary based on your project needs):
   ```
   pip install crewai-tools
   pip install openai  # If using OpenAI models
   ```

4. Verify the installation:
   ```
   python -c "import crewai; print(crewai.__version__)"
   ```

This should print the installed version of CrewAI.

### Potential platform-specific issues:

- Windows: 
  - Ensure you have the correct Visual C++ Redistributable installed.
  - Some packages may require a C++ compiler. Install "Build Tools for Visual Studio" if needed.

- macOS:
  - If you encounter SSL certificate issues, you may need to install certificates:
    ```
    /Applications/Python 3.10/Install Certificates.command
    ```

- Linux:
  - Ensure you have necessary development libraries:
    ```
    sudo apt-get install python3-dev build-essential
    ```

## 6. Understanding the CrewAI project structure and main components

A typical CrewAI project has the following structure:

```
crewai_project/
├── crewai_env/
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── researcher.py
│   │   └── writer.py
│   ├── tasks/
│   │   ├── __init__.py
│   │   ├── research_task.py
│   │   └── writing_task.py
│   ├── tools/
│   │   ├── __init__.py
│   │   └── custom_tool.py
│   ├── config/
│   │   ├── agents.yaml
│   │   └── tasks.yaml
│   ├── main.py
│   └── crew.py
├── tests/
│   ├── __init__.py
│   ├── test_agents.py
│   └── test_tasks.py
├── .env
├── requirements.txt
└── README.md
```

Main components:

1. Agents: Define the roles and capabilities of AI agents.
2. Tasks: Specify the work to be done by agents.
3. Tools: Custom functionalities that agents can use.
4. Config: YAML files for configuring agents and tasks.
5. Crew: Orchestrates the agents and tasks.
6. Main: Entry point for running the CrewAI application.

## 7. Creating your first CrewAI project

Let's create a simple CrewAI project that demonstrates the basic concepts:

1. Create the project structure:
   ```
   mkdir -p src/{agents,tasks,tools,config}
   touch src/{agents,tasks,tools}/__init__.py
   touch src/{main.py,crew.py}
   touch src/config/{agents.yaml,tasks.yaml}
   ```

2. Create a simple agent (src/agents/researcher.py):
   ```python
   from crewai import Agent

   class Researcher(Agent):
       def __init__(self):
           super().__init__(
               role='Researcher',
               goal='Conduct thorough research on given topics',
               backstory='You are an experienced researcher with a keen eye for detail.'
           )
   ```

3. Create a simple task (src/tasks/research_task.py):
   ```python
   from crewai import Task

   class ResearchTask(Task):
       def __init__(self, agent, topic):
           super().__init__(
               description=f'Research the topic: {topic}',
               agent=agent
           )
   ```

4. Create the crew (src/crew.py):
   ```python
   from crewai import Crew
   from .agents.researcher import Researcher
   from .tasks.research_task import ResearchTask

   class ResearchCrew(Crew):
       def __init__(self, topic):
           researcher = Researcher()
           task = ResearchTask(researcher, topic)
           super().__init__(
               agents=[researcher],
               tasks=[task],
               verbose=True
           )
   ```

5. Create the main entry point (src/main.py):
   ```python
   from .crew import ResearchCrew

   def main():
       topic = "Artificial Intelligence"
       crew = ResearchCrew(topic)
       result = crew.kickoff()
       print(f"Research result: {result}")

   if __name__ == "__main__":
       main()
   ```

6. Run your first CrewAI project:
   ```
   python -m src.main
   ```

This basic example demonstrates how to create agents, tasks, and a crew in CrewAI. As you progress through the course, you'll learn how to create more complex systems with multiple agents, advanced tasks, and custom tools.

## Conclusion

In this lesson, we've covered the fundamentals of CrewAI, including its purpose, the concept of multi-agent systems, system requirements, environment setup, and creating a basic CrewAI project. We've also touched on the project structure and main components of a CrewAI application.

In the next lesson, we'll dive deeper into Python fundamentals specifically relevant to CrewAI development, including asynchronous programming and working with Pydantic models.

## Exercises

1. Set up a CrewAI development environment on your local machine.
2. Modify the example project to include an additional agent (e.g., a Writer) and a corresponding task.
3. Experiment with different configurations in the `agents.yaml` and `tasks.yaml` files.
4. Try integrating a simple custom tool into your project.

Remember to consult the CrewAI documentation for more detailed information on each component as you work through these exercises.
