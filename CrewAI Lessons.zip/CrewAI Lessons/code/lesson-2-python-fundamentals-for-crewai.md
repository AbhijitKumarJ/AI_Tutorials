# Lesson 2: Python Fundamentals for CrewAI

## 1. Quick review of essential Python concepts

Before diving into CrewAI-specific concepts, let's review some essential Python concepts that are crucial for working with the framework:

### Variables and Data Types

Python is dynamically typed, meaning you don't need to declare the type of a variable explicitly. Common data types include:

```python
# Numeric types
integer_var = 42
float_var = 3.14

# Strings
string_var = "Hello, CrewAI!"

# Boolean
bool_var = True

# Lists
list_var = [1, 2, 3, "four"]

# Dictionaries
dict_var = {"key": "value", "number": 42}

# Tuples (immutable)
tuple_var = (1, "two", 3.0)

# Sets
set_var = {1, 2, 3, 3}  # Duplicates are automatically removed
```

### Functions

Functions in Python are defined using the `def` keyword:

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"

# Using the function
result = greet("CrewAI")
print(result)  # Output: Hello, CrewAI!
```

### Classes

Classes are used to create objects that bundle data and functionality:

```python
class Agent:
    def __init__(self, name: str, role: str):
        self.name = name
        self.role = role

    def introduce(self) -> str:
        return f"I'm {self.name}, and I'm a {self.role}."

# Creating an instance of the class
researcher = Agent("Alice", "Researcher")
print(researcher.introduce())  # Output: I'm Alice, and I'm a Researcher.
```

These concepts form the foundation of Python programming and are extensively used in CrewAI development.

## 2. Introduction to asynchronous programming in Python (async/await, coroutines)

Asynchronous programming is crucial for efficient execution in CrewAI, especially when dealing with multiple agents and tasks. Python's `async` and `await` keywords are used to define and work with coroutines.

### Coroutines

Coroutines are special functions that can be paused and resumed. They are defined using the `async def` syntax:

```python
import asyncio

async def fetch_data(url: str) -> str:
    print(f"Fetching data from {url}")
    await asyncio.sleep(2)  # Simulating an I/O operation
    return f"Data from {url}"

async def main():
    result = await fetch_data("https://example.com")
    print(result)

# Running the asynchronous function
asyncio.run(main())
```

### Async/Await

The `await` keyword is used to pause the execution of a coroutine until the awaited operation completes:

```python
async def process_data(data: str) -> str:
    print("Processing data...")
    await asyncio.sleep(1)  # Simulating processing time
    return f"Processed: {data.upper()}"

async def main():
    raw_data = await fetch_data("https://example.com")
    processed_data = await process_data(raw_data)
    print(processed_data)

asyncio.run(main())
```

### Concurrency with asyncio

asyncio allows running multiple coroutines concurrently:

```python
async def fetch_multiple(urls: list[str]) -> list[str]:
    async def fetch(url: str) -> str:
        await asyncio.sleep(1)  # Simulating network delay
        return f"Data from {url}"

    tasks = [asyncio.create_task(fetch(url)) for url in urls]
    results = await asyncio.gather(*tasks)
    return results

async def main():
    urls = ["https://example.com", "https://crewai.com", "https://python.org"]
    data = await fetch_multiple(urls)
    print(data)

asyncio.run(main())
```

In CrewAI, asynchronous programming is used to manage multiple agents working on different tasks concurrently, improving overall performance.

## 3. Working with type hints and Pydantic models in CrewAI

CrewAI makes extensive use of type hints and Pydantic models to ensure type safety and data validation.

### Type Hints

Type hints improve code readability and catch type-related errors early:

```python
from typing import List, Dict, Optional

def process_agent_data(name: str, age: int, skills: List[str]) -> Dict[str, Any]:
    return {
        "name": name,
        "age": age,
        "skills": skills
    }

# Using the function with type hints
agent_data = process_agent_data("Alice", 30, ["research", "writing"])
```

### Pydantic Models

Pydantic is used in CrewAI for data validation and settings management. Here's an example of a Pydantic model:

```python
from pydantic import BaseModel, Field

class Agent(BaseModel):
    name: str
    role: str
    age: int = Field(..., ge=18)  # Must be 18 or older
    skills: List[str] = []

    class Config:
        extra = "forbid"  # Prevent additional attributes

# Creating an instance of the model
try:
    agent = Agent(name="Bob", role="Writer", age=25, skills=["creative writing"])
    print(agent)
except ValueError as e:
    print(f"Validation error: {e}")

# This will raise a validation error
try:
    invalid_agent = Agent(name="Charlie", role="Developer", age=15)
except ValueError as e:
    print(f"Validation error: {e}")
```

In CrewAI, Pydantic models are used to define the structure of agents, tasks, and configuration settings, ensuring that all components have the required attributes and that they are of the correct type.

## 4. Error handling and exceptions in Python, specific to CrewAI usage

Proper error handling is crucial in CrewAI applications to manage unexpected situations gracefully. Python's try-except blocks are used for this purpose.

### Basic Error Handling

```python
try:
    result = some_crewai_function()
except Exception as e:
    print(f"An error occurred: {e}")
```

### Handling Specific Exceptions

CrewAI may raise specific exceptions that you'll want to handle differently:

```python
from crewai.exceptions import AgentException, TaskException

try:
    agent.execute_task(task)
except AgentException as ae:
    print(f"Agent error: {ae}")
except TaskException as te:
    print(f"Task error: {te}")
except Exception as e:
    print(f"Unexpected error: {e}")
```

### Custom Exceptions

You can create custom exceptions for your CrewAI application:

```python
class CrewConfigurationError(Exception):
    pass

def setup_crew(config):
    if "agents" not in config:
        raise CrewConfigurationError("Crew configuration must include 'agents'")
    # Rest of the setup code...

try:
    setup_crew({"tasks": []})
except CrewConfigurationError as ce:
    print(f"Configuration error: {ce}")
```

### Using `finally` for Cleanup

The `finally` block is useful for cleanup operations that should run regardless of whether an exception occurred:

```python
def run_crew_task():
    resources = acquire_resources()
    try:
        result = execute_crew_task(resources)
        return result
    except Exception as e:
        print(f"Task execution failed: {e}")
    finally:
        release_resources(resources)
```

Proper error handling ensures that your CrewAI application can recover from errors and provide meaningful feedback to users or logging systems.

## 5. Best practices for writing clean and maintainable Python code in CrewAI projects

Following best practices ensures that your CrewAI projects are easy to understand, maintain, and extend. Here are some key principles:

### 1. Follow PEP 8 Style Guide

PEP 8 is Python's official style guide. Key points include:

- Use 4 spaces for indentation
- Limit lines to 79 characters
- Use snake_case for function and variable names
- Use CamelCase for class names

```python
class ResearchAgent:
    def perform_research(self, topic: str) -> str:
        research_result = self._fetch_data(topic)
        return self._analyze_data(research_result)

    def _fetch_data(self, topic: str) -> List[str]:
        # Implementation here
        pass

    def _analyze_data(self, data: List[str]) -> str:
        # Implementation here
        pass
```

### 2. Write Descriptive Names

Use clear, descriptive names for variables, functions, and classes:

```python
# Bad
def p(x, y):
    return x * y

# Good
def calculate_area(length: float, width: float) -> float:
    return length * width
```

### 3. Use Type Hints Consistently

Type hints improve code readability and catch errors early:

```python
from typing import List, Dict

def process_agent_results(results: List[Dict[str, Any]]) -> Dict[str, float]:
    # Implementation here
    pass
```

### 4. Write Docstrings

Use docstrings to document functions, classes, and modules:

```python
class Crew:
    """
    Represents a crew of AI agents working together on tasks.

    Attributes:
        agents (List[Agent]): The agents in the crew.
        tasks (List[Task]): The tasks assigned to the crew.
    """

    def execute_tasks(self) -> Dict[str, Any]:
        """
        Execute all tasks assigned to the crew.

        Returns:
            Dict[str, Any]: A dictionary containing the results of each task.
        """
        # Implementation here
        pass
```

### 5. Use Context Managers

Context managers (the `with` statement) are useful for resource management:

```python
class DatabaseConnection:
    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()

# Usage
with DatabaseConnection() as db:
    db.execute_query("SELECT * FROM agents")
```

### 6. Avoid Global Variables

Instead of global variables, use class attributes or pass parameters:

```python
# Bad
global_config = {}

def setup_agent():
    global global_config
    global_config['agent'] = Agent()

# Good
class CrewConfig:
    def __init__(self):
        self.agent = None

    def setup_agent(self):
        self.agent = Agent()

config = CrewConfig()
config.setup_agent()
```

### 7. Use List Comprehensions and Generator Expressions

These can make your code more readable and efficient:

```python
# List comprehension
agent_names = [agent.name for agent in crew.agents]

# Generator expression
total_tasks = sum(len(agent.tasks) for agent in crew.agents)
```

### 8. Handle Configurations with Environment Variables

Use environment variables for configuration to keep sensitive information out of your code:

```python
import os
from dotenv import load_dotenv

load_dotenv()  # Load variables from .env file

api_key = os.getenv('OPENAI_API_KEY')
```

### 9. Modularize Your Code

Break your CrewAI project into logical modules:

```
crewai_project/
├── agents/
│   ├── __init__.py
│   ├── researcher.py
│   └── writer.py
├── tasks/
│   ├── __init__.py
│   ├── research_task.py
│   └── writing_task.py
├── utils/
│   ├── __init__.py
│   └── data_processing.py
├── config.py
├── main.py
└── crew.py
```

### 10. Write Tests

Use pytest or unittest to write tests for your CrewAI components:

```python
# test_agent.py
import pytest
from agents.researcher import ResearchAgent

def test_research_agent():
    agent = ResearchAgent("Alice")
    result = agent.perform_research("AI")
    assert isinstance(result, str)
    assert len(result) > 0
```

By following these best practices, you'll create CrewAI projects that are easier to understand, maintain, and extend over time.

## Conclusion

In this lesson, we've covered essential Python concepts crucial for CrewAI development, including asynchronous programming, type hints, Pydantic models, error handling, and best practices for clean code. These fundamentals will serve as a strong foundation as we delve deeper into CrewAI-specific concepts in the upcoming lessons.

## Exercises

1. Create a simple asynchronous function that simulates an AI agent performing a task, and use it in a CrewAI-style project structure.
2. Define a Pydantic model for a custom Agent type with at least five attributes, including one that uses Field validation.
3. Write a function that demonstrates proper error handling for at least three different types of exceptions that might occur in a CrewAI project.
4. Refactor a given piece of code (provided by the instructor) to follow the best practices outlined in this lesson.
5. Create a small CrewAI project that incorporates asynchronous programming, Pydantic models, and proper error handling. Include at least two agents and two tasks.

Remember to consult the Python documentation and CrewAI documentation for more detailed information as you work through these exercises. In the next lesson, we'll dive deeper into the core concepts of CrewAI, building upon the Python fundamentals we've covered here.
