# Lesson 10: Tools and Integrations in CrewAI

## Introduction

Tools and integrations are essential components in CrewAI that extend the capabilities of your agents and allow them to interact with external services and data sources. In this lesson, we'll explore how to work with built-in tools, create custom tools, and integrate external APIs and services into your CrewAI projects.

## Table of Contents

1. [Overview of Built-in Tools in CrewAI](#1-overview-of-built-in-tools-in-crewai)
2. [Creating Custom Tools for Agents](#2-creating-custom-tools-for-agents)
3. [Integrating External APIs and Services](#3-integrating-external-apis-and-services)
4. [Tool Validation and Error Handling](#4-tool-validation-and-error-handling)
5. [Implementing Tool Caching and Optimization](#5-implementing-tool-caching-and-optimization)
6. [Best Practices for Tool Development and Usage](#6-best-practices-for-tool-development-and-usage)
7. [Hands-on Exercise](#7-hands-on-exercise)
8. [Summary and Next Steps](#8-summary-and-next-steps)

## 1. Overview of Built-in Tools in CrewAI

CrewAI provides a set of built-in tools that agents can use out of the box. These tools cover common functionalities and can be easily integrated into your agents. Let's explore some of the key built-in tools:

### 1.1 File Operations Tool

The File Operations Tool allows agents to read from and write to files:

```python
from crewai_tools import FileOperationsTool

file_tool = FileOperationsTool()

# Usage in an agent
agent = Agent(
    role="File Manager",
    goal="Manage file operations",
    backstory="You are responsible for handling file-related tasks.",
    tools=[file_tool]
)
```

### 1.2 Web Browsing Tool

The Web Browsing Tool enables agents to search the web and extract information from websites:

```python
from crewai_tools import WebBrowsingTool

web_tool = WebBrowsingTool()

# Usage in an agent
agent = Agent(
    role="Web Researcher",
    goal="Gather information from the internet",
    backstory="You are an expert at finding and synthesizing online information.",
    tools=[web_tool]
)
```

### 1.3 Calculator Tool

The Calculator Tool allows agents to perform mathematical calculations:

```python
from crewai_tools import CalculatorTool

calc_tool = CalculatorTool()

# Usage in an agent
agent = Agent(
    role="Financial Analyst",
    goal="Perform financial calculations and analysis",
    backstory="You are skilled in financial modeling and data analysis.",
    tools=[calc_tool]
)
```

## 2. Creating Custom Tools for Agents

While built-in tools cover many common use cases, you'll often need to create custom tools tailored to your specific requirements. Let's walk through the process of creating a custom tool:

### 2.1 Basic Custom Tool Structure

Custom tools in CrewAI are created by subclassing `BaseTool`:

```python
from crewai_tools import BaseTool

class MyCustomTool(BaseTool):
    name: str = "My Custom Tool"
    description: str = "This tool performs a specific custom operation."

    def _run(self, argument: str) -> str:
        # Implement the tool's functionality here
        return f"Processed: {argument}"
```

### 2.2 Example: Weather Information Tool

Let's create a more practical custom tool that fetches weather information:

```python
import requests
from crewai_tools import BaseTool

class WeatherTool(BaseTool):
    name: str = "Weather Information Tool"
    description: str = "Use this tool to get current weather information for a specific location."

    def _run(self, location: str) -> str:
        # Note: You would need to sign up for a weather API service to get a real API key
        api_key = "your_weather_api_key_here"
        base_url = "http://api.openweathermap.org/data/2.5/weather"
        
        params = {
            "q": location,
            "appid": api_key,
            "units": "metric"
        }
        
        response = requests.get(base_url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            weather_description = data['weather'][0]['description']
            temperature = data['main']['temp']
            return f"The weather in {location} is {weather_description} with a temperature of {temperature}°C."
        else:
            return f"Failed to fetch weather information for {location}."

# Usage in an agent
weather_agent = Agent(
    role="Weather Reporter",
    goal="Provide accurate weather information",
    backstory="You are a meteorologist with access to real-time weather data.",
    tools=[WeatherTool()]
)
```

## 3. Integrating External APIs and Services

Integrating external APIs and services can greatly enhance the capabilities of your CrewAI agents. Let's look at how to integrate a popular external service:

### 3.1 Example: Integrating with OpenAI's GPT API

```python
import openai
from crewai_tools import BaseTool

class GPT3Tool(BaseTool):
    name: str = "GPT-3 Language Model Tool"
    description: str = "Use this tool to generate text or answer questions using OpenAI's GPT-3 model."

    def __init__(self):
        openai.api_key = "your_openai_api_key_here"

    def _run(self, prompt: str) -> str:
        try:
            response = openai.Completion.create(
                engine="text-davinci-002",
                prompt=prompt,
                max_tokens=150
            )
            return response.choices[0].text.strip()
        except Exception as e:
            return f"Error: {str(e)}"

# Usage in an agent
gpt_agent = Agent(
    role="AI Assistant",
    goal="Provide helpful information and answer questions",
    backstory="You are an AI assistant powered by GPT-3, capable of generating human-like text.",
    tools=[GPT3Tool()]
)
```

## 4. Tool Validation and Error Handling

Proper validation and error handling are crucial for creating robust and reliable tools. Let's enhance our WeatherTool with better validation and error handling:

```python
from pydantic import BaseModel, Field
from crewai_tools import BaseTool

class WeatherToolInput(BaseModel):
    location: str = Field(..., description="The city and country for which to fetch weather information")

class WeatherTool(BaseTool):
    name: str = "Weather Information Tool"
    description: str = "Use this tool to get current weather information for a specific location."
    args_schema: BaseModel = WeatherToolInput

    def _run(self, location: str) -> str:
        try:
            # API call code here (similar to previous example)
            # ...

            if response.status_code == 200:
                data = response.json()
                weather_description = data['weather'][0]['description']
                temperature = data['main']['temp']
                return f"The weather in {location} is {weather_description} with a temperature of {temperature}°C."
            elif response.status_code == 404:
                return f"Error: Location '{location}' not found. Please check the spelling and try again."
            else:
                return f"Error: Unable to fetch weather data. Status code: {response.status_code}"
        except requests.RequestException as e:
            return f"Network error occurred while fetching weather data: {str(e)}"
        except KeyError as e:
            return f"Error parsing weather data: {str(e)}"
        except Exception as e:
            return f"An unexpected error occurred: {str(e)}"
```

This enhanced version includes input validation using Pydantic, more specific error handling, and informative error messages.

## 5. Implementing Tool Caching and Optimization

To improve performance and reduce unnecessary API calls, you can implement caching for your tools. Here's an example of how to add caching to the WeatherTool:

```python
import time
from typing import Dict, Tuple
from crewai_tools import BaseTool

class CachedWeatherTool(BaseTool):
    name: str = "Cached Weather Information Tool"
    description: str = "Use this tool to get current weather information for a specific location, with caching."

    def __init__(self, cache_duration: int = 1800):  # Cache duration in seconds (default 30 minutes)
        self.cache: Dict[str, Tuple[float, str]] = {}
        self.cache_duration = cache_duration

    def _run(self, location: str) -> str:
        current_time = time.time()

        # Check if we have a cached result that's still valid
        if location in self.cache:
            cache_time, cache_result = self.cache[location]
            if current_time - cache_time < self.cache_duration:
                return f"(Cached) {cache_result}"

        # If no valid cache, fetch new data
        result = self._fetch_weather_data(location)  # Implement this method to fetch actual weather data
        
        # Cache the new result
        self.cache[location] = (current_time, result)
        
        return result

    def _fetch_weather_data(self, location: str) -> str:
        # Implement the actual API call here (similar to previous WeatherTool example)
        # ...
```

This cached version of the WeatherTool stores results for a specified duration, reducing the number of API calls for frequently requested locations.

## 6. Best Practices for Tool Development and Usage

When developing and using tools in CrewAI, consider the following best practices:

1. **Clear Documentation**: Provide clear and concise descriptions for your tools. This helps agents understand when and how to use them effectively.

2. **Input Validation**: Use Pydantic models to validate input parameters, ensuring that tools receive the correct data types and formats.

3. **Error Handling**: Implement comprehensive error handling to gracefully manage exceptions and provide informative error messages.

4. **Caching**: Implement caching mechanisms for tools that fetch external data to improve performance and reduce API calls.

5. **Rate Limiting**: For tools that interact with external APIs, implement rate limiting to avoid exceeding usage quotas or getting blocked.

6. **Modularity**: Design tools to be modular and reusable across different agents and projects.

7. **Security**: When dealing with sensitive data or API keys, use environment variables or secure storage methods rather than hardcoding them in your tool implementations.

8. **Testing**: Write unit tests for your custom tools to ensure they behave as expected under various conditions.

9. **Version Control**: Use version control for your custom tools, especially when sharing them across multiple projects or team members.

10. **Performance Monitoring**: Implement logging and monitoring for your tools to track usage patterns and identify potential bottlenecks.

## 7. Hands-on Exercise

Let's put these concepts into practice by creating a multi-tool agent that can perform various tasks using both built-in and custom tools.

File: `multi_tool_agent.py`

```python
from crewai import Agent, Task, Crew
from crewai_tools import BaseTool, WebBrowsingTool, CalculatorTool
import requests
from typing import Dict, Tuple
import time

class CachedWeatherTool(BaseTool):
    name: str = "Cached Weather Information Tool"
    description: str = "Use this tool to get current weather information for a specific location, with caching."

    def __init__(self, cache_duration: int = 1800):
        self.cache: Dict[str, Tuple[float, str]] = {}
        self.cache_duration = cache_duration

    def _run(self, location: str) -> str:
        current_time = time.time()
        if location in self.cache:
            cache_time, cache_result = self.cache[location]
            if current_time - cache_time < self.cache_duration:
                return f"(Cached) {cache_result}"
        result = self._fetch_weather_data(location)
        self.cache[location] = (current_time, result)
        return result

    def _fetch_weather_data(self, location: str) -> str:
        # Note: You would need to sign up for a weather API service to get a real API key
        api_key = "your_weather_api_key_here"
        base_url = "http://api.openweathermap.org/data/2.5/weather"
        params = {"q": location, "appid": api_key, "units": "metric"}
        try:
            response = requests.get(base_url, params=params)
            if response.status_code == 200:
                data = response.json()
                weather_description = data['weather'][0]['description']
                temperature = data['main']['temp']
                return f"The weather in {location} is {weather_description} with a temperature of {temperature}°C."
            else:
                return f"Failed to fetch weather information for {location}. Status code: {response.status_code}"
        except Exception as e:
            return f"An error occurred while fetching weather data: {str(e)}"

class StockPriceTool(BaseTool):
    name: str = "Stock Price Information Tool"
    description: str = "Use this tool to get the current stock price for a given ticker symbol."

    def _run(self, ticker: str) -> str:
        # Note: You would need to sign up for a stock API service to get a real API key
        api_key = "your_stock_api_key_here"
        base_url = "https://www.alphavantage.co/query"
        params = {
            "function": "GLOBAL_QUOTE",
            "symbol": ticker,
            "apikey": api_key
        }
        try:
            response = requests.get(base_url, params=params)
            if response.status_code == 200:
                data = response.json()
                if "Global Quote" in data:
                    price = data["Global Quote"]["05. price"]
                    return f"The current stock price of {ticker} is ${price}"
                else:
                    return f"Unable to fetch stock price for {ticker}. The symbol may be invalid."
            else:
                return f"Failed to fetch stock price for {ticker}. Status code: {response.status_code}"
        except Exception as e:
            return f"An error occurred while fetching stock price data: {str(e)}"

# Create the multi-tool agent
multi_tool_agent = Agent(
    role="Multi-Tool Assistant",
    goal="Provide information and perform various tasks using multiple tools",
    backstory="You are an advanced AI assistant equipped with various tools to help with information gathering, calculations, and data analysis.",
    tools=[
        WebBrowsingTool(),
        CalculatorTool(),
        CachedWeatherTool(),
        StockPriceTool()
    ]
)

# Define a task for the agent
multi_tool_task = Task(
    description="""
    1. Search the web for the latest news about renewable energy.
    2. Calculate the percentage increase in solar panel efficiency from 20% to 22%.
    3. Check the weather in New York City.
    4. Get the current stock price of Tesla (TSLA).
    Compile all this information into a brief report.
    """,
    agent=multi_tool_agent
)

# Create a crew with the multi-tool agent
multi_tool_crew = Crew(
    agents=[multi_tool_agent],
    tasks=[multi_tool_task],
    verbose=True
)

# Execute the crew
result = multi_tool_crew.kickoff()

print(result)
```

This exercise demonstrates the use of multiple tools, including built-in tools (WebBrowsingTool and CalculatorTool) and custom tools (CachedWeatherTool and StockPriceTool). The multi-tool agent can switch between these tools to complete a complex task that involves web searching, calculations, weather checking, and stock price lookup.

## 8. Summary and Next Steps

In this lesson, we've explored Tools and Integrations in CrewAI, covering:

- Overview of built-in tools in CrewAI
- Creating custom tools for agents
- Integrating external APIs and services
- Tool validation and error handling
- Implementing tool caching and optimization
- Best practices for tool development and usage

By mastering these concepts, you'll be able to create powerful and versatile agents capable of interacting with a wide range of data sources and services.

In the next lesson, we'll dive into Natural Language Processing and Language Models in CrewAI, exploring how to effectively use and configure language models to power your agents' decision-making and communication capabilities.

