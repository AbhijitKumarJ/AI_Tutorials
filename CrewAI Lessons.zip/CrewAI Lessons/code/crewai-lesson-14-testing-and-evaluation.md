# Lesson 14: Testing and Evaluation

## Introduction
Testing and evaluation are crucial aspects of developing robust and reliable CrewAI applications. In this lesson, we'll explore various testing techniques, from unit tests to integration tests, and learn how to evaluate the performance of our AI agents and crews.

## Table of Contents
1. Writing Unit Tests for CrewAI Components
2. Implementing Integration Tests
3. Using the CrewAI Evaluation Framework
4. Mocking External Dependencies and LLM Responses
5. Continuous Integration and Testing Strategies
6. Best Practices for Testing AI-driven Applications

## 1. Writing Unit Tests for CrewAI Components

Unit testing is essential for ensuring individual components of your CrewAI application work correctly. Let's look at how to write unit tests for agents, tasks, and tools.

### a. Testing Agents

Create a test file `test_agents.py`:

```python
import unittest
from unittest.mock import Mock
from crewai import Agent
from your_project.agents import ResearchAgent

class TestResearchAgent(unittest.TestCase):
    def setUp(self):
        self.mock_llm = Mock()
        self.agent = ResearchAgent(llm=self.mock_llm)

    def test_agent_initialization(self):
        self.assertEqual(self.agent.name, "Research Agent")
        self.assertEqual(self.agent.goal, "Conduct thorough research on given topics")

    def test_execute_task(self):
        mock_task = Mock()
        mock_task.description = "Research AI trends"
        self.mock_llm.generate.return_value = "AI is advancing rapidly."
        
        result = self.agent.execute_task(mock_task)
        
        self.assertIn("AI is advancing rapidly", result)
        self.mock_llm.generate.assert_called_once()

if __name__ == '__main__':
    unittest.main()
```

### b. Testing Tasks

Create a test file `test_tasks.py`:

```python
import unittest
from crewai import Task
from your_project.tasks import ResearchTask

class TestResearchTask(unittest.TestCase):
    def setUp(self):
        self.task = ResearchTask(description="Research AI trends")

    def test_task_initialization(self):
        self.assertEqual(self.task.description, "Research AI trends")
        self.assertIsNone(self.task.agent)

    def test_task_assignment(self):
        mock_agent = unittest.mock.Mock()
        self.task.assign(mock_agent)
        self.assertEqual(self.task.agent, mock_agent)

if __name__ == '__main__':
    unittest.main()
```

### c. Testing Tools

Create a test file `test_tools.py`:

```python
import unittest
from unittest.mock import patch
from your_project.tools import WebSearchTool

class TestWebSearchTool(unittest.TestCase):
    def setUp(self):
        self.tool = WebSearchTool()

    @patch('your_project.tools.requests.get')
    def test_web_search(self, mock_get):
        mock_get.return_value.text = "AI is transforming industries"
        result = self.tool.search("AI trends")
        self.assertIn("AI is transforming industries", result)
        mock_get.assert_called_once_with("https://api.search.com", params={"q": "AI trends"})

if __name__ == '__main__':
    unittest.main()
```

## 2. Implementing Integration Tests

Integration tests ensure that different components of your CrewAI application work together correctly. Let's create an integration test for a complete crew workflow.

Create a test file `test_crew_integration.py`:

```python
import unittest
from unittest.mock import patch
from crewai import Crew
from your_project.agents import ResearchAgent, WriterAgent
from your_project.tasks import ResearchTask, WriteReportTask

class TestCrewIntegration(unittest.TestCase):
    @patch('your_project.agents.ResearchAgent.execute_task')
    @patch('your_project.agents.WriterAgent.execute_task')
    def test_research_and_write_workflow(self, mock_write, mock_research):
        # Mock the research and writing outputs
        mock_research.return_value = "AI is advancing in natural language processing."
        mock_write.return_value = "Report: AI advancements in NLP are transforming industries."

        # Create agents
        research_agent = ResearchAgent()
        writer_agent = WriterAgent()

        # Create tasks
        research_task = ResearchTask(description="Research AI NLP advancements")
        write_task = WriteReportTask(description="Write a report on AI NLP advancements")

        # Create and run the crew
        crew = Crew(
            agents=[research_agent, writer_agent],
            tasks=[research_task, write_task]
        )
        result = crew.kickoff()

        # Assertions
        self.assertIn("AI advancements in NLP", result)
        mock_research.assert_called_once()
        mock_write.assert_called_once()

if __name__ == '__main__':
    unittest.main()
```

## 3. Using the CrewAI Evaluation Framework

CrewAI provides a built-in evaluation framework to assess the performance of your agents and crews. Let's explore how to use it effectively.

Create an evaluation script `evaluate_crew.py`:

```python
from crewai import Crew
from crewai.evaluation import CrewEvaluator
from your_project.agents import ResearchAgent, WriterAgent
from your_project.tasks import ResearchTask, WriteReportTask

def run_evaluation():
    # Create agents and tasks
    research_agent = ResearchAgent()
    writer_agent = WriterAgent()
    research_task = ResearchTask(description="Research AI trends")
    write_task = WriteReportTask(description="Write a report on AI trends")

    # Create the crew
    crew = Crew(
        agents=[research_agent, writer_agent],
        tasks=[research_task, write_task]
    )

    # Create the evaluator
    evaluator = CrewEvaluator(crew)

    # Run the evaluation
    evaluation_results = evaluator.evaluate(iterations=5)

    # Print the results
    print("Evaluation Results:")
    print(f"Average Task Completion Rate: {evaluation_results.avg_task_completion_rate}")
    print(f"Average Output Quality: {evaluation_results.avg_output_quality}")
    print("Task-specific Metrics:")
    for task, metrics in evaluation_results.task_metrics.items():
        print(f"  {task.description}:")
        print(f"    Completion Rate: {metrics.completion_rate}")
        print(f"    Output Quality: {metrics.output_quality}")

if __name__ == "__main__":
    run_evaluation()
```

## 4. Mocking External Dependencies and LLM Responses

Mocking external dependencies and LLM responses is crucial for creating reliable and reproducible tests. Let's explore some techniques for effective mocking in CrewAI applications.

### a. Mocking LLM Responses

Create a mock LLM class in `test_utils.py`:

```python
from unittest.mock import MagicMock

class MockLLM(MagicMock):
    def generate(self, prompt):
        # Define mock responses based on prompts
        responses = {
            "Research AI trends": "AI is advancing in areas like natural language processing and computer vision.",
            "Write a report on AI trends": "Report: Recent AI trends show significant progress in language models and generative AI.",
        }
        return responses.get(prompt, "Default mock response")

# Usage in tests
from test_utils import MockLLM

def test_agent_with_mock_llm():
    mock_llm = MockLLM()
    agent = ResearchAgent(llm=mock_llm)
    result = agent.execute_task(Task(description="Research AI trends"))
    assert "natural language processing" in result
```

### b. Mocking External API Calls

Use the `unittest.mock.patch` decorator to mock external API calls:

```python
import unittest
from unittest.mock import patch
from your_project.tools import WeatherTool

class TestWeatherTool(unittest.TestCase):
    @patch('your_project.tools.requests.get')
    def test_get_weather(self, mock_get):
        mock_response = unittest.mock.Mock()
        mock_response.json.return_value = {
            "main": {"temp": 20},
            "weather": [{"description": "sunny"}]
        }
        mock_get.return_value = mock_response

        weather_tool = WeatherTool()
        result = weather_tool.get_weather("New York")

        self.assertIn("20", result)
        self.assertIn("sunny", result)
        mock_get.assert_called_once_with(
            "https://api.openweathermap.org/data/2.5/weather",
            params={"q": "New York", "appid": weather_tool.api_key}
        )
```

## 5. Continuous Integration and Testing Strategies

Implementing a continuous integration (CI) pipeline ensures that your CrewAI application is consistently tested with every code change. Here's an example of how to set up a CI pipeline using GitHub Actions.

Create a file `.github/workflows/ci.yml`:

```yaml
name: CrewAI CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: 3.9
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Run unit tests
      run: python -m unittest discover tests/unit
    - name: Run integration tests
      run: python -m unittest discover tests/integration
    - name: Run evaluation
      run: python evaluate_crew.py
```

This CI pipeline will run your unit tests, integration tests, and crew evaluation every time you push code or create a pull request.

## 6. Best Practices for Testing AI-driven Applications

1. **Test for Determinism**: Ensure that your tests are deterministic by using fixed random seeds and mocked LLM responses.

2. **Test Edge Cases**: Include tests for edge cases and potential failure modes of your AI agents and tools.

3. **Parameterized Testing**: Use parameterized tests to cover a wide range of inputs and scenarios.

4. **Test for Bias**: Include tests to detect and mitigate potential biases in your AI agents' outputs.

5. **Performance Testing**: Implement performance tests to ensure your CrewAI application meets efficiency requirements.

6. **Security Testing**: Include tests for potential security vulnerabilities, especially when dealing with external APIs or user inputs.

7. **Regularly Update Test Data**: Keep your test data and mock responses up-to-date with the latest AI capabilities and trends.

8. **Test for Interpretability**: Implement tests to ensure your AI agents' decisions and outputs are interpretable and explainable.

9. **Continuous Monitoring**: Set up monitoring for your production CrewAI applications to catch any issues that arise in real-world usage.

10. **Documentation**: Maintain comprehensive documentation for your tests, including the purpose of each test and expected outcomes.

## Conclusion

Testing and evaluation are critical components of developing robust and reliable CrewAI applications. By implementing comprehensive unit tests, integration tests, and using the CrewAI evaluation framework, you can ensure that your AI-driven systems perform as expected. Remember to mock external dependencies and LLM responses for consistent and reproducible tests, and implement a continuous integration pipeline for ongoing quality assurance. Following best practices for testing AI-driven applications will help you build more trustworthy and effective CrewAI systems.

## File Layout

Here's a typical file layout for a CrewAI project with comprehensive testing and evaluation:

```
crewai_project/
│
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── research_agent.py
│   │   └── writer_agent.py
│   │
│   ├── tasks/
│   │   ├── __init__.py
│   │   ├── research_task.py
│   │   └── write_report_task.py
│   │
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── web_search_tool.py
│   │   └── weather_tool.py
│   │
│   └── main.py
│
├── tests/
│   ├── unit/
│   │   ├── __init__.py
│   │   ├── test_agents.py
│   │   ├── test_tasks.py
│   │   └── test_tools.py
│   │
│   ├── integration/
│   │   ├── __init__.py
│   │   └── test_crew_integration.py
│   │
│   └── test_utils.py
│
├── evaluation/
│   └── evaluate_crew.py
│
├── .github/
│   └── workflows/
│       └── ci.yml
│
├── requirements.txt
├── README.md
└── .gitignore
```

This structure organizes your CrewAI project with separate directories for source code, unit tests, integration tests, and evaluation scripts. The `.github/workflows/ci.yml` file sets up the continuous integration pipeline, ensuring that your tests are run automatically with every code change.
