# Lesson 19: Contributing to CrewAI

## Introduction

Contributing to open-source projects like CrewAI is an excellent way to improve your skills, give back to the community, and help shape the future of AI-driven automation. In this lesson, we'll explore the process of contributing to CrewAI, from setting up your development environment to submitting pull requests and participating in the community.

## 1. Understanding the CrewAI Development Process and Community Guidelines

Before you start contributing, it's essential to familiarize yourself with CrewAI's development process and community guidelines.

### CrewAI GitHub Repository

The CrewAI project is hosted on GitHub. You can find the repository at:

[https://github.com/joaomdmoura/crewai](https://github.com/joaomdmoura/crewai)

### Code of Conduct

CrewAI follows a Code of Conduct to ensure a welcoming and inclusive community. Make sure to read and adhere to it:

[https://github.com/joaomdmoura/crewai/blob/main/CODE_OF_CONDUCT.md](https://github.com/joaomdmoura/crewai/blob/main/CODE_OF_CONDUCT.md)

### Contributing Guidelines

Review the contributing guidelines to understand the project's expectations for contributions:

[https://github.com/joaomdmoura/crewai/blob/main/CONTRIBUTING.md](https://github.com/joaomdmoura/crewai/blob/main/CONTRIBUTING.md)

## 2. Setting Up a Development Environment for Contributing to CrewAI

To contribute to CrewAI, you'll need to set up a development environment. Here's a step-by-step guide:

1. Fork the CrewAI repository on GitHub.

2. Clone your fork locally:
   ```bash
   git clone https://github.com/your-username/crewai.git
   cd crewai
   ```

3. Set up a virtual environment:
   ```bash
   python -m venv crewai-env
   source crewai-env/bin/activate  # On Windows, use `crewai-env\Scripts\activate`
   ```

4. Install the development dependencies:
   ```bash
   pip install -e ".[dev]"
   ```

5. Set up pre-commit hooks:
   ```bash
   pre-commit install
   ```

6. Create a new branch for your changes:
   ```bash
   git checkout -b feature/your-feature-name
   ```

## 3. Writing and Submitting Pull Requests

When you're ready to contribute your changes, follow these steps to submit a pull request:

1. Ensure your changes adhere to the project's coding standards:
   ```bash
   make style
   ```

2. Run the tests to make sure everything is working:
   ```bash
   make test
   ```

3. Commit your changes with a descriptive commit message:
   ```bash
   git add .
   git commit -m "Add feature: Brief description of your changes"
   ```

4. Push your changes to your fork:
   ```bash
   git push origin feature/your-feature-name
   ```

5. Go to the CrewAI repository on GitHub and create a new pull request from your branch.

6. Fill out the pull request template with a detailed description of your changes, including:
   - The problem you're solving
   - How your changes address the problem
   - Any potential side effects or areas that need special attention

Here's an example of a good pull request description:

```markdown
## Description
This pull request adds support for custom agent behaviors using a new `CustomBehaviorMixin` class. This feature allows users to define reusable behaviors that can be easily applied to multiple agents.

## Changes
- Added `CustomBehaviorMixin` class in `crewai/mixins/custom_behavior.py`
- Updated `Agent` class to support the new mixin
- Added unit tests for the new functionality
- Updated documentation to explain how to use custom behaviors

## Example Usage
```python
from crewai import Agent
from crewai.mixins import CustomBehaviorMixin

class PersistentAgent(Agent, CustomBehaviorMixin):
    def persist(self, task):
        return self.execute_task(task, max_retries=5)

agent = PersistentAgent(name="Persistent Researcher")
result = agent.persist(some_task)
```

## Testing
I've added unit tests for the new `CustomBehaviorMixin` class and updated existing tests to cover the integration with the `Agent` class. All tests are passing.

## Documentation
I've updated the documentation in `docs/advanced_usage.md` to include a section on using custom behaviors with agents.
```

## 4. Participating in Code Reviews and Addressing Feedback

After submitting your pull request, maintainers and other contributors may review your code and provide feedback. Here's how to handle the code review process:

1. Be responsive to comments and questions on your pull request.

2. If changes are requested, make them in your local branch and push the updates:
   ```bash
   git add .
   git commit -m "Address feedback: Description of changes"
   git push origin feature/your-feature-name
   ```

3. Be open to constructive criticism and willing to make changes to improve your code.

4. If there are disagreements, discuss them respectfully and try to find a consensus.

5. Once your pull request is approved, a maintainer will merge it into the main branch.

## 5. Documentation Writing and Maintenance

Good documentation is crucial for open-source projects. When contributing to CrewAI, consider the following:

1. Update existing documentation to reflect your changes.

2. Write clear and concise docstrings for new classes and functions:

```python
class CustomAgent(Agent):
    """
    A custom agent with additional capabilities.

    This agent extends the base Agent class with methods for
    specialized tasks in a specific domain.

    Attributes:
        domain (str): The specialized domain of this agent.

    Example:
        >>> agent = CustomAgent("AI Research", domain="Machine Learning")
        >>> result = agent.specialized_task()
    """

    def __init__(self, name: str, domain: str):
        super().__init__(name)
        self.domain = domain

    def specialized_task(self) -> str:
        """
        Perform a specialized task in the agent's domain.

        Returns:
            str: The result of the specialized task.
        """
        # Implementation here
        pass
```

3. Create or update tutorials and examples in the `docs/` directory.

4. If you're adding a new feature, consider creating a dedicated documentation page explaining its usage and benefits.

## 6. Best Practices for Open-Source Contribution and Collaboration

Follow these best practices to make your contributions to CrewAI as effective as possible:

1. **Start Small**: Begin with small, manageable contributions like fixing typos or small bugs to familiarize yourself with the contribution process.

2. **Communicate**: Before starting work on a significant feature, open an issue to discuss it with the maintainers and community.

3. **Stay Updated**: Regularly sync your fork with the upstream repository to stay up-to-date with the latest changes:
   ```bash
   git remote add upstream https://github.com/joaomdmoura/crewai.git
   git fetch upstream
   git merge upstream/main
   ```

4. **Write Clear Commit Messages**: Use descriptive commit messages that explain the why, not just the what, of your changes.

5. **Follow the Style Guide**: Adhere to the project's coding style and conventions. For CrewAI, this means following PEP 8 guidelines and using tools like Black for formatting.

6. **Write Tests**: Always include tests for new features or bug fixes. Aim for high test coverage to ensure code reliability.

7. **Be Patient**: Maintainers are often volunteers and may take some time to review your contributions. Be patient and responsive to feedback.

8. **Help Others**: As you gain experience with the project, help newcomers and review other contributors' pull requests.

## 7. Continuous Learning and Engagement

Contributing to open-source projects like CrewAI is an ongoing learning process. Here are some ways to stay engaged and continue improving your skills:

1. **Join the Community**: Participate in discussions on the CrewAI GitHub Issues page, Discord server, or other community platforms.

2. **Attend Events**: Look for opportunities to attend or speak at conferences or meetups related to CrewAI or AI automation.

3. **Stay Informed**: Keep up with the latest developments in AI and automation to bring fresh ideas to the project.

4. **Mentor Others**: As you gain expertise, consider mentoring new contributors to help grow the CrewAI community.

## Conclusion

Contributing to CrewAI is a rewarding experience that allows you to improve your skills, collaborate with others, and make a meaningful impact on the future of AI-driven automation. By following the guidelines and best practices outlined in this lesson, you'll be well-equipped to become an active and valued contributor to the CrewAI project.

Remember that open-source contribution is not just about code – documentation improvements, bug reports, and helping other users are all valuable ways to contribute. Start small, be consistent, and don't hesitate to ask for help when needed. Your contributions, no matter how small, can make a significant difference in the CrewAI ecosystem.

In the next and final lesson, we'll explore advanced topics and future directions for CrewAI, giving you a glimpse into the exciting possibilities that lie ahead in the world of AI-driven automation.
