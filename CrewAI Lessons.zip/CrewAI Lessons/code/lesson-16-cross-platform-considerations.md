# Lesson 16: Cross-Platform Considerations in CrewAI

## Introduction

In this lesson, we'll explore the important aspects of developing CrewAI applications that can run seamlessly across different operating systems, including Windows, macOS, and Linux. Cross-platform development is crucial for ensuring that your CrewAI projects are accessible and functional for a wide range of users and deployment environments.

## 1. Handling File Paths and Storage

One of the most common issues in cross-platform development is dealing with file paths. Different operating systems use different conventions for representing file paths, which can lead to errors if not handled properly.

### File Path Separators

Windows uses backslashes (`\`) as path separators, while Unix-based systems (macOS and Linux) use forward slashes (`/`). To handle this, we can use Python's `os.path` module:

```python
import os

# Create a path that works on any platform
data_dir = os.path.join('user', 'data', 'crewai')

# This will produce:
# Windows: 'user\data\crewai'
# macOS/Linux: 'user/data/crewai'
```

### Absolute vs. Relative Paths

Always use relative paths when possible, and when absolute paths are necessary, use methods that work across platforms:

```python
import os

# Get the current script's directory
current_dir = os.path.dirname(os.path.abspath(__file__))

# Create an absolute path to a file in a subdirectory
config_file = os.path.join(current_dir, 'config', 'settings.yaml')
```

### Home Directory

To access the user's home directory across platforms:

```python
import os
from pathlib import Path

home_dir = str(Path.home())
crewai_config = os.path.join(home_dir, '.crewai', 'config.yaml')
```

### CrewAI-specific Storage Considerations

When working with CrewAI, you might need to store data, logs, or configuration files. Here's an example of how to create a platform-independent storage location:

```python
import os
import appdirs

def get_crewai_data_dir():
    app_name = "CrewAI"
    app_author = "YourCompany"
    data_dir = appdirs.user_data_dir(app_name, app_author)
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
    return data_dir

# Usage
data_dir = get_crewai_data_dir()
log_file = os.path.join(data_dir, 'crewai.log')
```

## 2. Managing Environment Variables and Configuration Files

Environment variables and configuration files are crucial for managing settings across different environments.

### Environment Variables

Use `os.environ` to access environment variables consistently across platforms:

```python
import os

# Access an environment variable
api_key = os.environ.get('CREWAI_API_KEY', 'default_key')

# Set an environment variable
os.environ['CREWAI_DEBUG'] = 'True'
```

For CrewAI projects, you might want to use a `.env` file to manage environment variables. Here's how you can set it up:

1. Create a `.env` file in your project root:

```
CREWAI_API_KEY=your_api_key_here
CREWAI_DEBUG=True
```

2. Use the `python-dotenv` library to load these variables:

```python
from dotenv import load_dotenv

load_dotenv()  # This loads the variables from .env

api_key = os.environ.get('CREWAI_API_KEY')
debug_mode = os.environ.get('CREWAI_DEBUG') == 'True'
```

### Configuration Files

For more complex configurations, use YAML files, which are human-readable and supported by CrewAI. Here's an example of a cross-platform configuration setup:

1. Create a `config.yaml` file:

```yaml
default:
  log_level: INFO
  max_agents: 5

windows:
  data_dir: '%APPDATA%\CrewAI'

macos:
  data_dir: '~/Library/Application Support/CrewAI'

linux:
  data_dir: '~/.crewai'
```

2. Load and use the configuration:

```python
import yaml
import os
import platform

def load_config():
    with open('config.yaml', 'r') as file:
        config = yaml.safe_load(file)
    
    # Load default config
    current_config = config['default']
    
    # Override with platform-specific config
    system = platform.system().lower()
    if system in config:
        current_config.update(config[system])
    
    # Expand user home directory if needed
    if 'data_dir' in current_config:
        current_config['data_dir'] = os.path.expanduser(current_config['data_dir'])
    
    return current_config

# Usage
config = load_config()
data_dir = config['data_dir']
max_agents = config['max_agents']
```

## 3. Addressing Platform-Specific Dependencies and Installation Issues

Different platforms may require different dependencies or have unique installation quirks. Here are some strategies to handle these issues:

### Using `requirements.txt` with Platform-Specific Dependencies

Create a `requirements.txt` file with conditional dependencies:

```
crewai>=0.70.1,<1.0.0
pywin32; sys_platform == 'win32'
pyobjc; sys_platform == 'darwin'
```

### Platform-Specific Installation Scripts

Create separate installation scripts for different platforms:

File structure:
```
crewai_project/
│
├── install_scripts/
│   ├── install_windows.bat
│   ├── install_macos.sh
│   └── install_linux.sh
│
└── setup.py
```

Example `setup.py`:

```python
import platform
from setuptools import setup, find_packages

def get_platform_dependencies():
    system = platform.system().lower()
    if system == 'windows':
        return ['pywin32']
    elif system == 'darwin':
        return ['pyobjc']
    else:
        return []

setup(
    name='your_crewai_project',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'crewai>=0.70.1,<1.0.0',
    ] + get_platform_dependencies(),
    # ... other setup configurations
)
```

## 4. Implementing Platform Detection and Conditional Logic

Sometimes you need to execute different code based on the platform. Here's how to detect the platform and implement conditional logic:

```python
import platform
import os

def get_platform():
    system = platform.system().lower()
    if system == 'darwin':
        return 'macos'
    return system

def configure_crewai():
    platform = get_platform()
    
    if platform == 'windows':
        # Windows-specific configuration
        temp_dir = os.environ.get('TEMP')
    elif platform == 'macos':
        # macOS-specific configuration
        temp_dir = '/tmp'
    elif platform == 'linux':
        # Linux-specific configuration
        temp_dir = '/tmp'
    else:
        raise NotImplementedError(f"Unsupported platform: {platform}")
    
    # Use the temp_dir for CrewAI temporary storage
    return {'temp_dir': temp_dir}

# Usage
crewai_config = configure_crewai()
```

## 5. Packaging and Distributing CrewAI Applications

To distribute your CrewAI application across platforms, consider using PyInstaller or creating a Python package.

### Using PyInstaller

PyInstaller can create standalone executables for Windows, macOS, and Linux.

1. Install PyInstaller:

```bash
pip install pyinstaller
```

2. Create a spec file for your CrewAI application:

```python
# crewai_app.spec
block_cipher = None

a = Analysis(['your_main_script.py'],
             pathex=['/path/to/your/project'],
             binaries=[],
             datas=[('config.yaml', '.'), ('tools', 'tools')],
             hiddenimports=['crewai'],
             hookspath=[],
             runtime_hooks=[],
             excludes=[],
             win_no_prefer_redirects=False,
             win_private_assemblies=False,
             cipher=block_cipher,
             noarchive=False)

pyz = PYZ(a.pure, a.zipped_data,
          cipher=block_cipher)

exe = EXE(pyz,
          a.scripts,
          a.binaries,
          a.zipfiles,
          a.datas,
          [],
          name='crewai_app',
          debug=False,
          bootloader_ignore_signals=False,
          strip=False,
          upx=True,
          upx_exclude=[],
          runtime_tmpdir=None,
          console=True)
```

3. Build the executable:

```bash
pyinstaller --onefile crewai_app.spec
```

### Creating a Python Package

To distribute your CrewAI application as a Python package:

1. Create a `setup.py` file (as shown earlier).

2. Create a `MANIFEST.in` file to include non-Python files:

```
include README.md
include LICENSE
include requirements.txt
recursive-include your_package/config *.yaml
recursive-include your_package/tools *.py
```

3. Build and distribute your package:

```bash
python setup.py sdist bdist_wheel
```

4. Upload to PyPI:

```bash
twine upload dist/*
```

## 6. Best Practices for Developing Cross-Platform CrewAI Applications

1. **Use relative imports**: When importing modules within your project, use relative imports to avoid path issues.

2. **Avoid hardcoded paths**: Always use `os.path.join()` or `pathlib.Path` to construct file paths.

3. **Test on all target platforms**: Regularly test your CrewAI application on Windows, macOS, and Linux to catch platform-specific issues early.

4. **Use virtual environments**: Always develop and test in virtual environments to isolate dependencies.

5. **Document platform-specific requirements**: Clearly document any platform-specific setup or requirements in your README file.

6. **Use cross-platform libraries**: Prefer libraries that work across platforms. If you need platform-specific functionality, abstract it behind a common interface.

7. **Handle encoding issues**: Be aware of encoding differences between platforms, especially when reading/writing files. Always specify encodings explicitly.

8. **Use CI/CD for multi-platform testing**: Set up Continuous Integration to automatically test your CrewAI application on different operating systems.

## Conclusion

Developing cross-platform CrewAI applications requires careful consideration of file paths, environment variables, configurations, and platform-specific nuances. By following the practices outlined in this lesson, you can create robust CrewAI applications that run smoothly across Windows, macOS, and Linux, ensuring a wider reach and easier deployment for your AI-driven automation projects.

In the next lesson, we'll explore the CrewAI CLI and deployment strategies, building upon the cross-platform knowledge gained here to streamline your development and deployment workflow.
