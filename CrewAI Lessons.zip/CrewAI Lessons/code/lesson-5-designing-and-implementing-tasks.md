# Lesson 5: Designing and Implementing Tasks in CrewAI

## Introduction

In this lesson, we'll dive deep into the creation and implementation of tasks within the CrewAI framework. Tasks are fundamental building blocks in CrewAI, representing specific units of work that agents perform. Understanding how to design effective tasks is crucial for creating efficient and productive AI-driven workflows.

## File Structure

Before we begin, let's look at a typical file structure for a CrewAI project that includes task definitions:

```
my_crewai_project/
│
├── src/
│   ├── my_project/
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── crew.py
│   │   ├── tasks/
│   │   │   ├── __init__.py
│   │   │   ├── research_task.py
│   │   │   └── report_task.py
│   │   └── config/
│   │       ├── tasks.yaml
│   │       └── agents.yaml
│   └── tools/
│       └── custom_tool.py
├── tests/
│   └── test_tasks.py
├── .env
├── pyproject.toml
└── README.md
```

In this structure, we define individual tasks in separate files within the `tasks/` directory, and configure them using the `tasks.yaml` file.

## Creating Effective Task Descriptions

The first step in designing a task is crafting a clear and specific description. A well-written task description guides the agent in understanding what needs to be accomplished.

Example in `src/my_project/tasks/research_task.py`:

```python
from crewai import Task

research_task = Task(
    description="Conduct a comprehensive research on the latest advancements in quantum computing, focusing on potential applications in cryptography. Gather information from reputable scientific journals and tech news sources from the past year.",
    expected_output="A detailed report summarizing the key advancements in quantum computing related to cryptography, including potential real-world applications and challenges.",
)
```

Key points for effective task descriptions:
- Be specific about the task's objective
- Define the scope clearly (e.g., time frame, sources to use)
- Indicate the level of detail required
- Specify any constraints or guidelines

## Defining Expected Outputs

The `expected_output` parameter helps set clear expectations for the task result. This guides the agent in formulating its response and helps in evaluating the task's success.

Example in `src/my_project/tasks/report_task.py`:

```python
from crewai import Task

report_task = Task(
    description="Create a comprehensive report on the research findings of quantum computing advancements in cryptography.",
    expected_output="A well-structured report with the following sections: 1) Executive Summary, 2) Introduction to Quantum Computing in Cryptography, 3) Key Advancements (last 12 months), 4) Potential Applications, 5) Challenges and Limitations, 6) Future Outlook, 7) References. The report should be written in a clear, concise manner suitable for both technical and non-technical audiences.",
)
```

## Assigning Agents to Tasks

In CrewAI, tasks are typically associated with specific agents. This association can be done either when creating the task or when setting up the crew.

Example of assigning an agent when creating a task:

```python
from crewai import Agent, Task

researcher = Agent(
    role="Quantum Computing Researcher",
    goal="Conduct cutting-edge research in quantum computing and its applications",
    backstory="You are a renowned physicist with a Ph.D. in Quantum Mechanics and 10 years of experience in quantum computing research.",
)

research_task = Task(
    description="Conduct in-depth research on quantum computing advancements in cryptography.",
    agent=researcher
)
```

Alternatively, you can assign tasks to agents when creating a crew:

```python
from crewai import Crew

crew = Crew(
    agents=[researcher, writer],
    tasks=[
        Task(description="Research quantum computing...", agent=researcher),
        Task(description="Write a report on the findings...", agent=writer)
    ]
)
```

## Task Execution Modes

CrewAI supports both synchronous and asynchronous task execution.

### Synchronous Execution

Synchronous execution is the default mode. Tasks are executed one after another in the order they are defined.

Example:

```python
result = crew.kickoff()
```

### Asynchronous Execution

For tasks that can be run independently, you can use asynchronous execution to improve performance.

Example:

```python
from crewai import Task

async_task = Task(
    description="Gather real-time quantum computing news from multiple sources.",
    async_execution=True
)

# In your crew setup
crew = Crew(
    agents=[news_agent],
    tasks=[async_task, another_async_task],
    process=Process.sequential  # Tasks will run concurrently
)

# Kickoff asynchronously
import asyncio
result = asyncio.run(crew.kickoff_async())
```

## Implementing Task Callbacks

Callbacks allow you to execute custom logic at specific points during task execution. This is useful for logging, monitoring, or triggering additional actions.

Example:

```python
def on_task_complete(task_output):
    print(f"Task completed. Output: {task_output.raw}")
    # You could save the output to a database, send a notification, etc.

task = Task(
    description="Analyze quantum cryptography market trends",
    callback=on_task_complete
)
```

## Handling Task Outputs

CrewAI provides flexibility in how task outputs are handled and formatted.

### Raw Output

By default, task outputs are returned as raw strings.

### JSON Output

For structured data, you can specify a JSON output format:

```python
from pydantic import BaseModel, Field

class ResearchOutput(BaseModel):
    key_findings: List[str] = Field(description="List of key research findings")
    potential_applications: List[str] = Field(description="Potential applications of the research")
    challenges: List[str] = Field(description="Challenges and limitations identified")

task = Task(
    description="Summarize quantum cryptography research findings",
    output_json=ResearchOutput
)
```

### Pydantic Model Output

For even more structured and validated outputs, use Pydantic models:

```python
task = Task(
    description="Analyze quantum cryptography market trends",
    output_pydantic=MarketAnalysisOutput
)
```

## Best Practices for Task Design and Implementation

1. **Modularity**: Break complex workflows into smaller, manageable tasks.
2. **Clarity**: Write clear, concise task descriptions and expected outputs.
3. **Flexibility**: Design tasks that can adapt to different inputs or scenarios.
4. **Error Handling**: Implement proper error handling and fallback mechanisms.
5. **Testing**: Write unit tests for your tasks to ensure they behave as expected.

Example test in `tests/test_tasks.py`:

```python
import pytest
from crewai import Task, Agent

def test_research_task():
    researcher = Agent(role="Researcher", goal="Conduct thorough research", backstory="Experienced in quantum physics")
    task = Task(
        description="Research quantum cryptography",
        expected_output="A summary of recent advancements",
        agent=researcher
    )
    
    assert task.description == "Research quantum cryptography"
    assert task.expected_output == "A summary of recent advancements"
    assert task.agent == researcher

def test_async_task():
    task = Task(
        description="Gather real-time data",
        async_execution=True
    )
    assert task.async_execution == True
```

## Conclusion

Mastering task design and implementation in CrewAI is crucial for creating effective AI-driven workflows. By following these guidelines and best practices, you can create tasks that are clear, efficient, and adaptable to various scenarios. In the next lesson, we'll explore how to build and manage crews, combining agents and tasks into powerful AI teams.

## Exercises

1. Create a task for researching a topic of your choice, ensuring the description and expected output are clear and specific.
2. Implement a task that uses a custom tool (hint: look into the `tools` parameter of the Task class).
3. Design a sequence of three related tasks that could be executed by different agents in a crew.
4. Write a task that produces a structured output using a Pydantic model.
5. Implement an asynchronous task and test its execution in a crew.

Remember to test your tasks thoroughly and consider how they fit into the larger context of your CrewAI project!

