# Lesson 15: Advanced CrewAI Features

## Introduction
As you become more proficient with CrewAI, it's time to explore its advanced features. These features allow you to create more complex, efficient, and flexible AI-driven systems. In this lesson, we'll dive into Pipelines, Routers, custom Process types, the Flow feature, advanced configuration techniques, and how to extend CrewAI's core classes.

## Table of Contents
1. Working with Pipelines
2. Implementing and Using Routers
3. Creating Custom Process Types
4. Using the Flow Feature
5. Advanced Configuration Techniques
6. Extending CrewAI's Core Classes

## 1. Working with Pipelines

Pipelines in CrewAI allow you to design complex, multi-stage workflows that can involve multiple crews or agents working in sequence or parallel.

### Creating a Pipeline

Let's create a pipeline that involves research, writing, and editing stages:

```python
from crewai import Agent, Task, Crew, Pipeline

# Define agents
researcher = Agent(name="Researcher", role="Research specialist")
writer = Agent(name="Writer", role="Content creator")
editor = Agent(name="Editor", role="Content editor")

# Define tasks
research_task = Task(description="Research the latest AI trends", agent=researcher)
writing_task = Task(description="Write an article on AI trends", agent=writer)
editing_task = Task(description="Edit and refine the AI article", agent=editor)

# Create crews
research_crew = Crew(agents=[researcher], tasks=[research_task])
writing_crew = Crew(agents=[writer], tasks=[writing_task])
editing_crew = Crew(agents=[editor], tasks=[editing_task])

# Create the pipeline
ai_article_pipeline = Pipeline(
    stages=[
        research_crew,
        writing_crew,
        editing_crew
    ]
)

# Execute the pipeline
result = ai_article_pipeline.run(initial_input={"topic": "AI trends in 2024"})
print(result)
```

### Parallel Execution in Pipelines

You can also execute stages in parallel when they're independent:

```python
from crewai import Agent, Task, Crew, Pipeline

# Define agents and tasks for different sections
tech_agent = Agent(name="Tech Writer", role="Technology specialist")
business_agent = Agent(name="Business Analyst", role="Business trends analyst")
tech_task = Task(description="Write about AI in technology", agent=tech_agent)
business_task = Task(description="Analyze AI's impact on business", agent=business_agent)

# Create crews
tech_crew = Crew(agents=[tech_agent], tasks=[tech_task])
business_crew = Crew(agents=[business_agent], tasks=[business_task])

# Create a pipeline with parallel execution
parallel_pipeline = Pipeline(
    stages=[
        [tech_crew, business_crew],  # These crews will run in parallel
        editing_crew  # This crew will run after both parallel crews are finished
    ]
)

# Execute the pipeline
result = parallel_pipeline.run(initial_input={"topic": "AI's impact on tech and business"})
print(result)
```

## 2. Implementing and Using Routers

Routers in CrewAI allow you to dynamically allocate tasks or choose execution paths based on certain conditions.

### Creating a Router

Let's create a router that directs tasks to different agents based on the task type:

```python
from crewai import Agent, Task, Crew, Router

# Define agents
general_agent = Agent(name="General Agent", role="General task handler")
math_agent = Agent(name="Math Specialist", role="Mathematical task solver")
writing_agent = Agent(name="Writing Expert", role="Content writer")

# Create a router
task_router = Router(
    name="Task Allocator",
    description="Allocates tasks to the appropriate agent based on task type"
)

@task_router.route
def route_task(task: Task):
    if "math" in task.description.lower():
        return math_agent
    elif "write" in task.description.lower() or "content" in task.description.lower():
        return writing_agent
    else:
        return general_agent

# Create a crew with the router
dynamic_crew = Crew(
    agents=[general_agent, math_agent, writing_agent],
    tasks=[
        Task(description="Solve complex mathematical equations"),
        Task(description="Write a blog post about AI"),
        Task(description="Research recent technological advancements")
    ],
    router=task_router
)

# Execute the crew
result = dynamic_crew.kickoff()
print(result)
```

## 3. Creating Custom Process Types

CrewAI allows you to create custom process types to define unique execution patterns for your crews.

### Implementing a Custom Process

Let's create a custom process that executes tasks in a round-robin fashion:

```python
from crewai import Crew, Process
from typing import List, Any

class RoundRobinProcess(Process):
    def execute(self, crew: Crew) -> List[Any]:
        results = []
        agents = crew.agents
        tasks = crew.tasks
        agent_index = 0

        for task in tasks:
            agent = agents[agent_index]
            result = agent.execute_task(task)
            results.append(result)
            agent_index = (agent_index + 1) % len(agents)

        return results

# Use the custom process in a crew
custom_crew = Crew(
    agents=[agent1, agent2, agent3],
    tasks=[task1, task2, task3, task4, task5],
    process=RoundRobinProcess()
)

result = custom_crew.kickoff()
print(result)
```

## 4. Using the Flow Feature

The Flow feature in CrewAI allows for visual workflow design and execution, making it easier to create and manage complex AI workflows.

### Creating a Flow

Here's an example of how to create and use a Flow:

```python
from crewai import Agent, Task, Flow

# Define agents
researcher = Agent(name="Researcher", role="Research specialist")
writer = Agent(name="Writer", role="Content creator")
editor = Agent(name="Editor", role="Content editor")

# Create a flow
article_flow = Flow("Article Creation")

# Define flow steps
@article_flow.step
def research(flow):
    task = Task(description="Research the latest AI trends")
    return researcher.execute_task(task)

@article_flow.step
def write(flow, research_result):
    task = Task(description=f"Write an article based on: {research_result}")
    return writer.execute_task(task)

@article_flow.step
def edit(flow, article):
    task = Task(description=f"Edit and refine the article: {article}")
    return editor.execute_task(task)

# Execute the flow
result = article_flow.start()
print(result)
```

## 5. Advanced Configuration Techniques

CrewAI offers advanced configuration options to customize your AI system's behavior and performance.

### Dynamic Configuration Loading

You can implement dynamic configuration loading to adapt your CrewAI system to different environments:

```python
import yaml
import os

def load_config(env='development'):
    config_path = f"config/{env}.yaml"
    with open(config_path, 'r') as file:
        return yaml.safe_load(file)

# Usage
env = os.getenv('CREWAI_ENV', 'development')
config = load_config(env)

# Create agents and crews using the loaded configuration
researcher = Agent(**config['agents']['researcher'])
research_task = Task(**config['tasks']['research'])
research_crew = Crew(agents=[researcher], tasks=[research_task])
```

### Environment-specific Configurations

Create separate configuration files for different environments:

```yaml
# config/development.yaml
agents:
  researcher:
    name: "Dev Researcher"
    role: "Research specialist"
    llm:
      model: "gpt-3.5-turbo"

# config/production.yaml
agents:
  researcher:
    name: "Prod Researcher"
    role: "Senior Research specialist"
    llm:
      model: "gpt-4"
```

## 6. Extending CrewAI's Core Classes

You can extend CrewAI's core classes to add custom functionality or modify existing behavior.

### Custom Agent Class

Create a custom agent class with additional capabilities:

```python
from crewai import Agent
import requests

class WebResearchAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.web_search_api_key = kwargs.get('web_search_api_key')

    def web_search(self, query):
        # Implement web search logic here
        api_url = f"https://api.websearch.com/search?q={query}&key={self.web_search_api_key}"
        response = requests.get(api_url)
        return response.json()

    def execute_task(self, task):
        # Augment task execution with web search
        search_results = self.web_search(task.description)
        augmented_description = f"{task.description}\nWeb search results: {search_results}"
        return super().execute_task(Task(description=augmented_description))

# Usage
web_researcher = WebResearchAgent(
    name="Web Researcher",
    role="Web research specialist",
    web_search_api_key="your-api-key-here"
)
```

### Custom Crew Class

Extend the Crew class to add custom execution logic:

```python
from crewai import Crew
from typing import List, Any

class IterativeCrew(Crew):
    def __init__(self, *args, max_iterations=3, **kwargs):
        super().__init__(*args, **kwargs)
        self.max_iterations = max_iterations

    def kickoff(self) -> List[Any]:
        results = []
        for _ in range(self.max_iterations):
            iteration_result = super().kickoff()
            results.append(iteration_result)
            if self._stop_condition(iteration_result):
                break
        return results

    def _stop_condition(self, result):
        # Implement your stop condition here
        return "FINAL" in result

# Usage
iterative_crew = IterativeCrew(
    agents=[agent1, agent2],
    tasks=[task1, task2],
    max_iterations=5
)
results = iterative_crew.kickoff()
```

## Conclusion

These advanced CrewAI features allow you to create more sophisticated, efficient, and flexible AI-driven systems. By mastering Pipelines, Routers, custom Process types, the Flow feature, advanced configuration techniques, and extending core classes, you can tackle complex problems and build highly customized AI solutions.

## File Layout

Here's a typical file layout for a CrewAI project utilizing these advanced features:

```
advanced_crewai_project/
│
├── config/
│   ├── development.yaml
│   └── production.yaml
│
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── web_research_agent.py
│   │   └── specialized_agents.py
│   │
│   ├── crews/
│   │   ├── __init__.py
│   │   └── iterative_crew.py
│   │
│   ├── tasks/
│   │   ├── __init__.py
│   │   └── custom_tasks.py
│   │
│   ├── processes/
│   │   ├── __init__.py
│   │   └── round_robin_process.py
│   │
│   ├── routers/
│   │   ├── __init__.py
│   │   └── task_router.py
│   │
│   ├── flows/
│   │   ├── __init__.py
│   │   └── article_creation_flow.py
│   │
│   ├── pipelines/
│   │   ├── __init__.py
│   │   └── research_write_edit_pipeline.py
│   │
│   └── main.py
│
├── tests/
│   ├── test_agents.py
│   ├── test_crews.py
│   ├── test_processes.py
│   ├── test_routers.py
│   ├── test_flows.py
│   └── test_pipelines.py
│
├── requirements.txt
├── README.md
└── .env
```

This structure organizes your advanced CrewAI components into logical directories, making it easier to manage and extend your AI system as it grows in complexity. The `config/` directory contains environment-specific configurations, while the `src/` directory houses all the custom implementations of agents, crews, processes, routers, flows, and pipelines.
