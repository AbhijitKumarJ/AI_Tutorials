# Lesson 9: Memory Management in CrewAI

## Introduction

Memory management is a crucial aspect of building intelligent and context-aware multi-agent systems with CrewAI. In this lesson, we'll explore the different types of memory available in CrewAI, how to implement and use them effectively, and best practices for memory utilization in your projects.

## Table of Contents

1. [Understanding Different Types of Memory](#1-understanding-different-types-of-memory)
2. [Implementing and Using Memory in Agents and Crews](#2-implementing-and-using-memory-in-agents-and-crews)
3. [Configuring Memory Storage Options](#3-configuring-memory-storage-options)
4. [Memory Retrieval Strategies and Relevance Scoring](#4-memory-retrieval-strategies-and-relevance-scoring)
5. [Handling Memory Conflicts and Updates](#5-handling-memory-conflicts-and-updates)
6. [Best Practices for Effective Memory Utilization](#6-best-practices-for-effective-memory-utilization)
7. [Hands-on Exercise](#7-hands-on-exercise)
8. [Summary and Next Steps](#8-summary-and-next-steps)

## 1. Understanding Different Types of Memory

CrewAI provides three main types of memory to enhance agent performance and maintain context:

1. **Short-Term Memory**: Stores recent interactions and information for quick access.
2. **Long-Term Memory**: Retains important information over extended periods.
3. **Entity Memory**: Manages structured information about specific entities or concepts.

Let's explore each type in detail:

### 1.1 Short-Term Memory

Short-term memory is designed to store recent interactions and temporary information. It's useful for maintaining context within a single conversation or task execution.

### 1.2 Long-Term Memory

Long-term memory is used to store important information that needs to be retained across multiple interactions or sessions. It's crucial for maintaining persistent knowledge and learning from past experiences.

### 1.3 Entity Memory

Entity memory is specialized for storing structured information about specific entities, concepts, or relationships. It's particularly useful for maintaining a knowledge graph or database of domain-specific information.

## 2. Implementing and Using Memory in Agents and Crews

To use memory in CrewAI, you need to enable it at the Crew level and then utilize it within your agents and tasks.

### 2.1 Enabling Memory for a Crew

First, let's see how to enable memory for a Crew:

File: `crew_with_memory.py`

```python
from crewai import Crew
from crewai.memory import ShortTermMemory, LongTermMemory, EntityMemory

crew = Crew(
    agents=[...],  # Your agents here
    tasks=[...],   # Your tasks here
    memory=True,   # Enable memory for this crew
    short_term_memory=ShortTermMemory(),
    long_term_memory=LongTermMemory(),
    entity_memory=EntityMemory()
)
```

### 2.2 Using Memory in Agents

Once memory is enabled for the Crew, agents can access and utilize it in their tasks:

File: `agent_with_memory.py`

```python
from crewai import Agent, Task, Crew
from crewai.memory import ShortTermMemory, LongTermMemory, EntityMemory

class MemoryTool:
    def save_to_memory(self, memory_type, key, value):
        if memory_type == "short_term":
            self.crew.short_term_memory.save(key, value)
        elif memory_type == "long_term":
            self.crew.long_term_memory.save(key, value)
        elif memory_type == "entity":
            self.crew.entity_memory.save(key, value)

    def retrieve_from_memory(self, memory_type, key):
        if memory_type == "short_term":
            return self.crew.short_term_memory.retrieve(key)
        elif memory_type == "long_term":
            return self.crew.long_term_memory.retrieve(key)
        elif memory_type == "entity":
            return self.crew.entity_memory.retrieve(key)

agent_with_memory = Agent(
    role="Memory Manager",
    goal="Manage and utilize different types of memory",
    backstory="You are an expert in information management and retrieval.",
    tools=[MemoryTool()]
)

memory_task = Task(
    description="Store important information in different memory types and retrieve it when needed.",
    agent=agent_with_memory
)

crew = Crew(
    agents=[agent_with_memory],
    tasks=[memory_task],
    memory=True,
    short_term_memory=ShortTermMemory(),
    long_term_memory=LongTermMemory(),
    entity_memory=EntityMemory()
)

result = crew.kickoff()
```

In this example, we've created a `MemoryTool` that allows the agent to interact with different types of memory. The agent can use this tool to store and retrieve information as needed during task execution.

## 3. Configuring Memory Storage Options

CrewAI offers various storage options for memory, including in-memory storage, SQLite, and custom storage solutions. Let's explore how to configure these options:

### 3.1 In-Memory Storage

In-memory storage is the default option and is suitable for short-lived sessions or when persistence isn't required:

```python
from crewai.memory import ShortTermMemory, LongTermMemory, EntityMemory

short_term = ShortTermMemory()  # Uses in-memory storage by default
long_term = LongTermMemory()    # Uses in-memory storage by default
entity = EntityMemory()         # Uses in-memory storage by default

crew = Crew(
    # ... other configurations ...
    memory=True,
    short_term_memory=short_term,
    long_term_memory=long_term,
    entity_memory=entity
)
```

### 3.2 SQLite Storage

For persistent storage, you can use SQLite:

```python
from crewai.memory import ShortTermMemory, LongTermMemory, EntityMemory
from crewai.memory.storage import SQLiteStorage

sqlite_storage = SQLiteStorage("my_crew_memory.db")

short_term = ShortTermMemory(storage=sqlite_storage)
long_term = LongTermMemory(storage=sqlite_storage)
entity = EntityMemory(storage=sqlite_storage)

crew = Crew(
    # ... other configurations ...
    memory=True,
    short_term_memory=short_term,
    long_term_memory=long_term,
    entity_memory=entity
)
```

### 3.3 Custom Storage

You can also implement custom storage solutions by creating a class that adheres to the `Storage` interface:

```python
from crewai.memory.storage import Storage

class CustomStorage(Storage):
    def save(self, key, value):
        # Implement custom save logic
        pass

    def retrieve(self, key):
        # Implement custom retrieve logic
        pass

    def delete(self, key):
        # Implement custom delete logic
        pass

custom_storage = CustomStorage()

short_term = ShortTermMemory(storage=custom_storage)
long_term = LongTermMemory(storage=custom_storage)
entity = EntityMemory(storage=custom_storage)

crew = Crew(
    # ... other configurations ...
    memory=True,
    short_term_memory=short_term,
    long_term_memory=long_term,
    entity_memory=entity
)
```

## 4. Memory Retrieval Strategies and Relevance Scoring

Efficient memory retrieval is crucial for large-scale systems. CrewAI provides mechanisms for relevance scoring and efficient retrieval:

### 4.1 Semantic Search

For long-term and entity memory, you can use semantic search to find relevant information:

```python
from crewai.memory import LongTermMemory
from crewai.memory.embedding import OpenAIEmbedding

embedding_model = OpenAIEmbedding()
long_term = LongTermMemory(embedding_model=embedding_model)

# Store some memories
long_term.save("Project A", "Details about Project A...")
long_term.save("Project B", "Information related to Project B...")

# Perform a semantic search
results = long_term.search("Find projects related to AI", top_k=2)
```

### 4.2 Relevance Scoring

Implement custom relevance scoring for more precise memory retrieval:

```python
def custom_relevance_score(query, memory_item):
    # Implement your custom relevance scoring logic
    # Return a float value representing the relevance (higher is more relevant)
    pass

results = long_term.search("Find projects related to AI", top_k=2, scorer=custom_relevance_score)
```

## 5. Handling Memory Conflicts and Updates

As your multi-agent system evolves, you may encounter memory conflicts or need to update existing memories. Here are some strategies to handle these situations:

### 5.1 Versioning

Implement versioning for your memories to track changes over time:

```python
from crewai.memory import EntityMemory

class VersionedEntityMemory(EntityMemory):
    def save(self, key, value, version=None):
        if version is None:
            version = self.get_latest_version(key) + 1
        super().save(f"{key}_v{version}", value)

    def get_latest_version(self, key):
        versions = [int(k.split('_v')[-1]) for k in self.storage.keys() if k.startswith(f"{key}_v")]
        return max(versions) if versions else 0

    def retrieve_latest(self, key):
        latest_version = self.get_latest_version(key)
        return super().retrieve(f"{key}_v{latest_version}")

versioned_entity_memory = VersionedEntityMemory()
```

### 5.2 Conflict Resolution

Implement a conflict resolution strategy when updating memories:

```python
from crewai.memory import EntityMemory

class ConflictResolvingEntityMemory(EntityMemory):
    def update(self, key, new_value, resolver):
        old_value = self.retrieve(key)
        if old_value is not None:
            resolved_value = resolver(old_value, new_value)
            self.save(key, resolved_value)
        else:
            self.save(key, new_value)

def resolve_conflict(old_value, new_value):
    # Implement your conflict resolution logic
    # For example, merge the old and new values
    return {**old_value, **new_value}

conflict_resolving_memory = ConflictResolvingEntityMemory()

# Usage
conflict_resolving_memory.update("project_status", {"status": "in_progress"}, resolve_conflict)
```

## 6. Best Practices for Effective Memory Utilization

To make the most of CrewAI's memory capabilities, consider the following best practices:

1. **Use Appropriate Memory Types**: Choose the right type of memory (short-term, long-term, or entity) based on the nature and lifespan of the information you're storing.

2. **Implement Efficient Storage**: For large-scale systems, use persistent storage options like SQLite or implement custom storage solutions optimized for your specific use case.

3. **Leverage Semantic Search**: Utilize semantic search capabilities for more intelligent and context-aware memory retrieval, especially for long-term and entity memories.

4. **Implement Versioning**: Use versioning for important memories to track changes over time and maintain a history of updates.

5. **Handle Conflicts Gracefully**: Implement robust conflict resolution strategies to handle updates to existing memories, especially in multi-agent systems where multiple agents might be modifying the same information.

6. **Regular Memory Cleanup**: Implement mechanisms to clean up or archive old or irrelevant memories to prevent memory bloat and maintain system performance.

7. **Secure Sensitive Information**: If your system deals with sensitive data, ensure that your memory storage is properly secured and encrypted.

8. **Optimize Retrieval**: Implement efficient retrieval strategies, including caching frequently accessed memories and using relevance scoring for large memory sets.

9. **Monitor Memory Usage**: Regularly monitor memory usage and performance to identify and address any bottlenecks or issues.

10. **Contextual Memory Access**: Design your agents to access and utilize memories in a context-aware manner, retrieving and applying relevant information based on the current task or situation.

## 7. Hands-on Exercise

Let's put these concepts into practice with a hands-on exercise. We'll create a customer support system that uses different types of memory to provide personalized assistance.

File: `customer_support_system.py`

```python
from crewai import Agent, Task, Crew
from crewai.memory import ShortTermMemory, LongTermMemory, EntityMemory
from crewai_tools import BaseTool

class CustomerMemoryTool(BaseTool):
    name: str = "Customer Memory Tool"
    description: str = "Use this tool to store and retrieve customer information."

    def _run(self, action: str, customer_id: str, data: str = None):
        if action == "store":
            self.crew.entity_memory.save(customer_id, data)
            return f"Stored information for customer {customer_id}"
        elif action == "retrieve":
            return self.crew.entity_memory.retrieve(customer_id)

class InteractionMemoryTool(BaseTool):
    name: str = "Interaction Memory Tool"
    description: str = "Use this tool to store and retrieve interaction history."

    def _run(self, action: str, interaction_id: str, data: str = None):
        if action == "store":
            self.crew.short_term_memory.save(interaction_id, data)
            return f"Stored interaction {interaction_id}"
        elif action == "retrieve":
            return self.crew.short_term_memory.retrieve(interaction_id)

class KnowledgeBaseTool(BaseTool):
    name: str = "Knowledge Base Tool"
    description: str = "Use this tool to access and update the knowledge base."

    def _run(self, action: str, topic: str, data: str = None):
        if action == "store":
            self.crew.long_term_memory.save(topic, data)
            return f"Updated knowledge base for topic: {topic}"
        elif action == "retrieve":
            return self.crew.long_term_memory.retrieve(topic)

# Define agents
customer_service_agent = Agent(
    role="Customer Service Representative",
    goal="Provide excellent customer support using available information",
    backstory="You are an experienced customer service rep with access to customer data and a knowledge base.",
    tools=[CustomerMemoryTool(), InteractionMemoryTool(), KnowledgeBaseTool()]
)

# Define tasks
support_task = Task(
    description="Handle a customer inquiry about their recent order, using available memory tools to provide personalized assistance.",
    agent=customer_service_agent
)

# Create the crew
support_crew = Crew(
    agents=[customer_service_agent],
    tasks=[support_task],
    memory=True,
    short_term_memory=ShortTermMemory(),
    long_term_memory=LongTermMemory(),
    entity_memory=EntityMemory(),
    verbose=True
)

# Execute the crew
result = support_crew.kickoff()

print(result)
```

This exercise demonstrates how to use different types of memory in a customer support scenario:

- Entity Memory (CustomerMemoryTool) stores and retrieves customer-specific information.
- Short-Term Memory (InteractionMemoryTool) manages the current interaction history.
- Long-Term Memory (KnowledgeBaseTool) maintains a knowledge base for common issues and solutions.

The customer service agent can use these tools to provide personalized and informed support based on the customer's history and current context.

## 8. Summary and Next Steps

In this lesson, we've explored memory management in CrewAI, covering:

- Different types of memory: short-term, long-term, and entity memory
- Implementing and using memory in agents and crews
- Configuring memory storage options
- Memory retrieval strategies and relevance scoring
- Handling memory conflicts and updates
- Best practices for effective memory utilization

By mastering these concepts, you'll be able to create more intelligent and context-aware multi-agent systems that can maintain and utilize information effectively across interactions and sessions.

In the next lesson, we'll dive into Tools and Integrations in CrewAI, exploring how to extend your agents' capabilities with custom tools and integrate external services into your multi-agent systems.

