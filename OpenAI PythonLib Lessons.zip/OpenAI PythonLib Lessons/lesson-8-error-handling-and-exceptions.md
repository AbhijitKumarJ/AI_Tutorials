# Lesson 8: Error Handling and Exceptions in the OpenAI Python Library

## Introduction

In this lesson, we'll delve into the crucial topic of error handling and exceptions in the OpenAI Python Library. Proper error handling is essential for building robust and reliable applications that can gracefully manage unexpected situations. We'll explore the custom exception classes provided by the library, examine how to parse and handle error responses from the API, and discuss best practices for implementing error handling in your applications. Additionally, we'll cover retry mechanisms, timeout handling, and strategies for logging and debugging errors.

## Custom Exception Classes in the Library

The OpenAI Python Library defines several custom exception classes to provide more specific and informative error handling. These custom exceptions allow you to catch and handle different types of errors that may occur when interacting with the OpenAI API.

Let's explore some of the key custom exception classes:

### OpenAIError

The `OpenAIError` is the base exception class for all errors raised by the OpenAI library. It serves as a catch-all for any errors that might occur during API interactions. Here's a simplified version of what this class might look like:

```python
class OpenAIError(Exception):
    def __init__(
        self,
        message=None,
        http_body=None,
        http_status=None,
        json_body=None,
        headers=None,
        code=None,
    ):
        super(OpenAIError, self).__init__(message)
        self.message = message
        self.http_body = http_body
        self.http_status = http_status
        self.json_body = json_body
        self.headers = headers or {}
        self.code = code
```

This base class captures various details about the error, including the error message, HTTP status code, response body, and headers. This information can be crucial for debugging and understanding the nature of the error.

### APIError

The `APIError` class is used for errors returned by the OpenAI API. It extends the `OpenAIError` class and typically represents errors where the API request was received and processed by the server, but resulted in an error response. For example:

```python
class APIError(OpenAIError):
    pass
```

### Timeout

The `Timeout` exception is raised when a request to the API times out. This could happen due to network issues or if the API takes too long to respond:

```python
class Timeout(OpenAIError):
    pass
```

### RateLimitError

The `RateLimitError` is raised when you've exceeded your rate limit (i.e., you've made too many requests in a given time period):

```python
class RateLimitError(OpenAIError):
    pass
```

### APIConnectionError

This exception is raised when there are network issues preventing connection to the API:

```python
class APIConnectionError(OpenAIError):
    pass
```

### InvalidRequestError

The `InvalidRequestError` is raised when the API request is invalid, often due to missing or incorrect parameters:

```python
class InvalidRequestError(OpenAIError):
    pass
```

Understanding these custom exception classes allows you to catch and handle specific types of errors in your code. For example:

```python
from openai import OpenAI
from openai.error import RateLimitError, InvalidRequestError

client = OpenAI()

try:
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": "Hello!"}]
    )
except RateLimitError as e:
    print(f"Rate limit exceeded. Please wait and try again. Details: {e}")
except InvalidRequestError as e:
    print(f"The request was invalid. Please check your inputs. Details: {e}")
except OpenAIError as e:
    print(f"An error occurred: {e}")
```

In this example, we're catching specific exceptions like `RateLimitError` and `InvalidRequestError`, as well as the general `OpenAIError`. This allows us to provide more informative error messages and potentially take different actions based on the type of error encountered.

## Error Response Parsing and Handling

When an error occurs during an API request, the OpenAI API typically returns a JSON response containing details about the error. The OpenAI Python Library parses this response and creates an appropriate exception object. Understanding how to access and use this information can be crucial for effective error handling and debugging.

### Structure of Error Responses

A typical error response from the OpenAI API might look something like this:

```json
{
  "error": {
    "message": "The model `gpt-3.5-turbo` does not exist",
    "type": "invalid_request_error",
    "param": "model",
    "code": "model_not_found"
  }
}
```

The library parses this JSON response and populates the corresponding fields in the exception object.

### Accessing Error Details

When you catch an exception, you can access various details about the error:

```python
from openai import OpenAI
from openai.error import OpenAIError

client = OpenAI()

try:
    response = client.chat.completions.create(
        model="non-existent-model",
        messages=[{"role": "user", "content": "Hello!"}]
    )
except OpenAIError as e:
    print(f"Error message: {e.message}")
    print(f"HTTP status code: {e.http_status}")
    print(f"Error code: {e.code}")
    print(f"Error type: {type(e).__name__}")
    if e.json_body:
        print(f"Full error response: {e.json_body}")
```

This approach allows you to extract detailed information about the error, which can be useful for logging, debugging, or providing informative messages to users of your application.

### Handling Specific Error Types

Different types of errors may require different handling strategies. Here's an example of how you might handle various error types:

```python
from openai import OpenAI
from openai.error import RateLimitError, InvalidRequestError, APIError, APIConnectionError

client = OpenAI()

try:
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": "Hello!"}]
    )
except RateLimitError as e:
    print(f"Rate limit exceeded. Waiting for {e.retry_after} seconds before retrying.")
    time.sleep(e.retry_after)
    # Implement retry logic here
except InvalidRequestError as e:
    print(f"Invalid request: {e.message}")
    # Log the error and possibly alert the user or developer
except APIError as e:
    print(f"API error occurred: {e.message}")
    if e.http_status == 500:
        print("Internal server error. Please try again later.")
    # Implement appropriate error handling based on the status code
except APIConnectionError as e:
    print(f"Connection error: {e.message}")
    # Implement retry logic with exponential backoff
except OpenAIError as e:
    print(f"An unexpected error occurred: {e.message}")
    # Log the full error details for debugging
```

This approach allows you to provide more specific error handling and recovery strategies based on the type of error encountered.

## Retry Mechanisms and Timeout Handling

When working with external APIs, it's important to implement retry mechanisms and proper timeout handling to make your application more resilient to temporary failures and network issues.

### Implementing Retries

The OpenAI Python Library doesn't provide built-in retry functionality, but you can implement your own retry mechanism using a library like `tenacity` or by writing a custom retry decorator. Here's an example using `tenacity`:

```python
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from openai import OpenAI
from openai.error import APIError, RateLimitError, APIConnectionError

client = OpenAI()

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=4, max=10),
    retry=retry_if_exception_type((APIError, RateLimitError, APIConnectionError))
)
def create_chat_completion_with_retry(messages):
    return client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=messages
    )

try:
    response = create_chat_completion_with_retry([
        {"role": "user", "content": "Hello!"}
    ])
    print(response.choices[0].message.content)
except Exception as e:
    print(f"All retry attempts failed. Last error: {e}")
```

In this example, we're using `tenacity` to retry the API call up to 3 times, with exponential backoff between attempts. We're only retrying on specific types of errors that are likely to be resolved by retrying.

### Timeout Handling

Proper timeout handling is crucial to prevent your application from hanging indefinitely when the API is slow to respond. The OpenAI Python Library allows you to set timeouts when creating the client or making individual requests:

```python
from openai import OpenAI
from openai.error import Timeout

# Set a default timeout for all requests
client = OpenAI(timeout=30.0)

try:
    # Override the timeout for this specific request
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": "Hello!"}],
        timeout=10.0
    )
    print(response.choices[0].message.content)
except Timeout as e:
    print(f"Request timed out: {e}")
```

In this example, we set a default timeout of 30 seconds for all requests, but override it with a 10-second timeout for a specific request. If the request doesn't complete within the specified timeout, a `Timeout` exception is raised.

## Best Practices for Error Handling in Applications

When building applications that interact with the OpenAI API, it's important to implement robust error handling to ensure a smooth user experience and easier debugging. Here are some best practices to consider:

1. **Use Specific Exception Types**: Catch and handle specific exception types when possible. This allows you to provide more targeted error messages and recovery strategies.

2. **Implement Graceful Degradation**: When an error occurs, try to provide a fallback option or gracefully degrade the functionality rather than completely failing.

3. **Provide Informative Error Messages**: Give users clear, actionable information about what went wrong and what they can do about it.

4. **Log Errors for Debugging**: Always log detailed error information for debugging purposes, but be careful not to expose sensitive information to end-users.

5. **Use Retries with Caution**: While retries can improve reliability, be careful not to overwhelm the API with too many retries. Use exponential backoff and limit the number of retry attempts.

6. **Handle Rate Limits Appropriately**: When you encounter rate limit errors, implement a backoff strategy and possibly queue requests for later processing.

7. **Set Appropriate Timeouts**: Use timeouts to prevent your application from hanging, but make sure they're not too short for complex operations.

8. **Validate Input Before Sending**: Catch potential `InvalidRequestError`s early by validating user input before sending it to the API.

Here's an example that incorporates several of these best practices:

```python
import logging
from openai import OpenAI
from openai.error import OpenAIError, RateLimitError, InvalidRequestError, Timeout

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

client = OpenAI(timeout=30.0)

def generate_response(prompt, max_retries=3):
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                timeout=10.0
            )
            return response.choices[0].message.content
        except InvalidRequestError as e:
            logger.error(f"Invalid request: {e}")
            return "I'm sorry, but I couldn't understand your request. Could you please rephrase it?"
        except RateLimitError as e:
            logger.warning(f"Rate limit exceeded. Retrying in {e.retry_after} seconds.")
            time.sleep(e.retry_after)
        except Timeout as e:
            logger.warning(f"Request timed out. Attempt {attempt + 1} of {max_retries}")
        except OpenAIError as e:
            logger.error(f"An error occurred: {e}")
            if attempt == max_retries - 1:
                return "I'm sorry, but I'm having trouble responding right now. Please try again later."
    
    return "I apologize, but I'm currently experiencing technical difficulties. Please try again later."

# Usage
user_prompt = input("Enter your prompt: ")
response = generate_response(user_prompt)
print(response)
```

This example incorporates error logging, retries with backoff for rate limit errors, input validation (by catching `InvalidRequestError`), appropriate timeout handling, and graceful degradation by providing fallback responses when errors occur.

## Logging and Debugging Errors

Effective logging and debugging are crucial for maintaining and troubleshooting applications that interact with the OpenAI API. Here are some strategies for logging and debugging errors:

### Logging

Python's built-in `logging` module is a powerful tool for recording error information. Here's an example of how you might set up logging for your application:

```python
import logging
from openai import OpenAI
from openai.error import OpenAIError

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='openai_app.log'
)
logger = logging.getLogger(__name__)

client = OpenAI()

def make_api_request(prompt):
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        logger.info(f"API request successful for prompt: {prompt}")
        return response.choices[0].message.content
    except OpenAIError as e:
        logger.error(f"API request failed for prompt: {prompt}")
        logger.error(f"Error details: {e}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.error(f"HTTP status: {e.http_status}")
        logger.error(f"Error code: {e.code}")
        if hasattr(e, 'json_body'):
            logger.error(f"Full error response: {e.json_body}")
        raise

# Usage
try:
    result = make_api_request("Tell me a joke")
    print(result)
except OpenAIError as e:
    print(f"An error occurred: {e}")
```

This logging setup records successful API calls as well as detailed information about any errors that occur. The log messages are written to a file named `openai_app.log`, which you can review for debugging purposes.

### Debugging

When debugging issues with the OpenAI API, consider the following strategies:

1. **Use Debug Logging**: Temporarily increase the logging level to `DEBUG` to get more detailed information about the API interactions.

2. **Inspect Request and Response Objects**: The OpenAI Python Library allows you to access the raw request and response objects for debugging purposes.

3. **Use a Network Debugging Proxy**: Tools like Charles Proxy or Fiddler can help you inspect the raw HTTP traffic between your application and the API.

4. **Enable API Request Logging**: The OpenAI API allows you to enable request logging in your account settings, which can be helpful for debugging issues on the API side.

Here's an example of how you might use debug logging and inspect request/response objects:

```python
import logging
from openai import OpenAI
from openai.error import OpenAIError

# Set up debug logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

client = OpenAI()

def make_api_request(prompt):
    try:
        logger.debug(f"Sending request with prompt: {prompt}")
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        logger.debug(f"Raw API response: {response}")
        return response.choices[0].message.content
    except OpenAIError as e:
        logger.error(f"API request failed: {e}")
        logger.debug(f"Error details: {e.__dict__}")
        raise

# Usage
try:
    result = make_api_request("Tell me a joke")
    print(result)
except OpenAIError as e:
    print(f"An error occurred: {e}")
```

This example uses debug logging to record the details of the API request and response, which can be invaluable when troubleshooting issues.

## Creating Custom Error Handlers

In some cases, you might want to create custom error handlers to standardize error handling across your application. Here's an example of a custom error handler:

```python
from openai import OpenAI
from openai.error import OpenAIError, RateLimitError, InvalidRequestError, Timeout

class OpenAIErrorHandler:
    def __init__(self, logger):
        self.logger = logger

    def handle(self, error):
        if isinstance(error, RateLimitError):
            self.logger.warning(f"Rate limit exceeded. Retry after {error.retry_after} seconds.")
            return f"I'm a bit busy right now. Please try again in {error.retry_after} seconds."
        elif isinstance(error, InvalidRequestError):
            self.logger.error(f"Invalid request: {error}")
            return "I couldn't understand your request. Could you please rephrase it?"
        elif isinstance(error, Timeout):
            self.logger.error(f"Request timed out: {error}")
            return "I'm taking too long to respond. Please try again later."
        elif isinstance(error, OpenAIError):
            self.logger.error(f"OpenAI API error: {error}")
            return "I'm having trouble responding right now. Please try again later."
        else:
            self.logger.critical(f"Unexpected error: {error}")
            return "An unexpected error occurred. Please try again later."

# Usage
client = OpenAI()
error_handler = OpenAIErrorHandler(logger)

def generate_response(prompt):
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message.content
    except Exception as e:
        return error_handler.handle(e)

# Example usage
result = generate_response("Tell me a joke")
print(result)
```

This custom error handler provides a standardized way to handle different types of errors, logging them appropriately and returning user-friendly error messages.

## Conclusion

Error handling and exception management are crucial aspects of working with the OpenAI Python Library. By understanding the custom exception classes, implementing proper error response parsing, and following best practices for error handling, you can create more robust and reliable applications.

Remember these key points:

1. Use specific exception types to handle different error scenarios.
2. Implement retry mechanisms with exponential backoff for transient errors.
3. Set appropriate timeouts to prevent your application from hanging.
4. Log errors comprehensively for debugging purposes.
5. Provide informative and user-friendly error messages.
6. Create custom error handlers to standardize error handling across your application.

By mastering these concepts, you'll be well-equipped to handle the various challenges that may arise when interacting with the OpenAI API, ensuring a smooth experience for your users and easier maintenance for your development team.

In the next lesson, we'll explore utility functions and helpers in the OpenAI Python Library, which will further enhance your ability to work efficiently with the API.