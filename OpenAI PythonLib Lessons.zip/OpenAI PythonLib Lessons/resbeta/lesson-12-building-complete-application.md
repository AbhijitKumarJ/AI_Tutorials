# Lesson 12: Building a Complete Application

## Introduction

In this final lesson of our series, we'll put all the concepts we've learned into practice by building a complete application using the OpenAI beta resources. Our application will be an AI-powered document analysis system that leverages multiple components of the OpenAI API, including assistants, threads, runs, and vector stores. We'll implement both synchronous and asynchronous operations, handle errors robustly, and consider cross-platform compatibility.

## Application Overview

Our application, which we'll call "DocuMind," will perform the following functions:

1. Allow users to upload documents for analysis
2. Process and store document content in vector stores for efficient retrieval
3. Create an AI assistant specialized in document analysis
4. Enable users to ask questions about their documents
5. Provide detailed answers and insights based on the document content

Throughout the development process, we'll apply best practices for error handling, performance optimization, and code organization.

## Setting Up the Project

First, let's set up our project structure:

```
documind/
├── __init__.py
├── config.py
├── main.py
├── document_processor.py
├── vector_store_manager.py
├── assistant_manager.py
├── query_engine.py
└── utils.py
```

Now, let's create a virtual environment and install the required dependencies:

```bash
python -m venv documind_env
source documind_env/bin/activate  # On Windows, use `documind_env\Scripts\activate`
pip install openai python-dotenv fastapi uvicorn
```

## Configuration

Let's start by setting up our configuration in `config.py`:

```python
# config.py
import os
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_ORG_ID = os.getenv("OPENAI_ORG_ID")

VECTOR_STORE_ID = os.getenv("VECTOR_STORE_ID")
ASSISTANT_ID = os.getenv("ASSISTANT_ID")

MAX_CONCURRENT_REQUESTS = 5
```

This configuration file loads environment variables and defines some constants we'll use throughout our application. The use of environment variables allows for easy configuration changes across different environments without modifying the code.

## Document Processing

Next, let's implement the document processing functionality in `document_processor.py`:

```python
# document_processor.py
import asyncio
from pathlib import Path
from typing import List
from openai import AsyncOpenAI
from .config import OPENAI_API_KEY, OPENAI_ORG_ID, MAX_CONCURRENT_REQUESTS

client = AsyncOpenAI(api_key=OPENAI_API_KEY, organization=OPENAI_ORG_ID)

async def process_document(file_path: Path) -> str:
    """Process a single document and return its file ID."""
    try:
        with file_path.open("rb") as file:
            response = await client.files.create(file=file, purpose="assistants")
        return response.id
    except Exception as e:
        print(f"Error processing file {file_path}: {e}")
        return None

async def process_documents(file_paths: List[Path]) -> List[str]:
    """Process multiple documents concurrently."""
    semaphore = asyncio.Semaphore(MAX_CONCURRENT_REQUESTS)
    
    async def process_with_semaphore(file_path: Path) -> str:
        async with semaphore:
            return await process_document(file_path)
    
    tasks = [process_with_semaphore(file_path) for file_path in file_paths]
    return await asyncio.gather(*tasks)
```

This module handles the uploading of documents to the OpenAI API. It uses asynchronous programming to process multiple documents concurrently, with a semaphore to limit the number of simultaneous requests. This approach optimizes performance while preventing overload of the API or local resources.

## Vector Store Management

Now, let's implement the vector store management functionality in `vector_store_manager.py`:

```python
# vector_store_manager.py
from openai import OpenAI
from .config import OPENAI_API_KEY, OPENAI_ORG_ID, VECTOR_STORE_ID

client = OpenAI(api_key=OPENAI_API_KEY, organization=OPENAI_ORG_ID)

def create_vector_store(name: str) -> str:
    """Create a new vector store and return its ID."""
    try:
        response = client.beta.vector_stores.create(name=name)
        return response.id
    except Exception as e:
        print(f"Error creating vector store: {e}")
        return None

def add_files_to_vector_store(vector_store_id: str, file_ids: List[str]) -> bool:
    """Add files to an existing vector store."""
    try:
        client.beta.vector_stores.file_batches.create(
            vector_store_id=vector_store_id,
            file_ids=file_ids
        )
        return True
    except Exception as e:
        print(f"Error adding files to vector store: {e}")
        return False

def search_vector_store(vector_store_id: str, query: str, max_results: int = 5) -> List[dict]:
    """Search the vector store for relevant content."""
    try:
        response = client.beta.vector_stores.search(
            vector_store_id=vector_store_id,
            query=query,
            max_results=max_results
        )
        return response.data
    except Exception as e:
        print(f"Error searching vector store: {e}")
        return []
```

This module manages interactions with the vector store, including creation, adding files, and searching. It uses the synchronous client for simplicity, but could be adapted to use asynchronous calls if needed for better performance in specific scenarios.

## Assistant Management

Let's implement the assistant management functionality in `assistant_manager.py`:

```python
# assistant_manager.py
from openai import OpenAI
from .config import OPENAI_API_KEY, OPENAI_ORG_ID, ASSISTANT_ID

client = OpenAI(api_key=OPENAI_API_KEY, organization=OPENAI_ORG_ID)

def create_assistant(name: str, instructions: str) -> str:
    """Create a new assistant and return its ID."""
    try:
        response = client.beta.assistants.create(
            name=name,
            instructions=instructions,
            model="gpt-4-1106-preview",
            tools=[{"type": "retrieval"}]
        )
        return response.id
    except Exception as e:
        print(f"Error creating assistant: {e}")
        return None

def update_assistant(assistant_id: str, instructions: str) -> bool:
    """Update an existing assistant's instructions."""
    try:
        client.beta.assistants.update(
            assistant_id=assistant_id,
            instructions=instructions
        )
        return True
    except Exception as e:
        print(f"Error updating assistant: {e}")
        return False

def create_thread() -> str:
    """Create a new thread and return its ID."""
    try:
        response = client.beta.threads.create()
        return response.id
    except Exception as e:
        print(f"Error creating thread: {e}")
        return None

def add_message_to_thread(thread_id: str, content: str) -> bool:
    """Add a message to an existing thread."""
    try:
        client.beta.threads.messages.create(
            thread_id=thread_id,
            role="user",
            content=content
        )
        return True
    except Exception as e:
        print(f"Error adding message to thread: {e}")
        return False

def run_assistant(thread_id: str, assistant_id: str) -> str:
    """Run the assistant on a thread and return the run ID."""
    try:
        response = client.beta.threads.runs.create(
            thread_id=thread_id,
            assistant_id=assistant_id
        )
        return response.id
    except Exception as e:
        print(f"Error running assistant: {e}")
        return None

def get_run_status(thread_id: str, run_id: str) -> str:
    """Get the status of a run."""
    try:
        response = client.beta.threads.runs.retrieve(
            thread_id=thread_id,
            run_id=run_id
        )
        return response.status
    except Exception as e:
        print(f"Error getting run status: {e}")
        return None

def get_messages(thread_id: str) -> List[dict]:
    """Get all messages in a thread."""
    try:
        response = client.beta.threads.messages.list(thread_id=thread_id)
        return [{"role": msg.role, "content": msg.content[0].text.value} for msg in response.data]
    except Exception as e:
        print(f"Error getting messages: {e}")
        return []
```

This module manages the creation and interaction with assistants and threads. It provides functions for creating assistants, updating their instructions, creating threads, adding messages, running the assistant, and retrieving results.

## Query Engine

Now, let's implement the query engine in `query_engine.py`:

```python
# query_engine.py
import asyncio
from typing import List, Dict
from .assistant_manager import (
    create_thread, add_message_to_thread, run_assistant, get_run_status, get_messages
)
from .vector_store_manager import search_vector_store
from .config import ASSISTANT_ID, VECTOR_STORE_ID

async def process_query(query: str) -> Dict[str, Any]:
    """Process a user query and return the assistant's response."""
    try:
        # Search vector store for relevant content
        search_results = search_vector_store(VECTOR_STORE_ID, query)
        
        # Create a new thread
        thread_id = create_thread()
        if not thread_id:
            return {"error": "Failed to create thread"}
        
        # Add the user's query and search results to the thread
        context = f"Query: {query}\n\nRelevant information:\n"
        for result in search_results:
            context += f"- {result.text}\n"
        add_message_to_thread(thread_id, context)
        
        # Run the assistant
        run_id = run_assistant(thread_id, ASSISTANT_ID)
        if not run_id:
            return {"error": "Failed to run assistant"}
        
        # Wait for the run to complete
        while True:
            status = get_run_status(thread_id, run_id)
            if status == "completed":
                break
            elif status in ["failed", "cancelled", "expired"]:
                return {"error": f"Run {status}"}
            await asyncio.sleep(1)
        
        # Get the assistant's response
        messages = get_messages(thread_id)
        assistant_response = next((msg["content"] for msg in reversed(messages) if msg["role"] == "assistant"), None)
        
        return {"response": assistant_response}
    except Exception as e:
        return {"error": str(e)}
```

This module ties together the vector store search and assistant interaction to process user queries. It uses asynchronous programming to handle the waiting period while the assistant processes the query.

## Main Application

Finally, let's implement the main application in `main.py`:

```python
# main.py
import uvicorn
from fastapi import FastAPI, File, UploadFile, HTTPException
from pydantic import BaseModel
from typing import List
from pathlib import Path
import asyncio

from .document_processor import process_documents
from .vector_store_manager import add_files_to_vector_store
from .query_engine import process_query
from .config import VECTOR_STORE_ID

app = FastAPI()

class Query(BaseModel):
    text: str

@app.post("/upload")
async def upload_documents(files: List[UploadFile] = File(...)):
    temp_dir = Path("temp")
    temp_dir.mkdir(exist_ok=True)
    
    temp_files = []
    for file in files:
        temp_file = temp_dir / file.filename
        with temp_file.open("wb") as buffer:
            buffer.write(await file.read())
        temp_files.append(temp_file)
    
    file_ids = await process_documents(temp_files)
    success = add_files_to_vector_store(VECTOR_STORE_ID, file_ids)
    
    for temp_file in temp_files:
        temp_file.unlink()
    
    if success:
        return {"message": "Documents uploaded and processed successfully"}
    else:
        raise HTTPException(status_code=500, message="Failed to process documents")

@app.post("/query")
async def query(query: Query):
    result = await process_query(query.text)
    if "error" in result:
        raise HTTPException(status_code=500, detail=result["error"])
    return result

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

This main application uses FastAPI to create a web server with two endpoints:

1. `/upload` for uploading and processing documents
2. `/query` for submitting queries and receiving responses

The application handles file uploads, processes documents, adds them to the vector store, and uses the query engine to process user queries.

## Cross-Platform Considerations

To ensure our application works across different platforms, we've implemented the following strategies:

1. Use of `pathlib` for file path handling, which works consistently across operating systems.
2. Environment variables for configuration, allowing easy adaptation to different deployment environments.
3. Asynchronous programming with `asyncio`, which is supported across platforms.
4. Use of a virtual environment to isolate dependencies.

## Error Handling and Logging

Throughout the application, we've implemented error handling to catch and report issues. In a production environment, you would want to enhance this with more detailed logging. For example:

```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    # Some operation
    logger.info("Operation completed successfully")
except Exception as e:
    logger.error(f"An error occurred: {e}", exc_info=True)
```

## Performance Optimizations

We've implemented several performance optimizations in our application:

1. Asynchronous document processing to handle multiple uploads concurrently.
2. Use of a semaphore to limit the number of concurrent API requests.
3. Vector store for efficient document searching.
4. Asynchronous query processing to handle waiting for assistant responses without blocking.

## Deployment Considerations

For deploying this application, consider the following:

1. Use a production-grade ASGI server like Gunicorn with Uvicorn workers.
2. Implement proper authentication and authorization for API endpoints.
3. Use environment variables for all sensitive information (API keys, etc.).
4. Consider containerization using Docker for consistent deployment across environments.
5. Implement rate limiting to prevent abuse of your API.

Here's a simple Dockerfile for our application:

```dockerfile
FROM python:3.9

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["uvicorn", "documind.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

## Conclusion

In this final lesson, we've built a complete application that leverages multiple components of the OpenAI beta resources. We've implemented document processing, vector store management, assistant interactions, and a query engine. The application demonstrates both synchronous and asynchronous operations, error handling, and considerations for cross-platform compatibility and deployment.