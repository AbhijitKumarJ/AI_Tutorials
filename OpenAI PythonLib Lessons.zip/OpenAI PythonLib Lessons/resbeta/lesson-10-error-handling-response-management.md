# Lesson 10: Error Handling and Response Management

## Introduction

In this lesson, we'll delve deep into error handling and response management in the OpenAI Python library, with a specific focus on the beta resources. Proper error handling and response management are crucial for building robust and reliable applications that interact with AI services. We'll explore various response wrapper classes, examine raw and streaming response options, and discuss strategies for implementing effective error handling in OpenAI-powered applications.

## File Structure

Before we dive into the details, let's review the relevant file structure from the openai-src-resbeta file:

```
openai-src-resbeta/
├── beta/
│   ├── __init__.py
│   ├── assistants.py
│   ├── beta.py
│   ├── threads/
│   │   ├── __init__.py
│   │   ├── messages.py
│   │   ├── runs/
│   │   │   ├── __init__.py
│   │   │   ├── runs.py
│   │   │   └── steps.py
│   │   └── threads.py
│   └── vector_stores/
│       ├── __init__.py
│       ├── file_batches.py
│       ├── files.py
│       └── vector_stores.py
└── chat/
    ├── __init__.py
    ├── chat.py
    └── completions.py
```

This structure shows the organization of the beta resources, which all incorporate error handling and response management mechanisms.

## Response Wrapper Classes

The OpenAI library provides several response wrapper classes to handle different types of responses. These wrappers allow developers to access raw response data, including headers and status codes, in addition to the parsed content. Let's examine some of these wrapper classes:

### VectorStoresWithRawResponse

```python
class VectorStoresWithRawResponse:
    def __init__(self, vector_stores: VectorStores) -> None:
        self._vector_stores = vector_stores

        self.create = _legacy_response.to_raw_response_wrapper(
            vector_stores.create,
        )
        self.retrieve = _legacy_response.to_raw_response_wrapper(
            vector_stores.retrieve,
        )
        self.update = _legacy_response.to_raw_response_wrapper(
            vector_stores.update,
        )
        self.list = _legacy_response.to_raw_response_wrapper(
            vector_stores.list,
        )
        self.delete = _legacy_response.to_raw_response_wrapper(
            vector_stores.delete,
        )

    @cached_property
    def files(self) -> FilesWithRawResponse:
        return FilesWithRawResponse(self._vector_stores.files)

    @cached_property
    def file_batches(self) -> FileBatchesWithRawResponse:
        return FileBatchesWithRawResponse(self._vector_stores.file_batches)
```

This wrapper class provides access to raw response data for VectorStores operations. Key points to note:

1. It wraps each method of the original VectorStores class using the `to_raw_response_wrapper` function.
2. The wrapped methods return the raw response object instead of the parsed content.
3. It also provides access to raw response wrappers for nested resources (files and file_batches).

### AsyncVectorStoresWithRawResponse

```python
class AsyncVectorStoresWithRawResponse:
    def __init__(self, vector_stores: AsyncVectorStores) -> None:
        self._vector_stores = vector_stores

        self.create = _legacy_response.async_to_raw_response_wrapper(
            vector_stores.create,
        )
        self.retrieve = _legacy_response.async_to_raw_response_wrapper(
            vector_stores.retrieve,
        )
        self.update = _legacy_response.async_to_raw_response_wrapper(
            vector_stores.update,
        )
        self.list = _legacy_response.async_to_raw_response_wrapper(
            vector_stores.list,
        )
        self.delete = _legacy_response.async_to_raw_response_wrapper(
            vector_stores.delete,
        )

    @cached_property
    def files(self) -> AsyncFilesWithRawResponse:
        return AsyncFilesWithRawResponse(self._vector_stores.files)

    @cached_property
    def file_batches(self) -> AsyncFileBatchesWithRawResponse:
        return AsyncFileBatchesWithRawResponse(self._vector_stores.file_batches)
```

This is the asynchronous version of the raw response wrapper. The key differences are:

1. It wraps methods of the AsyncVectorStores class.
2. It uses the `async_to_raw_response_wrapper` function for wrapping methods.
3. The wrapped methods are coroutines and should be awaited when called.

These wrapper classes allow developers to access raw response data when needed, which can be useful for debugging, logging, or handling specific HTTP-level information.

## Raw Response and Streaming Response Options

The OpenAI library provides options for both raw responses and streaming responses. Let's explore these options in more detail:

### Raw Response

Raw responses give access to the full HTTP response, including status codes, headers, and the raw body. This is useful when you need to inspect or log the complete server response. Here's an example of how to use raw responses:

```python
from openai import OpenAI

client = OpenAI()

# Using raw response
raw_response = client.beta.vector_stores.with_raw_response.create(
    name="My Vector Store",
    file_ids=["file-abc123"]
)

print(f"Status code: {raw_response.status_code}")
print(f"Headers: {raw_response.headers}")
print(f"Content: {raw_response.content}")

# Access the parsed response
vector_store = raw_response.parse()
print(f"Vector Store ID: {vector_store.id}")
```

Key points about raw responses:

1. They provide access to the full HTTP response object.
2. You can still access the parsed response using the `parse()` method.
3. They're useful for debugging and logging purposes.

### Streaming Response

Streaming responses are useful for handling large amounts of data or long-running operations. They allow you to process the response as it's received, rather than waiting for the entire response to be downloaded. Here's an example of using streaming responses:

```python
from openai import OpenAI

client = OpenAI()

# Using streaming response
with client.beta.vector_stores.with_streaming_response.create(
    name="My Vector Store",
    file_ids=["file-abc123"]
) as response:
    print(f"Status code: {response.status_code}")
    print(f"Headers: {response.headers}")
    
    for chunk in response.iter_content(chunk_size=4096):
        print(f"Received chunk: {len(chunk)} bytes")

    # Access the parsed response
    vector_store = response.parse()
    print(f"Vector Store ID: {vector_store.id}")
```

Key points about streaming responses:

1. They allow processing of the response as it's received.
2. You can iterate over chunks of the response body.
3. They're useful for handling large responses or long-running operations.
4. The parsed response is still accessible after streaming is complete.

## Implementing Robust Error Handling

Effective error handling is crucial for building reliable applications. The OpenAI library provides several tools and patterns for handling errors. Let's explore some strategies for implementing robust error handling:

### Custom Exception Classes

The OpenAI library defines custom exception classes for different types of errors. For example:

```python
class OpenAIError(Exception):
    def __init__(self, message=None, http_body=None, http_status=None, json_body=None, headers=None, code=None):
        super(OpenAIError, self).__init__(message)
        self.http_body = http_body
        self.http_status = http_status
        self.json_body = json_body
        self.headers = headers or {}
        self.code = code

class APIError(OpenAIError):
    pass

class Timeout(OpenAIError):
    pass

class RateLimitError(OpenAIError):
    pass
```

These custom exceptions provide more context about the error, including HTTP status codes, response bodies, and headers. When handling errors, you can catch these specific exception types to provide more granular error handling.

### Try-Except Blocks

When making API calls, it's important to use try-except blocks to catch and handle potential errors. Here's an example:

```python
from openai import OpenAI
from openai.error import APIError, RateLimitError, Timeout

client = OpenAI()

try:
    vector_store = client.beta.vector_stores.create(
        name="My Vector Store",
        file_ids=["file-abc123"]
    )
    print(f"Vector Store created with ID: {vector_store.id}")
except APIError as e:
    print(f"API Error: {e}")
    print(f"HTTP Status: {e.http_status}")
    print(f"Error Code: {e.code}")
except RateLimitError:
    print("Rate limit exceeded. Please wait before making more requests.")
except Timeout:
    print("Request timed out. Please try again later.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
```

Key points about error handling:

1. Catch specific exceptions first, followed by more general exceptions.
2. Log error details for debugging and monitoring purposes.
3. Provide user-friendly error messages in your application.
4. Consider implementing retry logic for transient errors (e.g., network issues or rate limiting).

### Asynchronous Error Handling

When working with asynchronous code, error handling follows a similar pattern, but with some key differences:

```python
import asyncio
from openai import AsyncOpenAI
from openai.error import APIError, RateLimitError, Timeout

async def create_vector_store():
    client = AsyncOpenAI()

    try:
        vector_store = await client.beta.vector_stores.create(
            name="My Vector Store",
            file_ids=["file-abc123"]
        )
        print(f"Vector Store created with ID: {vector_store.id}")
    except APIError as e:
        print(f"API Error: {e}")
        print(f"HTTP Status: {e.http_status}")
        print(f"Error Code: {e.code}")
    except RateLimitError:
        print("Rate limit exceeded. Please wait before making more requests.")
    except Timeout:
        print("Request timed out. Please try again later.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

asyncio.run(create_vector_store())
```

Key points about asynchronous error handling:

1. Use `async/await` syntax consistently in asynchronous functions.
2. Exceptions are raised and caught in the same way as synchronous code.
3. Ensure that all asynchronous operations are properly awaited to catch errors.

## Logging and Debugging Strategies

Effective logging and debugging are essential for maintaining and troubleshooting OpenAI-powered applications. Here are some strategies to consider:

1. Use Python's built-in logging module to create structured logs:

```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    # API call here
except APIError as e:
    logger.error(f"API Error occurred: {e}", extra={
        "http_status": e.http_status,
        "error_code": e.code,
        "request_id": e.headers.get("X-Request-ID")
    })
```

2. Implement request ID tracking for correlating logs across different parts of your application:

```python
import uuid

def generate_request_id():
    return str(uuid.uuid4())

request_id = generate_request_id()
logger.info(f"Starting vector store creation", extra={"request_id": request_id})

# Include the request_id in your API calls
client.beta.vector_stores.create(
    name="My Vector Store",
    file_ids=["file-abc123"],
    extra_headers={"X-Request-ID": request_id}
)
```

3. Use debug mode for development and testing:

```python
import openai

openai.debug = True
```

This will enable more verbose logging of API requests and responses.

4. Implement custom error handling and logging middleware:

```python
class ErrorLoggingMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        try:
            await self.app(scope, receive, send)
        except Exception as e:
            logger.exception(f"An error occurred: {e}")
            # Re-raise the exception or handle it as appropriate
            raise
```

5. Use OpenAI's support resources:

If you encounter persistent issues or need help debugging complex problems, don't hesitate to use OpenAI's support resources, including their documentation, community forums, and support channels.

## Conclusion

Effective error handling and response management are crucial for building robust and reliable applications with the OpenAI library. By leveraging raw response and streaming response options, implementing thorough error handling, and employing effective logging and debugging strategies, you can create applications that gracefully handle errors and provide valuable insights for troubleshooting and optimization.

In the next lesson, we'll explore advanced topics and best practices for working with the OpenAI library, building on the concepts we've covered in this and previous lessons.
