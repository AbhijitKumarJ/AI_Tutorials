# Bonus Lesson: Practical Applications and Real-World Projects

In this bonus lesson, we'll explore practical applications of the knowledge you've gained throughout the course. We'll dive into real-world projects that leverage the OpenAI API, demonstrating how to apply your skills to create innovative and impactful applications.

## 1. AI-Powered Content Generation System

Let's start by creating a comprehensive content generation system that can produce various types of written content, from blog posts to product descriptions.

### Project Overview

This system will use the OpenAI API to generate content based on user input, and will include features like topic expansion, SEO optimization, and content customization.

### Implementation

```python
import openai
from typing import List, Dict
import re

class ContentGenerator:
    def __init__(self, api_key: str):
        self.api_key = api_key
        openai.api_key = self.api_key

    def generate_outline(self, topic: str, num_sections: int = 3) -> List[str]:
        prompt = f"Create an outline for a blog post about {topic} with {num_sections} main sections:"
        response = openai.Completion.create(
            engine="text-davinci-002",
            prompt=prompt,
            max_tokens=200,
            n=1,
            stop=None,
            temperature=0.7,
        )
        outline = response.choices[0].text.strip().split("\n")
        return [section.strip() for section in outline if section.strip()]

    def expand_section(self, topic: str, section: str) -> str:
        prompt = f"Write a detailed paragraph about the following section of a blog post about {topic}:\n\n{section}"
        response = openai.Completion.create(
            engine="text-davinci-002",
            prompt=prompt,
            max_tokens=300,
            n=1,
            stop=None,
            temperature=0.7,
        )
        return response.choices[0].text.strip()

    def generate_seo_keywords(self, topic: str) -> List[str]:
        prompt = f"Generate a list of 5 SEO keywords for a blog post about {topic}:"
        response = openai.Completion.create(
            engine="text-davinci-002",
            prompt=prompt,
            max_tokens=100,
            n=1,
            stop=None,
            temperature=0.5,
        )
        keywords = response.choices[0].text.strip().split("\n")
        return [keyword.strip() for keyword in keywords if keyword.strip()]

    def optimize_for_seo(self, content: str, keywords: List[str]) -> str:
        prompt = f"Optimize the following content for SEO using these keywords: {', '.join(keywords)}. Content:\n\n{content}"
        response = openai.Completion.create(
            engine="text-davinci-002",
            prompt=prompt,
            max_tokens=len(content) + 100,
            n=1,
            stop=None,
            temperature=0.7,
        )
        return response.choices[0].text.strip()

    def generate_content(self, topic: str) -> Dict[str, str]:
        outline = self.generate_outline(topic)
        keywords = self.generate_seo_keywords(topic)
        
        content = f"# {topic}\n\n"
        for section in outline:
            content += f"## {section}\n\n"
            section_content = self.expand_section(topic, section)
            content += f"{section_content}\n\n"
        
        optimized_content = self.optimize_for_seo(content, keywords)
        
        return {
            "original": content,
            "seo_optimized": optimized_content,
            "keywords": keywords
        }

# Usage
generator = ContentGenerator("your-api-key-here")
result = generator.generate_content("The Impact of Artificial Intelligence on Modern Healthcare")
print(result["seo_optimized"])
print("\nKeywords:", result["keywords"])
```

This content generation system demonstrates several key concepts:

1. **Modular Design**: The system is broken down into separate methods for different tasks (outline generation, section expansion, SEO optimization), making it easy to maintain and extend.

2. **Prompt Engineering**: Each method uses carefully crafted prompts to guide the AI in generating the desired content.

3. **Iterative Content Creation**: The system builds content piece by piece, first creating an outline, then expanding each section, and finally optimizing for SEO.

4. **SEO Integration**: The system incorporates SEO best practices by generating relevant keywords and optimizing the content accordingly.

## 2. Intelligent Customer Support Chatbot

Next, let's create a more advanced chatbot that can handle customer support queries, integrating with a hypothetical product database and order tracking system.

### Project Overview

This chatbot will use the OpenAI API for natural language understanding and generation, while also interfacing with external systems to provide accurate, context-aware responses.

### Implementation

```python
import openai
from typing import Dict, Any
import json

class CustomerSupportBot:
    def __init__(self, api_key: str):
        self.api_key = api_key
        openai.api_key = self.api_key
        self.conversation_history = []

    def get_product_info(self, product_id: str) -> Dict[str, Any]:
        # This would normally query a database. For this example, we'll use a mock.
        products = {
            "P001": {"name": "SuperWidget", "price": 99.99, "stock": 50},
            "P002": {"name": "MegaGadget", "price": 149.99, "stock": 25},
        }
        return products.get(product_id, {})

    def get_order_status(self, order_id: str) -> str:
        # This would normally query an order tracking system. For this example, we'll use a mock.
        orders = {
            "O001": "Shipped",
            "O002": "Processing",
            "O003": "Delivered",
        }
        return orders.get(order_id, "Not Found")

    def generate_response(self, user_input: str) -> str:
        # Add user input to conversation history
        self.conversation_history.append({"role": "user", "content": user_input})

        # Prepare the messages for the API call
        messages = [
            {"role": "system", "content": "You are a helpful customer support assistant for an e-commerce company."},
            *self.conversation_history
        ]

        # Generate response
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages,
            max_tokens=150,
            n=1,
            stop=None,
            temperature=0.7,
        )

        assistant_response = response.choices[0].message['content'].strip()

        # Check if we need to query product info or order status
        if "product" in user_input.lower() and any(pid in user_input for pid in ["P001", "P002"]):
            product_id = "P001" if "P001" in user_input else "P002"
            product_info = self.get_product_info(product_id)
            if product_info:
                assistant_response += f"\n\nProduct information: {json.dumps(product_info)}"

        if "order" in user_input.lower() and any(oid in user_input for oid in ["O001", "O002", "O003"]):
            order_id = next(oid for oid in ["O001", "O002", "O003"] if oid in user_input)
            order_status = self.get_order_status(order_id)
            assistant_response += f"\n\nOrder status for {order_id}: {order_status}"

        # Add assistant response to conversation history
        self.conversation_history.append({"role": "assistant", "content": assistant_response})

        return assistant_response

    def start_chat(self):
        print("Customer Support Bot: Hello! How can I assist you today?")
        while True:
            user_input = input("You: ")
            if user_input.lower() in ['exit', 'quit', 'bye']:
                print("Customer Support Bot: Thank you for chatting with us. Have a great day!")
                break
            response = self.generate_response(user_input)
            print(f"Customer Support Bot: {response}")

# Usage
bot = CustomerSupportBot("your-api-key-here")
bot.start_chat()
```

This customer support chatbot showcases several advanced concepts:

1. **Contextual Awareness**: The bot maintains a conversation history, allowing it to understand and respond to queries in context.

2. **Integration with External Systems**: The bot interfaces with mock product and order databases, demonstrating how AI can be combined with traditional data systems.

3. **Dynamic Response Generation**: The bot generates responses using the OpenAI API, then enhances these responses with specific product or order information when relevant.

4. **Natural Conversation Flow**: The chat interface allows for a natural back-and-forth between the user and the bot.

## 3. AI-Assisted Code Refactoring Tool

Lastly, let's create a tool that uses AI to assist in code refactoring tasks. This tool will analyze Python code and suggest improvements or optimizations.

### Project Overview

This tool will use the OpenAI API to understand and generate code, providing suggestions for improving code quality, readability, and efficiency.

### Implementation

```python
import openai
import ast
import astunparse

class CodeRefactorAssistant:
    def __init__(self, api_key: str):
        self.api_key = api_key
        openai.api_key = self.api_key

    def analyze_code(self, code: str) -> str:
        prompt = f"Analyze the following Python code and suggest improvements for readability, efficiency, and best practices:\n\n{code}\n\nSuggestions:"
        response = openai.Completion.create(
            engine="text-davinci-002",
            prompt=prompt,
            max_tokens=200,
            n=1,
            stop=None,
            temperature=0.7,
        )
        return response.choices[0].text.strip()

    def suggest_docstring(self, func_def: str) -> str:
        prompt = f"Write a clear and concise docstring for the following Python function:\n\n{func_def}\n\nDocstring:"
        response = openai.Completion.create(
            engine="text-davinci-002",
            prompt=prompt,
            max_tokens=100,
            n=1,
            stop=None,
            temperature=0.7,
        )
        return response.choices[0].text.strip()

    def refactor_code(self, code: str) -> str:
        tree = ast.parse(code)
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                if not ast.get_docstring(node):
                    docstring = self.suggest_docstring(astunparse.unparse(node))
                    node.body.insert(0, ast.Expr(ast.Str(s=docstring)))
        
        return astunparse.unparse(tree)

    def improve_code(self, code: str) -> Dict[str, str]:
        analysis = self.analyze_code(code)
        refactored_code = self.refactor_code(code)
        return {
            "original_code": code,
            "analysis": analysis,
            "refactored_code": refactored_code
        }

# Usage
assistant = CodeRefactorAssistant("your-api-key-here")

sample_code = """
def fibonacci(n):
    if n <= 1:
        return n
    else:
        return fibonacci(n-1) + fibonacci(n-2)

def print_fibonacci(n):
    for i in range(n):
        print(fibonacci(i))
"""

result = assistant.improve_code(sample_code)
print("Original Code:")
print(result["original_code"])
print("\nAnalysis:")
print(result["analysis"])
print("\nRefactored Code:")
print(result["refactored_code"])
```

This code refactoring assistant demonstrates several advanced concepts in AI-assisted development:

1. **Code Analysis**: The tool uses AI to analyze code and provide suggestions for improvement, which can help developers identify potential issues or optimizations they might have missed.

2. **Automated Docstring Generation**: The assistant can generate docstrings for functions that lack them, improving code documentation automatically.

3. **Abstract Syntax Tree (AST) Manipulation**: The tool uses Python's `ast` module to parse, analyze, and modify code structures programmatically.

4. **AI-Powered Code Generation**: While this example focuses on analysis and docstring generation, the same principles could be extended to generate or modify code based on high-level descriptions or requirements.

5. **Iterative Improvement**: The tool provides both an analysis of the existing code and a refactored version, allowing developers to understand the suggestions and see them applied.

## Conclusion

These practical applications demonstrate how the OpenAI API can be leveraged to create powerful, intelligent systems across various domains:

1. **Content Creation**: The AI-powered content generation system shows how AI can assist in creating high-quality, SEO-optimized written content, potentially revolutionizing the fields of marketing and journalism.

2. **Customer Service**: The intelligent customer support chatbot illustrates how AI can enhance customer interactions, providing quick, accurate responses while seamlessly integrating with existing business systems.

3. **Software Development**: The AI-assisted code refactoring tool showcases how AI can be used to improve software development processes, potentially increasing code quality and developer productivity.

Each of these projects can serve as a starting point for more complex applications. For example:

- The content generation system could be expanded into a full-fledged content management system with AI-powered editing and optimization features.
- The customer support chatbot could be integrated with a company's CRM system and trained on company-specific data to provide even more personalized support.
- The code refactoring tool could be developed into an IDE plugin that provides real-time coding assistance and suggestions.

As you continue to work with the OpenAI API and other AI technologies, keep in mind the ethical considerations we've discussed throughout this course. Always strive to create applications that are beneficial, fair, and respectful of user privacy.

The field of AI is rapidly evolving, and new possibilities are emerging all the time. By combining your programming skills with the power of AI, you're well-positioned to create innovative solutions to real-world problems. Keep experimenting, learning, and pushing the boundaries of what's possible with AI!

