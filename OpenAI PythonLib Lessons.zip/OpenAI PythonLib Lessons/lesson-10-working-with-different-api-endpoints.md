# Lesson 10: Working with Different API Endpoints in the OpenAI Python Library

## Introduction

In this lesson, we'll explore how to work with various API endpoints using the OpenAI Python Library. We'll cover the main categories of endpoints: chat completions, image generation, audio processing, file management, and fine-tuning operations. For each category, we'll discuss the purpose of the endpoint, how to use it with the library, and provide practical examples.

## File Layout

Before we dive into the specifics, let's look at how the different endpoints are organized within the library:

```
openai/
    resources/
        chat/
            completions.py
        images/
            images.py
        audio/
            speech.py
            transcriptions.py
            translations.py
        files/
            files.py
        fine_tuning/
            jobs.py
    _client.py
    ...
```

Each category of endpoints is typically represented by a separate module within the `resources` directory. The `_client.py` file serves as the main entry point for interacting with these endpoints.

## 1. Chat Completions

Chat completions are one of the most commonly used endpoints in the OpenAI API. They allow you to generate human-like text based on a given conversation history.

### Purpose
The chat completions endpoint is used for generating conversational responses, answering questions, and creating text based on a series of messages.

### Usage
To use chat completions, you typically create a list of messages representing the conversation history, then send this to the API to generate a response.

### Example

```python
from openai import OpenAI

client = OpenAI()

response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "What's the capital of France?"}
    ]
)

print(response.choices[0].message.content)
```

In this example, we're using the `gpt-3.5-turbo` model to generate a response to the question "What's the capital of France?". The system message sets the context for the AI's behavior.

### Key Points
- The `messages` parameter is a list of dictionaries, each representing a message in the conversation.
- Each message has a `role` ("system", "user", or "assistant") and `content`.
- The `model` parameter specifies which AI model to use for generating the response.
- The response object contains various metadata about the API call, but the actual generated text is in `response.choices[0].message.content`.

## 2. Image Generation and Manipulation

The OpenAI API provides endpoints for generating and manipulating images based on text descriptions.

### Purpose
These endpoints allow you to create, edit, or generate variations of images using natural language descriptions.

### Usage
The image endpoints are accessed through the `images` resource in the library. You can create new images, edit existing ones, or create variations of images.

### Example

```python
from openai import OpenAI

client = OpenAI()

response = client.images.generate(
    model="dall-e-3",
    prompt="A serene landscape with a lake and mountains at sunset",
    n=1,
    size="1024x1024"
)

image_url = response.data[0].url
print(f"Generated image URL: {image_url}")
```

This example generates an image based on the given prompt using the DALL-E 3 model.

### Key Points
- The `prompt` parameter is a text description of the image you want to generate.
- `n` specifies the number of images to generate (1 in this case).
- `size` determines the resolution of the generated image.
- The response contains a URL where the generated image can be accessed.
- For image editing or creating variations, you would use the `edit` or `create_variation` methods respectively, which require an existing image file.

## 3. Audio Processing

The OpenAI API offers several audio-related endpoints for speech synthesis, transcription, and translation.

### Purpose
These endpoints allow you to convert text to speech, transcribe audio to text, and translate audio from one language to another.

### Usage
Audio processing is divided into three main categories: speech (text-to-speech), transcriptions (speech-to-text), and translations (speech-to-text with translation).

### Example: Text-to-Speech

```python
from openai import OpenAI
import io

client = OpenAI()

response = client.audio.speech.create(
    model="tts-1",
    voice="alloy",
    input="Hello, world! This is a test of the OpenAI text-to-speech API."
)

# Save the audio to a file
with open("output.mp3", "wb") as f:
    for chunk in response.iter_bytes():
        f.write(chunk)

print("Audio saved to output.mp3")
```

This example generates an audio file from the given text input.

### Example: Speech-to-Text (Transcription)

```python
from openai import OpenAI

client = OpenAI()

with open("audio_file.mp3", "rb") as audio_file:
    transcript = client.audio.transcriptions.create(
        model="whisper-1", 
        file=audio_file
    )

print(transcript.text)
```

This example transcribes an audio file to text.

### Key Points
- For speech synthesis, you can choose different voices and control aspects like speed and pitch.
- Transcription and translation support various audio formats and can handle multiple languages.
- The `whisper-1` model is used for both transcription and translation tasks.
- Audio files need to be opened in binary mode ('rb') when passed to the API.

## 4. File Management

The OpenAI API includes endpoints for managing files that can be used with other API features, such as fine-tuning.

### Purpose
File management endpoints allow you to upload, list, retrieve, and delete files associated with your OpenAI account.

### Usage
File operations are handled through the `files` resource in the library.

### Example

```python
from openai import OpenAI

client = OpenAI()

# Upload a file
with open("training_data.jsonl", "rb") as file:
    upload = client.files.create(
        file=file,
        purpose="fine-tune"
    )

print(f"File uploaded with ID: {upload.id}")

# List files
files = client.files.list()
for file in files:
    print(f"File: {file.filename}, ID: {file.id}, Purpose: {file.purpose}")

# Retrieve file content
file_content = client.files.retrieve_content(upload.id)
print(f"File content: {file_content[:100]}...")  # Print first 100 characters

# Delete a file
client.files.delete(upload.id)
print(f"File {upload.id} deleted")
```

This example demonstrates uploading a file, listing all files, retrieving file content, and deleting a file.

### Key Points
- Files have a `purpose` which determines how they can be used (e.g., "fine-tune" for files used in fine-tuning).
- File IDs are used to reference files in other API calls, such as when starting a fine-tuning job.
- The `retrieve_content` method is useful for verifying the contents of uploaded files.
- Always remember to delete files that are no longer needed to manage your storage efficiently.

## 5. Fine-tuning Operations

Fine-tuning allows you to improve the performance of OpenAI's models on specific tasks by training them on your custom dataset.

### Purpose
Fine-tuning endpoints enable you to create custom versions of OpenAI's models that are tailored to your specific use case.

### Usage
Fine-tuning operations are managed through the `fine_tuning` resource in the library.

### Example

```python
from openai import OpenAI

client = OpenAI()

# Create a fine-tuning job
job = client.fine_tuning.jobs.create(
    training_file="file-abc123",  # ID of a file uploaded with purpose='fine-tune'
    model="gpt-3.5-turbo"
)

print(f"Fine-tuning job created with ID: {job.id}")

# Retrieve the status of a fine-tuning job
job_status = client.fine_tuning.jobs.retrieve(job.id)
print(f"Job status: {job_status.status}")

# List all fine-tuning jobs
jobs = client.fine_tuning.jobs.list()
for job in jobs:
    print(f"Job ID: {job.id}, Model: {job.model}, Status: {job.status}")

# Cancel a fine-tuning job (if needed)
canceled_job = client.fine_tuning.jobs.cancel(job.id)
print(f"Job {canceled_job.id} cancelled")
```

This example shows how to create a fine-tuning job, check its status, list all jobs, and cancel a job if necessary.

### Key Points
- Fine-tuning requires a training file that has been previously uploaded using the file management endpoints.
- The `model` parameter specifies which base model to fine-tune (e.g., "gpt-3.5-turbo").
- Fine-tuning jobs can take a significant amount of time to complete, so it's important to monitor their status.
- Once a fine-tuning job is complete, you can use the fine-tuned model in other API calls by specifying its ID.
- Carefully manage your fine-tuned models, as they can incur additional costs.

## Conclusion

In this lesson, we've explored the main categories of endpoints available in the OpenAI API and how to interact with them using the OpenAI Python Library. We've covered chat completions for generating conversational text, image generation and manipulation for creating visual content, audio processing for speech synthesis and recognition, file management for handling data used in other API operations, and fine-tuning for creating custom models.

Each of these endpoint categories offers powerful capabilities that can be combined to create sophisticated AI-powered applications. As you work with these endpoints, remember to consult the official OpenAI documentation for the most up-to-date information on available parameters and best practices.

In the next lesson, we'll dive into advanced features and customization options that allow you to get the most out of the OpenAI API and tailor it to your specific needs.
