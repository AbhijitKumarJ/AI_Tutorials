# Lesson 2: Python Fundamentals for OpenAI Library

## 1. Review of Essential Python Concepts

Before diving into the specifics of the OpenAI Library, it's crucial to have a solid understanding of fundamental Python concepts. Let's review some key elements that are particularly relevant to working with the OpenAI Library:

### Variables and Data Types

Python is a dynamically-typed language, which means you don't need to declare the type of a variable explicitly. However, understanding data types is crucial for effective programming.

```python
# Integer
api_version = 1

# Float
confidence_score = 0.95

# String
model_name = "gpt-3.5-turbo"

# Boolean
is_streaming = True

# List
messages = [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "Hello, how are you?"}
]

# Dictionary
completion_params = {
    "model": "gpt-3.5-turbo",
    "temperature": 0.7,
    "max_tokens": 150
}
```

Understanding these data types is essential because the OpenAI Library often requires specific data structures (like lists of messages or parameter dictionaries) when making API calls.

### Functions

Functions are reusable blocks of code that perform specific tasks. They are crucial for organizing code and promoting reusability. In the context of the OpenAI Library, you'll often create functions to encapsulate API calls or process responses.

```python
def generate_response(prompt, model="gpt-3.5-turbo", max_tokens=100):
    """
    Generate a response using the OpenAI API.
    
    :param prompt: The input prompt
    :param model: The model to use (default: gpt-3.5-turbo)
    :param max_tokens: Maximum number of tokens in the response
    :return: Generated response text
    """
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=max_tokens
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"An error occurred: {e}")
        return None
```

This function encapsulates the process of making an API call to generate a response, including error handling. It demonstrates how functions can be used to create reusable components when working with the OpenAI Library.

## 2. Object-Oriented Programming in Python

Object-Oriented Programming (OOP) is a programming paradigm that organizes code into objects, which are instances of classes. The OpenAI Library extensively uses OOP principles, so understanding these concepts is crucial.

### Classes and Objects

A class is a blueprint for creating objects. It defines attributes (data) and methods (functions) that its objects will have. The OpenAI Library uses classes to represent various components of the API, such as clients, models, and responses.

```python
class AIAssistant:
    def __init__(self, model_name, api_key):
        self.model_name = model_name
        self.client = openai.OpenAI(api_key=api_key)
    
    def generate_response(self, prompt, max_tokens=100):
        try:
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=max_tokens
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"An error occurred: {e}")
            return None

# Usage
assistant = AIAssistant("gpt-3.5-turbo", "your-api-key")
response = assistant.generate_response("What is the capital of France?")
print(response)
```

This example demonstrates how a class can be used to create a simple AI assistant using the OpenAI Library. The class encapsulates the API client and provides a method for generating responses.

### Inheritance

Inheritance allows a class to inherit attributes and methods from another class. This is useful for creating specialized versions of classes or for organizing code hierarchically.

```python
class SpecializedAssistant(AIAssistant):
    def __init__(self, model_name, api_key, specialty):
        super().__init__(model_name, api_key)
        self.specialty = specialty
    
    def generate_response(self, prompt, max_tokens=100):
        specialized_prompt = f"As an expert in {self.specialty}, {prompt}"
        return super().generate_response(specialized_prompt, max_tokens)

# Usage
science_assistant = SpecializedAssistant("gpt-3.5-turbo", "your-api-key", "science")
response = science_assistant.generate_response("Explain photosynthesis")
print(response)
```

This example shows how inheritance can be used to create a specialized version of the AIAssistant class. The SpecializedAssistant inherits from AIAssistant but adds its own functionality.

### Encapsulation

Encapsulation is the bundling of data and the methods that operate on that data within a single unit (class). It restricts direct access to some of an object's components, which is a means of preventing accidental interference and misuse of the methods and data.

In Python, encapsulation is typically achieved using private attributes (prefixed with double underscores) and getter/setter methods.

```python
class SecureAIAssistant:
    def __init__(self, model_name, api_key):
        self.__model_name = model_name
        self.__client = openai.OpenAI(api_key=api_key)
    
    def get_model_name(self):
        return self.__model_name
    
    def set_model_name(self, model_name):
        if model_name in ["gpt-3.5-turbo", "gpt-4"]:
            self.__model_name = model_name
        else:
            raise ValueError("Invalid model name")
    
    def generate_response(self, prompt, max_tokens=100):
        # Implementation remains the same
        pass

# Usage
secure_assistant = SecureAIAssistant("gpt-3.5-turbo", "your-api-key")
print(secure_assistant.get_model_name())  # Accessing through getter
secure_assistant.set_model_name("gpt-4")  # Modifying through setter
```

In this example, the `__model_name` and `__client` attributes are private, and access is controlled through getter and setter methods. This encapsulation helps prevent accidental modification of these critical attributes.

## 3. Type Hinting and Its Importance in the OpenAI Library

Type hinting is a feature in Python that allows you to specify the expected types of variables, function parameters, and return values. While Python remains dynamically typed, type hints provide several benefits:

1. Improved code readability
2. Better IDE support (auto-completion, error detection)
3. Enhanced static type checking tools (e.g., mypy)
4. Clearer documentation

The OpenAI Library extensively uses type hinting to make the codebase more maintainable and to provide better developer experience. Here's an example of how type hinting is used:

```python
from typing import List, Dict, Optional
import openai

def generate_chat_completion(
    messages: List[Dict[str, str]],
    model: str = "gpt-3.5-turbo",
    max_tokens: Optional[int] = None
) -> str:
    """
    Generate a chat completion using the OpenAI API.

    :param messages: List of message dictionaries
    :param model: The model to use for completion
    :param max_tokens: Maximum number of tokens to generate (optional)
    :return: Generated completion text
    """
    client: openai.OpenAI = openai.OpenAI()
    
    try:
        response: openai.types.chat.completion.ChatCompletion = client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=max_tokens
        )
        return response.choices[0].message.content
    except openai.APIError as e:
        print(f"An API error occurred: {e}")
        return ""

# Usage
messages: List[Dict[str, str]] = [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "What is the capital of Japan?"}
]

result: str = generate_chat_completion(messages)
print(result)
```

In this example, we use type hints to specify the types of function parameters, local variables, and the return value. This makes the code more self-documenting and helps catch type-related errors early in the development process.

## 4. Understanding Asynchronous Programming in Python

Asynchronous programming is a concurrent programming model that allows multiple I/O-bound operations to run concurrently, improving the overall efficiency of the program. The OpenAI Library supports both synchronous and asynchronous operations, making it crucial to understand asynchronous programming concepts.

### Async and Await Keywords

Python's `async` and `await` keywords are used to define and work with coroutines, which are the building blocks of asynchronous programming.

```python
import asyncio
import openai

async def generate_async_completion(prompt: str) -> str:
    client = openai.AsyncOpenAI()
    try:
        response = await client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message.content
    except openai.APIError as e:
        print(f"An API error occurred: {e}")
        return ""

async def main():
    prompts = [
        "What is the capital of France?",
        "Who wrote 'Romeo and Juliet'?",
        "What is the largest planet in our solar system?"
    ]
    
    tasks = [generate_async_completion(prompt) for prompt in prompts]
    results = await asyncio.gather(*tasks)
    
    for prompt, result in zip(prompts, results):
        print(f"Prompt: {prompt}")
        print(f"Response: {result}\n")

# Run the async main function
asyncio.run(main())
```

This example demonstrates how to use asynchronous programming with the OpenAI Library. The `generate_async_completion` function is defined as a coroutine using the `async` keyword. We use `await` to wait for the asynchronous API call to complete. The `main` function shows how to run multiple API calls concurrently using `asyncio.gather`.

## 5. Error Handling and Exceptions in Python

Proper error handling is crucial when working with external APIs like OpenAI. Python's try-except blocks are used to catch and handle exceptions.

```python
import openai

def safe_generate_completion(prompt: str) -> str:
    client = openai.OpenAI()
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message.content
    except openai.APIError as e:
        print(f"An API error occurred: {e}")
    except openai.RateLimitError as e:
        print(f"Rate limit exceeded: {e}")
    except openai.APIConnectionError as e:
        print(f"Failed to connect to OpenAI API: {e}")
    except openai.AuthenticationError as e:
        print(f"Authentication failed: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    
    return "Sorry, I couldn't generate a response at this time."

# Usage
result = safe_generate_completion("What is the meaning of life?")
print(result)
```

This example demonstrates how to handle various types of exceptions that may occur when using the OpenAI Library. It's important to catch specific exceptions (like `APIError`, `RateLimitError`, etc.) to provide more informative error messages and potentially implement appropriate error-handling strategies.

## 6. Context Managers and Their Usage in the Library

Context managers in Python are used for resource management, ensuring that resources are properly acquired and released. They are typically used with the `with` statement. The OpenAI Library uses context managers for managing API resources and connections.

```python
import openai
from openai.types import CompletionUsage

class OpenAIContext:
    def __init__(self, api_key: str):
        self.client = openai.OpenAI(api_key=api_key)
    
    def __enter__(self):
        print("Entering OpenAI context")
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        print("Exiting OpenAI context")
        # Perform any necessary cleanup here
    
    def generate_completion(self, prompt: str) -> tuple[str, CompletionUsage]:
        response = self.client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message.content, response.usage

# Usage
with OpenAIContext("your-api-key") as ai_context:
    content, usage = ai_context.generate_completion("Tell me a joke")
    print(f"Generated content: {content}")
    print(f"Token usage: {usage}")
```

In this example, we create a custom context manager for OpenAI operations. The `__enter__` method is called when entering the context (opening the `with` block), and `__exit__` is called when exiting. This pattern can be useful for managing resources, handling errors, or performing setup and teardown operations when working with the OpenAI Library.

The OpenAI Library itself uses context managers internally for managing HTTP sessions and other resources, ensuring efficient and safe API interactions.

In conclusion, this lesson has covered essential Python concepts that are particularly relevant when working with the OpenAI Library. We've explored object-oriented programming, type hinting, asynchronous programming, error handling, and context managers. Understanding these concepts will greatly enhance your ability to work effectively with the OpenAI Library and create robust, efficient applications. In the next lesson, we'll dive deeper into the library's architecture and explore its main components in more detail.

