# Lesson 15: Security Best Practices

## Introduction

Security is a critical aspect of any application, especially when dealing with AI and machine learning services that may process sensitive data. In this lesson, we'll explore security best practices for using the OpenAI Python Library. We'll cover secure handling of API keys, implementing rate limiting and quota management, data privacy considerations, secure storage of conversation history, encryption techniques, and compliance with security standards.

## 1. Secure Handling of API Keys and Tokens

API keys are the primary means of authentication for the OpenAI API. Protecting these keys is crucial to prevent unauthorized access to your OpenAI resources.

### Best Practices for API Key Management

1. **Never hardcode API keys**: Avoid including API keys directly in your source code. Instead, use environment variables or secure configuration files.

2. **Use environment variables**: Store API keys as environment variables and access them in your code. This approach keeps sensitive information separate from your codebase.

   Example:
   ```python
   import os
   from openai import OpenAI

   api_key = os.environ.get("OPENAI_API_KEY")
   if not api_key:
       raise ValueError("OPENAI_API_KEY environment variable is not set")

   client = OpenAI(api_key=api_key)
   ```

3. **Use a secrets management service**: For production environments, consider using a secrets management service like AWS Secrets Manager, Azure Key Vault, or HashiCorp Vault.

4. **Rotate API keys regularly**: Periodically generate new API keys and update your applications. This limits the potential damage if a key is compromised.

5. **Use different API keys for different environments**: Use separate keys for development, staging, and production environments to limit the impact of a compromised key.

6. **Implement the principle of least privilege**: Only grant the necessary permissions to each API key. If OpenAI introduces more granular permissions in the future, take advantage of them.

### Secure Configuration Files

For local development, you can use a `.env` file to store your API key. Ensure this file is never committed to version control.

Example `.env` file:
```
OPENAI_API_KEY=your-api-key-here
```

To use this file, you can use the `python-dotenv` library:

```python
from dotenv import load_dotenv
import os
from openai import OpenAI

load_dotenv()  # Load environment variables from .env file

api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise ValueError("OPENAI_API_KEY not found in .env file")

client = OpenAI(api_key=api_key)
```

Remember to add `.env` to your `.gitignore` file to prevent accidental commits:

```
# .gitignore
.env
```

## 2. Implementing Rate Limiting and Quota Management

OpenAI API has rate limits and quotas to prevent abuse and ensure fair usage. Implementing your own rate limiting can help you stay within these limits and manage your API usage effectively.

### Client-Side Rate Limiting

While the OpenAI API enforces rate limits server-side, implementing client-side rate limiting can help prevent quota exhaustion and manage costs.

Here's an example using the `ratelimit` library:

```python
from ratelimit import limits, sleep_and_retry
from openai import OpenAI

client = OpenAI()

# Limit to 20 calls per minute
@sleep_and_retry
@limits(calls=20, period=60)
def rate_limited_completion(prompt):
    return client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )

# Usage
try:
    for i in range(25):
        response = rate_limited_completion("Hello, world!")
        print(f"Request {i+1}: {response.choices[0].message.content}")
except Exception as e:
    print(f"Rate limit exceeded: {e}")
```

This code will automatically slow down requests to stay within the defined limit of 20 calls per minute.

### Quota Management

To manage your API usage and prevent unexpected costs, you can implement a quota system. Here's a simple example using Redis to track API calls:

```python
import redis
from openai import OpenAI

client = OpenAI()
redis_client = redis.Redis(host='localhost', port=6379, db=0)

def check_and_update_quota(user_id, limit=1000):
    key = f"openai_quota:{user_id}"
    current_usage = redis_client.get(key)
    
    if current_usage is None:
        redis_client.set(key, 1)
        return True
    elif int(current_usage) < limit:
        redis_client.incr(key)
        return True
    else:
        return False

def make_api_call(user_id, prompt):
    if check_and_update_quota(user_id):
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message.content
    else:
        return "Quota exceeded. Please try again later."

# Usage
user_id = "user123"
print(make_api_call(user_id, "Hello, world!"))
```

This example uses Redis to track API usage per user and ensures that each user stays within their allocated quota.

## 3. Data Privacy and Handling Sensitive Information

When working with the OpenAI API, it's crucial to consider data privacy, especially when processing user data or sensitive information.

### Best Practices for Data Privacy

1. **Minimize data collection**: Only collect and process the data you absolutely need.

2. **Anonymize data**: Remove or hash personally identifiable information (PII) before sending it to the API.

3. **Inform users**: Clearly communicate to users how their data will be used and processed.

4. **Implement data retention policies**: Regularly delete data that is no longer needed.

5. **Use OpenAI's data privacy features**: Take advantage of any data privacy features offered by OpenAI, such as data processing agreements or privacy-preserving APIs if available.

### Example: Anonymizing Data

Here's a simple example of how you might anonymize user data before sending it to the OpenAI API:

```python
import hashlib
from openai import OpenAI

client = OpenAI()

def anonymize_data(text):
    # This is a very basic example. In practice, you'd use more sophisticated
    # methods to identify and anonymize different types of PII.
    words = text.split()
    anonymized_words = [hashlib.sha256(word.encode()).hexdigest()[:8] if word.istitle() else word for word in words]
    return " ".join(anonymized_words)

def process_user_input(user_input):
    anonymized_input = anonymize_data(user_input)
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": anonymized_input}]
    )
    return response.choices[0].message.content

# Usage
user_input = "My name is John Doe and I live in New York."
print("Original input:", user_input)
print("Processed result:", process_user_input(user_input))
```

This example uses a simple hashing technique to anonymize potential names in the input. In a real-world scenario, you'd use more sophisticated natural language processing techniques to identify and anonymize various types of PII.

## 4. Secure Storage of Conversation History and User Data

If your application stores conversation history or user data, it's important to implement secure storage practices.

### Best Practices for Secure Storage

1. **Encryption at rest**: Encrypt sensitive data before storing it in your database.

2. **Use secure databases**: Choose databases with built-in security features and keep them updated.

3. **Implement access controls**: Use role-based access control (RBAC) to limit who can access stored data.

4. **Regular backups**: Implement a secure backup strategy for your data.

5. **Data sanitization**: Sanitize user inputs to prevent SQL injection and other attacks.

### Example: Encrypting Conversation History

Here's an example of how you might encrypt conversation history before storing it:

```python
from cryptography.fernet import Fernet
import json
from openai import OpenAI

client = OpenAI()

# In a real application, store this key securely and never hardcode it
encryption_key = Fernet.generate_key()
fernet = Fernet(encryption_key)

def encrypt_conversation(conversation):
    return fernet.encrypt(json.dumps(conversation).encode()).decode()

def decrypt_conversation(encrypted_conversation):
    return json.loads(fernet.decrypt(encrypted_conversation.encode()).decode())

def chat_and_store(prompt, conversation_history=None):
    if conversation_history is None:
        conversation_history = []
    
    conversation_history.append({"role": "user", "content": prompt})
    
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=conversation_history
    )
    
    ai_message = response.choices[0].message.content
    conversation_history.append({"role": "assistant", "content": ai_message})
    
    # Encrypt before storing
    encrypted_history = encrypt_conversation(conversation_history)
    
    # In a real application, you would store encrypted_history in a database here
    
    return ai_message, encrypted_history

# Usage
prompt = "Hello, how are you?"
response, encrypted_history = chat_and_store(prompt)
print("AI response:", response)
print("Encrypted history:", encrypted_history)

# To retrieve and use the history later
decrypted_history = decrypt_conversation(encrypted_history)
print("Decrypted history:", decrypted_history)
```

This example demonstrates a basic method of encrypting conversation history. In a real-world application, you would store the encrypted data in a secure database and implement proper key management practices.

## 5. Encryption and Hashing Techniques

Encryption and hashing are fundamental techniques for protecting sensitive data. While the previous example showed a basic encryption technique, let's explore some more advanced concepts.

### Encryption

Encryption is the process of encoding information in such a way that only authorized parties can access it. For sensitive data that needs to be retrieved and decrypted later, you should use strong encryption algorithms.

Example using AES encryption:

```python
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import os

def encrypt_aes(plaintext, key):
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(key), modes.CFB(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(plaintext.encode()) + encryptor.finalize()
    return iv + ciphertext

def decrypt_aes(ciphertext, key):
    iv = ciphertext[:16]
    cipher = Cipher(algorithms.AES(key), modes.CFB(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    plaintext = decryptor.update(ciphertext[16:]) + decryptor.finalize()
    return plaintext.decode()

# Usage
key = os.urandom(32)  # 256-bit key
plaintext = "Sensitive data"
encrypted = encrypt_aes(plaintext, key)
decrypted = decrypt_aes(encrypted, key)

print("Original:", plaintext)
print("Encrypted:", encrypted)
print("Decrypted:", decrypted)
```

### Hashing

Hashing is used to create a fixed-size output from input data of any size. It's commonly used for storing passwords or verifying data integrity. Unlike encryption, hashing is a one-way process – you can't retrieve the original data from the hash.

Example using bcrypt for password hashing:

```python
import bcrypt

def hash_password(password):
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode(), salt)
    return hashed

def verify_password(password, hashed):
    return bcrypt.checkpw(password.encode(), hashed)

# Usage
password = "mysecretpassword"
hashed_password = hash_password(password)

print("Original password:", password)
print("Hashed password:", hashed_password)
print("Verification (correct password):", verify_password(password, hashed_password))
print("Verification (wrong password):", verify_password("wrongpassword", hashed_password))
```

Always use well-established cryptographic libraries and keep them updated to ensure you're using secure and up-to-date algorithms.

## 6. Compliance with Security Standards (e.g., GDPR, CCPA)

When using AI services like OpenAI, it's crucial to ensure your application complies with relevant data protection and privacy regulations. Two major regulations to consider are the General Data Protection Regulation (GDPR) in the European Union and the California Consumer Privacy Act (CCPA) in the United States.

### Key Compliance Considerations

1. **Data Minimization**: Only collect and process the data you absolutely need.

2. **User Consent**: Obtain and maintain clear records of user consent for data processing.

3. **Data Subject Rights**: Implement mechanisms for users to exercise their rights (e.g., right to access, right to be forgotten).

4. **Data Protection Impact Assessments (DPIA)**: Conduct DPIAs for high-risk processing activities.

5. **Privacy by Design**: Implement data protection measures from the outset of your project.

6. **Data Breach Notification**: Have a plan in place to detect and report data breaches.

### Example: Implementing User Consent

Here's a simple example of how you might implement user consent in a Python web application using Flask:

```python
from flask import Flask, request, jsonify
from openai import OpenAI
import uuid

app = Flask(__name__)
client = OpenAI()

# In a real application, you'd use a database to store user consents
user_consents = {}

@app.route('/give-consent', methods=['POST'])
def give_consent():
    user_id = str(uuid.uuid4())
    user_consents[user_id] = True
    return jsonify({"user_id": user_id, "message": "Consent recorded"})

@app.route('/revoke-consent', methods=['POST'])
def revoke_consent():
    user_id = request.json.get('user_id')
    if user_id in user_consents:
        del user_consents[user_id]
        return jsonify({"message": "Consent revoked"})
    return jsonify({"message": "User not found"}), 404

@app.route('/process-data', methods=['POST'])
def process_data():
    user_id = request.json.get('user_id')
    data = request.json.get('data')
    
    if user_id not in user_consents:
        return jsonify({"message": "User consent not found"}), 403
    
    # Process data with OpenAI API
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": data}]
    )
    
    return jsonify({"result": response.choices[0].message.content})

if __name__ == '__main__':
    app.run(debug=True)
```

This example demonstrates basic consent management. In a real-world application, you would need to implement more comprehensive consent management, including storing consent records securely, providing detailed information about data processing, and implementing mechanisms for users to view and modify their consent settings.

### Compliance Checklist

Here's a basic checklist to help ensure compliance:

1. **Privacy Policy**: Develop a clear and comprehensive privacy policy.
2. **Data Inventory**: Maintain an inventory of all personal data you collect and process.
3. **Data Inventory**: Maintain an inventory of all personal data you collect and process. This inventory should include:
   - Types of personal data collected
   - Purpose of collection
   - Where the data is stored
   - How long the data is retained
   - Who has access to the data

4. **Data Protection Officer**: If required by GDPR, appoint a Data Protection Officer (DPO) to oversee data protection strategy and implementation.

5. **Third-Party Risk Management**: Assess the data protection practices of any third-party services you use, including OpenAI. Ensure they comply with relevant regulations.

6. **Regular Audits**: Conduct regular security audits and update your practices as needed. This includes:
   - Reviewing access controls
   - Checking for vulnerabilities in your systems
   - Ensuring all software and libraries are up-to-date
   - Testing your incident response procedures

7. **Employee Training**: Regularly train your employees on data protection and security best practices. This should cover:
   - Identifying and handling sensitive data
   - Recognizing and reporting security threats
   - Understanding relevant data protection regulations

8. **Documentation**: Maintain detailed documentation of your data protection measures and processes. This is crucial for demonstrating compliance in case of an audit.

## Conclusion

Security is a critical aspect of working with the OpenAI API and developing AI applications. By implementing these best practices, you can protect sensitive data, maintain user trust, and comply with relevant regulations.

Remember that security is an ongoing process. Stay informed about the latest security threats and best practices, and regularly review and update your security measures. As AI technology evolves, new security considerations may emerge, so it's important to stay vigilant and adaptable.

In the next lesson, we'll explore documentation and contribution, focusing on how to effectively document your OpenAI-powered applications and contribute to the OpenAI Python library ecosystem.

