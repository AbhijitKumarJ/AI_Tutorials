# Lesson 11: Advanced Features and Customization in the OpenAI Python Library

## Introduction

In this lesson, we'll explore advanced features and customization options available in the OpenAI Python Library. We'll cover function calling, response parsing, content extraction, customizing request options, extending the library with custom functionality, and integrating with other libraries and frameworks. These advanced techniques will allow you to leverage the full power of the OpenAI API and tailor it to your specific needs.

## 1. Function Calling and Tool Usage

Function calling is an advanced feature that allows the model to call predefined functions or tools as part of its response generation process. This can be particularly useful for tasks that require specific actions or data retrieval.

### Purpose
Function calling enables the model to interact with external tools or perform specific actions based on the conversation context. This feature bridges the gap between language models and external systems or databases.

### Implementation
To use function calling, you need to define the functions or tools that the model can use, and then include them in your API request.

### Example

```python
from openai import OpenAI
import json

client = OpenAI()

# Define a function that the model can call
def get_current_weather(location, unit="celsius"):
    """Get the current weather in a given location"""
    # In a real scenario, you would call a weather API here
    weather_info = {
        "location": location,
        "temperature": "22",
        "unit": unit,
        "forecast": ["sunny", "windy"],
    }
    return json.dumps(weather_info)

# Define the function for the model
functions = [
    {
        "name": "get_current_weather",
        "description": "Get the current weather in a given location",
        "parameters": {
            "type": "object",
            "properties": {
                "location": {
                    "type": "string",
                    "description": "The city and state, e.g. San Francisco, CA",
                },
                "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]},
            },
            "required": ["location"],
        },
    }
]

# Make a request to the API with function calling
response = client.chat.completions.create(
    model="gpt-3.5-turbo-0613",
    messages=[
        {"role": "user", "content": "What's the weather like in Boston?"}
    ],
    functions=functions,
    function_call="auto",
)

# Check if the model wants to call a function
message = response.choices[0].message
if message.function_call:
    function_name = message.function_call.name
    function_args = json.loads(message.function_call.arguments)
    
    # Call the function
    function_response = get_current_weather(
        location=function_args.get("location"),
        unit=function_args.get("unit", "celsius")
    )
    
    # Send the function result back to the model
    second_response = client.chat.completions.create(
        model="gpt-3.5-turbo-0613",
        messages=[
            {"role": "user", "content": "What's the weather like in Boston?"},
            message,
            {
                "role": "function",
                "name": function_name,
                "content": function_response,
            }
        ]
    )
    print(second_response.choices[0].message.content)
else:
    print(message.content)
```

### Key Points
- Function definitions include a name, description, and parameter schema.
- The `function_call` parameter in the API request can be set to "auto" to let the model decide when to call functions, or you can specify a particular function to always be called.
- When the model decides to call a function, you need to execute the function and send the result back to the model in a follow-up request.
- This feature allows for more interactive and dynamic conversations, where the model can retrieve or manipulate external data as needed.

## 2. Response Parsing and Content Extraction

Extracting and parsing the content from API responses is crucial for integrating OpenAI's capabilities into your applications effectively.

### Purpose
Response parsing allows you to extract relevant information from the API's responses and transform it into a format that's easy to work with in your application.

### Implementation
The OpenAI Python Library provides several ways to access and parse response data. Additionally, you can create custom parsers for more complex scenarios.

### Example

```python
from openai import OpenAI
from pydantic import BaseModel, Field
from typing import List

client = OpenAI()

# Define a Pydantic model for structured output
class MovieReview(BaseModel):
    title: str = Field(..., description="The title of the movie")
    rating: int = Field(..., ge=1, le=10, description="Rating out of 10")
    summary: str = Field(..., max_length=100, description="Brief summary of the review")
    pros: List[str] = Field(..., max_items=3, description="Up to 3 pros of the movie")
    cons: List[str] = Field(..., max_items=3, description="Up to 3 cons of the movie")

# Function to parse the response into our custom model
def parse_movie_review(response_content: str) -> MovieReview:
    try:
        # Attempt to parse the response directly
        return MovieReview.parse_raw(response_content)
    except:
        # If direct parsing fails, you might need more sophisticated parsing here
        # For simplicity, we'll just raise an error
        raise ValueError("Failed to parse the response into a MovieReview object")

# Make a request to the API
response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are a movie critic. Provide a review in JSON format."},
        {"role": "user", "content": "Review the movie 'Inception'"}
    ],
    response_format={"type": "json_object"}
)

# Extract and parse the content
content = response.choices[0].message.content
review = parse_movie_review(content)

print(f"Movie: {review.title}")
print(f"Rating: {review.rating}/10")
print(f"Summary: {review.summary}")
print("Pros:", ", ".join(review.pros))
print("Cons:", ", ".join(review.cons))
```

### Key Points
- Using a library like Pydantic for defining response models can greatly simplify parsing and validation.
- The `response_format` parameter in the API request can be used to specify that you want a JSON response, making parsing easier.
- Custom parsing functions allow you to handle complex or nested response structures.
- Error handling is important when parsing responses, as the model's output may not always perfectly match your expected format.

## 3. Customizing Request Options and Headers

The OpenAI Python Library allows for extensive customization of API requests, including setting custom headers and query parameters.

### Purpose
Customizing request options allows you to fine-tune your API interactions, implement advanced features like request tracking, and adjust how the library handles timeouts and retries.

### Implementation
You can customize requests by passing additional parameters when creating the client or making individual API calls.

### Example

```python
from openai import OpenAI
from openai._client import HttpxClientWrapper
import httpx

# Custom timeout and header
custom_headers = {"X-My-Header": "CustomValue"}

# Create a custom transport with a retry strategy
class CustomRetryTransport(httpx.HTTPTransport):
    def __init__(self, max_retries=3):
        super().__init__()
        self.max_retries = max_retries

    def handle_request(self, request):
        for retry in range(self.max_retries):
            try:
                return super().handle_request(request)
            except httpx.TransportError as e:
                if retry == self.max_retries - 1:
                    raise
                print(f"Request failed, retrying ({retry + 1}/{self.max_retries})...")

# Create a custom HttpxClientWrapper
custom_client_wrapper = HttpxClientWrapper(
    base_url="https://api.openai.com",
    max_retries=3,
    timeout=60.0,
    default_headers=custom_headers,
    transport=CustomRetryTransport(max_retries=5),
)

# Create the OpenAI client with the custom wrapper
client = OpenAI(
    api_key="your-api-key",
    http_client=custom_client_wrapper,
)

# Make a request with additional custom options
response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "user", "content": "Hello, how are you?"}
    ],
    extra_headers={"X-Request-ID": "unique-request-id"},
    timeout=30.0  # Override timeout for this specific request
)

print(response.choices[0].message.content)
```

### Key Points
- Custom headers can be set globally when creating the client or for individual requests.
- You can create a custom `HttpxClientWrapper` to have fine-grained control over the HTTP client used by the library.
- Implementing a custom retry strategy allows you to handle transient errors more gracefully.
- Timeouts can be set globally or per-request to manage long-running operations.

## 4. Extending the Library with Custom Functionality

While the OpenAI Python Library provides a comprehensive set of features, you may sometimes need to extend its functionality to meet specific requirements.

### Purpose
Extending the library allows you to add custom behaviors, implement additional error handling, or integrate OpenAI's capabilities more seamlessly into your application's architecture.

### Implementation
You can extend the library by subclassing existing classes or creating wrapper classes that add new functionality.

### Example

```python
from openai import OpenAI
from openai.resources.chat import Completions
import time

class CustomCompletions(Completions):
    def create(self, *args, **kwargs):
        # Add retry logic with exponential backoff
        max_retries = 5
        for attempt in range(max_retries):
            try:
                return super().create(*args, **kwargs)
            except Exception as e:
                if attempt == max_retries - 1:
                    raise
                wait_time = 2 ** attempt
                print(f"Request failed, retrying in {wait_time} seconds...")
                time.sleep(wait_time)

class CustomOpenAI(OpenAI):
    @property
    def chat(self):
        return CustomChatCompletions(self)

class CustomChatCompletions:
    def __init__(self, client):
        self.completions = CustomCompletions(client)

    def create(self, *args, **kwargs):
        # Add logging
        print(f"Making chat completion request with args: {args}, kwargs: {kwargs}")
        start_time = time.time()
        result = self.completions.create(*args, **kwargs)
        end_time = time.time()
        print(f"Request completed in {end_time - start_time:.2f} seconds")
        return result

# Use the custom client
client = CustomOpenAI()

response = client.chat.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "user", "content": "What's the meaning of life?"}
    ]
)

print(response.choices[0].message.content)
```

### Key Points
- Subclassing allows you to override specific methods to add custom behavior while retaining the rest of the library's functionality.
- Custom wrapper classes can add cross-cutting concerns like logging or performance monitoring.
- When extending the library, it's important to maintain compatibility with the original API to ensure that your custom implementation can be used interchangeably with the standard library.

## 5. Integrating with Other Libraries and Frameworks

The OpenAI Python Library can be integrated with various other libraries and frameworks to create more powerful and feature-rich applications.

### Purpose
Integration with other libraries and frameworks allows you to leverage OpenAI's capabilities within larger ecosystems, combining AI-powered features with other functionalities.

### Implementation
Integration typically involves creating wrapper classes or utility functions that bridge the OpenAI library with other libraries or frameworks.

### Example: Integration with FastAPI

```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from openai import OpenAI
import asyncio

app = FastAPI()
client = OpenAI()

class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    response: str

@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    try:
        # Use asyncio to run the OpenAI request in a separate thread
        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None,
            lambda: client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "user", "content": request.message}
                ]
            )
        )
        return ChatResponse(response=response.choices[0].message.content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

### Key Points
- When integrating with asynchronous frameworks like FastAPI, you may need to use `asyncio` to run synchronous OpenAI API calls in a non-blocking manner.
- Using Pydantic models for request and response validation helps ensure data consistency between your API and the OpenAI library.
- Error handling is crucial when integrating libraries, as you'll need to translate OpenAI-specific exceptions into appropriate responses for your application's API.
- Consider rate limiting and caching strategies when exposing OpenAI capabilities through your own API to manage costs and improve performance.

## Conclusion

In this lesson, we've explored advanced features and customization options available in the OpenAI Python Library. We've covered function calling for interactive tool usage, response parsing for structured data extraction, request customization for fine-grained control over API interactions, library extension for adding custom behaviors, and integration with other frameworks for building comprehensive applications.

These advanced techniques allow you to fully leverage the power of the OpenAI API while tailoring it to your specific needs. As you implement these features in your projects, remember to always refer to the most recent OpenAI documentation, as the API and library are continually evolving.

In the next lesson, we'll dive into testing and debugging strategies specifically tailored for applications using the OpenAI Python Library, ensuring that your AI-powered features are robust and reliable.
