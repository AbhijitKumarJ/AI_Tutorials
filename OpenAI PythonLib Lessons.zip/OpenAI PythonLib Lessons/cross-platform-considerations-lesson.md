# Lesson 14: Cross-Platform Considerations

## Introduction

In today's diverse computing landscape, it's crucial to develop applications that can run seamlessly across different operating systems and environments. This lesson focuses on cross-platform considerations when using the OpenAI Python Library, ensuring that your code works consistently on various platforms such as Windows, macOS, and Linux. We'll cover file path handling, environment variables, encoding issues, platform-specific optimizations, containerization, and cross-platform testing.

## 1. Handling File Paths Across Different Operating Systems

One of the most common issues in cross-platform development is dealing with file paths. Different operating systems use different conventions for representing file paths, which can lead to errors if not handled properly.

### Understanding Path Differences

- Windows uses backslashes (`\`) as path separators.
- Unix-based systems (macOS, Linux) use forward slashes (`/`).
- Windows uses drive letters (e.g., `C:\`), while Unix-based systems use a single root directory (`/`).

### Using `os.path` for Cross-Platform Compatibility

Python's `os.path` module provides functions for working with file paths in a platform-independent manner. Here's an example:

```python
import os

# Constructing a path
data_dir = "data"
file_name = "example.txt"
file_path = os.path.join(data_dir, file_name)

print(f"Constructed path: {file_path}")

# Getting the absolute path
abs_path = os.path.abspath(file_path)
print(f"Absolute path: {abs_path}")

# Splitting a path
dir_path, file_name = os.path.split(abs_path)
print(f"Directory: {dir_path}")
print(f"File name: {file_name}")
```

This code will work correctly on any operating system, automatically using the appropriate path separators.

### Using `pathlib` for Modern Path Handling

For more advanced path operations, the `pathlib` module (introduced in Python 3.4) provides an object-oriented interface for working with file paths:

```python
from pathlib import Path

# Constructing a path
data_dir = Path("data")
file_path = data_dir / "example.txt"

print(f"Constructed path: {file_path}")

# Getting the absolute path
abs_path = file_path.resolve()
print(f"Absolute path: {abs_path}")

# Accessing path components
print(f"Parent directory: {file_path.parent}")
print(f"File name: {file_path.name}")
print(f"File stem: {file_path.stem}")
print(f"File suffix: {file_path.suffix}")
```

`pathlib` automatically handles the differences between operating systems, making it an excellent choice for cross-platform development.

## 2. Managing Environment Variables on Various Platforms

Environment variables are often used to store configuration details and sensitive information like API keys. However, setting and accessing environment variables can differ across platforms.

### Setting Environment Variables

- On Unix-based systems (macOS, Linux), you typically set environment variables in the shell:
  ```
  export OPENAI_API_KEY="your-api-key"
  ```
- On Windows, you use the `set` command:
  ```
  set OPENAI_API_KEY=your-api-key
  ```

### Accessing Environment Variables in Python

Python's `os.environ` dictionary provides a cross-platform way to access environment variables:

```python
import os
from openai import OpenAI

# Accessing an environment variable
api_key = os.environ.get("OPENAI_API_KEY")

if api_key is None:
    raise ValueError("OPENAI_API_KEY environment variable is not set")

client = OpenAI(api_key=api_key)

# Use the client as usual
response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[{"role": "user", "content": "Hello, world!"}]
)
print(response.choices[0].message.content)
```

### Using `.env` Files for Local Development

For local development, it's common to use `.env` files to store environment variables. The `python-dotenv` library makes it easy to load these variables:

```python
from dotenv import load_dotenv
import os
from openai import OpenAI

# Load environment variables from .env file
load_dotenv()

# Access the API key
api_key = os.getenv("OPENAI_API_KEY")

if api_key is None:
    raise ValueError("OPENAI_API_KEY not found in .env file")

client = OpenAI(api_key=api_key)

# Use the client as usual
```

Remember to add `.env` to your `.gitignore` file to prevent sensitive information from being committed to version control.

## 3. Dealing with Encoding Issues (UTF-8, ASCII, etc.)

Encoding issues can cause unexpected behavior, especially when working with text in different languages or special characters. It's important to handle encodings consistently across platforms.

### Understanding Encoding Basics

- UTF-8 is a widely used encoding that can represent any Unicode character.
- ASCII is a 7-bit encoding that can only represent basic Latin characters.
- Different operating systems may use different default encodings.

### Handling Text Encoding in Python

Python 3 uses UTF-8 as its default encoding for source code and string literals. However, when working with files or external data, you may need to specify the encoding explicitly:

```python
# Writing to a file with explicit encoding
with open("output.txt", "w", encoding="utf-8") as f:
    f.write("Hello, 世界!")

# Reading from a file with explicit encoding
with open("output.txt", "r", encoding="utf-8") as f:
    content = f.read()
    print(content)

# Handling JSON with non-ASCII characters
import json

data = {"greeting": "Hello, 世界!"}
json_str = json.dumps(data, ensure_ascii=False)
print(json_str)

# When working with the OpenAI API, ensure proper encoding
from openai import OpenAI

client = OpenAI()

response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[{"role": "user", "content": "Translate 'Hello' to Japanese"}]
)
japanese_text = response.choices[0].message.content
print(japanese_text)  # This should correctly display Japanese characters
```

Always specify the encoding when opening files to ensure consistent behavior across platforms.

## 4. Platform-Specific Optimizations and Considerations

While the OpenAI Python Library itself is cross-platform, your application may benefit from platform-specific optimizations or need to handle platform-specific features.

### Windows-Specific Considerations

- Use the `wincertstore` module to handle SSL certificate verification on Windows.
- Be aware of path length limitations (260 characters by default) and use long path support when necessary.

### Unix-Specific Considerations

- Take advantage of Unix-specific features like file permissions and symbolic links when appropriate.
- Use the `fcntl` module for file locking on Unix systems.

### Example: Platform-Specific File Locking

```python
import os
import sys

def lock_file(file_path):
    if sys.platform.startswith('win'):
        # Windows file locking
        import msvcrt
        file_handle = open(file_path, 'r')
        msvcrt.locking(file_handle.fileno(), msvcrt.LK_LOCK, 1)
        return file_handle
    else:
        # Unix file locking
        import fcntl
        file_handle = open(file_path, 'r')
        fcntl.flock(file_handle, fcntl.LOCK_EX)
        return file_handle

# Usage
try:
    file_handle = lock_file("example.txt")
    # Perform operations on the locked file
finally:
    file_handle.close()
```

## 5. Containerization and Cross-Platform Deployment

Containerization, particularly using Docker, is an excellent way to ensure consistent behavior across different environments and platforms.

### Benefits of Containerization

- Consistent environment across development, testing, and production.
- Easier deployment and scaling.
- Isolation of application dependencies.

### Creating a Dockerfile for an OpenAI Application

Here's an example Dockerfile for a Python application using the OpenAI library:

```dockerfile
# Use an official Python runtime as the base image
FROM python:3.9-slim

# Set the working directory in the container
WORKDIR /app

# Copy the current directory contents into the container
COPY . /app

# Install the required packages
RUN pip install --no-cache-dir -r requirements.txt

# Set environment variables
ENV OPENAI_API_KEY=${OPENAI_API_KEY}

# Run the application
CMD ["python", "app.py"]
```

To build and run the Docker container:

```bash
docker build -t myopenaiapp .
docker run -e OPENAI_API_KEY=your-api-key myopenaiapp
```

This approach ensures that your application runs in a consistent environment regardless of the host operating system.

## 6. Testing on Multiple Operating Systems

To ensure cross-platform compatibility, it's crucial to test your application on different operating systems.

### Strategies for Cross-Platform Testing

1. **Virtual Machines**: Use virtual machines to test on different operating systems.
2. **Continuous Integration (CI) Services**: Use CI services that offer multiple OS environments, such as GitHub Actions or Travis CI.
3. **Docker**: Use Docker to simulate different environments.
4. **Cloud Testing Services**: Use services like BrowserStack or Sauce Labs for testing on various OS configurations.

### Example: GitHub Actions Workflow for Cross-Platform Testing

Here's an example GitHub Actions workflow that tests a Python application on multiple operating systems:

```yaml
name: Cross-Platform Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        os: [ubuntu-latest, windows-latest, macos-latest]
        python-version: [3.7, 3.8, 3.9]

    steps:
    - uses: actions/checkout@v2
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v2
      with:
        python-version: ${{ matrix.python-version }}
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Run tests
      run: python -m unittest discover tests
      env:
        OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
```

This workflow will run your tests on Ubuntu, Windows, and macOS, using different Python versions, helping ensure cross-platform compatibility.

## Conclusion

Developing cross-platform applications with the OpenAI Python Library requires careful consideration of various factors, from file path handling and environment variables to encoding issues and platform-specific optimizations. By following the practices outlined in this lesson, you can create robust applications that work consistently across different operating systems and environments.

Remember to:
- Use platform-independent modules like `os.path` or `pathlib` for file operations.
- Handle environment variables carefully and consider using `.env` files for local development.
- Be mindful of encoding issues, especially when working with international text.
- Leverage containerization for consistent deployment across platforms.
- Implement thorough cross-platform testing to catch and resolve platform-specific issues early.

By keeping these considerations in mind, you'll be well-equipped to develop OpenAI-powered applications that can run smoothly on any platform, providing a consistent experience for all users regardless of their operating system.

