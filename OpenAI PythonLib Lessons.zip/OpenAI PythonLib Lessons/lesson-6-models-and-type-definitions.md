# Lesson 6: Models and Type Definitions in the OpenAI Python Library

## Introduction

In this lesson, we'll delve into the world of models and type definitions within the OpenAI Python Library. Understanding these concepts is crucial for working effectively with the library, ensuring type safety, and leveraging the full power of Python's type system. We'll explore how the library uses Pydantic for data validation and serialization, examine custom types, and learn about the extensive type definitions that make the library robust and developer-friendly.

## Pydantic Models and Their Usage in the Library

Pydantic is a data validation and settings management library using Python type annotations. The OpenAI Python Library makes extensive use of Pydantic to define data models, validate incoming data, and serialize data for API requests and responses.

### Why Pydantic?

Pydantic offers several advantages that make it an excellent choice for the OpenAI Python Library:

1. Data Validation: Pydantic automatically validates data based on the type annotations, ensuring that the data conforms to the expected structure.
2. Serialization and Deserialization: It can easily convert between Python objects and JSON, which is crucial for API interactions.
3. IDE Support: Pydantic models provide excellent autocomplete and type checking support in modern IDEs.
4. Clear Data Structures: The models serve as clear, self-documenting data structures.

### Example of a Pydantic Model in the Library

Let's look at an example of how Pydantic is used in the library. Here's a simplified version of the `ChatCompletionMessage` model:

```python
from pydantic import BaseModel, Field
from typing import Literal, Optional

class ChatCompletionMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: Optional[str] = None
    name: Optional[str] = None
    function_call: Optional[dict] = None

    class Config:
        extra = 'forbid'
```

This model defines the structure of a chat message. Let's break it down:

- `role`: This field is constrained to only accept "system", "user", or "assistant" as valid values.
- `content`: An optional string field for the message content.
- `name`: An optional string field for the name of the message sender.
- `function_call`: An optional dictionary for function call data.

The `Config` class with `extra = 'forbid'` ensures that no additional fields can be added to the model, maintaining strict data integrity.

### Using Pydantic Models

These models are used throughout the library for data validation and serialization. For example, when you create a chat completion request:

```python
from openai import OpenAI
client = OpenAI()

response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Hello!"}
    ]
)
```

The library internally uses Pydantic models to validate the input data and parse the response. This ensures that the data you're sending to the API is correctly formatted and that the response you receive is properly structured and typed.

## Type Aliases and Custom Types

The OpenAI Python Library makes extensive use of type aliases and custom types to improve code readability and provide more specific type hints. These are defined in various files within the `types` directory of the library.

### Type Aliases

Type aliases are created using the `typing.TypeAlias` feature introduced in Python 3.10. For earlier versions, the library uses `typing_extensions.TypeAlias`. Here's an example of how type aliases are used in the library:

```python
from typing_extensions import TypeAlias

FileTypes: TypeAlias = "bytes | IO[bytes] | str | PathLike[str]"
```

This type alias, `FileTypes`, represents the various types that can be used to specify a file in the library's functions. It allows for flexibility in how users can provide file data while still maintaining type safety.

### Custom Types

The library also defines custom types to represent complex data structures or to provide more specific type information. For example, the `GPTModel` type:

```python
class GPTModel(str):
    gpt_35_turbo: str = "gpt-3.5-turbo"
    gpt_35_turbo_16k: str = "gpt-3.5-turbo-16k"
    gpt_4: str = "gpt-4"
    gpt_4_32k: str = "gpt-4-32k"
```

This custom type extends the `str` class and provides specific constants for different GPT models. It allows for both type checking and easy access to model names.

## Exploring the Types Directory

The `types` directory in the OpenAI Python Library contains a wealth of type definitions that form the backbone of the library's type system. Let's take a closer look at its structure and contents:

```
openai/types/
├── __init__.py
├── audio/
│   ├── __init__.py
│   ├── translation.py
│   ├── transcription.py
│   └── ...
├── chat/
│   ├── __init__.py
│   ├── chat_completion.py
│   ├── chat_completion_chunk.py
│   └── ...
├── images/
│   ├── __init__.py
│   ├── image.py
│   └── ...
└── shared.py
```

Each subdirectory (`audio`, `chat`, `images`, etc.) contains type definitions specific to that area of functionality. The `shared.py` file contains types that are used across multiple areas of the library.

Let's examine a few key files:

### chat/chat_completion.py

This file defines the types related to chat completions. Here's a simplified excerpt:

```python
from typing import List, Optional
from pydantic import BaseModel, Field

class ChatCompletionMessage(BaseModel):
    role: str
    content: Optional[str] = None
    name: Optional[str] = None
    function_call: Optional[dict] = None

class ChatCompletion(BaseModel):
    id: str
    object: str
    created: int
    model: str
    choices: List[ChatCompletionMessage]
    usage: dict
```

These models define the structure of chat completion requests and responses, ensuring that data is correctly typed and validated.

### images/image.py

This file contains types related to image generation and manipulation:

```python
from typing import List, Union
from pydantic import BaseModel

class Image(BaseModel):
    url: str
    b64_json: Union[str, None]

class ImageResponse(BaseModel):
    created: int
    data: List[Image]
```

These models represent the structure of image data and responses from image-related API calls.

## Understanding Generic Types and Their Application

Generic types are a powerful feature in Python's type system, allowing you to write flexible, reusable code while maintaining type safety. The OpenAI Python Library makes extensive use of generics, particularly in its streaming and parsing functionality.

### Example: ParsedChatCompletion

Let's look at how generics are used in the `ParsedChatCompletion` type:

```python
from typing import Generic, TypeVar

ResponseFormatT = TypeVar("ResponseFormatT")

class ParsedChatCompletion(Generic[ResponseFormatT]):
    # ... other fields ...
    choices: List[ParsedChoice[ResponseFormatT]]
```

In this example, `ResponseFormatT` is a type variable that can be replaced with a specific type when the `ParsedChatCompletion` class is used. This allows for flexibility in how the parsed content is represented while still maintaining type safety.

### Usage of Generic Types

Generic types are particularly useful when dealing with different response formats or when parsing content into specific structures. For example:

```python
from typing import Dict, Any

# Parsing into a dictionary
result: ParsedChatCompletion[Dict[str, Any]] = parse_chat_completion(response)

# Parsing into a custom class
class MyCustomFormat:
    # ... custom format definition ...

result: ParsedChatCompletion[MyCustomFormat] = parse_chat_completion(response, MyCustomFormat)
```

By using generics, the library can provide type-safe parsing for various response formats without needing separate functions for each type.

## Creating and Using Custom Models

While the OpenAI Python Library provides a comprehensive set of models, you may sometimes need to create custom models for your specific use case. Here's how you can create and use custom models that integrate well with the library:

### Creating a Custom Model

Let's create a custom model for a specialized chat message:

```python
from pydantic import BaseModel, Field
from typing import Optional

class CustomChatMessage(BaseModel):
    role: str
    content: str
    sentiment: Optional[str] = Field(None, description="The sentiment of the message")
    importance: int = Field(1, ge=1, le=5, description="Importance rating from 1 to 5")

    class Config:
        extra = 'forbid'
```

This custom model extends the basic chat message with additional fields for sentiment and importance.

### Using Custom Models with the Library

You can use your custom models in conjunction with the library's functions. For example:

```python
from openai import OpenAI
client = OpenAI()

custom_message = CustomChatMessage(
    role="user",
    content="Hello, how are you?",
    sentiment="neutral",
    importance=3
)

response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[custom_message.dict(exclude_unset=True)]
)
```

By using `custom_message.dict(exclude_unset=True)`, we convert our custom model to a dictionary that the library can use, excluding any unset optional fields.

## Type Checking and Validation

Type checking and validation are crucial for ensuring the correctness and reliability of your code when working with the OpenAI Python Library. The library leverages Python's type hinting system and Pydantic's validation capabilities to provide robust type checking and data validation.

### Static Type Checking

You can use static type checkers like mypy or Pyright to catch type-related errors before runtime. For example, if you run mypy on a file using the OpenAI library:

```python
from openai import OpenAI
client = OpenAI()

response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "user", "content": "Hello!"}
    ],
    temperature: 0.7  # This should be a float, not a string
)
```

A type checker would catch the error in the `temperature` parameter, which should be a float, not a string.

### Runtime Validation

Pydantic models in the library provide runtime validation. When you create an instance of a model or when the library parses API responses into model instances, Pydantic performs validation:

```python
from openai.types.chat import ChatCompletionMessage

try:
    message = ChatCompletionMessage(
        role="invalid_role",  # This should be "user", "system", or "assistant"
        content="Hello!"
    )
except ValueError as e:
    print(f"Validation error: {e}")
```

This code would raise a `ValueError` at runtime because "invalid_role" is not a valid value for the `role` field.

### Custom Validation

You can also add custom validation to your models using Pydantic's validators:

```python
from pydantic import BaseModel, validator

class CustomCompletionRequest(BaseModel):
    model: str
    messages: List[dict]
    max_tokens: int

    @validator('max_tokens')
    def check_max_tokens(cls, v):
        if v > 4096:
            raise ValueError("max_tokens cannot exceed 4096")
        return v
```

This custom model adds a validator to ensure that `max_tokens` doesn't exceed the maximum allowed value.

## Conclusion

Understanding models and type definitions in the OpenAI Python Library is crucial for writing type-safe, robust code when working with the OpenAI API. By leveraging Pydantic models, custom types, and Python's type hinting system, you can catch errors early, improve code readability, and ensure that your data structures align with the API's requirements.

The extensive use of type definitions in the library not only provides better IDE support and documentation but also serves as a guide for how to structure your own code when working with the API. As you continue to work with the library, you'll find that these strong type definitions make your code more maintainable and less prone to runtime errors.

In the next lesson, we'll explore streaming and asynchronous operations, building on the type system knowledge you've gained here to understand how the library handles real-time data and concurrent operations.

