# Lesson 4: Working with API Requests and Responses

## 1. HTTP Basics (GET, POST, headers, status codes)

Before diving into the specifics of how the OpenAI Python Library handles API requests and responses, it's crucial to understand the basics of HTTP communication. HTTP (Hypertext Transfer Protocol) is the foundation of data communication on the web, and it's what the OpenAI API uses for its interactions.

### HTTP Methods

The most common HTTP methods used in API interactions are:

1. **GET**: Used to retrieve data from the server. It should not modify any data on the server.
   
2. **POST**: Used to submit data to be processed by the server. It often results in the creation of a new resource or the triggering of a specific action.

3. **PUT**: Used to update an existing resource on the server.

4. **DELETE**: Used to request the removal of a resource from the server.

The OpenAI API primarily uses GET for retrieving data (like listing models) and POST for actions that generate new data (like creating completions or embeddings).

### Headers

HTTP headers provide additional information about the request or the response. Some important headers in API communication include:

- **Authorization**: Used to send credentials, like API keys.
- **Content-Type**: Specifies the media type of the body of the request or response.
- **Accept**: Indicates which content types the client can understand in the response.

For example, when making a request to the OpenAI API, you might see headers like this:

```python
headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json",
    "Accept": "application/json"
}
```

### Status Codes

HTTP status codes indicate the result of the request. They are grouped into five classes:

1. **1xx (Informational)**: The request was received, continuing process.
2. **2xx (Successful)**: The request was successfully received, understood, and accepted.
   - 200 OK: Standard success response
   - 201 Created: Resource was successfully created
3. **3xx (Redirection)**: Further action needs to be taken to complete the request.
4. **4xx (Client Error)**: The request contains bad syntax or cannot be fulfilled.
   - 400 Bad Request: The server couldn't understand the request
   - 401 Unauthorized: Authentication is required and has failed
   - 403 Forbidden: The server understood the request but refuses to authorize it
   - 404 Not Found: The requested resource could not be found
5. **5xx (Server Error)**: The server failed to fulfill a valid request.
   - 500 Internal Server Error: A generic error message when an unexpected condition was encountered

Understanding these status codes is crucial for proper error handling when working with APIs.

## 2. The _base_client.py Module and Its Role in Making API Calls

The `_base_client.py` module in the OpenAI Python Library is a fundamental component that handles the low-level details of making API requests. It provides a foundation for all API interactions and is typically subclassed by more specific client classes.

Let's explore a simplified version of what this module might contain:

```python
# openai/_base_client.py

import requests
from typing import Any, Dict, Optional

class BaseClient:
    def __init__(self, api_key: str, base_url: str = "https://api.openai.com/v1"):
        self.api_key = api_key
        self.base_url = base_url

    def request(
        self, 
        method: str, 
        path: str, 
        params: Optional[Dict[str, Any]] = None, 
        data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

        response = requests.request(
            method=method,
            url=url,
            headers=headers,
            params=params,
            json=data
        )

        response.raise_for_status()  # Raises an HTTPError for bad responses

        return response.json()

    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self.request("GET", path, params=params)

    def post(self, path: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self.request("POST", path, data=data)

    # Additional methods for other HTTP verbs could be added here
```

This `BaseClient` class provides several key functionalities:

1. **API Key Management**: It securely stores the API key provided during initialization.

2. **Request Method**: The `request` method is a generic method for making HTTP requests. It handles setting up the headers, constructing the full URL, and making the actual HTTP request using the `requests` library.

3. **Response Handling**: It automatically raises an exception for non-200 status codes using `raise_for_status()` and parses the JSON response.

4. **Convenience Methods**: It provides convenience methods like `get` and `post` that wrap the more generic `request` method, making it easier to make specific types of requests.

This base client can then be extended by more specific client classes to add additional functionality or customize behavior for particular API endpoints.

## 3. Request Preparation and Parameter Handling

When working with the OpenAI API, different endpoints require different parameters. The library needs to handle these parameters correctly, validate them, and prepare them for the API request. Let's look at how this might be implemented:

```python
# openai/_client.py

from typing import List, Dict, Any, Optional
from openai._base_client import BaseClient

class ChatCompletions:
    def __init__(self, client: BaseClient):
        self._client = client

    def create(
        self, 
        messages: List[Dict[str, str]],
        model: str = "gpt-3.5-turbo",
        temperature: float = 1.0,
        max_tokens: Optional[int] = None,
        **kwargs: Any
    ) -> Dict[str, Any]:
        data = {
            "messages": messages,
            "model": model,
            "temperature": temperature,
            **kwargs
        }
        if max_tokens is not None:
            data["max_tokens"] = max_tokens

        return self._client.post("/chat/completions", data=data)

class OpenAI(BaseClient):
    def __init__(self, api_key: str):
        super().__init__(api_key)
        self.chat = ChatCompletions(self)

# Usage
client = OpenAI("your-api-key")
response = client.chat.create(
    messages=[{"role": "user", "content": "Hello, how are you?"}],
    temperature=0.7
)
```

In this example:

1. **Parameter Validation**: The `create` method of `ChatCompletions` specifies the expected types for each parameter. This provides a level of type checking when the method is called.

2. **Default Values**: Some parameters have default values (like `model` and `temperature`), while others are optional (like `max_tokens`).

3. **Request Preparation**: The method constructs a dictionary (`data`) with all the necessary parameters for the API request.

4. **Flexible Parameters**: The use of `**kwargs` allows for additional parameters to be passed, providing flexibility for future API changes or less common parameters.

5. **Optional Parameters**: The `max_tokens` parameter is only added to the request data if it's provided, demonstrating how to handle optional parameters.

This approach allows for a clean and intuitive API while ensuring that requests are properly formatted for the OpenAI API.

## 4. Response Parsing and Data Extraction

After receiving a response from the API, the library needs to parse it and extract the relevant data. This often involves converting the raw JSON response into Python objects that are easier to work with. Here's an example of how this might be implemented:

```python
# openai/types/chat/completion.py

from typing import List, Dict, Any
from pydantic import BaseModel, Field

class CompletionChoice(BaseModel):
    index: int
    message: Dict[str, str]
    finish_reason: str

class CompletionUsage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int

class ChatCompletion(BaseModel):
    id: str
    object: str
    created: int
    model: str
    choices: List[CompletionChoice]
    usage: CompletionUsage

# openai/_client.py

from openai.types.chat.completion import ChatCompletion

class ChatCompletions:
    # ... (previous code)

    def create(self, *args, **kwargs) -> ChatCompletion:
        response_data = self._client.post("/chat/completions", data=kwargs)
        return ChatCompletion(**response_data)

# Usage
client = OpenAI("your-api-key")
completion = client.chat.create(
    messages=[{"role": "user", "content": "Hello, how are you?"}],
    temperature=0.7
)

print(f"Response: {completion.choices[0].message['content']}")
print(f"Total tokens used: {completion.usage.total_tokens}")
```

In this example:

1. **Data Models**: We define Pydantic models (`CompletionChoice`, `CompletionUsage`, `ChatCompletion`) that match the structure of the API response. Pydantic provides automatic validation and parsing of the JSON data into Python objects.

2. **Response Parsing**: The `create` method now returns a `ChatCompletion` object instead of a raw dictionary. This is done by passing the API response data to the `ChatCompletion` constructor.

3. **Data Extraction**: Users of the library can now easily access specific parts of the response through the attributes of the `ChatCompletion` object and its nested objects.

This approach provides several benefits:

- **Type Safety**: The use of Pydantic models provides runtime type checking and validation.
- **IntelliSense Support**: IDEs can provide better autocompletion and type hinting for the response objects.
- **Easy Access**: Users can access nested data using dot notation instead of dictionary access.

## 5. Handling Streaming Responses

The OpenAI API supports streaming responses for some endpoints, which can be useful for displaying results in real-time. The OpenAI Python Library needs to handle these streaming responses differently from regular responses. Here's an example of how this might be implemented:

```python
# openai/_streaming.py

import json
from typing import Iterator, Dict, Any

class Stream:
    def __init__(self, iterator: Iterator[bytes]):
        self._iterator = iterator

    def __iter__(self):
        return self

    def __next__(self) -> Dict[str, Any]:
        while True:
            try:
                chunk = next(self._iterator)
                if chunk.startswith(b'data: '):
                    chunk = chunk[6:]
                    if chunk.strip() == b'[DONE]':
                        raise StopIteration
                    data = json.loads(chunk)
                    return data
            except StopIteration:
                raise

# openai/_client.py

from openai._streaming import Stream

class ChatCompletions:
    # ... (previous code)

    def create_stream(self, *args, **kwargs) -> Stream:
        kwargs['stream'] = True
        response = self._client.post("/chat/completions", data=kwargs, stream=True)
        return Stream(response.iter_lines())

# Usage
client = OpenAI("your-api-key")
stream = client.chat.create_stream(
    messages=[{"role": "user", "content": "Tell me a long story"}],
    temperature=0.7
)

for chunk in stream:
    if chunk['choices'][0]['finish_reason'] is not None:
        break
    content = chunk['choices'][0]['delta'].get('content', '')
    print(content, end='', flush=True)
```

In this example:

1. **Stream Class**: We define a `Stream` class that wraps the raw response iterator and handles the parsing of server-sent events (SSE) format used by the OpenAI API for streaming.

2. **Streaming Method**: The `create_stream` method is added to `ChatCompletions`. It sets the `stream` parameter to `True` and returns a `Stream` object instead of parsing the entire response at once.

3. **Iteration**: The `Stream` class implements the iterator protocol, allowing users to easily loop over the chunks of the response as they arrive.

4. **Parsing**: Each chunk is parsed from the SSE format and converted to a Python dictionary.

5. **Usage**: In the usage example, we print each piece of content as it arrives, providing a real-time output of the generated text.

This approach to handling streaming responses allows for efficient processing of large amounts of data and enables real-time applications.

## 6. Serialization and Deserialization of Data

Proper serialization and deserialization of data is crucial for ensuring that data is correctly formatted when sent to the API and correctly interpreted when received from the API. The OpenAI Python Library uses Pydantic for much of this work, but let's look at how this process might be implemented more explicitly:

```python
# openai/_serialization.py

import json
from typing import Any, Dict, List, Union

def serialize_message(message: Dict[str, str]) -> Dict[str, str]:
    return {
        "role": message["role"],
        "content": message["content"]
    }

def serialize_messages(messages: List[Dict[str, str]]) -> List[Dict[str, str]]:
    return [serialize_message(message) for message in messages]

def serialize_request(data: Dict[str, Any]) -> str:
    if "messages" in data:
        data["messages"] = serialize_messages(data["messages"])
    return json.dumps(data)

def deserialize_response(response_text: str) -> Dict[str, Any]:
    data = json.loads(response_text)
    # Additional processing could be done here
    return data

# openai/_client.py

from openai._serialization import serialize_request, deserialize_response

class BaseClient:
    # ... (previous code)

    def request(self, method: str, path: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

        if data:
            data = serialize_request(data)

        response = requests.request(method=method, url=url, headers=headers, data=data)
        response.raise_for_status()

        return deserialize_response(response.text)
```

In this example:

1. **Serialization**: The `serialize_request` function handles converting the Python data structures into a JSON string that can be sent to the API. It includes special handling for the `messages` field, which requires a specific format.

2. **Deserialization**: The `deserialize_response` function handles parsing the JSON response from the API back into Python data structures. In this simple example, it just uses `json.loads`, but in a real implementation, it might do additional processing or use Pydantic models for validation.

3. **Integration**: These serialization and deserialization functions are used in the `request` method of the `BaseClient` class, ensuring that all data is properly formatted before being sent to the API and properly parsed when received from the API.

This approach provides several benefits:

- **Consistency**: By centralizing the serialization and deserialization logic, we ensure that data is always formatted consistently.
- **Flexibility**: If the API's data format changes, we only need to update these functions rather than changing code throughout the library.
- **Validation**: We can add validation checks in these functions to catch data formatting issues early.

In conclusion, this lesson has provided a comprehensive overview of how the OpenAI Python Library handles API requests and responses. We've covered HTTP basics, the role of the base client in making API calls, request preparation and parameter handling, response parsing and data extraction, handling streaming responses, and serialization and deserialization of data. 

Understanding these concepts is crucial for effectively using the OpenAI Python Library, troubleshooting issues, and even extending the library's functionality if needed. By breaking down the process of API communication into these components, the library provides a robust and flexible framework for interacting with the OpenAI API.

In the next lesson, we'll explore authentication and configuration in more detail, including how the library manages API keys and handles different authentication methods.