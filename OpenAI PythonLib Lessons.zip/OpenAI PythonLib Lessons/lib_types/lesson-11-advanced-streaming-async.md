# Lesson 11: Streaming and Asynchronous Operations (Part 2)

## Introduction

In this lesson, we'll dive deeper into the advanced aspects of streaming and asynchronous operations in the OpenAI Python library. We'll focus on the `AssistantEventHandler` and `AsyncAssistantEventHandler` classes, explore stream managers and their lifecycle, and discuss implementing custom event handlers for streaming operations. We'll also cover best practices for working with streaming data in real-world scenarios.

## File Layout

Let's start by examining the relevant file structure within the `openai-src-lib` directory:

```
openai-src-lib/
    streaming/
        __init__.py
        _assistants.py
        _deltas.py
        chat/
            __init__.py
            _completions.py
            _events.py
            _types.py
```

We'll be focusing primarily on the `_assistants.py` file in this lesson, which contains the advanced streaming functionality for assistants.

## Key Components of Advanced Streaming Operations

### 1. AssistantEventHandler Class

The `AssistantEventHandler` class is a crucial component for handling streaming events from the OpenAI API, particularly for assistant-based interactions. Let's examine its structure and key methods:

```python
class AssistantEventHandler:
    def __init__(self) -> None:
        # ... initialization code ...

    def _init(self, stream: Stream[AssistantStreamEvent]) -> None:
        # ... initialization with stream ...

    def __next__(self) -> AssistantStreamEvent:
        # ... implementation ...

    def __iter__(self) -> Iterator[AssistantStreamEvent]:
        # ... implementation ...

    def close(self) -> None:
        # ... resource cleanup ...

    def until_done(self) -> None:
        # ... wait for stream completion ...

    def get_final_run(self) -> Run:
        # ... retrieve final run object ...

    def get_final_run_steps(self) -> list[RunStep]:
        # ... retrieve final run steps ...

    def get_final_messages(self) -> list[Message]:
        # ... retrieve final messages ...

    def __text_deltas__(self) -> Iterator[str]:
        # ... iterate over text deltas ...

    # Event handler methods
    def on_end(self) -> None:
        # ... handle stream end ...

    def on_event(self, event: AssistantStreamEvent) -> None:
        # ... handle generic events ...

    def on_run_step_created(self, run_step: RunStep) -> None:
        # ... handle run step creation ...

    # ... more event handler methods ...

    def _emit_sse_event(self, event: AssistantStreamEvent) -> None:
        # ... internal event emission logic ...

    def __stream__(self) -> Iterator[AssistantStreamEvent]:
        # ... main streaming logic ...
```

This class encapsulates the logic for handling various events that occur during an assistant's operation. Here's a breakdown of its key aspects:

- **Initialization and Setup**: The `__init__` and `_init` methods prepare the handler for use with a specific stream.

- **Iterator Protocol**: By implementing `__next__` and `__iter__`, the class allows for easy iteration over the stream of events.

- **Resource Management**: The `close` method ensures proper cleanup of resources when the stream is no longer needed.

- **Stream Control**: Methods like `until_done` provide ways to wait for and control the stream's progress.

- **Result Retrieval**: Methods such as `get_final_run`, `get_final_run_steps`, and `get_final_messages` allow access to the final state after stream completion.

- **Event Handlers**: A series of `on_*` methods (e.g., `on_run_step_created`, `on_message_delta`) provide hooks for custom behavior for different event types.

- **Internal Event Processing**: The `_emit_sse_event` method is responsible for processing each event and triggering the appropriate handlers.

### 2. AsyncAssistantEventHandler Class

The `AsyncAssistantEventHandler` class is the asynchronous counterpart to `AssistantEventHandler`. It has a similar structure but is designed for use in asynchronous contexts:

```python
class AsyncAssistantEventHandler:
    def __init__(self) -> None:
        # ... initialization code ...

    async def __anext__(self) -> AssistantStreamEvent:
        # ... async implementation ...

    async def __aiter__(self) -> AsyncIterator[AssistantStreamEvent]:
        # ... async implementation ...

    async def close(self) -> None:
        # ... async resource cleanup ...

    async def until_done(self) -> None:
        # ... async wait for stream completion ...

    async def get_final_run(self) -> Run:
        # ... async retrieve final run object ...

    # ... more async methods ...

    async def __stream__(self) -> AsyncIterator[AssistantStreamEvent]:
        # ... main async streaming logic ...
```

This class provides the same functionality as `AssistantEventHandler` but in an asynchronous manner, allowing for non-blocking operations in asynchronous applications.

### 3. Stream Managers

The library includes stream manager classes that help manage the lifecycle of streaming operations:

```python
class AssistantStreamManager(Generic[AssistantEventHandlerT]):
    def __init__(
        self,
        api_request: Callable[[], Stream[AssistantStreamEvent]],
        *,
        event_handler: AssistantEventHandlerT,
    ) -> None:
        # ... initialization ...

    def __enter__(self) -> AssistantEventHandlerT:
        # ... context manager entry ...

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        # ... context manager exit ...

class AsyncAssistantStreamManager(Generic[AsyncAssistantEventHandlerT]):
    # ... similar structure to AssistantStreamManager, but for async contexts ...
```

These manager classes provide a convenient way to set up and tear down streaming operations, ensuring proper resource management through the use of context managers.

## Advanced Concepts and Techniques

### 1. Custom Event Handlers

One of the most powerful features of the streaming system is the ability to create custom event handlers. This allows you to define specific behaviors for different types of events. For example:

```python
class MyCustomHandler(AssistantEventHandler):
    def on_message_created(self, message: Message) -> None:
        print(f"New message created: {message.content}")

    def on_run_step_completed(self, run_step: RunStep) -> None:
        print(f"Run step completed: {run_step.step_details}")

    def on_text_delta(self, delta: TextDelta, snapshot: Text) -> None:
        print(f"Received text delta: {delta.value}")
```

By subclassing `AssistantEventHandler` or `AsyncAssistantEventHandler`, you can override specific event methods to implement custom behavior for your application.

### 2. State Management

The event handlers maintain internal state to track the progress of the assistant's operation. This state includes:

- The current run
- Run steps
- Messages
- Tool calls

Understanding this state management is crucial for building complex applications that need to react to or analyze the assistant's behavior over time.

### 3. Error Handling and Resilience

The streaming system includes built-in error handling mechanisms:

```python
try:
    async for event in stream:
        await self._emit_sse_event(event)
        yield event
except (httpx.TimeoutException, asyncio.TimeoutError) as exc:
    await self.on_timeout()
    await self.on_exception(exc)
    raise
except Exception as exc:
    await self.on_exception(exc)
    raise
finally:
    await self.on_end()
```

This structure ensures that timeouts and exceptions are properly handled, and that cleanup operations (via `on_end`) are always performed.

### 4. Delta Accumulation

The library implements a delta accumulation system to build up the full content of messages and run steps over time:

```python
def accumulate_delta(acc: dict[object, object], delta: dict[object, object]) -> dict[object, object]:
    for key, delta_value in delta.items():
        # ... complex accumulation logic ...
```

This system allows for efficient streaming of large amounts of content, providing partial updates that can be used to display progress in real-time.

## Best Practices for Advanced Streaming

1. **Efficient Event Processing**: When implementing custom event handlers, ensure that your processing is efficient. Heavy computations in event handlers can slow down the entire streaming process.

2. **State Synchronization**: If you're maintaining application state based on streaming events, be careful to keep it synchronized with the internal state of the event handler. Consider using the `get_final_*` methods to verify your state at the end of the stream.

3. **Graceful Degradation**: Design your application to handle partial or interrupted streams gracefully. Users should still have a good experience even if the full stream isn't received.

4. **Backpressure Management**: In high-volume streaming scenarios, be prepared to handle backpressure. This might involve buffering events or implementing flow control mechanisms.

5. **Testing with Mock Streams**: Create mock streams that simulate various scenarios (slow connections, errors, specific event sequences) to thoroughly test your event handling logic.

6. **Lifecycle Management**: Always use the provided stream managers (e.g., `AssistantStreamManager`) to ensure proper setup and teardown of streaming resources.

7. **Asynchronous Considerations**: When working with `AsyncAssistantEventHandler`, be mindful of async context switches. Avoid blocking operations in your event handlers.

8. **Monitoring and Logging**: Implement comprehensive logging in your custom event handlers. This can be invaluable for debugging and understanding the behavior of your application in production.

## Real-World Application Scenario

Let's consider a real-world scenario of building a live coding assistant that provides real-time suggestions as a user types:

```python
class LiveCodingAssistant(AsyncAssistantEventHandler):
    def __init__(self, ui_update_callback):
        super().__init__()
        self.ui_update_callback = ui_update_callback
        self.current_suggestion = ""

    async def on_text_delta(self, delta: TextDelta, snapshot: Text) -> None:
        self.current_suggestion += delta.value
        await self.ui_update_callback(self.current_suggestion)

    async def on_run_step_completed(self, run_step: RunStep) -> None:
        if run_step.step_details.type == "tool_calls":
            for tool_call in run_step.step_details.tool_calls:
                if tool_call.type == "function" and tool_call.function.name == "suggest_code":
                    await self.ui_update_callback(tool_call.function.arguments)

async def main():
    client = AsyncOpenAI()
    assistant = await client.beta.assistants.create(
        name="Live Coding Assistant",
        instructions="You are a helpful coding assistant. Provide real-time suggestions as the user types.",
        model="gpt-4-32k",
        tools=[{"type": "code_interpreter"}]
    )

    async def update_ui(suggestion):
        # In a real application, this would update a UI component
        print(f"Suggestion: {suggestion}")

    handler = LiveCodingAssistant(update_ui)

    async with client.beta.threads.create_and_run_stream(
        assistant_id=assistant.id,
        thread={
            "messages": [
                {"role": "user", "content": "I'm writing a Python function to calculate fibonacci numbers"}
            ]
        },
        event_handler=handler
    ) as stream:
        async for event in stream:
            # The handler methods will be called automatically
            pass

    print("Final suggestion:", handler.current_suggestion)

asyncio.run(main())
```

This example demonstrates how to use the advanced streaming capabilities to create a responsive, real-time coding assistant. It processes text deltas to provide immediate feedback and uses tool calls to offer more structured code suggestions.

## Conclusion

The advanced streaming and asynchronous operations in the OpenAI Python library provide a powerful foundation for building complex, real-time applications. By understanding the event handling system, state management, and best practices, you can create highly responsive and efficient applications that make the most of the OpenAI API's capabilities.

As you continue to work with these advanced features, remember to always consider the user experience, performance implications, and error handling in your designs. The flexibility offered by the custom event handling system allows for a wide range of innovative applications, limited only by your imagination and the capabilities of the underlying AI models.
