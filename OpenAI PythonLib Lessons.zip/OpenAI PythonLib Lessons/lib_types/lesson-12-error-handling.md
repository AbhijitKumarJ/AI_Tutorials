# Lesson 12: Error Handling and Exception Management

## Introduction

In this lesson, we'll delve into the error handling and exception management mechanisms within the OpenAI Python library. Proper error handling is crucial for building robust and reliable applications that can gracefully handle unexpected situations. We'll explore the custom exceptions defined in the library, examine the error hierarchy, and discuss strategies for implementing effective error handling in your applications.

## File Layout

Let's start by examining the relevant file structure within the `openai-src-lib` directory:

```
openai-src-lib/
    _exceptions.py
    _base_client.py
    azure.py
    _client.py
```

The primary focus of our discussion will be the `_exceptions.py` file, which defines the custom exceptions used throughout the library. However, we'll also reference other files to understand how these exceptions are used and handled in different contexts.

## Custom Exceptions in the OpenAI Library

### 1. OpenAIError Hierarchy

The OpenAI library defines a hierarchy of custom exceptions, all inheriting from a base `OpenAIError` class. Let's examine the structure:

```python
class OpenAIError(Exception):
    def __init__(
        self,
        message: str | None = None,
        *,
        http_status: int | None = None,
        type: str | None = None,
        **kwargs: Any,
    ) -> None:
        # ... initialization code ...

class APIError(OpenAIError):
    pass

class APIStatusError(APIError):
    pass

class APIConnectionError(APIError):
    pass

class APITimeoutError(APIConnectionError):
    pass

class APIResponseValidationError(APIError):
    pass

class APIResponseTooLarge(APIError):
    pass

# ... more specific exceptions ...
```

This hierarchy allows for precise error handling and provides valuable context about the nature of the error. Here's a breakdown of the key exception classes:

- **OpenAIError**: The base exception class for all OpenAI-related errors. It includes fields for HTTP status, error type, and additional context.

- **APIError**: A general class for API-related errors. This is used for unexpected errors that don't fit into more specific categories.

- **APIStatusError**: Used for HTTP status code errors. It includes additional information about the request and response.

- **APIConnectionError**: Indicates issues with connecting to the API, such as network problems or DNS failures.

- **APITimeoutError**: A specific type of connection error that occurs when a request times out.

- **APIResponseValidationError**: Raised when the API response doesn't match the expected schema.

- **APIResponseTooLarge**: Indicates that the API response exceeded the maximum allowed size.

### 2. Specialized Exceptions

The library also includes several specialized exceptions for specific scenarios:

```python
class AuthenticationError(OpenAIError):
    pass

class PermissionDeniedError(OpenAIError):
    pass

class RateLimitError(OpenAIError):
    pass

class APIBadRequestError(APIStatusError):
    pass

class ConflictError(APIStatusError):
    pass

class NotFoundError(APIStatusError):
    pass
```

These exceptions provide more granular control over error handling:

- **AuthenticationError**: Raised when there are issues with API authentication.
- **PermissionDeniedError**: Indicates that the authenticated user doesn't have permission for the requested operation.
- **RateLimitError**: Occurs when API rate limits are exceeded.
- **APIBadRequestError**: Represents a 400 Bad Request response from the API.
- **ConflictError**: Indicates a conflict in the request, typically a 409 HTTP status.
- **NotFoundError**: Raised when a requested resource is not found (404 status).

## Error Handling Mechanisms

### 1. Exception Raising

The OpenAI library raises these custom exceptions at various points during API interactions. For example, in the `_base_client.py` file:

```python
def _process_response(
    self,
    *,
    response: httpx.Response,
    cast_to: Type[ResponseT] | None,
    stream: bool,
    stream_cls: type[_StreamT] | None,
) -> ResponseT | _StreamT:
    if response.is_success:
        # ... success handling ...
    else:
        # ... error handling ...
        raise self._make_status_error_from_response(response) from None
```

This method processes the API response and raises an appropriate exception if the response indicates an error.

### 2. Error Creation

The library includes utility methods for creating appropriate error objects based on the API response:

```python
def _make_status_error_from_response(self, response: httpx.Response) -> APIStatusError:
    err_msg = f"Error code: {response.status_code}"
    err_msg += f" - {self._extract_error_message(response)}"

    if response.status_code == 400:
        return APIBadRequestError(err_msg, response=response)
    elif response.status_code == 401:
        return AuthenticationError(err_msg, response=response)
    elif response.status_code == 403:
        return PermissionDeniedError(err_msg, response=response)
    elif response.status_code == 404:
        return NotFoundError(err_msg, response=response)
    elif response.status_code == 409:
        return ConflictError(err_msg, response=response)
    elif response.status_code == 429:
        return RateLimitError(err_msg, response=response)
    
    return APIStatusError(err_msg, response=response)
```

This method creates the most appropriate exception based on the HTTP status code and other response details.

## Implementing Effective Error Handling

When working with the OpenAI library, it's crucial to implement proper error handling to create robust applications. Here are some strategies and best practices:

### 1. Use Exception Hierarchies

Leverage the exception hierarchy to handle errors at different levels of specificity:

```python
try:
    response = client.completions.create(prompt="Hello, world!")
except AuthenticationError as e:
    print("Authentication failed. Please check your API key.")
except RateLimitError as e:
    print("Rate limit exceeded. Please wait and try again.")
except APIConnectionError as e:
    print("Connection error. Please check your internet connection.")
except APIError as e:
    print(f"An API error occurred: {e}")
except OpenAIError as e:
    print(f"An unexpected error occurred: {e}")
```

This approach allows you to handle specific error cases differently while still catching any unexpected OpenAI-related errors.

### 2. Extract Detailed Error Information

The custom exceptions in the OpenAI library often contain detailed information about the error. Make use of this information in your error handling:

```python
except APIStatusError as e:
    print(f"API error status: {e.status_code}")
    print(f"Error message: {e.message}")
    print(f"Request ID: {e.request_id}")
    # Log the full error for debugging
    logger.error(f"Full error details: {e!r}")
```

### 3. Implement Retries for Transient Errors

Some errors, like network issues or rate limiting, may be transient. Implement a retry mechanism for these cases:

```python
import time
from openai._exceptions import RateLimitError, APIConnectionError

def retry_with_exponential_backoff(
    func,
    max_retries=5,
    initial_wait=1,
    exponential_base=2,
):
    def wrapper(*args, **kwargs):
        num_retries = 0
        wait_time = initial_wait

        while True:
            try:
                return func(*args, **kwargs)
            except (RateLimitError, APIConnectionError) as e:
                num_retries += 1
                if num_retries > max_retries:
                    raise

                print(f"Retry {num_retries}/{max_retries} after error: {e}")
                time.sleep(wait_time)
                wait_time *= exponential_base

    return wrapper

@retry_with_exponential_backoff
def make_api_call(client):
    return client.completions.create(prompt="Hello, world!")

response = make_api_call(client)
```

This decorator implements an exponential backoff strategy for retrying failed API calls.

### 4. Graceful Degradation

Design your application to gracefully handle API errors and continue functioning, albeit with reduced capabilities:

```python
def get_ai_response(client, prompt):
    try:
        response = client.completions.create(prompt=prompt)
        return response.choices[0].text
    except OpenAIError as e:
        logging.error(f"AI response generation failed: {e}")
        return "I'm sorry, I'm having trouble right now. Please try again later."

def main():
    while True:
        user_input = input("You: ")
        ai_response = get_ai_response(client, user_input)
        print(f"AI: {ai_response}")
```

This approach ensures that your application can continue to function even if AI-generated responses are temporarily unavailable.

### 5. Logging and Monitoring

Implement comprehensive logging for errors to aid in debugging and monitoring:

```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    # API call
except OpenAIError as e:
    logger.error(f"OpenAI API error occurred: {e}", exc_info=True)
    # Additional error handling
```

Consider integrating with monitoring tools to alert you of recurring errors or unusual error patterns.

### 6. Handling Streaming Errors

When working with streaming responses, implement error handling that can deal with interruptions mid-stream:

```python
async def process_stream():
    try:
        async with client.beta.chat.completions.stream(...) as stream:
            async for chunk in stream:
                yield chunk
    except APIConnectionError as e:
        logging.error(f"Stream interrupted: {e}")
        yield "Stream interrupted. Please try again."
    finally:
        # Cleanup code

async for chunk in process_stream():
    # Process chunk
```

This approach ensures that streaming errors are caught and handled appropriately, allowing for cleanup and user feedback.

## Best Practices for Error Handling

1. **Be Specific**: Catch specific exceptions when possible, rather than catching all exceptions broadly. This allows for more targeted error handling.

2. **Provide Context**: When re-raising exceptions or logging errors, include contextual information about what operation was being performed.

3. **Fail Gracefully**: Design your application to continue functioning (perhaps with reduced capabilities) in the face of API errors.

4. **Log Comprehensively**: Log all errors with sufficient detail for debugging, but be cautious about logging sensitive information.

5. **Consider the User**: Translate technical error messages into user-friendly notifications when appropriate.

6. **Monitor and Alert**: Set up monitoring for your application, with alerts for unusual error patterns or frequencies.

7. **Test Error Scenarios**: Implement unit tests and integration tests that simulate various error conditions to ensure your error handling works as expected.

8. **Keep Up-to-Date**: Stay informed about updates to the OpenAI library, as new exception types or error handling mechanisms may be introduced.

## Conclusion

Effective error handling and exception management are crucial for building robust applications with the OpenAI Python library. By understanding the custom exception hierarchy, implementing appropriate error handling strategies, and following best practices, you can create applications that gracefully handle unexpected situations, provide a better user experience, and simplify debugging and maintenance.

Remember that error handling is not just about preventing crashes; it's about creating a resilient system that can adapt to various failure modes and continue to provide value to users even when things don't go as planned. As you develop your applications, continually refine your error handling strategies based on real-world usage patterns and feedback.

In the next lesson, we'll explore performance optimization techniques and best practices for working with the OpenAI API at scale.
