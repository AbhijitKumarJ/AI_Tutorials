# Lesson 12: Testing and Debugging in the OpenAI Python Library

## Introduction

In this lesson, we'll explore techniques for testing and debugging applications that use the OpenAI Python Library. Effective testing and debugging are crucial for ensuring the reliability, performance, and correctness of AI-powered applications. We'll cover unit testing, mocking API responses, debugging techniques specific to API interactions, logging and tracing, integration testing, and test-driven development practices.

## 1. Unit Testing

Unit testing is a fundamental practice in software development that involves testing individual components or functions in isolation. When working with the OpenAI Python Library, unit tests help ensure that your code interacts correctly with the API and handles responses appropriately.

### Purpose
Unit tests verify that individual parts of your code work as expected, catch regressions early, and serve as documentation for how your code should behave.

### Implementation
To implement unit tests for code using the OpenAI Python Library, you'll typically use a testing framework like pytest along with mocking utilities to simulate API responses.

### Example

```python
import pytest
from unittest.mock import patch, MagicMock
from openai import OpenAI
from your_module import generate_response  # The function we're testing

@pytest.fixture
def mock_openai_client():
    with patch('openai.OpenAI') as mock_client:
        yield mock_client

def test_generate_response(mock_openai_client):
    # Arrange
    mock_completion = MagicMock()
    mock_completion.choices[0].message.content = "This is a test response."
    mock_openai_client.return_value.chat.completions.create.return_value = mock_completion

    # Act
    result = generate_response("What is the meaning of life?")

    # Assert
    assert "test response" in result.lower()
    mock_openai_client.return_value.chat.completions.create.assert_called_once_with(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": "What is the meaning of life?"}]
    )

# The function we're testing
def generate_response(prompt):
    client = OpenAI()
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content
```

### Key Points
- Use `pytest.fixture` to set up mocks that can be reused across multiple tests.
- The `patch` decorator from `unittest.mock` allows you to replace the OpenAI client with a mock object.
- Mocking the API response allows you to test different scenarios without making actual API calls.
- Assert both the expected output and that the API was called with the correct parameters.
- Testing error handling is crucial; make sure to include tests for various error conditions.

## 2. Mocking API Responses

Mocking API responses is a crucial technique when testing code that interacts with external services like the OpenAI API. It allows you to simulate various response scenarios without actually calling the API.

### Purpose
Mocking helps in testing edge cases, error handling, and different response types without incurring API usage costs or relying on network connectivity.

### Implementation
Use the `unittest.mock` library or a mocking framework like `responses` to intercept HTTP requests and return predefined responses.

### Example

```python
import responses
import json
from openai import OpenAI
from your_module import summarize_text

@responses.activate
def test_summarize_text():
    # Mock the API response
    responses.add(
        responses.POST,
        "https://api.openai.com/v1/chat/completions",
        json={
            "id": "chatcmpl-123",
            "object": "chat.completion",
            "created": 1677858242,
            "model": "gpt-3.5-turbo-0301",
            "usage": {"prompt_tokens": 13, "completion_tokens": 7, "total_tokens": 20},
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "This is a summary of the text."
                    },
                    "finish_reason": "stop",
                    "index": 0
                }
            ]
        },
        status=200
    )

    # Call the function that uses the API
    result = summarize_text("This is a long text that needs summarizing.")

    # Assert the result
    assert result == "This is a summary of the text."

    # Check that the request was made correctly
    assert len(responses.calls) == 1
    assert responses.calls[0].request.url == "https://api.openai.com/v1/chat/completions"
    request_body = json.loads(responses.calls[0].request.body)
    assert request_body["model"] == "gpt-3.5-turbo"
    assert request_body["messages"][0]["content"] == "Summarize the following text: This is a long text that needs summarizing."

# The function we're testing
def summarize_text(text):
    client = OpenAI()
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "user", "content": f"Summarize the following text: {text}"}
        ]
    )
    return response.choices[0].message.content
```

### Key Points
- The `responses` library allows you to easily mock HTTP responses for specific URLs and methods.
- Mocked responses should mimic the structure of real API responses to ensure your code handles them correctly.
- Test both successful responses and error responses to ensure your code handles all scenarios.
- Verify that the outgoing request is correctly formatted, including headers, URL, and body content.
- Remember to mock all API calls your function might make, including potential retries or follow-up requests.

## 3. Debugging Techniques for API Interactions

Debugging code that interacts with the OpenAI API requires some specific techniques due to the asynchronous and network-dependent nature of API calls.

### Purpose
Effective debugging helps identify and resolve issues in your code, especially those related to API interactions, response handling, and error management.

### Implementation
Use a combination of logging, debugger breakpoints, and API response inspection to understand how your code interacts with the OpenAI API.

### Example

```python
import logging
from openai import OpenAI
import sys

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def generate_story(prompt):
    client = OpenAI()
    try:
        logger.debug(f"Sending request to OpenAI API with prompt: {prompt}")
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        logger.debug(f"Received response: {response}")
        
        story = response.choices[0].message.content
        logger.info(f"Generated story: {story[:50]}...")  # Log first 50 characters
        return story
    except Exception as e:
        logger.error(f"Error occurred: {str(e)}", exc_info=True)
        return None

# Usage
if __name__ == "__main__":
    prompt = "Write a short story about a robot learning to paint."
    story = generate_story(prompt)
    if story:
        print(story)
    else:
        print("Failed to generate story.")

# To use a debugger, you can add breakpoints or use the built-in debugger
import pdb
# pdb.set_trace()  # Uncomment this line to pause execution and start the debugger
```

### Key Points
- Use logging to track the flow of your program and the content of requests and responses.
- Set log levels appropriately: use DEBUG for detailed information, INFO for general operations, and ERROR for issues.
- When debugging, pay attention to the exact structure of API responses to ensure you're accessing the correct fields.
- Use try-except blocks to catch and log specific exceptions that may occur during API interactions.
- The Python debugger (`pdb`) can be used to pause execution and inspect variables at runtime.
- For production environments, consider using structured logging and a logging service to aggregate and analyze logs.

## 4. Integration Testing

Integration testing involves testing the interaction between different components of your system, including external services like the OpenAI API.

### Purpose
Integration tests ensure that your application works correctly with the actual OpenAI API, verifying that your code can handle real-world scenarios and API changes.

### Implementation
Write tests that make actual API calls, but use separate API keys and lower-cost models for testing purposes.

### Example

```python
import os
import pytest
from openai import OpenAI

# Ensure you're using a test API key
os.environ['OPENAI_API_KEY'] = 'your-test-api-key'

@pytest.mark.integration
def test_chat_completion_integration():
    client = OpenAI()
    
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "What's the capital of France?"}
        ]
    )
    
    assert response.choices[0].message.content.lower().count("paris") > 0, "Response should mention Paris"
    assert len(response.choices) == 1, "Should return only one choice"
    assert response.usage.total_tokens > 0, "Should report token usage"

@pytest.mark.integration
def test_error_handling_integration():
    client = OpenAI()
    
    with pytest.raises(Exception) as exc_info:
        client.chat.completions.create(
            model="non-existent-model",
            messages=[{"role": "user", "content": "This should fail."}]
        )
    
    assert "non-existent-model" in str(exc_info.value), "Should mention the invalid model name in the error"

# Run these tests with: pytest -v -m integration
```

### Key Points
- Use a separate API key for testing to avoid interfering with production usage or incurring unnecessary costs.
- Mark integration tests (e.g., with `@pytest.mark.integration`) so they can be run separately from unit tests.
- Test both successful API interactions and error scenarios.
- Verify that the responses contain the expected structure and content.
- Be mindful of rate limits and costs when running integration tests frequently.
- Consider implementing retry logic in your tests to handle transient API errors.

## 5. Test-Driven Development Practices

Test-Driven Development (TDD) is a software development approach where you write tests before implementing the actual functionality.

### Purpose
TDD helps ensure that your code meets its requirements, encourages modular design, and provides a safety net for refactoring.

### Implementation
Follow the Red-Green-Refactor cycle: write a failing test, implement the minimum code to make it pass, then refactor as needed.

### Example

```python
import pytest
from unittest.mock import patch, MagicMock
from openai import OpenAI

# Step 1: Write the test first
def test_sentiment_analysis():
    with patch('openai.OpenAI') as mock_openai:
        mock_completion = MagicMock()
        mock_completion.choices[0].message.content = "positive"
        mock_openai.return_value.chat.completions.create.return_value = mock_completion

        result = analyze_sentiment("I love this product!")
        
        assert result == "positive"
        mock_openai.return_value.chat.completions.create.assert_called_once()

# Step 2: Implement the minimum code to make the test pass
def analyze_sentiment(text):
    client = OpenAI()
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a sentiment analysis tool. Respond with only 'positive', 'negative', or 'neutral'."},
            {"role": "user", "content": f"Analyze the sentiment of this text: {text}"}
        ]
    )
    return response.choices[0].message.content

# Step 3: Refactor if necessary
# In this case, our implementation is simple, so no refactoring is needed.

# Additional tests to cover more scenarios
def test_sentiment_analysis_negative():
    with patch('openai.OpenAI') as mock_openai:
        mock_completion = MagicMock()
        mock_completion.choices[0].message.content = "negative"
        mock_openai.return_value.chat.completions.create.return_value = mock_completion

        result = analyze_sentiment("I hate this product!")
        
        assert result == "negative"

def test_sentiment_analysis_neutral():
    with patch('openai.OpenAI') as mock_openai:
        mock_completion = MagicMock()
        mock_completion.choices[0].message.content = "neutral"
        mock_openai.return_value.chat.completions.create.return_value = mock_completion

        result = analyze_sentiment("This product is okay.")
        
        assert result == "neutral"
```

### Key Points
- Start by writing a test that defines the expected behavior of your function.
- Implement the minimum code necessary to make the test pass.
- Refactor your code if needed, ensuring that all tests still pass after refactoring.
- Add more tests to cover edge cases and different scenarios.
- When using TDD with API calls, focus on the expected input and output of your functions, using mocks to simulate API responses.
- Regularly run your full test suite to ensure new changes don't break existing functionality.
- TDD can be particularly helpful when working with complex AI models, as it forces you to clearly define the expected behavior of your AI-powered features.

## Conclusion

In this lesson, we've explored various techniques for testing and debugging applications that use the OpenAI Python Library. We covered unit testing for verifying individual components, mocking API responses for controlled testing environments, debugging techniques specific to API interactions, integration testing for ensuring real-world compatibility, and test-driven development practices for building robust AI-powered features.

Effective testing and debugging are crucial when working with AI APIs, as they help ensure the reliability and correctness of your applications. By implementing these practices, you can catch issues early, maintain code quality, and confidently develop applications that leverage the power of OpenAI's models.

Remember that testing AI-powered applications comes with unique challenges, such as handling non-deterministic outputs and evolving model behaviors. Always strive to write tests that are resilient to minor changes in AI responses while still catching significant deviations from expected behavior.

In the next lesson, we'll explore performance optimization techniques for applications using the OpenAI Python Library, helping you build not just robust, but also efficient AI-powered systems.
