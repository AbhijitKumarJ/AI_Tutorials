# Lesson 5: Authentication and Configuration in the OpenAI Python Library

## Introduction

Authentication and configuration are crucial aspects of working with any API, and the OpenAI Python Library is no exception. In this lesson, we'll explore how to properly set up and manage your API credentials, configure your client, and understand the different authentication methods available. We'll also dive into best practices for securing your credentials and configuring the library for different environments.

## API Key Management and Best Practices

The most common method of authentication with the OpenAI API is using an API key. This key is a unique identifier that allows the API to associate requests with your account. It's essential to handle this key securely to prevent unauthorized access to your account.

### Obtaining an API Key

To get an API key, you need to sign up for an OpenAI account and navigate to the API section of your dashboard. Here, you can create a new API key. Remember, this key should be treated like a password - it gives access to your account and associated credits.

### Storing the API Key

There are several ways to store and use your API key, each with its own pros and cons:

1. Environment Variables: This is the recommended method for most applications. You can set an environment variable named `OPENAI_API_KEY` with your API key value. The OpenAI library will automatically look for this variable if no key is explicitly provided.

   To set an environment variable in Unix-based systems:
   ```bash
   export OPENAI_API_KEY='your-api-key-here'
   ```

   For Windows:
   ```powershell
   $env:OPENAI_API_KEY='your-api-key-here'
   ```

2. Configuration File: You can store your API key in a configuration file, such as a YAML or JSON file. This method is useful for applications that need to manage multiple configurations.

   Example `config.yaml`:
   ```yaml
   openai:
     api_key: 'your-api-key-here'
   ```

3. Direct Assignment: While not recommended for production, during development you might directly assign the API key in your code. Always ensure this code is not committed to version control.

   ```python
   import openai
   openai.api_key = 'your-api-key-here'
   ```

### Best Practices for API Key Management

1. Never hardcode your API key directly into your source code, especially if it's shared or open-source.
2. Use environment variables or secure configuration management systems to store and access your API key.
3. Implement key rotation: regularly update your API keys to minimize the impact of potential key exposure.
4. Use different API keys for development and production environments.
5. If your application is client-side (e.g., a browser-based application), avoid exposing your API key. Instead, use a backend service to make API calls.

## Environment Variables and Configuration Files

The OpenAI library supports various methods of configuration to make it flexible for different use cases and environments.

### Environment Variables

The library looks for the following environment variables:

- `OPENAI_API_KEY`: Your OpenAI API key
- `OPENAI_ORGANIZATION`: Your OpenAI organization ID (optional)
- `OPENAI_API_BASE`: The base URL for API requests (useful for proxies or custom endpoints)

You can set these variables in your shell or within your application:

```python
import os
os.environ['OPENAI_API_KEY'] = 'your-api-key-here'
os.environ['OPENAI_ORGANIZATION'] = 'your-org-id-here'
```

### Configuration Files

For more complex configurations, you might want to use a configuration file. The OpenAI library doesn't directly support configuration files, but you can easily implement this yourself:

```python
import yaml
import openai

def load_config(config_path):
    with open(config_path, 'r') as file:
        return yaml.safe_load(file)

config = load_config('config.yaml')
openai.api_key = config['openai']['api_key']
openai.organization = config['openai']['organization']
```

This approach allows you to manage multiple configurations (e.g., development, staging, production) easily.

## The Azure OpenAI Client and Its Specific Configuration

Azure OpenAI Service is a version of OpenAI's API hosted on Microsoft Azure. It requires a different configuration process compared to the standard OpenAI API.

### Setting Up Azure OpenAI

To use Azure OpenAI, you need to have an Azure subscription and deploy an Azure OpenAI resource. Once you have this set up, you'll have the following information:

- Azure OpenAI endpoint (e.g., `https://your-resource-name.openai.azure.com/`)
- Azure OpenAI API key
- Deployment name for the model you want to use

### Configuring the Azure OpenAI Client

The OpenAI library provides a specific client for Azure OpenAI. Here's how to set it up:

```python
from openai import AzureOpenAI

client = AzureOpenAI(
    api_key = "your-azure-openai-key",  
    api_version = "2023-05-15",
    azure_endpoint = "https://your-resource-name.openai.azure.com/"
)

response = client.chat.completions.create(
    model="deployment-name", # This is your deployment name
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Hello!"}
    ]
)
```

Note that when using Azure OpenAI, you specify the deployment name instead of the model name in your requests.

## Understanding Different Authentication Methods

While API key authentication is the most common method, the OpenAI library supports other authentication methods, particularly for Azure OpenAI.

### API Key Authentication

This is the standard method for the OpenAI API:

```python
from openai import OpenAI

client = OpenAI(api_key="your-api-key-here")
```

### Azure Active Directory (Azure AD) Token Authentication

For Azure OpenAI, you can use Azure AD tokens for authentication. This method is particularly useful for applications running in Azure that can use managed identities.

```python
from openai import AzureOpenAI

def get_azure_ad_token():
    # Implementation to fetch Azure AD token
    # This could use the Azure Identity library or a custom implementation
    pass

client = AzureOpenAI(
    azure_ad_token=get_azure_ad_token(),
    api_version="2023-05-15",
    azure_endpoint="https://your-resource-name.openai.azure.com/"
)
```

### Azure AD Token Provider

For more dynamic token management, you can use a token provider function:

```python
from openai import AzureOpenAI

def azure_ad_token_provider():
    # Implementation to fetch Azure AD token
    pass

client = AzureOpenAI(
    azure_ad_token_provider=azure_ad_token_provider,
    api_version="2023-05-15",
    azure_endpoint="https://your-resource-name.openai.azure.com/"
)
```

This method allows for automatic token refresh without reinitializing the client.

## Secure Storage of Credentials

Securing your API credentials is crucial. Here are some methods for secure credential storage:

1. Environment Variables: As mentioned earlier, this is a simple and effective method for many applications.

2. Secrets Management Services: For production environments, consider using a secrets management service like AWS Secrets Manager, Azure Key Vault, or HashiCorp Vault.

3. Encrypted Configuration Files: If you must use configuration files, ensure they are encrypted and decrypted securely in your application.

4. Application-Specific Credential Stores: Some frameworks and platforms offer secure credential storage, like Django's `SECRET_KEY` setting.

## Configuration Inheritance and Overrides

The OpenAI library allows for flexible configuration with inheritance and overrides. This is particularly useful when you need different configurations for different parts of your application.

### Global Configuration

You can set global configuration that will be used by default:

```python
import openai

openai.api_key = "your-global-api-key"
openai.organization = "your-organization-id"
```

### Client-Level Configuration

When creating a client, you can override the global configuration:

```python
from openai import OpenAI

client = OpenAI(
    api_key="your-specific-api-key",
    organization="your-specific-org-id"
)
```

### Request-Level Configuration

For even more granular control, you can override configuration at the request level:

```python
response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[{"role": "user", "content": "Hello!"}],
    api_key="one-time-use-api-key"
)
```

This flexibility allows you to use different credentials or settings for specific operations without changing your global or client-level configuration.

## Understanding the Configuration in the Library's Source Code

To get a deeper understanding of how configuration works in the OpenAI library, let's look at some relevant parts of the source code.

The main configuration logic is implemented in the `_base_client.py` file. Here's a simplified version of the file structure:

```
openai/
├── _base_client.py
├── _client.py
├── _async_client.py
└── ...
```

In `_base_client.py`, you'll find the `BaseClient` class, which handles the core configuration logic. Here's a simplified excerpt:

```python
class BaseClient:
    def __init__(
        self,
        *,
        api_key: str | None = None,
        organization: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = NOT_GIVEN,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # ...
    ):
        # ... (implementation details)

    def _init_configuration(self):
        api_key = self.api_key
        if api_key is None:
            api_key = os.environ.get("OPENAI_API_KEY")
        if api_key is None:
            raise OpenAIError(
                "The api_key client option must be set either by passing api_key to the client or by setting the OPENAI_API_KEY environment variable"
            )
        self.api_key = api_key

        base_url = self.base_url
        if base_url is None:
            base_url = os.environ.get("OPENAI_BASE_URL")
        if base_url is None:
            base_url = DEFAULT_BASE_URL
        self.base_url = base_url

        # ... (more configuration logic)
```

This code shows how the library prioritizes configuration sources:

1. Values passed directly to the client constructor
2. Environment variables
3. Default values

Understanding this hierarchy helps you manage your configuration effectively across different environments and use cases.

## Conclusion

Authentication and configuration are fundamental to using the OpenAI Python Library effectively and securely. By following best practices for API key management, utilizing environment variables and configuration files appropriately, and understanding the different authentication methods available, you can ensure that your application interacts with the OpenAI API securely and efficiently.

Remember to always prioritize the security of your credentials, especially in production environments. Regularly review and update your authentication and configuration setup to align with the latest security best practices and any updates to the OpenAI library.

In the next lesson, we'll dive deeper into the models and type definitions used in the library, which will build upon the configuration knowledge you've gained here.

