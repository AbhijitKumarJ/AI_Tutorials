# Module 6, Lesson 14: Deployment Strategies
## G1 Reasoning Chains Advanced Course

### Lesson Overview

This lesson focuses on deploying g1 reasoning chain implementations in production environments. We'll explore various deployment strategies, security considerations, scaling approaches, and monitoring solutions. The lesson combines theoretical knowledge with practical implementation guidance to ensure successful production deployments.

### Prerequisites
- Completion of Module 5, Lesson 13: Performance Optimization
- Understanding of Docker and containerization
- Basic knowledge of cloud platforms (AWS, GCP, or Azure)
- Familiarity with CI/CD concepts
- Understanding of basic security principles

### Lesson Duration
- Theory: 2 hours
- Hands-on Practice: 4 hours
- Deployment Project: 6 hours

### Production Environment Structure

```
g1-production/
├── deploy/
│   ├── docker/
│   │   ├── Dockerfile
│   │   ├── docker-compose.yml
│   │   └── .dockerignore
│   ├── kubernetes/
│   │   ├── deployment.yaml
│   │   ├── service.yaml
│   │   └── ingress.yaml
│   └── terraform/
│       ├── main.tf
│       ├── variables.tf
│       └── outputs.tf
├── config/
│   ├── production.yml
│   ├── staging.yml
│   └── secrets/
│       └── .env.production
├── monitoring/
│   ├── prometheus/
│   │   └── prometheus.yml
│   └── grafana/
│       └── dashboards/
│           └── g1-metrics.json
├── scripts/
│   ├── deploy.sh
│   ├── rollback.sh
│   └── health_check.sh
└── tests/
    ├── load_tests/
    │   └── locustfile.py
    └── integration_tests/
        └── test_production.py
```

### 1. Production Environment Setup

#### Docker Configuration
The `Dockerfile` for g1 deployment:

```dockerfile
# Base image with Python 3.9
FROM python:3.9-slim

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    python3-dev \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements first for better caching
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Set environment variables
ENV PYTHONUNBUFFERED=1
ENV ENVIRONMENT=production

# Health check
HEALTHCHECK --interval=30s --timeout=30s --start-period=5s --retries=3 \
    CMD python scripts/health_check.py

# Start application
CMD ["python", "-m", "gunicorn", "-w", "4", "-k", "uvicorn.workers.UvicornWorker", "app.main:app"]
```

#### Docker Compose Configuration
`docker-compose.yml` for local development and testing:

```yaml
version: '3.8'

services:
  g1-app:
    build: .
    ports:
      - "8000:8000"
    environment:
      - GROQ_API_KEY=${GROQ_API_KEY}
      - ENVIRONMENT=production
    volumes:
      - ./app:/app
    depends_on:
      - redis
    networks:
      - g1-network

  redis:
    image: redis:6.2-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    networks:
      - g1-network

networks:
  g1-network:
    driver: bridge

volumes:
  redis-data:
```

### 2. Security Considerations

#### Security Implementation
Create a `security_manager.py` to handle security concerns:

```python
from cryptography.fernet import Fernet
import secrets
import logging

class SecurityManager:
    def __init__(self):
        self.key = self._load_encryption_key()
        self.fernet = Fernet(self.key)
        self.rate_limiter = RateLimiter()
        
    def _load_encryption_key(self):
        """Load encryption key from secure storage"""
        key = os.getenv('ENCRYPTION_KEY')
        if not key:
            key = Fernet.generate_key()
            # Store key securely
        return key
        
    def encrypt_sensitive_data(self, data):
        """Encrypt sensitive data before storage"""
        return self.fernet.encrypt(data.encode())
        
    def decrypt_sensitive_data(self, encrypted_data):
        """Decrypt sensitive data for processing"""
        return self.fernet.decrypt(encrypted_data).decode()
        
    async def validate_request(self, request):
        """Validate incoming requests"""
        if not await self.rate_limiter.check(request.client.host):
            raise RateLimitExceeded
        
        if not self._validate_token(request.headers.get('Authorization')):
            raise InvalidToken
```

#### Environment Configuration
Example `.env.production` file structure (do not commit actual values):

```ini
# API Keys (Use secure key management in production)
GROQ_API_KEY=your_encrypted_key_here
EXA_API_KEY=your_encrypted_key_here

# Security Settings
JWT_SECRET=your_jwt_secret_here
ENCRYPTION_KEY=your_encryption_key_here

# Rate Limiting
MAX_REQUESTS_PER_MINUTE=60
RATE_LIMIT_WINDOW=60

# Performance Settings
CACHE_TTL=3600
MAX_CONCURRENT_REQUESTS=100
```

### 3. Scaling Considerations

#### Kubernetes Deployment
`deployment.yaml` for Kubernetes deployment:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: g1-deployment
spec:
  replicas: 3
  selector:
    matchLabels:
      app: g1
  template:
    metadata:
      labels:
        app: g1
    spec:
      containers:
      - name: g1
        image: g1-app:latest
        resources:
          requests:
            memory: "256Mi"
            cpu: "200m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        env:
        - name: ENVIRONMENT
          value: "production"
        - name: GROQ_API_KEY
          valueFrom:
            secretKeyRef:
              name: g1-secrets
              key: groq-api-key
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 30
```

#### Horizontal Pod Autoscaling
`hpa.yaml` for automatic scaling:

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: g1-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: g1-deployment
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

### 4. Monitoring and Logging

#### Prometheus Configuration
`prometheus.yml` for metrics collection:

```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'g1-app'
    static_configs:
      - targets: ['localhost:8000']
    metrics_path: '/metrics'
```

#### Application Metrics Implementation
Create a `metrics_manager.py` for collecting application metrics:

```python
from prometheus_client import Counter, Histogram, Gauge
import time

class MetricsManager:
    def __init__(self):
        # Request metrics
        self.request_count = Counter(
            'g1_requests_total',
            'Total number of requests processed'
        )
        self.request_latency = Histogram(
            'g1_request_latency_seconds',
            'Request latency in seconds'
        )
        
        # API metrics
        self.api_calls = Counter(
            'g1_api_calls_total',
            'Total number of API calls made',
            ['endpoint']
        )
        
        # System metrics
        self.memory_usage = Gauge(
            'g1_memory_usage_bytes',
            'Current memory usage in bytes'
        )
        
    async def track_request(self, request_func):
        """Track request metrics"""
        start_time = time.time()
        try:
            result = await request_func()
            self.request_count.inc()
            return result
        finally:
            self.request_latency.observe(time.time() - start_time)
```

### 5. Deployment Pipeline

Create a GitHub Actions workflow for automated deployment:

```yaml
name: G1 Deployment

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2

    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'

    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt

    - name: Run tests
      run: |
        python -m pytest tests/

    - name: Build and push Docker image
      uses: docker/build-push-action@v2
      with:
        context: .
        push: true
        tags: g1-app:latest

    - name: Deploy to Kubernetes
      uses: kubectl-deploy-action@v1
      with:
        kubeconfig: ${{ secrets.KUBE_CONFIG }}
        manifest: deploy/kubernetes/deployment.yaml
```

### Hands-on Practice

1. Local Deployment
- Set up local development environment with Docker
- Implement security measures
- Configure monitoring

2. Cloud Deployment
- Deploy to a cloud provider (AWS, GCP, or Azure)
- Set up auto-scaling
- Implement monitoring and alerting

### Assessment Project

Students will create a complete production deployment pipeline including:

1. Containerized application with Docker
2. Kubernetes deployment configuration
3. Monitoring and logging setup
4. Security implementation
5. CI/CD pipeline
6. Load testing and performance validation

### Further Reading and Resources

1. Kubernetes Documentation
2. Docker Best Practices
3. Cloud Provider Documentation
4. Security Best Practices
5. Monitoring and Observability Guides

### Next Steps

After completing this lesson, students should:
1. Understand production deployment requirements
2. Be able to implement secure deployments
3. Know how to scale applications
4. Understand monitoring and logging requirements
5. Be able to set up automated deployment pipelines

The next lesson will focus on advanced use cases and custom tool development for g1 implementations.

### Troubleshooting Guide

Common deployment issues and solutions:

1. Container startup failures
   - Check logs using `docker logs <container_id>`
   - Verify environment variables
   - Check resource limits

2. Kubernetes deployment issues
   - Use `kubectl describe pod <pod-name>`
   - Check events with `kubectl get events`
   - Verify secret configuration

3. Monitoring setup issues
   - Check Prometheus target configuration
   - Verify metrics endpoint accessibility
   - Check Grafana dashboard configuration

4. Security-related issues
   - Verify secret management
   - Check API key encryption
   - Validate rate limiting configuration
