# Module 5: Advanced Concepts
## Lesson 12: Prompt Engineering in g1

### Duration: 120 minutes
### Prerequisites
- Completed Modules 1-4
- Understanding of LLM behavior
- Basic knowledge of JSON formatting
- Familiarity with g1's core functionality

### Lesson Overview
In this lesson, we will deep dive into g1's prompt engineering system, examining how it achieves sophisticated reasoning chains through carefully crafted prompts. We'll analyze the system prompts, explore prompt design patterns, understand response formatting, and study error handling mechanisms in prompting.

### Project Structure
The prompt engineering aspects of g1 are primarily implemented in:

```
g1/
├── g1.py                 # Core reasoning engine with prompt implementation
├── tool-use/
│   └── g1_experimental.py # Enhanced prompting with tool usage
└── ollama/
    └── ollama_app.py     # Ollama-specific prompt adaptations
```

### 1. Understanding System Prompts

g1's system prompts are carefully engineered to create structured reasoning chains. Let's examine the core system prompt architecture:

#### Base System Prompt
From g1.py:
```python
messages = [
    {"role": "system", "content": """You are an expert AI assistant that explains your reasoning step by step. For each step, provide a title that describes what you're doing in that step, along with the content. Decide if you need another step or if you're ready to give the final answer. Respond in JSON format with 'title', 'content', and 'next_action' (either 'continue' or 'final_answer') keys. USE AS MANY REASONING STEPS AS POSSIBLE. AT LEAST 3. BE AWARE OF YOUR LIMITATIONS AS AN LLM AND WHAT YOU CAN AND CANNOT DO. IN YOUR REASONING, INCLUDE EXPLORATION OF ALTERNATIVE ANSWERS. CONSIDER YOU MAY BE WRONG, AND IF YOU ARE WRONG IN YOUR REASONING, WHERE IT WOULD BE. FULLY TEST ALL OTHER POSSIBILITIES. YOU CAN BE WRONG. WHEN YOU SAY YOU ARE RE-EXAMINING, ACTUALLY RE-EXAMINE, AND USE ANOTHER APPROACH TO DO SO. DO NOT JUST SAY YOU ARE RE-EXAMINING. USE AT LEAST 3 METHODS TO DERIVE THE ANSWER. USE BEST PRACTICES."""},
]
```

This prompt structure incorporates several key elements:

1. **Role Definition**
   - Establishes expert assistant persona
   - Sets expectations for step-by-step reasoning
   - Emphasizes methodical approach

2. **Output Structure**
   - Defines JSON response format
   - Specifies required fields
   - Establishes response flow control

3. **Reasoning Guidelines**
   - Minimum step requirement
   - Multiple method verification
   - Alternative answer exploration
   - Self-awareness of limitations

### 2. Prompt Design Patterns

g1 implements several sophisticated prompt design patterns:

#### Chain of Thought Pattern
```python
def generate_response(prompt, custom_client=None):
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": prompt},
        {"role": "assistant", "content": "Thank you! I will now think step by step following my instructions, starting at the beginning after decomposing the problem."}
    ]
```

This implementation:
- Establishes clear thinking process
- Maintains consistency in reasoning
- Enables step-by-step verification
- Supports multiple reasoning approaches

#### Tool-Enhanced Prompting
From g1_experimental.py:
```python
{
    "role": "system",
    "content": """You can also use tools by including:
    - A 'tool' key with one of the following values: 'code_executor', 'web_search', 'fetch_page_content', or 'wolfram_alpha'.
    - A 'tool_input' key with the expression, code to execute, search query, or list of IDs.
    - For 'web_search', you can specify the number of results (default is 5) by adding a 'num_results' key.
    """
}
```

This pattern:
- Extends basic reasoning capabilities
- Integrates external tools
- Maintains structured output
- Enhances problem-solving abilities

### 3. Response Formatting

g1 implements strict response formatting requirements:

#### JSON Structure
```python
Example_Response = {
    "title": "Identifying Key Information",
    "content": "To begin solving this problem...",
    "next_action": "continue"
}
```

#### Format Enforcement
```python
response = client.chat.completions.create(
    model="llama-3.1-70b-versatile",
    messages=messages,
    max_tokens=max_tokens,
    temperature=0.2,
    response_format={"type": "json_object"}
)
```

This implementation ensures:
- Consistent response structure
- Parseable outputs
- Error prevention
- Clean data flow

### 4. Error Handling in Prompts

g1 implements robust error handling in its prompt system:

#### Retry Mechanism
```python
def make_api_call(messages, max_tokens, is_final_answer=False, custom_client=None):
    for attempt in range(3):
        try:
            # API call logic
        except Exception as e:
            if attempt == 2:
                if is_final_answer:
                    return {"title": "Error", "content": f"Failed to generate final answer after 3 attempts. Error: {str(e)}"}
                else:
                    return {"title": "Error", "content": f"Failed to generate step after 3 attempts. Error: {str(e)}", "next_action": "final_answer"}
            time.sleep(1)
```

This system provides:
- Automatic retry on failure
- Graceful error reporting
- System stability
- User feedback

### 5. Advanced Prompt Engineering Techniques

#### Temperature Control
```python
response = client.chat.completions.create(
    temperature=0.2,  # Low temperature for consistent reasoning
)
```

#### Token Management
```python
def make_api_call(messages, max_tokens, is_final_answer=False):
    # Token limit varies based on response type
    max_tokens = 1200 if is_final_answer else 300
```

#### Progressive Refinement
```python
steps.append((f"Step {step_count}: {step_data['title']}", step_data['content'], thinking_time))
messages.append({"role": "assistant", "content": json.dumps(step_data)})
```

### 6. Best Practices and Recommendations

When implementing prompt engineering in similar systems:

1. **Clarity in Instructions**
```python
system_prompt = """
You are an expert AI assistant that explains your reasoning step by step.
For each step, provide a title that describes what you're doing in that step...
"""
```

2. **Structured Output Requirements**
```python
response_format={"type": "json_object"}
```

3. **Error Recovery**
```python
if attempt == 2:
    return {"title": "Error", "content": "Failed after 3 attempts..."}
```

### Practical Exercise

Implement an enhanced version of g1's prompt system that includes:
1. Additional reasoning patterns
2. New tool integrations
3. Enhanced error handling
4. Custom response formats

### Additional Resources

1. LLM Prompting Guide
2. g1 GitHub Repository
3. JSON Schema Documentation
4. Error Handling Patterns

### Next Steps

After completing this lesson, you should:
1. Understand g1's prompt engineering system
2. Be able to design effective prompts
3. Know how to handle response formatting
4. Be prepared for advanced prompt engineering

### Assessment Questions

1. Explain g1's approach to step-by-step reasoning in its prompt system
2. Describe how g1 handles tool integration in prompts
3. How does g1 manage prompt failures and errors?
4. What improvements would you suggest to g1's current prompt engineering system?

### Case Study: The Strawberry Problem

Let's examine how g1's prompt engineering solves the classic "How many Rs are in strawberry?" problem:

1. **Initial Prompt Structure**
```python
{
    "title": "Breaking Down the Word",
    "content": "Let's examine 'strawberry' letter by letter...",
    "next_action": "continue"
}
```

2. **Multiple Verification Methods**
```python
{
    "title": "Alternative Counting Approach",
    "content": "Let's count from right to left to verify...",
    "next_action": "continue"
}
```

3. **Final Answer Formation**
```python
{
    "title": "Final Answer",
    "content": "After multiple verification methods...",
    "next_action": "final_answer"
}
```

This case study demonstrates:
- Systematic problem decomposition
- Multiple verification methods
- Clear reasoning steps
- Error prevention techniques

Remember to practice implementing these concepts in your own projects and experiment with different prompt engineering approaches to improve reasoning capabilities.
