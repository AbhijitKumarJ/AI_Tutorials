# Lesson 2: Development Environment Setup

## Introduction
Setting up a proper development environment is crucial for working with g1 effectively. In this lesson, we'll walk through the entire setup process, ensuring you have a robust, cross-platform compatible environment for developing and running g1 applications.

## Understanding Virtual Environments

### The Importance of Virtual Environments
Virtual environments in Python are isolated spaces where you can install specific package versions without affecting your system's global Python installation. For g1, this is particularly important because:

1. It helps manage dependencies effectively
2. Prevents conflicts between different project requirements
3. Makes the project easily reproducible
4. Simplifies deployment and sharing

### Creating Virtual Environments
Let's examine the recommended setup process from the codebase:

```bash
python3 -m venv venv
source venv/bin/activate  # On Unix/MacOS
.\venv\Scripts\activate   # On Windows
```

This creates a new virtual environment named 'venv' and activates it. The activation process differs between Unix-based systems and Windows, which is an important cross-platform consideration.

## Dependencies Management

### Understanding requirements.txt
The g1 project includes multiple requirements.txt files, each serving different purposes:

1. Root requirements.txt:
```
streamlit
groq
```

2. Gradio implementation requirements:
```
groq
gradio
```

3. Ollama implementation requirements:
```
streamlit
ollama
```

### Managing Multiple Implementation Requirements
The project's structure shows three different implementations, each with its own requirements:
1. Main Streamlit implementation
2. Gradio alternative interface
3. Ollama backend variation

This modular approach allows for flexibility in deployment while maintaining clear dependency separation.

## API Keys and Environment Variables

### Environment Variable Management
The project uses environment variables for sensitive information like API keys. Let's examine the example.env file:
```
GROQ_API_KEY=gsk...
```

### Cross-Platform Environment Variable Handling
Different platforms handle environment variables differently:
1. Unix/MacOS:
```bash
export GROQ_API_KEY=your_key_here
```

2. Windows Command Prompt:
```cmd
set GROQ_API_KEY=your_key_here
```

3. Windows PowerShell:
```powershell
$env:GROQ_API_KEY="your_key_here"
```

### Security Best Practices
1. Never commit API keys to version control
2. Use environment variables or secure key management systems
3. Implement proper error handling for missing keys
4. Regular key rotation and monitoring

## Project Structure Setup

### Understanding the Directory Layout
The g1 project uses a well-organized directory structure:
```
/
├── app.py              # Main Streamlit application
├── g1.py              # Core reasoning engine
├── requirements.txt    # Main requirements
├── gradio/            # Gradio implementation
├── ollama/            # Ollama implementation
└── tool-use/          # Extended functionality
```

### Cross-Platform Path Handling
When working with files and directories, always use platform-agnostic path handling:
```python
import os

# Correct way to handle paths
path = os.path.join('directory', 'file.txt')
```

## Development Tools Setup

### Editor Configuration
Recommended editor settings for consistent development:
1. Python language server configuration
2. Linting tools setup
3. Code formatting settings
4. Git integration

### Debugging Setup
Configure debugging tools for different implementations:
1. Streamlit debugging configuration
2. Gradio development server setup
3. API testing tools configuration

## Running the Application

### Starting the Main Application
```bash
streamlit run app.py
```

### Running Alternative Implementations
1. Gradio Implementation:
```bash
cd gradio
python app.py
```

2. Ollama Implementation:
```bash
cd ollama
streamlit run ollama_app.py
```

## Cross-Platform Testing

### Platform-Specific Considerations
1. File path handling
2. Environment variable management
3. Line ending differences
4. Package compatibility

### Testing Checklist
- Verify virtual environment activation works
- Confirm all dependencies install correctly
- Test environment variable loading
- Verify application startup
- Check API integrations
- Test file system operations

## Troubleshooting Common Issues

### Virtual Environment Issues
1. Python version mismatches
2. Activation script problems
3. Package installation errors

### API Integration Problems
1. Missing or invalid API keys
2. Network connectivity issues
3. Rate limiting considerations

### Platform-Specific Problems
1. Windows path length limitations
2. Unix permission issues
3. MacOS security restrictions

## Development Workflow Setup

### Version Control Integration
1. Git configuration
2. .gitignore setup
3. Branch management strategy

### Code Quality Tools
1. Linting configuration
2. Code formatting setup
3. Type checking integration

## Best Practices

### Environment Management
1. Keep virtual environments project-specific
2. Document all dependencies clearly
3. Use consistent naming conventions
4. Implement proper error handling

### Security Considerations
1. Secure API key management
2. Environment variable protection
3. Dependency vulnerability scanning
4. Access control implementation

## Practical Exercise
Set up a complete development environment:
1. Create and activate a virtual environment
2. Install all required dependencies
3. Configure environment variables
4. Test all implementations
5. Set up debugging tools
6. Verify cross-platform compatibility

## Next Steps
In the next lesson, we'll dive deep into the core components of g1, starting with the main application structure and how it implements the reasoning chain concept.

## Additional Resources
- Python Virtual Environments Documentation
- Streamlit Setup Guide
- Gradio Documentation
- Cross-Platform Python Development Guide
- Security Best Practices Documentation