# Module 3: Advanced Features
## Lesson 7: Tool Integration

### Lesson Overview

This lesson focuses on understanding and implementing tool integration within the g1 reasoning chain system. We'll explore how various tools enhance the system's capabilities and examine the implementation details of each tool integration. The lesson is structured to provide both theoretical understanding and practical implementation knowledge.

### Learning Objectives

By the end of this lesson, students will understand:
- The architecture of tool integration in g1
- Implementation of various tool types
- Security considerations in tool integration
- Best practices for error handling
- Performance optimization in tool usage

### Project Structure

Before diving into the implementation details, let's examine the relevant file structure for tool integration:

```
tool-use/
├── app.py                 # Main application file with UI implementation
├── g1_experimental.py     # Core implementation with tool integration
└── README.md             # Documentation
```

### 1. Tool Integration Architecture

The g1 system implements tool integration through a flexible architecture defined in g1_experimental.py. The system supports multiple tools including:

1. Calculator (Basic and Wolfram Alpha)
2. Code Executor
3. Web Search (via Exa.ai)
4. Page Content Fetcher
5. Wolfram Alpha Integration

Each tool is implemented as a separate function within the g1_experimental.py file, with a unified interface for tool invocation. The system uses a JSON-based communication protocol between the reasoning chain and tools.

### 2. Calculator Implementation

The calculator implementation in g1 comes in two forms:

a) Basic Calculator:
```python
def calculate(expression):
    try:
        return eval(expression, {"__builtins__": None}, {"math": math})
    except Exception as e:
        return f"Error: {str(e)}"
```

The basic calculator provides fundamental mathematical operations while maintaining security by restricting the evaluation context. It uses Python's math module for advanced mathematical functions while preventing access to potentially dangerous built-ins.

b) Wolfram Alpha Calculator:
```python
def wolfram_alpha_calculate(query):
    app_id = os.environ.get('WOLFRAM_APP_ID')
    if not app_id:
        return "Error: Wolfram Alpha App ID is not set in environment variables."
    
    url = 'https://api.wolframalpha.com/v2/query'
    params = {
        'appid': app_id,
        'input': query,
        'output': 'json',
    }
    # Implementation details...
```

The Wolfram Alpha integration provides advanced computational capabilities, handling complex mathematical operations, unit conversions, and more sophisticated calculations.

### 3. Code Executor Implementation

The code executor tool provides a secure environment for running Python code:

```python
def execute_code(code):
    try:
        result = subprocess.run(
            ['python3', '-c', code],
            capture_output=True,
            text=True,
            timeout=5,
            env={"PYTHONPATH": os.getcwd()}
        )
        return result.stdout if result.returncode == 0 else f"Error: {result.stderr}"
    except subprocess.TimeoutExpired:
        return "Error: Code execution timed out"
    except Exception as e:
        return f"Error: {str(e)}"
```

Security considerations in the code executor include:
- Timeout limitations (5 seconds)
- Subprocess isolation
- Error handling and output sanitization
- Environment restrictions

### 4. Web Search Integration

The web search functionality is implemented using the Exa.ai API:

```python
def web_search(query, num_results=5):
    try:
        search_results = exa.search_and_contents(
            query,
            type="auto",
            use_autoprompt=True,
            num_results=num_results,
            highlights=True,
            text=True
        )
        # Results formatting...
```

The web search implementation includes:
- Query optimization
- Result limitation
- Content highlighting
- Error handling
- Rate limiting considerations

### 5. Page Content Fetcher

The page content fetcher complements the web search functionality:

```python
def fetch_page_content(ids):
    try:
        page_contents = exa.get_contents(ids, text=True)
        # Content formatting...
```

This tool allows for detailed content retrieval from search results, implementing:
- Content caching
- Error handling
- Rate limiting
- Content sanitization

### 6. Tool Integration in the Reasoning Chain

The tools are integrated into the main reasoning chain through the generate_response function:

```python
def generate_response(prompt, custom_client=None):
    messages = [
        {
            "role": "system",
            "content": """You are an expert AI assistant..."""
        },
        # Message chain implementation...
    ]
```

The integration includes:
- Tool selection logic
- Response formatting
- Error handling
- Performance monitoring
- Rate limiting

### 7. Security Considerations

When implementing tool integration, several security measures are crucial:

1. Input Validation
   - All tool inputs are validated before execution
   - Input size limitations are enforced
   - Input sanitization is performed

2. Resource Limitations
   - Execution timeouts
   - Memory usage restrictions
   - API rate limiting

3. Environment Isolation
   - Subprocess containment
   - Limited environment variables
   - Restricted file system access

### 8. Performance Optimization

Tool integration performance is optimized through:

1. Caching Mechanisms
   - Results caching
   - API response caching
   - Cache invalidation strategies

2. Parallel Execution
   - Asynchronous API calls
   - Response streaming
   - Background processing

### 9. Error Handling

Robust error handling is implemented across all tools:

```python
try:
    # Tool execution
    result = execute_tool(input)
except ToolException as e:
    handle_tool_error(e)
except Exception as e:
    handle_general_error(e)
finally:
    cleanup_resources()
```

### 10. Testing and Validation

Each tool integration includes comprehensive testing:

1. Unit Tests
   - Individual tool functionality
   - Error handling
   - Edge cases

2. Integration Tests
   - Tool interaction
   - System integration
   - Performance testing

### Practical Exercises

1. Basic Tool Implementation
   - Implement a simple calculator tool
   - Add basic error handling
   - Implement input validation

2. Advanced Integration
   - Add Wolfram Alpha integration
   - Implement web search functionality
   - Add content fetching capabilities

3. Security Implementation
   - Add input sanitization
   - Implement resource limitations
   - Add error handling

### Additional Resources

1. API Documentation
   - Wolfram Alpha API documentation
   - Exa.ai API documentation
   - Python subprocess documentation

2. Security Resources
   - Python security best practices
   - API security guidelines
   - Input validation techniques

3. Performance Optimization
   - Caching strategies
   - Async programming in Python
   - Resource management techniques

### Next Steps

After completing this lesson, students should proceed to Lesson 8: API Integration, which builds upon the tool integration concepts covered here.