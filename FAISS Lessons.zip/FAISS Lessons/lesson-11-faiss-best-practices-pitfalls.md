# Lesson 11: FAISS Best Practices and Common Pitfalls

## Introduction

In this lesson, we'll explore best practices for using FAISS effectively and discuss common pitfalls that developers often encounter. By the end of this lesson, you'll have a deep understanding of how to choose the right metrics, handle high-dimensional data, maintain your indexes, avoid common mistakes, and optimize performance in your FAISS-based applications.

## Table of Contents

1. Choosing the Right Metric
2. Handling High-Dimensional Data Effectively
3. Dealing with Data Updates and Index Maintenance
4. Common Mistakes and How to Avoid Them
5. Performance Tuning and Benchmarking

## 1. Choosing the Right Metric

The choice of distance metric is crucial in FAISS as it directly impacts the relevance of your search results and the performance of your index. FAISS supports several metrics, and choosing the right one depends on your specific use case.

### 1.1 L2 Distance (Euclidean Distance)

L2 distance is the default and most commonly used metric in FAISS. It's suitable for many applications where you want to find the nearest neighbors in Euclidean space.

```python
import faiss

dimension = 128
index = faiss.IndexFlatL2(dimension)
```

Use L2 distance when:
- Your vectors represent points in Euclidean space
- You want to find the most similar items based on absolute distances

### 1.2 Inner Product

Inner product is useful when you want to find vectors that are the most aligned (have the highest dot product) with the query vector.

```python
import faiss

dimension = 128
index = faiss.IndexFlatIP(dimension)
```

Use inner product when:
- You're working with normalized vectors (e.g., word embeddings)
- You want to find the most similar items based on their direction, regardless of magnitude

### 1.3 Cosine Similarity

Cosine similarity is not directly supported in FAISS, but you can achieve it by normalizing your vectors and then using inner product.

```python
import faiss
import numpy as np

def normalize_vectors(vectors):
    return vectors / np.linalg.norm(vectors, axis=1)[:, np.newaxis]

dimension = 128
index = faiss.IndexFlatIP(dimension)

# Normalize vectors before adding to the index
normalized_vectors = normalize_vectors(vectors)
index.add(normalized_vectors)

# Normalize query before searching
normalized_query = normalize_vectors(query)
D, I = index.search(normalized_query, k)
```

Use cosine similarity when:
- You want to find the most similar items based on the angle between vectors, regardless of their magnitude
- You're working with text embeddings or other scenarios where vector direction is more important than magnitude

### 1.4 Impact on Performance and Accuracy

The choice of metric can significantly impact both performance and accuracy:

- L2 distance is generally faster to compute than inner product
- Inner product can be more accurate for certain types of data, especially when working with normalized vectors
- Cosine similarity (implemented via normalized vectors and inner product) can be more computationally expensive due to the normalization step, but may provide better results for certain applications

Always benchmark different metrics with your specific dataset to determine the best trade-off between performance and accuracy.

## 2. Handling High-Dimensional Data Effectively

High-dimensional data presents challenges due to the "curse of dimensionality." FAISS provides several techniques to handle high-dimensional data effectively.

### 2.1 Dimensionality Reduction Techniques

#### 2.1.1 Principal Component Analysis (PCA)

FAISS provides a built-in PCA implementation that can be used to reduce dimensionality:

```python
import faiss
import numpy as np

dimension = 1024
reduced_dimension = 128
num_vectors = 10000

# Generate random high-dimensional data
vectors = np.random.random((num_vectors, dimension)).astype('float32')

# Create a PCA matrix
pca_matrix = faiss.PCAMatrix(dimension, reduced_dimension)

# Train the PCA matrix
pca_matrix.train(vectors)

# Apply PCA to the vectors
reduced_vectors = pca_matrix.apply_py(vectors)

# Create an index with the reduced dimensionality
index = faiss.IndexFlatL2(reduced_dimension)
index.add(reduced_vectors)
```

#### 2.1.2 Product Quantization (PQ)

Product Quantization can be used to compress high-dimensional vectors:

```python
import faiss

dimension = 1024
num_subvectors = 64  # Number of subvectors to split the original vector into
bits_per_subvector = 8  # Number of bits to use for each subvector

index = faiss.IndexPQ(dimension, num_subvectors, bits_per_subvector)
index.train(vectors)
index.add(vectors)
```

### 2.2 Impact on Search Performance

When dealing with high-dimensional data:

- Use approximate search methods like IVF (Inverted File) or HNSW (Hierarchical Navigable Small World) instead of exhaustive search
- Experiment with different index parameters to find the optimal trade-off between search speed and accuracy
- Consider using GPU acceleration for faster search in high dimensions

```python
import faiss

dimension = 1024
nlist = 100  # Number of clusters for IVF
nprobe = 10  # Number of clusters to search

index = faiss.index_factory(dimension, f"IVF{nlist},Flat")
index.train(vectors)
index.add(vectors)
index.nprobe = nprobe
```

## 3. Dealing with Data Updates and Index Maintenance

As your dataset grows and changes, you'll need strategies for updating your FAISS index efficiently.

### 3.1 Strategies for Incremental Updates

#### 3.1.1 Adding New Vectors

For most FAISS indexes, you can simply add new vectors using the `add` method:

```python
import faiss

index = faiss.IndexFlatL2(dimension)
index.add(initial_vectors)

# Later, add new vectors
index.add(new_vectors)
```

#### 3.1.2 Removing Vectors

FAISS doesn't support direct removal of vectors from most index types. Instead, you can use an IDMap index to maintain a mapping of IDs to vectors:

```python
import faiss

base_index = faiss.IndexFlatL2(dimension)
index = faiss.IndexIDMap(base_index)

# Add vectors with IDs
index.add_with_ids(vectors, ids)

# Remove vectors
index.remove_ids(ids_to_remove)
```

### 3.2 When and How to Rebuild Indexes

In some cases, you may need to rebuild your index entirely:

- When the index becomes imbalanced due to many additions or removals
- When you want to change the index parameters or structure

To rebuild an index:

1. Create a new index with the desired parameters
2. Train the new index if necessary
3. Add all vectors to the new index
4. Replace the old index with the new one

```python
import faiss

old_index = # ... your existing index
vectors = # ... all vectors in your dataset

# Create and train new index
new_index = faiss.index_factory(dimension, "IVF100,PQ16")
new_index.train(vectors)

# Add vectors to the new index
new_index.add(vectors)

# Replace old index with new index
old_index = new_index
```

## 4. Common Mistakes and How to Avoid Them

### 4.1 Improper Data Normalization

Mistake: Not normalizing data consistently across training, indexing, and querying.

Solution: Always apply the same normalization to your training data, indexed vectors, and query vectors.

```python
import faiss
import numpy as np

def normalize_vectors(vectors):
    return vectors / np.linalg.norm(vectors, axis=1)[:, np.newaxis]

# Normalize training data
normalized_train = normalize_vectors(train_vectors)

# Create and train index
index = faiss.IndexFlatIP(dimension)
index.train(normalized_train)

# Normalize and add vectors to index
normalized_vectors = normalize_vectors(vectors)
index.add(normalized_vectors)

# Normalize query before searching
normalized_query = normalize_vectors(query)
D, I = index.search(normalized_query, k)
```

### 4.2 Mismatched Data Types

Mistake: Using different data types for training, indexing, and querying.

Solution: Consistently use the same data type (usually `float32`) throughout your FAISS operations.

```python
import faiss
import numpy as np

# Ensure all data is float32
train_data = train_data.astype(np.float32)
index_vectors = index_vectors.astype(np.float32)
query_vectors = query_vectors.astype(np.float32)

index = faiss.IndexFlatL2(dimension)
index.train(train_data)
index.add(index_vectors)
D, I = index.search(query_vectors, k)
```

### 4.3 Incorrect Parameter Settings

Mistake: Using default parameters without considering your specific use case.

Solution: Understand the meaning of each parameter and tune them based on your dataset and requirements.

```python
import faiss

dimension = 128
nlist = 100  # Number of clusters, adjust based on your dataset size
nprobe = 10  # Number of clusters to search, adjust based on speed/accuracy trade-off

index = faiss.index_factory(dimension, f"IVF{nlist},Flat")
index.train(train_vectors)
index.add(vectors)
index.nprobe = nprobe  # Set nprobe after training and adding vectors
```

## 5. Performance Tuning and Benchmarking

### 5.1 Systematic Approach to Optimization

1. Establish a baseline: Start with a simple index (e.g., FlatL2) and measure its performance.
2. Identify bottlenecks: Use profiling tools to find performance bottlenecks.
3. Experiment with index types: Try different index types (IVF, HNSW, PQ) and compare their performance.
4. Tune parameters: Adjust parameters like `nlist`, `nprobe`, `M` (for HNSW) to optimize performance.
5. Consider hardware: Evaluate CPU vs. GPU performance for your specific use case.

### 5.2 Tools and Techniques for Benchmarking

#### 5.2.1 Use the FAISS Benchmarking Tools

FAISS provides built-in benchmarking tools:

```python
import faiss

dimension = 128
nb = 100000  # database size
nq = 10000   # nb of queries
np.random.seed(1234)
xb = np.random.random((nb, dimension)).astype('float32')
xq = np.random.random((nq, dimension)).astype('float32')

index = faiss.index_factory(dimension, "IVF100,Flat")
index.train(xb)
index.add(xb)

k = 10  # number of nearest neighbors
D, I = index.search(xq, k)

# Compute recalls
gt_index = faiss.IndexFlatL2(dimension)
gt_index.add(xb)
gt_D, gt_I = gt_index.search(xq, k)

n_ok = (I == gt_I).sum()
recall = n_ok / (nq * k)
print(f"Recall@{k}: {recall:.4f}")
```

#### 5.2.2 Measure Query Time

```python
import time

start_time = time.time()
D, I = index.search(xq, k)
end_time = time.time()

query_time = end_time - start_time
qps = nq / query_time  # queries per second

print(f"Query time: {query_time:.4f} seconds")
print(f"Queries per second: {qps:.2f}")
```

#### 5.2.3 Memory Usage

Monitor memory usage to ensure your index fits within available RAM:

```python
import psutil
import os

def get_memory_usage():
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / (1024 * 1024)  # in MB

print(f"Memory usage: {get_memory_usage():.2f} MB")
```

### 5.3 Optimization Tips

- Use `IVFFlat` for a good balance between speed and accuracy
- For large datasets, consider using `IVFPQ` for memory efficiency
- For very high recall requirements, use `HNSW`
- Adjust `nprobe` (for IVF indexes) or `efSearch` (for HNSW) to trade off between speed and accuracy
- Use GPU acceleration for large-scale similarity search tasks
- Implement caching for frequent queries to improve overall system performance

## Conclusion

In this lesson, we've covered best practices for using FAISS effectively and discussed common pitfalls to avoid. We've explored the importance of choosing the right metric, handling high-dimensional data, maintaining indexes, avoiding common mistakes, and optimizing performance through systematic benchmarking and tuning.

By applying these best practices and being aware of potential pitfalls, you'll be well-equipped to build efficient and accurate similarity search systems using FAISS. Remember that the optimal configuration often depends on your specific use case, dataset characteristics, and performance requirements, so always benchmark and profile your system to find the best solution.

In the next and final lesson, we'll look at advanced topics and future directions in vector similarity search and FAISS development.

