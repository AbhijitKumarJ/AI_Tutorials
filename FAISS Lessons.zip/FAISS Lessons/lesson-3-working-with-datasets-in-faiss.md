# Lesson 3: Working with Datasets in FAISS

## 1. Preparing Data for FAISS: Normalization and Preprocessing Techniques

Proper data preparation is crucial for optimal performance in FAISS. Here are key steps:

### Data Type Conversion

FAISS works best with 32-bit float arrays. Convert your data if necessary:

```python
import numpy as np

data = np.array([[1, 2, 3], [4, 5, 6]])
data = data.astype('float32')
```

### Normalization

Normalizing vectors can improve search accuracy, especially for inner product similarity:

```python
from sklearn.preprocessing import normalize

# L2 normalization
data_l2 = normalize(data, norm='l2')

# Alternative using FAISS
faiss.normalize_L2(data)
```

### Dimensionality Reduction

For high-dimensional data, consider reducing dimensions:

```python
from sklearn.decomposition import PCA

pca = PCA(n_components=32)
data_reduced = pca.fit_transform(data).astype('float32')

# Alternative using FAISS
d = data.shape[1]  # original dimension
d_out = 32  # target dimension
pca_matrix = faiss.PCAMatrix(d, d_out)
pca_matrix.train(data)
data_reduced = pca_matrix.apply(data)
```

### Handling Missing Values

FAISS doesn't handle NaN or infinity values. Replace or remove them:

```python
data = np.nan_to_num(data)  # replaces NaN with 0 and inf with large finite numbers
```

## 2. NumPy Integration with FAISS: Data Types and Array Manipulations

FAISS is designed to work seamlessly with NumPy arrays. Here are some key points:

### Data Types

FAISS primarily uses `float32` for vector components and `int64` for indices:

```python
vectors = np.random.rand(1000, 128).astype('float32')
indices = np.arange(1000).astype('int64')
```

### Array Manipulations

You can use NumPy operations to prepare data for FAISS:

```python
# Concatenate multiple arrays
vectors_combined = np.concatenate([vectors1, vectors2], axis=0)

# Slice arrays
vectors_subset = vectors[::2]  # every other vector

# Reshape if necessary
vectors_reshaped = vectors.reshape(-1, 128)
```

## 3. Adding Vectors to an Index: Batch Addition and Memory Management

Adding vectors to a FAISS index is straightforward, but there are considerations for large datasets:

### Basic Addition

For small to medium datasets, you can add all vectors at once:

```python
index = faiss.IndexFlatL2(128)
index.add(vectors)
```

### Batch Addition

For large datasets, add vectors in batches to manage memory:

```python
batch_size = 10000
for i in range(0, len(vectors), batch_size):
    index.add(vectors[i:i+batch_size])
```

### Adding with IDs

If you want to specify custom IDs for your vectors:

```python
index = faiss.IndexIDMap(faiss.IndexFlatL2(128))
index.add_with_ids(vectors, indices)
```

## 4. Performing Basic Search Operations: Syntax and Result Interpretation

FAISS provides two main types of search operations:

### k-Nearest Neighbors Search

```python
k = 5
D, I = index.search(query_vectors, k)

# Interpret results
for i in range(len(query_vectors)):
    print(f"Query {i}:")
    for j in range(k):
        print(f"  Neighbor {j}: ID = {I[i][j]}, Distance = {D[i][j]}")
```

### Range Search

```python
radius = 10.0
lims, D, I = index.range_search(query_vectors, radius)

# Interpret results
for i in range(len(query_vectors)):
    print(f"Query {i}:")
    start, end = lims[i], lims[i+1]
    for j in range(start, end):
        print(f"  Neighbor: ID = {I[j]}, Distance = {D[j]}")
```

## 5. Handling Large Datasets Efficiently

When working with datasets that don't fit in memory, consider these techniques:

### Chunking Large Datasets

Process and add data in chunks:

```python
def process_in_chunks(filename, chunk_size=10000):
    index = faiss.IndexFlatL2(128)
    with open(filename, 'rb') as f:
        while True:
            chunk = np.fromfile(f, dtype='float32', count=chunk_size*128)
            if not chunk.size:
                break
            chunk = chunk.reshape(-1, 128)
            index.add(chunk)
    return index

index = process_in_chunks('large_dataset.bin')
```

### Memory-Mapped Files

Use memory-mapped files for datasets that don't fit in RAM:

```python
import numpy as np

# Create a memory-mapped array
fp = np.memmap('large_dataset.dat', dtype='float32', mode='r', shape=(1000000, 128))

# Use the memory-mapped array with FAISS
index = faiss.IndexFlatL2(128)
batch_size = 10000
for i in range(0, fp.shape[0], batch_size):
    index.add(fp[i:i+batch_size])
```

### On-Disk Storage Options

For extremely large datasets, consider using FAISS's on-disk storage:

```python
import faiss

# Create an on-disk index
index = faiss.index_factory(128, "IVF1024,Flat")
index_ivf = faiss.extract_index_ivf(index)
index_ivf.make_direct_map()

# Write the index to disk
faiss.write_index(index, "large_index.faiss")

# Later, read and use the index
index = faiss.read_index("large_index.faiss")
```

## 6. Benchmarking Dataset Operations for Different Sizes

Benchmarking is crucial to understand the performance characteristics of your FAISS setup. Here's a simple benchmarking script:

```python
import time
import numpy as np
import faiss

def benchmark_faiss(d, nb, nq, index_factory):
    print(f"Benchmarking: d={d}, nb={nb}, nq={nq}, index={index_factory}")
    
    # Generate data
    xb = np.random.random((nb, d)).astype('float32')
    xq = np.random.random((nq, d)).astype('float32')

    # Create and train index
    index = faiss.index_factory(d, index_factory)
    if index_factory != 'Flat':
        start = time.time()
        index.train(xb)
        print(f"  Train time: {time.time() - start:.3f}s")

    # Add vectors
    start = time.time()
    index.add(xb)
    print(f"  Add time: {time.time() - start:.3f}s")

    # Search
    k = 10
    start = time.time()
    D, I = index.search(xq, k)
    print(f"  Search time: {time.time() - start:.3f}s")

    # Memory usage
    print(f"  Index size: {index.ntotal}")
    print(f"  Memory usage: {index.get_memory_usage() / (1024**2):.2f} MB")

# Run benchmarks
for d in [64, 128, 256]:
    for nb in [10000, 100000, 1000000]:
        for index_type in ['Flat', 'IVF100,Flat', 'IVF100,PQ16']:
            benchmark_faiss(d, nb, 1000, index_type)
        print()
```

This script benchmarks different index types for various dataset sizes and dimensions, measuring training time, addition time, search time, and memory usage.

## Summary

In this lesson, we've covered:
- Data preparation techniques for FAISS, including normalization and preprocessing
- NumPy integration with FAISS
- Adding vectors to FAISS indexes, including batch addition
- Performing and interpreting basic search operations
- Techniques for handling large datasets efficiently
- Benchmarking FAISS operations for different dataset sizes

In the next lesson, we'll dive deeper into advanced indexing techniques, exploring more complex index structures and their use cases.

## Further Reading

1. [FAISS Preprocessing and Training](https://github.com/facebookresearch/faiss/wiki/Preprocessing-and-training) - Official wiki page on data preparation
2. [Dealing with Large Datasets](https://github.com/facebookresearch/faiss/wiki/Dealing-with-large-datasets) - FAISS guide on handling large-scale data
3. [Faster search CPUs](https://github.com/facebookresearch/faiss/wiki/Faster-search-CPUs) - Tips for optimizing FAISS performance on CPUs
4. "Billion-scale similarity search with GPUs" by Johnson et al. - Research paper discussing large-scale similarity search
5. [NumPy documentation](https://numpy.org/doc/stable/) - For more advanced NumPy operations that can be useful in data preparation

