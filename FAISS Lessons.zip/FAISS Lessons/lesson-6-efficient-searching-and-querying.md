# FAISS Lesson 6: Efficient Searching and Querying

## Introduction

In this lesson, we'll dive deep into efficient searching and querying techniques using FAISS. We'll explore various search parameters, optimizing search speed vs. accuracy, batch searching, range searches, and implementing fast k-nearest neighbor (KNN) search. By the end of this lesson, you'll have a comprehensive understanding of how to perform efficient searches with FAISS.

## Table of Contents

1. Understanding Search Parameters in Depth
2. Optimizing Search Speed vs Accuracy
3. Batch Searching for Improved Performance
4. Range Searches and Their Applications
5. Implementing Fast KNN Search

## 1. Understanding Search Parameters in Depth

Different index types in FAISS have various parameters that affect search performance. Let's explore the most important ones:

### IVF-based Indexes: nprobe

For IVF (Inverted File) based indexes like IndexIVFFlat or IndexIVFPQ, the most important search parameter is `nprobe`.

- `nprobe`: The number of nearest inverted lists to search.

```python
import numpy as np
import faiss

# Sample data
d = 64  # dimensions
nb = 100000  # database size
nq = 1000  # num of queries
np.random.seed(1234)
xb = np.random.random((nb, d)).astype('float32')
xq = np.random.random((nq, d)).astype('float32')

# Create and train an IVF index
nlist = 100
quantizer = faiss.IndexFlatL2(d)
index = faiss.IndexIVFFlat(quantizer, d, nlist)
index.train(xb)
index.add(xb)

# Search with different nprobe values
k = 5  # top k results
for nprobe in [1, 10, 50, 100]:
    index.nprobe = nprobe
    D, I = index.search(xq, k)
    print(f"nprobe = {nprobe}: First query results:")
    for i in range(k):
        print(f"  {i+1}. ID: {I[0, i]}, Distance: {D[0, i]}")
```

### HNSW Indexes: efSearch

For HNSW (Hierarchical Navigable Small World) indexes, the main search parameter is `efSearch`.

- `efSearch`: The size of the dynamic candidate list during search.

```python
# Create an HNSW index
M = 16  # number of connections per layer
index_hnsw = faiss.IndexHNSWFlat(d, M)
index_hnsw.add(xb)

# Search with different efSearch values
for ef_search in [10, 50, 100, 200]:
    index_hnsw.hnsw.efSearch = ef_search
    D, I = index_hnsw.search(xq, k)
    print(f"efSearch = {ef_search}: First query results:")
    for i in range(k):
        print(f"  {i+1}. ID: {I[0, i]}, Distance: {D[0, i]}")
```

## 2. Optimizing Search Speed vs Accuracy

There's often a trade-off between search speed and accuracy. Here's how to measure and optimize this trade-off:

```python
import time

def benchmark_index(index, xq, k, ground_truth):
    start_time = time.time()
    D, I = index.search(xq, k)
    search_time = time.time() - start_time
    
    recall = faiss.eval_recall_at_r(index, xq, ground_truth, 1)
    
    return search_time, recall

# Create a ground truth index (exact search)
index_flat = faiss.IndexFlatL2(d)
index_flat.add(xb)
_, ground_truth = index_flat.search(xq, k)

# Benchmark IVF index with different nprobe values
index_ivf = faiss.IndexIVFFlat(quantizer, d, nlist)
index_ivf.train(xb)
index_ivf.add(xb)

for nprobe in [1, 10, 50, 100, 200]:
    index_ivf.nprobe = nprobe
    search_time, recall = benchmark_index(index_ivf, xq, k, ground_truth)
    print(f"IVF - nprobe: {nprobe}, Time: {search_time:.4f}s, Recall@1: {recall:.4f}")

# Benchmark HNSW index with different efSearch values
for ef_search in [10, 50, 100, 200, 400]:
    index_hnsw.hnsw.efSearch = ef_search
    search_time, recall = benchmark_index(index_hnsw, xq, k, ground_truth)
    print(f"HNSW - efSearch: {ef_search}, Time: {search_time:.4f}s, Recall@1: {recall:.4f}")
```

## 3. Batch Searching for Improved Performance

Batch searching can significantly improve performance by amortizing overheads across multiple queries:

```python
def batch_search(index, queries, k, batch_size=1000):
    nq = queries.shape[0]
    all_D, all_I = [], []
    
    for i in range(0, nq, batch_size):
        batch = queries[i:i+batch_size]
        D, I = index.search(batch, k)
        all_D.append(D)
        all_I.append(I)
    
    return np.vstack(all_D), np.vstack(all_I)

# Compare single query vs batch search
single_start = time.time()
D_single, I_single = index_ivf.search(xq, k)
single_time = time.time() - single_start

batch_start = time.time()
D_batch, I_batch = batch_search(index_ivf, xq, k)
batch_time = time.time() - batch_start

print(f"Single query time: {single_time:.4f}s")
print(f"Batch query time: {batch_time:.4f}s")
print(f"Speedup: {single_time / batch_time:.2f}x")

# Verify results are the same
assert np.all(I_single == I_batch), "Results differ between single and batch search"
```

## 4. Range Searches and Their Applications

Range search finds all vectors within a specified distance from the query vector. This is useful for tasks like finding all similar items within a certain threshold.

```python
def perform_range_search(index, xq, radius):
    lims, D, I = index.range_search(xq, radius)
    return lims, D, I

# Perform range search on IVF index
index_ivf.nprobe = 10  # Set a reasonable nprobe value
radius = 0.5  # Set an appropriate radius for your data

lims, D, I = perform_range_search(index_ivf, xq[:5], radius)

for i in range(5):  # Print results for first 5 queries
    start, end = lims[i], lims[i+1]
    print(f"Query {i}: Found {end - start} results within radius {radius}")
    for j in range(start, end):
        print(f"  ID: {I[j]}, Distance: {D[j]}")

# Application: Clustering
def simple_clustering(index, xb, radius):
    clusters = {}
    for i in range(xb.shape[0]):
        lims, D, I = perform_range_search(index, xb[i:i+1], radius)
        clusters[i] = I[lims[0]:lims[1]].tolist()
    return clusters

sample_size = 1000  # Use a subset for demonstration
clusters = simple_clustering(index_ivf, xb[:sample_size], radius)

print(f"Number of clusters: {len(clusters)}")
print("Sample cluster sizes:", [len(cluster) for cluster in list(clusters.values())[:5]])
```

## 5. Implementing Fast KNN Search

To implement fast k-nearest neighbor (KNN) search, we'll use appropriate index structures, optimize search parameters, and leverage GPU acceleration if available.

### Using Appropriate Index Structures

For large-scale KNN search, HNSW and IVF-based indexes are generally the best choices:

```python
# HNSW for fast, accurate searches
index_hnsw = faiss.IndexHNSWFlat(d, M=16)
index_hnsw.add(xb)

# IVF-PQ for memory-efficient searches
nlist = 100
m = 8  # number of subquantizers
bits = 8  # bits per subquantizer
index_ivfpq = faiss.IndexIVFPQ(quantizer, d, nlist, m, bits)
index_ivfpq.train(xb)
index_ivfpq.add(xb)
```

### Optimizing Search Parameters

We've already covered parameter optimization, but here's a quick example of finding optimal parameters:

```python
def find_optimal_params(index, xq, k, ground_truth, param_name, param_values):
    best_recall = 0
    best_param = None
    best_time = float('inf')
    
    for param in param_values:
        if param_name == 'nprobe':
            index.nprobe = param
        elif param_name == 'efSearch':
            index.hnsw.efSearch = param
        
        search_time, recall = benchmark_index(index, xq, k, ground_truth)
        
        if recall > best_recall or (recall == best_recall and search_time < best_time):
            best_recall = recall
            best_param = param
            best_time = search_time
    
    return best_param, best_recall, best_time

# Find optimal nprobe for IVF-PQ
best_nprobe, best_recall, best_time = find_optimal_params(
    index_ivfpq, xq, k, ground_truth, 'nprobe', [1, 5, 10, 20, 50, 100]
)
print(f"Optimal nprobe: {best_nprobe}, Recall: {best_recall:.4f}, Time: {best_time:.4f}s")

# Find optimal efSearch for HNSW
best_ef, best_recall, best_time = find_optimal_params(
    index_hnsw, xq, k, ground_truth, 'efSearch', [10, 20, 40, 80, 100, 200]
)
print(f"Optimal efSearch: {best_ef}, Recall: {best_recall:.4f}, Time: {best_time:.4f}s")
```

### Leveraging GPU Acceleration

If you have a GPU available, you can use it to speed up searches:

```python
import faiss.contrib.torch_utils

def gpu_search(index, xq, k):
    res = faiss.StandardGpuResources()
    gpu_index = faiss.index_cpu_to_gpu(res, 0, index)
    
    start_time = time.time()
    D, I = gpu_index.search(xq, k)
    gpu_time = time.time() - start_time
    
    return D, I, gpu_time

# Compare CPU vs GPU search times
cpu_start = time.time()
D_cpu, I_cpu = index_ivfpq.search(xq, k)
cpu_time = time.time() - cpu_start

D_gpu, I_gpu, gpu_time = gpu_search(index_ivfpq, xq, k)

print(f"CPU search time: {cpu_time:.4f}s")
print(f"GPU search time: {gpu_time:.4f}s")
print(f"GPU speedup: {cpu_time / gpu_time:.2f}x")

# Verify results are the same (allowing for small float differences)
assert np.allclose(D_cpu, D_gpu, atol=1e-5), "GPU and CPU distances differ"
assert np.all(I_cpu == I_gpu), "GPU and CPU indices differ"
```

## Conclusion

In this lesson, we've covered efficient searching and querying techniques using FAISS. We explored search parameters in depth, optimized the trade-off between search speed and accuracy, implemented batch searching for improved performance, performed range searches, and implemented fast KNN search using appropriate index structures and GPU acceleration.

Remember that the best approach will depend on your specific use case, dataset characteristics, and hardware capabilities. Always benchmark different strategies to find the optimal solution for your application.

## File Layout

Here's a suggested file layout for organizing the code examples in this lesson:

```
faiss_tutorial/
│
├── lesson_6/
│   ├── __init__.py
│   ├── search_parameters.py
│   ├── speed_vs_accuracy.py
│   ├── batch_search.py
│   ├── range_search.py
│   ├── fast_knn.py
│   └── gpu_acceleration.py
│
└── data/
    ├── sample_vectors.npy
    └── sample_queries.npy
```

You can create separate Python files for each main topic covered in the lesson. The sample vectors and queries can be stored in NumPy files in the data directory.

