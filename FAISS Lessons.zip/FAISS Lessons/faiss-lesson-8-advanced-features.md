# FAISS Lesson 8: Advanced FAISS Features

## Introduction

In this lesson, we'll explore advanced features of FAISS that allow for more efficient and specialized vector similarity search operations. We'll cover binary indexes, strategies for handling billion-scale datasets, composite indexes, techniques for high-dimensional data, and methods for dynamically updating indexes.

## Table of Contents

1. [Binary Indexes](#1-binary-indexes)
2. [IVF for Billion-Scale Datasets](#2-ivf-for-billion-scale-datasets)
3. [Composite Indexes](#3-composite-indexes)
4. [Dealing with High-Dimensional Data](#4-dealing-with-high-dimensional-data)
5. [Dynamic Index Updates and Maintenance](#5-dynamic-index-updates-and-maintenance)
6. [Best Practices and Considerations](#6-best-practices-and-considerations)
7. [Exercises](#7-exercises)
8. [Conclusion](#8-conclusion)

## 1. Binary Indexes

Binary indexes in FAISS are designed for memory efficiency and fast similarity search on binary vectors. They are particularly useful when working with binary descriptors or hash codes.

### 1.1 Creating a Binary Index

To create a binary index, you can use the `IndexBinaryFlat` class:

```python
import numpy as np
import faiss

d = 256  # dimension (must be a multiple of 8)
nb = 10000  # database size
nq = 1000  # number of queries

# Generate random binary vectors
xb = np.random.randint(256, size=(nb, d // 8)).astype('uint8')
xq = np.random.randint(256, size=(nq, d // 8)).astype('uint8')

# Create and add vectors to the index
index = faiss.IndexBinaryFlat(d)
index.add(xb)

# Perform a search
k = 10  # number of nearest neighbors
D, I = index.search(xq, k)
```

### 1.2 Binary Index Types

FAISS provides several types of binary indexes:

- `IndexBinaryFlat`: Exact search for binary vectors
- `IndexBinaryIVF`: Inverted file index for binary vectors
- `IndexBinaryHash`: Hash-based index for binary vectors

### 1.3 Use Cases for Binary Indexes

Binary indexes are particularly useful in scenarios such as:

- Image matching with binary descriptors (e.g., ORB, BRIEF)
- Locality-Sensitive Hashing (LSH) for approximate nearest neighbor search
- Hamming distance-based similarity search

## 2. IVF for Billion-Scale Datasets

Inverted File (IVF) indexes in FAISS can be optimized to handle billion-scale datasets efficiently.

### 2.1 Creating an IVF Index for Large Datasets

When dealing with very large datasets, you'll want to use an IVF index with a large number of clusters:

```python
import numpy as np
import faiss

d = 128  # dimension
nb = 1_000_000_000  # 1 billion vectors
nlist = 1_000_000  # number of clusters

# Create the index
quantizer = faiss.IndexFlatL2(d)
index = faiss.IndexIVFFlat(quantizer, d, nlist, faiss.METRIC_L2)

# Train the index (you'll need a representative sample of your data)
ntrain = 10_000_000
train_data = np.random.random((ntrain, d)).astype('float32')
index.train(train_data)

# Add vectors in batches
batch_size = 1_000_000
for i in range(0, nb, batch_size):
    xb = np.random.random((batch_size, d)).astype('float32')
    index.add(xb)
```

### 2.2 Optimizing Search Parameters

For billion-scale datasets, you'll need to carefully tune the `nprobe` parameter to balance search speed and accuracy:

```python
# Set nprobe for search
index.nprobe = 1000  # Increase this for better accuracy, decrease for faster search

# Perform search
k = 10
xq = np.random.random((1, d)).astype('float32')
D, I = index.search(xq, k)
```

### 2.3 Using On-Disk Storage

For datasets that don't fit in memory, FAISS provides on-disk storage options:

```python
import faiss

# Create an on-disk IVF index
index = faiss.index_factory(d, "IVF1000000,Flat")
index_ivf = faiss.extract_index_ivf(index)

# Create on-disk inverted lists
invlists = faiss.OnDiskInvertedLists(index_ivf.nlist, index_ivf.code_size,
                                     "/path/to/store/invlists")
index_ivf.replace_invlists(invlists)

# Train and add vectors as before
```

## 3. Composite Indexes

Composite indexes in FAISS allow you to combine different index types to leverage their respective strengths.

### 3.1 Creating a Composite Index

A common composite index is the `IndexIVFPQ`, which combines an IVF structure with Product Quantization:

```python
import numpy as np
import faiss

d = 128  # dimension
nb = 1_000_000  # database size
nlist = 1000  # number of clusters
m = 8  # number of subquantizers in PQ
nbits = 8  # bits per subquantizer

# Create the index
quantizer = faiss.IndexFlatL2(d)
index = faiss.IndexIVFPQ(quantizer, d, nlist, m, nbits)

# Train and add vectors
train_data = np.random.random((100000, d)).astype('float32')
index.train(train_data)

xb = np.random.random((nb, d)).astype('float32')
index.add(xb)
```

### 3.2 Other Composite Index Types

FAISS offers various composite index types, including:

- `IndexIVFFlat`: Combines IVF with exact vector storage
- `IndexIVFPQR`: IVF with Product Quantization and re-ranking
- `IndexHNSWFlat`: Hierarchical Navigable Small World graph with exact vector storage

### 3.3 Choosing the Right Composite Index

The choice of composite index depends on your specific requirements:

- `IndexIVFPQ`: Good balance between search speed and memory usage
- `IndexIVFFlat`: Fast search with higher memory usage
- `IndexHNSWFlat`: Very fast search, but high memory usage and slow construction

## 4. Dealing with High-Dimensional Data

High-dimensional data can be challenging due to the "curse of dimensionality". FAISS provides several techniques to handle high-dimensional vectors efficiently.

### 4.1 Dimensionality Reduction

One approach is to use dimensionality reduction techniques before indexing:

```python
import numpy as np
import faiss

d_original = 1024  # original dimension
d_reduced = 128  # reduced dimension
nb = 1_000_000

# Create a random projection matrix
matrix = np.random.random((d_original, d_reduced)).astype('float32')

# Create a precomputed transformation
pca = faiss.PCAMatrix(d_original, d_reduced)
pca.train(matrix)

# Create an index with the precomputed transformation
index = faiss.index_factory(d_original, f"PCA{d_reduced},IVF1000,Flat")
index.train(np.random.random((100000, d_original)).astype('float32'))

# Add vectors
xb = np.random.random((nb, d_original)).astype('float32')
index.add(xb)
```

### 4.2 Using Product Quantization

Product Quantization can be effective for high-dimensional data:

```python
d = 512  # high dimension
m = 64  # number of subquantizers
nbits = 8  # bits per subquantizer

index = faiss.index_factory(d, f"IVF1000,PQ{m}x{nbits}")
```

### 4.3 Optimizing Search Parameters

For high-dimensional data, you may need to adjust search parameters:

```python
index.nprobe = 100  # increase for better accuracy
faiss.ParameterSpace().set_index_parameter(index, "efSearch", 100)  # for HNSW-based indexes
```

## 5. Dynamic Index Updates and Maintenance

FAISS allows for dynamic updates to indexes, including adding and removing vectors.

### 5.1 Adding Vectors to an Existing Index

You can add vectors to an existing index at any time:

```python
# Assuming 'index' is an existing trained index
new_vectors = np.random.random((10000, d)).astype('float32')
index.add(new_vectors)
```

### 5.2 Removing Vectors from an Index

Removing vectors is supported for some index types:

```python
import faiss

# Create an IDSelector to specify which vectors to remove
sel = faiss.IDSelectorRange(100, 200)  # remove vectors with IDs 100-199

# Remove the selected vectors
num_removed = index.remove_ids(sel)
```

### 5.3 Retraining and Rebalancing Indexes

For optimal performance, you may need to retrain or rebalance the index periodically:

```python
# Retrain the index with updated data
new_train_data = np.random.random((100000, d)).astype('float32')
index.train(new_train_data)

# For IVF indexes, you can rebalance the inverted lists
if isinstance(index, faiss.IndexIVF):
    index.invlists.rebalance()
```

## 6. Best Practices and Considerations

When working with advanced FAISS features, keep these best practices in mind:

1. **Memory Management**: Monitor memory usage, especially with large datasets or high-dimensional data.
2. **Index Selection**: Choose the appropriate index type based on your dataset size, dimension, and performance requirements.
3. **Parameter Tuning**: Experiment with parameters like `nprobe`, `efSearch`, and `nlist` to find the optimal balance between speed and accuracy.
4. **Incremental Updates**: For dynamic datasets, consider using indexes that support efficient updates (e.g., `IndexIVFFlat`).
5. **Dimensionality Reduction**: Use techniques like PCA or random projections for very high-dimensional data.
6. **Evaluation**: Regularly evaluate your index's performance in terms of accuracy, speed, and memory usage as your dataset evolves.

## 7. Exercises

1. Create a binary index for a set of binary descriptors (e.g., ORB features from images). Compare its performance with a standard float index.

2. Implement a billion-scale similarity search system using FAISS. Use synthetic data and focus on optimizing for both speed and memory usage.

3. Experiment with different composite indexes (e.g., `IndexIVFPQ`, `IndexIVFPQR`, `IndexHNSWFlat`) on a high-dimensional dataset. Compare their performance in terms of speed, accuracy, and memory usage.

4. Implement a dimensionality reduction pipeline using PCA before indexing. Compare the performance of the reduced-dimension index with the full-dimension index.

5. Create a dynamic index that supports adding and removing vectors. Implement a scenario where you periodically update the index and measure how the performance changes over time.

## 8. Conclusion

In this lesson, we've explored advanced FAISS features that enable efficient similarity search on various types of data and at different scales. We've covered binary indexes for memory-efficient operations, strategies for handling billion-scale datasets, composite indexes for balancing performance trade-offs, techniques for high-dimensional data, and methods for dynamically updating indexes.

These advanced features allow you to fine-tune FAISS for specific use cases and performance requirements. As you work with these features, remember to continually evaluate and optimize your indexes based on your evolving data and application needs.

In the next lesson, we'll dive into specific applications of FAISS, including image similarity search, text embeddings and semantic search, and recommendation systems.

