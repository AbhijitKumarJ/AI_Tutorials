# Lesson 10: Optimizing FAISS for Production

## Introduction

In this lesson, we'll dive deep into optimizing FAISS for production environments. We'll cover memory management, serialization, integration with web services, scaling for distributed systems, and monitoring. By the end of this lesson, you'll have a comprehensive understanding of how to deploy and maintain FAISS in real-world, large-scale applications.

## Table of Contents

1. Memory Management Techniques
2. Serialization and Deserialization of Indexes
3. Integrating FAISS with Web Services
4. Scaling FAISS for Distributed Systems
5. Monitoring and Logging FAISS Operations

## 1. Memory Management Techniques

Efficient memory management is crucial when working with large-scale similarity search systems. FAISS provides several ways to manage memory effectively, both for RAM and GPU memory.

### 1.1 Efficient use of RAM

When working with large datasets, it's important to be mindful of RAM usage. Here are some techniques to optimize RAM usage:

a) Use memory-mapped files:
For large datasets that don't fit in RAM, you can use memory-mapped files to access the data without loading it all into memory at once.

```python
import numpy as np

# Create a memory-mapped array
mmap_array = np.memmap('large_dataset.dat', dtype='float32', mode='r', shape=(1000000, 128))

# Use the memory-mapped array with FAISS
import faiss
index = faiss.IndexFlatL2(128)
index.add(mmap_array)
```

b) Implement a data loader:
For extremely large datasets, implement a custom data loader that reads data in chunks:

```python
class ChunkDataLoader:
    def __init__(self, filename, chunk_size, vector_dim):
        self.filename = filename
        self.chunk_size = chunk_size
        self.vector_dim = vector_dim

    def __iter__(self):
        with open(self.filename, 'rb') as f:
            while True:
                chunk = np.fromfile(f, dtype='float32', count=self.chunk_size * self.vector_dim)
                if not chunk:
                    break
                yield chunk.reshape(-1, self.vector_dim)

# Use the chunk data loader
loader = ChunkDataLoader('large_dataset.bin', chunk_size=10000, vector_dim=128)
index = faiss.IndexFlatL2(128)

for chunk in loader:
    index.add(chunk)
```

### 1.2 GPU Memory Management

When using GPU-accelerated FAISS, managing GPU memory is crucial:

a) Use `StandardGpuResources` to manage GPU memory:

```python
import faiss

# Create GPU resources
res = faiss.StandardGpuResources()

# Configure GPU resources
res.setTempMemory(1024 * 1024 * 1024)  # 1GB of temporary memory

# Create a GPU index
index = faiss.GpuIndexFlatL2(res, 128)
```

b) Implement pinned memory for faster CPU-GPU transfers:

```python
import faiss

# Create GPU resources
res = faiss.StandardGpuResources()

# Allocate pinned memory
res.setPinnedMemory(1024 * 1024 * 1024)  # 1GB of pinned memory

# Create a GPU index
index = faiss.GpuIndexFlatL2(res, 128)
```

### 1.3 Swapping between CPU and GPU

For datasets that don't fit in GPU memory, you can implement a strategy to swap between CPU and GPU:

```python
import faiss

# Create CPU index
cpu_index = faiss.IndexFlatL2(128)

# Add vectors to CPU index
cpu_index.add(large_dataset)

# Create GPU resources
res = faiss.StandardGpuResources()

# Transfer a subset to GPU for search
gpu_index = faiss.index_cpu_to_gpu(res, 0, cpu_index, 2**20)  # Transfer 1M vectors

# Perform search on GPU
D, I = gpu_index.search(queries, k)

# Transfer results back to CPU if needed
cpu_D, cpu_I = faiss.swig_ptr(D), faiss.swig_ptr(I)
```

## 2. Serialization and Deserialization of Indexes

Serialization allows you to save and load FAISS indexes, which is crucial for persisting your indexes and sharing them across different processes or machines.

### 2.1 Saving and Loading Indexes

Basic saving and loading of indexes:

```python
import faiss

# Save index
faiss.write_index(index, "my_index.faiss")

# Load index
loaded_index = faiss.read_index("my_index.faiss")
```

### 2.2 Versioning Considerations

When saving indexes, it's important to consider versioning to ensure compatibility across different versions of FAISS or your application:

```python
import faiss
import json

def save_index_with_metadata(index, filename, version):
    # Save the index
    faiss.write_index(index, f"{filename}.faiss")
    
    # Save metadata
    metadata = {
        "version": version,
        "faiss_version": faiss.__version__,
        "index_type": type(index).__name__,
        "dimension": index.d,
        "ntotal": index.ntotal
    }
    
    with open(f"{filename}_metadata.json", 'w') as f:
        json.dump(metadata, f)

def load_index_with_metadata(filename):
    # Load metadata
    with open(f"{filename}_metadata.json", 'r') as f:
        metadata = json.load(f)
    
    # Check version compatibility
    if metadata["faiss_version"] != faiss.__version__:
        print(f"Warning: Index was created with FAISS version {metadata['faiss_version']}, "
              f"but current version is {faiss.__version__}")
    
    # Load the index
    index = faiss.read_index(f"{filename}.faiss")
    
    return index, metadata

# Usage
index = faiss.IndexFlatL2(128)
save_index_with_metadata(index, "my_index", "1.0")

loaded_index, metadata = load_index_with_metadata("my_index")
print(f"Loaded index of type {metadata['index_type']} with {metadata['ntotal']} vectors")
```

## 3. Integrating FAISS with Web Services

To make FAISS available as a service, you can create a RESTful API and containerize it for easy deployment.

### 3.1 RESTful API Design for FAISS

Here's an example of a simple Flask API for FAISS:

File structure:
```
faiss_service/
├── app.py
├── faiss_wrapper.py
└── Dockerfile
```

`faiss_wrapper.py`:
```python
import faiss
import numpy as np

class FAISSWrapper:
    def __init__(self, dimension):
        self.index = faiss.IndexFlatL2(dimension)
    
    def add(self, vectors):
        self.index.add(np.array(vectors, dtype=np.float32))
    
    def search(self, query, k):
        query_array = np.array([query], dtype=np.float32)
        D, I = self.index.search(query_array, k)
        return D[0].tolist(), I[0].tolist()

```

`app.py`:
```python
from flask import Flask, request, jsonify
from faiss_wrapper import FAISSWrapper

app = Flask(__name__)
faiss_index = FAISSWrapper(128)

@app.route('/add', methods=['POST'])
def add_vectors():
    vectors = request.json['vectors']
    faiss_index.add(vectors)
    return jsonify({"status": "success", "added": len(vectors)})

@app.route('/search', methods=['POST'])
def search():
    query = request.json['query']
    k = request.json.get('k', 5)
    distances, indices = faiss_index.search(query, k)
    return jsonify({"distances": distances, "indices": indices})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
```

### 3.2 Containerization with Docker

`Dockerfile`:
```dockerfile
FROM python:3.8-slim-buster

WORKDIR /app

RUN apt-get update && apt-get install -y \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["python", "app.py"]
```

`requirements.txt`:
```
faiss-cpu==1.7.2
Flask==2.0.1
numpy==1.21.0
```

Build and run the Docker container:
```bash
docker build -t faiss-service .
docker run -p 5000:5000 faiss-service
```

## 4. Scaling FAISS for Distributed Systems

For very large datasets, you may need to distribute your FAISS index across multiple machines.

### 4.1 Sharding Large Indexes

You can shard your index across multiple machines:

```python
import faiss

class ShardedIndex:
    def __init__(self, dimension, num_shards):
        self.dimension = dimension
        self.num_shards = num_shards
        self.shards = [faiss.IndexFlatL2(dimension) for _ in range(num_shards)]
    
    def add(self, vectors):
        for i, vector in enumerate(vectors):
            shard_index = i % self.num_shards
            self.shards[shard_index].add(vector.reshape(1, -1))
    
    def search(self, query, k):
        results = [shard.search(query.reshape(1, -1), k) for shard in self.shards]
        distances = [r[0][0] for r in results]
        indices = [r[1][0] for r in results]
        
        # Merge and sort results
        merged = sorted(zip(distances[0] + distances[1], indices[0] + indices[1]))
        top_k = merged[:k]
        
        return [d for d, _ in top_k], [i for _, i in top_k]

# Usage
sharded_index = ShardedIndex(128, 2)
```

### 4.2 Load Balancing Strategies

Implement a load balancer to distribute queries across multiple FAISS instances:

```python
import random

class FAISSLoadBalancer:
    def __init__(self, faiss_instances):
        self.instances = faiss_instances
    
    def search(self, query, k):
        # Simple round-robin load balancing
        instance = random.choice(self.instances)
        return instance.search(query, k)

# Usage
instance1 = FAISSWrapper(128)
instance2 = FAISSWrapper(128)
load_balancer = FAISSLoadBalancer([instance1, instance2])

result = load_balancer.search(query, k)
```

## 5. Monitoring and Logging FAISS Operations

Proper monitoring and logging are crucial for maintaining and optimizing your FAISS-based system in production.

### 5.1 Performance Metrics to Track

- Query latency
- Index size
- Memory usage
- GPU utilization (if applicable)
- Number of queries per second
- Cache hit rate (if implementing caching)

### 5.2 Implementing Logging for Debugging and Optimization

Here's an example of how to implement logging for a FAISS wrapper:

```python
import faiss
import time
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MonitoredFAISSWrapper:
    def __init__(self, dimension):
        self.index = faiss.IndexFlatL2(dimension)
        self.total_query_time = 0
        self.num_queries = 0
    
    def add(self, vectors):
        start_time = time.time()
        self.index.add(vectors)
        end_time = time.time()
        
        logger.info(f"Added {len(vectors)} vectors in {end_time - start_time:.4f} seconds")
    
    def search(self, query, k):
        start_time = time.time()
        D, I = self.index.search(query, k)
        end_time = time.time()
        
        query_time = end_time - start_time
        self.total_query_time += query_time
        self.num_queries += 1
        
        logger.info(f"Search completed in {query_time:.4f} seconds")
        logger.info(f"Average query time: {self.total_query_time / self.num_queries:.4f} seconds")
        
        return D, I

# Usage
index = MonitoredFAISSWrapper(128)
```

For production systems, consider using more advanced monitoring solutions like Prometheus and Grafana to track and visualize these metrics in real-time.

## Conclusion

In this lesson, we've covered various aspects of optimizing FAISS for production environments. We've discussed memory management techniques for both CPU and GPU, serialization and versioning of indexes, integration with web services through RESTful APIs and containerization, scaling strategies for distributed systems, and monitoring and logging best practices.

By applying these techniques, you'll be well-equipped to deploy and maintain FAISS in large-scale, production environments. Remember to always benchmark and profile your specific use case, as the optimal configuration can vary depending on your dataset, hardware, and performance requirements.

In the next lesson, we'll dive into best practices and common pitfalls when using FAISS, helping you avoid common mistakes and further optimize your similarity search systems.

