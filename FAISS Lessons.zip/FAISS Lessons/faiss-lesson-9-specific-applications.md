# FAISS Lesson 9: FAISS for Specific Applications

## Introduction

In this lesson, we'll explore how to apply FAISS to specific real-world applications. We'll cover image similarity search, text embeddings and semantic search, recommendation systems, large-scale clustering, and anomaly detection. Each application will be explained with practical examples and code snippets.

## Table of Contents

1. [Image Similarity Search](#1-image-similarity-search)
2. [Text Embeddings and Semantic Search](#2-text-embeddings-and-semantic-search)
3. [Recommendation Systems](#3-recommendation-systems)
4. [Clustering Large Datasets](#4-clustering-large-datasets)
5. [Anomaly Detection](#5-anomaly-detection)
6. [Best Practices and Considerations](#6-best-practices-and-considerations)
7. [Exercises](#7-exercises)
8. [Conclusion](#8-conclusion)

## 1. Image Similarity Search

Image similarity search is a common application of FAISS, used in reverse image search engines, content-based image retrieval systems, and duplicate image detection.

### 1.1 Extracting Image Features

Before using FAISS, we need to extract features from images. We'll use a pre-trained CNN model for this purpose:

```python
import torch
import torchvision.models as models
import torchvision.transforms as transforms
from PIL import Image
import numpy as np

# Load pre-trained ResNet model
model = models.resnet50(pretrained=True)
model = torch.nn.Sequential(*list(model.children())[:-1])
model.eval()

# Define image transformation
transform = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

def extract_features(image_path):
    image = Image.open(image_path).convert('RGB')
    image = transform(image).unsqueeze(0)
    with torch.no_grad():
        features = model(image)
    return features.numpy().flatten()
```

### 1.2 Building the FAISS Index

Now, let's build a FAISS index with our image features:

```python
import faiss
import glob

# Extract features from all images
image_paths = glob.glob('path/to/your/images/*.jpg')
features = [extract_features(path) for path in image_paths]
features = np.array(features).astype('float32')

# Create and train the index
d = features.shape[1]  # dimension of feature vectors
nlist = 100  # number of clusters
quantizer = faiss.IndexFlatL2(d)
index = faiss.IndexIVFFlat(quantizer, d, nlist, faiss.METRIC_L2)
index.train(features)
index.add(features)
```

### 1.3 Performing Image Similarity Search

To find similar images, we can use the following function:

```python
def find_similar_images(query_image_path, index, image_paths, k=5):
    query_vector = extract_features(query_image_path)
    D, I = index.search(query_vector.reshape(1, -1), k)
    return [(image_paths[i], D[0][j]) for j, i in enumerate(I[0])]

# Example usage
query_image = 'path/to/query/image.jpg'
similar_images = find_similar_images(query_image, index, image_paths)
for path, distance in similar_images:
    print(f"Similar image: {path}, Distance: {distance}")
```

## 2. Text Embeddings and Semantic Search

FAISS can be used for efficient semantic search on text data by indexing text embeddings.

### 2.1 Generating Text Embeddings

We'll use a pre-trained BERT model to generate text embeddings:

```python
from transformers import BertTokenizer, BertModel
import torch

# Load pre-trained model and tokenizer
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertModel.from_pretrained('bert-base-uncased')
model.eval()

def get_bert_embedding(text):
    inputs = tokenizer(text, return_tensors='pt', padding=True, truncation=True, max_length=512)
    with torch.no_grad():
        outputs = model(**inputs)
    return outputs.last_hidden_state.mean(dim=1).numpy()
```

### 2.2 Building the FAISS Index for Text

Let's create a FAISS index for our text embeddings:

```python
import numpy as np

# Sample text data
texts = [
    "The quick brown fox jumps over the lazy dog",
    "A journey of a thousand miles begins with a single step",
    "To be or not to be, that is the question",
    # ... more texts ...
]

# Generate embeddings
embeddings = np.array([get_bert_embedding(text) for text in texts]).astype('float32')

# Create and train the index
d = embeddings.shape[1]
index = faiss.IndexFlatL2(d)
index.add(embeddings)
```

### 2.3 Performing Semantic Search

Now we can perform semantic search on our text data:

```python
def semantic_search(query, index, texts, k=5):
    query_vector = get_bert_embedding(query)
    D, I = index.search(query_vector, k)
    return [(texts[i], D[0][j]) for j, i in enumerate(I[0])]

# Example usage
query = "What is the meaning of life?"
results = semantic_search(query, index, texts)
for text, distance in results:
    print(f"Similar text: {text}, Distance: {distance}")
```

## 3. Recommendation Systems

FAISS can be used to build efficient recommendation systems based on collaborative filtering or content-based filtering.

### 3.1 Collaborative Filtering with FAISS

Let's implement a simple collaborative filtering system using user-item interactions:

```python
import numpy as np
import faiss

# Sample user-item interaction matrix (users as rows, items as columns)
user_item_matrix = np.random.rand(10000, 1000).astype('float32')

# Normalize the vectors
faiss.normalize_L2(user_item_matrix)

# Create and add to the index
d = user_item_matrix.shape[1]
index = faiss.IndexFlatIP(d)  # Inner product similarity
index.add(user_item_matrix)

def get_recommendations(user_id, index, user_item_matrix, k=10):
    user_vector = user_item_matrix[user_id].reshape(1, -1)
    D, I = index.search(user_vector, k+1)  # +1 because the user will be included
    return [(i, D[0][j]) for j, i in enumerate(I[0]) if i != user_id]

# Example usage
user_id = 42
recommendations = get_recommendations(user_id, index, user_item_matrix)
for item_id, similarity in recommendations:
    print(f"Recommended item: {item_id}, Similarity: {similarity}")
```

### 3.2 Content-Based Recommendations

For content-based recommendations, we can use item features:

```python
# Sample item features
item_features = np.random.rand(1000, 128).astype('float32')  # 1000 items, 128-dim features

# Create and add to the index
d = item_features.shape[1]
index = faiss.IndexFlatL2(d)
index.add(item_features)

def get_content_based_recommendations(item_id, index, item_features, k=10):
    item_vector = item_features[item_id].reshape(1, -1)
    D, I = index.search(item_vector, k+1)  # +1 because the item itself will be included
    return [(i, D[0][j]) for j, i in enumerate(I[0]) if i != item_id]

# Example usage
item_id = 42
similar_items = get_content_based_recommendations(item_id, index, item_features)
for similar_item_id, distance in similar_items:
    print(f"Similar item: {similar_item_id}, Distance: {distance}")
```

## 4. Clustering Large Datasets

FAISS provides efficient implementations of clustering algorithms that can handle large datasets.

### 4.1 K-means Clustering

Let's perform k-means clustering on a large dataset:

```python
import numpy as np
import faiss

# Generate sample data
d = 64  # dimensions
n = 100000  # number of vectors
k = 100  # number of clusters
data = np.random.rand(n, d).astype('float32')

# Perform k-means clustering
kmeans = faiss.Kmeans(d, k, niter=20, verbose=True)
kmeans.train(data)

# Get cluster centroids and assignments
centroids = kmeans.centroids
_, assignments = kmeans.index.search(data, 1)

print(f"Cluster centroids shape: {centroids.shape}")
print(f"Assignments shape: {assignments.shape}")
```

### 4.2 Hierarchical Clustering

For even larger datasets, we can use hierarchical clustering:

```python
# Parameters for hierarchical clustering
ncentroids = 10000  # total number of centroids
niter = 20
verbose = True

# Train the index
quantizer = faiss.IndexFlatL2(d)
index = faiss.IndexHNSWFlat(quantizer, d, 32)  # 32 neighbors for HNSW graph

clustering = faiss.Clustering(d, ncentroids)
clustering.verbose = verbose
clustering.niter = niter
clustering.train(data, index)

# Get centroids and assignments
centroids = faiss.vector_to_array(clustering.centroids)
_, assignments = index.search(data, 1)

print(f"Hierarchical clustering centroids shape: {centroids.shape}")
print(f"Hierarchical clustering assignments shape: {assignments.shape}")
```

## 5. Anomaly Detection

FAISS can be used for anomaly detection by finding data points that are far from their nearest neighbors.

### 5.1 Distance-Based Anomaly Detection

We'll implement a simple distance-based anomaly detection system:

```python
import numpy as np
import faiss

# Generate sample data with some anomalies
n = 10000
d = 64
data = np.random.randn(n, d).astype('float32')
anomalies = np.random.uniform(low=-10, high=10, size=(100, d)).astype('float32')
data = np.vstack([data, anomalies])

# Create and train the index
index = faiss.IndexFlatL2(d)
index.add(data)

def detect_anomalies(index, data, threshold=5.0):
    # Find distance to the nearest neighbor (excluding itself)
    D, _ = index.search(data, 2)
    nn_distances = D[:, 1]  # distances to the nearest neighbor (excluding itself)
    
    # Flag points with distance greater than threshold as anomalies
    anomaly_indices = np.where(nn_distances > threshold)[0]
    return anomaly_indices

# Detect anomalies
anomaly_indices = detect_anomalies(index, data)
print(f"Number of anomalies detected: {len(anomaly_indices)}")
print(f"Anomaly indices: {anomaly_indices}")
```

### 5.2 Local Outlier Factor (LOF) with FAISS

We can implement a more sophisticated anomaly detection method like LOF using FAISS:

```python
import numpy as np
import faiss

def compute_lof(index, data, k=5):
    # Compute k-distances and k-nearest neighbors
    D, I = index.search(data, k + 1)  # +1 because point itself is included
    k_distances = D[:, -1]
    k_neighbors = I[:, 1:]  # exclude the point itself
    
    # Compute reachability distances
    reach_dists = np.maximum(D[:, 1:], k_distances[k_neighbors])
    
    # Compute local reachability density (LRD)
    lrd = 1 / (reach_dists.mean(axis=1) + 1e-10)
    
    # Compute LOF
    lof = np.mean(lrd[k_neighbors] / lrd.reshape(-1, 1), axis=1)
    
    return lof

# Using the same data as before
index = faiss.IndexFlatL2(d)
index.add(data)

lof_scores = compute_lof(index, data)

# Detect anomalies based on LOF scores
threshold = np.percentile(lof_scores, 95)  # Flag top 5% as anomalies
anomaly_indices = np.where(lof_scores > threshold)[0]

print(f"Number of anomalies detected (LOF): {len(anomaly_indices)}")
print(f"Anomaly indices (LOF): {anomaly_indices}")
```

## 6. Best Practices and Considerations

When applying FAISS to specific applications, keep these best practices in mind:

1. **Feature Engineering**: The quality of your similarity search depends heavily on the quality of your feature vectors. Invest time in developing good feature extraction methods.

2. **Index Selection**: Choose the appropriate index type based on your dataset size, dimensionality, and performance requirements. For example, use `IndexFlatL2` for small datasets, `IndexIVFFlat` for medium-sized datasets, and `IndexIVFPQ` for large datasets.

3. **Parameter Tuning**: Experiment with parameters like `nlist`, `nprobe`, and `m` (for PQ-based indexes) to find the optimal trade-off between search speed and accuracy.

4. **Data Preprocessing**: Normalize your vectors (e.g., L2 normalization) before indexing, especially when using inner product as a similarity measure.

5. **Evaluation**: Regularly evaluate the performance of your FAISS-based system in terms of accuracy, speed, and relevance to your specific application.

6. **Scalability**: Plan for dataset growth. Choose index structures that allow for efficient updates and can handle increasing data volumes.

7. **GPU Acceleration**: For large-scale applications, consider using GPU-accelerated FAISS indexes to improve performance.

## 7. Exercises

1. Implement an image deduplication system using FAISS. Use a dataset of images, extract features, and find near-duplicate images based on feature similarity.

2. Create a semantic search engine for a collection of news articles. Use a pre-trained language model to generate embeddings, index them with FAISS, and implement a search interface.

3. Build a music recommendation system using FAISS. Use features extracted from audio files (e.g., MFCCs) or existing embeddings (e.g., from Spotify API) to find similar songs.

4. Implement a clustering-based anomaly detection system for network traffic data. Use FAISS to perform efficient k-means clustering and identify outliers.

5. Create a content-based recommendation system for movies using FAISS. Use movie features (e.g., genre, actors, directors) to build an index and recommend similar movies.

## 8. Conclusion

In this lesson, we've explored how to apply FAISS to various real-world applications, including image similarity search, semantic text search, recommendation systems, large-scale clustering, and anomaly detection. We've seen how FAISS's efficient similarity search capabilities can be leveraged to build scalable and performant systems across different domains.

As you work on these applications, remember that the key to success often lies in the quality of your feature representations and the appropriate choice of index structure and parameters. Always benchmark your system and iterate on your approach to achieve the best results for your