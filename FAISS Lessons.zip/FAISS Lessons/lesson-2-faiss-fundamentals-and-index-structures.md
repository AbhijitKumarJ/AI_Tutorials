# Lesson 2: FAISS Fundamentals and Index Structures

## 1. Vector Operations in FAISS: Creation, Manipulation, and Basic Computations

FAISS primarily works with dense vectors of float32 values. Here's how to perform basic vector operations:

### Vector Creation

FAISS uses NumPy arrays for vector creation:

```python
import numpy as np
import faiss

# Create a single vector
vector = np.array([1.0, 2.0, 3.0, 4.0], dtype='float32')

# Create a matrix (multiple vectors)
matrix = np.random.rand(1000, 128).astype('float32')
```

### Vector Manipulation

FAISS provides utilities for vector manipulation:

```python
# L2 normalization
faiss.normalize_L2(vector)

# Dimension reduction using PCA
d = 128  # original dimension
d_out = 64  # target dimension
pca = faiss.PCAMatrix(d, d_out)
pca.train(matrix)
reduced_matrix = pca.apply(matrix)
```

### Basic Computations

FAISS offers efficient implementations of common vector operations:

```python
# Compute L2 distances between vectors
distances = faiss.distances_L2sqr(vector, matrix)

# Compute inner products
ip = faiss.inner_product_range(vector, matrix)
```

## 2. Understanding Index Structures: Concept and Necessity

Index structures in FAISS are data structures designed to efficiently organize and search large collections of vectors. They are necessary for several reasons:

1. **Speed**: Brute-force search becomes impractical for large datasets. Indexes enable faster searches.
2. **Scalability**: Indexes allow FAISS to handle billions of vectors efficiently.
3. **Memory Efficiency**: Some index structures compress vectors, reducing memory usage.
4. **Flexibility**: Different index types offer various trade-offs between speed, accuracy, and memory usage.

## 3. Types of Indexes in Detail

### Flat Index

The simplest index type, which performs exhaustive search.

- **Pros**: Exact results, simple to use
- **Cons**: Slow for large datasets, high memory usage

```python
d = 64  # dimension
index = faiss.IndexFlatL2(d)
```

### IVF (Inverted File) Index

Partitions the vector space into clusters for faster search.

- **Pros**: Faster than Flat for large datasets
- **Cons**: Approximate results, requires training

```python
nlist = 100  # number of clusters
quantizer = faiss.IndexFlatL2(d)
index = faiss.IndexIVFFlat(quantizer, d, nlist)
```

### PQ (Product Quantization) Index

Compresses vectors by splitting them into subvectors and quantizing each separately.

- **Pros**: Very memory efficient, fast search
- **Cons**: Lower accuracy, requires training

```python
m = 8  # number of subvectors
bits = 8  # bits per subvector
index = faiss.IndexPQ(d, m, bits)
```

### HNSW (Hierarchical Navigable Small World) Index

Builds a multi-layer graph for efficient search.

- **Pros**: Very fast search, good accuracy
- **Cons**: High memory usage, slow to build

```python
M = 16  # number of connections per layer
index = faiss.IndexHNSWFlat(d, M)
```

## 4. Creating and Using a Flat Index: Step-by-Step Guide

Let's create a complete example using a Flat index:

```python
import numpy as np
import faiss

# 1. Generate sample data
d = 64  # dimension
nb = 100000  # database size
nq = 1000  # number of queries
np.random.seed(1234)
xb = np.random.random((nb, d)).astype('float32')
xq = np.random.random((nq, d)).astype('float32')

# 2. Create the index
index = faiss.IndexFlatL2(d)

# 3. Add vectors to the index
index.add(xb)

# 4. Search
k = 5  # we want to see 5 nearest neighbors
D, I = index.search(xq, k)

# 5. Print results
print(f"Database size: {index.ntotal}")
print(f"Search results (distances and indices for first 5 queries):")
for i in range(5):
    print(f"Query {i}:")
    for j in range(k):
        print(f"  {j+1}. Distance: {D[i][j]:.4f}, Index: {I[i][j]}")
```

This example demonstrates the basic workflow: creating an index, adding vectors, and performing a search.

## 5. Basic Similarity Search Operations: kNN Search and Range Search

### k-Nearest Neighbors (kNN) Search

kNN search finds the k closest vectors to a query vector:

```python
k = 5
D, I = index.search(xq, k)
```

- `D`: array of shape (nq, k) with distances
- `I`: array of shape (nq, k) with indices of nearest neighbors

### Range Search

Range search finds all vectors within a certain distance of the query vector:

```python
radius = 0.5
lims, D, I = index.range_search(xq, radius)
```

- `lims`: array of shape (nq + 1,) with offsets of results for each query
- `D`: array of shape (sum(lims[1:] - lims[:-1]),) with distances
- `I`: array of shape (sum(lims[1:] - lims[:-1]),) with indices

## 6. Performance Characteristics of Different Index Types

Let's compare the performance of different index types:

```python
import time

def benchmark_index(index_type, xb, xq, k):
    start = time.time()
    index = index_type
    index.add(xb)
    add_time = time.time() - start
    
    start = time.time()
    D, I = index.search(xq, k)
    search_time = time.time() - start
    
    return add_time, search_time

# Flat index
flat_add, flat_search = benchmark_index(faiss.IndexFlatL2(d), xb, xq, k)

# IVF index
quantizer = faiss.IndexFlatL2(d)
ivf_index = faiss.IndexIVFFlat(quantizer, d, 100)
ivf_index.train(xb)
ivf_add, ivf_search = benchmark_index(ivf_index, xb, xq, k)

# PQ index
pq_index = faiss.IndexPQ(d, 8, 8)
pq_index.train(xb)
pq_add, pq_search = benchmark_index(pq_index, xb, xq, k)

# HNSW index
hnsw_add, hnsw_search = benchmark_index(faiss.IndexHNSWFlat(d, 32), xb, xq, k)

print(f"Flat:  Add {flat_add:.3f}s, Search {flat_search:.3f}s")
print(f"IVF:   Add {ivf_add:.3f}s, Search {ivf_search:.3f}s")
print(f"PQ:    Add {pq_add:.3f}s, Search {pq_search:.3f}s")
print(f"HNSW:  Add {hnsw_add:.3f}s, Search {hnsw_search:.3f}s")
```

This benchmark will give you an idea of the performance trade-offs between different index types. Generally:

- Flat is slowest but most accurate
- IVF offers a good balance of speed and accuracy
- PQ is very fast and memory-efficient but less accurate
- HNSW is very fast for search but slow to build and memory-intensive

## Summary

In this lesson, we've covered:
- Vector operations in FAISS
- The concept and necessity of index structures
- Detailed explanations of different index types (Flat, IVF, PQ, HNSW)
- Step-by-step guide to creating and using a Flat index
- Basic similarity search operations (kNN and range search)
- Performance characteristics of different index types

In the next lesson, we'll dive into working with larger datasets in FAISS, including data preparation, normalization, and efficient handling of large-scale data.

## Further Reading

1. [FAISS Indexes](https://github.com/facebookresearch/faiss/wiki/Faiss-indexes) - Detailed wiki page on FAISS index types
2. [Guidelines to choose an index](https://github.com/facebookresearch/faiss/wiki/Guidelines-to-choose-an-index) - Official FAISS guide on selecting appropriate indexes
3. "Product Quantization for Nearest Neighbor Search" by Jégou et al. - Research paper on Product Quantization
4. "Efficient and robust approximate nearest neighbor search using Hierarchical Navigable Small World graphs" by Malkov and Yashunin - Paper introducing the HNSW algorithm
5. [FAISS Extended Tutorial](https://github.com/facebookresearch/faiss/blob/main/tutorial/python/1-Flat.py) - Official FAISS tutorial covering more advanced usage of different index types

