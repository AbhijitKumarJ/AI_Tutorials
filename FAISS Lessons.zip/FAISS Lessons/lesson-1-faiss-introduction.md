# Lesson 1: Introduction to Vector Similarity Search and FAISS

## 1. Understanding Vector Representations in Machine Learning

In machine learning, data is often represented as vectors - ordered lists of numbers that capture various features or attributes of the data. For example:

- An image might be represented as a vector of pixel values
- A document might be represented as a vector of word frequencies
- A user's preferences might be represented as a vector of ratings

These vector representations allow machine learning algorithms to process and analyze data mathematically.

## 2. The Concept of Similarity Search and Its Applications

Similarity search is the task of finding vectors in a large dataset that are most similar to a given query vector. This has numerous applications:

- Recommendation systems: Find products similar to ones a user likes
- Image search: Find images similar to a given image
- Plagiarism detection: Find documents similar to a given document
- Anomaly detection: Find data points that are dissimilar to most others

The challenge is performing these searches quickly and efficiently, especially with large datasets and high-dimensional vectors.

## 3. Introduction to FAISS: History, Purpose, and Advantages

FAISS (Facebook AI Similarity Search) is a library developed by Facebook Research to efficiently perform similarity search and clustering of dense vectors. 

History:
- Introduced in 2017 by Facebook Research
- Designed to handle billion-scale datasets
- Continuously improved and maintained by the open-source community

Purpose:
- Provide efficient algorithms for similarity search
- Enable fast and memory-efficient vector operations
- Support both CPU and GPU computations

Advantages:
- High performance on large datasets
- Flexible index structures for different use cases
- GPU support for accelerated computations
- Well-optimized C++ core with Python bindings
- Active development and community support

## 4. Comparing FAISS with Other Similarity Search Libraries

While FAISS is powerful, it's not the only option. Here's a brief comparison:

1. Annoy (Spotify):
   - Pros: Simple to use, good for small to medium datasets
   - Cons: Less efficient for very large datasets, no GPU support

2. NMSLIB:
   - Pros: Supports various metrics, good performance
   - Cons: More complex API, less active development

3. ScaNN (Google):
   - Pros: Good performance, especially for inner product search
   - Cons: Less flexible than FAISS, newer and less established

4. FAISS:
   - Pros: Highly efficient for large datasets, GPU support, flexible index structures
   - Cons: Can be complex for beginners, requires more memory for some index types

FAISS stands out for its performance on large-scale problems and GPU support, making it ideal for production environments with massive datasets.

## 5. Installing FAISS

FAISS can be installed on Windows, macOS, and Linux. Here are the instructions for each:

### Windows

Using conda (recommended):
```
conda install -c pytorch faiss-cpu
```

For GPU support:
```
conda install -c pytorch faiss-gpu
```

Using pip:
```
pip install faiss-cpu
```

Note: GPU support via pip on Windows is not officially supported.

### macOS

Using conda (recommended):
```
conda install -c pytorch faiss-cpu
```

Using pip:
```
pip install faiss-cpu
```

Note: GPU support on macOS is not available.

### Linux

Using conda (recommended):
```
conda install -c pytorch faiss-cpu
```

For GPU support:
```
conda install -c pytorch faiss-gpu
```

Using pip:
```
pip install faiss-cpu
```

For GPU support:
```
pip install faiss-gpu
```

Building from source:
1. Clone the FAISS repository:
   ```
   git clone https://github.com/facebookresearch/faiss.git
   ```
2. Install dependencies:
   ```
   sudo apt-get update
   sudo apt-get install -y libopenblas-dev
   ```
3. Build and install:
   ```
   cd faiss
   cmake -B build . -DFAISS_ENABLE_GPU=OFF -DFAISS_ENABLE_PYTHON=ON
   make -C build -j faiss
   make -C build install
   ```

## 6. Setting up a Python Environment for FAISS

It's recommended to use a virtual environment for FAISS development. Here's how to set it up:

1. Create a new directory for your FAISS project:
   ```
   mkdir faiss_project
   cd faiss_project
   ```

2. Create a virtual environment:
   ```
   python -m venv faiss_env
   ```

3. Activate the virtual environment:
   - On Windows: `faiss_env\Scripts\activate`
   - On macOS/Linux: `source faiss_env/bin/activate`

4. Install FAISS and other necessary libraries:
   ```
   pip install numpy scipy matplotlib faiss-cpu
   ```

5. Create a requirements.txt file:
   ```
   numpy
   scipy
   matplotlib
   faiss-cpu==1.7.3
   ```

Your project structure should look like this:
```
faiss_project/
├── faiss_env/
└── requirements.txt
```

## 7. Writing Your First FAISS Program in Python

Let's create a simple program that demonstrates basic FAISS functionality:

1. Create a new file called `faiss_demo.py` in your project directory:

```
faiss_project/
├── faiss_env/
├── requirements.txt
└── faiss_demo.py
```

2. Add the following code to `faiss_demo.py`:

```python
import numpy as np
import faiss

# Generate some random data
d = 64  # dimension
nb = 100000  # database size
nq = 10000  # nb of queries
np.random.seed(1234)
xb = np.random.random((nb, d)).astype('float32')
xq = np.random.random((nq, d)).astype('float32')

# Create a Flat (brute-force) index
index = faiss.IndexFlatL2(d)

# Add vectors to the index
index.add(xb)

# Search
k = 4  # we want to see 4 nearest neighbors
D, I = index.search(xq, k)

# Print results
print(f"Database size: {index.ntotal}")
print(f"Search results (distances and indices for first 5 queries):")
for i in range(5):
    print(f"Query {i}:")
    for j in range(k):
        print(f"  {j+1}. Distance: {D[i][j]:.4f}, Index: {I[i][j]}")
```

3. Run the program:
```
python faiss_demo.py
```

This program does the following:
- Generates random vectors for a database and queries
- Creates a simple L2 (Euclidean distance) index
- Adds vectors to the index
- Performs a k-nearest neighbor search
- Prints out the results for the first 5 queries

This demonstrates the basic workflow of using FAISS: creating an index, adding vectors, and performing similarity search.

## Summary

In this lesson, we've covered:
- The concept of vector representations in machine learning
- The importance and applications of similarity search
- An introduction to FAISS, its history, purpose, and advantages
- Comparison of FAISS with other similarity search libraries
- Installation instructions for FAISS on different platforms
- Setting up a Python environment for FAISS development
- Writing and running a basic FAISS program

In the next lesson, we'll dive deeper into FAISS fundamentals and explore various index structures in detail.

## Further Reading

1. [FAISS GitHub Repository](https://github.com/facebookresearch/faiss)
2. [FAISS Wiki](https://github.com/facebookresearch/faiss/wiki)
3. "Billion-scale similarity search with GPUs" by Johnson, Douze, and Jégou (research paper introducing FAISS)
4. "A Survey of Product Quantization" by Jegou, Douze, and Schmid (for background on product quantization, a key technique in FAISS)
5. [Scikit-learn's Nearest Neighbors module](https://scikit-learn.org/stable/modules/neighbors.html) (for comparison with a simpler similarity search implementation)

