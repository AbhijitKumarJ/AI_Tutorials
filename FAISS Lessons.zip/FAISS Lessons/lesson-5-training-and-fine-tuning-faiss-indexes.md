# FAISS Lesson 5: Training and Fine-tuning FAISS Indexes

## Introduction

In this lesson, we'll delve into the critical aspects of training and fine-tuning FAISS indexes. We'll explore why training is essential, how to train different index types, and strategies for optimizing index parameters. We'll also cover techniques for handling large datasets and leveraging GPUs for training.

## Table of Contents

1. The Importance of Training in FAISS
2. Training Different Index Types
3. Optimizing Index Parameters
4. Cross-validation Techniques for FAISS Indexes
5. Handling Out-of-Memory Scenarios During Training

## 1. The Importance of Training in FAISS

Training is a crucial step in creating effective FAISS indexes. It involves learning the underlying structure of your data, which allows for more efficient indexing and searching. The impact of proper training on performance can be significant, affecting both search speed and accuracy.

### Why Training Matters

1. **Improved Search Accuracy**: Training helps the index better understand the distribution of your data, leading to more accurate search results.
2. **Faster Search Speed**: A well-trained index can more efficiently navigate the data space, resulting in faster query times.
3. **Optimal Resource Utilization**: Proper training ensures that your index makes the best use of available memory and computational resources.

### When Training is Required

Not all FAISS indexes require training. Here's a quick overview:

- **Require Training**: IVF-based indexes (e.g., IndexIVFFlat, IndexIVFPQ), PQ-based indexes
- **Don't Require Training**: IndexFlatL2, IndexLSH
- **Optional Training**: IndexHNSW (training can improve performance but isn't strictly necessary)

## 2. Training Different Index Types

Let's explore how to train different types of FAISS indexes, with specific considerations for each.

### IndexIVFFlat

IndexIVFFlat requires training to learn the centroids for its coarse quantizer.

```python
import numpy as np
import faiss

# Generate sample data
d = 64  # dimension
nb = 100000  # database size
nt = 10000  # training vectors
np.random.seed(1234)
xb = np.random.random((nb, d)).astype('float32')
xt = np.random.random((nt, d)).astype('float32')

# Create an IVF index
nlist = 100  # number of clusters
quantizer = faiss.IndexFlatL2(d)
index = faiss.IndexIVFFlat(quantizer, d, nlist)

# Train the index
index.train(xt)

print(f"Is trained: {index.is_trained}")

# Add vectors to the index
index.add(xb)

# Perform a search
nq = 10  # number of queries
xq = np.random.random((nq, d)).astype('float32')
k = 5  # top k results
D, I = index.search(xq, k)

print(f"\nTop {k} results for the first query:")
for i in range(k):
    print(f"  {i+1}. ID: {I[0, i]}, Distance: {D[0, i]}")
```

### IndexIVFPQ

IndexIVFPQ requires training both for its coarse quantizer (IVF part) and its product quantizer (PQ part).

```python
# Continuing from the previous example...

# Create an IVFPQ index
nlist = 100  # number of clusters
m = 8  # number of subquantizers in PQ
bits = 8  # bits per subquantizer in PQ
index_ivfpq = faiss.IndexIVFPQ(quantizer, d, nlist, m, bits)

# Train the index
index_ivfpq.train(xt)

print(f"Is trained: {index_ivfpq.is_trained}")

# Add vectors to the index
index_ivfpq.add(xb)

# Perform a search
D, I = index_ivfpq.search(xq, k)

print(f"\nTop {k} results for the first query (IVFPQ):")
for i in range(k):
    print(f"  {i+1}. ID: {I[0, i]}, Distance: {D[0, i]}")
```

### IndexHNSW

While IndexHNSW doesn't strictly require training, you can optimize its parameters based on your data.

```python
# Create an HNSW index
M = 16  # number of connections per layer
ef_construction = 100  # size of dynamic candidate list for construction
index_hnsw = faiss.IndexHNSWFlat(d, M)
index_hnsw.hnsw.efConstruction = ef_construction

# Add vectors to the index (this implicitly trains the index)
index_hnsw.add(xb)

# Perform a search
ef_search = 50  # size of dynamic candidate list for search
index_hnsw.hnsw.efSearch = ef_search
D, I = index_hnsw.search(xq, k)

print(f"\nTop {k} results for the first query (HNSW):")
for i in range(k):
    print(f"  {i+1}. ID: {I[0, i]}, Distance: {D[0, i]}")
```

## 3. Optimizing Index Parameters

Optimizing index parameters is crucial for achieving the best performance. Let's look at some key parameters for different index types and how to tune them.

### IVF Indexes

For IVF-based indexes, the main parameters to tune are:

1. **nlist**: The number of centroids (inverted lists)
2. **nprobe**: The number of nearest inverted lists to search

```python
# Experiment with different nlist values
for nlist in [10, 100, 1000]:
    index = faiss.IndexIVFFlat(quantizer, d, nlist)
    index.train(xt)
    index.add(xb)
    
    for nprobe in [1, 10, 50]:
        index.nprobe = nprobe
        D, I = index.search(xq, k)
        recall = faiss.eval_recall_at_r(index, xq, xb, 1)  # Recall@1
        print(f"nlist: {nlist}, nprobe: {nprobe}, Recall@1: {recall}")
```

### PQ Indexes

For PQ-based indexes, key parameters include:

1. **m**: The number of subquantizers
2. **bits**: The number of bits per subquantizer

```python
# Experiment with different m and bits values
for m in [4, 8, 16]:
    for bits in [4, 8]:
        index_pq = faiss.IndexPQ(d, m, bits)
        index_pq.train(xt)
        index_pq.add(xb)
        D, I = index_pq.search(xq, k)
        recall = faiss.eval_recall_at_r(index_pq, xq, xb, 1)
        print(f"m: {m}, bits: {bits}, Recall@1: {recall}")
```

### HNSW Indexes

For HNSW indexes, the main parameters to tune are:

1. **M**: The number of connections per layer
2. **efConstruction**: The size of the dynamic candidate list during construction
3. **efSearch**: The size of the dynamic candidate list during search

```python
# Experiment with different M and efConstruction values
for M in [16, 32, 64]:
    for ef_construction in [40, 100, 200]:
        index_hnsw = faiss.IndexHNSWFlat(d, M)
        index_hnsw.hnsw.efConstruction = ef_construction
        index_hnsw.add(xb)
        
        for ef_search in [10, 50, 100]:
            index_hnsw.hnsw.efSearch = ef_search
            D, I = index_hnsw.search(xq, k)
            recall = faiss.eval_recall_at_r(index_hnsw, xq, xb, 1)
            print(f"M: {M}, efConstruction: {ef_construction}, efSearch: {ef_search}, Recall@1: {recall}")
```

## 4. Cross-validation Techniques for FAISS Indexes

Cross-validation helps ensure that your index performs well on unseen data. Here's a simple cross-validation technique for FAISS:

```python
import sklearn.model_selection as model_selection

# Split data into train and test sets
xtrain, xtest = model_selection.train_test_split(xb, test_size=0.2, random_state=42)

# Function to evaluate index performance
def evaluate_index(index, xtrain, xtest):
    index.train(xtrain)
    index.add(xtrain)
    D, I = index.search(xtest, k)
    recall = faiss.eval_recall_at_r(index, xtest, xtrain, 1)
    return recall

# Perform cross-validation
nlist_values = [10, 100, 1000]
nprobe_values = [1, 10, 50]

best_recall = 0
best_params = None

for nlist in nlist_values:
    for nprobe in nprobe_values:
        index = faiss.IndexIVFFlat(quantizer, d, nlist)
        index.nprobe = nprobe
        recall = evaluate_index(index, xtrain, xtest)
        print(f"nlist: {nlist}, nprobe: {nprobe}, Recall@1: {recall}")
        
        if recall > best_recall:
            best_recall = recall
            best_params = (nlist, nprobe)

print(f"Best parameters: nlist={best_params[0]}, nprobe={best_params[1]}, Recall@1: {best_recall}")
```

## 5. Handling Out-of-Memory Scenarios During Training

When dealing with large datasets, you might encounter out-of-memory errors during training. Here are some strategies to handle this:

### Incremental Training

Some FAISS indexes support incremental training, allowing you to train on batches of data:

```python
def train_in_batches(index, xt, batch_size=10000):
    for i in range(0, len(xt), batch_size):
        batch = xt[i:i+batch_size]
        index.train(batch)

# Usage
index = faiss.IndexIVFFlat(quantizer, d, nlist)
train_in_batches(index, xt)
```

### Using a Subset of Data

If your full dataset is too large, you can train on a representative subset:

```python
import random

def get_random_subset(data, subset_size):
    indices = random.sample(range(len(data)), subset_size)
    return data[indices]

# Usage
subset_size = 100000  # Adjust based on your memory constraints
xt_subset = get_random_subset(xt, subset_size)
index.train(xt_subset)
```

### Leveraging GPU for Training

If you have a GPU available, you can use it to speed up training and handle larger datasets:

```python
import faiss.contrib.torch_utils

# Convert CPU index to GPU
res = faiss.StandardGpuResources()
gpu_index = faiss.index_cpu_to_gpu(res, 0, index)

# Train on GPU
gpu_index.train(xt)

# Convert back to CPU if needed
cpu_index = faiss.index_gpu_to_cpu(gpu_index)
```

## Conclusion

In this lesson, we've covered the importance of training in FAISS, how to train different index types, techniques for optimizing index parameters, cross-validation methods, and strategies for handling large datasets during training. By applying these techniques, you can significantly improve the performance and efficiency of your FAISS indexes.

Remember that the optimal configuration will depend on your specific dataset and use case. Always benchmark and test different configurations to find the best balance between search speed, accuracy, and memory usage for your application.

## File Layout

Here's a suggested file layout for organizing the code examples in this lesson:

```
faiss_tutorial/
│
├── lesson_5/
│   ├── __init__.py
│   ├── index_training.py
│   ├── parameter_optimization.py
│   ├── cross_validation.py
│   └── large_scale_training.py
│
└── data/
    ├── sample_vectors.npy
    └── sample_queries.npy
```

You can create separate Python files for each main topic covered in the lesson. The sample vectors and queries can be stored in NumPy files in the data directory.

