# FAISS Lesson 4: Advanced Indexing Techniques

## Introduction
In this lesson, we'll dive deep into advanced indexing techniques in FAISS. We'll cover IVF (Inverted File) indexes, Product Quantization (PQ), the combination of IVF and PQ, and the HNSW (Hierarchical Navigable Small World) graph structure. We'll also discuss how to choose the right index for your specific use case.

## Table of Contents
1. IVF (Inverted File) Indexes
2. Product Quantization (PQ) for Compression
3. Combining IVF and PQ: The IVFPQ Index Structure
4. Understanding and Using HNSW
5. Choosing the Right Index

## 1. IVF (Inverted File) Indexes

### Theory
IVF indexes are based on the idea of clustering the dataset into multiple partitions, also known as "inverted lists". Each partition is represented by a centroid. During search, only a subset of these partitions is explored, significantly speeding up the search process.

### Implementation
Let's implement an IVF index:

```python
import numpy as np
import faiss

# Generate sample data
d = 64  # dimension
nb = 100000  # database size
nq = 10000  # num of queries
np.random.seed(1234)
xb = np.random.random((nb, d)).astype('float32')
xq = np.random.random((nq, d)).astype('float32')

# Create an IVF index
nlist = 100  # number of clusters
quantizer = faiss.IndexFlatL2(d)  # the other index
index = faiss.IndexIVFFlat(quantizer, d, nlist)

# Train the index
index.train(xb)

# Add vectors to the index
index.add(xb)

# Search
k = 4  # we want to see 4 nearest neighbors
index.nprobe = 10  # we probe 10 clusters (out of 100)
D, I = index.search(xq, k)

print(f"Top {k} neighbors of the first query vector:")
for i in range(k):
    print(f"  {i+1}. ID: {I[0, i]}, Distance: {D[0, i]}")
```

### Use Cases
IVF indexes are particularly useful when:
- You have a large dataset that doesn't fit in memory
- You need faster search times and can trade off some accuracy
- Your data naturally clusters into distinct groups

## 2. Product Quantization (PQ) for Compression

### Theory
Product Quantization is a compression technique that allows for efficient storage of high-dimensional vectors. It works by splitting the vector into smaller subvectors, and then quantizing each subvector separately.

### Implementation
Here's how to implement a PQ index:

```python
# Continuing from the previous example...

# Create a PQ index
m = 8  # number of subquantizers
bits = 8  # bits per subquantizer
pq_index = faiss.IndexPQ(d, m, bits)

# Train and add vectors
pq_index.train(xb)
pq_index.add(xb)

# Search
D, I = pq_index.search(xq, k)

print(f"\nTop {k} neighbors of the first query vector (PQ):")
for i in range(k):
    print(f"  {i+1}. ID: {I[0, i]}, Distance: {D[0, i]}")
```

### Use Cases
PQ is particularly useful when:
- You need to compress your vectors to save memory
- You can tolerate some loss in accuracy for better space efficiency
- You're working with very high-dimensional data

## 3. Combining IVF and PQ: The IVFPQ Index Structure

### Theory
IVFPQ combines the benefits of IVF and PQ. It uses IVF for coarse quantization and PQ for fine quantization, resulting in a highly efficient index structure for both storage and search.

### Implementation
Let's implement an IVFPQ index:

```python
# Continuing from the previous examples...

# Create an IVFPQ index
nlist = 100  # number of inverted lists
m = 8  # number of subquantizers in PQ
bits = 8  # bits per subquantizer in PQ
ivfpq_index = faiss.IndexIVFPQ(quantizer, d, nlist, m, bits)

# Train and add vectors
ivfpq_index.train(xb)
ivfpq_index.add(xb)

# Search
ivfpq_index.nprobe = 10  # number of inverted lists to probe
D, I = ivfpq_index.search(xq, k)

print(f"\nTop {k} neighbors of the first query vector (IVFPQ):")
for i in range(k):
    print(f"  {i+1}. ID: {I[0, i]}, Distance: {D[0, i]}")
```

### Use Cases
IVFPQ is particularly useful when:
- You have a very large dataset that needs to be compressed
- You need fast search times and can tolerate some loss in accuracy
- You want a good balance between search speed, memory usage, and accuracy

## 4. Understanding and Using HNSW

### Theory
HNSW (Hierarchical Navigable Small World) is a graph-based index structure that provides a good trade-off between search speed and accuracy. It builds a multi-layer graph where each layer is a "small world" graph.

#### Graph Construction
1. Vectors are inserted one by one into the graph
2. For each new vector, connections are made to existing vectors based on similarity
3. The process starts at the top layer and moves down, creating more connections in lower layers

#### Search Algorithm
1. The search starts at the top layer at a random point
2. It moves greedily to the nearest neighbor of the query
3. This process is repeated in lower layers, but starting from the best point found in the upper layer
4. The final search is performed in the bottom layer

### Implementation
Let's implement an HNSW index:

```python
# Continuing from the previous examples...

# Create an HNSW index
M = 16  # number of connections per layer
ef_construction = 100  # size of dynamic candidate list for construction
hnsw_index = faiss.IndexHNSWFlat(d, M)
hnsw_index.hnsw.efConstruction = ef_construction

# Train is not needed for IndexHNSWFlat
hnsw_index.add(xb)

# Search
ef_search = 50  # size of dynamic candidate list for search
hnsw_index.hnsw.efSearch = ef_search
D, I = hnsw_index.search(xq, k)

print(f"\nTop {k} neighbors of the first query vector (HNSW):")
for i in range(k):
    print(f"  {i+1}. ID: {I[0, i]}, Distance: {D[0, i]}")
```

### Parameter Tuning
- `M`: Controls the number of connections per layer. Higher values lead to better accuracy but increased memory usage and construction time.
- `efConstruction`: Controls the size of the dynamic candidate list during construction. Higher values lead to better accuracy but slower construction.
- `efSearch`: Controls the size of the dynamic candidate list during search. Higher values lead to better accuracy but slower search.

### Use Cases
HNSW is particularly useful when:
- You need very fast approximate nearest neighbor search
- You can afford some extra memory usage for index construction
- You want a good balance between search speed and accuracy

## 5. Choosing the Right Index

Choosing the right index depends on various factors:

### Dataset Size
- Small datasets (< 1M vectors): Flat index or HNSW
- Medium datasets (1M - 10M vectors): IVF or IVFPQ
- Large datasets (> 10M vectors): IVFPQ or HNSW

### Dimensionality
- Low dimensions (< 50): Any index works well
- Medium dimensions (50 - 1000): IVF, IVFPQ, or HNSW
- High dimensions (> 1000): Consider using PQ or HNSW

### Accuracy Requirements
- High accuracy: Flat index or HNSW with high ef_search
- Moderate accuracy: IVF or IVFPQ with higher nprobe
- Lower accuracy: IVFPQ with lower nprobe or faster HNSW settings

### Memory Constraints
- Low memory: IVFPQ with high compression
- Moderate memory: IVF or HNSW
- High memory available: Flat index or HNSW with high M

### Search Speed Requirements
- Very fast search: HNSW or IVFPQ with low nprobe
- Moderate speed: IVF or IVFPQ with moderate nprobe
- Exact search: Flat index

### Performance Comparisons

Here's a rough comparison of the index types we've covered:

| Index Type | Search Speed | Build Time | Memory Usage | Accuracy |
|------------|--------------|------------|--------------|----------|
| Flat       | Slow         | Fast       | High         | Perfect  |
| IVF        | Fast         | Moderate   | Moderate     | Good     |
| PQ         | Very Fast    | Slow       | Low          | Moderate |
| IVFPQ      | Very Fast    | Slow       | Low          | Moderate |
| HNSW       | Very Fast    | Slow       | High         | Excellent|

Remember that these are general guidelines, and the best index for your specific use case may require experimentation and benchmarking.

## Conclusion

In this lesson, we've covered advanced indexing techniques in FAISS, including IVF, PQ, IVFPQ, and HNSW. We've discussed their theories, implemented examples, and provided guidance on choosing the right index for different scenarios. In the next lesson, we'll dive into training and fine-tuning FAISS indexes to optimize their performance.

## File Layout

Here's a suggested file layout for organizing the code examples in this lesson:

```
faiss_tutorial/
│
├── lesson_4/
│   ├── __init__.py
│   ├── ivf_example.py
│   ├── pq_example.py
│   ├── ivfpq_example.py
│   ├── hnsw_example.py
│   └── index_comparison.py
│
└── data/
    └── sample_vectors.npy
```

You can create separate Python files for each index type example, and a comparison script to benchmark different indexes. The sample vectors can be stored in a NumPy file in the data directory.

