# FAISS Lesson 7: GPU Acceleration

## Introduction

GPU acceleration is a crucial feature of FAISS that allows for significant performance improvements in vector similarity search operations. This lesson will cover the benefits and limitations of GPU usage in FAISS, how to set up and use GPU support, and how to optimize performance using GPU acceleration.

## Table of Contents

1. [Introduction to GPU Usage in FAISS](#introduction-to-gpu-usage-in-faiss)
2. [Setting Up FAISS with GPU Support](#setting-up-faiss-with-gpu-support)
3. [Converting CPU Indexes to GPU](#converting-cpu-indexes-to-gpu)
4. [Multi-GPU Processing](#multi-gpu-processing)
5. [Performance Comparison: CPU vs GPU](#performance-comparison-cpu-vs-gpu)
6. [Best Practices and Considerations](#best-practices-and-considerations)
7. [Exercises](#exercises)
8. [Conclusion](#conclusion)

## 1. Introduction to GPU Usage in FAISS

GPU acceleration in FAISS can significantly speed up vector similarity search operations, especially for large-scale datasets. The primary benefits of using GPUs with FAISS include:

- Faster search operations
- Ability to handle larger datasets
- Improved training speed for certain index types

However, there are some limitations to consider:

- Not all index types support GPU acceleration
- GPU memory constraints may limit the size of indexes that can be fully loaded
- The speedup may not be significant for small datasets or simple operations

## 2. Setting Up FAISS with GPU Support

To use FAISS with GPU support, you need to have CUDA installed on your system and build FAISS with GPU support enabled.

### 2.1 CUDA Installation

First, ensure that you have CUDA installed on your system. You can download CUDA from the NVIDIA website: https://developer.nvidia.com/cuda-downloads

### 2.2 Installing FAISS with GPU Support

#### Using Conda (Recommended)

The easiest way to install FAISS with GPU support is using Conda:

```bash
conda install -c pytorch faiss-gpu
```

#### Building from Source

If you need to build FAISS from source with GPU support, follow these steps:

1. Clone the FAISS repository:
```bash
git clone https://github.com/facebookresearch/faiss.git
```

2. Navigate to the FAISS directory:
```bash
cd faiss
```

3. Create a build directory:
```bash
mkdir build && cd build
```

4. Configure the build with GPU support:
```bash
cmake .. -DFAISS_ENABLE_GPU=ON -DCMAKE_BUILD_TYPE=Release
```

5. Build FAISS:
```bash
make -j
```

6. Install FAISS:
```bash
make install
```

### 2.3 Verifying GPU Support

To verify that FAISS is built with GPU support, you can run the following Python code:

```python
import faiss
print(faiss.get_num_gpus())
```

If this returns a number greater than 0, FAISS has successfully detected your GPU(s).

## 3. Converting CPU Indexes to GPU

FAISS provides methods to convert CPU indexes to GPU indexes. Here's a step-by-step guide:

### 3.1 Creating a GPU Resources Object

First, you need to create a `StandardGpuResources` object:

```python
import faiss

res = faiss.StandardGpuResources()
```

### 3.2 Converting a CPU Index to GPU

To convert a CPU index to a GPU index, use the `index_cpu_to_gpu` function:

```python
import numpy as np

# Create a CPU index
d = 64  # dimension
nb = 100000  # database size
np.random.seed(1234)
xb = np.random.random((nb, d)).astype('float32')

cpu_index = faiss.IndexFlatL2(d)
cpu_index.add(xb)

# Convert to GPU
gpu_index = faiss.index_cpu_to_gpu(res, 0, cpu_index)
```

### 3.3 Using the GPU Index

Once you have a GPU index, you can use it just like a CPU index:

```python
nq = 1000  # number of queries
xq = np.random.random((nq, d)).astype('float32')

k = 10  # we want to see 10 nearest neighbors
D, I = gpu_index.search(xq, k)
```

## 4. Multi-GPU Processing

FAISS supports distributing workload across multiple GPUs for even faster processing.

### 4.1 Using Multiple GPUs

To use multiple GPUs, you can create a `GpuMultipleClonerOptions` object and use the `index_cpu_to_gpu_multiple` function:

```python
import faiss

ngpus = faiss.get_num_gpus()
print(f"Number of GPUs: {ngpus}")

cpu_index = faiss.IndexFlatL2(d)
cpu_index.add(xb)

gpu_resources = []
for i in range(ngpus):
    res = faiss.StandardGpuResources()
    gpu_resources.append(res)

co = faiss.GpuMultipleClonerOptions()
gpu_index = faiss.index_cpu_to_gpu_multiple_py(gpu_resources, cpu_index, co)
```

### 4.2 Synchronization and Result Aggregation

When using multiple GPUs, FAISS automatically handles synchronization and result aggregation. You can use the multi-GPU index just like a single-GPU or CPU index:

```python
D, I = gpu_index.search(xq, k)
```

## 5. Performance Comparison: CPU vs GPU

To demonstrate the performance difference between CPU and GPU, let's run a benchmark:

```python
import time
import faiss
import numpy as np

d = 128  # dimension
nb = 1000000  # database size
nq = 10000  # number of queries
k = 100  # top k results

# Generate some random data
np.random.seed(1234)
xb = np.random.random((nb, d)).astype('float32')
xq = np.random.random((nq, d)).astype('float32')

# CPU index
cpu_index = faiss.IndexFlatL2(d)
cpu_index.add(xb)

# GPU index
res = faiss.StandardGpuResources()
gpu_index = faiss.index_cpu_to_gpu(res, 0, cpu_index)

# CPU search
start = time.time()
D_cpu, I_cpu = cpu_index.search(xq, k)
cpu_time = time.time() - start
print(f"CPU search time: {cpu_time:.4f} seconds")

# GPU search
start = time.time()
D_gpu, I_gpu = gpu_index.search(xq, k)
gpu_time = time.time() - start
print(f"GPU search time: {gpu_time:.4f} seconds")

print(f"Speedup: {cpu_time / gpu_time:.2f}x")
```

This benchmark will give you an idea of the performance improvement you can expect when using GPU acceleration with FAISS.

## 6. Best Practices and Considerations

When using GPU acceleration in FAISS, keep the following best practices and considerations in mind:

1. **Memory Management**: GPUs typically have less memory than CPUs. Monitor your GPU memory usage and consider using techniques like indexing in batches for large datasets.

2. **Index Type Selection**: Not all index types support GPU acceleration. IVF-based indexes (e.g., IVFFlat, IVFPQ) and Flat indexes generally work well on GPUs.

3. **Data Transfer Overhead**: Be aware of the overhead involved in transferring data between CPU and GPU memory. For small datasets or infrequent queries, this overhead might outweigh the benefits of GPU acceleration.

4. **Multi-GPU Scaling**: When using multiple GPUs, the speedup may not be linear. The optimal number of GPUs depends on your specific workload and hardware configuration.

5. **Precision**: GPUs often use single-precision floating-point numbers (float32) by default. If your application requires double precision, be aware that this may impact performance.

6. **Warmup**: The first GPU operation may take longer due to CUDA context initialization. Consider performing a warmup query before timing critical operations.

## 7. Exercises

1. Create a CPU index and a GPU index with the same data. Compare the search times for various dataset sizes and dimensions.

2. Implement a multi-GPU search using `index_cpu_to_gpu_multiple_py`. Compare the performance with single-GPU and CPU implementations.

3. Profile the memory usage of your GPU when running FAISS operations. Determine the maximum size of the index that can fit in your GPU's memory.

4. Experiment with different index types (e.g., IVFFlat, IVFPQ) on both CPU and GPU. Compare the trade-offs between search speed, memory usage, and accuracy.

5. Implement a simple vector similarity search application that can switch between CPU and GPU backends based on user input or available hardware.

## 8. Conclusion

GPU acceleration in FAISS can provide significant performance improvements for vector similarity search operations, especially for large-scale datasets. By understanding how to set up and use GPU support, convert indexes between CPU and GPU, and optimize for multi-GPU processing, you can leverage the full power of FAISS in your applications.

In the next lesson, we'll explore advanced FAISS features, including binary indexes, composite indexes, and techniques for handling high-dimensional data.

