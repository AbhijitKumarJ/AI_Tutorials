# Lesson 5: Operational Modes and Interfaces

## Lesson Overview

This lesson explores the various operational modes available in OpenHands and how to effectively use each interface. We'll cover the Graphical User Interface (GUI), Command Line Interface (CLI), Headless mode, and GitHub Action integration. By the end of this lesson, you'll understand how to choose and utilize the most appropriate mode for your specific use case.

## Prerequisites
- Completed OpenHands installation
- Basic understanding of Docker
- Familiarity with command-line operations
- GitHub account (for GitHub Actions section)

## 1. GUI Mode

### Understanding the GUI Interface

The GUI mode provides a user-friendly web interface accessible through your browser. The interface is structured as follows:

```
http://localhost:3000/
├── Settings Panel (gear icon)
│   ├── LLM Provider Selection
│   ├── Model Selection
│   ├── API Key Configuration
│   └── Advanced Options
├── Chat Window
│   ├── Message History
│   └── Input Box
└── Workspace Panel
    ├── File Browser
    ├── Command History
    └── Web History
```

The GUI mode is particularly useful for:
- Interactive development sessions
- Visual file management
- Real-time feedback and debugging
- Team collaboration scenarios

To start GUI mode, you would typically use the standard Docker command:

```bash
docker run -it --pull=always \
    -e SANDBOX_RUNTIME_CONTAINER_IMAGE=docker.all-hands.dev/all-hands-ai/runtime:0.13-nikolaik \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -p 3000:3000 \
    --add-host host.docker.internal:host-gateway \
    --name openhands-app \
    docker.all-hands.dev/all-hands-ai/openhands:0.13
```

## 2. CLI Mode

The Command Line Interface provides a terminal-based interaction method, ideal for users who prefer command-line operations or need to integrate OpenHands into terminal-based workflows.

### CLI Structure

```
openhands-cli/
├── Interactive Session
│   ├── Command Input
│   ├── Response Output
│   └── Status Indicators
└── Configuration
    ├── Environment Variables
    └── Config Files
```

To start CLI mode, you have two options:

1. Using Python directly:
```bash
poetry run python -m openhands.core.cli
```

2. Using Docker:
```bash
docker run -it \
    --pull=always \
    -e SANDBOX_RUNTIME_CONTAINER_IMAGE=docker.all-hands.dev/all-hands-ai/runtime:0.13-nikolaik \
    -e SANDBOX_USER_ID=$(id -u) \
    -e WORKSPACE_MOUNT_PATH=$WORKSPACE_BASE \
    -e LLM_API_KEY=$LLM_API_KEY \
    -e LLM_MODEL=$LLM_MODEL \
    -v $WORKSPACE_BASE:/opt/workspace_base \
    -v /var/run/docker.sock:/var/run/docker.sock \
    --add-host host.docker.internal:host-gateway \
    docker.all-hands.dev/all-hands-ai/openhands:0.13 \
    python -m openhands.core.cli
```

## 3. Headless Mode

Headless mode is designed for automation and scripting scenarios where user interaction isn't required. This mode is particularly useful for:
- Automated testing
- Batch processing
- CI/CD pipelines
- System integration

### Headless Mode Configuration

```
headless-mode/
├── Configuration
│   ├── config.toml
│   └── Environment Variables
├── Input
│   ├── Task Definition
│   └── Parameters
└── Output
    ├── Logs
    └── Results
```

To run in headless mode:

```bash
poetry run python -m openhands.core.main -t "your task description"
```

Or with Docker:

```bash
docker run -it \
    --pull=always \
    -e SANDBOX_RUNTIME_CONTAINER_IMAGE=docker.all-hands.dev/all-hands-ai/runtime:0.13-nikolaik \
    -e SANDBOX_USER_ID=$(id -u) \
    -e WORKSPACE_MOUNT_PATH=$WORKSPACE_BASE \
    -e LLM_API_KEY=$LLM_API_KEY \
    -e LLM_MODEL=$LLM_MODEL \
    -v $WORKSPACE_BASE:/opt/workspace_base \
    -v /var/run/docker.sock:/var/run/docker.sock \
    --add-host host.docker.internal:host-gateway \
    docker.all-hands.dev/all-hands-ai/openhands:0.13 \
    python -m openhands.core.main -t "your task description"
```

## 4. GitHub Action Integration

OpenHands can be integrated into GitHub workflows through GitHub Actions. This enables automated code review, bug fixing, and code generation directly within your GitHub repositories.

### GitHub Action Structure

```
.github/
└── workflows/
    └── openhands.yml
```

Example workflow configuration:

```yaml
name: OpenHands Action
on:
  issues:
    types: [labeled]

jobs:
  openhands:
    if: github.event.label.name == 'fix-me'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: OpenHands Resolver
        uses: All-Hands-AI/OpenHands-resolver@v1
        with:
          github-token: ${{ secrets.GITHUB_TOKEN }}
          openai-api-key: ${{ secrets.OPENAI_API_KEY }}
```

## 5. Mode Selection Guidelines

When choosing between different modes, consider the following factors:

### Interactive Development (GUI/CLI)
The GUI and CLI modes are ideal for interactive development where you need real-time feedback and the ability to iterate quickly. Choose GUI mode when you prefer visual interaction and need to manage files graphically. Use CLI mode when you're comfortable with terminal operations and want to integrate with other command-line tools.

### Automation (Headless/GitHub Action)
Headless mode and GitHub Actions are perfect for automation scenarios. Use headless mode when you need to integrate OpenHands into your own automation scripts or systems. Choose GitHub Actions when you want to automate tasks directly within your GitHub workflow.

## 6. Cross-Platform Considerations

### Windows
- WSL is required for Docker-based operations
- Pay attention to path separators in file operations
- Consider filesystem permissions when mounting volumes

### macOS
- Ensure Docker Desktop settings allow socket access
- Monitor resource usage as Docker runs in a VM

### Linux
- Direct Docker support
- Native filesystem performance
- Better resource utilization

## 7. Security Considerations

For each mode, consider these security aspects:
- API key management
- File system permissions
- Network access controls
- Container isolation
- GitHub token scope

## Practical Exercises

1. GUI Mode Exercise:
   Start OpenHands in GUI mode and complete a simple code generation task using the visual interface.

2. CLI Mode Exercise:
   Use the CLI mode to perform the same task as above, noting the differences in workflow.

3. Headless Mode Exercise:
   Create a script that uses headless mode to automate a series of code modifications.

4. GitHub Action Exercise:
   Set up a GitHub Action that uses OpenHands to automatically review pull requests.

## Additional Resources

- [OpenHands Documentation](https://docs.all-hands.dev)
- [GitHub Action Repository](https://github.com/All-Hands-AI/OpenHands-resolver)
- [Troubleshooting Guide](https://docs.all-hands.dev/modules/usage/troubleshooting)
- Community Support Channels:
  - [Slack Workspace](https://join.slack.com/t/opendevin/shared_invite/zt-2oikve2hu-UDxHeo8nsE69y6T7yFX_BA)
  - [Discord Server](https://discord.gg/ESHStjSjD4)

## Assessment

To complete this lesson, students should be able to:
1. Successfully operate OpenHands in all four modes
2. Understand when to use each mode appropriately
3. Configure and customize each mode for specific use cases
4. Implement basic security measures for each mode
5. Troubleshoot common issues in each operational mode

Next Lesson Preview: Lesson 6 will cover File System and Runtime Management, building upon the operational modes we've learned here.