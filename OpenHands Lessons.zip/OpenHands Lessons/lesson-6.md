# Lesson 6: File System and Runtime Management

## Lesson Overview

This lesson explores the intricacies of file system operations and runtime management in OpenHands. We'll dive deep into how OpenHands manages files, interacts with the host system, and maintains security through its sandbox environment. Understanding these concepts is crucial for effectively managing and scaling OpenHands deployments.

## Prerequisites
- Completion of Lesson 5: Operational Modes and Interfaces
- Understanding of Docker containers and volumes
- Basic knowledge of Linux file systems
- Familiarity with system permissions

## 1. Understanding the Sandbox Environment

### Sandbox Architecture

The OpenHands sandbox environment is structured as follows:

```
sandbox/
├── runtime/
│   ├── base-container/
│   │   ├── Dockerfile
│   │   └── runtime-components/
│   └── plugins/
│       ├── jupyter/
│       ├── browser/
│       └── custom-plugins/
├── workspace/
│   ├── user-files/
│   └── temp-files/
└── system/
    ├── configs/
    └── security/
```

The sandbox environment serves several crucial purposes:
1. Isolation of execution environment
2. Security boundary enforcement
3. Resource management
4. Clean state maintenance
5. Plugin system support

### Container Image Management

OpenHands uses a specialized runtime image system with three types of tags:
1. Source Tags (most specific)
2. Lock Tags (dependency management)
3. Versioned Tags (most generic)

Example of image tagging system:
```
oh_v0.9.9_1234567890abcdef_1234567890abcdef  # Source tag
oh_v0.9.9_1234567890abcdef                    # Lock tag
oh_v0.9.9_nikolaik                            # Versioned tag
```

## 2. File System Operations

### Workspace Structure

The OpenHands workspace is organized as follows:

```
workspace_base/
├── .openhands/
│   ├── cache/
│   ├── logs/
│   └── config/
├── project-files/
│   ├── source/
│   └── generated/
└── temp/
    └── runtime-files/
```

### File System Mounting

To mount your local filesystem into OpenHands:

```bash
export WORKSPACE_BASE=/path/to/your/code

docker run -it --rm \
    -e SANDBOX_USER_ID=$(id -u) \
    -e WORKSPACE_MOUNT_PATH=$WORKSPACE_BASE \
    -v $WORKSPACE_BASE:/opt/workspace_base \
    # ... other options ...
```

### Permission Management

OpenHands implements a sophisticated permission system:

1. User Mapping:
```toml
# config.toml
[sandbox]
user_id = 1000  # Default sandbox user ID
```

2. Volume Permissions:
```bash
# Ensure correct ownership
chown -R $SANDBOX_USER_ID:$SANDBOX_USER_ID $WORKSPACE_BASE
```

## 3. Runtime Configuration and Management

### Runtime Types

OpenHands supports multiple runtime environments:

1. Docker Runtime (Default):
```toml
[core]
runtime = "eventstream"
sandbox_base_container_image = "docker.all-hands.dev/all-hands-ai/runtime:0.13-nikolaik"
```

2. All Hands Runtime (Beta):
```toml
[core]
runtime = "remote"
sandbox_remote_runtime_api_url = "https://runtime.app.all-hands.dev"
sandbox_api_key = "your-all-hands-api-key"
```

3. Modal Runtime:
```toml
[core]
runtime = "modal"
modal_api_token_id = "your-id"
modal_api_token_secret = "your-secret"
```

### Runtime Lifecycle Management

The runtime lifecycle follows these stages:

1. Initialization:
```python
runtime = create_runtime(config)
await runtime.connect()
```

2. Execution:
```python
state = run_controller(
    config=config,
    task_str=instruction,
    runtime=runtime
)
```

3. Cleanup:
```python
await runtime.disconnect()
```

## 4. Custom Runtime Development

### Creating a Custom Runtime

To create a custom runtime, implement the Runtime interface:

```python
from zope.interface import Interface, implementer
from openhands.runtime.runtime import Runtime

@implementer(Runtime)
class CustomRuntime:
    async def connect(self):
        # Implementation
        pass

    async def disconnect(self):
        # Implementation
        pass

    async def execute(self, action):
        # Implementation
        pass
```

### Plugin System Integration

The plugin system follows this structure:

```
plugins/
├── __init__.py
├── base.py
└── custom_plugin/
    ├── __init__.py
    ├── plugin.py
    └── requirements.txt
```

Example plugin implementation:

```python
from openhands.runtime.plugins import Plugin

class CustomPlugin(Plugin):
    def __init__(self):
        super().__init__("custom_plugin")

    async def initialize(self):
        # Plugin initialization code
        pass

    async def cleanup(self):
        # Cleanup code
        pass
```

## 5. Security Implementation

### Sandbox Security Measures

1. Resource Limits:
```toml
[sandbox]
timeout = 300  # 5 minute timeout
memory_limit = "2g"
cpu_limit = "1.0"
```

2. Network Isolation:
```toml
[sandbox]
use_host_network = false
allowed_hosts = ["api.github.com"]
```

3. File System Restrictions:
```toml
[sandbox]
read_only_paths = ["/etc", "/usr"]
writable_paths = ["/workspace"]
```

## 6. Performance Optimization

### Resource Management

1. Container Resource Allocation:
```bash
docker run \
    --cpus=2 \
    --memory=4g \
    --memory-swap=4g \
    # ... other options ...
```

2. File System Caching:
```toml
[core]
cache_dir = "/path/to/cache"
file_store = "local"
file_store_path = "/path/to/store"
```

### Monitoring and Logging

1. Log Configuration:
```toml
[logging]
level = "INFO"
file = "openhands.log"
format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
```

2. Performance Metrics:
```python
from openhands.metrics import MetricsCollector

metrics = MetricsCollector()
metrics.record_timing("file_operation", duration)
```

## 7. Cross-Platform Considerations

### Windows (WSL)

Special considerations for Windows systems:
1. Path translation between Windows and WSL
2. File permission mapping
3. Docker desktop configuration
4. Network routing through WSL

### macOS

MacOS-specific configurations:
1. Docker desktop resource allocation
2. File system performance optimization
3. Network configuration for docker containers

### Linux

Native Linux optimizations:
1. Direct Docker integration
2. Native file system performance
3. System resource management

## Practical Exercises

1. Runtime Configuration:
   Set up different runtime configurations and compare their performance.

2. Custom Plugin Development:
   Create a basic custom plugin that adds new functionality to OpenHands.

3. File System Management:
   Implement a file backup system using OpenHands's file system capabilities.

4. Security Implementation:
   Configure and test various security measures in the sandbox environment.

## Additional Resources

- [OpenHands Runtime Documentation](https://docs.all-hands.dev/modules/usage/architecture/runtime)
- [Docker Documentation](https://docs.docker.com/)
- [Security Best Practices](https://docs.all-hands.dev/modules/usage/security)
- Community Support:
  - [Slack Workspace](https://join.slack.com/t/opendevin/shared_invite/zt-2oikve2hu-UDxHeo8nsE69y6T7yFX_BA)
  - [Discord Server](https://discord.gg/ESHStjSjD4)

## Assessment

To complete this lesson, students should be able to:
1. Configure and manage different runtime environments
2. Implement custom plugins
3. Manage file system operations securely
4. Optimize performance for different platforms
5. Implement appropriate security measures
6. Troubleshoot common runtime issues

## Next Lesson Preview

Lesson 7 will cover Agent Development and Customization, building upon our understanding of the runtime environment and file system operations to create and modify OpenHands agents.