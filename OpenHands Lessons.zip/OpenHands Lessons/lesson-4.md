# Lesson 4: Advanced LLM Operations

## Lesson Overview
This advanced lesson delves deep into sophisticated LLM operations within OpenHands. Students will learn advanced prompt engineering, response optimization, cross-model compatibility, and advanced debugging techniques. The lesson emphasizes practical implementation with real-world examples and performance optimization strategies.

## Duration: 4 hours

## Learning Objectives
By the end of this lesson, students will be able to:
1. Master advanced prompt engineering techniques
2. Implement sophisticated response handling
3. Optimize LLM performance across different models
4. Debug complex LLM interactions
5. Implement advanced cost optimization strategies
6. Handle cross-model compatibility issues

## Detailed Content

### 1. Advanced Prompt Engineering

Understanding and implementing sophisticated prompt engineering techniques is crucial for optimal LLM performance in OpenHands.

#### System Message Template Framework
```python
class SystemMessageTemplate:
    """Framework for creating structured system messages."""
    
    def __init__(self):
        self.context = []
        self.constraints = []
        self.examples = []
        self.format_requirements = []
        
    def add_context(self, context: str):
        """Add contextual information for the LLM."""
        self.context.append(context)
        
    def add_constraint(self, constraint: str):
        """Add operational constraints."""
        self.constraints.append(constraint)
        
    def add_example(self, example: str):
        """Add few-shot examples."""
        self.examples.append(example)
        
    def add_format_requirement(self, requirement: str):
        """Add output format requirements."""
        self.format_requirements.append(requirement)
        
    def build(self) -> str:
        """Construct the final system message."""
        message_parts = []
        
        if self.context:
            message_parts.append("Context:\n" + "\n".join(self.context))
            
        if self.constraints:
            message_parts.append("Constraints:\n" + "\n".join(self.constraints))
            
        if self.examples:
            message_parts.append("Examples:\n" + "\n".join(self.examples))
            
        if self.format_requirements:
            message_parts.append("Output Format:\n" + "\n".join(self.format_requirements))
            
        return "\n\n".join(message_parts)
```

#### Advanced Prompt Templates for Code Generation
```python
class CodeGenerationPrompt:
    """Specialized prompt templates for code generation tasks."""
    
    @staticmethod
    def create_refactoring_prompt(code: str, target_language: str) -> str:
        template = SystemMessageTemplate()
        
        template.add_context(f"""
You are an expert software developer specializing in {target_language}.
Your task is to refactor the provided code following best practices and design patterns.
Consider:
1. Code readability and maintainability
2. Performance optimization
3. Error handling
4. Documentation standards
""")
        
        template.add_constraint("""
- Maintain existing functionality
- Preserve public interfaces
- Add comprehensive documentation
- Include error handling
""")
        
        template.add_example(f"""
Original code:
```{target_language}
function processData(data) {{
    var result = [];
    for(var i=0; i<data.length; i++) {{
        if(data[i] > 0) result.push(data[i] * 2);
    }}
    return result;
}}
```

Refactored code:
```{target_language}
/**
 * Processes an array of numbers by doubling positive values.
 * @param {{number[]}} data - Input array of numbers
 * @returns {{number[]}} Array containing doubled positive numbers
 * @throws {{Error}} If input is not an array
 */
function processData(data) {{
    if (!Array.isArray(data)) {{
        throw new Error('Input must be an array');
    }}
    
    return data
        .filter(value => value > 0)
        .map(value => value * 2);
}}
```
""")
        
        return template.build() + f"\n\nCode to refactor:\n```{target_language}\n{code}\n```"
```

### 2. Response Optimization and Parsing

Implementing sophisticated response handling and parsing mechanisms:

#### Advanced Response Parser
```python
from dataclasses import dataclass
from typing import Optional, List, Dict, Any
import json
import re

@dataclass
class CodeBlock:
    language: str
    code: str
    metadata: Dict[str, Any]

@dataclass
class ParsedResponse:
    explanation: Optional[str]
    code_blocks: List[CodeBlock]
    action_items: List[str]
    references: List[str]

class LLMResponseParser:
    """Advanced response parser for LLM outputs."""
    
    @staticmethod
    def extract_code_blocks(text: str) -> List[CodeBlock]:
        """Extract code blocks with language and metadata."""
        pattern = r"```(\w+)?\s*({[^}]+})?\n(.*?)```"
        matches = re.finditer(pattern, text, re.DOTALL)
        
        code_blocks = []
        for match in matches:
            language = match.group(1) or "text"
            metadata_str = match.group(2) or "{}"
            code = match.group(3).strip()
            
            try:
                metadata = json.loads(metadata_str)
            except json.JSONDecodeError:
                metadata = {}
                
            code_blocks.append(CodeBlock(
                language=language,
                code=code,
                metadata=metadata
            ))
            
        return code_blocks
    
    @staticmethod
    def extract_action_items(text: str) -> List[str]:
        """Extract action items from response."""
        action_pattern = r"(?:^|\n)(?:[-*]\s*|\d+\.\s*)(TODO|FIXME|NOTE|ACTION):\s*(.+)(?:\n|$)"
        matches = re.finditer(action_pattern, text, re.MULTILINE)
        return [match.group(2).strip() for match in matches]
    
    @staticmethod
    def extract_references(text: str) -> List[str]:
        """Extract referenced documentation or resources."""
        ref_pattern = r"(?:^|\n)(?:Reference|See|Docs):\s*(.+)(?:\n|$)"
        matches = re.finditer(ref_pattern, text, re.MULTILINE)
        return [match.group(1).strip() for match in matches]
    
    @classmethod
    def parse(cls, text: str) -> ParsedResponse:
        """Parse complete LLM response."""
        # Extract code blocks
        code_blocks = cls.extract_code_blocks(text)
        
        # Remove code blocks from text for further processing
        clean_text = re.sub(r"```.*?```", "", text, flags=re.DOTALL)
        
        # Extract other components
        action_items = cls.extract_action_items(clean_text)
        references = cls.extract_references(clean_text)
        
        # Remaining text is explanation
        explanation = clean_text.strip()
        
        return ParsedResponse(
            explanation=explanation,
            code_blocks=code_blocks,
            action_items=action_items,
            references=references
        )
```

### 3. Cross-Model Compatibility

Implementing robust cross-model compatibility strategies:

#### Model Adapter Framework
```python
from abc import ABC, abstractmethod
from typing import Dict, Any

class ModelAdapter(ABC):
    """Abstract base class for model-specific adapters."""
    
    @abstractmethod
    def prepare_prompt(self, prompt: str) -> Dict[str, Any]:
        """Prepare prompt for specific model."""
        pass
    
    @abstractmethod
    def parse_response(self, response: Any) -> str:
        """Parse model-specific response format."""
        pass
    
    @abstractmethod
    def get_token_count(self, text: str) -> int:
        """Get token count for specific model."""
        pass

class AnthropicAdapter(ModelAdapter):
    """Adapter for Anthropic Claude models."""
    
    def prepare_prompt(self, prompt: str) -> Dict[str, Any]:
        return {
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "model": "claude-3-5-sonnet-20241022",
            "max_tokens": 4096
        }
    
    def parse_response(self, response: Any) -> str:
        return response.completion
    
    def get_token_count(self, text: str) -> int:
        # Implementation for Claude token counting
        pass

class GPTAdapter(ModelAdapter):
    """Adapter for OpenAI GPT models."""
    
    def prepare_prompt(self, prompt: str) -> Dict[str, Any]:
        return {
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "model": "gpt-4",
            "max_tokens": 4000
        }
    
    def parse_response(self, response: Any) -> str:
        return response.choices[0].message.content
    
    def get_token_count(self, text: str) -> int:
        # Implementation for GPT token counting
        pass
```

### 4. Advanced Debugging Techniques

Implementing comprehensive debugging tools for LLM interactions:

#### LLM Interaction Logger
```python
import logging
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

class LLMDebugger:
    """Advanced debugger for LLM interactions."""
    
    def __init__(self, log_dir: str = "logs/llm"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Set up logging
        self.logger = logging.getLogger("LLMDebugger")
        self.logger.setLevel(logging.DEBUG)
        
        # File handler for detailed logs
        fh = logging.FileHandler(
            self.log_dir / f"llm_debug_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        )
        fh.setLevel(logging.DEBUG)
        
        # Format for detailed logging
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        fh.setFormatter(formatter)
        self.logger.addHandler(fh)
        
    def log_interaction(
        self,
        prompt: str,
        response: str,
        metadata: Dict[str, Any]
    ):
        """Log complete interaction with metadata."""
        timestamp = datetime.now().isoformat()
        
        interaction_data = {
            "timestamp": timestamp,
            "prompt": prompt,
            "response": response,
            "metadata": metadata
        }
        
        # Log to file
        interaction_file = self.log_dir / f"interaction_{timestamp}.json"
        with open(interaction_file, 'w') as f:
            json.dump(interaction_data, f, indent=2)
            
        # Log summary to debug log
        self.logger.debug(
            f"Interaction logged: {interaction_file}\n"
            f"Tokens: {metadata.get('token_count', 'N/A')}\n"
            f"Duration: {metadata.get('duration_ms', 'N/A')}ms"
        )
        
    def analyze_interactions(self, timeframe: str = "1d") -> Dict[str, Any]:
        """Analyze interactions within specified timeframe."""
        analysis = {
            "total_interactions": 0,
            "total_tokens": 0,
            "average_duration_ms": 0,
            "error_rate": 0,
            "token_distribution": {}
        }
        
        # Implementation of analysis logic
        return analysis
```

### 5. Performance Optimization

Implementing advanced performance optimization strategies:

#### Performance Monitor
```python
from dataclasses import dataclass
from typing import Dict, List
import time
import statistics

@dataclass
class PerformanceMetric:
    timestamp: float
    duration_ms: float
    token_count: int
    success: bool
    error: str = None

class LLMPerformanceMonitor:
    """Monitor and optimize LLM performance."""
    
    def __init__(self):
        self.metrics: List[PerformanceMetric] = []
        self.thresholds = {
            "max_duration_ms": 5000,
            "max_token_count": 4000,
            "error_rate_threshold": 0.1
        }
        
    def add_metric(self, metric: PerformanceMetric):
        """Add performance metric."""
        self.metrics.append(metric)
        
        # Trigger optimization if thresholds are exceeded
        if len(self.metrics) >= 10:
            self.optimize()
            
    def analyze_performance(self) -> Dict[str, float]:
        """Analyze current performance metrics."""
        if not self.metrics:
            return {}
            
        durations = [m.duration_ms for m in self.metrics]
        token_counts = [m.token_count for m in self.metrics]
        error_rate = len([m for m in self.metrics if not m.success]) / len(self.metrics)
        
        return {
            "avg_duration_ms": statistics.mean(durations),
            "avg_token_count": statistics.mean(token_counts),
            "error_rate": error_rate,
            "p95_duration_ms": statistics.quantiles(durations, n=20)[-1]
        }
        
    def optimize(self):
        """Optimize based on performance metrics."""
        analysis = self.analyze_performance()
        
        optimizations = []
        if analysis["avg_duration_ms"] > self.thresholds["max_duration_ms"]:
            optimizations.append("Reduce prompt complexity")
            
        if analysis["avg_token_count"] > self.thresholds["max_token_count"]:
            optimizations.append("Implement token optimization")
            
        if analysis["error_rate"] > self.thresholds["error_rate_threshold"]:
            optimizations.append("Implement additional error handling")
            
        return optimizations
```

## Practical Exercise

Students will implement:
1. Advanced prompt engineering system
2. Sophisticated response parser
3. Cross-model compatibility framework
4. Debug logging system
5. Performance monitoring and optimization

## Additional Resources

1. OpenHands Advanced Configuration: [docs.all-hands.dev/advanced](https://docs.all-hands.dev/advanced)
2. LiteLLM Advanced Features: [docs.litellm.ai/advanced](https://docs.litellm.ai/advanced)
3. Anthropic Prompt Engineering Guide: [docs.anthropic.com/prompting](https://docs.anthropic.com/prompting)

## Next Steps

In the next lesson, we'll explore operational modes and interfaces, building upon these advanced LLM operations.

## Assignment

Create a comprehensive LLM operations toolkit that includes:
1. Advanced prompt generation system
2. Response parsing framework
3. Cross-model compatibility layer
4. Debug logging implementation
5. Performance monitoring system
6. Optimization strategies implementation

This assignment will help solidify understanding of advanced LLM operations and prepare for practical implementation in complex scenarios.
