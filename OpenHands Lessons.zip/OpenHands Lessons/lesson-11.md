# Lesson 11: Development Best Practices for OpenHands

## Introduction

This lesson covers comprehensive development best practices for the OpenHands project, focusing on code organization, documentation standards, testing methodologies, security practices, and performance optimization. We'll explore how these practices come together in a real-world development environment.

## Code Organization and Structure

### Project Layout
OpenHands follows a clear and organized structure that separates concerns and makes the codebase maintainable. Here's the standard layout:

```
openhands/
├── frontend/           # Frontend React application
├── openhands/         # Core Python backend
│   ├── agenthub/      # Agent implementations
│   ├── controller/    # Control flow and state management
│   ├── core/          # Core functionality
│   ├── events/        # Event handling
│   ├── runtime/       # Runtime implementations
│   └── server/        # Server and API endpoints
├── evaluation/        # Evaluation frameworks and benchmarks
├── docs/             # Documentation
│   ├── modules/      # Module documentation
│   └── static/       # Static assets
└── tests/            # Test suites
    ├── unit/         # Unit tests
    └── integration/  # Integration tests
```

### Module Organization Principles

1. **Separation of Concerns**
   Each module in OpenHands should have a single, well-defined responsibility. For example, the `runtime` module handles sandbox environments, while `agenthub` contains agent implementations. This separation makes the code easier to maintain and test.

2. **Dependency Management**
   Dependencies are managed through Poetry, with clear version specifications in `pyproject.toml`. The file should be organized as follows:
   - Core dependencies under `[tool.poetry.dependencies]`
   - Development dependencies under `[tool.poetry.group.dev.dependencies]`
   - Test dependencies under `[tool.poetry.group.test.dependencies]`

3. **Import Structure**
   Imports should be organized in the following order:
   - Standard library imports
   - Third-party imports
   - Local application imports
   
   Example:
   ```python
   import os
   import sys
   from typing import Optional, List
   
   import docker
   import fastapi
   from litellm import completion
   
   from openhands.core import config
   from openhands.events import action
   ```

## Documentation Standards

1. **Code Documentation**
   - Every module should have a module-level docstring explaining its purpose
   - Classes and functions should have Google-style docstrings
   - Complex algorithms should include inline comments explaining the logic

Example of good documentation:

```python
"""Runtime module for managing sandbox environments.

This module provides abstract and concrete implementations for sandbox
environments where agents can safely execute code and commands.
"""

from typing import Optional

class Runtime:
    """Base class for runtime environments.
    
    Attributes:
        workspace_path: Path to the workspace directory
        timeout: Maximum execution time in seconds
    
    Args:
        config: Runtime configuration object
    """
    
    def __init__(self, config: RuntimeConfig) -> None:
        """Initialize the runtime environment.
        
        Args:
            config: Configuration object containing runtime settings
            
        Raises:
            RuntimeError: If initialization fails
        """
        self.workspace_path = config.workspace_path
        self.timeout = config.timeout
```

2. **README Files**
   Each major component should have its own README.md file containing:
   - Component overview
   - Setup instructions
   - Usage examples
   - Common issues and solutions

3. **API Documentation**
   - Use OpenAPI/Swagger for REST API documentation
   - Include example requests and responses
   - Document error codes and handling

## Testing Methodologies

1. **Unit Testing**
   Unit tests should be small, focused, and follow the Arrange-Act-Assert pattern:

```python
def test_runtime_initialization():
    # Arrange
    config = RuntimeConfig(workspace_path="/tmp", timeout=30)
    
    # Act
    runtime = Runtime(config)
    
    # Assert
    assert runtime.workspace_path == "/tmp"
    assert runtime.timeout == 30
```

2. **Integration Testing**
   Integration tests should verify that components work together correctly:
   - Test actual file system operations
   - Verify Docker container creation and management
   - Test LLM integration with proper mocking

3. **Test Coverage**
   - Maintain high test coverage (aim for >80%)
   - Use pytest-cov to generate coverage reports
   - Focus on testing critical paths and edge cases

## Security Best Practices

1. **Input Validation**
   - Validate all user inputs
   - Use type hints and runtime checks
   - Sanitize file paths and command inputs

Example:
```python
from pathlib import Path
from typing import Optional

def safe_file_operation(filepath: str) -> Optional[str]:
    """Safely perform operations on a file within the workspace.
    
    Args:
        filepath: Path to the file
        
    Returns:
        File contents if successful, None if invalid path
    """
    try:
        path = Path(filepath).resolve()
        workspace = Path("/workspace").resolve()
        
        if not path.is_relative_to(workspace):
            return None
            
        return path.read_text()
    except (ValueError, OSError):
        return None
```

2. **Sandbox Security**
   - Run user code in isolated containers
   - Limit container resources and capabilities
   - Regular security audits of container configurations

3. **API Security**
   - Use proper authentication
   - Rate limiting
   - Input validation
   - Secure secret management

## Performance Optimization

1. **Code Optimization**
   - Use appropriate data structures
   - Implement caching where beneficial
   - Profile code to identify bottlenecks

2. **Resource Management**
   - Proper cleanup of resources (files, containers)
   - Memory management
   - Connection pooling

Example of resource management:
```python
class ManagedResource:
    def __init__(self):
        self.resource = None
    
    def __enter__(self):
        self.resource = acquire_resource()
        return self.resource
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.resource:
            self.resource.cleanup()
```

## Cross-Platform Development

1. **Platform Independence**
   - Use os.path for file operations
   - Handle platform-specific line endings
   - Test on multiple platforms

2. **Docker Compatibility**
   - Use multi-stage builds
   - Platform-specific base images
   - Handle architecture differences

## Contributing Guidelines

1. **Code Style**
   - Follow PEP 8 guidelines
   - Use type hints
   - Consistent naming conventions
   - Use ruff for linting

2. **Git Workflow**
   - Meaningful commit messages
   - Feature branches
   - Pull request templates
   - Code review process

3. **Version Control Best Practices**
   - Regular commits
   - Clear commit messages
   - Branch naming conventions
   - Git hooks for pre-commit checks

## Practical Exercises

1. Create a new agent following the project structure and documentation standards
2. Implement comprehensive tests for the agent
3. Add security measures and performance optimizations
4. Submit a pull request following the contribution guidelines

## Conclusion

Following these development best practices ensures that OpenHands remains maintainable, secure, and performant as it grows. Remember that these practices are not just rules to follow, but principles that help us build better software together.

## Additional Resources

- [Python Style Guide (PEP 8)](https://pep8.org/)
- [Docker Best Practices](https://docs.docker.com/develop/develop-images/dockerfile_best-practices/)
- [FastAPI Documentation](https://fastapi.tiangolo.com/tutorial/)
- [Poetry Documentation](https://python-poetry.org/docs/)
