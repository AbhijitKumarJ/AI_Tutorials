# Lesson 7: Agent Development and Customization

## Lesson Overview

This lesson deep dives into the development and customization of OpenHands agents. We'll explore the architecture of agents, learn how to create custom agents, modify existing ones, and integrate them with various systems. The focus will be on practical implementation while maintaining security and performance standards.

## Prerequisites
- Completion of Lesson 6: File System and Runtime Management
- Strong Python programming skills
- Understanding of LLMs and their APIs
- Basic knowledge of software design patterns

## 1. Understanding Agent Architecture

### Core Agent Structure

The OpenHands agent system follows this architecture:

```
openhands/
├── agenthub/
│   ├── base/
│   │   ├── agent.py
│   │   └── interface.py
│   ├── codeact_agent/
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   └── prompts/
│   └── custom_agents/
└── core/
    ├── controller/
    ├── events/
    └── state/
```

### Agent Components

1. Base Agent Interface:
```python
from abc import ABC, abstractmethod
from openhands.core.state import State
from openhands.events.action import Action
from openhands.events.observation import Observation

class Agent(ABC):
    @abstractmethod
    async def act(self, state: State) -> Action:
        """Generate next action based on current state"""
        pass

    @abstractmethod
    async def observe(self, observation: Observation) -> None:
        """Process an observation from the environment"""
        pass
```

2. State Management:
```python
class State:
    def __init__(self):
        self.history = []
        self.context = {}
        self.metrics = MetricsCollector()
        self.last_error = None
```

## 2. Creating Custom Agents

### Basic Agent Template

```python
from openhands.agenthub.base import Agent
from openhands.core.config import AgentConfig

class CustomAgent(Agent):
    def __init__(self, config: AgentConfig):
        super().__init__(config)
        self.memory = []
        self.llm_client = self._setup_llm()
    
    async def act(self, state: State) -> Action:
        # Process state and generate action
        context = self._build_context(state)
        response = await self.llm_client.generate(context)
        return self._parse_response(response)
    
    async def observe(self, observation: Observation) -> None:
        # Process observation and update internal state
        self.memory.append(observation)
```

### Configuration Management

```toml
# config.toml
[agent.CustomAgent]
llm_config = "gpt-4"
memory_enabled = true
memory_max_threads = 3
```

## 3. Implementing Agent Capabilities

### Action Generation

1. Command Execution:
```python
from openhands.events.action import CmdRunAction

async def execute_command(self, command: str) -> Action:
    return CmdRunAction(
        command=command,
        working_dir=self.workspace_dir,
        timeout=self.config.timeout
    )
```

2. File Operations:
```python
from openhands.events.action import FileWriteAction

async def write_file(self, path: str, content: str) -> Action:
    return FileWriteAction(
        path=path,
        content=content,
        mode="w"
    )
```

### Memory Management

1. Thread-based Memory:
```python
class MemoryManager:
    def __init__(self, max_threads: int):
        self.threads = []
        self.max_threads = max_threads
    
    def add_memory(self, observation: Observation):
        if len(self.threads) >= self.max_threads:
            self.threads.pop(0)
        self.threads.append(observation)
```

2. Context Building:
```python
def build_context(self, state: State) -> str:
    context = []
    for thread in self.memory.threads:
        context.append(f"Previous action: {thread.action}")
        context.append(f"Observation: {thread.observation}")
    return "\n".join(context)
```

## 4. LLM Integration

### Prompt Engineering

1. System Prompt Template:
```python
SYSTEM_PROMPT = """You are an AI development agent capable of:
1. Writing and modifying code
2. Running shell commands
3. Managing files
4. Browsing documentation

Follow these guidelines:
- Write clear, documented code
- Use appropriate error handling
- Consider security implications
- Optimize for performance

Current workspace: {workspace}
Available tools: {tools}
"""
```

2. Task Processing:
```python
async def process_task(self, task: str) -> str:
    prompt = self._build_prompt(task)
    response = await self.llm_client.chat(
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7
    )
    return response.content
```

## 5. Security Implementation

### Input Validation

```python
class SecurityValidator:
    def __init__(self):
        self.blocked_commands = ["rm -rf", "sudo", "chmod 777"]
    
    def validate_command(self, command: str) -> bool:
        return not any(cmd in command for cmd in self.blocked_commands)
    
    def validate_file_path(self, path: str) -> bool:
        return not path.startswith("/") and ".." not in path
```

### Permission Management

```python
class PermissionManager:
    def __init__(self, workspace_dir: str):
        self.workspace_dir = workspace_dir
    
    def can_access_path(self, path: str) -> bool:
        absolute_path = os.path.abspath(path)
        return absolute_path.startswith(self.workspace_dir)
```

## 6. Performance Optimization

### Caching System

```python
from functools import lru_cache

class ResponseCache:
    @lru_cache(maxsize=1000)
    async def get_cached_response(self, prompt: str) -> str:
        return await self.llm_client.generate(prompt)
```

### Batch Processing

```python
class BatchProcessor:
    def __init__(self, batch_size: int = 5):
        self.batch_size = batch_size
        self.queue = []
    
    async def process_batch(self):
        if len(self.queue) >= self.batch_size:
            batch = self.queue[:self.batch_size]
            self.queue = self.queue[self.batch_size:]
            return await self._process_items(batch)
```

## 7. Testing and Validation

### Unit Testing

```python
import pytest
from openhands.testing import MockLLM

@pytest.fixture
def custom_agent():
    config = AgentConfig(llm_config="mock")
    return CustomAgent(config)

async def test_agent_action(custom_agent):
    state = State()
    action = await custom_agent.act(state)
    assert isinstance(action, Action)
    assert action.is_valid()
```

### Integration Testing

```python
async def test_agent_workflow():
    agent = CustomAgent(config)
    runtime = create_runtime(config)
    
    await runtime.connect()
    state = run_controller(
        config=config,
        task_str="Write a hello world program",
        runtime=runtime,
        agent=agent
    )
    assert state.last_error is None
```

## 8. Deployment Considerations

### Environment Setup

```bash
# Production deployment script
#!/bin/bash

# Set environment variables
export AGENT_TYPE="CustomAgent"
export LLM_MODEL="gpt-4"
export MEMORY_ENABLED="true"

# Start the agent
python -m openhands.core.main \
    --agent $AGENT_TYPE \
    --model $LLM_MODEL \
    --workspace /path/to/workspace
```

### Monitoring

```python
from openhands.monitoring import AgentMonitor

class AgentMetricsCollector:
    def __init__(self):
        self.monitor = AgentMonitor()
    
    def record_action(self, action: Action):
        self.monitor.increment_counter("actions_total")
        self.monitor.record_timing("action_duration")
```

## Practical Exercises

1. Basic Agent Development:
   Create a simple agent that can respond to basic commands and file operations.

2. Advanced Agent Features:
   Implement memory management and context building in your custom agent.

3. Security Implementation:
   Add security validations and permission checks to your agent.

4. Performance Testing:
   Create benchmarks and optimize your agent's performance.

## Additional Resources

- [OpenHands Agent Documentation](https://docs.all-hands.dev/modules/usage/agents)
- [LLM Integration Guide](https://docs.all-hands.dev/modules/usage/llms)
- [Security Best Practices](https://docs.all-hands.dev/modules/usage/security)
- Community Support:
  - [Slack Workspace](https://join.slack.com/t/opendevin/shared_invite/zt-2oikve2hu-UDxHeo8nsE69y6T7yFX_BA)
  - [Discord Server](https://discord.gg/ESHStjSjD4)

## Assessment

To complete this lesson, students should be able to:
1. Create a custom agent from scratch
2. Implement proper security measures
3. Optimize agent performance
4. Write comprehensive tests
5. Deploy and monitor agents in production

## Next Lesson Preview

Lesson 8 will cover Runtime and Plugin System, building upon our understanding of agents to create more sophisticated interactions with the OpenHands environment.