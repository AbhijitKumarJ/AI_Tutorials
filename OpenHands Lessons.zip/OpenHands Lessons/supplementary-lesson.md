# Supplementary Lesson: Foundation Concepts and Additional Topics

## Introduction

This supplementary lesson covers foundational concepts that were assumed in the main curriculum and addresses additional topics that deserve deeper exploration. Understanding these concepts is crucial for mastering OpenHands development and deployment.

## Part 1: Core Concepts

### Understanding Docker and Containerization

While Docker was mentioned throughout the series, let's dive deeper into how it works in OpenHands:

1. **Container Basics**
   Docker containers are lightweight, isolated environments that package everything needed to run an application. In OpenHands, containers serve two primary purposes:

   ```plaintext
   OpenHands Container Architecture:
   
   Host System
   └── OpenHands Main Container
       └── Sandbox Containers (for running user code)
           ├── Isolated file system
           ├── Network namespace
           └── Process namespace
   ```

   The sandbox container system provides:
   - Process isolation
   - Resource limitations
   - Security boundaries
   - Clean environment for each execution

2. **Docker Networking**
   Understanding how OpenHands containers communicate:

   ```plaintext
   Network Architecture:
   
   Host Machine (localhost:3000)
   ├── OpenHands Container (host.docker.internal)
   │   └── Internal API (localhost:3000)
   └── Sandbox Containers
       └── Network Bridge
   ```

### Python Async Programming

Async programming is used extensively in OpenHands but wasn't fully explained. Here's a deeper look:

1. **Async/Await Pattern**
   ```python
   import asyncio
   from typing import Optional

   class AsyncExecutor:
       """Example of async execution in OpenHands."""
       
       async def execute_command(self, command: str) -> Optional[str]:
           """Execute a command asynchronously.
           
           Args:
               command: Command to execute
               
           Returns:
               Optional[str]: Command output if successful
           """
           try:
               # Simulate long-running process
               await asyncio.sleep(1)  # Non-blocking wait
               return f"Executed: {command}"
           except Exception as e:
               print(f"Error: {e}")
               return None

       async def run_multiple_commands(self, commands: list[str]):
           """Run multiple commands concurrently.
           
           Args:
               commands: List of commands to execute
           """
           tasks = [self.execute_command(cmd) for cmd in commands]
           results = await asyncio.gather(*tasks)
           return results
   ```

2. **Event Loop Management**
   ```python
   import asyncio
   from contextlib import asynccontextmanager

   class EventLoopManager:
       """Manage async event loops in OpenHands."""
       
       @asynccontextmanager
       async def managed_loop(self):
           """Create and manage an event loop."""
           loop = asyncio.new_event_loop()
           asyncio.set_event_loop(loop)
           try:
               yield loop
           finally:
               loop.close()

       async def run_async_task(self, coro):
           """Run an async task with proper loop management."""
           async with self.managed_loop() as loop:
               return await loop.run_until_complete(coro)
   ```

### Type System and Static Type Checking

OpenHands makes extensive use of Python's type system:

1. **Type Hints and Generics**
   ```python
   from typing import TypeVar, Generic, Optional, List

   T = TypeVar('T')

   class Result(Generic[T]):
       """Generic result container used in OpenHands."""
       
       def __init__(self, value: Optional[T] = None, error: Optional[str] = None):
           self.value = value
           self.error = error

       @property
       def is_success(self) -> bool:
           return self.error is None

       def unwrap(self) -> T:
           """Get the value or raise error."""
           if self.error:
               raise ValueError(self.error)
           return self.value

   class DataProcessor(Generic[T]):
       """Generic data processor."""
       
       def process(self, items: List[T]) -> List[Result[T]]:
           return [self._process_item(item) for item in items]

       def _process_item(self, item: T) -> Result[T]:
           try:
               # Process item
               return Result(value=item)
           except Exception as e:
               return Result(error=str(e))
   ```

2. **Runtime Type Checking**
   ```python
   from typing import Any, Type, TypeVar, cast
   from dataclasses import dataclass

   T = TypeVar('T')

   @dataclass
   class TypeChecker:
       """Runtime type checking utilities."""

       @staticmethod
       def ensure_type(value: Any, expected_type: Type[T]) -> T:
           """Ensure value is of expected type.
           
           Args:
               value: Value to check
               expected_type: Expected type
               
           Returns:
               T: Value cast to expected type
               
           Raises:
               TypeError: If value is not of expected type
           """
           if not isinstance(value, expected_type):
               raise TypeError(f"Expected {expected_type}, got {type(value)}")
           return cast(expected_type, value)
   ```

## Part 2: Advanced Topics

### Memory Management and Resource Optimization

1. **Memory Profiling Tools**
   ```python
   from typing import Any, Dict
   import tracemalloc
   from dataclasses import dataclass

   @dataclass
   class MemorySnapshot:
       """Memory snapshot information."""
       
       total: int
       peak: int
       current: int

   class MemoryProfiler:
       """Advanced memory profiling for OpenHands."""
       
       def __init__(self):
           self.snapshots: Dict[str, MemorySnapshot] = {}

       def start_tracking(self):
           """Start memory tracking."""
           tracemalloc.start()

       def take_snapshot(self, name: str):
           """Take a memory snapshot."""
           snapshot = tracemalloc.take_snapshot()
           stats = snapshot.statistics('lineno')
           
           total = sum(stat.size for stat in stats)
           peak = tracemalloc.get_traced_memory()[1]
           current = tracemalloc.get_traced_memory()[0]
           
           self.snapshots[name] = MemorySnapshot(
               total=total,
               peak=peak,
               current=current
           )

       def compare_snapshots(self, snapshot1: str, snapshot2: str) -> Dict[str, Any]:
           """Compare two memory snapshots."""
           s1 = self.snapshots[snapshot1]
           s2 = self.snapshots[snapshot2]
           
           return {
               'total_diff': s2.total - s1.total,
               'peak_diff': s2.peak - s1.peak,
               'current_diff': s2.current - s1.current
           }
   ```

### Advanced Security Concepts

1. **RBAC (Role-Based Access Control)**
   ```python
   from enum import Enum, auto
   from typing import Set, Dict, List
   from dataclasses import dataclass

   class Permission(Enum):
       """Permissions in OpenHands."""
       
       READ = auto()
       WRITE = auto()
       EXECUTE = auto()
       ADMIN = auto()

   @dataclass
   class Role:
       """Role definition."""
       
       name: str
       permissions: Set[Permission]

   class RBACSystem:
       """Role-based access control system."""
       
       def __init__(self):
           self.roles: Dict[str, Role] = {}
           self.user_roles: Dict[str, List[str]] = {}

       def add_role(self, role: Role):
           """Add a new role."""
           self.roles[role.name] = role

       def assign_role(self, user_id: str, role_name: str):
           """Assign role to user."""
           if user_id not in self.user_roles:
               self.user_roles[user_id] = []
           self.user_roles[user_id].append(role_name)

       def has_permission(self, user_id: str, permission: Permission) -> bool:
           """Check if user has permission."""
           if user_id not in self.user_roles:
               return False
               
           user_permissions = set()
           for role_name in self.user_roles[user_id]:
               role = self.roles[role_name]
               user_permissions.update(role.permissions)
               
           return permission in user_permissions
   ```

### Plugin System Architecture

1. **Plugin Management**
   ```python
   from abc import ABC, abstractmethod
   from typing import Dict, Type, Optional
   import importlib

   class Plugin(ABC):
       """Base class for OpenHands plugins."""
       
       @abstractmethod
       async def initialize(self):
           """Initialize the plugin."""
           pass

       @abstractmethod
       async def cleanup(self):
           """Clean up plugin resources."""
           pass

   class PluginManager:
       """Manage OpenHands plugins."""
       
       def __init__(self):
           self.plugins: Dict[str, Plugin] = {}

       async def load_plugin(self, plugin_path: str) -> Optional[Plugin]:
           """Load a plugin from path.
           
           Args:
               plugin_path: Import path to plugin
               
           Returns:
               Optional[Plugin]: Loaded plugin instance
           """
           try:
               module = importlib.import_module(plugin_path)
               plugin_class: Type[Plugin] = getattr(module, 'Plugin')
               plugin = plugin_class()
               await plugin.initialize()
               self.plugins[plugin_path] = plugin
               return plugin
           except Exception as e:
               print(f"Failed to load plugin {plugin_path}: {e}")
               return None

       async def unload_plugin(self, plugin_path: str):
           """Unload a plugin."""
           if plugin_path in self.plugins:
               await self.plugins[plugin_path].cleanup()
               del self.plugins[plugin_path]
   ```

### State Management and Persistence

1. **State Management System**
   ```python
   from typing import Any, Dict, Optional
   import json
   from pathlib import Path

   class StateManager:
       """Manage application state in OpenHands."""
       
       def __init__(self, state_file: Path):
           self.state_file = state_file
           self.state: Dict[str, Any] = {}
           self._load_state()

       def _load_state(self):
           """Load state from file."""
           if self.state_file.exists():
               with open(self.state_file, 'r') as f:
                   self.state = json.load(f)

       def _save_state(self):
           """Save state to file."""
           with open(self.state_file, 'w') as f:
               json.dump(self.state, f)

       def get(self, key: str, default: Any = None) -> Any:
           """Get state value."""
           return self.state.get(key, default)

       def set(self, key: str, value: Any):
           """Set state value."""
           self.state[key] = value
           self._save_state()

       def delete(self, key: str):
           """Delete state value."""
           if key in self.state:
               del self.state[key]
               self._save_state()
   ```

## Part 3: Integration Patterns

### Message Queue Integration

1. **Message Queue Handler**
   ```python
   from typing import Callable, Any, Awaitable
   import asyncio
   from dataclasses import dataclass

   @dataclass
   class Message:
       """Message structure."""
       
       topic: str
       payload: Any

   class MessageQueue:
       """Simple message queue implementation."""
       
       def __init__(self):
           self.subscribers: Dict[str, List[Callable[[Message], Awaitable[None]]]] = {}

       async def publish(self, message: Message):
           """Publish message to topic."""
           if message.topic in self.subscribers:
               tasks = [
                   handler(message)
                   for handler in self.subscribers[message.topic]
               ]
               await asyncio.gather(*tasks)

       def subscribe(self, topic: str, handler: Callable[[Message], Awaitable[None]]):
           """Subscribe to topic."""
           if topic not in self.subscribers:
               self.subscribers[topic] = []
           self.subscribers[topic].append(handler)
   ```

### Error Handling and Recovery

1. **Advanced Error Recovery**
   ```python
   from typing import TypeVar, Callable, Awaitable
   import asyncio
   from functools import wraps

   T = TypeVar('T')

   class RetryStrategy:
       """Retry strategy for operations."""
       
       def __init__(self, max_retries: int, delay: float, backoff: float = 2.0):
           self.max_retries = max_retries
           self.delay = delay
           self.backoff = backoff

   def with_retry(strategy: RetryStrategy):
       """Decorator for retry logic."""
       def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
           @wraps(func)
           async def wrapper(*args, **kwargs) -> T:
               delay = strategy.delay
               for attempt in range(strategy.max_retries):
                   try:
                       return await func(*args, **kwargs)
                   except Exception as e:
                       if attempt == strategy.max_retries - 1:
                           raise
                       await asyncio.sleep(delay)
                       delay *= strategy.backoff
           return wrapper
       return decorator
   ```

## Conclusion

This supplementary lesson has covered important foundational concepts and advanced topics that were assumed or not fully explained in the main curriculum. Understanding these concepts will help you:

1. Better understand the OpenHands architecture
2. Write more efficient and maintainable code
3. Implement advanced features and integrations
4. Debug and troubleshoot issues more effectively

## Additional Resources

- [Python Type Hints Documentation](https://docs.python.org/3/library/typing.html)
- [AsyncIO Documentation](https://docs.python.org/3/library/asyncio.html)
- [Docker Documentation](https://docs.docker.com/)
- [Python Memory Management](https://docs.python.org/3/c-api/memory.html)
