# Lesson 12: Troubleshooting and Maintenance

## Introduction

This final lesson covers comprehensive troubleshooting strategies and maintenance procedures for OpenHands deployments. We'll explore common issues, debugging techniques, performance profiling, security auditing, and system maintenance procedures. This knowledge is crucial for maintaining a healthy, secure, and efficient OpenHands installation.

## Common Issues and Solutions

### Environment Issues

#### Docker-Related Problems

One of the most common issues users face involves Docker configuration. Here's a systematic approach to troubleshooting Docker issues:

1. **Connection Issues**
   When you see errors like:
   ```
   Error creating controller. Please check Docker is running and visit 
   'https://docs.all-hands.dev/modules/usage/troubleshooting' for more debugging information.
   ```

   Troubleshooting steps:
   ```bash
   # 1. Check Docker status
   docker ps
   
   # 2. Verify Docker permissions
   groups | grep docker
   
   # 3. Check Docker socket permissions
   ls -l /var/run/docker.sock
   
   # 4. Restart Docker service if needed
   sudo systemctl restart docker
   ```

2. **Resource Constraints**
   When containers fail to start or perform poorly:
   ```bash
   # Check Docker resource usage
   docker stats
   
   # View container logs
   docker logs <container-id>
   ```

### LLM Integration Issues

Common LLM-related problems and their solutions:

1. **API Connection Issues**
   ```python
   # Proper error handling for LLM calls
   try:
       response = await llm.generate(prompt)
   except ConnectionError:
       logger.error("LLM API connection failed")
       # Implement exponential backoff retry
       response = await retry_with_backoff(llm.generate, prompt)
   except RateLimitError:
       logger.warning("Rate limit reached")
       # Wait and retry
       await asyncio.sleep(60)
       response = await llm.generate(prompt)
   ```

2. **Token Limits**
   Implementation of token management:
   ```python
   def check_token_limits(prompt: str, max_tokens: int) -> bool:
       """Check if prompt exceeds token limits.
       
       Args:
           prompt: The input prompt
           max_tokens: Maximum allowed tokens
           
       Returns:
           bool: True if within limits, False otherwise
       """
       estimated_tokens = len(prompt.split()) * 1.3  # Rough estimate
       return estimated_tokens <= max_tokens
   ```

## Debugging Techniques

### Logging System

OpenHands uses a comprehensive logging system. Here's how to implement and use it effectively:

```python
import logging
from pathlib import Path

def setup_logging(log_dir: Path):
    """Configure logging for OpenHands.
    
    Args:
        log_dir: Directory for log files
    """
    log_dir.mkdir(parents=True, exist_ok=True)
    
    # Configure root logger
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_dir / 'openhands.log'),
            logging.StreamHandler()
        ]
    )
    
    # Configure component-specific loggers
    runtime_logger = logging.getLogger('openhands.runtime')
    runtime_logger.setLevel(logging.DEBUG)
    
    # Add special handler for LLM debugging
    llm_logger = logging.getLogger('openhands.llm')
    llm_logger.addHandler(
        logging.FileHandler(log_dir / 'llm_debug.log')
    )
```

### Debug Mode

Implementing and using debug mode:

```python
class DebugConfig:
    """Configuration for debug mode."""
    
    def __init__(self):
        self.debug = os.getenv('DEBUG', '0') == '1'
        self.trace_calls = os.getenv('TRACE_CALLS', '0') == '1'
        self.log_level = logging.DEBUG if self.debug else logging.INFO

def enable_debug_mode():
    """Enable debug mode with additional logging and checks."""
    if DebugConfig().debug:
        # Enable detailed logging
        logging.getLogger().setLevel(logging.DEBUG)
        
        # Log all LLM interactions
        os.environ['LLM_DEBUG'] = '1'
        
        # Enable runtime debugging
        os.environ['SANDBOX_DEBUG'] = '1'
```

## Performance Profiling

### Code Profiling

1. **CPU Profiling**
   Using cProfile for performance analysis:

```python
import cProfile
import pstats
from functools import wraps

def profile_func(func):
    """Decorator to profile a function."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        profile = cProfile.Profile()
        try:
            return profile.runcall(func, *args, **kwargs)
        finally:
            stats = pstats.Stats(profile)
            stats.sort_stats('cumulative')
            stats.print_stats()
    return wrapper

@profile_func
def expensive_operation():
    # Your code here
    pass
```

2. **Memory Profiling**
   Using memory_profiler to track memory usage:

```python
from memory_profiler import profile as memory_profile

@memory_profile
def memory_intensive_task():
    """Monitor memory usage of this function."""
    large_list = []
    for i in range(1000000):
        large_list.append(i)
    return large_list
```

### System Monitoring

Implementation of system resource monitoring:

```python
import psutil
import time
from dataclasses import dataclass

@dataclass
class SystemMetrics:
    cpu_percent: float
    memory_percent: float
    disk_usage: float
    network_io: dict

class SystemMonitor:
    """Monitor system resources."""
    
    def __init__(self, interval: int = 60):
        self.interval = interval
        self.metrics_history = []
    
    def collect_metrics(self) -> SystemMetrics:
        """Collect current system metrics."""
        return SystemMetrics(
            cpu_percent=psutil.cpu_percent(interval=1),
            memory_percent=psutil.virtual_memory().percent,
            disk_usage=psutil.disk_usage('/').percent,
            network_io=psutil.net_io_counters()._asdict()
        )
    
    def start_monitoring(self):
        """Start continuous monitoring."""
        while True:
            metrics = self.collect_metrics()
            self.metrics_history.append(metrics)
            self.check_thresholds(metrics)
            time.sleep(self.interval)
    
    def check_thresholds(self, metrics: SystemMetrics):
        """Check if metrics exceed thresholds."""
        if metrics.cpu_percent > 80:
            logging.warning("High CPU usage detected")
        if metrics.memory_percent > 90:
            logging.warning("High memory usage detected")
```

## Security Auditing

### Security Scanning

Implementation of security scanning tools:

```python
from typing import List
import subprocess
import json

class SecurityScanner:
    """Perform security scans on the codebase."""
    
    def __init__(self, repo_path: str):
        self.repo_path = repo_path
    
    def run_bandit_scan(self) -> List[dict]:
        """Run Bandit security scanner."""
        cmd = [
            'bandit',
            '-r',
            self.repo_path,
            '-f', 'json'
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        return json.loads(result.stdout)
    
    def check_dependencies(self) -> List[dict]:
        """Check for known vulnerabilities in dependencies."""
        cmd = [
            'safety',
            'check',
            '--full-report',
            '--json'
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        return json.loads(result.stdout)
```

### Audit Logging

Implementation of audit logging:

```python
import json
from datetime import datetime
from typing import Any, Dict

class AuditLogger:
    """Log security-relevant events."""
    
    def __init__(self, log_file: str):
        self.log_file = log_file
    
    def log_event(self, 
                  event_type: str,
                  user: str,
                  action: str,
                  details: Dict[str, Any]):
        """Log a security event.
        
        Args:
            event_type: Type of security event
            user: User who triggered the event
            action: Action performed
            details: Additional event details
        """
        event = {
            'timestamp': datetime.utcnow().isoformat(),
            'event_type': event_type,
            'user': user,
            'action': action,
            'details': details
        }
        
        with open(self.log_file, 'a') as f:
            json.dump(event, f)
            f.write('\n')
```

## System Maintenance

### Update Procedures

1. **Version Management**
   Implementation of version checking and updates:

```python
import semver
import requests
from typing import Optional

class UpdateManager:
    """Manage system updates."""
    
    def __init__(self, current_version: str):
        self.current_version = semver.VersionInfo.parse(current_version)
        self.latest_version = None
    
    async def check_for_updates(self) -> Optional[str]:
        """Check for available updates.
        
        Returns:
            Optional[str]: Latest version if update available
        """
        try:
            response = await self.fetch_latest_version()
            self.latest_version = semver.VersionInfo.parse(response['version'])
            
            if self.latest_version > self.current_version:
                return str(self.latest_version)
            return None
        except Exception as e:
            logging.error(f"Failed to check for updates: {e}")
            return None
    
    async def perform_update(self) -> bool:
        """Perform system update."""
        try:
            # Backup current state
            await self.backup_system()
            
            # Download updates
            await self.download_updates()
            
            # Apply updates
            await self.apply_updates()
            
            return True
        except Exception as e:
            logging.error(f"Update failed: {e}")
            await self.restore_backup()
            return False
```

2. **Database Maintenance**
   Implementation of database maintenance procedures:

```python
class DatabaseMaintenance:
    """Maintain database health."""
    
    def __init__(self, db_url: str):
        self.db_url = db_url
    
    async def optimize_database(self):
        """Perform database optimization."""
        # Implementation depends on database type
        pass
    
    async def backup_database(self, backup_path: str):
        """Create database backup."""
        # Implementation depends on database type
        pass
    
    async def verify_integrity(self) -> bool:
        """Verify database integrity."""
        # Implementation depends on database type
        return True
```

### Disaster Recovery

Implementation of disaster recovery procedures:

```python
from pathlib import Path
import shutil
import tarfile

class DisasterRecovery:
    """Handle system recovery procedures."""
    
    def __init__(self, backup_dir: Path):
        self.backup_dir = backup_dir
        self.backup_dir.mkdir(parents=True, exist_ok=True)
    
    def create_backup(self) -> Path:
        """Create system backup.
        
        Returns:
            Path: Path to backup file
        """
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_file = self.backup_dir / f"backup_{timestamp}.tar.gz"
        
        with tarfile.open(backup_file, "w:gz") as tar:
            tar.add("config/", arcname="config")
            tar.add("data/", arcname="data")
        
        return backup_file
    
    def restore_backup(self, backup_file: Path) -> bool:
        """Restore system from backup.
        
        Args:
            backup_file: Path to backup file
            
        Returns:
            bool: True if successful
        """
        try:
            # Create temporary restoration directory
            temp_dir = Path("/tmp/restore")
            temp_dir.mkdir(exist_ok=True)
            
            # Extract backup
            with tarfile.open(backup_file, "r:gz") as tar:
                tar.extractall(temp_dir)
            
            # Verify backup integrity
            if not self.verify_backup(temp_dir):
                raise ValueError("Backup verification failed")
            
            # Perform restoration
            shutil.rmtree("config/")
            shutil.rmtree("data/")
            shutil.move(temp_dir / "config", ".")
            shutil.move(temp_dir / "data", ".")
            
            return True
        except Exception as e:
            logging.error(f"Restoration failed: {e}")
            return False
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)
```

## Practical Exercises

1. **Debugging Exercise**
   Debug a failing OpenHands deployment using the techniques learned.

2. **Performance Optimization**
   Profile and optimize a slow-performing OpenHands instance.

3. **Security Audit**
   Perform a security audit on an OpenHands deployment.

4. **Disaster Recovery**
   Practice backup and restore procedures.

## Conclusion

Effective troubleshooting and maintenance are crucial for keeping OpenHands running smoothly and securely. The techniques and tools covered in this lesson provide a comprehensive framework for maintaining and optimizing OpenHands deployments.

## Additional Resources

- [Docker Troubleshooting Guide](https://docs.docker.com/engine/troubleshoot/)
- [Python Debugging Tools](https://docs.python.org/3/library/debug.html)
- [Security Best Practices](https://owasp.org/www-project-top-ten/)
- [System Maintenance Checklist](https://www.digitalocean.com/community/tutorials/recommended-security-measures-to-protect-your-servers)
