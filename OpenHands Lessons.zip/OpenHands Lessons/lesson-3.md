# Lesson 3: LLM Integration and Configuration

## Lesson Overview
This technical lesson focuses on integrating and configuring Large Language Models (LLMs) within OpenHands. Students will learn about different LLM providers, model selection criteria, API configuration, and performance optimization. The lesson emphasizes practical implementation while covering security considerations and cost management.

## Duration: 3 hours

## Learning Objectives
By the end of this lesson, students will be able to:
1. Configure different LLM providers in OpenHands
2. Select appropriate models based on performance requirements
3. Implement secure API key management
4. Optimize model performance and costs
5. Troubleshoot common LLM integration issues

## Detailed Content

### 1. Understanding LLM Providers and Models

OpenHands supports multiple LLM providers through the LiteLLM library. Based on recent evaluations, different models show varying performance levels for coding tasks. Let's explore the key providers and their characteristics:

#### Supported Providers and Performance Metrics

**Top Performing Models (Based on SWE-bench evaluation):**

1. Claude 3.5 Sonnet (Anthropic)
   - 27% resolve rate with default agent
   - Excellent understanding of context
   - Strong performance in complex coding tasks
   ```toml
   [llm]
   model = "anthropic/claude-3-5-sonnet-20241022"
   api_key = "your-anthropic-key"
   ```

2. GPT-4 (OpenAI)
   - Strong general performance
   - Reliable code generation
   - Good documentation understanding
   ```toml
   [llm]
   model = "openai/gpt-4"
   api_key = "your-openai-key"
   ```

3. Open Source Models
   - Llama 3.1 405B
   - DeepSeek v2.5
   ```toml
   [llm]
   model = "ollama/llama2-70b"
   base_url = "http://localhost:11434"
   ```

### 2. Provider-Specific Configuration

Each provider requires specific configuration settings. Let's explore the setup for major providers:

#### Anthropic Configuration
```yaml
services:
  openhands:
    environment:
      - LLM_MODEL=anthropic/claude-3-5-sonnet-20241022
      - LLM_API_KEY=your-anthropic-key
      - LLM_MAX_TOKENS=4096
      - LLM_TEMPERATURE=0.0
```

#### Azure OpenAI Configuration
```yaml
services:
  openhands:
    environment:
      - LLM_MODEL=azure/your-deployment-name
      - LLM_API_KEY=your-azure-key
      - LLM_API_VERSION=2024-02-15-preview
      - LLM_BASE_URL=https://your-endpoint.openai.azure.com
```

#### Google Vertex AI Configuration
```yaml
services:
  openhands:
    environment:
      - GOOGLE_APPLICATION_CREDENTIALS=path-to-credentials.json
      - LLM_MODEL=vertex_ai/gemini-1.0-pro
      - VERTEXAI_PROJECT=your-project-id
      - VERTEXAI_LOCATION=your-location
```

### 3. API Key Management and Security

Implementing secure API key management is crucial. Here's a comprehensive approach:

#### Environment-based Key Management
Create a secure `.env` file:
```bash
# Create encrypted environment file
touch .env
chmod 600 .env

# Add API keys
cat << EOF > .env
LLM_API_KEY=your-api-key
AZURE_API_KEY=your-azure-key
ANTHROPIC_API_KEY=your-anthropic-key
EOF
```

#### Docker Secrets Management
For production deployments:
```yaml
version: '3.8'
services:
  openhands:
    secrets:
      - llm_api_key
    environment:
      - LLM_API_KEY_FILE=/run/secrets/llm_api_key

secrets:
  llm_api_key:
    file: ./secrets/llm_api_key.txt
```

### 4. Model Performance Configuration

Fine-tuning model parameters for optimal performance:

#### Basic Configuration Template
```toml
[llm]
# Model selection
model = "anthropic/claude-3-5-sonnet-20241022"
api_key = "${LLM_API_KEY}"

# Performance parameters
temperature = 0.0
max_input_tokens = 4000
max_output_tokens = 1000

# Retry configuration
num_retries = 8
retry_min_wait = 15
retry_max_wait = 120
retry_multiplier = 2.0

# Cost optimization
drop_params = false
disable_vision = true  # Disable when not needed
```

#### Advanced Performance Settings
```toml
[llm]
# Caching configuration
caching_prompt = true
file_store = "local"
file_store_path = "/path/to/cache"

# Embedding configuration
embedding_model = "local"
embedding_base_url = "http://localhost:8080"

# Rate limiting
max_requests_per_minute = 60
max_tokens_per_minute = 90000
```

### 5. Cost Management and Optimization

Implementing cost controls and optimization strategies:

#### Budget Controls
```toml
[core]
# Set maximum budget per task
max_budget_per_task = 5.0  # USD

[llm]
# Cost per token settings
input_cost_per_token = 0.00001
output_cost_per_token = 0.00003
```

#### Usage Monitoring Script
```python
import os
from typing import Dict
from datetime import datetime, timedelta

class LLMUsageMonitor:
    def __init__(self):
        self.usage: Dict[str, int] = {}
        self.costs: Dict[str, float] = {}
        
    def track_request(self, model: str, input_tokens: int, output_tokens: int):
        if model not in self.usage:
            self.usage[model] = {'input': 0, 'output': 0}
            self.costs[model] = 0.0
            
        self.usage[model]['input'] += input_tokens
        self.usage[model]['output'] += output_tokens
        
        # Calculate costs based on model pricing
        cost = self.calculate_cost(model, input_tokens, output_tokens)
        self.costs[model] += cost
        
    def generate_report(self):
        print("=== LLM Usage Report ===")
        for model, usage in self.usage.items():
            print(f"\nModel: {model}")
            print(f"Input tokens: {usage['input']}")
            print(f"Output tokens: {usage['output']}")
            print(f"Total cost: ${self.costs[model]:.2f}")
```

### 6. Error Handling and Retries

Implementing robust error handling for LLM operations:

#### Retry Configuration
```python
from tenacity import retry, stop_after_attempt, wait_exponential

@retry(
    stop=stop_after_attempt(8),
    wait=wait_exponential(multiplier=15, min=15, max=120)
)
async def make_llm_request(prompt: str) -> str:
    try:
        response = await llm_client.complete(
            model=settings.llm_model,
            prompt=prompt,
            max_tokens=settings.max_output_tokens
        )
        return response.text
    except Exception as e:
        logger.error(f"LLM request failed: {str(e)}")
        raise
```

### 7. Validation and Testing

Creating a validation suite for LLM integration:

#### Model Validation Script
```python
async def validate_llm_setup():
    """Validates LLM configuration and connectivity."""
    
    # Test basic completion
    try:
        response = await llm_client.complete(
            model=settings.llm_model,
            prompt="Return the string 'OK' if you receive this message.",
            max_tokens=5
        )
        assert "OK" in response.text
        print("✅ Basic completion test passed")
    except Exception as e:
        print(f"❌ Basic completion test failed: {str(e)}")
        
    # Test token limits
    try:
        long_prompt = "test " * 1000
        response = await llm_client.complete(
            model=settings.llm_model,
            prompt=long_prompt,
            max_tokens=settings.max_output_tokens
        )
        print("✅ Token limit test passed")
    except Exception as e:
        print(f"❌ Token limit test failed: {str(e)}")

if __name__ == "__main__":
    asyncio.run(validate_llm_setup())
```

## Practical Exercise

Students will:
1. Set up and configure multiple LLM providers
2. Implement secure API key management
3. Create a cost monitoring system
4. Test different model parameters
5. Implement error handling and retry logic

## Additional Resources

1. LiteLLM Documentation: [docs.litellm.ai](https://docs.litellm.ai)
2. OpenHands LLM Guide: [docs.all-hands.dev/modules/usage/llms](https://docs.all-hands.dev/modules/usage/llms)
3. Provider-specific documentation:
   - [Anthropic API](https://docs.anthropic.com/claude/docs)
   - [Azure OpenAI](https://learn.microsoft.com/en-us/azure/ai-services/openai)
   - [Google Vertex AI](https://cloud.google.com/vertex-ai/docs)

## Next Steps

In the next lesson, we'll explore advanced LLM operations, including prompt engineering and model-specific optimizations.

## Assignment

Create a comprehensive LLM integration project that includes:
1. Configuration for multiple providers
2. Secure API key management system
3. Cost monitoring and reporting system
4. Performance optimization implementation
5. Error handling and retry logic
6. Validation test suite

This assignment will help solidify understanding of LLM integration and prepare for advanced usage in subsequent lessons.
