# Lesson 2: Environment Setup and Installation

## Lesson Overview
This hands-on lesson guides students through the complete process of setting up OpenHands across different operating systems. Students will learn about system requirements, installation methods, configuration management, and troubleshooting techniques. The lesson emphasizes practical implementation while ensuring security and optimization.

## Duration: 3 hours

## Learning Objectives
By the end of this lesson, students will be able to:
1. Set up OpenHands across different operating systems
2. Understand and implement Docker configurations
3. Configure development environments
4. Troubleshoot common installation issues
5. Implement security best practices
6. Validate installation success

## Detailed Content

### 1. System Requirements

#### Base System Requirements
Before beginning the installation process, it's crucial to ensure your system meets the following requirements:

For Production Environment:
```
- Docker version 26.0.0+ or Docker Desktop 4.31.0+
- 4GB RAM minimum (8GB recommended)
- 20GB available disk space
- Internet connection for pulling Docker images and LLM API access
```

For Development Environment:
```
- Python 3.12
- NodeJS >= 18.17.1
- Poetry >= 1.8
- Git for version control
- Modern web browser (Chrome, Firefox, or Safari)
```

Operating System-Specific Requirements:

**Linux (Ubuntu/Debian)**
```bash
# Essential build tools
sudo apt-get update
sudo apt-get install build-essential
sudo apt-get install netcat

# Docker installation
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
```

**macOS**
```bash
# Homebrew installation (if not installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install required packages
brew install python@3.12
brew install node@18
brew install poetry
```

**Windows (WSL)**
```bash
# Install WSL
wsl --install

# Update package manager
sudo apt update && sudo apt upgrade

# Install dependencies
sudo apt install build-essential python3.12 python3-pip
```

### 2. Docker Setup and Configuration

Docker plays a crucial role in OpenHands by providing isolated environments for code execution. Here's a detailed setup process:

#### Docker Installation Verification
```bash
# Check Docker version
docker --version

# Verify Docker daemon is running
docker info

# Test Docker functionality
docker run hello-world
```

#### Docker Configuration for OpenHands
Create a dedicated directory for OpenHands and set up the Docker environment:

```bash
# Create project directory
mkdir openhands-project
cd openhands-project

# Create docker-compose configuration
touch compose.yml
```

Example `compose.yml` configuration:
```yaml
services:
  openhands:
    image: docker.all-hands.dev/all-hands-ai/openhands:0.13
    container_name: openhands-app
    environment:
      - SANDBOX_RUNTIME_CONTAINER_IMAGE=docker.all-hands.dev/all-hands-ai/runtime:0.13-nikolaik
      - SANDBOX_USER_ID=1000
      - WORKSPACE_MOUNT_PATH=/opt/workspace_base
    ports:
      - "3000:3000"
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
      - ./workspace:/opt/workspace_base
```

### 3. Installation Methods

OpenHands offers several installation methods, each suited for different use cases:

#### Method 1: Docker Production Setup
The quickest way to get started with OpenHands:

```bash
# Pull the runtime image
docker pull docker.all-hands.dev/all-hands-ai/runtime:0.13-nikolaik

# Run OpenHands
docker run -it --pull=always \
    -e SANDBOX_RUNTIME_CONTAINER_IMAGE=docker.all-hands.dev/all-hands-ai/runtime:0.13-nikolaik \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -p 3000:3000 \
    --add-host host.docker.internal:host-gateway \
    --name openhands-app \
    docker.all-hands.dev/all-hands-ai/openhands:0.13
```

#### Method 2: Development Environment Setup
For contributors and developers who want to modify the source code:

```bash
# Clone the repository
git clone https://github.com/All-Hands-AI/OpenHands.git
cd OpenHands

# Install dependencies
make build

# Configure the environment
make setup-config

# Start the development server
make run
```

#### Method 3: Headless Mode Installation
For automated environments and CI/CD pipelines:

```bash
# Install OpenHands package
pip install openhands-ai

# Run in headless mode
python -m openhands.core.main -t "your-task"
```

### 4. Configuration Management

OpenHands uses a TOML-based configuration system. Understanding and managing these configurations is crucial for optimal operation.

#### Basic Configuration Structure
Create a `config.toml` file in your project root:

```toml
[core]
workspace_base = "./workspace"
debug = false
max_iterations = 100

[llm]
api_key = "your-api-key"
model = "anthropic/claude-3-5-sonnet-20241022"
embedding_model = "local"

[agent]
memory_enabled = true
memory_max_threads = 3

[sandbox]
timeout = 120
user_id = 1000
base_container_image = "nikolaik/python-nodejs:python3.12-nodejs22"
```

#### Environment Variables
Critical configurations can also be set via environment variables:
```bash
export LLM_API_KEY="your-api-key"
export LLM_MODEL="anthropic/claude-3-5-sonnet-20241022"
export SANDBOX_USER_ID="1000"
```

### 5. Security Implementation

Security is paramount when setting up OpenHands. Here are key security measures to implement:

#### File System Security
```bash
# Set appropriate permissions for workspace
chmod 700 ./workspace

# Create secure storage for API keys
mkdir -p ~/.openhands/secrets
chmod 700 ~/.openhands/secrets
```

#### Docker Security Configuration
```bash
# Create dedicated user for OpenHands
sudo groupadd docker-openhands
sudo usermod -aG docker-openhands $USER

# Configure Docker daemon security
sudo tee /etc/docker/daemon.json <<EOF
{
  "userns-remap": "default",
  "no-new-privileges": true,
  "seccomp-profile": "/etc/docker/seccomp-profile.json"
}
EOF
```

### 6. Environment Validation

After installation, it's crucial to validate the setup:

#### Basic Validation Script
```python
#!/usr/bin/env python3
import subprocess
import sys

def check_docker():
    try:
        subprocess.run(['docker', 'info'], check=True)
        print("✅ Docker is running correctly")
    except subprocess.CalledProcessError:
        print("❌ Docker is not running or not accessible")
        sys.exit(1)

def check_network():
    try:
        subprocess.run(['curl', 'localhost:3000'], check=True)
        print("✅ OpenHands server is accessible")
    except subprocess.CalledProcessError:
        print("❌ OpenHands server is not responding")
        sys.exit(1)

if __name__ == "__main__":
    check_docker()
    check_network()
```

### 7. Troubleshooting Guide

Common issues and their solutions:

#### Docker Connection Issues
```bash
# Reset Docker daemon
sudo systemctl restart docker

# Check Docker socket permissions
sudo chmod 666 /var/run/docker.sock
```

#### Network Configuration Problems
```bash
# Check port availability
sudo lsof -i :3000

# Test network connectivity
nc -zv localhost 3000
```

#### Workspace Mount Issues
```bash
# Reset workspace permissions
sudo chown -R $USER:$USER ./workspace
sudo chmod -R 755 ./workspace
```

## Practical Exercise

Students will:
1. Set up OpenHands using all three installation methods
2. Configure the environment for their specific use case
3. Implement security measures
4. Validate the installation
5. Practice troubleshooting common issues

## Additional Resources

1. Docker Documentation: [docs.docker.com](https://docs.docker.com)
2. OpenHands Installation Guide: [docs.all-hands.dev/modules/usage/installation](https://docs.all-hands.dev/modules/usage/installation)
3. WSL Documentation: [learn.microsoft.com/en-us/windows/wsl](https://learn.microsoft.com/en-us/windows/wsl)

## Next Steps

In the next lesson, we'll explore LLM integration and configuration, building upon this solid foundation of environment setup.

## Assignment

Create a comprehensive installation guide for your specific operating system, including:
1. Step-by-step installation process
2. Custom configuration requirements
3. Security measures implemented
4. Validation procedures
5. Troubleshooting steps for common issues

This assignment will help reinforce the installation process and create valuable documentation for future reference.
