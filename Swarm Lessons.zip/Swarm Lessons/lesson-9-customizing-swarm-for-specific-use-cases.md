# Lesson 9: Customizing Swarm for Specific Use Cases

## Learning Objectives
By the end of this lesson, you will be able to:
1. Tailor agents for different domains and specific use cases
2. Implement domain-specific tools to enhance agent capabilities
3. Optimize prompts for better performance in specific scenarios
4. Analyze case studies of custom Swarm implementations
5. Apply techniques for fine-tuning language models for specialized tasks

## 1. Tailoring Agents for Different Domains

When customizing Swarm for specific use cases, it's crucial to tailor agents to the domain they'll be operating in. This involves crafting specific instructions, defining relevant functions, and structuring the agent network appropriately.

### Example: E-commerce Customer Support System

Let's create a set of agents tailored for an e-commerce platform:

```python
from swarm import Agent, Result

def update_order_status(order_id: str, status: str):
    # Simulated function to update order status
    print(f"Updating order {order_id} to status: {status}")
    return f"Order {order_id} updated to {status}"

def check_inventory(product_id: str):
    # Simulated function to check inventory
    inventory = {"P001": 10, "P002": 5, "P003": 0}
    return f"Product {product_id} has {inventory.get(product_id, 0)} units in stock"

def process_return(order_id: str, reason: str):
    # Simulated function to process a return
    print(f"Processing return for order {order_id}. Reason: {reason}")
    return f"Return processed for order {order_id}"

order_status_agent = Agent(
    name="Order Status Agent",
    instructions="""
    You are an Order Status Agent for an e-commerce platform.
    Your role is to provide customers with updates on their orders and assist with order-related queries.
    Use the update_order_status function to modify order statuses when necessary.
    If a query is not related to order status, transfer to the appropriate agent.
    """,
    functions=[update_order_status, transfer_to_agent]
)

inventory_agent = Agent(
    name="Inventory Agent",
    instructions="""
    You are an Inventory Agent for an e-commerce platform.
    Your role is to check product availability and answer inventory-related questions.
    Use the check_inventory function to verify stock levels.
    If a query is not related to inventory, transfer to the appropriate agent.
    """,
    functions=[check_inventory, transfer_to_agent]
)

returns_agent = Agent(
    name="Returns Agent",
    instructions="""
    You are a Returns Agent for an e-commerce platform.
    Your role is to assist customers with product returns and refunds.
    Use the process_return function to initiate return procedures.
    If a query is not related to returns or refunds, transfer to the appropriate agent.
    """,
    functions=[process_return, transfer_to_agent]
)
```

This example demonstrates how agents can be tailored to specific roles within an e-commerce customer support system, each with its own set of instructions and relevant functions.

## 2. Implementing Domain-Specific Tools

Domain-specific tools enhance the capabilities of agents, allowing them to perform specialized tasks relevant to their domain. These tools are implemented as functions that agents can call.

### Example: Financial Advisory System

Let's implement some domain-specific tools for a financial advisory system:

```python
import yfinance as yf
from typing import List

def get_stock_price(ticker: str) -> float:
    stock = yf.Ticker(ticker)
    return stock.info['regularMarketPrice']

def calculate_portfolio_value(holdings: List[dict]) -> float:
    total_value = 0
    for holding in holdings:
        price = get_stock_price(holding['ticker'])
        value = price * holding['shares']
        total_value += value
    return total_value

def recommend_portfolio_allocation(risk_tolerance: str, investment_horizon: int) -> dict:
    allocations = {
        "low": {"stocks": 0.3, "bonds": 0.6, "cash": 0.1},
        "medium": {"stocks": 0.6, "bonds": 0.3, "cash": 0.1},
        "high": {"stocks": 0.8, "bonds": 0.15, "cash": 0.05}
    }
    base_allocation = allocations[risk_tolerance]
    
    # Adjust based on investment horizon
    if investment_horizon > 10:
        base_allocation["stocks"] += 0.1
        base_allocation["bonds"] -= 0.1
    elif investment_horizon < 5:
        base_allocation["stocks"] -= 0.1
        base_allocation["bonds"] += 0.1
    
    return base_allocation

financial_advisor_agent = Agent(
    name="Financial Advisor Agent",
    instructions="""
    You are a Financial Advisor Agent.
    Your role is to provide financial advice, check stock prices, calculate portfolio values,
    and recommend portfolio allocations based on client risk tolerance and investment horizon.
    Use the provided functions to assist with these tasks.
    Always explain your recommendations and calculations to the client.
    """,
    functions=[get_stock_price, calculate_portfolio_value, recommend_portfolio_allocation]
)
```

These domain-specific tools allow the Financial Advisor Agent to perform tasks such as checking stock prices, calculating portfolio values, and recommending portfolio allocations based on client preferences.

## 3. Optimizing Prompts for Better Performance

Prompt optimization is crucial for improving the performance of agents in specific scenarios. Well-crafted prompts can guide the model to provide more accurate and relevant responses.

### Techniques for Prompt Optimization:

1. **Be Specific**: Clearly define the agent's role and the expected output format.
2. **Provide Context**: Include relevant background information in the prompt.
3. **Use Examples**: Incorporate few-shot learning by providing examples of desired interactions.
4. **Structured Output**: Specify the desired structure for the agent's responses.

### Example: Optimized Prompt for a Customer Service Agent

```python
customer_service_agent = Agent(
    name="Customer Service Agent",
    instructions="""
    You are a Customer Service Agent for TechGadgets, an online electronics retailer.
    Your role is to assist customers with inquiries, resolve issues, and ensure customer satisfaction.

    Guidelines:
    1. Always greet the customer and ask for their name if not provided.
    2. Be empathetic and professional in your responses.
    3. If you need more information, ask clear, concise questions.
    4. Provide step-by-step solutions when addressing technical issues.
    5. If you can't resolve an issue, escalate to a human supervisor.

    Example Interaction:
    Customer: My new laptop isn't turning on.
    Agent: I'm sorry to hear that you're having trouble with your new laptop. Let's try to resolve this together. Could you please tell me the model of your laptop?
    Customer: It's a TechBook Pro 2000.
    Agent: Thank you for providing that information. Let's go through some troubleshooting steps for your TechBook Pro 2000:
    1. Ensure the laptop is plugged into a working power outlet.
    2. Press and hold the power button for 10 seconds, then release.
    3. Press the power button again to turn on the laptop.
    If these steps don't work, we may need to check the battery or power adapter. Would you like me to guide you through those checks?

    Remember: Your goal is to resolve issues efficiently while maintaining a positive customer experience.
    """,
    functions=[escalate_to_human, check_order_status, initiate_return]
)
```

This optimized prompt provides clear instructions, guidelines, and an example interaction, helping the agent understand its role and how to respond effectively in various scenarios.

## 4. Case Studies of Custom Swarm Implementations

Let's examine a case study of a custom Swarm implementation for a specific use case.

### Case Study: Automated Medical Triage System

**Objective**: Develop a Swarm-based system to perform initial medical triage for patients, directing them to appropriate care based on their symptoms.

**Implementation**:

```python
from swarm import Swarm, Agent, Result

def check_vital_signs(temperature: float, heart_rate: int, blood_pressure: str):
    # Simulated function to analyze vital signs
    if temperature > 38.0 or heart_rate > 100 or int(blood_pressure.split('/')[0]) > 140:
        return "Abnormal vital signs detected"
    return "Vital signs within normal range"

def assess_pain_level(pain_score: int):
    if pain_score >= 7:
        return "Severe pain reported"
    elif pain_score >= 4:
        return "Moderate pain reported"
    else:
        return "Mild or no pain reported"

def recommend_care_level(symptoms: list, vitals_status: str, pain_level: str):
    if "difficulty breathing" in symptoms or "chest pain" in symptoms:
        return "Emergency Care Recommended"
    elif vitals_status == "Abnormal vital signs detected" or pain_level == "Severe pain reported":
        return "Urgent Care Recommended"
    else:
        return "Primary Care Recommended"

triage_nurse_agent = Agent(
    name="Triage Nurse Agent",
    instructions="""
    You are a Triage Nurse Agent in an automated medical triage system.
    Your role is to gather initial information from patients, assess their symptoms,
    and recommend an appropriate level of care.

    Follow these steps:
    1. Greet the patient and ask for their main complaint.
    2. Inquire about specific symptoms related to their complaint.
    3. Ask for and record their vital signs (temperature, heart rate, blood pressure).
    4. Assess their pain level on a scale of 0-10.
    5. Use the provided functions to analyze the information and recommend care.
    6. Clearly communicate the recommended care level to the patient.
    7. Provide any necessary immediate advice or precautions.

    Always prioritize patient safety. If you're unsure about a situation, recommend a higher level of care.
    """,
    functions=[check_vital_signs, assess_pain_level, recommend_care_level]
)

def run_triage(client: Swarm, user_input: str):
    messages = [{"role": "user", "content": user_input}]
    response = client.run(agent=triage_nurse_agent, messages=messages)
    return response.messages[-1]['content']

# Example usage
client = Swarm()
patient_complaint = "I've been having severe chest pain for the last hour"
triage_result = run_triage(client, patient_complaint)
print(triage_result)
```

This case study demonstrates how Swarm can be customized for a specialized medical triage system, using domain-specific knowledge and functions to assess patient conditions and recommend appropriate care levels.

## 5. Techniques for Fine-tuning Language Models

While Swarm typically uses pre-trained models, fine-tuning can further enhance performance for specific tasks. Here are some techniques for fine-tuning language models:

1. **Data Preparation**: Collect high-quality, domain-specific data for fine-tuning.
2. **Task-Specific Fine-tuning**: Focus on the specific task your agent will perform.
3. **Few-Shot Learning**: Use examples in your prompts to guide the model's behavior.
4. **Iterative Refinement**: Continuously evaluate and refine your fine-tuned model.

### Example: Fine-tuning for Medical Terminology

```python
import openai

def prepare_medical_data():
    # Simulated function to prepare medical data for fine-tuning
    return [
        {"prompt": "Patient presents with dyspnea", "completion": "The patient is experiencing difficulty breathing."},
        {"prompt": "Patient reports pyrexia", "completion": "The patient has an elevated body temperature or fever."},
        # Add more medical term translations...
    ]

def fine_tune_model(data):
    # Note: This is a simplified example. In practice, you would use OpenAI's fine-tuning API.
    openai.File.create(file=data, purpose='fine-tune')
    openai.FineTune.create(training_file=data, model="davinci")

medical_data = prepare_medical_data()
fine_tune_model(medical_data)

# After fine-tuning, update your agent to use the fine-tuned model
medical_terminology_agent = Agent(
    name="Medical Terminology Agent",
    model="ft:davinci-002:medical-terms:1",  # Use your actual fine-tuned model name
    instructions="You are an expert in medical terminology. Translate medical terms into layman's terms.",
    functions=[]
)
```

This example demonstrates the process of fine-tuning a model for medical terminology translation, which can be particularly useful in a medical triage or patient communication system.

## Hands-on Exercise: Customizing Swarm for a Travel Planning Assistant

Let's create a Swarm-based Travel Planning Assistant that helps users plan their trips by recommending destinations, finding flights, and suggesting accommodations.

1. Set up the project structure:

```
travel_planner/
├── main.py
├── agents.py
├── tools.py
└── requirements.txt
```

2. Install the required packages:

```bash
pip install openai python-dotenv requests
```

3. In `tools.py`, implement domain-specific tools:

```python
import requests
from typing import List, Dict

def search_destinations(interests: List[str], budget: int, season: str) -> List[str]:
    # Simulated API call to a travel database
    destinations = [
        "Paris, France",
        "Bali, Indonesia",
        "New York City, USA",
        "Tokyo, Japan",
        "Cape Town, South Africa"
    ]
    return destinations[:3]  # Return top 3 destinations

def find_flights(origin: str, destination: str, date: str) -> Dict[str, str]:
    # Simulated flight search
    return {
        "airline": "Global Airways",
        "departure": "10:00 AM",
        "arrival": "2:00 PM",
        "price": "$500"
    }

def suggest_accommodations(destination: str, check_in: str, check_out: str, budget: int) -> List[Dict[str, str]]:
    # Simulated accommodation search
    return [
        {"name": "City Center Hotel", "price": "$100/night", "rating": "4.5 stars"},
        {"name": "Beachfront Resort", "price": "$150/night", "rating": "4.8 stars"}
    ]

def get_weather_forecast(destination: str, date: str) -> str:
    # Simulated weather forecast
    return "Sunny with a high of 25°C (77°F)"
```

4. In `agents.py`, define the travel planning agents:

```python
from swarm import Agent
from tools import search_destinations, find_flights, suggest_accommodations, get_weather_forecast

def transfer_to_agent(agent_name: str):
    return f"Transferring to {agent_name}"

destination_agent = Agent(
    name="Destination Recommendation Agent",
    instructions="""
    You are a Destination Recommendation Agent for a travel planning service.
    Your role is to suggest suitable destinations based on the traveler's interests, budget, and preferred travel season.
    Use the search_destinations function to find appropriate destinations.
    Once you've suggested destinations, transfer to the Flight Search Agent.
    """,
    functions=[search_destinations, transfer_to_agent]
)

flight_agent = Agent(
    name="Flight Search Agent",
    instructions="""
    You are a Flight Search Agent for a travel planning service.
    Your role is to find suitable flights based on the traveler's chosen destination and dates.
    Use the find_flights function to search for flights.
    After providing flight options, transfer to the Accommodation Agent.
    """,
    functions=[find_flights, transfer_to_agent]
)

accommodation_agent = Agent(
    name="Accommodation Agent",
    instructions="""
    You are an Accommodation Agent for a travel planning service.
    Your role is to suggest suitable accommodations based on the traveler's destination, dates, and budget.
    Use the suggest_accommodations function to find appropriate options.
    After suggesting accommodations, transfer to the Weather Agent.
    """,
    functions=[suggest_accommodations, transfer_to_agent]
)

weather_agent = Agent(
    name="Weather Agent",
    instructions="""
    You are a Weather Agent for a travel planning service.
    Your role is to provide weather forecasts for the traveler's chosen destination and dates.
    Use the get_weather_forecast function to retrieve weather information.
    This is typically the last step in the travel planning process.
    """,
    functions=[get_weather_forecast]
)
```

5. In `main.py`, create the main application:

```python
import os
from dotenv import load_dotenv
from swarm import Swarm
from agents import destination_agent, flight_agent, accommodation_agent, weather_agent

# Load environment variables
load_dotenv()

# Get API key
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise ValueError("OPENAI_API_KEY environment variable not set")

# Initialize Swarm
client = Swarm(api_key=api_key)

def run_travel_planner(user_input):
    messages = [{"role": "user", "content": user_input}]
    current_agent = destination_agent
    
    while True:
        response = client.run(agent=current_agent, messages=messages)
        print(f"{current_agent.name}: {response.messages[-1]['content']}")
        
        if "Transferring to" in response.messages[-1]['content']:
            next_agent = response.messages[-1]['content'].split("Transferring to ")[-1]
            if next_agent == "Flight Search Agent":
                current_agent = flight_agent
            elif next_agent == "Accommodation Agent":
                current_agent = accommodation_agent
            elif next_agent == "Weather Agent":
                current_agent = weather_agent
            else:
                break
        else:
            break
        
        messages.append({"role": "user", "content": "Please continue with the next step of my travel planning."})
    
    print("Travel planning completed!")

# Test the travel planner
user_query = """
I'm interested in a beach vacation with some cultural experiences.
My budget is $2000, and I'd like to travel in the summer.
I'll be departing from New York City.
"""

run_travel_planner(user_query)
```

This exercise demonstrates:
- Creation of domain-specific tools for travel planning
- Implementation of specialized agents for different aspects of travel planning
- A multi-step travel planning process with agent handoffs
- Integration of external data sources (simulated in this case)

To run the application:

1. Set up your OpenAI API key in a `.env` file:
   ```
   OPENAI_API_KEY=your_api_key_here
   ```

2. Run the main script:
   ```
   python main.py
   ```

This will simulate a travel planning session, demonstrating how the customized Swarm system handles the entire process from destination recommendation to weather forecasting.

## Quiz

1. What are the key considerations when tailoring agents for specific domains?
2. How do domain-specific tools enhance the capabilities of Swarm agents?
3. What techniques can be used to optimize prompts for better performance in specific scenarios?
4. In the travel planning case study, how does the system manage the flow between different aspects of travel planning?
5. What are some benefits and challenges of fine-tuning language models for specialized tasks?

## Additional Resources

- [OpenAI Fine-tuning Guide](https://platform.openai.com/docs/guides/fine-tuning)
- [Prompt Engineering Guide](https://www.promptingguide.ai/)
- [Best Practices for Building AI-Powered Travel Apps](https://www.phocuswire.com/Best-practices-for-building-AI-powered-apps-in-travel)
- [Domain-Specific Language Models](https://arxiv.org/abs/2110.08950)

In the next lesson, we'll explore testing and evaluation techniques for Swarm-based systems, building on the customization strategies we've learned here.

