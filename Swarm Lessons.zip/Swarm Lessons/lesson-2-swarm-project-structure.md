# Lesson 2: Understanding the Swarm Project Structure

## Learning Objectives
By the end of this lesson, you will be able to:
1. Navigate and understand the Swarm project directory layout
2. Identify key files in the Swarm project and understand their purposes
3. Use package management tools and understand dependencies in Python projects
4. Create and manage virtual environments for Python projects
5. Read and interpret README files and documentation effectively

## 1. Exploring the Swarm Project Directory Layout

The Swarm project follows a typical Python project structure. Let's examine its layout:

```
swarm/
├── examples/
│   ├── airline/
│   ├── basic/
│   ├── customer_service/
│   ├── personal_shopper/
│   ├── support_bot/
│   ├── triage_agent/
│   └── weather_agent/
├── logs/
├── swarm/
│   ├── repl/
│   │   ├── __init__.py
│   │   └── repl.py
│   ├── __init__.py
│   ├── core.py
│   ├── types.py
│   └── util.py
├── tests/
│   ├── test_runs/
│   ├── __init__.py
│   ├── mock_client.py
│   ├── test_core.py
│   └── test_util.py
├── .pre-commit-config.yaml
├── LICENSE
├── pyproject.toml
├── README.md
├── SECURITY.md
└── setup.cfg
```

### 1.1 Root Directory
The root directory contains configuration files, license information, and the main package directory.

### 1.2 swarm/ Directory
This is the main package directory containing the core Swarm code.

### 1.3 examples/ Directory
Contains various example implementations of Swarm for different use cases.

### 1.4 tests/ Directory
Contains test files for the Swarm project.

### 1.5 logs/ Directory
Used for storing log files generated during Swarm's execution.

## 2. Key Files and Their Purposes

Let's examine some of the key files in the Swarm project:

### 2.1 swarm/core.py
This file contains the main `Swarm` class, which is the core of the Swarm framework. It handles the execution of agents and manages the conversation flow.

Key components:
- `Swarm` class: Manages the overall conversation flow
- `run()` method: Executes the conversation loop
- `get_chat_completion()` method: Interacts with the OpenAI API

### 2.2 swarm/types.py
Defines custom types and classes used throughout the Swarm project.

Key components:
- `Agent` class: Represents an AI agent with specific instructions and tools
- `Response` class: Encapsulates the response from an agent interaction
- `Result` class: Represents the result of a function call

### 2.3 swarm/util.py
Contains utility functions used across the project.

Key functions:
- `function_to_json()`: Converts Python functions to JSON schemas for API calls
- `merge_chunk()`: Merges chunks of streaming responses

### 2.4 swarm/repl/repl.py
Implements a Read-Eval-Print Loop (REPL) for interactive Swarm sessions.

Key components:
- `run_demo_loop()`: Runs an interactive demo of the Swarm framework

### 2.5 setup.cfg
Contains configuration for the project setup, including metadata and dependencies.

### 2.6 pyproject.toml
Specifies the build system requirements for the project.

### 2.7 README.md
Provides an overview of the project, installation instructions, and usage examples.

## 3. Package Management and Dependencies

Python uses packages to organize and distribute code. Swarm, like many Python projects, uses external packages as dependencies.

### 3.1 Understanding dependencies
Dependencies are external packages that a project relies on. In Swarm, these include:

- `openai`: For interacting with OpenAI's API
- `pydantic`: For data validation and settings management

### 3.2 Using pip
Pip is Python's package installer. Basic usage:

```bash
# Install a package
pip install package_name

# Install from requirements file
pip install -r requirements.txt

# List installed packages
pip list
```

### 3.3 requirements.txt
This file lists all the dependencies of a project. For Swarm, it might look like this:

```
numpy
openai==1.33.0
pytest
requests
tqdm
pre-commit
instructor
```

### 3.4 setup.cfg and dependencies
In Swarm's `setup.cfg`, dependencies are specified in the `install_requires` section:

```ini
[options]
install_requires =
    numpy
    openai==1.33.0
    pytest
    requests
    tqdm
    pre-commit
    instructor
```

## 4. Virtual Environments

Virtual environments are isolated Python environments that allow you to manage project-specific dependencies.

### 4.1 Creating a virtual environment
```bash
python -m venv myenv
```

### 4.2 Activating a virtual environment
On Windows:
```bash
myenv\Scripts\activate
```
On macOS and Linux:
```bash
source myenv/bin/activate
```

### 4.3 Deactivating a virtual environment
```bash
deactivate
```

### 4.4 Installing project dependencies in a virtual environment
After activating your virtual environment:
```bash
pip install -r requirements.txt
```

## 5. Reading and Understanding README Files and Documentation

README files and documentation are crucial for understanding a project quickly.

### 5.1 Anatomy of a good README
Swarm's README.md includes:
1. Project title and description
2. Installation instructions
3. Usage examples
4. Overview of key concepts
5. API documentation
6. Contributing guidelines

### 5.2 Navigating documentation
Most Python projects, including Swarm, use docstrings for in-code documentation. For example, in `swarm/core.py`:

```python
class Swarm:
    """
    The main class for managing Swarm interactions.
    
    Attributes:
        client: An instance of the OpenAI client.
    """
    
    def run(self, agent, messages, context_variables=None, ...):
        """
        Execute a conversation with the specified agent.
        
        Args:
            agent (Agent): The agent to use for the conversation.
            messages (list): The conversation history.
            context_variables (dict, optional): Additional context for the conversation.
        
        Returns:
            Response: The result of the conversation.
        """
        # Implementation...
```

### 5.3 Using documentation effectively
1. Start with the README for an overview
2. Refer to docstrings for detailed function/class information
3. Look for examples in the `examples/` directory
4. Check for additional documentation in a `docs/` directory (if present)

## Hands-on Exercise: Exploring the Swarm Project

1. Clone the Swarm repository:
   ```bash
   git clone https://github.com/openai/swarm.git
   cd swarm
   ```

2. Create and activate a virtual environment:
   ```bash
   python -m venv swarm_env
   source swarm_env/bin/activate  # On Windows, use `swarm_env\Scripts\activate`
   ```

3. Install the project dependencies:
   ```bash
   pip install -e .
   ```

4. Explore the project structure:
   ```bash
   # List contents of main directories
   ls swarm
   ls examples
   ls tests
   ```

5. Examine key files:
   ```bash
   # View contents of core.py
   cat swarm/core.py
   
   # View README
   cat README.md
   ```

6. Run a basic example:
   ```bash
   python examples/basic/bare_minimum.py
   ```

7. Deactivate the virtual environment when done:
   ```bash
   deactivate
   ```

## Conclusion

In this lesson, we've explored the Swarm project structure, examined key files and their purposes, learned about package management and dependencies, worked with virtual environments, and practiced reading project documentation. These skills form the foundation for effectively working with and contributing to the Swarm project.

In the next lesson, we'll dive deeper into Python fundamentals specifically relevant to Swarm development.

## Additional Resources

- [Python Packaging User Guide](https://packaging.python.org/)
- [venv — Creation of virtual environments](https://docs.python.org/3/library/venv.html)
- [pip documentation](https://pip.pypa.io/en/stable/)
- [How to write a good README](https://www.makeareadme.com/)

