# Lesson 11: Scaling and Optimization

## Learning Objectives
By the end of this lesson, you will be able to:
1. Handle large conversations and context in Swarm
2. Optimize Swarm for response time and resource usage
3. Implement caching strategies for improved performance
4. Utilize parallel processing techniques in Swarm
5. Apply techniques to reduce API costs when using Swarm

## 1. Handling Large Conversations and Context

As AI agents engage in longer conversations, managing the growing context becomes crucial. Let's explore techniques to handle large conversations efficiently in Swarm.

### 1.1 Context Management

In the Swarm framework, context is primarily managed through the `messages` list in the `run()` method. Here's how we can optimize it:

```python
# swarm/core.py

class Swarm:
    def run(self, agent: Agent, messages: List, context_variables: dict = {}, ...):
        # ... existing code ...

        while len(messages) - init_len < max_turns:
            # Implement context truncation
            if len(messages) > MAX_CONTEXT_LENGTH:
                messages = messages[:MAX_CONTEXT_LENGTH//2] + messages[-MAX_CONTEXT_LENGTH//2:]

            # ... rest of the method ...
```

This technique keeps the most recent context while preserving some early context, which can be crucial for maintaining conversation coherence.

### 1.2 Summarization for Long Contexts

For very long conversations, we can implement a summarization step:

```python
# swarm/utils.py

def summarize_context(messages: List[dict], max_length: int = 1000) -> str:
    full_context = " ".join([m["content"] for m in messages])
    if len(full_context) <= max_length:
        return full_context
    
    # Use OpenAI's API to summarize
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "Summarize the following conversation:"},
            {"role": "user", "content": full_context[:max_length*2]}  # Send twice the desired length for better context
        ]
    )
    return response.choices[0].message.content

# In swarm/core.py, modify the run method:
def run(self, ...):
    # ... existing code ...
    if len(messages) > SUMMARIZATION_THRESHOLD:
        summary = summarize_context(messages)
        messages = [{"role": "system", "content": f"Previous conversation summary: {summary}"}] + messages[-10:]
    # ... rest of the method ...
```

## 2. Optimizing for Response Time and Resource Usage

### 2.1 Asynchronous Processing

Swarm can benefit from asynchronous processing, especially when dealing with multiple agents or external API calls. Let's modify the core to support async operations:

```python
# swarm/core.py

import asyncio
from openai import AsyncOpenAI

class Swarm:
    def __init__(self, client=None):
        self.client = AsyncOpenAI() if client is None else client

    async def run_async(self, agent: Agent, messages: List, ...):
        # ... existing setup code ...

        while len(messages) - init_len < max_turns:
            completion = await self.get_chat_completion_async(agent, messages, ...)
            # ... rest of the logic ...

    async def get_chat_completion_async(self, agent: Agent, history: List, ...):
        # ... existing setup code ...
        return await self.client.chat.completions.create(
            model=agent.model,
            messages=[{"role": "system", "content": instructions}] + history,
            tools=tool_schemas or None,
        )

# Usage
async def main():
    swarm = Swarm()
    result = await swarm.run_async(agent, messages)

asyncio.run(main())
```

### 2.2 Batching Requests

For scenarios where multiple independent tasks can be processed simultaneously:

```python
# swarm/core.py

async def process_batch(self, tasks: List[dict]):
    async def process_task(task):
        return await self.run_async(**task)

    return await asyncio.gather(*[process_task(task) for task in tasks])

# Usage
tasks = [
    {"agent": agent1, "messages": messages1},
    {"agent": agent2, "messages": messages2},
    # ... more tasks ...
]
results = await swarm.process_batch(tasks)
```

## 3. Implementing Caching Strategies

Caching can significantly reduce API calls and improve response times. Let's implement a simple caching mechanism:

```python
# swarm/cache.py

import hashlib
import json
from typing import Any, Dict

class SimpleCache:
    def __init__(self):
        self.cache: Dict[str, Any] = {}

    def _generate_key(self, agent: Agent, messages: List[Dict[str, str]]) -> str:
        key_data = json.dumps({"agent": agent.model_dump(), "messages": messages}, sort_keys=True)
        return hashlib.md5(key_data.encode()).hexdigest()

    def get(self, agent: Agent, messages: List[Dict[str, str]]) -> Any:
        key = self._generate_key(agent, messages)
        return self.cache.get(key)

    def set(self, agent: Agent, messages: List[Dict[str, str]], value: Any) -> None:
        key = self._generate_key(agent, messages)
        self.cache[key] = value

# Modify swarm/core.py to use the cache
from .cache import SimpleCache

class Swarm:
    def __init__(self, client=None):
        # ... existing code ...
        self.cache = SimpleCache()

    async def get_chat_completion_async(self, agent: Agent, history: List, ...):
        cached_response = self.cache.get(agent, history)
        if cached_response:
            return cached_response

        response = await self.client.chat.completions.create(...)
        self.cache.set(agent, history, response)
        return response
```

## 4. Parallel Processing in Swarm

For complex workflows involving multiple agents, we can implement parallel processing:

```python
# swarm/parallel.py

import asyncio
from typing import List, Dict
from .core import Swarm
from .types import Agent, Response

async def process_parallel(swarm: Swarm, workflow: List[Dict[str, Any]]) -> List[Response]:
    async def process_step(step):
        agent = step['agent']
        messages = step['messages']
        return await swarm.run_async(agent, messages)

    return await asyncio.gather(*[process_step(step) for step in workflow])

# Usage
workflow = [
    {'agent': agent1, 'messages': messages1},
    {'agent': agent2, 'messages': messages2},
    # ... more steps ...
]
results = await process_parallel(swarm, workflow)
```

## 5. Techniques for Reducing API Costs

### 5.1 Token Optimization

Implement a token counting utility to optimize API usage:

```python
# swarm/utils.py

import tiktoken

def num_tokens_from_messages(messages, model="gpt-3.5-turbo-0613"):
    encoding = tiktoken.encoding_for_model(model)
    num_tokens = 0
    for message in messages:
        num_tokens += 4  # every message follows <im_start>{role/name}\n{content}<im_end>\n
        for key, value in message.items():
            num_tokens += len(encoding.encode(value))
            if key == "name":  # if there's a name, the role is omitted
                num_tokens -= 1  # role is always required and always 1 token
    num_tokens += 2  # every reply is primed with <im_start>assistant
    return num_tokens

# Use in swarm/core.py
def run(self, ...):
    # ... existing code ...
    token_count = num_tokens_from_messages(messages, agent.model)
    if token_count > MAX_TOKENS:
        # Implement truncation or summarization
    # ... rest of the method ...
```

### 5.2 Model Selection Based on Complexity

Implement logic to choose the most cost-effective model based on the task complexity:

```python
# swarm/utils.py

def select_model(task_complexity: int, message_length: int) -> str:
    if task_complexity < 5 and message_length < 100:
        return "gpt-3.5-turbo"
    elif task_complexity < 8 and message_length < 500:
        return "gpt-4-1106-preview"
    else:
        return "gpt-4"

# Use in swarm/core.py
def run(self, agent: Agent, messages: List, ...):
    # ... existing code ...
    task_complexity = assess_task_complexity(messages)  # Implement this function
    message_length = sum(len(m['content']) for m in messages)
    model = select_model(task_complexity, message_length)
    # Use the selected model in the API call
    # ... rest of the method ...
```

## Hands-on Exercise

Implement a caching mechanism and parallel processing in a Swarm application that manages a customer support system with multiple specialized agents. The system should handle incoming queries, route them to appropriate agents, and process responses in parallel when possible.

## Best Practices and Pitfalls

- Regularly monitor and analyze your API usage to identify optimization opportunities.
- Be cautious with caching to ensure you're not serving outdated information.
- When implementing parallel processing, be mindful of rate limits and implement appropriate error handling and retries.
- Regularly review and update your model selection criteria as new models become available and pricing changes.

## Mini-Project

Develop a Swarm-based system that simulates a multi-department customer service center. Implement context management, caching, and parallel processing to handle a high volume of diverse customer inquiries efficiently.

## Assessment

1. What techniques can be used to manage large conversation contexts in Swarm?
2. How can asynchronous processing improve the performance of a Swarm application?
3. Describe a simple caching strategy for Swarm and its potential benefits.
4. How can parallel processing be implemented in Swarm for complex workflows?
5. What are some effective techniques for reducing API costs when using Swarm?

## Additional Resources

- [OpenAI API Documentation](https://beta.openai.com/docs/)
- [Python asyncio Documentation](https://docs.python.org/3/library/asyncio.html)
- [Tiktoken GitHub Repository](https://github.com/openai/tiktoken)
- [Designing Efficient LLM Applications](https://www.pinecone.io/learn/efficient-llm-applications/)

By mastering these scaling and optimization techniques, you'll be able to build more efficient and cost-effective AI agent systems using the Swarm framework. Remember to always test your optimizations thoroughly and monitor their impact on both performance and cost.
