# Lesson 8: Advanced Agent Interactions

## Learning Objectives
By the end of this lesson, you will be able to:
1. Implement complex conversation flows using multiple agents
2. Manage context across multiple agents effectively
3. Develop strategies for effective agent handoffs
4. Debug multi-agent interactions
5. Implement fallback mechanisms for failed interactions

## 1. Implementing Complex Conversation Flows

Complex conversation flows involve multiple agents working together to handle user queries. This often requires agents to pass control between each other based on the conversation context.

### Example: Customer Support System

Let's implement a customer support system with three agents: a Triage Agent, a Technical Support Agent, and a Billing Support Agent.

```python
from swarm import Swarm, Agent

def transfer_to_tech_support():
    return tech_support_agent

def transfer_to_billing_support():
    return billing_support_agent

def escalate_to_human():
    print("Escalating to human support...")
    return "Escalated to human support."

triage_agent = Agent(
    name="Triage Agent",
    instructions="You are the initial point of contact. Determine if the user needs technical or billing support, then transfer to the appropriate agent.",
    functions=[transfer_to_tech_support, transfer_to_billing_support, escalate_to_human]
)

tech_support_agent = Agent(
    name="Technical Support Agent",
    instructions="You handle technical issues. If you can't resolve the issue, escalate to human support.",
    functions=[escalate_to_human]
)

billing_support_agent = Agent(
    name="Billing Support Agent",
    instructions="You handle billing and account issues. If you can't resolve the issue, escalate to human support.",
    functions=[escalate_to_human]
)

def run_conversation(client, initial_agent, user_input):
    messages = [{"role": "user", "content": user_input}]
    current_agent = initial_agent
    
    while True:
        response = client.run(agent=current_agent, messages=messages)
        print(f"{current_agent.name}: {response.messages[-1]['content']}")
        
        if response.agent != current_agent:
            current_agent = response.agent
            print(f"Transferred to {current_agent.name}")
        else:
            break
        
    return response

client = Swarm()
user_query = "I'm having trouble logging into my account"
run_conversation(client, triage_agent, user_query)
```

This example demonstrates:
- Multiple agents with specific roles
- Agent-to-agent transfers based on the conversation context
- Escalation to human support when needed

## 2. Managing Context Across Multiple Agents

When transferring between agents, it's crucial to maintain context. This can be achieved using context variables and by passing the full conversation history.

### Implementing Context Management

```python
from swarm import Swarm, Agent, Result

def update_context(context_variables, **kwargs):
    context_variables.update(kwargs)
    return Result(value="Context updated", context_variables=context_variables)

def transfer_to_agent(agent, context_variables):
    return Result(value=f"Transferring to {agent.name}", agent=agent, context_variables=context_variables)

triage_agent = Agent(
    name="Triage Agent",
    instructions="You are the initial point of contact. Gather basic information and update the context before transferring.",
    functions=[update_context, transfer_to_agent]
)

support_agent = Agent(
    name="Support Agent",
    instructions="You provide detailed support. Use the context provided to give personalized assistance.",
    functions=[update_context]
)

def run_conversation_with_context(client, initial_agent, user_input):
    messages = [{"role": "user", "content": user_input}]
    current_agent = initial_agent
    context_variables = {}
    
    while True:
        response = client.run(agent=current_agent, messages=messages, context_variables=context_variables)
        print(f"{current_agent.name}: {response.messages[-1]['content']}")
        
        context_variables = response.context_variables
        if response.agent != current_agent:
            current_agent = response.agent
            print(f"Transferred to {current_agent.name}")
        else:
            break
        
    return response

client = Swarm()
user_query = "I need help with my subscription"
run_conversation_with_context(client, triage_agent, user_query)
```

This implementation:
- Uses `context_variables` to store and update context across agents
- Passes context during agent transfers
- Allows agents to access and modify shared context

## 3. Strategies for Effective Agent Handoffs

Effective handoffs ensure smooth transitions between agents and maintain conversation coherence.

### Best Practices for Agent Handoffs:

1. **Clear Handoff Conditions**: Define clear conditions for when an agent should transfer control.
2. **Context Summarization**: Provide a brief summary of the conversation when handing off.
3. **Explicit Handoff Statements**: Make the handoff clear to the user.
4. **Smooth Transitions**: Ensure the receiving agent acknowledges the handoff and continues the conversation seamlessly.

### Example Implementation:

```python
def handoff_to_specialist(specialist_type, context_summary):
    if specialist_type == "technical":
        return Result(
            value=f"Transferring to Technical Specialist. Context: {context_summary}",
            agent=tech_specialist_agent,
            context_variables={"summary": context_summary}
        )
    elif specialist_type == "billing":
        return Result(
            value=f"Transferring to Billing Specialist. Context: {context_summary}",
            agent=billing_specialist_agent,
            context_variables={"summary": context_summary}
        )

general_agent = Agent(
    name="General Support Agent",
    instructions="You handle initial queries. If a specialist is needed, summarize the context and hand off.",
    functions=[handoff_to_specialist]
)

tech_specialist_agent = Agent(
    name="Technical Specialist",
    instructions="You handle technical issues. Acknowledge the handoff and use the provided context to continue the conversation.",
    functions=[]
)

billing_specialist_agent = Agent(
    name="Billing Specialist",
    instructions="You handle billing issues. Acknowledge the handoff and use the provided context to continue the conversation.",
    functions=[]
)
```

## 4. Debugging Multi-Agent Interactions

Debugging multi-agent systems can be challenging due to their complexity. Here are some strategies:

1. **Logging**: Implement comprehensive logging for all agent interactions.
2. **Conversation Tracing**: Create a system to trace the flow of conversation across agents.
3. **State Visualization**: Develop tools to visualize the state of the conversation and agent transitions.
4. **Unit Testing**: Write unit tests for individual agent behaviors and handoff logic.

### Example Debugging Tools:

```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ConversationTracer:
    def __init__(self):
        self.trace = []

    def log_interaction(self, agent_name, message, is_handoff=False):
        self.trace.append({
            "agent": agent_name,
            "message": message,
            "is_handoff": is_handoff
        })
        logger.info(f"{'HANDOFF: ' if is_handoff else ''}{agent_name}: {message}")

    def print_trace(self):
        for step in self.trace:
            prefix = "HANDOFF: " if step["is_handoff"] else ""
            print(f"{prefix}{step['agent']}: {step['message']}")

tracer = ConversationTracer()

def run_conversation_with_tracing(client, initial_agent, user_input):
    messages = [{"role": "user", "content": user_input}]
    current_agent = initial_agent
    
    while True:
        response = client.run(agent=current_agent, messages=messages)
        tracer.log_interaction(current_agent.name, response.messages[-1]['content'])
        
        if response.agent != current_agent:
            tracer.log_interaction(current_agent.name, f"Transferring to {response.agent.name}", is_handoff=True)
            current_agent = response.agent
        else:
            break
        
    return response

# After running the conversation
tracer.print_trace()
```

## 5. Implementing Fallback Mechanisms

Fallback mechanisms ensure that the system can handle unexpected situations or failed interactions gracefully.

### Strategies for Fallback Mechanisms:

1. **Timeout Handling**: Implement timeouts for agent responses and actions.
2. **Error Recovery**: Develop error recovery procedures for each agent.
3. **Default Responses**: Provide default responses when an agent fails to generate an appropriate response.
4. **Human Escalation**: Implement a final fallback to human support.

### Example Implementation:

```python
import time

class FallbackHandler:
    def __init__(self, timeout=30, max_retries=3):
        self.timeout = timeout
        self.max_retries = max_retries

    def execute_with_fallback(self, func, *args, **kwargs):
        for attempt in range(self.max_retries):
            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                logger.warning(f"Attempt {attempt + 1} failed: {str(e)}")
                if attempt == self.max_retries - 1:
                    return self.final_fallback()
                time.sleep(2 ** attempt)  # Exponential backoff

    def final_fallback(self):
        logger.error("All attempts failed. Escalating to human support.")
        return Result(
            value="I apologize, but I'm having trouble assisting you. Let me transfer you to a human support agent.",
            agent=human_support_agent
        )

fallback_handler = FallbackHandler()

def run_conversation_with_fallback(client, initial_agent, user_input):
    messages = [{"role": "user", "content": user_input}]
    current_agent = initial_agent
    
    while True:
        response = fallback_handler.execute_with_fallback(
            client.run,
            agent=current_agent,
            messages=messages
        )
        print(f"{current_agent.name}: {response.messages[-1]['content']}")
        
        if response.agent != current_agent:
            current_agent = response.agent
            print(f"Transferred to {current_agent.name}")
        else:
            break
        
    return response
```

This implementation:
- Uses a `FallbackHandler` to manage retries and timeouts
- Implements exponential backoff for retries
- Provides a final fallback to human support

## Hands-on Exercise: Building a Multi-Agent Customer Support System

Let's create a Swarm application that demonstrates advanced agent interactions, including context management, handoffs, debugging, and fallback mechanisms.

1. Set up the project structure:

```
multi_agent_support/
├── main.py
├── agents.py
├── fallback.py
├── tracer.py
└── requirements.txt
```

2. Install the required packages:

```bash
pip install openai python-dotenv
```

3. In `agents.py`, define the agents:

```python
from swarm import Agent, Result

def update_context(context_variables, **kwargs):
    context_variables.update(kwargs)
    return Result(value="Context updated", context_variables=context_variables)

def transfer_to_agent(agent, context_variables):
    return Result(value=f"Transferring to {agent.name}", agent=agent, context_variables=context_variables)

def escalate_to_human():
    print("Escalating to human support...")
    return "Escalated to human support."

triage_agent = Agent(
    name="Triage Agent",
    instructions="You are the initial point of contact. Gather basic information and update the context before transferring.",
    functions=[update_context, transfer_to_agent, escalate_to_human]
)

tech_support_agent = Agent(
    name="Technical Support Agent",
    instructions="You handle technical issues. Use the context provided to give personalized assistance.",
    functions=[update_context, escalate_to_human]
)

billing_support_agent = Agent(
    name="Billing Support Agent",
    instructions="You handle billing and account issues. Use the context provided to give personalized assistance.",
    functions=[update_context, escalate_to_human]
)
```

4. In `fallback.py`, implement the fallback handler:

```python
import time
import logging
from swarm import Result

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FallbackHandler:
    def __init__(self, timeout=30, max_retries=3):
        self.timeout = timeout
        self.max_retries = max_retries

    def execute_with_fallback(self, func, *args, **kwargs):
        for attempt in range(self.max_retries):
            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                logger.warning(f"Attempt {attempt + 1} failed: {str(e)}")
                if attempt == self.max_retries - 1:
                    return self.final_fallback()
                time.sleep(2 ** attempt)  # Exponential backoff

    def final_fallback(self):
        logger.error("All attempts failed. Escalating to human support.")
        return Result(
            value="I apologize, but I'm having trouble assisting you. Let me transfer you to a human support agent.",
            agent=None
        )
```

5. In `tracer.py`, implement the conversation tracer:

```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ConversationTracer:
    def __init__(self):
        self.trace = []

    def log_interaction(self, agent_name, message, is_handoff=False):
        self.trace.append({
            "agent": agent_name,
            "message": message,
            "is_handoff": is_handoff
        })
        logger.info(f"{'HANDOFF: ' if is_handoff else ''}{agent_name}: {message}")

    def print_trace(self):
        for step in self.trace:
            prefix = "HANDOFF: " if step["is_handoff"] else ""
            print(f"{prefix}{step['agent']}: {step['message']}")
```

6. In `main.py`, create the main application:

```python
import os
from dotenv import load_dotenv
from swarm import Swarm
from agents import triage_agent, tech_support_agent, billing_support_agent
from fallback import FallbackHandler
from tracer import ConversationTracer

# Load environment variables
load_dotenv()

# Get API key
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise ValueError("OPENAI_API_KEY environment variable not set")

# Initialize Swarm, FallbackHandler, and ConversationTracer
client = Swarm(api_key=api_key)
fallback_handler = FallbackHandler()
tracer = ConversationTracer()

def run_conversation(user_input):
    messages = [{"role": "user", "content": user_input}]
    current_agent = triage_agent
    context_variables = {}
    
    while True:
        response = fallback_handler.execute_with_fallback(
            client.run,
            agent=current_agent,
            messages=messages,
            context_variables=context_variables
        )
        
        tracer.log_interaction(current_agent.name, response.messages[-1]['content'])
        
        context_variables = response.context


        if response.agent != current_agent:
            tracer.log_interaction(current_agent.name, f"Transferring to {response.agent.name}", is_handoff=True)
            current_agent = response.agent
        else:
            break
        
    return response

# Test the multi-agent system
user_queries = [
    "I'm having trouble logging into my account",
    "I want to upgrade my subscription",
    "My app is crashing, can you help?",
    "I have a billing question about my last invoice"
]

for query in user_queries:
    print(f"\nUser: {query}")
    run_conversation(query)

print("\nConversation Trace:")
tracer.print_trace()
```

This exercise demonstrates:
- Integration of multiple agents with specific roles
- Context management across agent interactions
- Implementation of fallback mechanisms for error handling
- Tracing and logging of conversations for debugging
- Handling of various user queries in a multi-agent support system

To run the application:

1. Set up your OpenAI API key in a `.env` file:
   ```
   OPENAI_API_KEY=your_api_key_here
   ```

2. Run the main script:
   ```
   python main.py
   ```

This will simulate a series of user queries and demonstrate how the multi-agent system handles different types of requests, including agent handoffs and error handling.

## Quiz

1. What are the key components needed to implement complex conversation flows with multiple agents?
2. How can context be effectively managed and passed between different agents?
3. What are some best practices for implementing agent handoffs?
4. Why is debugging important in multi-agent systems, and what tools can be used to facilitate debugging?
5. How does the fallback mechanism contribute to the robustness of a multi-agent system?

## Additional Resources

- [Multi-Agent Systems: A Survey](https://www.sciencedirect.com/science/article/pii/S1574119212000266)
- [Designing Conversational Agents](https://www.interaction-design.org/literature/article/how-to-design-voice-user-interfaces)
- [Error Handling Best Practices in Python](https://realpython.com/python-exceptions/)
- [Logging in Python](https://realpython.com/python-logging/)

In the next lesson, we'll explore how to customize Swarm for specific use cases, building on the advanced agent interactions we've learned here.

