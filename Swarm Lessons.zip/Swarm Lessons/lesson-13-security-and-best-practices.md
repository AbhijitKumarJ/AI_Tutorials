# Lesson 13: Security and Best Practices

## Learning Objectives
By the end of this lesson, you will be able to:
1. Implement secure methods for handling API keys and sensitive information
2. Design and implement rate limiting and quota management systems
3. Apply best practices for prompt engineering to enhance security and performance
4. Understand and address ethical considerations in AI agent development
5. Implement user authentication and authorization in Swarm-based applications

## 1. Securing API Keys and Sensitive Information

Proper handling of API keys and sensitive information is crucial for the security of your Swarm application.

### 1.1 Environment Variables

Use environment variables to store sensitive information:

```python
# swarm/config.py

import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
DATABASE_URL = os.getenv("DATABASE_URL")
```

### 1.2 Secure Configuration Management

Implement a secure configuration management system:

```python
# swarm/config.py

from cryptography.fernet import Fernet

class SecureConfig:
    def __init__(self, encryption_key: str):
        self.cipher_suite = Fernet(encryption_key)

    def encrypt(self, value: str) -> str:
        return self.cipher_suite.encrypt(value.encode()).decode()

    def decrypt(self, encrypted_value: str) -> str:
        return self.cipher_suite.decrypt(encrypted_value.encode()).decode()

# Usage
secure_config = SecureConfig(os.getenv("ENCRYPTION_KEY"))
encrypted_api_key = secure_config.encrypt(OPENAI_API_KEY)
```

### 1.3 Secure Storage

For persistent storage of sensitive information, use secure storage solutions:

```python
# swarm/storage.py

import keyring

def store_secret(service_name: str, username: str, secret: str):
    keyring.set_password(service_name, username, secret)

def get_secret(service_name: str, username: str) -> str:
    return keyring.get_password(service_name, username)

# Usage
store_secret("openai", "api_key", OPENAI_API_KEY)
retrieved_api_key = get_secret("openai", "api_key")
```

## 2. Implementing Rate Limiting and Quota Management

To prevent abuse and manage resources effectively, implement rate limiting and quota management.

### 2.1 Rate Limiting

Implement a simple rate limiter using a token bucket algorithm:

```python
# swarm/rate_limiter.py

import time
from typing import Dict

class RateLimiter:
    def __init__(self, max_calls: int, time_frame: float):
        self.max_calls = max_calls
        self.time_frame = time_frame
        self.calls: Dict[str, list] = {}

    def is_allowed(self, key: str) -> bool:
        current_time = time.time()
        if key not in self.calls:
            self.calls[key] = []
        
        self.calls[key] = [t for t in self.calls[key] if current_time - t < self.time_frame]
        
        if len(self.calls[key]) < self.max_calls:
            self.calls[key].append(current_time)
            return True
        return False

# Usage in swarm/core.py
from .rate_limiter import RateLimiter

class Swarm:
    def __init__(self, client=None):
        # ... existing code ...
        self.rate_limiter = RateLimiter(max_calls=60, time_frame=60)  # 60 calls per minute

    async def run(self, agent: Agent, messages: List, ...):
        if not self.rate_limiter.is_allowed(agent.name):
            raise SwarmException("Rate limit exceeded")
        # ... rest of the run method ...
```

### 2.2 Quota Management

Implement a quota management system to track and limit API usage:

```python
# swarm/quota.py

import redis
from datetime import datetime, timedelta

class QuotaManager:
    def __init__(self, redis_url: str):
        self.redis = redis.from_url(redis_url)

    def increment_usage(self, user_id: str, amount: int = 1):
        key = f"quota:{user_id}:{datetime.now().strftime('%Y-%m-%d')}"
        self.redis.incrby(key, amount)
        self.redis.expire(key, timedelta(days=30))  # Keep data for 30 days

    def get_usage(self, user_id: str) -> int:
        key = f"quota:{user_id}:{datetime.now().strftime('%Y-%m-%d')}"
        return int(self.redis.get(key) or 0)

    def check_quota(self, user_id: str, limit: int) -> bool:
        return self.get_usage(user_id) < limit

# Usage in swarm/core.py
from .quota import QuotaManager

class Swarm:
    def __init__(self, client=None, redis_url: str = "redis://localhost"):
        # ... existing code ...
        self.quota_manager = QuotaManager(redis_url)

    async def run(self, agent: Agent, messages: List, user_id: str, daily_limit: int = 1000):
        if not self.quota_manager.check_quota(user_id, daily_limit):
            raise SwarmException("Daily quota exceeded")
        # ... rest of the run method ...
        self.quota_manager.increment_usage(user_id)
```

## 3. Best Practices for Prompt Engineering

Proper prompt engineering is crucial for both security and performance.

### 3.1 Sanitize User Input

Always sanitize user input before including it in prompts:

```python
# swarm/utils.py

import re

def sanitize_input(text: str) -> str:
    # Remove any potential code or script tags
    text = re.sub(r'<script.*?>.*?</script>', '', text, flags=re.DOTALL)
    # Remove any HTML tags
    text = re.sub(r'<.*?>', '', text)
    # Remove any potential SQL injection attempts
    text = re.sub(r'\b(UNION|SELECT|FROM|WHERE)\b', '', text, flags=re.IGNORECASE)
    return text

# Usage in swarm/core.py
class Swarm:
    async def run(self, agent: Agent, messages: List, ...):
        sanitized_messages = [
            {**msg, "content": sanitize_input(msg["content"])}
            for msg in messages
        ]
        # Use sanitized_messages instead of messages
```

### 3.2 Use Role-Based Prompts

Structure your prompts to clearly define the role and boundaries of the AI:

```python
# swarm/prompts.py

def create_role_based_prompt(role: str, task: str, constraints: List[str]) -> str:
    return f"""
    You are a {role}. Your task is to {task}.
    
    Constraints:
    {' '.join(f'- {constraint}' for constraint in constraints)}
    
    Remember, you must always operate within these constraints.
    """

# Usage
prompt = create_role_based_prompt(
    role="customer service agent",
    task="assist customers with their inquiries",
    constraints=[
        "Never share personal information",
        "Always be polite and professional",
        "Escalate to a human agent if unsure"
    ]
)
```

### 3.3 Implement Content Filtering

Use content filtering to prevent generating or processing inappropriate content:

```python
# swarm/content_filter.py

import re

class ContentFilter:
    def __init__(self, forbidden_words: List[str]):
        self.forbidden_words = forbidden_words
        self.pattern = re.compile(r'\b(' + '|'.join(re.escape(word) for word in forbidden_words) + r')\b', re.IGNORECASE)

    def filter_content(self, text: str) -> str:
        return self.pattern.sub('[REDACTED]', text)

    def is_appropriate(self, text: str) -> bool:
        return not bool(self.pattern.search(text))

# Usage in swarm/core.py
from .content_filter import ContentFilter

class Swarm:
    def __init__(self, client=None):
        # ... existing code ...
        self.content_filter = ContentFilter(["inappropriate", "offensive", "explicit"])

    async def run(self, agent: Agent, messages: List, ...):
        filtered_messages = [
            {**msg, "content": self.content_filter.filter_content(msg["content"])}
            for msg in messages
        ]
        # Use filtered_messages instead of messages
        
        response = await self.get_chat_completion(agent, filtered_messages, ...)
        if not self.content_filter.is_appropriate(response.content):
            raise SwarmException("Generated content is not appropriate")
```

## 4. Ethical Considerations in AI Agent Development

As AI developers, we have a responsibility to consider the ethical implications of our work.

### 4.1 Implement Ethical Guidelines

Create a set of ethical guidelines for your AI agents:

```python
# swarm/ethics.py

from enum import Enum

class EthicalPrinciple(Enum):
    FAIRNESS = "Ensure fair and unbiased treatment of all users"
    TRANSPARENCY = "Be transparent about AI capabilities and limitations"
    PRIVACY = "Respect user privacy and data protection"
    ACCOUNTABILITY = "Take responsibility for AI actions and decisions"
    SAFETY = "Prioritize user safety and well-being"

class EthicsChecker:
    def __init__(self, principles: List[EthicalPrinciple]):
        self.principles = principles

    def check_compliance(self, action: str) -> bool:
        # Implement logic to check if the action complies with ethical principles
        # This is a placeholder implementation
        return all(principle.value in action for principle in self.principles)

# Usage in swarm/core.py
from .ethics import EthicsChecker, EthicalPrinciple

class Swarm:
    def __init__(self, client=None):
        # ... existing code ...
        self.ethics_checker = EthicsChecker([
            EthicalPrinciple.FAIRNESS,
            EthicalPrinciple.TRANSPARENCY,
            EthicalPrinciple.PRIVACY
        ])

    async def run(self, agent: Agent, messages: List, ...):
        # ... existing code ...
        if not self.ethics_checker.check_compliance(response.content):
            raise SwarmException("Generated content does not comply with ethical guidelines")
```

### 4.2 Implement Bias Detection and Mitigation

Use techniques to detect and mitigate bias in AI responses:

```python
# swarm/bias_detector.py

import re
from typing import List, Tuple

class BiasDetector:
    def __init__(self, bias_words: List[Tuple[str, str]]):
        self.bias_words = bias_words

    def detect_bias(self, text: str) -> List[str]:
        detected_bias = []
        for biased_word, alternative in self.bias_words:
            if re.search(r'\b' + re.escape(biased_word) + r'\b', text, re.IGNORECASE):
                detected_bias.append(f"Detected potentially biased term '{biased_word}'. Consider using '{alternative}' instead.")
        return detected_bias

# Usage in swarm/core.py
from .bias_detector import BiasDetector

class Swarm:
    def __init__(self, client=None):
        # ... existing code ...
        self.bias_detector = BiasDetector([
            ("mankind", "humanity"),
            ("policeman", "police officer"),
            ("chairman", "chairperson")
        ])

    async def run(self, agent: Agent, messages: List, ...):
        # ... existing code ...
        bias_warnings = self.bias_detector.detect_bias(response.content)
        if bias_warnings:
            print("Bias warnings:", bias_warnings)
```

## 5. Implementing User Authentication and Authorization

Secure your Swarm-based application by implementing proper user authentication and authorization.

### 5.1 User Authentication

Implement a simple user authentication system:

```python
# swarm/auth.py

import jwt
from datetime import datetime, timedelta
from passlib.hash import pbkdf2_sha256

SECRET_KEY = "your-secret-key"  # Store this securely, preferably in environment variables

class Auth:
    @staticmethod
    def hash_password(password: str) -> str:
        return pbkdf2_sha256.hash(password)

    @staticmethod
    def verify_password(password: str, hashed_password: str) -> bool:
        return pbkdf2_sha256.verify(password, hashed_password)

    @staticmethod
    def generate_token(user_id: str) -> str:
        payload = {
            "user_id": user_id,
            "exp": datetime.utcnow() + timedelta(days=1)
        }
        return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

    @staticmethod
    def verify_token(token: str) -> dict:
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
            return payload
        except jwt.ExpiredSignatureError:
            raise ValueError("Token has expired")
        except jwt.InvalidTokenError:
            raise ValueError("Invalid token")

# Usage
auth = Auth()
hashed_password = auth.hash_password("user_password")
is_valid = auth.verify_password("user_password", hashed_password)
token = auth.generate_token("user123")
payload = auth.verify_token(token)
```

### 5.2 User Authorization

```python
# swarm/auth.py

from enum import Enum
from typing import List

class UserRole(Enum):
    ADMIN = "admin"
    USER = "user"
    GUEST = "guest"

class RBAC:
    def __init__(self):
        self.role_permissions = {
            UserRole.ADMIN: ["read", "write", "delete"],
            UserRole.USER: ["read", "write"],
            UserRole.GUEST: ["read"]
        }

    def has_permission(self, role: UserRole, permission: str) -> bool:
        return permission in self.role_permissions.get(role, [])

# Usage in swarm/core.py
from .auth import Auth, RBAC, UserRole

class Swarm:
    def __init__(self, client=None):
        # ... existing code ...
        self.auth = Auth()
        self.rbac = RBAC()

    async def run(self, agent: Agent, messages: List, token: str, required_permission: str):
        try:
            payload = self.auth.verify_token(token)
            user_role = UserRole(payload.get("role", "guest"))
            if not self.rbac.has_permission(user_role, required_permission):
                raise SwarmException("User does not have the required permission")
            # ... rest of the run method ...
        except ValueError as e:
            raise SwarmException(f"Authentication failed: {str(e)}")
```

## Hands-on Exercise

Implement a secure Swarm-based chatbot with the following features:
1. Secure API key management using environment variables and encryption
2. Rate limiting to prevent abuse (e.g., 60 requests per minute per user)
3. Content filtering to prevent inappropriate content
4. User authentication and role-based access control
5. Logging of all interactions for auditing purposes

Ensure that all user inputs are properly sanitized and that the chatbot adheres to defined ethical guidelines.

## Best Practices and Pitfalls

- Always use HTTPS for any network communication involving sensitive data.
- Regularly update and rotate API keys and other secrets.
- Implement proper error handling to avoid leaking sensitive information through error messages.
- Regularly audit your codebase for potential security vulnerabilities.
- Keep your dependencies up-to-date to benefit from the latest security patches.
- Implement proper logging and monitoring to detect and respond to security incidents quickly.
- Be cautious about storing sensitive user data and always comply with relevant data protection regulations (e.g., GDPR, CCPA).

## Mini-Project

Develop a secure Swarm-based customer support system with the following features:
1. User authentication and role-based access (admin, support agent, customer)
2. Secure handling of customer information
3. Rate limiting and quota management to prevent abuse
4. Content filtering for both user inputs and AI-generated responses
5. Ethical AI guidelines implementation
6. Comprehensive logging and auditing system

Implement proper error handling and ensure that the system is resilient against common security threats.

## Assessment

1. What are some best practices for securely handling API keys in a Swarm-based application?
2. Describe the implementation of a rate limiting system and explain its importance.
3. How can prompt engineering techniques be used to enhance the security of AI interactions?
4. What ethical considerations should be taken into account when developing AI agents, and how can they be implemented in code?
5. Explain the process of implementing user authentication and authorization in a Swarm-based application.

## Additional Resources

- [OWASP Top Ten](https://owasp.org/www-project-top-ten/): A standard awareness document for developers about the most critical security risks to web applications
- [AI Ethics Guidelines](https://www.microsoft.com/en-us/ai/responsible-ai): Microsoft's guidelines for responsible AI development
- [JWT Authentication](https://jwt.io/introduction/): Introduction to JSON Web Tokens for secure authentication
- [Python Security Best Practices](https://snyk.io/learn/python-security-best-practices/): A guide to writing secure Python code
- [GDPR Compliance](https://gdpr.eu/): Official website for GDPR compliance information

By implementing these security measures and best practices, you'll be able to create more secure and ethical AI agent systems using the Swarm framework. Remember to stay updated on the latest security trends and continuously assess and improve your security measures.

