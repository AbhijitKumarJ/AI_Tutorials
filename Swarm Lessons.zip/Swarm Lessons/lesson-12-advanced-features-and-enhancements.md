# Lesson 12: Advanced Features and Enhancements

## Learning Objectives
By the end of this lesson, you will be able to:
1. Implement streaming responses in Swarm
2. Add support for different AI models
3. Enhance error handling and recovery mechanisms
4. Implement conversation logging and analysis
5. Add support for multimedia content in conversations

## 1. Implementing Streaming Responses

Streaming responses allow for real-time interaction with the AI, providing a more dynamic user experience. Let's implement this feature in Swarm.

### 1.1 Modifying the Core for Streaming

First, we'll update the `Swarm` class to support streaming:

```python
# swarm/core.py

from typing import AsyncGenerator
from openai import AsyncOpenAI

class Swarm:
    def __init__(self, client=None):
        self.client = AsyncOpenAI() if client is None else client

    async def run_streaming(self, agent: Agent, messages: List, ...) -> AsyncGenerator[str, None]:
        # ... existing setup code ...

        async for chunk in await self.get_streaming_chat_completion(agent, messages, ...):
            if chunk.choices[0].delta.content is not None:
                yield chunk.choices[0].delta.content

    async def get_streaming_chat_completion(self, agent: Agent, history: List, ...):
        # ... existing setup code ...
        return await self.client.chat.completions.create(
            model=agent.model,
            messages=[{"role": "system", "content": instructions}] + history,
            tools=tool_schemas or None,
            stream=True
        )

# Usage
async def main():
    swarm = Swarm()
    async for chunk in swarm.run_streaming(agent, messages):
        print(chunk, end='', flush=True)

asyncio.run(main())
```

### 1.2 Handling Streaming in Agents

We'll need to modify the `Agent` class to handle streaming responses:

```python
# swarm/types.py

from typing import Callable, AsyncGenerator

class Agent(BaseModel):
    # ... existing attributes ...
    stream_handler: Optional[Callable[[AsyncGenerator[str, None]], None]] = None

    async def handle_stream(self, stream: AsyncGenerator[str, None]):
        if self.stream_handler:
            await self.stream_handler(stream)
        else:
            async for chunk in stream:
                print(chunk, end='', flush=True)

# Usage in swarm/core.py
async def run_streaming(self, agent: Agent, messages: List, ...):
    # ... existing code ...
    stream = self.get_streaming_chat_completion(agent, messages, ...)
    await agent.handle_stream(stream)
```

## 2. Adding Support for Different AI Models

To make Swarm more flexible, let's add support for different AI models.

### 2.1 Model Configuration

First, we'll create a configuration file for different models:

```python
# swarm/config.py

from typing import Dict, Any

MODEL_CONFIGS: Dict[str, Dict[str, Any]] = {
    "gpt-3.5-turbo": {
        "max_tokens": 4096,
        "temperature": 0.7,
    },
    "gpt-4": {
        "max_tokens": 8192,
        "temperature": 0.5,
    },
    "claude-2": {
        "max_tokens": 100000,
        "temperature": 0.7,
    },
    # Add more models as needed
}

def get_model_config(model_name: str) -> Dict[str, Any]:
    return MODEL_CONFIGS.get(model_name, {})
```

### 2.2 Modifying Swarm to Use Different Models

Now, let's update the `Swarm` class to use these configurations:

```python
# swarm/core.py

from .config import get_model_config

class Swarm:
    # ... existing code ...

    async def get_chat_completion(self, agent: Agent, history: List, ...):
        model_config = get_model_config(agent.model)
        return await self.client.chat.completions.create(
            model=agent.model,
            messages=[{"role": "system", "content": instructions}] + history,
            tools=tool_schemas or None,
            **model_config
        )
```

### 2.3 Creating Model-Specific Agents

We can create model-specific agents for different use cases:

```python
# swarm/agents.py

from .types import Agent
from .config import get_model_config

def create_gpt3_agent(name: str, instructions: str) -> Agent:
    config = get_model_config("gpt-3.5-turbo")
    return Agent(name=name, model="gpt-3.5-turbo", instructions=instructions, **config)

def create_gpt4_agent(name: str, instructions: str) -> Agent:
    config = get_model_config("gpt-4")
    return Agent(name=name, model="gpt-4", instructions=instructions, **config)

# Usage
gpt3_agent = create_gpt3_agent("GPT-3 Agent", "You are a helpful assistant.")
gpt4_agent = create_gpt4_agent("GPT-4 Agent", "You are an advanced AI capable of complex reasoning.")
```

## 3. Enhancing Error Handling and Recovery

Robust error handling is crucial for a production-ready Swarm application. Let's implement advanced error handling and recovery mechanisms.

### 3.1 Custom Exception Classes

First, let's define custom exception classes:

```python
# swarm/exceptions.py

class SwarmException(Exception):
    """Base exception class for Swarm"""

class ModelUnavailableException(SwarmException):
    """Raised when a specified model is unavailable"""

class APILimitExceededException(SwarmException):
    """Raised when API rate limits are exceeded"""

class InvalidResponseException(SwarmException):
    """Raised when the API returns an invalid or unexpected response"""
```

### 3.2 Implementing Error Handling in Swarm

Now, let's update the `Swarm` class to use these exceptions:

```python
# swarm/core.py

from .exceptions import SwarmException, ModelUnavailableException, APILimitExceededException, InvalidResponseException

class Swarm:
    # ... existing code ...

    async def get_chat_completion(self, agent: Agent, history: List, ...):
        try:
            model_config = get_model_config(agent.model)
            return await self.client.chat.completions.create(
                model=agent.model,
                messages=[{"role": "system", "content": instructions}] + history,
                tools=tool_schemas or None,
                **model_config
            )
        except openai.APIError as e:
            if "model not found" in str(e):
                raise ModelUnavailableException(f"Model {agent.model} is not available")
            elif "rate limit" in str(e):
                raise APILimitExceededException("API rate limit exceeded")
            else:
                raise SwarmException(f"API error occurred: {str(e)}")
        except Exception as e:
            raise SwarmException(f"An unexpected error occurred: {str(e)}")

    async def run(self, agent: Agent, messages: List, ...):
        try:
            # ... existing code ...
        except SwarmException as e:
            # Log the error and attempt recovery
            print(f"Swarm error occurred: {str(e)}")
            # Implement recovery logic here (e.g., retry with a different model)
        except Exception as e:
            print(f"Unexpected error occurred: {str(e)}")
            # Implement fallback behavior
```

### 3.3 Implementing Retry Logic

Let's add a retry mechanism for transient errors:

```python
# swarm/utils.py

import asyncio
from functools import wraps

def async_retry(max_retries=3, delay=1):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return await func(*args, **kwargs)
                except (APILimitExceededException, ModelUnavailableException) as e:
                    if attempt == max_retries - 1:
                        raise
                    print(f"Attempt {attempt + 1} failed: {str(e)}. Retrying...")
                    await asyncio.sleep(delay * (2 ** attempt))  # Exponential backoff
        return wrapper
    return decorator

# Usage in swarm/core.py
class Swarm:
    @async_retry(max_retries=3)
    async def get_chat_completion(self, agent: Agent, history: List, ...):
        # ... existing code ...
```

## 4. Implementing Conversation Logging and Analysis

Logging and analyzing conversations can provide valuable insights and help improve the system over time.

### 4.1 Conversation Logger

Let's implement a conversation logger:

```python
# swarm/logging.py

import json
from datetime import datetime

class ConversationLogger:
    def __init__(self, log_file: str = "conversations.log"):
        self.log_file = log_file

    def log_conversation(self, agent: Agent, messages: List[Dict[str, str]]):
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "agent": agent.name,
            "model": agent.model,
            "conversation": messages
        }
        with open(self.log_file, "a") as f:
            json.dump(log_entry, f)
            f.write("\n")

# Usage in swarm/core.py
from .logging import ConversationLogger

class Swarm:
    def __init__(self, client=None):
        # ... existing code ...
        self.logger = ConversationLogger()

    async def run(self, agent: Agent, messages: List, ...):
        # ... existing code ...
        self.logger.log_conversation(agent, messages)
```

### 4.2 Conversation Analysis

Now, let's implement a simple conversation analyzer:

```python
# swarm/analysis.py

import json
from collections import Counter

class ConversationAnalyzer:
    def __init__(self, log_file: str = "conversations.log"):
        self.log_file = log_file

    def analyze_conversations(self):
        model_usage = Counter()
        agent_usage = Counter()
        total_messages = 0

        with open(self.log_file, "r") as f:
            for line in f:
                entry = json.loads(line)
                model_usage[entry["model"]] += 1
                agent_usage[entry["agent"]] += 1
                total_messages += len(entry["conversation"])

        return {
            "model_usage": dict(model_usage),
            "agent_usage": dict(agent_usage),
            "total_messages": total_messages,
            "average_conversation_length": total_messages / sum(model_usage.values())
        }

# Usage
analyzer = ConversationAnalyzer()
analysis_results = analyzer.analyze_conversations()
print(json.dumps(analysis_results, indent=2))
```

## 5. Adding Support for Multimedia Content

To enhance the capabilities of Swarm, let's add support for handling multimedia content in conversations.

### 5.1 Multimedia Message Type

First, we'll define a new message type that can include multimedia content:

```python
# swarm/types.py

from enum import Enum
from typing import Optional, Union

class ContentType(Enum):
    TEXT = "text"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"

class MultimediaContent(BaseModel):
    type: ContentType
    content: Union[str, bytes]
    metadata: Optional[Dict[str, Any]] = None

class Message(BaseModel):
    role: str
    content: Union[str, MultimediaContent]

# Update Agent to handle multimedia content
class Agent(BaseModel):
    # ... existing attributes ...
    supported_content_types: List[ContentType] = [ContentType.TEXT]
```

### 5.2 Handling Multimedia Content in Swarm

Now, let's update the `Swarm` class to handle multimedia content:

```python
# swarm/core.py

from .types import Message, MultimediaContent, ContentType

class Swarm:
    # ... existing code ...

    async def process_multimedia(self, agent: Agent, content: MultimediaContent) -> str:
        if content.type not in agent.supported_content_types:
            raise ValueError(f"Agent {agent.name} does not support {content.type.value} content")

        if content.type == ContentType.IMAGE:
            # Process image (e.g., perform OCR or image analysis)
            return f"[Image processed: {content.metadata.get('description', 'No description')}]"
        elif content.type == ContentType.AUDIO:
            # Process audio (e.g., perform speech-to-text)
            return f"[Audio processed: {content.metadata.get('duration', 'Unknown')} seconds]"
        elif content.type == ContentType.VIDEO:
            # Process video (e.g., extract key frames or perform video analysis)
            return f"[Video processed: {content.metadata.get('duration', 'Unknown')} seconds]"
        else:
            return str(content.content)

    async def run(self, agent: Agent, messages: List[Message], ...):
        processed_messages = []
        for message in messages:
            if isinstance(message.content, MultimediaContent):
                processed_content = await self.process_multimedia(agent, message.content)
                processed_messages.append(Message(role=message.role, content=processed_content))
            else:
                processed_messages.append(message)

        # Use processed_messages in the chat completion
        # ... rest of the run method ...
```

### 5.3 Creating Multimedia-Capable Agents

Finally, let's create agents that can handle multimedia content:

```python
# swarm/agents.py

from .types import Agent, ContentType

def create_multimedia_agent(name: str, instructions: str, supported_types: List[ContentType]) -> Agent:
    return Agent(
        name=name,
        model="gpt-4-vision-preview",  # Assuming a model that can handle multimedia
        instructions=instructions,
        supported_content_types=supported_types
    )

# Usage
image_agent = create_multimedia_agent(
    "Image Analysis Agent",
    "You are an AI capable of analyzing images and providing detailed descriptions.",
    [ContentType.TEXT, ContentType.IMAGE]
)
```

## Hands-on Exercise

Implement a Swarm-based chatbot that can handle text, image, and audio inputs. The chatbot should be able to:
1. Respond to text queries
2. Describe images
3. Transcribe and respond to audio messages

Use the streaming feature for real-time responses and implement proper error handling and logging.

## Best Practices and Pitfalls

- When implementing streaming, ensure that the client can handle partial responses properly.
- Regularly update your model configurations as new models become available or existing ones are updated.
- Implement a circuit breaker pattern to prevent cascading failures when a model or API is consistently failing.
- Be cautious with multimedia content processing, as it can be resource-intensive. Implement proper rate limiting and caching strategies.
- Regularly analyze your conversation logs to identify areas for improvement in your agents' performance.

## Mini-Project

Develop a Swarm-based virtual assistant that can handle multimedia inputs for a social media management tool. The assistant should be able to:
1. Analyze images and suggest captions
2. Transcribe audio messages and provide summaries
3. Generate text responses for user queries
4. Provide analytics on the conversation history

Implement streaming responses, error handling, and logging for all interactions.

## Assessment

1. How does implementing streaming responses improve the user experience in a Swarm-based application?
2. Describe the process of adding support for a new AI model in the Swarm framework.
3. What are some key considerations when implementing error handling and recovery in Swarm?
4. How can conversation logging and analysis be used to improve the performance of AI agents over time?
5. Explain the challenges and benefits of adding multimedia content support to Swarm agents.

## Additional Resources

- [OpenAI Streaming API Documentation](https://platform.openai.com/docs/api-reference/streaming)
- [Best Practices for AI Error Handling](https://www.oreilly.com/content/best-practices-for-error-handling-in-ai-systems/)
- [Introduction to Multimedia Content Analysis](https://www.ibm.com/cloud/learn/multimedia-content-analysis)
- [Asyncio Documentation](https://docs.python.org/3/library/asyncio.html)
- [Pydantic Documentation](https://pydantic-docs.helpmanual.io/)

By mastering these advanced features and enhancements, you'll be able to create more sophisticated and robust AI agent systems using the Swarm framework. Remember to always test your implementations thoroughly and consider the scalability and performance implications of each feature you add.
