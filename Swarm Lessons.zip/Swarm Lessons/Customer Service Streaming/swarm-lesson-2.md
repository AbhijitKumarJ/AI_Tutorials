# Lesson 2: Core Components of the Swarm System

## Learning Objectives
By the end of this lesson, you will be able to:
1. Understand the key classes that make up the Swarm system
2. Explain the role of Agents, Tasks, and Runs in Swarm
3. Describe the purpose and functionality of different engines in Swarm
4. Recognize how tools are integrated into the Swarm system

## Key Classes in Swarm

The Swarm system is built around several core classes that work together to create a flexible and powerful AI agent orchestration framework. Let's examine these key classes:

### 1. Swarm

The `Swarm` class is the central orchestrator of the entire system. It's responsible for managing agents, executing tasks, and coordinating the overall flow of the application.

Location: `src/swarm/swarm.py`

Key features:
- Initializes with an engine name and a list of tasks
- Manages the deployment of tasks
- Handles the loading and addition of tasks

```python
class Swarm:
    def __init__(self, engine_name, tasks=[], persist=False):
        self.tasks = tasks
        self.engine_name = engine_name
        self.engine = None
        self.persist = persist

    def deploy(self, test_mode=False, test_file_paths=None):
        # Implementation for deploying tasks

    def load_tasks(self):
        # Implementation for loading tasks from a file

    def add_task(self, task):
        self.tasks.append(task)
```

### 2. Agent

The `Agent` class represents an AI agent with specific capabilities and instructions.

Location: `src/swarm/assistants.py`

Key features:
- Defines an agent's name, model, instructions, and available functions
- Manages conversation history and context
- Handles evaluation of task performance

```python
class Agent(BaseModel):
    log_flag: bool
    name: Optional[str] = None
    instance: Optional[Any] = None
    tools: Optional[list] = None
    current_task_id: str = None
    sub_assistants: Optional[list] = None
    runs: list = []
    context: Optional[dict] = {}
    planner: str = 'sequential'

    def initialize_history(self):
        # Implementation for initializing conversation history

    def add_user_message(self, message):
        # Implementation for adding a user message to history

    def add_assistant_message(self, message):
        # Implementation for adding an assistant message to history

    def evaluate(self, client, task, plan_log):
        # Implementation for evaluating task performance
```

### 3. Task

The `Task` class represents a specific task to be performed by the Swarm system.

Location: `src/tasks/task.py`

Key features:
- Defines a task's description, associated agent, and evaluation settings
- Used to structure the work to be done by the Swarm system

```python
class Task:
    def __init__(self, description, iterate=False, evaluate=False, assistant='user_interface'):
        self.id = str(uuid.uuid4())
        self.description = description
        self.assistant = assistant
        self.iterate: bool = iterate
        self.evaluate: bool = evaluate
```

### 4. Run

The `Run` class represents a single execution of a task by an agent.

Location: `src/runs/run.py`

Key features:
- Manages the execution of a task
- Handles the generation of plans for task completion

```python
class Run:
    def __init__(self,assistant,request,client):
        self.assistant = assistant
        self.request = request
        self.client = client
        self.status = None
        self.response = None

    def initiate(self, planner):
        # Implementation for initiating a run

    def generate_plan(self,task=None):
        # Implementation for generating a plan for the task
```

## Engines in Swarm

Swarm uses different engines to handle the execution of tasks. The two main engines are:

### 1. AssistantsEngine

Location: `src/swarm/engines/assistants_engine.py`

Purpose: Manages the execution of tasks using OpenAI's Assistants API.

Key features:
- Initializes and manages threads for conversations
- Handles the loading and management of assistants
- Processes tasks and manages handoffs between assistants

### 2. LocalEngine

Location: `src/swarm/engines/local_engine.py`

Purpose: Manages the execution of tasks using a local implementation of the Swarm system.

Key features:
- Handles the loading and management of tools and assistants
- Processes tasks and manages the conversation flow
- Implements caching and fallback mechanisms

## Tools in Swarm

Tools in Swarm are functions that agents can use to perform specific actions. They are defined in the `configs/tools/` directory.

Example tool structure:
```
configs/tools/query_docs/
    - handler.py
    - tool.json
```

- `handler.py`: Contains the implementation of the tool's functionality
- `tool.json`: Defines the tool's interface and parameters

Tools are integrated into the Swarm system through the `Tool` class:

Location: `src/swarm/tool.py`

```python
class Tool(BaseModel):
    type: str
    function: Optional[FunctionTool]
    human_input: Optional[bool] = False
```

## Conclusion

Understanding these core components is crucial for working with the Swarm system. The `Swarm` class orchestrates the overall process, managing `Agents` that execute `Tasks` through `Runs`. Different engines provide flexibility in how tasks are processed, and `Tools` extend the capabilities of agents.

In the next lesson, we'll explore how these components interact to create a functioning AI agent system.

## Exercise

1. Examine the `Swarm` class in `src/swarm/swarm.py`. How does it handle the deployment of tasks for different engines?

2. Look at the `Agent` class in `src/swarm/assistants.py`. How does it manage conversation history, and why is this important?

3. Compare the `AssistantsEngine` and `LocalEngine` classes. What are the main differences in how they process tasks?

4. Find a tool implementation in the `configs/tools/` directory. How is the tool defined in its `tool.json` file, and how is its functionality implemented in the `handler.py` file?

5. Create a simple `Task` object and a corresponding `Run` object. How would you use these to execute a task in the Swarm system?

