# Lesson 5: Advanced Features and Extensions in Swarm

## Learning Objectives
By the end of this lesson, you will be able to:
1. Implement advanced conversation management techniques
2. Extend the Swarm system with custom engines
3. Integrate external APIs and services into Swarm
4. Implement advanced logging and monitoring features
5. Optimize performance and scalability of the Swarm system

## Advanced Conversation Management

Swarm's conversation management can be extended to handle more complex scenarios and maintain longer-term context.

### Context Windowing

Implement a sliding window approach to maintain relevant context without exceeding token limits:

```python
class ContextWindow:
    def __init__(self, max_tokens=4000):
        self.messages = []
        self.max_tokens = max_tokens
    
    def add_message(self, message):
        self.messages.append(message)
        while self.total_tokens() > self.max_tokens:
            self.messages.pop(0)
    
    def total_tokens(self):
        return sum(len(m['content'].split()) for m in self.messages)
    
    def get_context(self):
        return self.messages

# Usage in agent
agent.context_window = ContextWindow()
agent.context_window.add_message({"role": "user", "content": user_message})
context = agent.context_window.get_context()
```

### Conversation Summarization

Implement a summarization feature to condense long conversations:

```python
from transformers import pipeline

summarizer = pipeline("summarization")

def summarize_conversation(messages, max_length=150):
    full_text = " ".join(m['content'] for m in messages)
    summary = summarizer(full_text, max_length=max_length, min_length=30, do_sample=False)
    return summary[0]['summary_text']

# Usage in agent
if len(agent.context_window.messages) > 20:
    summary = summarize_conversation(agent.context_window.messages)
    agent.context_window.messages = [{"role": "system", "content": f"Conversation summary: {summary}"}]
```

## Extending Swarm with Custom Engines

Create a custom engine to integrate specialized processing or external services:

```python
from swarm.engines.engine import Engine

class CustomEngine(Engine):
    def __init__(self, external_service):
        self.external_service = external_service
    
    def run(self, agent, messages, context_variables=None):
        # Custom logic using self.external_service
        processed_result = self.external_service.process(messages)
        return self.format_response(processed_result)
    
    def format_response(self, result):
        # Convert result to Swarm's expected format
        return Response(messages=[{"role": "assistant", "content": result}])

# Usage
external_service = ExternalNLPService()
custom_engine = CustomEngine(external_service)
swarm = Swarm(engine=custom_engine)
```

## Integrating External APIs and Services

Extend Swarm's capabilities by integrating external APIs:

```python
import requests

class WeatherService:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.weatherapi.com/v1"
    
    def get_current_weather(self, location):
        url = f"{self.base_url}/current.json?key={self.api_key}&q={location}"
        response = requests.get(url)
        data = response.json()
        return f"Current weather in {location}: {data['current']['condition']['text']}, {data['current']['temp_c']}°C"

# Add as a tool
weather_service = WeatherService(api_key="your_api_key")
weather_tool = Tool(
    type="function",
    function={
        "name": "get_current_weather",
        "description": "Get current weather for a location",
        "parameters": {
            "type": "object",
            "properties": {
                "location": {"type": "string", "description": "City name or coordinates"}
            },
            "required": ["location"]
        }
    },
    handler=weather_service.get_current_weather
)

agent.tools.append(weather_tool)
```

## Advanced Logging and Monitoring

Implement comprehensive logging and monitoring to track system performance and debug issues:

```python
import logging
from prometheus_client import Counter, Histogram

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Set up metrics
TASK_COUNTER = Counter('swarm_tasks_total', 'Total number of tasks processed')
TASK_DURATION = Histogram('swarm_task_duration_seconds', 'Task processing duration in seconds')

class MonitoredSwarm(Swarm):
    def run_task(self, task):
        TASK_COUNTER.inc()
        with TASK_DURATION.time():
            try:
                result = super().run_task(task)
                logger.info(f"Task completed: {task.id}")
                return result
            except Exception as e:
                logger.error(f"Task failed: {task.id}, Error: {str(e)}")
                raise

# Usage
swarm = MonitoredSwarm(engine_name='local')
```

This implementation adds logging for task completion and failures, and metrics for task counts and durations.

## Optimizing Performance and Scalability

To improve the performance and scalability of the Swarm system, consider the following techniques:

### Parallel Task Execution

Implement parallel task execution using Python's `concurrent.futures`:

```python
from concurrent.futures import ThreadPoolExecutor

class ParallelSwarm(Swarm):
    def __init__(self, max_workers=4, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
    
    def deploy(self, test_mode=False, test_file_paths=None):
        futures = [self.executor.submit(self.run_task, task) for task in self.tasks]
        results = [future.result() for future in futures]
        return results

# Usage
swarm = ParallelSwarm(max_workers=8, engine_name='local')
```

### Caching

Implement a caching mechanism to store and reuse frequent results:

```python
from functools import lru_cache

class CachedSwarm(Swarm):
    @lru_cache(maxsize=100)
    def get_completion(self, prompt):
        return self.client.completions.create(model="text-davinci-002", prompt=prompt)

    def run_task(self, task):
        # Use the cached get_completion method
        completion = self.get_completion(task.description)
        # Process the completion and return result
        return self.process_completion(completion)

# Usage
swarm = CachedSwarm(engine_name='local')
```

### Load Balancing

For high-load scenarios, implement a load balancing system to distribute tasks across multiple Swarm instances:

```python
import random

class LoadBalancer:
    def __init__(self, swarm_instances):
        self.instances = swarm_instances
    
    def get_instance(self):
        return random.choice(self.instances)

class DistributedSwarm:
    def __init__(self, num_instances=3):
        self.instances = [Swarm(engine_name='local') for _ in range(num_instances)]
        self.balancer = LoadBalancer(self.instances)
    
    def run_task(self, task):
        instance = self.balancer.get_instance()
        return instance.run_task(task)

# Usage
distributed_swarm = DistributedSwarm(num_instances=5)
result = distributed_swarm.run_task(task)
```

## Conclusion

These advanced features and extensions significantly enhance the capabilities, performance, and scalability of the Swarm system. By implementing conversation management techniques, custom engines, external integrations, comprehensive monitoring, and optimization strategies, you can create a robust and efficient AI agent orchestration system capable of handling complex, real-world scenarios.

## Exercise

1. Implement the `ContextWindow` class and integrate it into the existing `Agent` class. How does this change the way conversations are managed in long-running tasks?

2. Create a custom engine that uses a different language model API (e.g., Hugging Face's API). How would you integrate this into the Swarm system?

3. Implement a new tool that integrates with a public API of your choice (e.g., a translation service or a stock price API). How does this expand the capabilities of your Swarm agents?

4. Set up the monitoring system described in this lesson. Use it to track the performance of your Swarm system over a series of tasks. What insights can you gain from the collected metrics?

5. Implement the `ParallelSwarm` class and benchmark its performance against the standard `Swarm` class. Under what conditions does parallel execution provide the most benefit?
