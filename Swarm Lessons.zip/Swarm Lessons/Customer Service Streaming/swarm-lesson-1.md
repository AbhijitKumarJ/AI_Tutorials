# Lesson 1: Introduction to Swarm Project Structure

## Learning Objectives
By the end of this lesson, you will be able to:
1. Understand the overall structure of the Swarm project
2. Identify key components and their purposes
3. Navigate the project directory effectively
4. Recognize the role of different configuration files

## Project Structure Overview

The Swarm project follows a well-organized structure to manage its various components. Let's examine the main directory layout:

```
- customer_service_streaming/
    - docker-compose.yaml
    - main.py
    - prep_data.py
    - configs/
    - data/
    - logs/
    - src/
    - tests/
```

### Key Components

1. **docker-compose.yaml**: This file defines the Docker services required for the project, including the Qdrant vector database.

2. **main.py**: The entry point of the application, responsible for initializing and running the Swarm system.

3. **prep_data.py**: A script for preparing and processing data before it's used in the main application.

4. **configs/**: Contains configuration files for various aspects of the project.

5. **data/**: Stores data files used by the application, such as JSON documents.

6. **logs/**: Directory for storing log files generated during the application's execution.

7. **src/**: Contains the source code for the Swarm project.

8. **tests/**: Houses the test files and test data for the project.

## Detailed Directory Structure

Let's dive deeper into the structure of each main directory:

### configs/

```
configs/
    - general.py
    - prompts.py
    - swarm_tasks.json
    - __init__.py
    - assistants/
        - user_interface/
            - assistant.json
    - tools/
        - query_docs/
            - handler.py
            - tool.json
        - send_email/
            - handler.py
            - tool.json
        - submit_ticket/
            - handler.py
            - tool.json
```

The `configs/` directory contains various configuration files:
- `general.py`: General configuration settings
- `prompts.py`: Defines prompts used in the application
- `swarm_tasks.json`: Configuration for Swarm tasks
- `assistants/`: Configurations for different assistants
- `tools/`: Configurations and handlers for various tools used in the project

### src/

```
src/
    - arg_parser.py
    - utils.py
    - validator.py
    - __init__.py
    - evals/
        - eval_function.py
    - runs/
        - run.py
    - swarm/
        - assistants.py
        - conversation.py
        - swarm.py
        - tool.py
        - engines/
            - assistants_engine.py
            - engine.py
            - local_engine.py
    - tasks/
        - task.py
```

The `src/` directory contains the core source code:
- `arg_parser.py`: Handles command-line argument parsing
- `utils.py`: Utility functions used across the project
- `validator.py`: Validation functions for data and configurations
- `evals/`: Evaluation functions for the Swarm system
- `runs/`: Contains the `run.py` script for executing Swarm runs
- `swarm/`: Core Swarm functionality including assistants, conversations, and engines
- `tasks/`: Defines task-related functionality

### tests/

```
tests/
    - test_prompts.jsonl
    - test_runs/
        - .gitkeep
```

The `tests/` directory contains test-related files:
- `test_prompts.jsonl`: Test prompts in JSONL format
- `test_runs/`: Directory for storing test run data

## Configuration Files

Let's take a closer look at some important configuration files:

### docker-compose.yaml

```yaml
version: '3.4'
services:
  qdrant:
    image: qdrant/qdrant:v1.3.0
    restart: on-failure
    ports:
      - "6333:6333"
      - "6334:6334"
```

This file defines the Qdrant service, which is a vector database used in the project.

### configs/general.py

```python
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    GREY = '\033[90m'

test_root = 'tests'
test_file = 'test_prompts.jsonl'
tasks_path = 'configs/swarm_tasks.json'

engine_name = 'local'

max_iterations = 5

persist = False
```

This file defines color codes for console output and various configuration parameters used throughout the project.

## Conclusion

Understanding the project structure is crucial for effectively working with and contributing to the Swarm project. This lesson has provided an overview of the main directories, their contents, and key configuration files. In the next lesson, we'll dive deeper into the core components of the Swarm system and how they interact.

## Exercise

1. Clone the Swarm project repository.
2. Navigate through the directory structure and identify the locations of:
   - The main application entry point
   - Configuration files for assistants
   - The core Swarm functionality
   - Test files
3. Examine the `configs/general.py` file and explain the purpose of the `Colors` class.
4. Look at the `docker-compose.yaml` file and describe what service it sets up and which ports it uses.

