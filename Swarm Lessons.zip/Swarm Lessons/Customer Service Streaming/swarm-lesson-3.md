# Lesson 3: Configuring and Customizing Swarm

## Learning Objectives
By the end of this lesson, you will be able to:
1. Understand the configuration files used in the Swarm system
2. Customize prompts and instructions for AI agents
3. Configure and add new tools to the Swarm system
4. Modify and extend the behavior of Swarm agents
5. Understand how to set up and use different engines in Swarm

## Configuration Files

The Swarm system uses several configuration files to control its behavior. Let's examine the key configuration files and their purposes:

### 1. configs/general.py

This file contains general configuration settings for the Swarm system.

```python
class Colors:
    # Color definitions for console output

test_root = 'tests'
test_file = 'test_prompts.jsonl'
tasks_path = 'configs/swarm_tasks.json'

engine_name = 'local'

max_iterations = 5

persist = False
```

Key settings:
- `test_root` and `test_file`: Paths for test-related files
- `tasks_path`: Path to the JSON file containing task definitions
- `engine_name`: Specifies which engine to use (e.g., 'local' or 'assistants')
- `max_iterations`: Maximum number of iterations for task execution
- `persist`: Whether to persist conversation state between tasks

### 2. configs/prompts.py

This file contains definitions for various prompts used in the Swarm system.

```python
TRIAGE_MESSAGE_PROMPT = "Given the following message: {}, select which assistant of the following is best suited to handle it: {}. Respond with JUST the name of the assistant, nothing else"
TRIAGE_SYSTEM_PROMPT = "You are an assistant who triages requests and selects the best assistant to handle that request."
EVAL_GROUNDTRUTH_PROMPT = "Given the following completion: {}, and the expected completion: {}, select whether the completion and expected completion are the same in essence. Correctness does not mean they are the same verbatim, but that the ANSWER is the same. For example: 'The answer, after calculating, is 4' and '4' would be the same. But 'it is 5' and 'the answer is 12' would be different. Respond with ONLY 'true' or 'false'"
# ... more prompt definitions ...
```

These prompts are used to guide the behavior of AI agents in various scenarios, such as triaging requests, evaluating responses, and planning tasks.

### 3. configs/swarm_tasks.json

This JSON file defines the tasks that the Swarm system will execute.

```json
[
  {
    "description": "What is the square root of 16?"
  },
  {
    "description": "Is phone verification required for new OpenAI account creation or ChatGPT usage",
    "evaluate": true
  },
  {
    "description": "How many free tokens do I get when I sign up for an OpenAI account? Send an email to me@gmail.com containing that answer",
    "iterate": true,
    "evaluate": true
  }
]
```

Each task in this file can have properties like:
- `description`: The task to be performed
- `evaluate`: Whether to evaluate the task's completion
- `iterate`: Whether to allow multiple iterations of the task

## Customizing Prompts and Instructions

To customize the behavior of AI agents, you can modify the prompts in `configs/prompts.py`. For example, to change how the system triages messages, you could modify the `TRIAGE_MESSAGE_PROMPT`:

```python
TRIAGE_MESSAGE_PROMPT = "Analyze the following message: {}. Determine which of these assistants is best suited to handle it: {}. Provide only the name of the most appropriate assistant."
```

## Configuring and Adding New Tools

To add a new tool to the Swarm system:

1. Create a new directory in `configs/tools/` for your tool.
2. Create a `handler.py` file with the tool's implementation.
3. Create a `tool.json` file defining the tool's interface.

Example of a new tool `calculate`:

```
configs/tools/calculate/
    - handler.py
    - tool.json
```

In `handler.py`:
```python
def calculate(expression: str) -> float:
    return eval(expression)
```

In `tool.json`:
```json
{
  "type": "function",
  "function": {
    "name": "calculate",
    "description": "Evaluate a mathematical expression",
    "parameters": {
      "type": "object",
      "properties": {
        "expression": {
          "type": "string",
          "description": "The mathematical expression to evaluate"
        }
      },
      "required": ["expression"]
    }
  }
}
```

## Modifying and Extending Agent Behavior

To modify agent behavior, you can edit the agent definitions in `configs/assistants/`. For example, to add a new capability to the user interface assistant:

```json
[
    {
        "model": "gpt-4-0125-preview",
        "description": "You are a user interface assistant that handles all interactions with the user. You can now also perform calculations.",
        "log_flag": false,
        "tools":["query_docs", "submit_ticket", "send_email", "calculate"],
        "planner": "sequential"
    }
]
```

## Setting Up Different Engines

The Swarm system supports different engines for task execution. To use a specific engine, modify the `engine_name` in `configs/general.py`:

```python
engine_name = 'assistants'  # Use the AssistantsEngine
```

or

```python
engine_name = 'local'  # Use the LocalEngine
```

Each engine may have its own configuration requirements, which should be documented in their respective implementation files.

## Conclusion

Configuring and customizing the Swarm system allows you to tailor its behavior to your specific needs. By modifying prompts, adding new tools, and adjusting agent behaviors, you can create a powerful and flexible AI agent orchestration system.

## Exercise

1. Create a new task in `configs/swarm_tasks.json` that uses the new `calculate` tool you added earlier.

2. Modify the `TRIAGE_SYSTEM_PROMPT` in `configs/prompts.py` to give more specific instructions about how to triage requests.

3. Add a new assistant in `configs/assistants/` that specializes in mathematical operations and uses the `calculate` tool.

4. Experiment with changing the `engine_name` in `configs/general.py` and observe how it affects the system's behavior.

5. Create a new tool that fetches current weather data for a given location, and integrate it into the Swarm system.
