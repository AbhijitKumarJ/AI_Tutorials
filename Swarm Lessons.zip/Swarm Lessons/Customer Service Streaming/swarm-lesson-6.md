# Lesson 6: Testing, Debugging, and Maintaining Swarm

## Learning Objectives
By the end of this lesson, you will be able to:
1. Implement comprehensive unit tests for Swarm components
2. Perform integration testing of the Swarm system
3. Debug common issues in Swarm applications
4. Implement effective logging and error handling strategies
5. Maintain and update the Swarm system over time

## Unit Testing Swarm Components

Unit testing is crucial for ensuring the reliability of individual components in the Swarm system. Let's look at how to implement unit tests for some key components.

### Testing the Agent Class

Create a test file `tests/test_agent.py`:

```python
import unittest
from swarm.assistants import Agent

class TestAgent(unittest.TestCase):
    def setUp(self):
        self.agent = Agent(name="TestAgent", log_flag=True, instructions="Test instructions")

    def test_initialization(self):
        self.assertEqual(self.agent.name, "TestAgent")
        self.assertTrue(self.agent.log_flag)
        self.assertEqual(self.agent.instructions, "Test instructions")

    def test_add_messages(self):
        self.agent.add_user_message("Hello")
        self.agent.add_assistant_message("Hi there")
        self.assertEqual(len(self.agent.context['history']), 2)
        self.assertEqual(self.agent.context['history'][0]['role'], 'user')
        self.assertEqual(self.agent.context['history'][1]['role'], 'assistant')

    def test_evaluate(self):
        # Mock client and task for testing
        mock_client = unittest.mock.MagicMock()
        mock_task = unittest.mock.MagicMock()
        mock_plan_log = {'step': ['action1', 'action2'], 'step_output': ['output1', 'output2']}
        
        result = self.agent.evaluate(mock_client, mock_task, mock_plan_log)
        self.assertIsNotNone(result)
        # Add more assertions based on expected behavior

if __name__ == '__main__':
    unittest.main()
```

### Testing the Swarm Class

Create a test file `tests/test_swarm.py`:

```python
import unittest
from swarm.swarm import Swarm
from swarm.tasks.task import Task

class TestSwarm(unittest.TestCase):
    def setUp(self):
        self.swarm = Swarm(engine_name='local')

    def test_initialization(self):
        self.assertEqual(self.swarm.engine_name, 'local')
        self.assertIsNone(self.swarm.engine)
        self.assertFalse(self.swarm.persist)

    def test_add_task(self):
        task = Task(description="Test task")
        self.swarm.add_task(task)
        self.assertEqual(len(self.swarm.tasks), 1)
        self.assertEqual(self.swarm.tasks[0].description, "Test task")

    def test_load_tasks(self):
        # Mock the tasks file
        with unittest.mock.patch('builtins.open', unittest.mock.mock_open(read_data='[{"description": "Task 1"}, {"description": "Task 2"}]')):
            self.swarm.load_tasks()
        self.assertEqual(len(self.swarm.tasks), 2)
        self.assertEqual(self.swarm.tasks[0].description, "Task 1")
        self.assertEqual(self.swarm.tasks[1].description, "Task 2")

    def test_deploy(self):
        # Mock the engine and its deploy method
        mock_engine = unittest.mock.MagicMock()
        self.swarm.engine = mock_engine
        
        self.swarm.deploy()
        mock_engine.deploy.assert_called_once_with(False, None)

if __name__ == '__main__':
    unittest.main()
```

## Integration Testing

Integration testing ensures that different components of the Swarm system work together correctly. Create an integration test file `tests/test_integration.py`:

```python
import unittest
from swarm.swarm import Swarm
from swarm.tasks.task import Task
from swarm.assistants import Agent

class TestSwarmIntegration(unittest.TestCase):
    def setUp(self):
        self.swarm = Swarm(engine_name='local')
        self.agent = Agent(name="TestAgent", log_flag=True, instructions="Test instructions")

    def test_end_to_end_task_execution(self):
        task = Task(description="What is the capital of France?", evaluate=True)
        self.swarm.add_task(task)
        
        result = self.swarm.deploy()
        
        self.assertIsNotNone(result)
        self.assertIn("Paris", result[0].content.lower())

    def test_multi_task_execution(self):
        tasks = [
            Task(description="What is 2 + 2?"),
            Task(description="Who wrote Romeo and Juliet?")
        ]
        for task in tasks:
            self.swarm.add_task(task)
        
        results = self.swarm.deploy()
        
        self.assertEqual(len(results), 2)
        self.assertIn("4", results[0].content)
        self.assertIn("Shakespeare", results[1].content.lower())

if __name__ == '__main__':
    unittest.main()
```

## Debugging Swarm Applications

Effective debugging is crucial for maintaining and improving Swarm applications. Here are some strategies:

### Enhanced Logging

Implement detailed logging throughout the Swarm system:

```python
import logging

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class DebuggableSwarm(Swarm):
    def run_task(self, task):
        logger.debug(f"Starting task: {task.description}")
        try:
            result = super().run_task(task)
            logger.debug(f"Task completed: {task.description}")
            return result
        except Exception as e:
            logger.error(f"Error in task {task.description}: {str(e)}")
            raise

# Usage
swarm = DebuggableSwarm(engine_name='local')
```

### Debugging Decorators

Create a decorator to help with debugging specific methods:

```python
import functools
import traceback

def debug_method(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        logger.debug(f"Entering {func.__name__}")
        logger.debug(f"Args: {args}, Kwargs: {kwargs}")
        try:
            result = func(*args, **kwargs)
            logger.debug(f"Exiting {func.__name__}")
            return result
        except Exception as e:
            logger.error(f"Exception in {func.__name__}: {str(e)}")
            logger.error(traceback.format_exc())
            raise
    return wrapper

# Usage
class DebuggableAgent(Agent):
    @debug_method
    def process_message(self, message):
        # Process message logic here
        pass
```

## Error Handling Strategies

Implement robust error handling to manage exceptions gracefully:

```python
class SwarmError(Exception):
    """Base class for Swarm exceptions"""

class TaskExecutionError(SwarmError):
    """Raised when a task fails to execute"""

class AgentError(SwarmError):
    """Raised when an agent encounters an error"""

class Swarm:
    def run_task(self, task):
        try:
            # Task execution logic
            pass
        except AgentError as e:
            logger.error(f"Agent error in task {task.description}: {str(e)}")
            # Attempt recovery or use fallback strategy
        except Exception as e:
            logger.critical(f"Unexpected error in task {task.description}: {str(e)}")
            raise TaskExecutionError(f"Task failed: {str(e)}")
```

## Maintaining and Updating Swarm

To keep the Swarm system up-to-date and functioning optimally:

1. **Regular Code Reviews**: Conduct periodic code reviews to ensure quality and identify areas for improvement.

2. **Dependency Management**: Regularly update dependencies and check for security vulnerabilities:

   ```
   pip install --upgrade -r requirements.txt
   pip list --outdated
   ```

3. **Performance Monitoring**: Implement ongoing performance monitoring to identify bottlenecks or issues:

   ```python
   import time

   class MonitoredSwarm(Swarm):
       def __init__(self, *args, **kwargs):
           super().__init__(*args, **kwargs)
           self.task_times = {}

       def run_task(self, task):
           start_time = time.time()
           result = super().run_task(task)
           end_time = time.time()
           self.task_times[task.id] = end_time - start_time
           return result

       def print_performance_report(self):
           for task_id, duration in self.task_times.items():
               print(f"Task {task_id}: {duration:.2f} seconds")
   ```

4. **Documentation**: Keep documentation up-to-date, including README files, inline comments, and API documentation.

5. **Continuous Integration**: Implement a CI/CD pipeline to automate testing and deployment:

   ```yaml
   # .github/workflows/ci.yml
   name: Swarm CI

   on: [push, pull_request]

   jobs:
     test:
       runs-on: ubuntu-latest
       steps:
       - uses: actions/checkout@v2
       - name: Set up Python
         uses: actions/setup-python@v2
         with:
           python-version: '3.8'
       - name: Install dependencies
         run: |
           python -m pip install --upgrade pip
           pip install -r requirements.txt
       - name: Run tests
         run: python -m unittest discover tests
   ```

## Conclusion

Effective testing, debugging, and maintenance are crucial for the long-term success and reliability of your Swarm system. By implementing comprehensive unit tests, integration tests, robust error handling, and ongoing monitoring and maintenance strategies, you can ensure that your Swarm application remains performant, reliable, and up-to-date.

## Exercise

1. Write unit tests for the `Task` class. Include tests for task creation, iteration, and evaluation.

2. Implement a new integration test that checks the handoff between different agents in a multi-agent scenario.

3. Add the `debug_method` decorator to a key method in the `Swarm` class. Use it to debug a complex task execution.

4. Implement the `MonitoredSwarm` class and use it to run a series of tasks. Analyze the performance report. Which tasks take the longest? Can you identify any patterns?

5. Set up a basic CI pipeline using GitHub Actions for your Swarm project. Configure it to run tests automatically on each push to the repository.

