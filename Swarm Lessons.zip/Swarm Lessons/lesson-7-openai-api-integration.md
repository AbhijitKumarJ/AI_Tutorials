# Lesson 7: OpenAI API Integration

## Learning Objectives
By the end of this lesson, you will be able to:
1. Understand the basics of the OpenAI API
2. Implement proper authentication and API key management
3. Make API calls from Swarm to OpenAI
4. Handle API responses and errors effectively
5. Implement rate limiting to manage API usage

## 1. Introduction to the OpenAI API

The OpenAI API provides access to powerful language models like GPT-3 and GPT-4, allowing developers to integrate AI capabilities into their applications. In the context of Swarm, the OpenAI API is used to generate responses for agents and process tool calls.

### Key Concepts:
- **Endpoints**: Different API endpoints for various tasks (e.g., completions, chat)
- **Models**: Various AI models with different capabilities and costs
- **Tokens**: The unit of text processed by the API, affecting pricing and rate limits

## 2. Authentication and API Key Management

Proper handling of API keys is crucial for security and usage tracking.

### Best Practices:
1. **Environment Variables**: Store API keys in environment variables, not in code.
2. **Key Rotation**: Regularly rotate API keys to minimize risk if compromised.
3. **Access Control**: Use separate API keys for different environments (dev, staging, prod).

### Implementation:

```python
import os
from openai import OpenAI

# Load API key from environment variable
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise ValueError("OPENAI_API_KEY environment variable not set")

# Initialize OpenAI client
client = OpenAI(api_key=api_key)
```

## 3. Making API Calls from Swarm

Swarm uses the OpenAI API primarily through the `get_chat_completion` method in the `Swarm` class.

### Example Implementation:

```python
from swarm import Agent
from swarm.types import ChatCompletionMessage
from typing import List

class Swarm:
    def __init__(self, client=None):
        if not client:
            self.client = OpenAI()
        else:
            self.client = client

    def get_chat_completion(
        self,
        agent: Agent,
        history: List,
        context_variables: dict,
        model_override: str,
        stream: bool,
        debug: bool,
    ) -> ChatCompletionMessage:
        instructions = (
            agent.instructions(context_variables)
            if callable(agent.instructions)
            else agent.instructions
        )
        messages = [{"role": "system", "content": instructions}] + history

        tools = [function_to_json(f) for f in agent.functions]

        create_params = {
            "model": model_override or agent.model,
            "messages": messages,
            "tools": tools or None,
            "tool_choice": agent.tool_choice,
            "stream": stream,
        }

        return self.client.chat.completions.create(**create_params)
```

This method:
1. Prepares the messages, including the agent's instructions
2. Converts functions to the required JSON format
3. Sets up parameters for the API call
4. Makes the API call using the OpenAI client

## 4. Handling API Responses and Errors

Proper error handling is crucial when working with external APIs. Here's how you can handle responses and errors from the OpenAI API:

```python
from openai import OpenAI, OpenAIError
import time

def make_api_call(client: OpenAI, messages: list, max_retries: int = 3):
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model="gpt-4",
                messages=messages
            )
            return response
        except OpenAIError as e:
            if attempt == max_retries - 1:
                raise
            if e.code == 'rate_limit_exceeded':
                time.sleep(2 ** attempt)  # Exponential backoff
            else:
                raise

try:
    response = make_api_call(client, messages)
    # Process the response
    content = response.choices[0].message.content
    print(f"Response: {content}")
except OpenAIError as e:
    print(f"An error occurred: {str(e)}")
```

This implementation:
- Uses a retry mechanism with exponential backoff for rate limit errors
- Handles other OpenAI-specific errors
- Provides informative error messages

## 5. Implementing Rate Limiting

Rate limiting is important to manage API usage and avoid exceeding quotas. Here's a simple rate limiter implementation:

```python
import time
from collections import deque

class RateLimiter:
    def __init__(self, max_calls: int, time_frame: float):
        self.max_calls = max_calls
        self.time_frame = time_frame
        self.calls = deque()

    def __call__(self, func):
        def wrapper(*args, **kwargs):
            now = time.time()
            
            # Remove old calls
            while self.calls and now - self.calls[0] >= self.time_frame:
                self.calls.popleft()

            if len(self.calls) >= self.max_calls:
                sleep_time = self.time_frame - (now - self.calls[0])
                time.sleep(max(0, sleep_time))

            result = func(*args, **kwargs)
            self.calls.append(time.time())
            return result
        return wrapper

# Usage
@RateLimiter(max_calls=60, time_frame=60)  # 60 calls per minute
def make_openai_api_call(client, messages):
    return client.chat.completions.create(
        model="gpt-4",
        messages=messages
    )
```

This rate limiter:
- Keeps track of API calls within a specified time frame
- Delays execution if the rate limit is exceeded
- Can be easily applied to any function making API calls

## Hands-on Exercise: Building a Swarm Application with OpenAI API Integration

Let's create a Swarm application that demonstrates OpenAI API integration, error handling, and rate limiting.

1. Set up the project structure:

```
swarm_openai_integration/
├── main.py
├── rate_limiter.py
├── swarm_client.py
└── requirements.txt
```

2. Install the required packages:

```bash
pip install openai python-dotenv
```

3. In `rate_limiter.py`, implement the rate limiter:

```python
import time
from collections import deque

class RateLimiter:
    def __init__(self, max_calls: int, time_frame: float):
        self.max_calls = max_calls
        self.time_frame = time_frame
        self.calls = deque()

    def __call__(self, func):
        def wrapper(*args, **kwargs):
            now = time.time()
            while self.calls and now - self.calls[0] >= self.time_frame:
                self.calls.popleft()
            if len(self.calls) >= self.max_calls:
                sleep_time = self.time_frame - (now - self.calls[0])
                time.sleep(max(0, sleep_time))
            result = func(*args, **kwargs)
            self.calls.append(time.time())
            return result
        return wrapper
```

4. In `swarm_client.py`, create a custom Swarm client with error handling:

```python
from openai import OpenAI, OpenAIError
from rate_limiter import RateLimiter

class SwarmClient:
    def __init__(self, api_key):
        self.client = OpenAI(api_key=api_key)

    @RateLimiter(max_calls=60, time_frame=60)
    def get_completion(self, messages, model="gpt-4", max_retries=3):
        for attempt in range(max_retries):
            try:
                response = self.client.chat.completions.create(
                    model=model,
                    messages=messages
                )
                return response.choices[0].message.content
            except OpenAIError as e:
                if attempt == max_retries - 1:
                    raise
                if e.code == 'rate_limit_exceeded':
                    time.sleep(2 ** attempt)
                else:
                    raise

    def run_conversation(self, user_input):
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": user_input}
        ]
        try:
            return self.get_completion(messages)
        except OpenAIError as e:
            return f"An error occurred: {str(e)}"
```

5. In `main.py`, create the main application:

```python
import os
from dotenv import load_dotenv
from swarm_client import SwarmClient

# Load environment variables
load_dotenv()

# Get API key
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise ValueError("OPENAI_API_KEY environment variable not set")

# Initialize SwarmClient
swarm = SwarmClient(api_key)

# Run conversations
questions = [
    "What is the capital of France?",
    "How do you make a chocolate cake?",
    "Explain the theory of relativity",
    "What are the benefits of exercise?",
    "Who wrote the play 'Romeo and Juliet'?",
]

for question in questions:
    print(f"Question: {question}")
    response = swarm.run_conversation(question)
    print(f"Response: {response}\n")
```

This exercise demonstrates:
- Proper API key management using environment variables
- Implementation of a rate limiter
- Error handling for API calls
- A simple conversation loop using the OpenAI API

## Quiz

1. Why is it important to use environment variables for API keys?
2. What is the purpose of the `get_chat_completion` method in the Swarm class?
3. How can you implement error handling for OpenAI API calls?
4. What is the purpose of rate limiting, and how can it be implemented?
5. How does the `RateLimiter` class work in the provided example?

## Additional Resources

- [OpenAI API Documentation](https://beta.openai.com/docs/)
- [Python `dotenv` Documentation](https://github.com/theskumar/python-dotenv)
- [Best Practices for API Key Management](https://www.cloudflare.com/learning/ssl/what-is-api-key-management/)
- [Understanding Rate Limiting](https://www.nginx.com/blog/rate-limiting-nginx/)

In the next lesson, we'll explore advanced agent interactions, building on the OpenAI API integration we've established here.

