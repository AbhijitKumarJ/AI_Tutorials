# Lesson 5: Swarm's Main Components

## Learning Objectives
By the end of this lesson, you will be able to:
1. Understand the structure and purpose of the Swarm class
2. Explain the role and properties of the Agent class
3. Describe the functionality of the Response class
4. Analyze the run() method and its importance in Swarm
5. Understand the purpose and usage of the MockOpenAIClient class

## 1. The Swarm Class

The Swarm class is the core of the Swarm library, orchestrating the interaction between agents and managing the overall conversation flow.

### Structure

```python
class Swarm:
    def __init__(self, client=None):
        if not client:
            client = OpenAI()
        self.client = client

    def run(self, agent, messages, context_variables=None, ...):
        # Main execution logic

    def get_chat_completion(self, agent, history, context_variables, ...):
        # Get completion from OpenAI API

    def handle_function_result(self, result, debug):
        # Process function call results

    def handle_tool_calls(self, tool_calls, functions, context_variables, debug):
        # Execute tool calls and process results
```

### Key Methods

1. `__init__`: Initializes the Swarm instance with an OpenAI client.
2. `run`: The main method for executing a conversation with an agent.
3. `get_chat_completion`: Retrieves a chat completion from the OpenAI API.
4. `handle_function_result`: Processes the results of function calls.
5. `handle_tool_calls`: Manages the execution of tool calls and their results.

## 2. The Agent Class

The Agent class represents an AI agent with specific instructions and capabilities.

### Structure

```python
class Agent(BaseModel):
    name: str = "Agent"
    model: str = "gpt-4o"
    instructions: Union[str, Callable[[], str]] = "You are a helpful agent."
    functions: List[AgentFunction] = []
    tool_choice: str = None
    parallel_tool_calls: bool = True
```

### Properties

- `name`: The agent's identifier.
- `model`: The AI model to be used (e.g., "gpt-4o").
- `instructions`: The agent's behavior guidelines, can be a string or a callable.
- `functions`: A list of functions the agent can use.
- `tool_choice`: Specifies how the agent should choose tools (if applicable).
- `parallel_tool_calls`: Indicates if the agent can make parallel tool calls.

## 3. The Response Class

The Response class encapsulates the result of a Swarm execution.

### Structure

```python
class Response(BaseModel):
    messages: List = []
    agent: Optional[Agent] = None
    context_variables: dict = {}
```

### Properties

- `messages`: A list of messages from the conversation.
- `agent`: The last agent that handled the conversation.
- `context_variables`: A dictionary of context variables used in the conversation.

## 4. The run() Method

The `run()` method in the Swarm class is the main entry point for executing a conversation.

### Key Steps

1. Initialize the conversation with the given agent and messages.
2. Enter a loop to process messages and tool calls:
   a. Get a chat completion from the OpenAI API.
   b. Process any tool calls made by the agent.
   c. Update the conversation history and context variables.
   d. Switch agents if a handoff occurs.
3. Return a Response object with the conversation results.

### Code Snippet

```python
def run(self, agent, messages, context_variables=None, ...):
    active_agent = agent
    context_variables = copy.deepcopy(context_variables) or {}
    history = copy.deepcopy(messages)

    while True:
        completion = self.get_chat_completion(active_agent, history, ...)
        message = completion.choices[0].message
        history.append(message)

        if not message.tool_calls:
            break

        partial_response = self.handle_tool_calls(message.tool_calls, ...)
        history.extend(partial_response.messages)
        context_variables.update(partial_response.context_variables)
        if partial_response.agent:
            active_agent = partial_response.agent

    return Response(messages=history, agent=active_agent, 
                    context_variables=context_variables)
```

## 5. The MockOpenAIClient Class

The MockOpenAIClient class is used for testing purposes to simulate OpenAI API responses.

### Usage

```python
class MockOpenAIClient:
    def __init__(self):
        self.chat = MagicMock()
        self.chat.completions = MagicMock()

    def set_response(self, response: ChatCompletion):
        self.chat.completions.create.return_value = response

    def set_sequential_responses(self, responses: list[ChatCompletion]):
        self.chat.completions.create.side_effect = responses

    def assert_create_called_with(self, **kwargs):
        self.chat.completions.create.assert_called_with(**kwargs)
```

This class allows developers to:
- Set predefined responses for testing
- Configure sequential responses for multi-turn conversations
- Assert that the OpenAI API was called with specific parameters

## Hands-on Exercise: Building a Simple Swarm Application

Let's create a basic Swarm application that uses two agents: a greeting agent and a math agent.

1. First, set up the project structure:

```
swarm_demo/
├── main.py
└── requirements.txt
```

2. Install the required packages:

```bash
pip install openai pydantic
```

3. In `main.py`, implement the Swarm application:

```python
from swarm import Swarm, Agent

def greet(name):
    return f"Hello, {name}!"

def add(a: int, b: int):
    return a + b

greeting_agent = Agent(
    name="Greeting Agent",
    instructions="You are a friendly greeting agent. Use the greet function to say hello.",
    functions=[greet]
)

math_agent = Agent(
    name="Math Agent",
    instructions="You are a math agent. Use the add function to perform addition.",
    functions=[add]
)

def transfer_to_math_agent():
    return math_agent

greeting_agent.functions.append(transfer_to_math_agent)

client = Swarm()

messages = [
    {"role": "user", "content": "Hello, can you greet me?"}
]

response = client.run(agent=greeting_agent, messages=messages)
print(response.messages[-1]['content'])

messages.append({"role": "user", "content": "Can you add 5 and 3?"})
response = client.run(agent=response.agent, messages=messages)
print(response.messages[-1]['content'])
```

This example demonstrates:
- Creating and configuring agents with specific functions
- Implementing a handoff between agents
- Using the Swarm client to run conversations
- Processing and displaying responses

## Quiz

1. What is the primary purpose of the Swarm class?
2. How does the Agent class represent an AI agent's capabilities?
3. What information does the Response class contain?
4. Describe the main steps of the run() method in the Swarm class.
5. How can the MockOpenAIClient be useful in developing Swarm applications?

## Additional Resources

- [OpenAI API Documentation](https://beta.openai.com/docs/)
- [Pydantic Documentation](https://pydantic-docs.helpmanual.io/)
- [Python asyncio Documentation](https://docs.python.org/3/library/asyncio.html)

In the next lesson, we'll explore function calls and tool integration in more depth, building on the foundations we've established here.

