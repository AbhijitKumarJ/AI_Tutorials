# Lesson 14: Building a Complete Application with Swarm

## Learning Objectives
By the end of this lesson, you will be able to:
1. Design a full-fledged application using the Swarm framework
2. Integrate Swarm with a web framework (Flask)
3. Build a simple frontend for interaction with Swarm agents
4. Deploy a Swarm-based application
5. Implement real-time updates and notifications

## 1. Designing a Swarm-based Application

Let's design a customer support chatbot application using Swarm. This application will handle customer inquiries, route them to appropriate departments, and provide real-time responses.

### 1.1 Application Architecture

```
customer-support-app/
├── backend/
│   ├── app.py
│   ├── config.py
│   ├── models/
│   │   └── user.py
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── auth.py
│   │   └── chat.py
│   └── swarm/
│       ├── __init__.py
│       ├── agents.py
│       └── utils.py
├── frontend/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── requirements.txt
└── README.md
```

### 1.2 Defining Swarm Agents

Let's define our Swarm agents in `backend/swarm/agents.py`:

```python
from swarm import Agent

def transfer_to_sales():
    return sales_agent

def transfer_to_support():
    return support_agent

def transfer_to_billing():
    return billing_agent

triage_agent = Agent(
    name="Triage Agent",
    instructions="You are a triage agent. Determine the nature of the customer's inquiry and transfer to the appropriate department.",
    functions=[transfer_to_sales, transfer_to_support, transfer_to_billing]
)

sales_agent = Agent(
    name="Sales Agent",
    instructions="You are a sales agent. Help customers with product inquiries and purchases."
)

support_agent = Agent(
    name="Support Agent",
    instructions="You are a support agent. Assist customers with technical issues and product usage."
)

billing_agent = Agent(
    name="Billing Agent",
    instructions="You are a billing agent. Help customers with billing inquiries and payment issues."
)
```

## 2. Integrating Swarm with Flask

We'll use Flask as our web framework to create a REST API for our Swarm-based chatbot.

### 2.1 Setting up Flask

First, let's set up our Flask application in `backend/app.py`:

```python
from flask import Flask
from flask_cors import CORS
from routes import auth, chat

app = Flask(__name__)
CORS(app)

app.register_blueprint(auth.bp)
app.register_blueprint(chat.bp)

if __name__ == '__main__':
    app.run(debug=True)
```

### 2.2 Implementing Chat Routes

Now, let's implement our chat routes in `backend/routes/chat.py`:

```python
from flask import Blueprint, request, jsonify
from swarm import Swarm
from swarm.agents import triage_agent

bp = Blueprint('chat', __name__, url_prefix='/api/chat')
swarm = Swarm()

@bp.route('/message', methods=['POST'])
def send_message():
    data = request.json
    user_message = data.get('message')
    
    response = swarm.run(
        agent=triage_agent,
        messages=[{"role": "user", "content": user_message}]
    )
    
    return jsonify({
        "message": response.messages[-1]["content"],
        "agent": response.agent.name
    })
```

## 3. Building a Simple Frontend

Let's create a simple HTML/CSS/JavaScript frontend for our chatbot.

### 3.1 HTML Structure

In `frontend/index.html`:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Support Chatbot</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div id="chat-container">
        <div id="chat-messages"></div>
        <form id="chat-form">
            <input type="text" id="user-input" placeholder="Type your message...">
            <button type="submit">Send</button>
        </form>
    </div>
    <script src="script.js"></script>
</body>
</html>
```

### 3.2 CSS Styling

In `frontend/styles.css`:

```css
body {
    font-family: Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    background-color: #f0f0f0;
}

#chat-container {
    width: 400px;
    height: 600px;
    border: 1px solid #ccc;
    border-radius: 5px;
    display: flex;
    flex-direction: column;
    background-color: white;
}

#chat-messages {
    flex-grow: 1;
    overflow-y: auto;
    padding: 10px;
}

#chat-form {
    display: flex;
    padding: 10px;
}

#user-input {
    flex-grow: 1;
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

button {
    padding: 5px 10px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 3px;
    margin-left: 5px;
    cursor: pointer;
}
```

### 3.3 JavaScript Interaction

In `frontend/script.js`:

```javascript
const chatMessages = document.getElementById('chat-messages');
const chatForm = document.getElementById('chat-form');
const userInput = document.getElementById('user-input');

chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const message = userInput.value.trim();
    if (message) {
        addMessage('User', message);
        userInput.value = '';

        try {
            const response = await fetch('http://localhost:5000/api/chat/message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message }),
            });
            const data = await response.json();
            addMessage(data.agent, data.message);
        } catch (error) {
            console.error('Error:', error);
            addMessage('System', 'An error occurred. Please try again.');
        }
    }
});

function addMessage(sender, message) {
    const messageElement = document.createElement('div');
    messageElement.innerHTML = `<strong>${sender}:</strong> ${message}`;
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}
```

## 4. Deploying the Swarm-based Application

For this example, we'll deploy our application to Heroku.

### 4.1 Prepare for Deployment

1. Create a `Procfile` in the root directory:

```
web: gunicorn backend.app:app
```

2. Update `requirements.txt` with all necessary dependencies.

3. Ensure your `backend/config.py` uses environment variables for sensitive information:

```python
import os

OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
SECRET_KEY = os.getenv('SECRET_KEY')
```

### 4.2 Deploy to Heroku

1. Install the Heroku CLI and login.
2. Create a new Heroku app:

```
heroku create customer-support-chatbot
```

3. Set environment variables:

```
heroku config:set OPENAI_API_KEY=your_openai_api_key
heroku config:set SECRET_KEY=your_secret_key
```

4. Push your code to Heroku:

```
git push heroku main
```

5. Open your app:

```
heroku open
```

## 5. Implementing Real-time Updates and Notifications

To implement real-time updates, we'll use WebSockets with Flask-SocketIO.

### 5.1 Update Backend

1. Install Flask-SocketIO:

```
pip install flask-socketio
```

2. Update `backend/app.py`:

```python
from flask import Flask
from flask_cors import CORS
from flask_socketio import SocketIO
from routes import auth, chat

app = Flask(__name__)
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

app.register_blueprint(auth.bp)
app.register_blueprint(chat.bp)

if __name__ == '__main__':
    socketio.run(app, debug=True)
```

3. Update `backend/routes/chat.py`:

```python
from flask import Blueprint, request, jsonify
from flask_socketio import emit
from swarm import Swarm
from swarm.agents import triage_agent
from app import socketio

bp = Blueprint('chat', __name__, url_prefix='/api/chat')
swarm = Swarm()

@socketio.on('send_message')
def handle_message(data):
    user_message = data['message']
    
    response = swarm.run(
        agent=triage_agent,
        messages=[{"role": "user", "content": user_message}]
    )
    
    emit('receive_message', {
        "message": response.messages[-1]["content"],
        "agent": response.agent.name
    })
```

### 5.2 Update Frontend

Update `frontend/script.js`:

```javascript
const socket = io('http://localhost:5000');

socket.on('connect', () => {
    console.log('Connected to server');
});

socket.on('receive_message', (data) => {
    addMessage(data.agent, data.message);
});

chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const message = userInput.value.trim();
    if (message) {
        addMessage('User', message);
        socket.emit('send_message', { message });
        userInput.value = '';
    }
});

function addMessage(sender, message) {
    const messageElement = document.createElement('div');
    messageElement.innerHTML = `<strong>${sender}:</strong> ${message}`;
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}
```

## Hands-on Exercise

Extend the customer support chatbot by adding the following features:
1. Implement user authentication
2. Add a feature for users to rate their conversation
3. Implement a dashboard for admins to view chat statistics and ratings

## Best Practices and Pitfalls

- Always sanitize user input to prevent XSS attacks.
- Use environment variables for sensitive information and API keys.
- Implement proper error handling and logging.
- Consider implementing rate limiting to prevent abuse.
- Regularly update your dependencies to patch security vulnerabilities.
- Test your application thoroughly, including edge cases and error scenarios
- Use asynchronous programming techniques to handle multiple concurrent users efficiently.
- Implement proper session management to maintain user state across requests.
- Consider implementing a caching mechanism to reduce API calls and improve response times.
- Use HTTPS for all communications to ensure data security.
- Implement proper CORS (Cross-Origin Resource Sharing) settings to prevent unauthorized access.
- Consider using a Content Security Policy (CSP) to mitigate XSS and other injection attacks.
- Regularly backup your data and have a disaster recovery plan in place.

## Mini-Project

Develop a Swarm-based language learning application with the following features:

1. User authentication and profile management
2. Multiple language agents (e.g., English, Spanish, French)
3. Conversation practice with AI agents
4. Grammar and vocabulary exercises
5. Progress tracking and performance analytics
6. Real-time pronunciation feedback (using speech recognition)
7. Leaderboard and gamification elements

Implement proper error handling, logging, and security measures. Use WebSockets for real-time interactions and deploy the application to a cloud platform of your choice.

## Assessment

1. Describe the key components of a full-fledged Swarm-based application and their interactions.
2. How would you integrate Swarm with a web framework like Flask? What are the advantages and potential challenges of this integration?
3. Explain the process of building a responsive frontend for a Swarm-based chatbot application. What considerations should be taken into account for user experience?
4. What are the main steps involved in deploying a Swarm-based application to a cloud platform like Heroku? What potential issues might arise during deployment?
5. How would you implement real-time updates and notifications in a Swarm-based application? What are the benefits and potential drawbacks of using WebSockets for this purpose?

## Additional Resources

- [Flask Documentation](https://flask.palletsprojects.com/): Comprehensive guide to building web applications with Flask
- [Socket.IO Documentation](https://socket.io/docs/): Learn how to implement real-time, bidirectional communication
- [Heroku Dev Center](https://devcenter.heroku.com/): Resources for deploying and managing applications on Heroku
- [Web Security Academy](https://portswigger.net/web-security): Free, online web security training from PortSwigger
- [Real-Time Web Technologies Guide](https://www.html5rocks.com/en/tutorials/eventsource/basics/): An overview of different real-time web technologies

By completing this lesson and the associated mini-project, you'll gain practical experience in building, deploying, and maintaining a complete Swarm-based application. Remember to continuously refine your application based on user feedback and emerging best practices in AI and web development.

