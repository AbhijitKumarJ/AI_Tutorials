# Lesson 4: Deep Dive into Swarm's Core Concepts

## Learning Objectives
By the end of this lesson, you will be able to:
1. Understand and implement Agents in Swarm
2. Design and execute Routines for Swarm Agents
3. Implement and manage Handoffs between Agents
4. Utilize Context Variables in Swarm conversations
5. Comprehend the Event Loop in Swarm and its importance

## 1. Agents in Swarm

Agents are the fundamental building blocks of Swarm. They represent individual AI entities with specific roles and capabilities.

### 1.1 Agent Structure

In Swarm, an Agent is defined as a class with several key attributes:

```python
from typing import List, Callable, Union
from pydantic import BaseModel

class Agent(BaseModel):
    name: str = "Agent"
    model: str = "gpt-4o"
    instructions: Union[str, Callable[[], str]] = "You are a helpful agent."
    functions: List[Callable] = []
    tool_choice: str = None
```

Let's break down these attributes:

- `name`: A unique identifier for the agent
- `model`: The AI model to be used (e.g., "gpt-4o")
- `instructions`: The agent's role and behavior guidelines
- `functions`: A list of callable tools the agent can use
- `tool_choice`: Specifies how the agent should choose tools (if applicable)

### 1.2 Creating an Agent

Here's an example of creating a simple agent:

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"

simple_agent = Agent(
    name="Greeter",
    instructions="You are a friendly greeting agent. Use the greet function to say hello.",
    functions=[greet]
)
```

## 2. Routines in Swarm

Routines in Swarm are sequences of steps that an agent follows to accomplish a task. They are typically implemented within the agent's instructions.

### 2.1 Designing a Routine

Here's an example of a routine for a customer service agent:

```python
customer_service_agent = Agent(
    name="CS Agent",
    instructions="""
    Follow this routine for each customer interaction:
    1. Greet the customer and ask how you can help.
    2. Listen to the customer's issue.
    3. If it's a simple query, answer directly.
    4. For complex issues, use the 'escalate' function.
    5. Always thank the customer at the end of the interaction.
    """,
    functions=[greet, escalate]
)
```

### 2.2 Executing a Routine

The routine is executed implicitly as part of the agent's behavior during a conversation. The Swarm framework handles the execution based on the agent's instructions and available functions.

## 3. Handoffs between Agents

Handoffs allow one agent to transfer control of a conversation to another agent when needed.

### 3.1 Implementing Handoffs

To implement handoffs, we define transfer functions that return other agents:

```python
def transfer_to_specialist():
    return specialist_agent

general_agent = Agent(
    name="General Agent",
    instructions="Handle general queries. For technical issues, use the transfer_to_specialist function.",
    functions=[transfer_to_specialist]
)

specialist_agent = Agent(
    name="Specialist",
    instructions="Handle technical queries in detail."
)
```

### 3.2 Managing Handoffs

The Swarm framework manages handoffs automatically. When a transfer function is called, Swarm switches to the new agent:

```python
from swarm import Swarm

client = Swarm()
messages = [{"role": "user", "content": "I have a technical issue with my account."}]

response = client.run(agent=general_agent, messages=messages)
print(response.agent.name)  # Output: Specialist
```

## 4. Context Variables in Swarm

Context variables allow passing additional information to agents and functions during a conversation.

### 4.1 Using Context Variables

Context variables are passed as a dictionary to the `run` method:

```python
def personalized_greeting(context_variables, name: str) -> str:
    language = context_variables.get("language", "en")
    if language == "es":
        return f"¡Hola, {name}!"
    return f"Hello, {name}!"

greeting_agent = Agent(
    name="Greeter",
    instructions="Greet the user in their preferred language.",
    functions=[personalized_greeting]
)

context = {"language": "es"}
messages = [{"role": "user", "content": "My name is Alice."}]

response = client.run(agent=greeting_agent, messages=messages, context_variables=context)
```

### 4.2 Updating Context Variables

Functions can also update context variables by returning a `Result` object:

```python
from swarm.types import Result

def set_language(language: str) -> Result:
    return Result(value=f"Language set to {language}", context_variables={"language": language})

language_agent = Agent(
    name="Language Setter",
    instructions="Set the user's preferred language.",
    functions=[set_language]
)
```

## 5. The Event Loop in Swarm

The event loop in Swarm manages the flow of conversation, agent execution, and handoffs.

### 5.1 Understanding the Event Loop

The core of Swarm's event loop is in the `run` method of the `Swarm` class. Here's a simplified version:

```python
def run(self, agent, messages, context_variables=None, max_turns=float("inf")):
    active_agent = agent
    context_variables = context_variables or {}
    history = messages.copy()

    while len(history) - len(messages) < max_turns:
        # Get completion from the current agent
        completion = self.get_chat_completion(active_agent, history, context_variables)
        
        # Process the completion
        message = completion.choices[0].message
        history.append(message)

        if not message.tool_calls:
            break

        # Handle function calls
        for tool_call in message.tool_calls:
            result = self.handle_tool_call(tool_call, active_agent.functions, context_variables)
            
            # Update context and potentially switch agents
            context_variables.update(result.context_variables)
            if result.agent:
                active_agent = result.agent

    return Response(messages=history, agent=active_agent, context_variables=context_variables)
```

### 5.2 Key Components of the Event Loop

1. **Agent Execution**: The current agent processes the conversation history and generates a response.
2. **Tool Calls**: If the agent's response includes tool calls, they are executed.
3. **Context Updates**: Context variables are updated based on function results.
4. **Handoffs**: If a function returns a new agent, the active agent is switched.
5. **Loop Termination**: The loop continues until there are no more tool calls or the maximum number of turns is reached.

## Hands-on Exercise: Building a Multi-Agent System

Let's put these concepts together by building a simple multi-agent system for a tech support scenario.

1. Create a new file called `tech_support_system.py`:

```python
from swarm import Swarm, Agent
from swarm.types import Result

# Define our agents
def transfer_to_billing():
    return billing_agent

def transfer_to_technical():
    return technical_agent

def set_urgency(level: str) -> Result:
    return Result(value=f"Urgency set to {level}", context_variables={"urgency": level})

triage_agent = Agent(
    name="Triage Agent",
    instructions="""
    You are the initial point of contact. Determine if the issue is billing-related or technical.
    Use transfer_to_billing for billing issues and transfer_to_technical for technical issues.
    For all issues, set the urgency level using set_urgency before transferring.
    """,
    functions=[transfer_to_billing, transfer_to_technical, set_urgency]
)

billing_agent = Agent(
    name="Billing Agent",
    instructions="You handle billing-related queries. Check the urgency level in context_variables."
)

technical_agent = Agent(
    name="Technical Agent",
    instructions="You handle technical issues. Check the urgency level in context_variables."
)

# Set up the Swarm client
client = Swarm()

# Run a conversation
messages = [
    {"role": "user", "content": "I can't access my account and I have an important meeting in an hour!"}
]

response = client.run(agent=triage_agent, messages=messages)

# Print the conversation flow
for message in response.messages:
    if message['role'] == 'assistant':
        print(f"{message['sender']}: {message['content']}")
    elif message['role'] == 'user':
        print(f"User: {message['content']}")

print(f"\nFinal Agent: {response.agent.name}")
print(f"Context Variables: {response.context_variables}")
```

2. Run the script:

```bash
python tech_support_system.py
```

This exercise demonstrates the use of multiple agents, handoffs, context variables, and the overall flow of a Swarm conversation.

## Conclusion

In this lesson, we've taken a deep dive into Swarm's core concepts. We've explored the structure and implementation of Agents, the design and execution of Routines, the mechanism of Handoffs between Agents, the use of Context Variables, and the workings of the Event Loop in Swarm.

These concepts form the foundation of Swarm's powerful multi-agent orchestration capabilities. By understanding and applying these concepts, you're now equipped to create sophisticated AI agent systems that can handle complex, multi-step interactions.

In the next lesson, we'll explore Swarm's main components in even greater detail, focusing on the implementation of the Swarm class and its key methods.

## Additional Resources

- [Swarm GitHub Repository](https://github.com/openai/swarm)
- [OpenAI API Documentation](https://platform.openai.com/docs/api-reference)
- [Pydantic Documentation](https://pydantic-docs.helpmanual.io/)
- [Python Event Loop](https://docs.python.org/3/library/asyncio-eventloop.html)

