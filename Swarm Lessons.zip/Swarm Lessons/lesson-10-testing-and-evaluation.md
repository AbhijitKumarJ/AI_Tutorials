# Lesson 10: Testing and Evaluation

## Learning Objectives
By the end of this lesson, you will be able to:
1. Write unit tests for Swarm components
2. Implement integration tests for Swarm-based systems
3. Evaluate agent performance using appropriate metrics
4. Set up continuous integration and testing strategies
5. Implement conversation simulations for comprehensive testing

## 1. Writing Unit Tests for Swarm Components

Unit testing is crucial for ensuring the reliability and correctness of individual Swarm components. Let's look at how to write unit tests for agents, tools, and other Swarm elements.

### Example: Unit Testing a Tool Function

Let's write a unit test for the `search_destinations` function from our travel planner:

```python
import unittest
from tools import search_destinations

class TestTravelTools(unittest.TestCase):
    def test_search_destinations(self):
        interests = ["beach", "culture"]
        budget = 2000
        season = "summer"
        
        results = search_destinations(interests, budget, season)
        
        self.assertIsInstance(results, list)
        self.assertTrue(len(results) > 0)
        self.assertLessEqual(len(results), 3)  # Ensure we get at most 3 results
        
        for destination in results:
            self.assertIsInstance(destination, str)
            self.assertTrue(len(destination) > 0)

if __name__ == '__main__':
    unittest.main()
```

### Example: Unit Testing an Agent

To unit test an agent, we often need to mock the Swarm client and test the agent's behavior in isolation:

```python
import unittest
from unittest.mock import Mock, patch
from agents import destination_agent

class TestDestinationAgent(unittest.TestCase):
    @patch('swarm.Swarm')
    def test_destination_agent_response(self, mock_swarm):
        mock_client = Mock()
        mock_client.run.return_value.messages = [
            {'role': 'assistant', 'content': 'Based on your interests, I recommend Paris, France.'}
        ]
        mock_swarm.return_value = mock_client
        
        messages = [{'role': 'user', 'content': 'I want to visit Europe in the summer.'}]
        response = mock_client.run(agent=destination_agent, messages=messages)
        
        self.assertIn('Paris', response.messages[-1]['content'])

if __name__ == '__main__':
    unittest.main()
```

## 2. Implementing Integration Tests

Integration tests ensure that different components of your Swarm system work together correctly. These tests often involve running through entire conversation flows.

### Example: Integration Test for Travel Planner

```python
import unittest
from swarm import Swarm
from agents import destination_agent, flight_agent, accommodation_agent, weather_agent

class TestTravelPlannerIntegration(unittest.TestCase):
    def setUp(self):
        self.client = Swarm()
    
    def test_full_travel_planning_flow(self):
        user_query = """
        I'm interested in a beach vacation with some cultural experiences.
        My budget is $2000, and I'd like to travel in the summer.
        I'll be departing from New York City.
        """
        
        messages = [{"role": "user", "content": user_query}]
        current_agent = destination_agent
        
        # Test Destination Recommendation
        response = self.client.run(agent=current_agent, messages=messages)
        self.assertIn("recommend", response.messages[-1]['content'].lower())
        
        # Test Flight Search
        current_agent = flight_agent
        messages.append({"role": "user", "content": "Find flights to the recommended destination."})
        response = self.client.run(agent=current_agent, messages=messages)
        self.assertIn("flight", response.messages[-1]['content'].lower())
        
        # Test Accommodation Search
        current_agent = accommodation_agent
        messages.append({"role": "user", "content": "Find accommodations at the destination."})
        response = self.client.run(agent=current_agent, messages=messages)
        self.assertIn("hotel", response.messages[-1]['content'].lower())
        
        # Test Weather Forecast
        current_agent = weather_agent
        messages.append({"role": "user", "content": "What's the weather like at the destination?"})
        response = self.client.run(agent=current_agent, messages=messages)
        self.assertIn("weather", response.messages[-1]['content'].lower())

if __name__ == '__main__':
    unittest.main()
```

## 3. Evaluating Agent Performance

Evaluating the performance of AI agents can be challenging due to the subjective nature of many tasks. However, we can use a combination of quantitative and qualitative metrics.

### Quantitative Metrics:
- Response time
- Number of turns to task completion
- Task success rate
- Adherence to specified formats or constraints

### Qualitative Metrics:
- Relevance of responses
- Coherence and fluency of language
- Appropriateness of tone and style
- User satisfaction ratings

### Example: Evaluation Script

```python
import time
from swarm import Swarm
from agents import destination_agent

def evaluate_agent_performance(agent, test_cases):
    client = Swarm()
    results = []
    
    for case in test_cases:
        start_time = time.time()
        response = client.run(agent=agent, messages=[{"role": "user", "content": case['input']}])
        end_time = time.time()
        
        result = {
            "input": case['input'],
            "output": response.messages[-1]['content'],
            "response_time": end_time - start_time,
            "num_turns": len(response.messages) // 2,  # Assuming alternating user/assistant messages
            "success": any(keyword in response.messages[-1]['content'].lower() for keyword in case['keywords'])
        }
        results.append(result)
    
    return results

test_cases = [
    {"input": "I want a beach vacation in Europe", "keywords": ["beach", "europe"]},
    {"input": "Cultural trip to Asia on a budget", "keywords": ["asia", "cultural", "budget"]},
    {"input": "Adventure holiday in South America", "keywords": ["adventure", "south america"]}
]

evaluation_results = evaluate_agent_performance(destination_agent, test_cases)

# Analyze results
success_rate = sum(result['success'] for result in evaluation_results) / len(evaluation_results)
avg_response_time = sum(result['response_time'] for result in evaluation_results) / len(evaluation_results)
avg_turns = sum(result['num_turns'] for result in evaluation_results) / len(evaluation_results)

print(f"Success Rate: {success_rate:.2f}")
print(f"Average Response Time: {avg_response_time:.2f} seconds")
print(f"Average Number of Turns: {avg_turns:.2f}")
```

## 4. Continuous Integration and Testing Strategies

Implementing continuous integration (CI) ensures that your Swarm system remains stable as you make changes. Here's an example of how to set up CI using GitHub Actions:

1. Create a `.github/workflows/ci.yml` file in your repository:

```yaml
name: Swarm CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: 3.8
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Run unit tests
      run: python -m unittest discover tests
    - name: Run integration tests
      run: python integration_tests.py
    - name: Run performance evaluation
      run: python evaluate_performance.py
```

2. Organize your tests:
   - Put unit tests in a `tests/` directory
   - Create an `integration_tests.py` file for integration tests
   - Create an `evaluate_performance.py` file for performance evaluation

3. Run tests locally before pushing:
   ```
   python -m unittest discover tests
   python integration_tests.py
   python evaluate_performance.py
   ```

4. Set up notifications for CI failures:
   - Configure GitHub to send notifications when CI fails
   - Integrate with Slack or other team communication tools for immediate alerts

## 5. Implementing Conversation Simulations

Conversation simulations allow you to test your Swarm system with a variety of user inputs and scenarios. This is particularly useful for identifying edge cases and improving overall robustness.

### Example: Conversation Simulator

```python
import random
from swarm import Swarm
from agents import destination_agent, flight_agent, accommodation_agent, weather_agent

class ConversationSimulator:
    def __init__(self):
        self.client = Swarm()
        self.agents = {
            "destination": destination_agent,
            "flight": flight_agent,
            "accommodation": accommodation_agent,
            "weather": weather_agent
        }
        self.scenarios = [
            "I want a beach vacation in {destination} with a budget of ${budget}.",
            "Looking for a cultural trip to {destination} in {season}.",
            "Planning an adventure holiday in {destination} for {duration} days.",
            "Need a relaxing getaway in {destination} with good weather.",
            "Seeking a budget-friendly trip to {destination} for a family of {people}."
        ]
        self.destinations = ["Europe", "Asia", "South America", "Africa", "Australia"]
        self.budgets = [1000, 2000, 3000, 5000]
        self.seasons = ["summer", "winter", "spring", "fall"]
        self.durations = [3, 5, 7, 10, 14]
        self.people = [2, 3, 4, 5]

    def generate_scenario(self):
        scenario = random.choice(self.scenarios)
        return scenario.format(
            destination=random.choice(self.destinations),
            budget=random.choice(self.budgets),
            season=random.choice(self.seasons),
            duration=random.choice(self.durations),
            people=random.choice(self.people)
        )

    def run_simulation(self, num_conversations=10):
        for i in range(num_conversations):
            print(f"\nSimulation {i+1}")
            scenario = self.generate_scenario()
            print(f"User: {scenario}")
            
            messages = [{"role": "user", "content": scenario}]
            current_agent = self.agents["destination"]
            
            while True:
                response = self.client.run(agent=current_agent, messages=messages)
                print(f"{current_agent.name}: {response.messages[-1]['content']}")
                
                if "Transferring to" in response.messages[-1]['content']:
                    next_agent = response.messages[-1]['content'].split("Transferring to ")[-1]
                    current_agent = self.agents.get(next_agent.lower().split()[0], current_agent)
                    messages.append({"role": "user", "content": "Please continue with the next step of my travel planning."})
                else:
                    break
            
            print("Simulation completed.")

# Run the simulation
simulator = ConversationSimulator()
simulator.run_simulation(num_conversations=5)
```

This conversation simulator:
- Generates random travel scenarios
- Runs through the entire travel planning process for each scenario
- Simulates user interactions and agent responses
- Helps identify potential issues in the conversation flow

## Hands-on Exercise: Comprehensive Testing Suite for Travel Planner

Let's create a comprehensive testing suite for our travel planner system, incorporating unit tests, integration tests, performance evaluation, and conversation simulations.

1. Set up the project structure:

```
travel_planner_tests/
├── tests/
│   ├── __init__.py
│   ├── test_tools.py
│   ├── test_agents.py
│   └── test_swarm.py
├── integration_tests.py
├── performance_eval.py
├── conversation_simulator.py
├── main.py
└── requirements.txt
```

2. In `tests/test_tools.py`, write unit tests for tool functions:

```python
import unittest
from tools import search_destinations, find_flights, suggest_accommodations, get_weather_forecast

class TestTravelTools(unittest.TestCase):
    def test_search_destinations(self):
        results = search_destinations(["beach", "culture"], 2000, "summer")
        self.assertIsInstance(results, list)
        self.assertTrue(0 < len(results) <= 3)

    def test_find_flights(self):
        flight = find_flights("New York", "Paris", "2023-07-01")
        self.assertIn("airline", flight)
        self.assertIn("price", flight)

    def test_suggest_accommodations(self):
        accommodations = suggest_accommodations("Paris", "2023-07-01", "2023-07-07", 1000)
        self.assertIsInstance(accommodations, list)
        self.assertTrue(len(accommodations) > 0)

    def test_get_weather_forecast(self):
        forecast = get_weather_forecast("Paris", "2023-07-01")
        self.assertIsInstance(forecast, str)
        self.assertTrue(len(forecast) > 0)

if __name__ == '__main__':
    unittest.main()
```

3. In `tests/test_agents.py`, write unit tests for agents:

```python
import unittest
from unittest.mock import Mock, patch
from agents import destination_agent, flight_agent, accommodation_agent, weather_agent

class TestTravelAgents(unittest.TestCase):
    @patch('swarm.Swarm')
    def test_destination_agent(self, mock_swarm):
        mock_client = Mock()
        mock_client.run.return_value.messages = [
            {'role': 'assistant', 'content': 'I recommend Paris, France.'}
        ]
        mock_swarm.return_value = mock_client
        
        messages = [{'role': 'user', 'content': 'I want to visit Europe in the summer.'}]
        response = mock_client.run(agent=destination_agent, messages=messages)
        
        self.assertIn('Paris', response.messages[-1]['content'])

    # Add similar tests for other agents

if __name__ == '__main__':
    unittest.main()
```

4. In `integration_tests.py`, implement integration tests:

```python
import unittest
from swarm import Swarm
from agents import destination_agent, flight_agent, accommodation_agent, weather_agent

class TestTravelPlannerIntegration(unittest.TestCase):
    def setUp(self):
        self.client = Swarm()
    
    def test_full_travel_planning_flow(self):
        user_query = "I want a beach vacation in Europe with a budget of $2000 in the summer."
        messages = [{"role": "user", "content": user_query}]
        
        # Test Destination Recommendation
        response = self.client.run(agent=destination_agent, messages=messages)
        self.assertIn("recommend", response.messages[-1]['content'].lower())
        
        # Test Flight Search
        messages.append({"role": "user", "content": "Find flights to the recommended destination."})
        response = self.client.run(agent=flight_agent, messages=messages)
        self.assertIn("flight", response.messages[-1]['content'].lower())
        
        # Test Accommodation Search
        messages.append({"role": "user", "content": "Find accommodations at the destination."})
        response = self.client.run(agent=accommodation_agent, messages=messages)
        self.assertIn("hotel", response.messages[-1]['content'].lower())
        
        # Test Weather Forecast
        messages.append({"role": "user", "content": "What's the weather like at the destination?"})
        response = self.client.run(agent=weather_agent, messages=messages)
        self.assertIn("weather", response.messages[-1]['content'].lower())

if __name__ == '__main__':
    unittest.main()
```

5. In `performance_eval.py`, create a performance evaluation script:

```python
import time
from swarm import Swarm
from agents import destination_agent, flight_agent, accommodation_agent, weather_agent

def evaluate_agent_performance(agent, test_cases):
    client = Swarm()
    results = []
    
    for case in test_cases:
        start_time = time.time()
        response = client.run(agent=agent, messages=[{"role": "user", "content": case['input']}])
        end_time = time.time()
        
        result = {
            "input": case['input'],
            "output": response.messages[-1]['content'],
            "response_time": end_time - start_time,
            "num_turns": len(response.messages) // 2,
            "success": any(keyword in response.messages[-1]['content'].lower() for keyword in case['keywords'])
        }
        results.append(result)
    
    return results

def run_performance_evaluation():
    test_cases = [
        {"input": "I want a beach vacation in Europe", "keywords": ["beach", "europe"]},
        {"input": "Cultural trip to Asia on a budget", "keywords": ["asia", "cultural", "budget"]},
        {"input": "Adventure holiday in South America", "keywords": ["adventure", "south america"]}
    ]

    agents = [destination_agent, flight_agent, accommodation_agent, weather_agent]
    
    for agent in agents:
        print(f"\nEvaluating {agent.name}")
        results = evaluate_agent_performance(agent, test_cases)
        
        success_rate = sum(result['success'] for result in results) / len(results)
        avg_response_time = sum(result['response_time'] for result in results) / len(results)
        avg_turns = sum(result['num_turns'] for result in results) / len(results)
        
        print(f"Success Rate: {success_rate:.2f}")
        print(f"Average Response Time: {avg_response_time:.2f} seconds")
        print(f"Average Number of Turns: {avg_turns:.2f}")

if __name__ == '__main__':
    run_performance_evaluation()
```

6. In `conversation_simulator.py`, implement the conversation simulator:

```python
import random
from swarm import Swarm
from agents import destination_agent, flight_agent, accommodation_agent, weather_agent

class ConversationSimulator:
    def __init__(self):
        self.client = Swarm()
        self.agents = {
            "destination": destination_agent,
            "flight": flight_agent,
            "accommodation": accommodation_agent,
            "weather": weather_agent
        }
        self.scenarios = [
            "I want a beach vacation in {destination} with a budget of ${budget}.",
            "Looking for a cultural trip to {destination} in {season}.",
            "Planning an adventure holiday in {destination} for {duration} days.",
            "Need a relaxing getaway in {destination} with good weather.",
            "Seeking a budget-friendly trip to {destination} for a family of {people}."
        ]
        self.destinations = ["Europe", "Asia", "South America", "Africa", "Australia"]
        self.budgets = [1000, 2000, 3000, 5000]
        self.seasons = ["summer", "winter", "spring", "fall"]
        self.durations = [3, 5, 7, 10, 14]
        self.people = [2, 3, 4, 5]

    def generate_scenario(self):
        scenario = random.choice(self.scenarios)
        return scenario.format(
            destination=random.choice(self.destinations),
            budget=random.choice(self.budgets),
            season=random.choice(self.seasons),
            duration=random.choice(self.durations),
            people=random.choice(self.people)
        )

    def run_simulation(self, num_conversations=10):
        for i in range(num_conversations):
            print(f"\nSimulation {i+1}")
            scenario = self.generate_scenario()
            print(f"User: {scenario}")
            
            messages = [{"role": "user", "content": scenario}]
            current_agent = self.agents["destination"]
            
            while True:
                response = self.client.run(agent=current_agent, messages=messages)
                print(f"{current_agent.name}: {response.messages[-1]['content']}")
                
                if "Transferring to" in response.messages[-1]['content']:
                    next_agent = response.messages[-1]['content'].split("Transferring to ")[-1]
                    current_agent = self.agents.get(next_agent.lower().split()[0], current_agent)
                    messages.append({"role": "user", "content": "Please continue with the next step of my travel planning."})
                else:
                    break
            
            print("Simulation completed.")

if __name__ == '__main__':
    simulator = ConversationSimulator()
    simulator.run_simulation(num_conversations=5)
```

7. In `main.py`, create a script to run all tests and evaluations:

```python
import unittest
import subprocess

def run_unit_tests():
    print("Running Unit Tests...")
    unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.discover('tests'))

def run_integration_tests():
    print("\nRunning Integration Tests...")
    subprocess.run(["python", "integration_tests.py"])

def run_performance_evaluation():
    print("\nRunning Performance Evaluation...")
    subprocess.run(["python", "performance_eval.py"])

def run_conversation_simulation():
    print("\nRunning Conversation Simulation...")
    subprocess.run(["python", "conversation_simulator.py"])

if __name__ == '__main__':
    run_unit_tests()
    run_integration_tests()
    run_performance_evaluation()
    run_conversation_simulation()
```

To run the comprehensive testing suite:

1. Install the required packages:
   ```
   pip install -r requirements.txt
   ```

2. Run the main script:
   ```
   python main.py
   ```

This will execute all unit tests, integration tests, performance evaluations, and conversation simulations, providing a comprehensive assessment of your travel planner system.

## Quiz

1. What are the key components of a comprehensive testing strategy for a Swarm-based system?
2. How do unit tests differ from integration tests in the context of Swarm?
3. What metrics can be used to evaluate the performance of AI agents in a Swarm system?
4. How does continuous integration benefit the development process of a Swarm-based application?
5. What is the purpose of implementing conversation simulations, and how do they complement other testing methods?

## Additional Resources

- [Python unittest Documentation](https://docs.python.org/3/library/unittest.html)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Best Practices for AI Testing](https://www.infoq.com/articles/testing-ai-systems/)
- [Evaluating Conversational AI](https://www.aclweb.org/anthology/2020.acl-main.647.pdf)

In the next lesson, we'll explore scaling and optimization techniques for Swarm-based systems, building on the testing and evaluation strategies we've learned here.

