# Lesson 3: Python Fundamentals for Swarm

## Learning Objectives
By the end of this lesson, you will be able to:
1. Define and use functions and classes in Python
2. Work with JSON data in Python
3. Implement error handling and debugging techniques
4. Use type hinting for improved code readability and maintainability
5. Understand the basics of asynchronous programming with Python's asyncio

## 1. Functions and Classes in Python

### 1.1 Functions

Functions in Python are defined using the `def` keyword. They are crucial in Swarm for defining agent behaviors and tools.

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"

print(greet("Alice"))  # Output: Hello, Alice!
```

#### Lambda Functions
Lambda functions are small, anonymous functions useful for simple operations.

```python
square = lambda x: x ** 2
print(square(4))  # Output: 16
```

### 1.2 Classes

Classes in Python are used to create objects that bundle data and functionality. In Swarm, classes like `Agent` and `Swarm` are fundamental.

```python
class Agent:
    def __init__(self, name: str, instructions: str):
        self.name = name
        self.instructions = instructions
    
    def introduce(self) -> str:
        return f"I am {self.name}, and my instructions are: {self.instructions}"

agent = Agent("Helper", "Assist users with their queries")
print(agent.introduce())
```

#### Inheritance
Inheritance allows creating new classes based on existing ones.

```python
class SpecializedAgent(Agent):
    def __init__(self, name: str, instructions: str, specialty: str):
        super().__init__(name, instructions)
        self.specialty = specialty
    
    def introduce(self) -> str:
        return f"{super().introduce()} My specialty is {self.specialty}."

special_agent = SpecializedAgent("Expert", "Provide expert advice", "Python")
print(special_agent.introduce())
```

## 2. Working with JSON in Python

JSON (JavaScript Object Notation) is widely used for data interchange. In Swarm, it's used for communication with the OpenAI API.

### 2.1 JSON Basics

```python
import json

# Converting Python object to JSON string
data = {
    "name": "Alice",
    "age": 30,
    "city": "New York"
}
json_string = json.dumps(data)
print(json_string)

# Converting JSON string to Python object
parsed_data = json.loads(json_string)
print(parsed_data["name"])  # Output: Alice
```

### 2.2 Reading and Writing JSON Files

```python
# Writing JSON to a file
with open("data.json", "w") as f:
    json.dump(data, f)

# Reading JSON from a file
with open("data.json", "r") as f:
    loaded_data = json.load(f)
```

### 2.3 JSON in Swarm

In Swarm, JSON is often used to format messages and function arguments:

```python
def execute_tool_call(tool_call, tools_map):
    name = tool_call.function.name
    args = json.loads(tool_call.function.arguments)
    return tools_map[name](**args)
```

## 3. Error Handling and Debugging Techniques

Proper error handling is crucial for building robust applications.

### 3.1 Try-Except Blocks

```python
try:
    result = 10 / 0
except ZeroDivisionError:
    print("Cannot divide by zero!")
except Exception as e:
    print(f"An error occurred: {e}")
else:
    print("Operation successful!")
finally:
    print("This always runs")
```

### 3.2 Raising Exceptions

```python
def divide(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b
```

### 3.3 Debugging with pdb

Python's built-in debugger, pdb, is a powerful tool for troubleshooting:

```python
import pdb

def complex_function(x, y):
    result = x + y
    pdb.set_trace()  # Debugger will pause here
    return result * 2

complex_function(3, 4)
```

When the debugger pauses, you can:
- Use `n` to go to the next line
- Use `c` to continue execution
- Use `p variable_name` to print a variable's value

### 3.4 Logging

Logging is crucial for tracking the flow of your application:

```python
import logging

logging.basicConfig(level=logging.DEBUG)

def some_function():
    logging.debug("This is a debug message")
    logging.info("This is an info message")
    logging.warning("This is a warning message")

some_function()
```

## 4. Type Hinting

Type hinting improves code readability and helps catch type-related errors early.

### 4.1 Basic Type Hinting

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"

def calculate_age(birth_year: int, current_year: int) -> int:
    return current_year - birth_year
```

### 4.2 Type Hinting with Collections

```python
from typing import List, Dict

def process_names(names: List[str]) -> Dict[str, int]:
    return {name: len(name) for name in names}
```

### 4.3 Type Hinting in Swarm

In Swarm, type hinting is used extensively to clarify function signatures:

```python
from typing import List, Optional
from pydantic import BaseModel

class Agent(BaseModel):
    name: str
    model: str = "gpt-4o-mini"
    instructions: str = "You are a helpful Agent"
    functions: List[Callable] = []

def run_full_turn(
    agent: Agent,
    messages: List[Dict[str, str]],
    context_variables: Optional[Dict[str, Any]] = None
) -> Response:
    # Implementation...
```

## 5. Asynchronous Programming with asyncio

Asyncio allows writing concurrent code using the async/await syntax.

### 5.1 Basic asyncio Usage

```python
import asyncio

async def say_after(delay, what):
    await asyncio.sleep(delay)
    print(what)

async def main():
    print("started at", asyncio.get_event_loop().time())
    await say_after(1, 'hello')
    await say_after(2, 'world')
    print("finished at", asyncio.get_event_loop().time())

asyncio.run(main())
```

### 5.2 Concurrent Tasks

```python
async def main():
    task1 = asyncio.create_task(say_after(1, 'hello'))
    task2 = asyncio.create_task(say_after(2, 'world'))

    print("started at", asyncio.get_event_loop().time())
    await task1
    await task2
    print("finished at", asyncio.get_event_loop().time())

asyncio.run(main())
```

### 5.3 Asyncio in Swarm

While the current version of Swarm doesn't use asyncio, understanding it can be beneficial for future extensions or custom implementations:

```python
import asyncio
from swarm import Swarm, Agent

async def run_swarm_async(agent: Agent, messages: List[Dict[str, str]]):
    client = Swarm()
    response = await asyncio.to_thread(client.run, agent=agent, messages=messages)
    return response

async def main():
    agent = Agent(name="AsyncAgent", instructions="Handle async tasks")
    messages = [{"role": "user", "content": "Hello, async world!"}]
    response = await run_swarm_async(agent, messages)
    print(response.messages[-1]["content"])

asyncio.run(main())
```

## Hands-on Exercise: Building a Simple Swarm Agent

Let's put these concepts together by building a simple Swarm agent that can perform basic mathematical operations.

1. Create a new file called `math_agent.py`:

```python
import json
from typing import Dict, List, Union
from swarm import Swarm, Agent

def add(a: float, b: float) -> float:
    return a + b

def subtract(a: float, b: float) -> float:
    return a - b

def multiply(a: float, b: float) -> float:
    return a * b

def divide(a: float, b: float) -> Union[float, str]:
    try:
        return a / b
    except ZeroDivisionError:
        return "Error: Division by zero"

math_agent = Agent(
    name="Math Agent",
    instructions="You are a helpful math assistant. Use the provided functions to perform calculations.",
    functions=[add, subtract, multiply, divide]
)

def run_math_agent():
    client = Swarm()
    messages: List[Dict[str, str]] = [
        {"role": "user", "content": "What is 5 plus 3?"}
    ]
    
    try:
        response = client.run(agent=math_agent, messages=messages)
        print(json.dumps(response.messages, indent=2))
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    run_math_agent()
```

2. Run the script:

```bash
python math_agent.py
```

3. Experiment by changing the user message to test different operations.

This exercise demonstrates the use of functions, error handling, type hinting, and basic Swarm concepts.

## Conclusion

In this lesson, we've covered essential Python fundamentals crucial for Swarm development. We explored functions and classes, JSON handling, error management and debugging, type hinting, and an introduction to asynchronous programming. These concepts form the backbone of effective Swarm development and will be instrumental in your journey to becoming an AI agent expert.

In the next lesson, we'll dive deeper into Swarm's core concepts, building upon the Python fundamentals we've learned here.

## Additional Resources

- [Python Official Documentation](https://docs.python.org/3/)
- [Real Python - Python Type Checking](https://realpython.com/python-type-checking/)
- [Asyncio Documentation](https://docs.python.org/3/library/asyncio.html)
- [JSON in Python](https://docs.python.org/3/library/json.html)
- [Python Debugging Techniques](https://realpython.com/python-debugging-pdb/)

