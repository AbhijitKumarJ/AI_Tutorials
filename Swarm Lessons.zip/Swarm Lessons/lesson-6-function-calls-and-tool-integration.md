# Lesson 6: Function Calls and Tool Integration

## Learning Objectives
By the end of this lesson, you will be able to:
1. Understand how Swarm integrates external tools
2. Implement the function_to_json conversion process
3. Create and use custom tools in Swarm
4. Apply best practices for tool development
5. Handle tool errors and edge cases effectively

## 1. How Swarm Integrates External Tools

Swarm integrates external tools by allowing agents to call functions that can perform various tasks. These functions are converted into a format that can be understood by the language model, enabling seamless interaction between the AI and external tools.

### Key Components:
- `function_to_json`: Converts Python functions to JSON schemas
- `execute_tool_call`: Executes the tool calls made by the agent
- `handle_tool_calls`: Manages multiple tool calls and their results

## 2. Understanding function_to_json Conversion

The `function_to_json` function is crucial for converting Python functions into a format that can be used by the language model.

### Implementation:

```python
import inspect

def function_to_json(func) -> dict:
    type_map = {
        str: "string",
        int: "integer",
        float: "number",
        bool: "boolean",
        list: "array",
        dict: "object",
        type(None): "null",
    }

    signature = inspect.signature(func)
    parameters = {}
    for param in signature.parameters.values():
        param_type = type_map.get(param.annotation, "string")
        parameters[param.name] = {"type": param_type}

    required = [
        param.name
        for param in signature.parameters.values()
        if param.default == inspect._empty
    ]

    return {
        "type": "function",
        "function": {
            "name": func.__name__,
            "description": (func.__doc__ or "").strip(),
            "parameters": {
                "type": "object",
                "properties": parameters,
                "required": required,
            },
        },
    }
```

This function:
1. Maps Python types to JSON schema types
2. Extracts function signature and parameters
3. Determines required parameters
4. Creates a JSON schema representation of the function

## 3. Implementing and Using Custom Tools

Custom tools in Swarm are simply Python functions that can be called by agents. Here's how to create and use them:

### Creating a Custom Tool:

```python
def weather_lookup(city: str, country: str) -> str:
    """Look up the current weather for a given city and country."""
    # In a real implementation, this would make an API call
    return f"The weather in {city}, {country} is sunny and 22°C."

def currency_convert(amount: float, from_currency: str, to_currency: str) -> float:
    """Convert an amount from one currency to another."""
    # In a real implementation, this would use current exchange rates
    conversion_rate = 1.2  # Example rate
    return amount * conversion_rate
```

### Using Custom Tools with an Agent:

```python
from swarm import Agent, Swarm

weather_agent = Agent(
    name="Weather Agent",
    instructions="You are a weather information agent. Use the weather_lookup function to provide weather information.",
    functions=[weather_lookup]
)

finance_agent = Agent(
    name="Finance Agent",
    instructions="You are a financial assistant. Use the currency_convert function to help with currency conversions.",
    functions=[currency_convert]
)

client = Swarm()

# Example usage
messages = [{"role": "user", "content": "What's the weather like in Paris, France?"}]
response = client.run(agent=weather_agent, messages=messages)
print(response.messages[-1]['content'])

messages = [{"role": "user", "content": "Convert 100 USD to EUR"}]
response = client.run(agent=finance_agent, messages=messages)
print(response.messages[-1]['content'])
```

## 4. Best Practices for Tool Development

When developing tools for Swarm, follow these best practices:

1. **Clear Documentation**: Provide clear docstrings for your functions, explaining their purpose, parameters, and return values.

2. **Type Hinting**: Use Python type hints to specify parameter and return types. This improves code readability and helps with function_to_json conversion.

3. **Error Handling**: Implement proper error handling within your tools to gracefully manage unexpected inputs or API failures.

4. **Modularity**: Keep tools focused on specific tasks. If a tool becomes complex, consider breaking it into smaller, more manageable functions.

5. **Testing**: Write unit tests for your tools to ensure they behave correctly under various conditions.

6. **Performance**: For tools that may be called frequently, optimize for performance. Consider caching results where appropriate.

7. **Security**: Be cautious when working with sensitive data. Never expose API keys or confidential information in tool outputs.

## 5. Handling Tool Errors and Edge Cases

Proper error handling is crucial for robust tool integration. Here's an example of how to implement error handling in a custom tool:

```python
import requests

def weather_lookup(city: str, country: str) -> str:
    """Look up the current weather for a given city and country."""
    try:
        # Make API call to weather service
        api_key = "your_api_key_here"
        url = f"https://api.weatherservice.com/data/2.5/weather?q={city},{country}&appid={api_key}"
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for bad responses
        
        data = response.json()
        temperature = data['main']['temp']
        description = data['weather'][0]['description']
        
        return f"The weather in {city}, {country} is {description} with a temperature of {temperature}°C."
    except requests.RequestException as e:
        return f"Error fetching weather data: {str(e)}"
    except (KeyError, IndexError) as e:
        return f"Error parsing weather data: {str(e)}"
    except Exception as e:
        return f"An unexpected error occurred: {str(e)}"
```

This implementation:
- Uses a try-except block to catch different types of errors
- Provides informative error messages for different scenarios
- Ensures that the function always returns a string, even in error cases

## Hands-on Exercise: Building a Multi-tool Agent

Let's create a Swarm application that uses multiple tools and handles potential errors.

1. Set up the project structure:

```
swarm_multi_tool/
├── main.py
├── tools.py
└── requirements.txt
```

2. Install the required packages:

```bash
pip install openai pydantic requests
```

3. In `tools.py`, implement the custom tools:

```python
import requests
from typing import Optional

def weather_lookup(city: str, country: str) -> str:
    """Look up the current weather for a given city and country."""
    try:
        # Simulating API call
        if city.lower() == "error":
            raise Exception("Simulated API error")
        return f"The weather in {city}, {country} is sunny and 22°C."
    except Exception as e:
        return f"Error fetching weather data: {str(e)}"

def currency_convert(amount: float, from_currency: str, to_currency: str) -> str:
    """Convert an amount from one currency to another."""
    try:
        # Simulating conversion
        if amount < 0:
            raise ValueError("Amount must be positive")
        conversion_rate = 1.2
        converted_amount = amount * conversion_rate
        return f"{amount} {from_currency} is equal to {converted_amount:.2f} {to_currency}"
    except Exception as e:
        return f"Error converting currency: {str(e)}"

def get_random_fact() -> str:
    """Fetch a random fact from an API."""
    try:
        response = requests.get("https://uselessfacts.jsph.pl/random.json?language=en")
        response.raise_for_status()
        data = response.json()
        return data['text']
    except requests.RequestException as e:
        return f"Error fetching random fact: {str(e)}"
    except Exception as e:
        return f"An unexpected error occurred: {str(e)}"
```

4. In `main.py`, create the Swarm application:

```python
from swarm import Swarm, Agent
from tools import weather_lookup, currency_convert, get_random_fact

multi_tool_agent = Agent(
    name="Multi-tool Agent",
    instructions="""You are a versatile assistant that can provide weather information,
    perform currency conversions, and share random facts. Use the appropriate function
    for each task.""",
    functions=[weather_lookup, currency_convert, get_random_fact]
)

client = Swarm()

def run_conversation(user_input):
    messages = [{"role": "user", "content": user_input}]
    response = client.run(agent=multi_tool_agent, messages=messages)
    return response.messages[-1]['content']

# Test the agent with various inputs
print(run_conversation("What's the weather like in London, UK?"))
print(run_conversation("Convert 100 USD to EUR"))
print(run_conversation("Tell me a random fact"))
print(run_conversation("What's the weather in Error, Nowhere?"))  # Test error handling
print(run_conversation("Convert -50 USD to EUR"))  # Test error handling
```

This exercise demonstrates:
- Creating multiple tools with error handling
- Integrating these tools into a single agent
- Handling both successful calls and error cases
- Using external APIs (simulated and real) in tools

## Quiz

1. What is the purpose of the `function_to_json` function in Swarm?
2. How does Swarm handle tool calls made by an agent?
3. What are some best practices for developing custom tools in Swarm?
4. Why is error handling important in tool development, and how can it be implemented?
5. How can you integrate multiple tools into a single agent?

## Additional Resources

- [OpenAI Function Calling Guide](https://platform.openai.com/docs/guides/gpt/function-calling)
- [Python Requests Library Documentation](https://docs.python-requests.org/en/master/)
- [Python Type Hinting Guide](https://docs.python.org/3/library/typing.html)
- [Best Practices for API Error Handling](https://www.moesif.com/blog/technical/api-design/Which-HTTP-Status-Code-To-Use-For-Every-CRUD-App/)

In the next lesson, we'll explore OpenAI API integration in more depth, building on the foundations we've established here.

