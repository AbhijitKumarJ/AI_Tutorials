# Lesson 1: Introduction to Python and AI Agents

## Learning Objectives
By the end of this lesson, you will be able to:
1. Understand basic Python syntax and data structures
2. Grasp the fundamental concepts of AI and language models
3. Comprehend the purpose and basic functionality of Swarm
4. Set up a development environment for Swarm projects
5. Use basic Git commands for version control

## 1. Basic Python Syntax and Data Structures

### 1.1 Python Syntax
Python is known for its clean and readable syntax. Here are some key points:

- Indentation is used to define code blocks (no curly braces)
- Lines do not end with semicolons
- Variables are dynamically typed

Example:

```python
# This is a comment
name = "Alice"  # String variable
age = 30        # Integer variable

if age >= 18:
    print(f"{name} is an adult.")
else:
    print(f"{name} is a minor.")
```

### 1.2 Basic Data Types
Python has several built-in data types:

- Numeric Types: `int`, `float`, `complex`
- Sequence Types: `list`, `tuple`, `range`
- Text Type: `str`
- Mapping Type: `dict`
- Set Types: `set`, `frozenset`
- Boolean Type: `bool`

### 1.3 Common Data Structures

#### Lists
Lists are ordered, mutable sequences.

```python
fruits = ["apple", "banana", "cherry"]
fruits.append("date")
print(fruits[0])  # Output: apple
```

#### Dictionaries
Dictionaries are key-value pairs.

```python
person = {
    "name": "Bob",
    "age": 25,
    "city": "New York"
}
print(person["name"])  # Output: Bob
```

#### Tuples
Tuples are ordered, immutable sequences.

```python
coordinates = (10, 20)
x, y = coordinates
print(x)  # Output: 10
```

## 2. Introduction to AI and Language Models

### 2.1 What is Artificial Intelligence?
Artificial Intelligence (AI) refers to systems or machines that mimic human intelligence to perform tasks and can iteratively improve themselves based on the information they collect.

### 2.2 Machine Learning and Deep Learning
- Machine Learning: A subset of AI that uses statistical techniques to enable machines to improve with experience.
- Deep Learning: A subset of machine learning based on artificial neural networks.

### 2.3 Natural Language Processing (NLP)
NLP is a branch of AI that deals with the interaction between computers and humans using natural language.

### 2.4 Language Models
Language models are AI systems trained on vast amounts of text data to understand and generate human-like text. Examples include:

- GPT (Generative Pre-trained Transformer) series
- BERT (Bidirectional Encoder Representations from Transformers)
- T5 (Text-to-Text Transfer Transformer)

## 3. Overview of Swarm and its Purpose

Swarm is a framework for orchestrating multiple AI agents to perform complex tasks. It allows developers to create, manage, and coordinate different AI agents, each with specific roles and capabilities.

### 3.1 Key Concepts in Swarm

#### Agents
In Swarm, an agent is an entity with specific instructions and tools to perform certain tasks.

#### Routines
Routines are sequences of steps that agents follow to accomplish their tasks.

#### Handoffs
Handoffs occur when one agent transfers control to another agent better suited for a specific task.

### 3.2 Swarm's Architecture

Swarm's architecture typically includes:

```
swarm/
├── __init__.py
├── core.py
├── types.py
├── util.py
└── repl/
    ├── __init__.py
    └── repl.py
```

- `core.py`: Contains the main Swarm and Agent classes
- `types.py`: Defines custom types used in Swarm
- `util.py`: Utility functions
- `repl/`: Directory for the Read-Eval-Print Loop functionality

## 4. Setting Up the Development Environment

### 4.1 Installing Python
Download and install Python from [python.org](https://www.python.org/downloads/). Ensure you check the option to add Python to your PATH during installation.

### 4.2 Setting Up a Virtual Environment
Virtual environments isolate project dependencies. Here's how to set one up:

```bash
# Create a virtual environment
python -m venv swarm_env

# Activate the virtual environment
# On Windows:
swarm_env\Scripts\activate
# On macOS and Linux:
source swarm_env/bin/activate
```

### 4.3 Installing Swarm and Dependencies
With your virtual environment activated, install Swarm and its dependencies:

```bash
pip install git+https://github.com/openai/swarm.git
```

### 4.4 Setting Up an Integrated Development Environment (IDE)
We recommend using Visual Studio Code for its excellent Python support. Download it from [code.visualstudio.com](https://code.visualstudio.com/).

After installation:
1. Open VS Code
2. Install the Python extension
3. Select your Python interpreter (the one in your virtual environment)

## 5. Introduction to Version Control with Git

Git is a distributed version control system that helps you track changes in your code.

### 5.1 Installing Git
Download and install Git from [git-scm.com](https://git-scm.com/downloads).

### 5.2 Basic Git Commands

```bash
# Initialize a new Git repository
git init

# Add files to staging area
git add .

# Commit changes
git commit -m "Initial commit"

# Check status of your repository
git status

# View commit history
git log
```

### 5.3 Working with Remote Repositories

```bash
# Clone a repository
git clone https://github.com/username/repository.git

# Push changes to a remote repository
git push origin main

# Pull changes from a remote repository
git pull origin main
```

## Hands-on Exercise: Setting Up a Swarm Project

1. Create a new directory for your project:
   ```bash
   mkdir my_swarm_project
   cd my_swarm_project
   ```

2. Initialize a Git repository:
   ```bash
   git init
   ```

3. Create a virtual environment and activate it:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
   ```

4. Install Swarm:
   ```bash
   pip install git+https://github.com/openai/swarm.git
   ```

5. Create a simple Python script to test Swarm:
   ```python
   # main.py
   from swarm import Swarm, Agent

   def main():
       client = Swarm()
       agent = Agent(
           name="Test Agent",
           instructions="You are a helpful assistant."
       )
       messages = [{"role": "user", "content": "Hello, world!"}]
       response = client.run(agent=agent, messages=messages)
       print(response.messages[-1]["content"])

   if __name__ == "__main__":
       main()
   ```

6. Run your script:
   ```bash
   python main.py
   ```

7. Add your files to Git and commit:
   ```bash
   git add .
   git commit -m "Initial Swarm project setup"
   ```

## Conclusion

In this lesson, we've covered the basics of Python syntax and data structures, introduced AI and language models, provided an overview of Swarm, set up a development environment, and learned basic Git commands. The hands-on exercise gave you practical experience in setting up a Swarm project.

In the next lesson, we'll dive deeper into the Swarm project structure and explore its components in more detail.

## Additional Resources

- [Official Python Tutorial](https://docs.python.org/3/tutorial/)
- [Git Documentation](https://git-scm.com/doc)
- [OpenAI API Documentation](https://beta.openai.com/docs/)
- [Swarm GitHub Repository](https://github.com/openai/swarm)

