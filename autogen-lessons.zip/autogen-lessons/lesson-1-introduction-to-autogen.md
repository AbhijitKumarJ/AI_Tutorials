# Lesson 1: Introduction to Autogen - Overview and Basic Usage

## Table of Contents
1. [What is Autogen?](#what-is-autogen)
2. [Why is Autogen Useful?](#why-is-autogen-useful)
3. [Installing and Setting Up Autogen](#installing-and-setting-up-autogen)
4. [Basic Concepts](#basic-concepts)
   - [Agents](#agents)
   - [Conversations](#conversations)
   - [Tasks](#tasks)
5. [Simple Example: Creating a Conversation Between Two Agents](#simple-example-creating-a-conversation-between-two-agents)
6. [Project Structure](#project-structure)
7. [Conclusion](#conclusion)

## What is Autogen?

Autogen is a powerful framework for building AI-powered applications and automating complex tasks. It provides a flexible and extensible platform for creating conversational AI agents that can interact with each other and with humans. Autogen is designed to simplify the process of developing AI applications by abstracting away many of the complexities of working with large language models (LLMs) and providing a high-level API for creating intelligent agents.

## Why is Autogen Useful?

Autogen offers several key benefits that make it an invaluable tool for AI developers and researchers:

1. **Simplified Agent Creation**: Autogen provides pre-built agent types and easy-to-use APIs for creating custom agents, reducing the time and effort required to develop AI applications.

2. **Flexible Conversation Management**: The framework offers robust support for managing complex conversations between multiple agents and humans, enabling sophisticated dialogue systems.

3. **Code Execution Capabilities**: Autogen includes built-in support for executing code, allowing agents to perform computational tasks and interact with external systems.

4. **Integration with Popular LLMs**: It seamlessly integrates with various language models, including OpenAI's GPT models, making it easy to leverage state-of-the-art AI in your applications.

5. **Extensibility**: Autogen's modular design allows for easy extension and customization, enabling developers to add new capabilities and integrate with external services.

## Installing and Setting Up Autogen

To get started with Autogen, you'll need to install it using pip. Open your terminal and run the following command:

```bash
pip install pyautogen
```

It's recommended to use a virtual environment to avoid conflicts with other Python packages. Here's how you can set up a virtual environment and install Autogen:

```bash
# Create a new virtual environment
python -m venv autogen_env

# Activate the virtual environment
# On Windows:
autogen_env\Scripts\activate
# On macOS and Linux:
source autogen_env/bin/activate

# Install Autogen
pip install pyautogen
```

## Basic Concepts

Before we dive into a practical example, let's review the core concepts in Autogen:

### Agents

Agents are the fundamental building blocks in Autogen. They represent entities capable of performing actions, processing information, and engaging in conversations. Autogen provides several types of agents:

1. **AssistantAgent**: An AI-powered agent that can understand and generate human-like text based on the conversation context.
2. **UserProxyAgent**: An agent that can represent a human user, execute code, and provide feedback to other agents.
3. **ConversableAgent**: A base class for creating custom agents with specific behaviors and capabilities.

### Conversations

Conversations in Autogen represent the exchange of messages between agents. They can be one-on-one interactions or involve multiple agents in a group chat. Autogen provides mechanisms for initiating, managing, and terminating conversations.

### Tasks

Tasks in Autogen represent specific objectives or goals that agents work towards. They can range from simple question-answering to complex problem-solving scenarios involving multiple steps and agents.

## Simple Example: Creating a Conversation Between Two Agents

Let's create a simple example to demonstrate how to use Autogen to create a conversation between two agents: an AssistantAgent and a UserProxyAgent.

First, create a new Python file called `autogen_example.py` in your project directory. Here's the project structure:

```
autogen_project/
│
├── autogen_env/
└── autogen_example.py
```

Now, let's write the code for our example:

```python
# autogen_example.py

import autogen

# Configure the AssistantAgent
assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={
        "config_list": [{"model": "gpt-3.5-turbo", "api_key": "your_api_key_here"}],
    }
)

# Configure the UserProxyAgent
user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={"work_dir": "coding"},
)

# Start the conversation
user_proxy.initiate_chat(
    assistant,
    message="Hello! Can you explain what Autogen is and how it can be used in AI development?",
)
```

Let's break down this example:

1. We import the `autogen` module.
2. We create an `AssistantAgent` named "AI_Assistant" and configure it to use the GPT-3.5-turbo model. Replace `"your_api_key_here"` with your actual OpenAI API key.
3. We create a `UserProxyAgent` named "Human" to represent the user in the conversation. We configure it to terminate the conversation when the message ends with "TERMINATE" and set up a directory for code execution.
4. We initiate the chat between the user proxy and the assistant, starting with a question about Autogen.

To run this example, execute the following command in your terminal:

```bash
python autogen_example.py
```

You'll see the conversation unfold in your terminal, with the AI Assistant explaining Autogen and its uses in AI development. The conversation will continue until you type a message ending with "TERMINATE".

## Project Structure

As your Autogen project grows, you might want to organize it into a more structured layout. Here's an example of how you could structure a larger Autogen project:

```
autogen_project/
│
├── autogen_env/
├── src/
│   ├── __init__.py
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── custom_assistant.py
│   │   └── custom_user_proxy.py
│   ├── conversations/
│   │   ├── __init__.py
│   │   └── chat_manager.py
│   └── utils/
│       ├── __init__.py
│       └── config_loader.py
├── examples/
│   ├── simple_chat.py
│   └── multi_agent_task.py
├── tests/
│   ├── __init__.py
│   ├── test_agents.py
│   └── test_conversations.py
├── config/
│   └── api_config.json
├── requirements.txt
└── README.md
```

This structure separates your code into logical components:

- `src/`: Contains the main source code for your project.
  - `agents/`: Custom agent implementations.
  - `conversations/`: Modules for managing conversations.
  - `utils/`: Utility functions and helpers.
- `examples/`: Example scripts showcasing different Autogen features.
- `tests/`: Unit tests for your project.
- `config/`: Configuration files, such as API keys and model settings.
- `requirements.txt`: List of project dependencies.
- `README.md`: Project documentation.

## Conclusion

In this introduction to Autogen, we've covered the basics of what Autogen is, why it's useful, and how to get started with a simple conversation between two agents. We've also looked at a sample project structure for organizing larger Autogen projects.

Autogen provides a powerful framework for building AI-powered applications, enabling developers to create sophisticated conversational agents and automate complex tasks. As you continue to explore Autogen, you'll discover its full potential in areas such as task automation, multi-agent systems, and AI-assisted software development.

In the next lesson, we'll dive deeper into Autogen's architecture and explore its core components in more detail.

