# Lesson 6: Code Execution and Tool Usage in Autogen

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding Code Execution in Autogen](#understanding-code-execution-in-autogen)
   - [CodeExecutor Interface](#codeexecutor-interface)
   - [Local Command Line Executor](#local-command-line-executor)
   - [Docker Command Line Executor](#docker-command-line-executor)
4. [Implementing and Using Tools](#implementing-and-using-tools)
   - [Function-based Tools](#function-based-tools)
   - [Class-based Tools](#class-based-tools)
5. [Code Sanitization and Security Considerations](#code-sanitization-and-security-considerations)
6. [Advanced Code Execution Techniques](#advanced-code-execution-techniques)
   - [Jupyter Integration](#jupyter-integration)
   - [Custom Code Executors](#custom-code-executors)
7. [Practical Examples](#practical-examples)
   - [Example 1: Simple Code Execution](#example-1-simple-code-execution)
   - [Example 2: Implementing a Custom Tool](#example-2-implementing-a-custom-tool)
   - [Example 3: Advanced Code Execution with Docker](#example-3-advanced-code-execution-with-docker)
8. [Conclusion](#conclusion)

## Introduction

Code execution and tool usage are fundamental features of Autogen that allow agents to interact with the environment, perform computations, and utilize external resources. This lesson will dive deep into how Autogen handles code execution, implements tools, and ensures security in these operations.

## Project Structure

Before we delve into the details, let's look at the project structure relevant to code execution and tool usage in Autogen:

```
autogen/
├── coding/
│   ├── base.py
│   ├── docker_commandline_code_executor.py
│   ├── factory.py
│   ├── local_commandline_code_executor.py
│   ├── markdown_code_extractor.py
│   ├── utils.py
│   └── jupyter/
│       ├── base.py
│       ├── embedded_ipython_code_executor.py
│       ├── jupyter_client.py
│       └── jupyter_code_executor.py
├── agentchat/
│   ├── conversable_agent.py
│   └── assistant_agent.py
└── code_utils.py
```

This structure shows the main components involved in code execution and tool usage. The `coding/` directory contains various code executors and utilities, while the `agentchat/` directory includes agent implementations that utilize these features.

## Understanding Code Execution in Autogen

Autogen provides a flexible system for executing code generated or requested by agents. The core of this system is defined in the `coding/base.py` file.

### CodeExecutor Interface

The `CodeExecutor` class defines the interface for all code executors in Autogen:

```python
from abc import ABC, abstractmethod

class CodeExecutor(ABC):
    @abstractmethod
    def execute_code_blocks(self, code_blocks: List[CodeBlock]) -> CodeResult:
        pass

    @abstractmethod
    def restart(self) -> None:
        pass
```

This abstract base class ensures that all code executors implement the `execute_code_blocks` method for running code and the `restart` method for resetting the execution environment.

### Local Command Line Executor

The `LocalCommandLineCodeExecutor` class in `local_commandline_code_executor.py` provides a way to execute code on the local machine:

```python
from autogen.coding.base import CodeExecutor, CodeResult

class LocalCommandLineCodeExecutor(CodeExecutor):
    def __init__(self, timeout: int = 60, work_dir: Union[Path, str] = Path(".")):
        self._timeout = timeout
        self._work_dir = Path(work_dir)

    def execute_code_blocks(self, code_blocks: List[CodeBlock]) -> CodeResult:
        # Implementation details...

    def restart(self) -> None:
        # Implementation details...
```

This executor runs code in a subprocess on the local machine, with configurable timeout and working directory.

### Docker Command Line Executor

For improved isolation and security, Autogen provides the `DockerCommandLineCodeExecutor` in `docker_commandline_code_executor.py`:

```python
import docker
from autogen.coding.base import CodeExecutor, CodeResult

class DockerCommandLineCodeExecutor(CodeExecutor):
    def __init__(
        self,
        image: str = "python:3-slim",
        container_name: Optional[str] = None,
        timeout: int = 60,
        work_dir: Union[Path, str] = Path("."),
    ):
        # Initialization code...

    def execute_code_blocks(self, code_blocks: List[CodeBlock]) -> CodeResult:
        # Implementation details...

    def restart(self) -> None:
        # Implementation details...
```

This executor runs code inside a Docker container, providing better isolation from the host system.

## Implementing and Using Tools

Tools in Autogen are functions or methods that agents can use to perform specific tasks. They can be implemented in two main ways: function-based and class-based.

### Function-based Tools

Function-based tools are simple Python functions that can be registered with an agent:

```python
from autogen import ConversableAgent

def calculator(expression: str) -> float:
    return eval(expression)

agent = ConversableAgent("MathAgent")
agent.register_function(
    function_map={
        "calculator": calculator
    }
)
```

### Class-based Tools

For more complex tools, you can create a class that encapsulates the tool's functionality:

```python
class DatabaseTool:
    def __init__(self, connection_string):
        self.conn = connect_to_database(connection_string)

    def query(self, sql: str) -> List[Dict]:
        cursor = self.conn.cursor()
        cursor.execute(sql)
        return cursor.fetchall()

agent = ConversableAgent("DBAgent")
db_tool = DatabaseTool("connection_string_here")
agent.register_function(
    function_map={
        "db_query": db_tool.query
    }
)
```

## Code Sanitization and Security Considerations

Autogen implements several security measures to prevent malicious code execution:

1. **Input Sanitization**: The `_sanitize_command` method in `LocalCommandLineCodeExecutor` checks for potentially dangerous commands:

```python
def _sanitize_command(lang: str, code: str) -> None:
    dangerous_patterns = [
        (r"\brm\s+-rf\b", "Use of 'rm -rf' command is not allowed."),
        (r"\bmv\b.*?\s+/dev/null", "Moving files to /dev/null is not allowed."),
        # ... more patterns ...
    ]
    for pattern, message in dangerous_patterns:
        if re.search(pattern, code):
            raise ValueError(f"Potentially dangerous command detected: {message}")
```

2. **Execution in Docker**: Using `DockerCommandLineCodeExecutor` provides an additional layer of isolation.

3. **Timeout Limits**: All code executors have a configurable timeout to prevent infinite loops or long-running processes.

## Advanced Code Execution Techniques

### Jupyter Integration

Autogen provides integration with Jupyter notebooks through the `jupyter/` submodule:

```python
from autogen.coding.jupyter import JupyterCodeExecutor

executor = JupyterCodeExecutor(
    kernel_name="python3",
    timeout=120
)

result = executor.execute_code_blocks([
    CodeBlock(code="import pandas as pd\ndf = pd.DataFrame({'A': [1, 2, 3]})\ndf", language="python")
])
```

This allows for interactive code execution and rich output handling.

### Custom Code Executors

You can create custom code executors by subclassing `CodeExecutor` and implementing the required methods:

```python
from autogen.coding.base import CodeExecutor, CodeResult, CodeBlock

class MyCustomExecutor(CodeExecutor):
    def execute_code_blocks(self, code_blocks: List[CodeBlock]) -> CodeResult:
        # Custom implementation...

    def restart(self) -> None:
        # Custom implementation...
```

## Practical Examples

### Example 1: Simple Code Execution

Let's create a simple agent that can execute Python code:

```python
from autogen import ConversableAgent, UserProxyAgent
from autogen.coding import LocalCommandLineCodeExecutor

# Create a code executor
executor = LocalCommandLineCodeExecutor(timeout=30)

# Create an agent with code execution capability
coder_agent = ConversableAgent(
    "PythonCoder",
    code_execution_config={"executor": executor}
)

# Create a user proxy agent
user_proxy = UserProxyAgent("User")

# Start a conversation
user_proxy.initiate_chat(
    coder_agent,
    message="Write a Python function to calculate the fibonacci sequence up to n terms and run it for n=10"
)
```

### Example 2: Implementing a Custom Tool

Let's implement a custom tool for currency conversion:

```python
import requests
from autogen import ConversableAgent, UserProxyAgent

class CurrencyConverter:
    def convert(self, amount: float, from_currency: str, to_currency: str) -> float:
        url = f"https://api.exchangerate-api.com/v4/latest/{from_currency}"
        response = requests.get(url)
        data = response.json()
        rate = data["rates"][to_currency]
        return amount * rate

converter = CurrencyConverter()

agent = ConversableAgent(
    "FinanceAgent",
    function_map={"convert_currency": converter.convert}
)

user_proxy = UserProxyAgent("User")

user_proxy.initiate_chat(
    agent,
    message="Convert 100 USD to EUR"
)
```

### Example 3: Advanced Code Execution with Docker

For secure code execution, we can use the Docker-based executor:

```python
from autogen import ConversableAgent, UserProxyAgent
from autogen.coding import DockerCommandLineCodeExecutor

# Create a Docker-based code executor
executor = DockerCommandLineCodeExecutor(
    image="python:3.9-slim",
    timeout=60
)

# Create an agent with Docker-based code execution
secure_coder = ConversableAgent(
    "SecureCoder",
    code_execution_config={"executor": executor}
)

user_proxy = UserProxyAgent("User")

user_proxy.initiate_chat(
    secure_coder,
    message="Write and run a Python script that reads a file named 'data.txt' and counts the occurrences of each word"
)
```

## Conclusion

In this lesson, we've explored the intricacies of code execution and tool usage in Autogen. We've covered the basic architecture of code executors, how to implement and use tools, security considerations, and advanced techniques like Jupyter integration and custom executors. By mastering these concepts, you can create powerful and flexible agents capable of performing a wide range of tasks securely and efficiently.

Remember to always consider security implications when allowing code execution, especially in production environments. Prefer using isolated environments like Docker when dealing with untrusted code, and always sanitize inputs to prevent potential security vulnerabilities.

In the next lesson, we'll dive into enhancing Autogen with plugins and extensions, which will allow you to further expand the capabilities of your agents and integrate them with external services and APIs.
