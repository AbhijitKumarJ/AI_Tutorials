# Lesson 2: Autogen Architecture and Project Structure

## Table of Contents
1. [Introduction](#introduction)
2. [High-level Overview of Autogen's Architecture](#high-level-overview-of-autogens-architecture)
3. [File Structure and Main Components](#file-structure-and-main-components)
4. [Key Modules](#key-modules)
   - [agentchat](#agentchat)
   - [oai](#oai)
   - [code_utils](#code_utils)
5. [Configuration and Environment Setup](#configuration-and-environment-setup)
6. [Sample Project Structure](#sample-project-structure)
7. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll dive deep into the architecture of Autogen and explore its project structure. Understanding the underlying design and organization of Autogen is crucial for effectively using the framework and potentially extending its functionality. We'll examine the main components, key modules, and how they interact to create a powerful system for building AI-powered applications.

## High-level Overview of Autogen's Architecture

Autogen is designed with a modular and extensible architecture that allows for flexibility in creating AI agents and managing their interactions. At its core, Autogen consists of several key components:

1. **Agents**: The fundamental building blocks of Autogen, representing entities that can perform actions and engage in conversations.
2. **Conversations**: Mechanisms for managing the exchange of messages between agents.
3. **Language Model Clients**: Interfaces for interacting with various language models (e.g., OpenAI's GPT models).
4. **Code Execution**: Utilities for executing code within the Autogen environment.
5. **Configuration Management**: Tools for managing API keys, model settings, and other configuration options.

These components work together to create a flexible and powerful framework for building AI applications. Let's examine how these components are organized within Autogen's file structure.

## File Structure and Main Components

Autogen's source code is organized into several directories, each containing modules related to specific functionality. Here's an overview of the main directories and their contents:

```
autogen/
├── agentchat/
├── cache/
├── coding/
├── io/
├── logger/
├── oai/
├── runtime_logging/
├── __init__.py
├── cache.py
├── code_utils.py
├── token_count_utils.py
├── formatting_utils.py
├── math_utils.py
└── ...
```

Let's break down the purpose of each main directory:

- **agentchat/**: Contains implementations of various agent types and chat-related functionality.
- **cache/**: Implements caching mechanisms for improved performance.
- **coding/**: Provides utilities for code execution and management.
- **io/**: Handles input/output operations, including console and websocket interfaces.
- **logger/**: Implements logging functionality for debugging and monitoring.
- **oai/**: Contains OpenAI-specific implementations and utilities.
- **runtime_logging/**: Manages runtime logging for tracking agent interactions and performance.

The root directory also contains several utility modules that are used across the project.

## Key Modules

Let's examine three key modules in more detail: agentchat, oai, and code_utils.

### agentchat

The `agentchat` module is central to Autogen's functionality, providing implementations for various types of agents and managing their interactions. Here's a closer look at its structure:

```
agentchat/
├── __init__.py
├── agent.py
├── assistant_agent.py
├── conversable_agent.py
├── groupchat.py
├── human_proxy_agent.py
└── user_proxy_agent.py
```

Key components:

- `agent.py`: Defines the base `Agent` class, which all other agent types inherit from.
- `conversable_agent.py`: Implements the `ConversableAgent` class, a flexible base class for creating agents that can engage in conversations.
- `assistant_agent.py`: Provides the `AssistantAgent` class, representing an AI-powered assistant.
- `user_proxy_agent.py`: Implements the `UserProxyAgent` class, which can represent a human user or execute code.
- `groupchat.py`: Manages group conversations involving multiple agents.

Example of creating an AssistantAgent:

```python
from autogen.agentchat import AssistantAgent

assistant = AssistantAgent(
    name="AI_Assistant",
    llm_config={
        "model": "gpt-3.5-turbo",
        "api_key": "your_api_key_here",
    }
)
```

### oai

The `oai` module handles interactions with OpenAI's language models and provides utilities for managing API calls. Here's its structure:

```
oai/
├── __init__.py
├── client.py
├── completion.py
├── openai_utils.py
└── ...
```

Key components:

- `client.py`: Implements the `OpenAIWrapper` class, which manages API calls to OpenAI's services.
- `completion.py`: Provides utilities for text completion tasks.
- `openai_utils.py`: Contains helper functions for working with OpenAI's API.

Example of using the OpenAIWrapper:

```python
from autogen.oai import OpenAIWrapper

oai_client = OpenAIWrapper(config_list=[{
    "model": "gpt-3.5-turbo",
    "api_key": "your_api_key_here",
}])

response = oai_client.create(messages=[{
    "role": "user",
    "content": "What is the capital of France?"
}])

print(response)
```

### code_utils

The `code_utils.py` module provides utilities for code execution and management within Autogen. It includes functions for:

- Extracting code blocks from text
- Executing code in various languages
- Sanitizing and validating code input

Example of using code_utils to execute Python code:

```python
from autogen import code_utils

code = """
def greet(name):
    return f"Hello, {name}!"

print(greet("Alice"))
"""

result = code_utils.execute_code(code, lang="python")
print(result)
```

## Configuration and Environment Setup

Autogen uses configuration files and environment variables to manage settings such as API keys, model preferences, and other options. Here's how you can set up your environment:

1. Create a `.env` file in your project root:

```
OPENAI_API_KEY=your_api_key_here
```

2. Use the `config_list_from_dotenv` function to load configurations:

```python
from autogen import config_list_from_dotenv

config_list = config_list_from_dotenv(
    dotenv_file_path=".env",
    model_api_key_map={
        "gpt-3.5-turbo": "OPENAI_API_KEY",
        "gpt-4": "OPENAI_API_KEY",
    }
)
```

This approach allows you to keep sensitive information separate from your code and easily manage different configurations for various environments (development, testing, production).

## Sample Project Structure

When building a larger application with Autogen, it's helpful to organize your project in a way that promotes modularity and maintainability. Here's an example of how you might structure a more complex Autogen project:

```
my_autogen_project/
├── .env
├── config/
│   ├── __init__.py
│   └── settings.py
├── src/
│   ├── __init__.py
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── custom_assistant.py
│   │   └── custom_user_proxy.py
│   ├── conversations/
│   │   ├── __init__.py
│   │   └── chat_manager.py
│   ├── tasks/
│   │   ├── __init__.py
│   │   ├── code_generation.py
│   │   └── data_analysis.py
│   └── utils/
│       ├── __init__.py
│       └── helpers.py
├── tests/
│   ├── __init__.py
│   ├── test_agents.py
│   └── test_conversations.py
├── main.py
├── requirements.txt
└── README.md
```

In this structure:

- `config/`: Contains configuration-related code and settings.
- `src/`: Houses the main application code.
  - `agents/`: Custom agent implementations.
  - `conversations/`: Modules for managing different types of conversations.
  - `tasks/`: Specific task implementations using Autogen.
  - `utils/`: Helper functions and utilities.
- `tests/`: Contains unit tests for your application.
- `main.py`: The entry point of your application.
- `requirements.txt`: Lists all the project dependencies.
- `README.md`: Documentation for your project.

This structure allows for easy expansion of your project while keeping related functionality organized and accessible.

## Conclusion

In this lesson, we've explored the architecture and project structure of Autogen. We've examined its key components, including the `agentchat`, `oai`, and `code_utils` modules, and how they work together to provide a powerful framework for building AI-powered applications.

Understanding Autogen's architecture is crucial for effectively using the framework and potentially extending its functionality. By organizing your own projects in a modular and maintainable way, you can leverage Autogen's capabilities to build sophisticated AI applications.

In the next lesson, we'll dive deeper into understanding and working with Autogen agents, exploring their properties, methods, and how to create custom agents for specific use cases.

