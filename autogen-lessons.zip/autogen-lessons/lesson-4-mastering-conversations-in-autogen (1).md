# Lesson 4: Mastering Conversations in Autogen

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Initiating and Managing Conversations](#initiating-and-managing-conversations)
4. [Message Handling and Processing](#message-handling-and-processing)
5. [Implementing Conversation Flows](#implementing-conversation-flows)
6. [Advanced Conversation Techniques](#advanced-conversation-techniques)
   - [Group Chats](#group-chats)
   - [Nested Conversations](#nested-conversations)
7. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll dive deep into mastering conversations in Autogen. We'll explore how to initiate and manage conversations, handle messages, implement various conversation flows, and use advanced techniques like group chats and nested conversations. By the end of this lesson, you'll have a comprehensive understanding of how to create complex, multi-agent conversations using Autogen.

## Project Structure

Before we begin, let's look at the typical project structure for an Autogen application focusing on conversations:

```
autogen_project/
│
├── main.py
├── agents/
│   ├── __init__.py
│   ├── assistant_agent.py
│   ├── user_proxy_agent.py
│   └── custom_agent.py
│
├── conversations/
│   ├── __init__.py
│   ├── basic_conversation.py
│   ├── group_chat.py
│   └── nested_conversation.py
│
├── utils/
│   ├── __init__.py
│   └── message_utils.py
│
└── config/
    └── config.json
```

This structure organizes our code into separate modules for agents, conversations, and utilities, making it easier to manage and extend our application.

## Initiating and Managing Conversations

Let's start by looking at how to initiate and manage a basic conversation between two agents in Autogen.

```python
# File: conversations/basic_conversation.py

from autogen import AssistantAgent, UserProxyAgent, config_list_from_json

# Load LLM inference endpoints from an env variable or a file
# See https://microsoft.github.io/autogen/docs/FAQ#set-your-api-endpoints
config_list = config_list_from_json(env_or_file="OAI_CONFIG_LIST")

assistant = AssistantAgent("assistant", llm_config={"config_list": config_list})
user_proxy = UserProxyAgent("user_proxy", code_execution_config={"work_dir": "coding"})

# Initiate the chat
user_proxy.initiate_chat(
    assistant,
    message="Hello! Can you help me write a Python function to calculate the Fibonacci sequence?"
)
```

In this example, we create an `AssistantAgent` and a `UserProxyAgent`, then initiate a chat between them. The `UserProxyAgent` starts the conversation with a request for help with a Python function.

## Message Handling and Processing

Autogen provides powerful mechanisms for handling and processing messages within conversations. Let's explore how to customize message handling:

```python
# File: utils/message_utils.py

def custom_message_handler(message, sender, recipient):
    print(f"Message from {sender.name} to {recipient.name}: {message}")
    # You can modify the message here if needed
    return message

# File: conversations/basic_conversation.py

from utils.message_utils import custom_message_handler

assistant.register_reply(
    UserProxyAgent,
    reply_func=custom_message_handler,
    config={"memory": None}  # You can add custom configuration here
)
```

By registering a custom reply function, we can intercept and process messages before they're handled by the default logic. This allows for logging, message modification, or triggering custom behaviors based on message content.

## Implementing Conversation Flows

Autogen allows for the implementation of complex conversation flows. Let's create a multi-turn conversation with conditional branching:

```python
# File: conversations/complex_flow.py

from autogen import AssistantAgent, UserProxyAgent, config_list_from_json

config_list = config_list_from_json(env_or_file="OAI_CONFIG_LIST")

assistant = AssistantAgent("assistant", llm_config={"config_list": config_list})
user_proxy = UserProxyAgent("user_proxy", code_execution_config={"work_dir": "coding"})

def conversation_flow():
    response = user_proxy.initiate_chat(
        assistant,
        message="Can you explain the concept of recursion in programming?"
    )
    
    if "example" in response.lower():
        user_proxy.send(
            "Great! Can you provide a Python code example of recursion?",
            assistant
        )
    else:
        user_proxy.send(
            "Could you elaborate more on how recursion works in practice?",
            assistant
        )
    
    # Continue the conversation based on the assistant's responses
    while True:
        last_message = user_proxy.last_message()
        if "thank you" in last_message.lower():
            user_proxy.send("You're welcome! Is there anything else I can help you with?", assistant)
            break

conversation_flow()
```

This example demonstrates a conversation flow with conditional branching based on the content of the assistant's responses. It also shows how to continue a conversation until a certain condition is met.

## Advanced Conversation Techniques

### Group Chats

Autogen supports group chats involving multiple agents. Here's an example of setting up a group chat:

```python
# File: conversations/group_chat.py

from autogen import AssistantAgent, UserProxyAgent, GroupChat, GroupChatManager, config_list_from_json

config_list = config_list_from_json(env_or_file="OAI_CONFIG_LIST")

# Create multiple agents
assistant1 = AssistantAgent("assistant1", llm_config={"config_list": config_list})
assistant2 = AssistantAgent("assistant2", llm_config={"config_list": config_list})
user_proxy = UserProxyAgent("user_proxy", code_execution_config={"work_dir": "coding"})

# Create a group chat
groupchat = GroupChat(agents=[user_proxy, assistant1, assistant2], messages=[], max_round=12)
manager = GroupChatManager(groupchat=groupchat, llm_config={"config_list": config_list})

# Start the group chat
user_proxy.initiate_chat(
    manager,
    message="Let's discuss the pros and cons of different sorting algorithms."
)
```

In this example, we create multiple agents and add them to a `GroupChat`. The `GroupChatManager` orchestrates the conversation, allowing agents to interact in a group setting.

### Nested Conversations

Nested conversations allow for more complex interaction patterns, where one conversation can trigger sub-conversations. Here's an example:

```python
# File: conversations/nested_conversation.py

from autogen import AssistantAgent, UserProxyAgent, config_list_from_json

config_list = config_list_from_json(env_or_file="OAI_CONFIG_LIST")

assistant = AssistantAgent("assistant", llm_config={"config_list": config_list})
researcher = AssistantAgent("researcher", llm_config={"config_list": config_list})
user_proxy = UserProxyAgent("user_proxy", code_execution_config={"work_dir": "coding"})

def nested_conversation():
    user_proxy.initiate_chat(
        assistant,
        message="I need help understanding quantum computing."
    )
    
    # Based on the assistant's response, initiate a nested conversation with the researcher
    last_assistant_message = assistant.last_message()
    if "complex" in last_assistant_message.lower():
        user_proxy.initiate_chat(
            researcher,
            message="Can you provide a more detailed explanation of quantum superposition?"
        )
        
        # Use the researcher's response to continue the conversation with the assistant
        researcher_explanation = researcher.last_message()
        user_proxy.send(
            f"The researcher explained superposition as follows: {researcher_explanation}. "
            "Can you use this to give me a simpler explanation of quantum computing?",
            assistant
        )

nested_conversation()
```

This example demonstrates how to create a nested conversation where the user interacts with an assistant, and based on the response, initiates a sub-conversation with a researcher before returning to the main conversation.

## Conclusion

In this lesson, we've explored the various aspects of mastering conversations in Autogen. We've covered initiating and managing conversations, handling messages, implementing complex conversation flows, and advanced techniques like group chats and nested conversations.

By leveraging these features, you can create sophisticated AI applications that involve multi-agent interactions, conditional conversation flows, and complex information exchange patterns. As you continue to work with Autogen, experiment with combining these techniques to create even more powerful and flexible conversational AI systems.

Remember to always consider the context of your application and the specific requirements of your use case when designing conversation flows. With practice, you'll be able to create highly interactive and dynamic AI-powered conversations using Autogen.
