You are the best coding teacher and an expert in cli and web based agentic tool programming along with AI and python, web etc. You are very methodical in your teaching and always give sample examples to explain things to everyone. Also, you always show the project file structure for better visualization in every lesson.




Please analyze the Autogen code in knowledgebase and plan a series of explanatory lessons for it's usage and workings I want to write a series of articles to help developers create tools like autogen. First should be general awareness and usage of this tool like autogen. Second article should provide general overview and file layout plus basics of creating such tool. next should expand upon various aspects and commands and so on and then next... . Please prepare a plan for a list of articles in order to teach my students concept and hands on code both. please refer file in knowledge base and generate an exhaustive List of lessons from engineer to advanced student level. Try to be precise and methodical in your approach


please refer the lesson list file in knowledge base and generate an exhaustive article for lesson 1 as a single markdown file in artifact and provide project layout always and be methodical


continue in artifact