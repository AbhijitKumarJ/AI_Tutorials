# Lesson 3: Understanding Autogen Agents

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Types of Agents](#types-of-agents)
   - [ConversableAgent](#conversableagent)
   - [AssistantAgent](#assistantagent)
   - [UserProxyAgent](#userproxyagent)
4. [Creating and Customizing Agents](#creating-and-customizing-agents)
5. [Agent Properties and Methods](#agent-properties-and-methods)
6. [Implementing Custom Agents](#implementing-custom-agents)
7. [Practical Examples](#practical-examples)
8. [Best Practices](#best-practices)
9. [Conclusion](#conclusion)

## Introduction

Agents are the core building blocks of the Autogen framework. They represent different participants in a conversation or workflow, each with their own capabilities and behaviors. Understanding how to work with agents is crucial for leveraging the full power of Autogen in your AI-powered applications.

In this lesson, we'll dive deep into the world of Autogen agents, exploring their types, properties, and how to create and customize them for your specific needs.

## Project Structure

Before we begin, let's take a look at the typical project structure for an Autogen application:

```
autogen_project/
│
├── agents/
│   ├── __init__.py
│   ├── custom_agent.py
│   └── specialized_agent.py
│
├── config/
│   └── agent_config.json
│
├── utils/
│   └── helpers.py
│
├── main.py
├── requirements.txt
└── README.md
```

This structure organizes our code into logical components:
- `agents/`: Contains our custom agent implementations
- `config/`: Stores configuration files for our agents
- `utils/`: Houses helper functions and utilities
- `main.py`: The entry point of our application

Now, let's explore the different types of agents available in Autogen.

## Types of Agents

Autogen provides several built-in agent types, each designed for specific roles in a conversation or workflow. The three main types are:

1. ConversableAgent
2. AssistantAgent
3. UserProxyAgent

Let's examine each of these in detail.

### ConversableAgent

The `ConversableAgent` is the base class for all agents in Autogen. It provides the fundamental capabilities for participating in conversations.

Key features:
- Can send and receive messages
- Supports function calling
- Customizable with various configuration options

Here's a basic example of creating a `ConversableAgent`:

```python
from autogen import ConversableAgent

agent = ConversableAgent(
    name="Basic Agent",
    system_message="You are a helpful assistant.",
    human_input_mode="NEVER",
    llm_config={
        "config_list": [{"model": "gpt-3.5-turbo", "api_key": "your-api-key"}]
    }
)
```

### AssistantAgent

The `AssistantAgent` is a specialized version of `ConversableAgent` designed to act as an AI assistant. It's preconfigured with settings suitable for most assistant-like tasks.

Key features:
- Optimized for assistant-like behavior
- Can execute Python code (if configured)
- Suitable for complex problem-solving tasks

Example of creating an `AssistantAgent`:

```python
from autogen import AssistantAgent

assistant = AssistantAgent(
    name="AI Assistant",
    system_message="You are a knowledgeable AI assistant with expertise in various fields.",
    llm_config={
        "config_list": [{"model": "gpt-4", "api_key": "your-api-key"}]
    }
)
```

### UserProxyAgent

The `UserProxyAgent` is designed to represent a human user in the conversation. It can interact with other agents and execute code on behalf of the user.

Key features:
- Can execute code and provide feedback
- Supports different human input modes
- Useful for automating user-like interactions

Example of creating a `UserProxyAgent`:

```python
from autogen import UserProxyAgent

user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="ALWAYS",
    max_consecutive_auto_reply=3,
    code_execution_config={"work_dir": "coding", "use_docker": True}
)
```

## Creating and Customizing Agents

When creating agents, you have a wide range of configuration options to tailor their behavior to your specific needs. Here are some key parameters you can customize:

- `name`: A unique identifier for the agent
- `system_message`: Instructions that define the agent's role and behavior
- `human_input_mode`: Determines when to ask for human input (e.g., "ALWAYS", "NEVER", "TERMINATE")
- `llm_config`: Configuration for the language model used by the agent
- `code_execution_config`: Settings for code execution capabilities

Let's create a more specialized assistant agent:

```python
from autogen import AssistantAgent

coding_assistant = AssistantAgent(
    name="Coding Assistant",
    system_message="You are an expert Python programmer. Provide clear, efficient, and well-documented code solutions.",
    human_input_mode="TERMINATE",
    llm_config={
        "config_list": [{"model": "gpt-4", "api_key": "your-api-key"}],
        "temperature": 0.7,
        "request_timeout": 120
    },
    code_execution_config={
        "work_dir": "python_workspace",
        "use_docker": False,
        "timeout": 60
    }
)
```

In this example, we've created a coding assistant with specific instructions, a custom LLM configuration, and code execution settings.

## Agent Properties and Methods

Agents in Autogen come with a variety of properties and methods that allow you to interact with them and customize their behavior. Here are some important ones:

Properties:
- `name`: The name of the agent
- `system_message`: The system message defining the agent's role
- `human_input_mode`: The current human input mode
- `llm_config`: The language model configuration

Methods:
- `send(message, recipient)`: Send a message to another agent
- `receive(message, sender)`: Process a received message
- `generate_reply(messages)`: Generate a reply based on the conversation history
- `execute_code(code)`: Execute a piece of code (if code execution is enabled)
- `update_system_message(new_message)`: Update the agent's system message

Example of using agent methods:

```python
from autogen import AssistantAgent, UserProxyAgent

# Create agents
assistant = AssistantAgent("AI Assistant")
user = UserProxyAgent("User")

# Start a conversation
user.send("Hello, can you help me with a Python problem?", assistant)

# Generate and send a reply
reply = assistant.generate_reply(assistant.chat_messages[user])
assistant.send(reply, user)

# Update the assistant's system message
assistant.update_system_message("You are now a data science expert specializing in pandas and numpy.")
```

## Implementing Custom Agents

While Autogen's built-in agents are versatile, you may sometimes need to create custom agents with specialized behaviors. You can do this by subclassing `ConversableAgent` or one of its descendants.

Here's an example of a custom agent that specializes in data analysis:

```python
# File: agents/data_analyst_agent.py

from autogen import AssistantAgent
import pandas as pd

class DataAnalystAgent(AssistantAgent):
    def __init__(self, name, system_message="You are a data analysis expert.", **kwargs):
        super().__init__(name, system_message, **kwargs)
        self.dataframes = {}

    def load_data(self, filename, sheet_name=0):
        """Load data from an Excel file into a pandas DataFrame."""
        self.dataframes[filename] = pd.read_excel(filename, sheet_name=sheet_name)
        return f"Data from {filename} loaded successfully."

    def analyze_data(self, filename, column):
        """Perform basic analysis on a specified column."""
        if filename not in self.dataframes:
            return f"Error: {filename} not loaded. Please load the data first."

        df = self.dataframes[filename]
        if column not in df.columns:
            return f"Error: Column '{column}' not found in {filename}."

        analysis = df[column].describe()
        return f"Analysis of {column} in {filename}:\n{analysis}"

    def generate_reply(self, messages, sender):
        """Override to include data analysis capabilities."""
        last_message = messages[-1]
        if "load_data" in last_message["content"]:
            # Extract filename from the message
            filename = last_message["content"].split("load_data")[-1].strip()
            return self.load_data(filename)
        elif "analyze_data" in last_message["content"]:
            # Extract filename and column from the message
            parts = last_message["content"].split("analyze_data")[-1].strip().split(",")
            if len(parts) != 2:
                return "Error: Please provide both filename and column name."
            filename, column = parts
            return self.analyze_data(filename.strip(), column.strip())
        else:
            # For other messages, use the default generate_reply
            return super().generate_reply(messages, sender)
```

To use this custom agent:

```python
# File: main.py

from agents.data_analyst_agent import DataAnalystAgent

analyst = DataAnalystAgent(
    name="Data Analyst",
    llm_config={
        "config_list": [{"model": "gpt-4", "api_key": "your-api-key"}]
    }
)

# Use the custom agent
analyst.send("Please load_data sales_data.xlsx", analyst)
analyst.send("Now, analyze_data sales_data.xlsx, Revenue", analyst)
```

## Practical Examples

Let's look at a more complex example that demonstrates the interaction between multiple agents:

```python
# File: main.py

from autogen import AssistantAgent, UserProxyAgent
from agents.data_analyst_agent import DataAnalystAgent

# Create agents
user = UserProxyAgent("User")
coding_assistant = AssistantAgent("Coding Assistant", system_message="You are an expert Python programmer.")
data_analyst = DataAnalystAgent("Data Analyst")

# Set up a group chat
agents = [user, coding_assistant, data_analyst]

# Start the conversation
user.send("I need help analyzing our sales data and creating a visualization.", agents)

# The conversation continues with agents collaborating to solve the task
# (In a real scenario, you would implement logic to manage turn-taking and task delegation)
```

This example showcases how different specialized agents can work together to solve a complex task involving data analysis and visualization.

## Best Practices

When working with Autogen agents, keep these best practices in mind:

1. **Clear Role Definition**: Provide clear and specific system messages to define each agent's role and capabilities.

2. **Proper Error Handling**: Implement robust error handling in custom agents to gracefully manage unexpected inputs or situations.

3. **Modular Design**: Create specialized agents for different tasks, allowing for better code organization and reusability.

4. **Security Considerations**: Be cautious when allowing agents to execute code, especially in production environments. Use sandboxing techniques like Docker when possible.

5. **Conversation Management**: Implement proper conversation management to ensure smooth interactions between multiple agents.

6. **Testing**: Thoroughly test your agents with various inputs to ensure they behave as expected in different scenarios.

7. **Documentation**: Maintain clear documentation for your custom agents, including their purpose, capabilities, and any special usage instructions.

## Conclusion

In this lesson, we've explored the world of Autogen agents, from the built-in types to creating custom agents for specialized tasks. We've seen how to create, configure, and use these agents in various scenarios.

By mastering Autogen agents, you'll be well-equipped to build complex, AI-powered applications that can handle a wide range of tasks through natural language interactions. In the next lesson, we'll dive deeper into managing conversations between these agents, allowing you to create even more sophisticated workflows.

Remember to experiment with different agent configurations and custom implementations to find the best approach for your specific use cases. Happy coding!
