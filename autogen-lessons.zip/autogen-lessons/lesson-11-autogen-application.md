# Lesson 11: Building a Complete Autogen-based Application

In this comprehensive lesson, we'll walk through the process of building a complete Autogen-based application. We'll create a task management system that uses AI agents to help users organize, prioritize, and complete their tasks. This application will demonstrate how to integrate Autogen's powerful features into a practical, user-facing tool.

## Table of Contents

1. [Project Planning and Architecture](#1-project-planning-and-architecture)
2. [Setting Up the Project](#2-setting-up-the-project)
3. [Implementing Core Features](#3-implementing-core-features)
4. [User Interface Design and Integration](#4-user-interface-design-and-integration)
5. [Testing the Application](#5-testing-the-application)
6. [Deployment and Maintenance](#6-deployment-and-maintenance)

## 1. Project Planning and Architecture

Before we start coding, let's define our project goals and architecture.

### Project Goals

Our AI-powered Task Management System will:

1. Allow users to create, update, and delete tasks
2. Use AI agents to suggest task priorities and deadlines
3. Provide AI-generated suggestions for breaking down complex tasks
4. Offer natural language interactions for task management

### Architecture Overview

We'll use a client-server architecture with the following components:

1. **Backend**: Python-based server using FastAPI
2. **Frontend**: React-based web application
3. **Database**: SQLite for simplicity (can be scaled to PostgreSQL later)
4. **Autogen Integration**: Custom agents for task analysis and suggestions

### Project Structure

Here's the overall project structure we'll be working with:

```
ai_task_manager/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── models.py
│   │   ├── database.py
│   │   ├── schemas.py
│   │   └── agents/
│   │       ├── __init__.py
│   │       ├── task_analyzer.py
│   │       └── task_suggester.py
│   ├── tests/
│   │   ├── __init__.py
│   │   ├── test_main.py
│   │   └── test_agents.py
│   ├── requirements.txt
│   └── .env
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── services/
│   │   ├── App.js
│   │   └── index.js
│   ├── package.json
│   └── .env
└── README.md
```

Now that we have our project structure, let's dive into the implementation.

## 2. Setting Up the Project

Let's start by setting up our development environment and project structure.

### Backend Setup

First, let's set up our Python backend:

```bash
mkdir -p ai_task_manager/backend/app ai_task_manager/backend/tests
cd ai_task_manager/backend
python -m venv venv
source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
pip install fastapi uvicorn sqlalchemy pydantic python-dotenv autogen
pip freeze > requirements.txt
```

Create a `.env` file in the `backend` directory:

```
DATABASE_URL=sqlite:///./tasks.db
OPENAI_API_KEY=your_openai_api_key_here
```

### Frontend Setup

Now, let's set up our React frontend:

```bash
npx create-react-app ai_task_manager/frontend
cd ai_task_manager/frontend
npm install axios @material-ui/core @material-ui/icons
```

## 3. Implementing Core Features

Let's implement the core features of our application, starting with the backend.

### Backend Implementation

#### `backend/app/database.py`

```python
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv
import os

load_dotenv()

SQLALCHEMY_DATABASE_URL = os.getenv("DATABASE_URL")

engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()
```

#### `backend/app/models.py`

```python
from sqlalchemy import Column, Integer, String, Boolean, DateTime
from .database import Base

class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    description = Column(String)
    is_completed = Column(Boolean, default=False)
    priority = Column(String)
    deadline = Column(DateTime)
```

#### `backend/app/schemas.py`

```python
from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class TaskBase(BaseModel):
    title: str
    description: Optional[str] = None
    is_completed: bool = False
    priority: Optional[str] = None
    deadline: Optional[datetime] = None

class TaskCreate(TaskBase):
    pass

class Task(TaskBase):
    id: int

    class Config:
        orm_mode = True
```

#### `backend/app/agents/task_analyzer.py`

```python
import autogen

class TaskAnalyzer:
    def __init__(self):
        self.config_list = autogen.config_list_from_json(
            "OAI_CONFIG_LIST",
            filter_dict={
                "model": {
                    "gpt-4",
                    "gpt-3.5-turbo",
                    "gpt-3.5-turbo-16k",
                },
            },
        )
        self.llm_config = {"config_list": self.config_list}

    def analyze_task(self, task_description):
        assistant = autogen.AssistantAgent(
            name="task_analyzer",
            llm_config=self.llm_config,
            system_message="You are an AI assistant that analyzes tasks and suggests priorities and deadlines."
        )

        user_proxy = autogen.UserProxyAgent(
            name="user_proxy",
            human_input_mode="NEVER",
            max_consecutive_auto_reply=1,
            is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
        )

        user_proxy.initiate_chat(
            assistant,
            message=f"Analyze this task and suggest a priority (High, Medium, or Low) and a reasonable deadline: {task_description}"
        )

        # Extract the last assistant message
        last_message = assistant.chat_messages[user_proxy][-1]
        return last_message['content']

task_analyzer = TaskAnalyzer()
```

#### `backend/app/main.py`

```python
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy.orm import Session
from . import models, schemas
from .database import SessionLocal, engine
from .agents.task_analyzer import task_analyzer

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/tasks/", response_model=schemas.Task)
def create_task(task: schemas.TaskCreate, db: Session = Depends(get_db)):
    analysis = task_analyzer.analyze_task(task.description)
    # Extract priority and deadline from analysis (you might need to implement a parser for this)
    # For now, let's assume the analysis is in a simple format:
    priority, deadline = analysis.split(", ")
    
    db_task = models.Task(**task.dict(), priority=priority, deadline=deadline)
    db.add(db_task)
    db.commit()
    db.refresh(db_task)
    return db_task

@app.get("/tasks/", response_model=list[schemas.Task])
def read_tasks(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    tasks = db.query(models.Task).offset(skip).limit(limit).all()
    return tasks

@app.get("/tasks/{task_id}", response_model=schemas.Task)
def read_task(task_id: int, db: Session = Depends(get_db)):
    task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@app.put("/tasks/{task_id}", response_model=schemas.Task)
def update_task(task_id: int, task: schemas.TaskCreate, db: Session = Depends(get_db)):
    db_task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if db_task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    for key, value in task.dict().items():
        setattr(db_task, key, value)
    db.commit()
    db.refresh(db_task)
    return db_task

@app.delete("/tasks/{task_id}", response_model=schemas.Task)
def delete_task(task_id: int, db: Session = Depends(get_db)):
    task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    db.delete(task)
    db.commit()
    return task
```

## 4. User Interface Design and Integration

Now that we have our backend implemented, let's create a simple frontend to interact with our AI-powered task management system.

### Frontend Implementation

#### `frontend/src/services/api.js`

```javascript
import axios from 'axios';

const API_URL = 'http://localhost:8000';

export const createTask = async (task) => {
  const response = await axios.post(`${API_URL}/tasks/`, task);
  return response.data;
};

export const getTasks = async () => {
  const response = await axios.get(`${API_URL}/tasks/`);
  return response.data;
};

export const updateTask = async (id, task) => {
  const response = await axios.put(`${API_URL}/tasks/${id}`, task);
  return response.data;
};

export const deleteTask = async (id) => {
  const response = await axios.delete(`${API_URL}/tasks/${id}`);
  return response.data;
};
```

#### `frontend/src/components/TaskList.js`

```javascript
import React, { useState, useEffect } from 'react';
import { List, ListItem, ListItemText, ListItemSecondaryAction, IconButton, Typography } from '@material-ui/core';
import { Delete as DeleteIcon, Edit as EditIcon } from '@material-ui/icons';
import { getTasks, deleteTask } from '../services/api';

const TaskList = ({ onEditTask }) => {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    const fetchedTasks = await getTasks();
    setTasks(fetchedTasks);
  };

  const handleDeleteTask = async (id) => {
    await deleteTask(id);
    fetchTasks();
  };

  return (
    <List>
      {tasks.map((task) => (
        <ListItem key={task.id}>
          <ListItemText
            primary={task.title}
            secondary={
              <>
                <Typography component="span" variant="body2" color="textPrimary">
                  {task.description}
                </Typography>
                <br />
                Priority: {task.priority}, Deadline: {new Date(task.deadline).toLocaleDateString()}
              </>
            }
          />
          <ListItemSecondaryAction>
            <IconButton edge="end" aria-label="edit" onClick={() => onEditTask(task)}>
              <EditIcon />
            </IconButton>
            <IconButton edge="end" aria-label="delete" onClick={() => handleDeleteTask(task.id)}>
              <DeleteIcon />
            </IconButton>
          </ListItemSecondaryAction>
        </ListItem>
      ))}
    </List>
  );
};

export default TaskList;
```

#### `frontend/src/components/TaskForm.js`

```javascript
import React, { useState, useEffect } from 'react';
import { TextField, Button, Grid } from '@material-ui/core';
import { createTask, updateTask } from '../services/api';

const TaskForm = ({ task, onTaskAdded, onTaskUpdated }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (task) {
      setTitle(task.title);
      setDescription(task.description);
    }
  }, [task]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const taskData = { title, description };
    if (task) {
      await updateTask(task.id, taskData);
      onTaskUpdated();
    } else {
      await createTask(taskData);
      onTaskAdded();
    }
    setTitle('');
    setDescription('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            multiline
            rows={4}
          />
        </Grid>
        <Grid item xs={12}>
          <Button type="submit" variant="contained" color="primary">
            {task ? 'Update Task' : 'Add Task'}
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default TaskForm;
```

#### `frontend/src/App.js`

```javascript
import React, { useState } from 'react';
import { Container, Typography, Box } from '@material-ui/core';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';

function App() {
  const [editingTask, setEditingTask] = useState(null);

  const handleTaskAdded = () => {
    // Refresh the task list
    // You might want to implement a more efficient way to update the list
    // For simplicity, we'll just force a re-render of TaskList
    setEditingTask(null);
  };

  const handleTaskUpdated = () => {
    setEditingTask(null);
  };

  return (
    <Container maxWidth="md">
      <Box my={4}>
        <Typography variant="h4" component="h1" gutterBottom>
          AI-Powered Task Manager
        </Typography>
        <TaskForm
          task={editingTask}
          onTaskAdded={handleTaskAdded}
          onTaskUpdated={handleTaskUpdated}
        />
        <Box my={4}>
          <TaskList onEditTask={setEditingTask} />
        </Box>
      </Box>
    </Container>
  );
}

export default App;
```

Now that we have implemented both the backend and frontend of our AI-powered Task Management System, let's go through the process of running and testing our application.

## 5. Testing the Application

Testing is a crucial part of the development process. We'll create some basic tests for our backend and manually test our frontend.

### Backend Tests

Create a new file `backend/tests/test_main.py`:

```python
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_create_task():
    response = client.post(
        "/tasks/",
        json={"title": "Test Task", "description": "This is a test task"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "Test Task"
    assert "id" in data

def test_read_tasks():
    response = client.get("/tasks/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_read_task():
    # First, create a task
    create_response = client.post(
        "/tasks/",
        json={"title": "Test Task", "description": "This is a test task"}
    )
    task_id = create_response.json()["id"]

    # Then, read the task
    response = client.get(f"/tasks/{task_id}")
    assert response.status_code == 200
    assert response.json()["id"] == task_id

def test_update_task():
    # First, create a task
    create_response = client.post(
        "/tasks/",
        json={"title": "Test Task", "description": "This is a test task"}
    )
    task_id = create_response.json()["id"]

    # Then, update the task
    update_response = client.put(
        f"/tasks/{task_id}",
        json={"title": "Updated Task", "description": "This is an updated test task"}
    )
    assert update_response.status_code == 200
    assert update_response.json()["title"] == "Updated Task"

def test_delete_task():
    # First, create a task
    create_response = client.post(
        "/tasks/",
        json={"title": "Test Task", "description": "This is a test task"}
    )
    task_id = create_response.json()["id"]

    # Then, delete the task
    delete_response = client.delete(f"/tasks/{task_id}")
    assert delete_response.status_code == 200

    # Verify that the task has been deleted
    get_response = client.get(f"/tasks/{task_id}")
    assert get_response.status_code == 404
```

To run the tests, use the following command in the `backend` directory:

```bash
pytest
```

### Manual Frontend Testing

To test the frontend manually, follow these steps:

1. Start the backend server:

```bash
cd backend
uvicorn app.main:app --reload
```

2. In a new terminal, start the frontend development server:

```bash
cd frontend
npm start
```

3. Open a web browser and navigate to `http://localhost:3000`.

4. Test the following functionalities:
   - Create a new task
   - View the list of tasks
   - Edit an existing task
   - Delete a task

Pay special attention to the AI-generated priorities and deadlines for the tasks you create.

## 6. Deployment and Maintenance

Now that we have a working application, let's discuss deployment and maintenance strategies.

### Deployment

For this example, we'll use a simple deployment strategy. In a production environment, you might want to use more robust solutions like Docker containers and cloud platforms.

#### Backend Deployment

1. Choose a server or cloud platform (e.g., DigitalOcean, AWS, or Heroku).
2. Set up a Python environment on the server.
3. Copy your backend code to the server.
4. Install dependencies:

```bash
pip install -r requirements.txt
```

5. Set up environment variables for your production environment.
6. Run the FastAPI application using a production-grade ASGI server like Gunicorn:

```bash
gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker
```

#### Frontend Deployment

1. Build the React application:

```bash
npm run build
```

2. Deploy the contents of the `build` directory to a static file hosting service (e.g., Netlify, Vercel, or Amazon S3).

3. Update the API_URL in `frontend/src/services/api.js` to point to your production backend URL.

### Maintenance

To keep your application running smoothly and up-to-date, consider the following maintenance tasks:

1. **Regular Updates**: Keep your dependencies up-to-date by periodically running:

```bash
# Backend
pip list --outdated
pip install --upgrade <package_name>

# Frontend
npm outdated
npm update
```

2. **Monitoring**: Set up monitoring for your backend server to track performance, errors, and usage. You can use tools like Prometheus, Grafana, or cloud-specific monitoring solutions.

3. **Logging**: Implement comprehensive logging in your backend to help with debugging and tracking user behavior. Consider using a centralized logging solution like ELK stack (Elasticsearch, Logstash, Kibana) or cloud-based logging services.

4. **Backup**: Regularly backup your database to prevent data loss.

5. **Security Updates**: Stay informed about security vulnerabilities in your dependencies and update them promptly.

6. **Performance Optimization**: Continuously monitor and optimize your application's performance. This may involve database query optimization, caching strategies, or code refactoring.

7. **User Feedback**: Implement a system to collect and analyze user feedback, which can guide future improvements and bug fixes.

## Conclusion

In this lesson, we've built a complete Autogen-based application that demonstrates how to integrate AI agents into a practical task management system. We've covered the entire development process, from planning and implementation to testing and deployment.

Key takeaways from this lesson include:

1. Structuring an Autogen-based project with a clear separation of concerns
2. Integrating Autogen agents with a web application backend
3. Creating a user-friendly frontend to interact with AI-powered features
4. Implementing proper testing strategies for both backend and frontend
5. Considering deployment and maintenance aspects of an AI-powered application

As you continue to develop Autogen-based applications, remember to stay updated with the latest Autogen features and best practices. Always consider the ethical implications of AI-powered systems and strive to create applications that provide genuine value to users while respecting their privacy and data.

