# Bonus Lesson 1: Debugging and Testing Autogen Applications

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Debugging Techniques](#debugging-techniques)
   3.1 [Logging](#logging)
   3.2 [Interactive Debugging](#interactive-debugging)
   3.3 [Error Handling](#error-handling)
4. [Testing Strategies](#testing-strategies)
   4.1 [Unit Testing](#unit-testing)
   4.2 [Integration Testing](#integration-testing)
   4.3 [End-to-End Testing](#end-to-end-testing)
5. [Mocking and Stubbing](#mocking-and-stubbing)
6. [Performance Profiling](#performance-profiling)
7. [Continuous Integration and Deployment](#continuous-integration-and-deployment)
8. [Best Practices](#best-practices)
9. [Conclusion](#conclusion)

## 1. Introduction

Debugging and testing are crucial aspects of developing robust and reliable Autogen applications. In this bonus lesson, we'll explore various techniques and strategies to effectively debug, test, and maintain your Autogen projects. By the end of this lesson, you'll have a comprehensive understanding of how to ensure the quality and reliability of your AI-powered applications.

## 2. Project Structure

Before we dive into the specifics of debugging and testing, let's consider a typical project structure for an Autogen application:

```
autogen_project/
│
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── assistant_agent.py
│   │   └── user_proxy_agent.py
│   │
│   ├── conversations/
│   │   ├── __init__.py
│   │   └── chat_manager.py
│   │
│   ├── tools/
│   │   ├── __init__.py
│   │   └── custom_tools.py
│   │
│   └── main.py
│
├── tests/
│   ├── unit/
│   │   ├── test_agents.py
│   │   ├── test_conversations.py
│   │   └── test_tools.py
│   │
│   ├── integration/
│   │   └── test_end_to_end.py
│   │
│   └── conftest.py
│
├── logs/
├── .env
├── requirements.txt
├── setup.py
└── README.md
```

This structure separates the main application code (`src/`), test files (`tests/`), and other project-related files. We'll refer to this structure throughout the lesson.

## 3. Debugging Techniques

### 3.1 Logging

Logging is an essential tool for debugging Autogen applications. Python's built-in `logging` module can be used effectively to track the flow of your application and capture important information.

Let's add logging to our `assistant_agent.py`:

```python
# src/agents/assistant_agent.py

import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AssistantAgent:
    def __init__(self, name):
        self.name = name
        logger.info(f"AssistantAgent '{name}' initialized")

    def generate_response(self, message):
        logger.debug(f"Generating response for message: {message}")
        # ... response generation logic ...
        response = "This is a sample response"
        logger.info(f"Generated response: {response}")
        return response
```

To use this logging in your main application:

```python
# src/main.py

from agents.assistant_agent import AssistantAgent

def main():
    agent = AssistantAgent("Helper")
    response = agent.generate_response("Hello, can you help me?")
    print(response)

if __name__ == "__main__":
    main()
```

Running this script will produce log output, helping you track the application's flow.

### 3.2 Interactive Debugging

For more complex issues, interactive debugging can be invaluable. You can use Python's built-in `pdb` module or an IDE like PyCharm or VSCode for step-by-step debugging.

To use `pdb`, add breakpoints in your code:

```python
# src/agents/assistant_agent.py

import pdb

class AssistantAgent:
    # ...

    def generate_response(self, message):
        pdb.set_trace()  # This will pause execution and start the debugger
        # ... response generation logic ...
        return response
```

When you run your script, it will pause at the breakpoint, allowing you to inspect variables and step through the code.

### 3.3 Error Handling

Proper error handling is crucial for debugging and maintaining robust Autogen applications. Use try-except blocks to catch and handle exceptions gracefully:

```python
# src/agents/assistant_agent.py

class AssistantAgent:
    # ...

    def generate_response(self, message):
        try:
            # ... response generation logic ...
            return response
        except Exception as e:
            logger.error(f"Error generating response: {str(e)}")
            return "I'm sorry, I encountered an error while processing your request."
```

## 4. Testing Strategies

### 4.1 Unit Testing

Unit tests focus on testing individual components in isolation. Let's write a unit test for our `AssistantAgent`:

```python
# tests/unit/test_agents.py

import unittest
from src.agents.assistant_agent import AssistantAgent

class TestAssistantAgent(unittest.TestCase):
    def setUp(self):
        self.agent = AssistantAgent("TestAgent")

    def test_generate_response(self):
        message = "Hello, can you help me?"
        response = self.agent.generate_response(message)
        self.assertIsInstance(response, str)
        self.assertTrue(len(response) > 0)

if __name__ == '__main__':
    unittest.main()
```

Run this test using:

```
python -m unittest tests/unit/test_agents.py
```

### 4.2 Integration Testing

Integration tests check how different components work together. Let's create an integration test for a conversation between agents:

```python
# tests/integration/test_end_to_end.py

import unittest
from src.agents.assistant_agent import AssistantAgent
from src.agents.user_proxy_agent import UserProxyAgent
from src.conversations.chat_manager import ChatManager

class TestEndToEnd(unittest.TestCase):
    def setUp(self):
        self.assistant = AssistantAgent("Assistant")
        self.user_proxy = UserProxyAgent("UserProxy")
        self.chat_manager = ChatManager()

    def test_conversation_flow(self):
        self.chat_manager.add_agent(self.assistant)
        self.chat_manager.add_agent(self.user_proxy)
        
        conversation = self.chat_manager.start_conversation(
            "UserProxy",
            "Hello, I need help with Python programming."
        )
        
        self.assertIsInstance(conversation, list)
        self.assertTrue(len(conversation) > 1)
        self.assertEqual(conversation[0]['agent'], "UserProxy")
        self.assertEqual(conversation[1]['agent'], "Assistant")

if __name__ == '__main__':
    unittest.main()
```

### 4.3 End-to-End Testing

End-to-end tests verify the entire application workflow. These tests often involve simulating user interactions and checking the final output. You can use tools like Selenium for web-based Autogen applications or create custom scripts that run your application with various inputs.

## 5. Mocking and Stubbing

When testing Autogen applications, you often need to mock external dependencies, such as API calls to language models. The `unittest.mock` module is useful for this purpose:

```python
# tests/unit/test_agents.py

from unittest.mock import patch
from src.agents.assistant_agent import AssistantAgent

class TestAssistantAgent(unittest.TestCase):
    @patch('src.agents.assistant_agent.openai.Completion.create')
    def test_generate_response_with_mock(self, mock_create):
        mock_create.return_value = {'choices': [{'text': 'Mocked response'}]}
        
        agent = AssistantAgent("TestAgent")
        response = agent.generate_response("Test message")
        
        self.assertEqual(response, 'Mocked response')
        mock_create.assert_called_once()

```

This test mocks the OpenAI API call, allowing you to test your agent's behavior without making actual API requests.

## 6. Performance Profiling

For Autogen applications, performance can be critical. Use Python's `cProfile` module to identify bottlenecks:

```python
# src/main.py

import cProfile

def main():
    # ... your main application logic ...

if __name__ == "__main__":
    cProfile.run('main()')
```

This will generate a performance report, helping you identify slow parts of your application.

## 7. Continuous Integration and Deployment

Implement a CI/CD pipeline to automatically run tests and deploy your Autogen application. Here's a sample GitHub Actions workflow:

```yaml
# .github/workflows/ci-cd.yml

name: Autogen CI/CD

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.8'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Run tests
      run: python -m unittest discover tests

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - uses: actions/checkout@v2
    - name: Deploy to production
      run: |
        # Add your deployment steps here
```

This workflow runs tests on every push and pull request, and deploys the application when changes are merged to the main branch.

## 8. Best Practices

1. **Write tests first**: Adopt a Test-Driven Development (TDD) approach when building Autogen applications.
2. **Use meaningful names**: Choose descriptive names for your tests, variables, and functions to improve readability.
3. **Keep tests independent**: Each test should be able to run independently of others.
4. **Mock external dependencies**: Use mocking to isolate your tests from external services.
5. **Regularly update dependencies**: Keep your Autogen and other dependencies up to date to benefit from the latest features and security patches.
6. **Monitor production logs**: Implement robust logging and monitoring in your production environment to catch and diagnose issues quickly.

## 9. Conclusion

Debugging and testing are essential skills for developing reliable Autogen applications. By implementing proper logging, writing comprehensive tests, and following best practices, you can ensure that your AI-powered applications are robust, maintainable, and performant.

Remember to adapt these techniques to your specific use case and continuously refine your debugging and testing strategies as your Autogen projects grow in complexity.
