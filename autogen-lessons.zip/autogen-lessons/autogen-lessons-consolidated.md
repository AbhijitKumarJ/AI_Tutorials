# Project Structure

- /
    - autogen-lesson-series.md
    - bonus-lesson-1-debugging-testing-autogen.md
    - bonus-lesson-2.md
    - bonus-lesson-3-advanced-autogen-customization.md
    - lesson-1-introduction-to-autogen.md
    - lesson-10-advanced-topics.md
    - lesson-11-autogen-application.md
    - lesson-12-autogen-best-practices.md
    - lesson-2-autogen-architecture-and-project-structure.md
    - lesson-3-understanding-autogen-agents.md
    - lesson-4-mastering-conversations-in-autogen (1).md
    - lesson-5-working-with-language-models-in-autogen.md
    - lesson-6-code-execution-and-tool-usage.md
    - lesson-7-enhancing-autogen-with-plugins-and-extensions.md
    - lesson-8-autogen-task-automation.md
    - lesson-9-performance-optimization.md
    - misc.md
- agentchat/
    - agentchat-lesson-series.md
    - lesson-1-introduction-to-autogen-agentchat.md
    - lesson-10-agent-evaluation-framework.md
    - lesson-11-advanced-agent-capabilities.md
    - lesson-12-text-compression-transformation.md
    - lesson-13-graph-based-rag.md
    - lesson-14-extending-agentchat-custom-extensions.md
    - lesson-15-advanced-message-handling.md
    - lesson-16-function-calling-and-tool-usage.md
    - lesson-17-state-management.md
    - lesson-18-error-handling.md
    - lesson-19-optimizing-agent-performance.md
    - lesson-2-understanding-agent-base-class.md
    - lesson-20-testing-debugging-autogen-agents.md
    - lesson-21-security-considerations.md
    - lesson-22-integration-external-ai-services.md
    - lesson-23-advanced-use-cases.txt
    - lesson-24-scaling-agentchat-for-production.txt
    - lesson-3-conversable-agent.md
    - lesson-4-specialized-agents.md
    - lesson-5-group-chats-and-collaboration.md
    - lesson-6-human-proxy-agent.md
    - lesson-7-contributed-agents-and-utilities.md
    - lesson-8-contributed-agents-and-utilities-part-2.md
    - lesson-9-information-retrieval-in-agents.md
    - extra/
        - lesson-3-understanding-agent-base-class.md
        - lesson-5-specialized-agents (1).md
        - lesson-5-specialized-agents.md
        - lesson-7-contributed-agents-part-1.md
- logger/
    - autogen-logger-series.md
    - Lesson 1 Introduction to Autogen's Logging System.md
    - lesson-2-baselogger.md
    - lesson-3-filelogger.md
    - lesson-4-sqlitelogger.md
    - lesson-5-loggerfactory-and-usage.md

---

# autogen-lesson-series.md

```
Thank you for the opportunity to help plan a series of articles on Autogen and similar tools. I'd be happy to create a comprehensive lesson plan that covers both conceptual understanding and hands-on coding. Based on the Autogen codebase provided, here's a proposed series of articles that progress from basic usage to advanced development:

1. Introduction to Autogen: Overview and Basic Usage
   - What is Autogen and why it's useful
   - Installing and setting up Autogen
   - Basic concepts: Agents, Conversations, and Tasks
   - Simple example: Creating a conversation between two agents

2. Autogen Architecture and Project Structure
   - High-level overview of Autogen's architecture
   - File structure and main components
   - Key modules: agentchat, oai, code_utils
   - Configuration and environment setup

3. Understanding Autogen Agents
   - Types of agents: AssistantAgent, UserProxyAgent, ConversableAgent
   - Creating and customizing agents
   - Agent properties and methods
   - Implementing custom agents

4. Mastering Conversations in Autogen
   - Initiating and managing conversations
   - Message handling and processing
   - Implementing conversation flows
   - Advanced conversation techniques: group chats, nested conversations

5. Working with Language Models in Autogen
   - Integration with OpenAI and other LLM providers
   - Configuring and using different models
   - Handling API calls and rate limiting
   - Implementing custom LLM clients

6. Code Execution and Tool Usage in Autogen
   - Understanding code execution in Autogen
   - Implementing and using tools
   - Code sanitization and security considerations
   - Advanced code execution techniques

7. Enhancing Autogen with Plugins and Extensions
   - Creating custom plugins
   - Extending Autogen's functionality
   - Integration with external services and APIs
   - Best practices for plugin development

8. Autogen for Task Automation
   - Designing complex workflows with Autogen
   - Task planning and execution
   - Error handling and recovery in automated tasks
   - Real-world examples of Autogen-powered automation

9. Performance Optimization and Scaling
   - Optimizing Autogen for large-scale applications
   - Caching strategies and implementation
   - Parallel processing and distributed systems
   - Monitoring and logging in Autogen applications

10. Advanced Topics in Autogen Development
    - Implementing custom LLM-powered features
    - Fine-tuning language models for specific tasks
    - Integrating Autogen with other AI frameworks
    - Cutting-edge research and future directions

11. Building a Complete Autogen-based Application
    - Project planning and architecture
    - Implementing core features using Autogen
    - User interface design and integration
    - Testing, deployment, and maintenance

12. Autogen Best Practices and Design Patterns
    - Code organization and modular design
    - Error handling and graceful degradation
    - Security considerations in AI-powered applications
    - Ethical considerations and responsible AI development
      
13. Bonus Lesson 1: Debugging and Testing Autogen Applications

    ## Table of Contents 1. \[Introduction]\(#introduction) 2. \[Project Structure]\(#project-structure) 3. \[Debugging Techniques]\(#debugging-techniques) 3.1 \[Logging]\(#logging) 3.2 \[Interactive Debugging]\(#interactive-debugging) 3.3 \[Error Handling]\(#error-handling) 4. \[Testing Strategies]\(#testing-strategies) 4.1 \[Unit Testing]\(#unit-testing) 4.2 \[Integration Testing]\(#integration-testing) 4.3 \[End-to-End Testing]\(#end-to-end-testing) 5. \[Mocking and Stubbing]\(#mocking-and-stubbing) 6. \[Performance Profiling]\(#performance-profiling) 7. \[Continuous Integration and Deployment]\(#continuous-integration-and-deployment) 8. \[Best Practices]\(#best-practices) 9. \[Conclusion]\(#conclusion)

    
14. Bonus Lesson 2: Advanced Agent Interactions and Collaboration in Autogen

    Table of Contents Introduction Project Structure Advanced Agent Types 3.1 Specialized Agents 3.2 Meta-Agents Complex Interaction Patterns 4.1 Multi-Stage Conversations 4.2 Branching Dialogues Collaborative Problem Solving 5.1 Task Decomposition 5.2 Parallel Processing Dynamic Agent Creation Inter-Agent Learning and Knowledge Sharing Conflict Resolution and Consensus Building Advanced GroupChat Techniques Integrating External Knowledge and APIs Performance Optimization for Multi-Agent Systems Best Practices and Design Patterns Conclusion


15. Bonus Lesson 3: Advanced Autogen Customization and Extensibility

    ## Table of Contents 1. \[Introduction]\(#introduction) 2. \[Project Structure]\(#project-structure) 3. \[Custom Agent Behaviors]\(#custom-agent-behaviors) 3.1 \[Extending ConversableAgent]\(#extending-conversableagent) 3.2 \[Custom Message Processing]\(#custom-message-processing) 4. \[Advanced Configuration Management]\(#advanced-configuration-management) 4.1 \[Dynamic Configuration Loading]\(#dynamic-configuration-loading) 4.2 \[Environment-specific Configurations]\(#environment-specific-configurations) 5. \[Plugin Architecture]\(#plugin-architecture) 5.1 \[Creating Plugins]\(#creating-plugins) 5.2 \[Plugin Management]\(#plugin-management) 6. \[Custom LLM Integrations]\(#custom-llm-integrations) 6.1 \[Implementing a Custom LLM Client]\(#implementing-a-custom-llm-client) 6.2 \[Advanced Prompt Engineering]\(#advanced-prompt-engineering) 7. \[Event System and Hooks]\(#event-system-and-hooks) 7.1 \[Implementing an Event System]\(#implementing-an-event-system) 7.2 \[Using Hooks for Extensibility]\(#using-hooks-for-extensibility) 8. \[Advanced Logging and Monitoring]\(#advanced-logging-and-monitoring) 8.1 \[Custom Logging Solutions]\(#custom-logging-solutions) 8.2 \[Real-time Monitoring]\(#real-time-monitoring) 9. \[Performance Optimization Techniques]\(#performance-optimization-techniques) 9.1 \[Caching Strategies]\(#caching-strategies) 9.2 \[Parallel Processing]\(#parallel-processing) 10. \[Security Enhancements]\(#security-enhancements) 10.1 \[Input Sanitization]\(#input-sanitization) 10.2 \[Access Control]\(#access-control) 11. \[Best Practices and Design Patterns]\(#best-practices-and-design-patterns) 12. \[Conclusion]\(#conclusion)



For each lesson, I'll provide detailed explanations, code samples, and project structure visualizations to help students understand both the concepts and practical implementation. Let me know if you'd like me to elaborate on any specific lesson or if you have any particular areas you'd like to emphasize in the series.
```

# bonus-lesson-1-debugging-testing-autogen.md

```
# Bonus Lesson 1: Debugging and Testing Autogen Applications

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Debugging Techniques](#debugging-techniques)
   3.1 [Logging](#logging)
   3.2 [Interactive Debugging](#interactive-debugging)
   3.3 [Error Handling](#error-handling)
4. [Testing Strategies](#testing-strategies)
   4.1 [Unit Testing](#unit-testing)
   4.2 [Integration Testing](#integration-testing)
   4.3 [End-to-End Testing](#end-to-end-testing)
5. [Mocking and Stubbing](#mocking-and-stubbing)
6. [Performance Profiling](#performance-profiling)
7. [Continuous Integration and Deployment](#continuous-integration-and-deployment)
8. [Best Practices](#best-practices)
9. [Conclusion](#conclusion)

## 1. Introduction

Debugging and testing are crucial aspects of developing robust and reliable Autogen applications. In this bonus lesson, we'll explore various techniques and strategies to effectively debug, test, and maintain your Autogen projects. By the end of this lesson, you'll have a comprehensive understanding of how to ensure the quality and reliability of your AI-powered applications.

## 2. Project Structure

Before we dive into the specifics of debugging and testing, let's consider a typical project structure for an Autogen application:

```
autogen_project/
│
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── assistant_agent.py
│   │   └── user_proxy_agent.py
│   │
│   ├── conversations/
│   │   ├── __init__.py
│   │   └── chat_manager.py
│   │
│   ├── tools/
│   │   ├── __init__.py
│   │   └── custom_tools.py
│   │
│   └── main.py
│
├── tests/
│   ├── unit/
│   │   ├── test_agents.py
│   │   ├── test_conversations.py
│   │   └── test_tools.py
│   │
│   ├── integration/
│   │   └── test_end_to_end.py
│   │
│   └── conftest.py
│
├── logs/
├── .env
├── requirements.txt
├── setup.py
└── README.md
```

This structure separates the main application code (`src/`), test files (`tests/`), and other project-related files. We'll refer to this structure throughout the lesson.

## 3. Debugging Techniques

### 3.1 Logging

Logging is an essential tool for debugging Autogen applications. Python's built-in `logging` module can be used effectively to track the flow of your application and capture important information.

Let's add logging to our `assistant_agent.py`:

```python
# src/agents/assistant_agent.py

import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AssistantAgent:
    def __init__(self, name):
        self.name = name
        logger.info(f"AssistantAgent '{name}' initialized")

    def generate_response(self, message):
        logger.debug(f"Generating response for message: {message}")
        # ... response generation logic ...
        response = "This is a sample response"
        logger.info(f"Generated response: {response}")
        return response
```

To use this logging in your main application:

```python
# src/main.py

from agents.assistant_agent import AssistantAgent

def main():
    agent = AssistantAgent("Helper")
    response = agent.generate_response("Hello, can you help me?")
    print(response)

if __name__ == "__main__":
    main()
```

Running this script will produce log output, helping you track the application's flow.

### 3.2 Interactive Debugging

For more complex issues, interactive debugging can be invaluable. You can use Python's built-in `pdb` module or an IDE like PyCharm or VSCode for step-by-step debugging.

To use `pdb`, add breakpoints in your code:

```python
# src/agents/assistant_agent.py

import pdb

class AssistantAgent:
    # ...

    def generate_response(self, message):
        pdb.set_trace()  # This will pause execution and start the debugger
        # ... response generation logic ...
        return response
```

When you run your script, it will pause at the breakpoint, allowing you to inspect variables and step through the code.

### 3.3 Error Handling

Proper error handling is crucial for debugging and maintaining robust Autogen applications. Use try-except blocks to catch and handle exceptions gracefully:

```python
# src/agents/assistant_agent.py

class AssistantAgent:
    # ...

    def generate_response(self, message):
        try:
            # ... response generation logic ...
            return response
        except Exception as e:
            logger.error(f"Error generating response: {str(e)}")
            return "I'm sorry, I encountered an error while processing your request."
```

## 4. Testing Strategies

### 4.1 Unit Testing

Unit tests focus on testing individual components in isolation. Let's write a unit test for our `AssistantAgent`:

```python
# tests/unit/test_agents.py

import unittest
from src.agents.assistant_agent import AssistantAgent

class TestAssistantAgent(unittest.TestCase):
    def setUp(self):
        self.agent = AssistantAgent("TestAgent")

    def test_generate_response(self):
        message = "Hello, can you help me?"
        response = self.agent.generate_response(message)
        self.assertIsInstance(response, str)
        self.assertTrue(len(response) > 0)

if __name__ == '__main__':
    unittest.main()
```

Run this test using:

```
python -m unittest tests/unit/test_agents.py
```

### 4.2 Integration Testing

Integration tests check how different components work together. Let's create an integration test for a conversation between agents:

```python
# tests/integration/test_end_to_end.py

import unittest
from src.agents.assistant_agent import AssistantAgent
from src.agents.user_proxy_agent import UserProxyAgent
from src.conversations.chat_manager import ChatManager

class TestEndToEnd(unittest.TestCase):
    def setUp(self):
        self.assistant = AssistantAgent("Assistant")
        self.user_proxy = UserProxyAgent("UserProxy")
        self.chat_manager = ChatManager()

    def test_conversation_flow(self):
        self.chat_manager.add_agent(self.assistant)
        self.chat_manager.add_agent(self.user_proxy)
        
        conversation = self.chat_manager.start_conversation(
            "UserProxy",
            "Hello, I need help with Python programming."
        )
        
        self.assertIsInstance(conversation, list)
        self.assertTrue(len(conversation) > 1)
        self.assertEqual(conversation[0]['agent'], "UserProxy")
        self.assertEqual(conversation[1]['agent'], "Assistant")

if __name__ == '__main__':
    unittest.main()
```

### 4.3 End-to-End Testing

End-to-end tests verify the entire application workflow. These tests often involve simulating user interactions and checking the final output. You can use tools like Selenium for web-based Autogen applications or create custom scripts that run your application with various inputs.

## 5. Mocking and Stubbing

When testing Autogen applications, you often need to mock external dependencies, such as API calls to language models. The `unittest.mock` module is useful for this purpose:

```python
# tests/unit/test_agents.py

from unittest.mock import patch
from src.agents.assistant_agent import AssistantAgent

class TestAssistantAgent(unittest.TestCase):
    @patch('src.agents.assistant_agent.openai.Completion.create')
    def test_generate_response_with_mock(self, mock_create):
        mock_create.return_value = {'choices': [{'text': 'Mocked response'}]}
        
        agent = AssistantAgent("TestAgent")
        response = agent.generate_response("Test message")
        
        self.assertEqual(response, 'Mocked response')
        mock_create.assert_called_once()

```

This test mocks the OpenAI API call, allowing you to test your agent's behavior without making actual API requests.

## 6. Performance Profiling

For Autogen applications, performance can be critical. Use Python's `cProfile` module to identify bottlenecks:

```python
# src/main.py

import cProfile

def main():
    # ... your main application logic ...

if __name__ == "__main__":
    cProfile.run('main()')
```

This will generate a performance report, helping you identify slow parts of your application.

## 7. Continuous Integration and Deployment

Implement a CI/CD pipeline to automatically run tests and deploy your Autogen application. Here's a sample GitHub Actions workflow:

```yaml
# .github/workflows/ci-cd.yml

name: Autogen CI/CD

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.8'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Run tests
      run: python -m unittest discover tests

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - uses: actions/checkout@v2
    - name: Deploy to production
      run: |
        # Add your deployment steps here
```

This workflow runs tests on every push and pull request, and deploys the application when changes are merged to the main branch.

## 8. Best Practices

1. **Write tests first**: Adopt a Test-Driven Development (TDD) approach when building Autogen applications.
2. **Use meaningful names**: Choose descriptive names for your tests, variables, and functions to improve readability.
3. **Keep tests independent**: Each test should be able to run independently of others.
4. **Mock external dependencies**: Use mocking to isolate your tests from external services.
5. **Regularly update dependencies**: Keep your Autogen and other dependencies up to date to benefit from the latest features and security patches.
6. **Monitor production logs**: Implement robust logging and monitoring in your production environment to catch and diagnose issues quickly.

## 9. Conclusion

Debugging and testing are essential skills for developing reliable Autogen applications. By implementing proper logging, writing comprehensive tests, and following best practices, you can ensure that your AI-powered applications are robust, maintainable, and performant.

Remember to adapt these techniques to your specific use case and continuously refine your debugging and testing strategies as your Autogen projects grow in complexity.

```

# bonus-lesson-2.md

```
# Bonus Lesson 2: Advanced Agent Interactions and Collaboration in Autogen

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Advanced Agent Types](#advanced-agent-types)
   3.1 [Specialized Agents](#specialized-agents)
   3.2 [Meta-Agents](#meta-agents)
4. [Complex Interaction Patterns](#complex-interaction-patterns)
   4.1 [Multi-Stage Conversations](#multi-stage-conversations)
   4.2 [Branching Dialogues](#branching-dialogues)
5. [Collaborative Problem Solving](#collaborative-problem-solving)
   5.1 [Task Decomposition](#task-decomposition)
   5.2 [Parallel Processing](#parallel-processing)
6. [Dynamic Agent Creation](#dynamic-agent-creation)
7. [Inter-Agent Learning and Knowledge Sharing](#inter-agent-learning-and-knowledge-sharing)
8. [Conflict Resolution and Consensus Building](#conflict-resolution-and-consensus-building)
9. [Advanced GroupChat Techniques](#advanced-groupchat-techniques)
10. [Integrating External Knowledge and APIs](#integrating-external-knowledge-and-apis)
11. [Performance Optimization for Multi-Agent Systems](#performance-optimization-for-multi-agent-systems)
12. [Best Practices and Design Patterns](#best-practices-and-design-patterns)
13. [Conclusion](#conclusion)

## 1. Introduction

In this bonus lesson, we'll explore advanced techniques for creating complex, collaborative multi-agent systems using Autogen. We'll build upon the foundational concepts covered in previous lessons and dive into sophisticated agent interactions, dynamic agent creation, and strategies for efficient problem-solving in a multi-agent environment.

## 2. Project Structure

Before we begin, let's look at the project structure for our advanced multi-agent system:

```
advanced_autogen_project/
│
├── agents/
│   ├── __init__.py
│   ├── specialized_agents.py
│   ├── meta_agents.py
│   └── dynamic_agent_factory.py
│
├── interaction_patterns/
│   ├── __init__.py
│   ├── multi_stage_conversation.py
│   └── branching_dialogue.py
│
├── collaboration/
│   ├── __init__.py
│   ├── task_decomposer.py
│   ├── parallel_processor.py
│   └── knowledge_sharing.py
│
├── utils/
│   ├── __init__.py
│   ├── conflict_resolver.py
│   └── external_api_integrator.py
│
├── config/
│   └── agent_config.yaml
│
├── main.py
├── requirements.txt
└── README.md
```

This structure organizes our code into logical modules, making it easier to manage and extend our advanced multi-agent system.

## 3. Advanced Agent Types

### 3.1 Specialized Agents

Let's create specialized agents that excel at specific tasks. These agents will have custom behaviors and capabilities beyond the standard Autogen agents.

```python
# agents/specialized_agents.py
from autogen import ConversableAgent

class DataAnalysisAgent(ConversableAgent):
    def __init__(self, name, **kwargs):
        super().__init__(name, **kwargs)
        self.data_analysis_tools = self._load_data_analysis_tools()

    def _load_data_analysis_tools(self):
        # Load specialized data analysis libraries and tools
        return {
            "pandas": __import__("pandas"),
            "numpy": __import__("numpy"),
            "matplotlib": __import__("matplotlib.pyplot"),
        }

    async def a_generate_reply(self, messages, sender, config):
        if "analyze_data" in messages[-1]["content"]:
            # Perform data analysis using specialized tools
            result = self._analyze_data(messages[-1]["content"])
            return True, f"Data analysis result: {result}"
        return await super().a_generate_reply(messages, sender, config)

    def _analyze_data(self, message):
        # Implement data analysis logic here
        pass

# Usage
data_analyst = DataAnalysisAgent("DataAnalyst")
```

### 3.2 Meta-Agents

Meta-agents can manage and coordinate other agents, making high-level decisions about task allocation and workflow.

```python
# agents/meta_agents.py
from autogen import ConversableAgent

class ProjectManagerAgent(ConversableAgent):
    def __init__(self, name, team, **kwargs):
        super().__init__(name, **kwargs)
        self.team = team
        self.task_queue = []

    async def a_generate_reply(self, messages, sender, config):
        if "new_task" in messages[-1]["content"]:
            task = self._parse_task(messages[-1]["content"])
            assigned_agent = self._assign_task(task)
            return True, f"Task assigned to {assigned_agent.name}: {task}"
        return await super().a_generate_reply(messages, sender, config)

    def _parse_task(self, message):
        # Parse task details from the message
        pass

    def _assign_task(self, task):
        # Assign task to the most suitable agent in the team
        pass

# Usage
team = [DataAnalysisAgent("DataAnalyst"), ConversableAgent("GeneralAssistant")]
project_manager = ProjectManagerAgent("ProjectManager", team)
```

## 4. Complex Interaction Patterns

### 4.1 Multi-Stage Conversations

Implement multi-stage conversations where agents collaborate through a series of predefined stages to solve complex problems.

```python
# interaction_patterns/multi_stage_conversation.py
from autogen import ConversableAgent

class MultiStageConversation:
    def __init__(self, agents, stages):
        self.agents = agents
        self.stages = stages
        self.current_stage = 0

    async def execute(self):
        while self.current_stage < len(self.stages):
            stage = self.stages[self.current_stage]
            agent = self.agents[stage["agent"]]
            message = stage["message"]
            
            response = await agent.a_generate_reply([{"role": "user", "content": message}], None, None)
            
            if stage.get("transition_condition", lambda x: True)(response):
                self.current_stage += 1
            
        return "Multi-stage conversation completed"

# Usage
agents = {
    "analyst": DataAnalysisAgent("DataAnalyst"),
    "manager": ProjectManagerAgent("ProjectManager", [])
}

stages = [
    {"agent": "analyst", "message": "Analyze the latest sales data"},
    {"agent": "manager", "message": "Review the analysis and make recommendations",
     "transition_condition": lambda x: "recommendation" in x[1].lower()},
    {"agent": "analyst", "message": "Implement the recommended changes"}
]

conversation = MultiStageConversation(agents, stages)
result = await conversation.execute()
```

### 4.2 Branching Dialogues

Create branching dialogues where the conversation flow depends on the agents' responses.

```python
# interaction_patterns/branching_dialogue.py
from autogen import ConversableAgent

class BranchingDialogue:
    def __init__(self, root_agent, branches):
        self.root_agent = root_agent
        self.branches = branches

    async def execute(self, initial_message):
        current_agent = self.root_agent
        message = initial_message

        while True:
            response = await current_agent.a_generate_reply([{"role": "user", "content": message}], None, None)
            
            if response[0]:  # If a reply was generated
                for branch in self.branches:
                    if branch["condition"](response[1]):
                        current_agent = branch["agent"]
                        message = branch["message"]
                        break
                else:
                    return "Conversation ended"
            else:
                return "No response generated"

# Usage
root_agent = ConversableAgent("RootAgent")
branch_a = ConversableAgent("BranchA")
branch_b = ConversableAgent("BranchB")

branches = [
    {"condition": lambda x: "option a" in x.lower(), "agent": branch_a, "message": "You chose option A"},
    {"condition": lambda x: "option b" in x.lower(), "agent": branch_b, "message": "You chose option B"}
]

dialogue = BranchingDialogue(root_agent, branches)
result = await dialogue.execute("What option do you prefer, A or B?")
```

## 5. Collaborative Problem Solving

### 5.1 Task Decomposition

Implement a system for breaking down complex tasks into smaller, manageable subtasks that can be distributed among specialized agents.

```python
# collaboration/task_decomposer.py
from autogen import ConversableAgent

class TaskDecomposer(ConversableAgent):
    def __init__(self, name, **kwargs):
        super().__init__(name, **kwargs)

    async def a_generate_reply(self, messages, sender, config):
        if "decompose_task" in messages[-1]["content"]:
            task = messages[-1]["content"].split("decompose_task: ")[1]
            subtasks = self._decompose_task(task)
            return True, f"Task decomposed into subtasks: {subtasks}"
        return await super().a_generate_reply(messages, sender, config)

    def _decompose_task(self, task):
        # Implement task decomposition logic
        # This could involve using the LLM to generate subtasks
        subtasks = [
            "Subtask 1: Gather data",
            "Subtask 2: Analyze data",
            "Subtask 3: Generate report"
        ]
        return subtasks

# Usage
decomposer = TaskDecomposer("TaskDecomposer")
```

### 5.2 Parallel Processing

Implement parallel processing of subtasks for efficient problem-solving.

```python
# collaboration/parallel_processor.py
import asyncio
from autogen import ConversableAgent

class ParallelTaskProcessor:
    def __init__(self, agents):
        self.agents = agents

    async def process_tasks(self, tasks):
        async def process_task(agent, task):
            return await agent.a_generate_reply([{"role": "user", "content": task}], None, None)

        tasks = [process_task(agent, task) for agent, task in zip(self.agents, tasks)]
        results = await asyncio.gather(*tasks)
        return results

# Usage
agents = [ConversableAgent(f"Agent{i}") for i in range(3)]
processor = ParallelTaskProcessor(agents)
tasks = ["Task 1", "Task 2", "Task 3"]
results = await processor.process_tasks(tasks)
```

## 6. Dynamic Agent Creation

Implement a factory for creating agents dynamically based on the current needs of the system.

```python
# agents/dynamic_agent_factory.py
from autogen import ConversableAgent

class DynamicAgentFactory:
    @staticmethod
    def create_agent(agent_type, name, **kwargs):
        if agent_type == "data_analyst":
            return DataAnalysisAgent(name, **kwargs)
        elif agent_type == "project_manager":
            return ProjectManagerAgent(name, **kwargs)
        else:
            return ConversableAgent(name, **kwargs)

# Usage
factory = DynamicAgentFactory()
new_agent = factory.create_agent("data_analyst", "DynamicDataAnalyst")
```

## 7. Inter-Agent Learning and Knowledge Sharing

Implement a mechanism for agents to share knowledge and learn from each other.

```python
# collaboration/knowledge_sharing.py
from autogen import ConversableAgent

class KnowledgeSharingAgent(ConversableAgent):
    def __init__(self, name, **kwargs):
        super().__init__(name, **kwargs)
        self.knowledge_base = {}

    async def a_generate_reply(self, messages, sender, config):
        if "share_knowledge" in messages[-1]["content"]:
            topic, knowledge = self._parse_knowledge(messages[-1]["content"])
            self.knowledge_base[topic] = knowledge
            return True, f"Knowledge about {topic} has been shared and stored"
        elif "request_knowledge" in messages[-1]["content"]:
            topic = messages[-1]["content"].split("request_knowledge: ")[1]
            if topic in self.knowledge_base:
                return True, f"Knowledge about {topic}: {self.knowledge_base[topic]}"
            else:
                return True, f"No knowledge found about {topic}"
        return await super().a_generate_reply(messages, sender, config)

    def _parse_knowledge(self, message):
        # Parse topic and knowledge from the message
        pass

# Usage
agent1 = KnowledgeSharingAgent("Agent1")
agent2 = KnowledgeSharingAgent("Agent2")

# Agent1 shares knowledge
await agent1.a_generate_reply([{"role": "user", "content": "share_knowledge: Python: Python is a versatile programming language"}], None, None)

# Agent2 requests knowledge
result = await agent2.a_generate_reply([{"role": "user", "content": "request_knowledge: Python"}], agent1, None)
```

## 8. Conflict Resolution and Consensus Building

Implement mechanisms for resolving conflicts and building consensus among agents with differing opinions.

```python
# utils/conflict_resolver.py
from autogen import ConversableAgent

class ConflictResolver(ConversableAgent):
    def __init__(self, name, agents, **kwargs):
        super().__init__(name, **kwargs)
        self.agents = agents

    async def resolve_conflict(self, topic):
        opinions = []
        for agent in self.agents:
            opinion = await agent.a_generate_reply([{"role": "user", "content": f"Your opinion on {topic}?"}], None, None)
            opinions.append(opinion[1])

        resolution = await self.a_generate_reply([{"role": "user", "content": f"Resolve conflict on {topic}: {opinions}"}], None, None)
        return resolution[1]

# Usage
agents = [ConversableAgent(f"Agent{i}") for i in range(3)]
resolver = ConflictResolver("ConflictResolver", agents)
resolution = await resolver.resolve_conflict("best programming language")
```

## 9. Advanced GroupChat Techniques

Enhance the GroupChat functionality with dynamic role assignment and topic-based discussions.

```python
# main.py
from autogen import GroupChat, GroupChatManager

class AdvancedGroupChat(GroupChat):
    def __init__(self, agents, dynamic_roles=False, **kwargs):
        super().__init__(agents, **kwargs)
        self.dynamic_roles = dynamic_roles

    def select_speaker(self, last_speaker, message):
        if self.dynamic_roles:
            # Implement dynamic role assignment based on message content
            return self._assign_dynamic_role(message)
        return super().select_speaker(last_speaker, message)

    def _assign_dynamic_role(self, message):
        # Implement logic to assign the most suitable agent based on message content
        pass

# Usage
agents = [DataAnalysisAgent("DataAnalyst"), ProjectManagerAgent("ProjectManager", []), ConversableAgent("GeneralAssistant")]
advanced_group_chat = AdvancedGroupChat(agents, dynamic_roles=True)
manager = GroupChatManager(advanced_group_chat)

result = await manager.a_initiate_chat("Let's discuss the project timeline and data analysis requirements")
```

## 10. Integrating External Knowledge and APIs

To make our multi-agent system more powerful and versatile, we can integrate external knowledge sources and APIs. This allows agents to access up-to-date information and perform actions beyond their built-in capabilities.

### 10.1 External API Integration

Let's create a utility class for integrating external APIs:

```python
# utils/external_api_integrator.py
import aiohttp
from autogen import ConversableAgent

class ExternalAPIIntegrator:
    def __init__(self):
        self.session = None

    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.session.close()

    async def fetch_data(self, url, params=None):
        async with self.session.get(url, params=params) as response:
            return await response.json()

class APIEnabledAgent(ConversableAgent):
    def __init__(self, name, api_integrator, **kwargs):
        super().__init__(name, **kwargs)
        self.api_integrator = api_integrator

    async def a_generate_reply(self, messages, sender, config):
        if "fetch_weather" in messages[-1]["content"]:
            city = messages[-1]["content"].split("fetch_weather: ")[1]
            weather_data = await self.fetch_weather(city)
            return True, f"Weather in {city}: {weather_data}"
        return await super().a_generate_reply(messages, sender, config)

    async def fetch_weather(self, city):
        url = "https://api.openweathermap.org/data/2.5/weather"
        params = {
            "q": city,
            "appid": "YOUR_API_KEY",  # Replace with your actual API key
            "units": "metric"
        }
        data = await self.api_integrator.fetch_data(url, params)
        return f"{data['weather'][0]['description']}, {data['main']['temp']}°C"

# Usage
async with ExternalAPIIntegrator() as api_integrator:
    weather_agent = APIEnabledAgent("WeatherAgent", api_integrator)
    result = await weather_agent.a_generate_reply([{"role": "user", "content": "fetch_weather: London"}], None, None)
    print(result[1])
```

This example demonstrates how to create an agent that can fetch real-time weather data from an external API.

### 10.2 Knowledge Base Integration

We can also integrate external knowledge bases to enhance our agents' capabilities:

```python
# utils/knowledge_base_integrator.py
import sqlite3
from autogen import ConversableAgent

class KnowledgeBaseIntegrator:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()

    def query_knowledge(self, topic):
        self.cursor.execute("SELECT information FROM knowledge_base WHERE topic = ?", (topic,))
        result = self.cursor.fetchone()
        return result[0] if result else None

    def add_knowledge(self, topic, information):
        self.cursor.execute("INSERT OR REPLACE INTO knowledge_base (topic, information) VALUES (?, ?)", (topic, information))
        self.conn.commit()

    def close(self):
        self.conn.close()

class KnowledgeEnhancedAgent(ConversableAgent):
    def __init__(self, name, knowledge_base, **kwargs):
        super().__init__(name, **kwargs)
        self.knowledge_base = knowledge_base

    async def a_generate_reply(self, messages, sender, config):
        if "query_knowledge" in messages[-1]["content"]:
            topic = messages[-1]["content"].split("query_knowledge: ")[1]
            knowledge = self.knowledge_base.query_knowledge(topic)
            if knowledge:
                return True, f"Knowledge about {topic}: {knowledge}"
            else:
                return True, f"No knowledge found about {topic}"
        elif "add_knowledge" in messages[-1]["content"]:
            parts = messages[-1]["content"].split("add_knowledge: ")[1].split(" | ")
            topic, information = parts[0], parts[1]
            self.knowledge_base.add_knowledge(topic, information)
            return True, f"Added knowledge about {topic}"
        return await super().a_generate_reply(messages, sender, config)

# Usage
kb_integrator = KnowledgeBaseIntegrator("knowledge.db")
enhanced_agent = KnowledgeEnhancedAgent("EnhancedAgent", kb_integrator)

# Add knowledge
await enhanced_agent.a_generate_reply([{"role": "user", "content": "add_knowledge: Python | Python is a high-level programming language"}], None, None)

# Query knowledge
result = await enhanced_agent.a_generate_reply([{"role": "user", "content": "query_knowledge: Python"}], None, None)
print(result[1])

kb_integrator.close()
```

This example shows how to create an agent that can query and update a SQLite-based knowledge base.

## 11. Performance Optimization for Multi-Agent Systems

As multi-agent systems grow in complexity, it's important to optimize their performance. Here are some techniques:

### 11.1 Caching

Implement a caching mechanism to store and reuse frequently accessed information:

```python
# utils/cache.py
from functools import lru_cache
from autogen import ConversableAgent

class CachedAgent(ConversableAgent):
    def __init__(self, name, **kwargs):
        super().__init__(name, **kwargs)

    @lru_cache(maxsize=100)
    def cached_operation(self, input_data):
        # Perform expensive operation here
        return f"Processed: {input_data}"

    async def a_generate_reply(self, messages, sender, config):
        if "process_data" in messages[-1]["content"]:
            data = messages[-1]["content"].split("process_data: ")[1]
            result = self.cached_operation(data)
            return True, result
        return await super().a_generate_reply(messages, sender, config)

# Usage
cached_agent = CachedAgent("CachedAgent")
result1 = await cached_agent.a_generate_reply([{"role": "user", "content": "process_data: example"}], None, None)
result2 = await cached_agent.a_generate_reply([{"role": "user", "content": "process_data: example"}], None, None)
# The second call will use the cached result
```

### 11.2 Asynchronous Processing

Utilize asynchronous programming to improve the overall system responsiveness:

```python
# main.py
import asyncio
from autogen import ConversableAgent

async def process_multiple_agents(agents, message):
    tasks = [agent.a_generate_reply([{"role": "user", "content": message}], None, None) for agent in agents]
    results = await asyncio.gather(*tasks)
    return results

# Usage
agents = [ConversableAgent(f"Agent{i}") for i in range(5)]
results = await process_multiple_agents(agents, "Perform your specific task")
```

## 12. Best Practices and Design Patterns

When working with advanced multi-agent systems in Autogen, consider the following best practices and design patterns:

1. **Separation of Concerns**: Keep agent definitions, interaction patterns, and utility functions in separate modules for better organization and reusability.

2. **Configuration Management**: Use configuration files (e.g., YAML) to manage agent properties and system settings:

```python
# config/agent_config.yaml
agents:
  - name: DataAnalyst
    type: DataAnalysisAgent
    tools:
      - pandas
      - numpy
      - matplotlib
  - name: ProjectManager
    type: ProjectManagerAgent
    team_size: 5

# main.py
import yaml
from agents.dynamic_agent_factory import DynamicAgentFactory

with open("config/agent_config.yaml", "r") as config_file:
    config = yaml.safe_load(config_file)

factory = DynamicAgentFactory()
agents = [factory.create_agent(agent["type"], agent["name"], **agent) for agent in config["agents"]]
```

3. **Error Handling and Logging**: Implement robust error handling and logging mechanisms:

```python
# utils/logging.py
import logging

def setup_logging():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# main.py
from utils.logging import setup_logging

setup_logging()
logger = logging.getLogger(__name__)

try:
    # Your multi-agent system code here
    pass
except Exception as e:
    logger.error(f"An error occurred: {str(e)}", exc_info=True)
```

4. **Modular Design**: Design your system with modularity in mind, allowing for easy addition or removal of agents and functionalities:

```python
# main.py
class MultiAgentSystem:
    def __init__(self):
        self.agents = {}
        self.interaction_patterns = {}

    def add_agent(self, agent):
        self.agents[agent.name] = agent

    def add_interaction_pattern(self, name, pattern):
        self.interaction_patterns[name] = pattern

    async def run_interaction(self, pattern_name, *args, **kwargs):
        if pattern_name in self.interaction_patterns:
            return await self.interaction_patterns[pattern_name].execute(*args, **kwargs)
        else:
            raise ValueError(f"Interaction pattern {pattern_name} not found")

# Usage
system = MultiAgentSystem()
system.add_agent(DataAnalysisAgent("DataAnalyst"))
system.add_agent(ProjectManagerAgent("ProjectManager", []))
system.add_interaction_pattern("multi_stage", MultiStageConversation(system.agents, stages))

result = await system.run_interaction("multi_stage")
```

5. **Testing**: Implement comprehensive unit tests and integration tests for your multi-agent system:

```python
# tests/test_agents.py
import unittest
from unittest.mock import AsyncMock, patch
from agents.specialized_agents import DataAnalysisAgent

class TestDataAnalysisAgent(unittest.TestCase):
    def setUp(self):
        self.agent = DataAnalysisAgent("TestDataAnalyst")

    @patch("agents.specialized_agents.DataAnalysisAgent._analyze_data")
    async def test_generate_reply(self, mock_analyze_data):
        mock_analyze_data.return_value = "Mocked analysis result"
        messages = [{"role": "user", "content": "analyze_data: sample_data.csv"}]
        
        result = await self.agent.a_generate_reply(messages, None, None)
        
        self.assertTrue(result[0])
        self.assertIn("Mocked analysis result", result[1])
        mock_analyze_data.assert_called_once_with("sample_data.csv")

if __name__ == "__main__":
    unittest.main()
```

## 13. Conclusion

In this bonus lesson, we've explored advanced techniques for creating sophisticated multi-agent systems using Autogen. We've covered topics such as specialized agents, complex interaction patterns, collaborative problem-solving, dynamic agent creation, knowledge sharing, and integration with external APIs and knowledge bases.

By applying these advanced concepts and best practices, you can build powerful, flexible, and efficient multi-agent systems capable of tackling complex tasks and problems. Remember to always consider the specific requirements of your project and adapt these techniques accordingly.

As you continue to work with Autogen, keep exploring new ways to enhance agent capabilities, optimize system performance, and create innovative solutions to challenging problems in the field of AI and automation.
```

# bonus-lesson-3-advanced-autogen-customization.md

```
# Bonus Lesson 3: Advanced Autogen Customization and Extensibility

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Custom Agent Behaviors](#custom-agent-behaviors)
   3.1 [Extending ConversableAgent](#extending-conversableagent)
   3.2 [Custom Message Processing](#custom-message-processing)
4. [Advanced Configuration Management](#advanced-configuration-management)
   4.1 [Dynamic Configuration Loading](#dynamic-configuration-loading)
   4.2 [Environment-specific Configurations](#environment-specific-configurations)
5. [Plugin Architecture](#plugin-architecture)
   5.1 [Creating Plugins](#creating-plugins)
   5.2 [Plugin Management](#plugin-management)
6. [Custom LLM Integrations](#custom-llm-integrations)
   6.1 [Implementing a Custom LLM Client](#implementing-a-custom-llm-client)
   6.2 [Advanced Prompt Engineering](#advanced-prompt-engineering)
7. [Event System and Hooks](#event-system-and-hooks)
   7.1 [Implementing an Event System](#implementing-an-event-system)
   7.2 [Using Hooks for Extensibility](#using-hooks-for-extensibility)
8. [Advanced Logging and Monitoring](#advanced-logging-and-monitoring)
   8.1 [Custom Logging Solutions](#custom-logging-solutions)
   8.2 [Real-time Monitoring](#real-time-monitoring)
9. [Performance Optimization Techniques](#performance-optimization-techniques)
   9.1 [Caching Strategies](#caching-strategies)
   9.2 [Parallel Processing](#parallel-processing)
10. [Security Enhancements](#security-enhancements)
    10.1 [Input Sanitization](#input-sanitization)
    10.2 [Access Control](#access-control)
11. [Best Practices and Design Patterns](#best-practices-and-design-patterns)
12. [Conclusion](#conclusion)

## 1. Introduction

Welcome to our bonus lesson on Advanced Autogen Customization and Extensibility. In this lesson, we'll explore advanced techniques to customize and extend Autogen's functionality, allowing you to create more powerful and flexible AI-powered applications. We'll cover topics such as creating custom agent behaviors, implementing plugin architectures, and optimizing performance for complex scenarios.

## 2. Project Structure

Before we dive into the details, let's look at a typical project structure for an advanced Autogen application:

```
advanced_autogen_project/
│
├── agents/
│   ├── __init__.py
│   ├── custom_assistant.py
│   └── custom_user_proxy.py
│
├── configs/
│   ├── __init__.py
│   ├── base_config.py
│   ├── development.py
│   └── production.py
│
├── plugins/
│   ├── __init__.py
│   ├── plugin_manager.py
│   ├── custom_tool_plugin.py
│   └── data_analysis_plugin.py
│
├── llm/
│   ├── __init__.py
│   ├── custom_llm_client.py
│   └── prompt_templates.py
│
├── utils/
│   ├── __init__.py
│   ├── event_system.py
│   ├── logging_utils.py
│   └── performance_utils.py
│
├── main.py
├── requirements.txt
└── README.md
```

This structure organizes our advanced Autogen application into logical components, making it easier to manage and extend.

## 3. Custom Agent Behaviors

### 3.1 Extending ConversableAgent

To create agents with custom behaviors, we can extend the `ConversableAgent` class. Let's create a `CustomAssistant` with advanced capabilities:

```python
# agents/custom_assistant.py
from autogen import ConversableAgent

class CustomAssistant(ConversableAgent):
    def __init__(self, name, system_message, *args, **kwargs):
        super().__init__(name, system_message, *args, **kwargs)
        self.conversation_history = []

    def generate_reply(self, messages, sender, config):
        # Custom logic for generating replies
        reply = super().generate_reply(messages, sender, config)
        self.conversation_history.append((sender.name, messages[-1]))
        self.conversation_history.append((self.name, reply))
        return reply

    def analyze_conversation(self):
        # Custom method to analyze the conversation history
        # Implementation details...
        pass
```

### 3.2 Custom Message Processing

Implement custom message processing to handle complex scenarios:

```python
# agents/custom_user_proxy.py
from autogen import UserProxyAgent

class CustomUserProxy(UserProxyAgent):
    def __init__(self, name, *args, **kwargs):
        super().__init__(name, *args, **kwargs)
        self.custom_data = {}

    def process_received_message(self, message, sender):
        # Custom message processing logic
        processed_message = self._preprocess_message(message)
        super().process_received_message(processed_message, sender)

    def _preprocess_message(self, message):
        # Custom preprocessing logic
        # Example: Extract and store custom data
        if "custom_data" in message:
            self.custom_data.update(message["custom_data"])
            del message["custom_data"]
        return message
```

## 4. Advanced Configuration Management

### 4.1 Dynamic Configuration Loading

Implement a system for dynamically loading configurations:

```python
# configs/base_config.py
class BaseConfig:
    DEBUG = False
    LLM_MODEL = "gpt-3.5-turbo"
    MAX_TOKENS = 1000

# configs/development.py
from .base_config import BaseConfig

class DevelopmentConfig(BaseConfig):
    DEBUG = True
    LLM_MODEL = "gpt-3.5-turbo"

# configs/production.py
from .base_config import BaseConfig

class ProductionConfig(BaseConfig):
    LLM_MODEL = "gpt-4"
    MAX_TOKENS = 2000

# utils/config_loader.py
import os
from importlib import import_module

def load_config():
    env = os.environ.get("AUTOGEN_ENV", "development")
    module = import_module(f"configs.{env}")
    return getattr(module, f"{env.capitalize()}Config")
```

### 4.2 Environment-specific Configurations

Use the dynamic configuration loader in your main application:

```python
# main.py
from utils.config_loader import load_config

config = load_config()
print(f"Using LLM Model: {config.LLM_MODEL}")
```

## 5. Plugin Architecture

### 5.1 Creating Plugins

Implement a plugin system for extensibility:

```python
# plugins/plugin_manager.py
class PluginManager:
    def __init__(self):
        self.plugins = {}

    def register_plugin(self, name, plugin):
        self.plugins[name] = plugin

    def get_plugin(self, name):
        return self.plugins.get(name)

# plugins/custom_tool_plugin.py
class CustomToolPlugin:
    def __init__(self):
        self.name = "custom_tool"

    def execute(self, *args, **kwargs):
        # Custom tool logic
        pass

# main.py
from plugins.plugin_manager import PluginManager
from plugins.custom_tool_plugin import CustomToolPlugin

plugin_manager = PluginManager()
plugin_manager.register_plugin("custom_tool", CustomToolPlugin())
```

### 5.2 Plugin Management

Use plugins in your agents:

```python
# agents/custom_assistant.py
class CustomAssistant(ConversableAgent):
    def __init__(self, name, system_message, plugin_manager, *args, **kwargs):
        super().__init__(name, system_message, *args, **kwargs)
        self.plugin_manager = plugin_manager

    def use_tool(self, tool_name, *args, **kwargs):
        tool = self.plugin_manager.get_plugin(tool_name)
        if tool:
            return tool.execute(*args, **kwargs)
        else:
            raise ValueError(f"Tool {tool_name} not found")
```

## 6. Custom LLM Integrations

### 6.1 Implementing a Custom LLM Client

Create a custom LLM client for specific needs:

```python
# llm/custom_llm_client.py
from autogen.oai.client import ModelClient

class CustomLLMClient(ModelClient):
    def __init__(self, model_name, api_key):
        self.model_name = model_name
        self.api_key = api_key

    def create(self, messages, stream=False, **kwargs):
        # Implement custom API call logic
        # Return response in the expected format
        pass

    def message_retrieval(self, response):
        # Implement custom message extraction logic
        pass

    def cost(self, response):
        # Implement custom cost calculation
        pass

# main.py
from llm.custom_llm_client import CustomLLMClient

custom_llm = CustomLLMClient("custom-model", "your-api-key")
```

### 6.2 Advanced Prompt Engineering

Implement a system for managing and optimizing prompts:

```python
# llm/prompt_templates.py
from string import Template

class PromptTemplate:
    def __init__(self, template):
        self.template = Template(template)

    def format(self, **kwargs):
        return self.template.safe_substitute(**kwargs)

# Usage
analysis_prompt = PromptTemplate(
    "Analyze the following data: ${data}\n"
    "Provide insights on: ${aspects}"
)

formatted_prompt = analysis_prompt.format(
    data="Sample data here",
    aspects="trends, anomalies, correlations"
)
```

## 7. Event System and Hooks

### 7.1 Implementing an Event System

Create a simple event system for inter-agent communication:

```python
# utils/event_system.py
class EventSystem:
    def __init__(self):
        self.listeners = {}

    def subscribe(self, event_type, callback):
        if event_type not in self.listeners:
            self.listeners[event_type] = []
        self.listeners[event_type].append(callback)

    def publish(self, event_type, data):
        if event_type in self.listeners:
            for callback in self.listeners[event_type]:
                callback(data)

# Usage
event_system = EventSystem()

def on_message_received(data):
    print(f"Message received: {data}")

event_system.subscribe("message_received", on_message_received)
event_system.publish("message_received", "Hello, Autogen!")
```

### 7.2 Using Hooks for Extensibility

Implement hooks in your custom agents:

```python
# agents/custom_assistant.py
class CustomAssistant(ConversableAgent):
    def __init__(self, name, system_message, *args, **kwargs):
        super().__init__(name, system_message, *args, **kwargs)
        self.hooks = {
            "pre_reply": [],
            "post_reply": []
        }

    def add_hook(self, hook_type, callback):
        if hook_type in self.hooks:
            self.hooks[hook_type].append(callback)

    def generate_reply(self, messages, sender, config):
        for hook in self.hooks["pre_reply"]:
            messages = hook(messages)

        reply = super().generate_reply(messages, sender, config)

        for hook in self.hooks["post_reply"]:
            reply = hook(reply)

        return reply

# Usage
def log_messages(messages):
    print(f"Received messages: {messages}")
    return messages

custom_assistant = CustomAssistant("Custom", "I am a custom assistant.")
custom_assistant.add_hook("pre_reply", log_messages)
```

## 8. Advanced Logging and Monitoring

### 8.1 Custom Logging Solutions

Implement a custom logging solution:

```python
# utils/logging_utils.py
import logging
import json
from datetime import datetime

class CustomJSONFormatter(logging.Formatter):
    def format(self, record):
        log_record = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno
        }
        return json.dumps(log_record)

def setup_logger(name, level=logging.INFO):
    logger = logging.getLogger(name)
    logger.setLevel(level)

    handler = logging.StreamHandler()
    handler.setFormatter(CustomJSONFormatter())
    logger.addHandler(handler)

    return logger

# Usage
logger = setup_logger("autogen_app")
logger.info("Application started")
```

### 8.2 Real-time Monitoring

Implement a basic real-time monitoring system:

```python
# utils/monitoring.py
import time
from threading import Thread

class Monitor:
    def __init__(self, interval=60):
        self.interval = interval
        self.stats = {}
        self._running = False

    def start(self):
        self._running = True
        Thread(target=self._run).start()

    def stop(self):
        self._running = False

    def _run(self):
        while self._running:
            self._collect_stats()
            time.sleep(self.interval)

    def _collect_stats(self):
        # Implement stats collection logic
        self.stats["timestamp"] = time.time()
        self.stats["active_agents"] = 5  # Example stat

    def get_stats(self):
        return self.stats

# Usage
monitor = Monitor(interval=30)
monitor.start()

# In your application
stats = monitor.get_stats()
print(f"Current stats: {stats}")

# When shutting down
monitor.stop()
```

## 9. Performance Optimization Techniques

### 9.1 Caching Strategies

Implement a caching system for expensive operations:

```python
# utils/performance_utils.py
from functools import lru_cache
import time

def timed_lru_cache(seconds: int, maxsize: int = 128):
    def wrapper_cache(func):
        func = lru_cache(maxsize=maxsize)(func)
        func.lifetime = seconds
        func.expiration = time.time() + func.lifetime

        @wraps(func)
        def wrapped_func(*args, **kwargs):
            if time.time() >= func.expiration:
                func.cache_clear()
                func.expiration = time.time() + func.lifetime

            return func(*args, **kwargs)

        return wrapped_func

    return wrapper_cache

# Usage
@timed_lru_cache(seconds=300)
def expensive_operation(x, y):
    # Simulate an expensive operation
    time.sleep(2)
    return x + y

result = expensive_operation(5, 7)  # Takes 2 seconds
result = expensive_operation(5, 7)  # Instant (cached)
```

### 9.2 Parallel Processing

Implement parallel processing for computationally intensive tasks:

```python
# utils/performance_utils.py
from concurrent.futures import ThreadPoolExecutor, as_completed

def parallel_map(func, iterable, max_workers=None):
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(func, item) for item in iterable]
        results = []
        for future in as_completed(futures):
            results.append(future.result())
    return results

# Usage
def process_data(item):
    # Simulate data processing
    time.sleep(1)
    return item * 2

data = [1, 2, 3, 4, 5]
results = parallel_map(process_data, data)
print(f"Processed data: {results}")
```

## 10. Security Enhancements

### 10.1 Input Sanitization

Implement input sanitization to prevent injection attacks:

```python
# utils/security_utils.py
import re
import html

def sanitize_input(input_string):
    # Remove any potential HTML or script tags
    cleaned = re.sub(r'<[^>]*?>', '', input_string)
    # Escape special characters
    cleaned = html.escape(cleaned)
    return cleaned

# Usage
user_input = "<script>alert('XSS');</script>Hello, world!"
safe_input = sanitize_input(user_input)
print(f"Sanitized input: {safe_input}")
```

### 10.2 Access Control

Implement a simple access control system:

```python
# utils/security_utils.py
from functools import wraps

class AccessControl:
    def __init__(self):
        self.permissions = {}

    def add_permission(self, user, permission):
        if user not in self.permissions:
            self.permissions[user] = set()
        self.permissions[user].add(permission)

    def check_permission(self, user, permission):
        return user in self.permissions and permission in self.permissions[user]

access_control = AccessControl()

def require_permission(permission):
    def decorator(func):
        @wraps(func)
        def wrapper(user, *args, **kwargs):
            if access_control.check_permission(user, permission):
                return func(user, *args, **kwargs)
            else:
                raise PermissionError(f"User {user} does not have {permission} permission")
        return wrapper
    return decorator

# Usage
access_control.add_permission("admin", "read_logs")

@require_permission("read_logs")
def read_system_logs(user):
    print(f"User {user} is reading system logs")

read_system_logs("admin")  # Works
try:
    read_system_logs("guest")  # Raises PermissionError
except PermissionError as e:
    print(e)
```

## 11. Best Practices and Design Patterns

When customizing and extending Autogen, keep these best practices in mind:

1. **Modular Design**: Organize your code into modules and packages for better maintainability and reusability.

2. **Configuration Management**: Use a robust configuration system to manage different environments and settings.

3. **Separation of Concerns**: Keep different functionalities (e.g., agent logic, LLM integration, plugins) separate and well-defined.

4. **Error Handling**: Implement comprehensive error handling and logging to make debugging easier.

5. **Testing**: Write unit tests and integration tests for your custom components to ensure reliability.

6. **Documentation**: Maintain clear and up-to-date documentation for your custom features and extensions.

7. **Version Control**: Use version control (e.g., Git) to track changes and collaborate with others.

8. **Performance Monitoring**: Implement monitoring and profiling to identify and address performance bottlenecks.

9. **Security First**: Always consider security implications when extending functionality, especially when dealing with user inputs or external integrations.

10. **Scalability**: Design your extensions with scalability in mind, considering potential future growth and increased load.

## 12. Conclusion

In this bonus lesson, we've explored advanced techniques for customizing and extending Autogen. We've covered topics such as creating custom agent behaviors, implementing plugin architectures, optimizing performance, and enhancing security. By applying these concepts, you can create more powerful, flexible, and secure AI-powered applications using Autogen.

Remember that customization and extensibility often come with increased complexity. Always strive for a balance between adding new features and maintaining code clarity and maintainability. As you continue to work with Autogen, keep exploring new ways to enhance its capabilities while adhering to best practices in software development.

Happy coding, and may your Autogen projects be ever more sophisticated and impactful!

```

# lesson-1-introduction-to-autogen.md

```
# Lesson 1: Introduction to Autogen - Overview and Basic Usage

## Table of Contents
1. [What is Autogen?](#what-is-autogen)
2. [Why is Autogen Useful?](#why-is-autogen-useful)
3. [Installing and Setting Up Autogen](#installing-and-setting-up-autogen)
4. [Basic Concepts](#basic-concepts)
   - [Agents](#agents)
   - [Conversations](#conversations)
   - [Tasks](#tasks)
5. [Simple Example: Creating a Conversation Between Two Agents](#simple-example-creating-a-conversation-between-two-agents)
6. [Project Structure](#project-structure)
7. [Conclusion](#conclusion)

## What is Autogen?

Autogen is a powerful framework for building AI-powered applications and automating complex tasks. It provides a flexible and extensible platform for creating conversational AI agents that can interact with each other and with humans. Autogen is designed to simplify the process of developing AI applications by abstracting away many of the complexities of working with large language models (LLMs) and providing a high-level API for creating intelligent agents.

## Why is Autogen Useful?

Autogen offers several key benefits that make it an invaluable tool for AI developers and researchers:

1. **Simplified Agent Creation**: Autogen provides pre-built agent types and easy-to-use APIs for creating custom agents, reducing the time and effort required to develop AI applications.

2. **Flexible Conversation Management**: The framework offers robust support for managing complex conversations between multiple agents and humans, enabling sophisticated dialogue systems.

3. **Code Execution Capabilities**: Autogen includes built-in support for executing code, allowing agents to perform computational tasks and interact with external systems.

4. **Integration with Popular LLMs**: It seamlessly integrates with various language models, including OpenAI's GPT models, making it easy to leverage state-of-the-art AI in your applications.

5. **Extensibility**: Autogen's modular design allows for easy extension and customization, enabling developers to add new capabilities and integrate with external services.

## Installing and Setting Up Autogen

To get started with Autogen, you'll need to install it using pip. Open your terminal and run the following command:

```bash
pip install pyautogen
```

It's recommended to use a virtual environment to avoid conflicts with other Python packages. Here's how you can set up a virtual environment and install Autogen:

```bash
# Create a new virtual environment
python -m venv autogen_env

# Activate the virtual environment
# On Windows:
autogen_env\Scripts\activate
# On macOS and Linux:
source autogen_env/bin/activate

# Install Autogen
pip install pyautogen
```

## Basic Concepts

Before we dive into a practical example, let's review the core concepts in Autogen:

### Agents

Agents are the fundamental building blocks in Autogen. They represent entities capable of performing actions, processing information, and engaging in conversations. Autogen provides several types of agents:

1. **AssistantAgent**: An AI-powered agent that can understand and generate human-like text based on the conversation context.
2. **UserProxyAgent**: An agent that can represent a human user, execute code, and provide feedback to other agents.
3. **ConversableAgent**: A base class for creating custom agents with specific behaviors and capabilities.

### Conversations

Conversations in Autogen represent the exchange of messages between agents. They can be one-on-one interactions or involve multiple agents in a group chat. Autogen provides mechanisms for initiating, managing, and terminating conversations.

### Tasks

Tasks in Autogen represent specific objectives or goals that agents work towards. They can range from simple question-answering to complex problem-solving scenarios involving multiple steps and agents.

## Simple Example: Creating a Conversation Between Two Agents

Let's create a simple example to demonstrate how to use Autogen to create a conversation between two agents: an AssistantAgent and a UserProxyAgent.

First, create a new Python file called `autogen_example.py` in your project directory. Here's the project structure:

```
autogen_project/
│
├── autogen_env/
└── autogen_example.py
```

Now, let's write the code for our example:

```python
# autogen_example.py

import autogen

# Configure the AssistantAgent
assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={
        "config_list": [{"model": "gpt-3.5-turbo", "api_key": "your_api_key_here"}],
    }
)

# Configure the UserProxyAgent
user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={"work_dir": "coding"},
)

# Start the conversation
user_proxy.initiate_chat(
    assistant,
    message="Hello! Can you explain what Autogen is and how it can be used in AI development?",
)
```

Let's break down this example:

1. We import the `autogen` module.
2. We create an `AssistantAgent` named "AI_Assistant" and configure it to use the GPT-3.5-turbo model. Replace `"your_api_key_here"` with your actual OpenAI API key.
3. We create a `UserProxyAgent` named "Human" to represent the user in the conversation. We configure it to terminate the conversation when the message ends with "TERMINATE" and set up a directory for code execution.
4. We initiate the chat between the user proxy and the assistant, starting with a question about Autogen.

To run this example, execute the following command in your terminal:

```bash
python autogen_example.py
```

You'll see the conversation unfold in your terminal, with the AI Assistant explaining Autogen and its uses in AI development. The conversation will continue until you type a message ending with "TERMINATE".

## Project Structure

As your Autogen project grows, you might want to organize it into a more structured layout. Here's an example of how you could structure a larger Autogen project:

```
autogen_project/
│
├── autogen_env/
├── src/
│   ├── __init__.py
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── custom_assistant.py
│   │   └── custom_user_proxy.py
│   ├── conversations/
│   │   ├── __init__.py
│   │   └── chat_manager.py
│   └── utils/
│       ├── __init__.py
│       └── config_loader.py
├── examples/
│   ├── simple_chat.py
│   └── multi_agent_task.py
├── tests/
│   ├── __init__.py
│   ├── test_agents.py
│   └── test_conversations.py
├── config/
│   └── api_config.json
├── requirements.txt
└── README.md
```

This structure separates your code into logical components:

- `src/`: Contains the main source code for your project.
  - `agents/`: Custom agent implementations.
  - `conversations/`: Modules for managing conversations.
  - `utils/`: Utility functions and helpers.
- `examples/`: Example scripts showcasing different Autogen features.
- `tests/`: Unit tests for your project.
- `config/`: Configuration files, such as API keys and model settings.
- `requirements.txt`: List of project dependencies.
- `README.md`: Project documentation.

## Conclusion

In this introduction to Autogen, we've covered the basics of what Autogen is, why it's useful, and how to get started with a simple conversation between two agents. We've also looked at a sample project structure for organizing larger Autogen projects.

Autogen provides a powerful framework for building AI-powered applications, enabling developers to create sophisticated conversational agents and automate complex tasks. As you continue to explore Autogen, you'll discover its full potential in areas such as task automation, multi-agent systems, and AI-assisted software development.

In the next lesson, we'll dive deeper into Autogen's architecture and explore its core components in more detail.


```

# lesson-10-advanced-topics.md

```
# Lesson 10: Advanced Topics in Autogen Development

## Table of Contents
1. [Introduction](#introduction)
2. [Implementing Custom LLM-Powered Features](#implementing-custom-llm-powered-features)
3. [Fine-Tuning Language Models for Specific Tasks](#fine-tuning-language-models-for-specific-tasks)
4. [Integrating Autogen with Other AI Frameworks](#integrating-autogen-with-other-ai-frameworks)
5. [Cutting-Edge Research and Future Directions](#cutting-edge-research-and-future-directions)
6. [Conclusion](#conclusion)

## Introduction

Welcome to Lesson 10 of our Autogen series! In this advanced lesson, we'll explore cutting-edge techniques and developments in Autogen, pushing the boundaries of what's possible with this powerful framework. We'll cover implementing custom LLM-powered features, fine-tuning models for specific tasks, integrating Autogen with other AI frameworks, and discuss future research directions.

Before we dive in, let's take a look at the project structure we'll be working with:

```
autogen_advanced/
│
├── src/
│   ├── custom_features/
│   │   ├── __init__.py
│   │   ├── semantic_search.py
│   │   └── text_summarizer.py
│   │
│   ├── fine_tuning/
│   │   ├── __init__.py
│   │   ├── data_preparation.py
│   │   └── model_tuner.py
│   │
│   ├── integrations/
│   │   ├── __init__.py
│   │   ├── huggingface_integration.py
│   │   └── langchain_integration.py
│   │
│   └── research/
│       ├── __init__.py
│       └── multi_agent_learning.py
│
├── tests/
│   ├── test_custom_features.py
│   ├── test_fine_tuning.py
│   ├── test_integrations.py
│   └── test_research.py
│
├── requirements.txt
└── main.py
```

This structure organizes our advanced Autogen project into distinct modules for custom features, fine-tuning, integrations, and research. Let's explore each section in detail.

## Implementing Custom LLM-Powered Features

Autogen provides a flexible framework for implementing custom LLM-powered features. We'll demonstrate this by creating two custom features: a semantic search engine and a text summarizer.

### Semantic Search Engine

Let's implement a semantic search engine using Autogen and a pre-trained sentence transformer model.

```python
# src/custom_features/semantic_search.py

import autogen
from sentence_transformers import SentenceTransformer
import numpy as np

class SemanticSearchEngine:
    def __init__(self, model_name='all-MiniLM-L6-v2'):
        self.model = SentenceTransformer(model_name)
        self.documents = []
        self.embeddings = []

    def add_documents(self, documents):
        self.documents.extend(documents)
        new_embeddings = self.model.encode(documents)
        self.embeddings.extend(new_embeddings)

    def search(self, query, top_k=5):
        query_embedding = self.model.encode([query])[0]
        scores = np.dot(self.embeddings, query_embedding)
        top_results = np.argsort(scores)[-top_k:][::-1]
        return [(self.documents[i], scores[i]) for i in top_results]

# Usage in an Autogen agent
class SemanticSearchAgent(autogen.ConversableAgent):
    def __init__(self, name, search_engine):
        super().__init__(name)
        self.search_engine = search_engine

    def search(self, query):
        results = self.search_engine.search(query)
        return [f"{doc} (Score: {score:.2f})" for doc, score in results]

# Example usage
search_engine = SemanticSearchEngine()
search_engine.add_documents([
    "Autogen is a framework for building AI agents",
    "Python is a popular programming language",
    "Machine learning is a subset of artificial intelligence"
])

search_agent = SemanticSearchAgent("SearchBot", search_engine)
human_proxy = autogen.UserProxyAgent("Human")

human_proxy.initiate_chat(search_agent, message="Tell me about Autogen")
```

This example demonstrates how to create a custom semantic search feature and integrate it into an Autogen agent. The `SemanticSearchEngine` class uses a pre-trained sentence transformer to encode documents and perform similarity searches. The `SemanticSearchAgent` wraps this functionality in an Autogen-compatible interface.

### Text Summarizer

Now, let's implement a text summarizer using Autogen and the Hugging Face Transformers library.

```python
# src/custom_features/text_summarizer.py

import autogen
from transformers import pipeline

class TextSummarizerAgent(autogen.ConversableAgent):
    def __init__(self, name, model_name="facebook/bart-large-cnn"):
        super().__init__(name)
        self.summarizer = pipeline("summarization", model=model_name)

    def summarize(self, text, max_length=150, min_length=50):
        summary = self.summarizer(text, max_length=max_length, min_length=min_length, do_sample=False)
        return summary[0]['summary_text']

# Example usage
summarizer_agent = TextSummarizerAgent("SummarizerBot")
human_proxy = autogen.UserProxyAgent("Human")

text_to_summarize = """
Autogen is an open-source framework for building large language model (LLM) applications using multiple agents. 
It provides a flexible and extensible platform for creating conversational AI systems, automating complex tasks, 
and developing advanced natural language processing applications. With Autogen, developers can easily create 
custom agents, define their behaviors, and orchestrate multi-agent conversations to solve complex problems.
"""

human_proxy.initiate_chat(summarizer_agent, message=f"Summarize this text: {text_to_summarize}")
```

This example shows how to create a text summarization agent using a pre-trained model from Hugging Face. The `TextSummarizerAgent` encapsulates the summarization functionality and can be easily integrated into Autogen workflows.

## Fine-Tuning Language Models for Specific Tasks

Fine-tuning language models can significantly improve their performance on specific tasks. Let's explore how to fine-tune a model using Autogen and the Hugging Face Transformers library.

```python
# src/fine_tuning/data_preparation.py

import pandas as pd
from sklearn.model_selection import train_test_split
from transformers import AutoTokenizer

def prepare_data(csv_file, text_column, label_column, model_name, max_length=512):
    df = pd.read_csv(csv_file)
    train_texts, val_texts, train_labels, val_labels = train_test_split(
        df[text_column], df[label_column], test_size=0.2
    )
    
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    
    train_encodings = tokenizer(list(train_texts), truncation=True, padding=True, max_length=max_length)
    val_encodings = tokenizer(list(val_texts), truncation=True, padding=True, max_length=max_length)
    
    return train_encodings, val_encodings, train_labels, val_labels

# src/fine_tuning/model_tuner.py

import autogen
from transformers import AutoModelForSequenceClassification, TrainingArguments, Trainer
import torch
from torch.utils.data import Dataset

class TextClassificationDataset(Dataset):
    def __init__(self, encodings, labels):
        self.encodings = encodings
        self.labels = labels

    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        item['labels'] = torch.tensor(self.labels[idx])
        return item

    def __len__(self):
        return len(self.labels)

class ModelTuner:
    def __init__(self, model_name, num_labels):
        self.model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=num_labels)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)

    def fine_tune(self, train_dataset, val_dataset, output_dir, num_epochs=3):
        training_args = TrainingArguments(
            output_dir=output_dir,
            num_train_epochs=num_epochs,
            per_device_train_batch_size=8,
            per_device_eval_batch_size=8,
            warmup_steps=500,
            weight_decay=0.01,
            logging_dir='./logs',
        )

        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=val_dataset
        )

        trainer.train()
        trainer.save_model()

# Usage in main.py

from src.fine_tuning.data_preparation import prepare_data
from src.fine_tuning.model_tuner import ModelTuner, TextClassificationDataset

# Prepare data
train_encodings, val_encodings, train_labels, val_labels = prepare_data(
    'path/to/your/data.csv', 'text_column', 'label_column', 'bert-base-uncased'
)

# Create datasets
train_dataset = TextClassificationDataset(train_encodings, train_labels)
val_dataset = TextClassificationDataset(val_encodings, val_labels)

# Fine-tune the model
tuner = ModelTuner('bert-base-uncased', num_labels=2)
tuner.fine_tune(train_dataset, val_dataset, './fine_tuned_model')

# Use the fine-tuned model in an Autogen agent
class FineTunedClassifierAgent(autogen.ConversableAgent):
    def __init__(self, name, model_path):
        super().__init__(name)
        self.model = AutoModelForSequenceClassification.from_pretrained(model_path)
        self.tokenizer = AutoTokenizer.from_pretrained(model_path)

    def classify(self, text):
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, padding=True)
        outputs = self.model(**inputs)
        probabilities = torch.softmax(outputs.logits, dim=1)
        prediction = torch.argmax(probabilities, dim=1).item()
        return prediction

# Example usage
classifier_agent = FineTunedClassifierAgent("ClassifierBot", "./fine_tuned_model")
human_proxy = autogen.UserProxyAgent("Human")

human_proxy.initiate_chat(classifier_agent, message="Classify this text: I love this product!")
```

This example demonstrates how to fine-tune a BERT model for text classification and integrate it into an Autogen agent. The `ModelTuner` class handles the fine-tuning process, while the `FineTunedClassifierAgent` uses the resulting model for text classification tasks.

## Integrating Autogen with Other AI Frameworks

Autogen can be integrated with other AI frameworks to leverage their strengths and create more powerful AI systems. Let's explore integrations with Hugging Face Transformers and LangChain.

### Hugging Face Integration

```python
# src/integrations/huggingface_integration.py

import autogen
from transformers import pipeline

class HuggingFaceAgent(autogen.ConversableAgent):
    def __init__(self, name, task, model):
        super().__init__(name)
        self.pipeline = pipeline(task, model=model)

    def run_pipeline(self, input_text):
        return self.pipeline(input_text)

# Example usage
sentiment_agent = HuggingFaceAgent("SentimentBot", "sentiment-analysis", "distilbert-base-uncased-finetuned-sst-2-english")
ner_agent = HuggingFaceAgent("NERBot", "ner", "dbmdz/bert-large-cased-finetuned-conll03-english")

human_proxy = autogen.UserProxyAgent("Human")

# Sentiment analysis
human_proxy.initiate_chat(sentiment_agent, message="Analyze the sentiment: I love using Autogen!")

# Named Entity Recognition
human_proxy.initiate_chat(ner_agent, message="Identify entities: Barack Obama was born in Hawaii.")
```

This example shows how to create Autogen agents that use Hugging Face pipelines for various NLP tasks.

### LangChain Integration

```python
# src/integrations/langchain_integration.py

import autogen
from langchain import PromptTemplate, LLMChain
from langchain.llms import OpenAI

class LangChainAgent(autogen.ConversableAgent):
    def __init__(self, name, template, llm):
        super().__init__(name)
        self.prompt = PromptTemplate(template=template, input_variables=["query"])
        self.llm_chain = LLMChain(prompt=self.prompt, llm=llm)

    def run_chain(self, query):
        return self.llm_chain.run(query)

# Example usage
template = """
You are a helpful AI assistant. Answer the following question:
{query}
"""

llm = OpenAI(temperature=0.7)
langchain_agent = LangChainAgent("LangChainBot", template, llm)

human_proxy = autogen.UserProxyAgent("Human")

human_proxy.initiate_chat(langchain_agent, message="What is the capital of France?")
```

This example demonstrates how to create an Autogen agent that uses a LangChain LLMChain for generating responses.

## Cutting-Edge Research and Future Directions

As Autogen continues to evolve, several exciting research directions and potential improvements are being explored:

1. Multi-Agent Reinforcement Learning

```python
# src/research/multi_agent_learning.py

import autogen
import torch
import torch.nn as nn
import torch.optim as optim

class PolicyNetwork(nn.Module):
    def __init__(self, input_size, output_size):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(input_size, 64),
            nn.ReLU(),
            nn.Linear(64, output_size)
        )

    def forward(self, x):
        return self.fc(x)

class RLAgent(autogen.ConversableAgent):
    def __init__(self, name, input_size, output_size):
        super().__init__(name)
        self.policy = PolicyNetwork(input_size, output_size)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=0.001)

    def act(self, state):
        with torch.no_grad():
            action_probs = torch.softmax(self.policy(torch.FloatTensor(state)), dim=0)
            action = torch.multinomial(action_probs, 1).item()
        return action

    def update(self, states, actions, rewards):
        states = torch.FloatTensor(states)
        actions = torch.LongTensor(actions)
        rewards = torch.FloatTensor(rewards)

        action_probs = torch.softmax(self.policy(states), dim=1)
        selected_action_probs = action_probs = torch.gather(action_probs, 1, actions.unsqueeze(1)).squeeze()
        loss = -torch.mean(torch.log(selected_action_probs) * rewards)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

# Example usage
env = YourEnvironment()  # Define your multi-agent environment
agents = [RLAgent(f"Agent{i}", env.state_size, env.action_size) for i in range(env.num_agents)]

for episode in range(1000):
    states = env.reset()
    done = False
    while not done:
        actions = [agent.act(state) for agent, state in zip(agents, states)]
        next_states, rewards, done, _ = env.step(actions)
        
        for agent, state, action, reward, next_state in zip(agents, states, actions, rewards, next_states):
            agent.update([state], [action], [reward])
        
        states = next_states

print("Multi-agent reinforcement learning completed!")
```

This example demonstrates a basic implementation of multi-agent reinforcement learning using Autogen. Each agent has its own policy network and learns to take actions in a shared environment. This approach can be extended to more complex scenarios where agents need to collaborate or compete to achieve their goals.

2. Federated Learning for Privacy-Preserving AI

Federated learning is an approach that allows multiple parties to train a shared model without exchanging raw data, preserving privacy. Here's how we could implement a simple federated learning system using Autogen:

```python
# src/research/federated_learning.py

import autogen
import torch
import torch.nn as nn
import torch.optim as optim

class FederatedModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc = nn.Linear(10, 1)

    def forward(self, x):
        return self.fc(x)

class FederatedAgent(autogen.ConversableAgent):
    def __init__(self, name, model, data):
        super().__init__(name)
        self.model = model
        self.data = data
        self.optimizer = optim.SGD(self.model.parameters(), lr=0.01)

    def train_local(self, epochs=5):
        criterion = nn.MSELoss()
        for _ in range(epochs):
            self.optimizer.zero_grad()
            outputs = self.model(self.data['x'])
            loss = criterion(outputs, self.data['y'])
            loss.backward()
            self.optimizer.step()
        return self.get_model_params()

    def get_model_params(self):
        return {name: param.data for name, param in self.model.named_parameters()}

    def set_model_params(self, params):
        for name, param in self.model.named_parameters():
            param.data = params[name]

class FederatedServer(autogen.ConversableAgent):
    def __init__(self, name, model, agents):
        super().__init__(name)
        self.model = model
        self.agents = agents

    def aggregate_models(self):
        agent_params = [agent.train_local() for agent in self.agents]
        avg_params = {name: torch.stack([params[name] for params in agent_params]).mean(0)
                      for name in agent_params[0]}
        for agent in self.agents:
            agent.set_model_params(avg_params)
        self.set_model_params(avg_params)

    def set_model_params(self, params):
        for name, param in self.model.named_parameters():
            param.data = params[name]

# Example usage
model = FederatedModel()
data1 = {'x': torch.randn(100, 10), 'y': torch.randn(100, 1)}
data2 = {'x': torch.randn(100, 10), 'y': torch.randn(100, 1)}

agent1 = FederatedAgent("Agent1", model, data1)
agent2 = FederatedAgent("Agent2", model, data2)
server = FederatedServer("Server", model, [agent1, agent2])

for round in range(10):
    server.aggregate_models()
    print(f"Federated learning round {round + 1} completed")

print("Federated learning completed!")
```

This example shows how to implement a basic federated learning system using Autogen. The `FederatedAgent` class represents a client with local data, while the `FederatedServer` class coordinates the learning process and aggregates model updates.

3. Explainable AI (XAI) Integration

Integrating explainable AI techniques into Autogen can help users understand the decision-making process of AI agents. Here's an example of how we could incorporate LIME (Local Interpretable Model-agnostic Explanations) into an Autogen agent:

```python
# src/research/explainable_ai.py

import autogen
import numpy as np
from sklearn.linear_model import LogisticRegression
from lime.lime_tabular import LimeTabularExplainer

class ExplainableAgent(autogen.ConversableAgent):
    def __init__(self, name, model, feature_names):
        super().__init__(name)
        self.model = model
        self.feature_names = feature_names
        self.explainer = LimeTabularExplainer(
            np.array([]),  # Training data (not needed for this example)
            feature_names=feature_names,
            class_names=['Negative', 'Positive'],
            mode='classification'
        )

    def predict_and_explain(self, instance):
        prediction = self.model.predict_proba([instance])[0]
        explanation = self.explainer.explain_instance(
            instance, self.model.predict_proba, num_features=len(self.feature_names)
        )
        return prediction, explanation

# Example usage
feature_names = ['feature1', 'feature2', 'feature3', 'feature4']
X = np.random.rand(100, 4)
y = (X.sum(axis=1) > 2).astype(int)

model = LogisticRegression()
model.fit(X, y)

explainable_agent = ExplainableAgent("ExplainableBot", model, feature_names)
human_proxy = autogen.UserProxyAgent("Human")

def format_explanation(prediction, explanation):
    class_names = ['Negative', 'Positive']
    result = f"Prediction: {class_names[prediction.argmax()]} (confidence: {prediction.max():.2f})\n\n"
    result += "Feature Importance:\n"
    for feature, importance in explanation.as_list():
        result += f"- {feature}: {importance:.4f}\n"
    return result

human_proxy.initiate_chat(
    explainable_agent,
    message="Explain this instance: {}".format([0.5, 0.2, 0.8, 0.1])
)
```

This example demonstrates how to create an Autogen agent that not only makes predictions but also provides explanations for those predictions using LIME. This can be particularly useful in scenarios where transparency and interpretability are crucial.

## Conclusion

In this lesson, we've explored advanced topics in Autogen development, including:

1. Implementing custom LLM-powered features like semantic search and text summarization
2. Fine-tuning language models for specific tasks
3. Integrating Autogen with other AI frameworks such as Hugging Face and LangChain
4. Cutting-edge research directions like multi-agent reinforcement learning, federated learning, and explainable AI

These advanced techniques open up new possibilities for creating sophisticated AI systems using Autogen. As you continue to develop with Autogen, consider how you can incorporate these ideas into your projects to create more powerful, flexible, and interpretable AI agents.

Remember that the field of AI is rapidly evolving, and new techniques and best practices are constantly emerging. Stay curious, keep experimenting, and don't hesitate to contribute your own innovations to the Autogen community!

## Project Layout

To recap, here's the project structure we've been working with throughout this lesson:

```
autogen_advanced/
│
├── src/
│   ├── custom_features/
│   │   ├── __init__.py
│   │   ├── semantic_search.py
│   │   └── text_summarizer.py
│   │
│   ├── fine_tuning/
│   │   ├── __init__.py
│   │   ├── data_preparation.py
│   │   └── model_tuner.py
│   │
│   ├── integrations/
│   │   ├── __init__.py
│   │   ├── huggingface_integration.py
│   │   └── langchain_integration.py
│   │
│   └── research/
│       ├── __init__.py
│       ├── multi_agent_learning.py
│       ├── federated_learning.py
│       └── explainable_ai.py
│
├── tests/
│   ├── test_custom_features.py
│   ├── test_fine_tuning.py
│   ├── test_integrations.py
│   └── test_research.py
│
├── requirements.txt
└── main.py
```

This structure organizes our advanced Autogen project into distinct modules, making it easy to navigate and extend. As you develop your own advanced Autogen applications, consider adopting a similar modular structure to keep your code organized and maintainable.

Happy coding, and may your Autogen agents bring new insights and capabilities to your AI projects!
```

# lesson-11-autogen-application.md

```
# Lesson 11: Building a Complete Autogen-based Application

In this comprehensive lesson, we'll walk through the process of building a complete Autogen-based application. We'll create a task management system that uses AI agents to help users organize, prioritize, and complete their tasks. This application will demonstrate how to integrate Autogen's powerful features into a practical, user-facing tool.

## Table of Contents

1. [Project Planning and Architecture](#1-project-planning-and-architecture)
2. [Setting Up the Project](#2-setting-up-the-project)
3. [Implementing Core Features](#3-implementing-core-features)
4. [User Interface Design and Integration](#4-user-interface-design-and-integration)
5. [Testing the Application](#5-testing-the-application)
6. [Deployment and Maintenance](#6-deployment-and-maintenance)

## 1. Project Planning and Architecture

Before we start coding, let's define our project goals and architecture.

### Project Goals

Our AI-powered Task Management System will:

1. Allow users to create, update, and delete tasks
2. Use AI agents to suggest task priorities and deadlines
3. Provide AI-generated suggestions for breaking down complex tasks
4. Offer natural language interactions for task management

### Architecture Overview

We'll use a client-server architecture with the following components:

1. **Backend**: Python-based server using FastAPI
2. **Frontend**: React-based web application
3. **Database**: SQLite for simplicity (can be scaled to PostgreSQL later)
4. **Autogen Integration**: Custom agents for task analysis and suggestions

### Project Structure

Here's the overall project structure we'll be working with:

```
ai_task_manager/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── models.py
│   │   ├── database.py
│   │   ├── schemas.py
│   │   └── agents/
│   │       ├── __init__.py
│   │       ├── task_analyzer.py
│   │       └── task_suggester.py
│   ├── tests/
│   │   ├── __init__.py
│   │   ├── test_main.py
│   │   └── test_agents.py
│   ├── requirements.txt
│   └── .env
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── services/
│   │   ├── App.js
│   │   └── index.js
│   ├── package.json
│   └── .env
└── README.md
```

Now that we have our project structure, let's dive into the implementation.

## 2. Setting Up the Project

Let's start by setting up our development environment and project structure.

### Backend Setup

First, let's set up our Python backend:

```bash
mkdir -p ai_task_manager/backend/app ai_task_manager/backend/tests
cd ai_task_manager/backend
python -m venv venv
source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
pip install fastapi uvicorn sqlalchemy pydantic python-dotenv autogen
pip freeze > requirements.txt
```

Create a `.env` file in the `backend` directory:

```
DATABASE_URL=sqlite:///./tasks.db
OPENAI_API_KEY=your_openai_api_key_here
```

### Frontend Setup

Now, let's set up our React frontend:

```bash
npx create-react-app ai_task_manager/frontend
cd ai_task_manager/frontend
npm install axios @material-ui/core @material-ui/icons
```

## 3. Implementing Core Features

Let's implement the core features of our application, starting with the backend.

### Backend Implementation

#### `backend/app/database.py`

```python
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv
import os

load_dotenv()

SQLALCHEMY_DATABASE_URL = os.getenv("DATABASE_URL")

engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()
```

#### `backend/app/models.py`

```python
from sqlalchemy import Column, Integer, String, Boolean, DateTime
from .database import Base

class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    description = Column(String)
    is_completed = Column(Boolean, default=False)
    priority = Column(String)
    deadline = Column(DateTime)
```

#### `backend/app/schemas.py`

```python
from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class TaskBase(BaseModel):
    title: str
    description: Optional[str] = None
    is_completed: bool = False
    priority: Optional[str] = None
    deadline: Optional[datetime] = None

class TaskCreate(TaskBase):
    pass

class Task(TaskBase):
    id: int

    class Config:
        orm_mode = True
```

#### `backend/app/agents/task_analyzer.py`

```python
import autogen

class TaskAnalyzer:
    def __init__(self):
        self.config_list = autogen.config_list_from_json(
            "OAI_CONFIG_LIST",
            filter_dict={
                "model": {
                    "gpt-4",
                    "gpt-3.5-turbo",
                    "gpt-3.5-turbo-16k",
                },
            },
        )
        self.llm_config = {"config_list": self.config_list}

    def analyze_task(self, task_description):
        assistant = autogen.AssistantAgent(
            name="task_analyzer",
            llm_config=self.llm_config,
            system_message="You are an AI assistant that analyzes tasks and suggests priorities and deadlines."
        )

        user_proxy = autogen.UserProxyAgent(
            name="user_proxy",
            human_input_mode="NEVER",
            max_consecutive_auto_reply=1,
            is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
        )

        user_proxy.initiate_chat(
            assistant,
            message=f"Analyze this task and suggest a priority (High, Medium, or Low) and a reasonable deadline: {task_description}"
        )

        # Extract the last assistant message
        last_message = assistant.chat_messages[user_proxy][-1]
        return last_message['content']

task_analyzer = TaskAnalyzer()
```

#### `backend/app/main.py`

```python
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy.orm import Session
from . import models, schemas
from .database import SessionLocal, engine
from .agents.task_analyzer import task_analyzer

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/tasks/", response_model=schemas.Task)
def create_task(task: schemas.TaskCreate, db: Session = Depends(get_db)):
    analysis = task_analyzer.analyze_task(task.description)
    # Extract priority and deadline from analysis (you might need to implement a parser for this)
    # For now, let's assume the analysis is in a simple format:
    priority, deadline = analysis.split(", ")
    
    db_task = models.Task(**task.dict(), priority=priority, deadline=deadline)
    db.add(db_task)
    db.commit()
    db.refresh(db_task)
    return db_task

@app.get("/tasks/", response_model=list[schemas.Task])
def read_tasks(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    tasks = db.query(models.Task).offset(skip).limit(limit).all()
    return tasks

@app.get("/tasks/{task_id}", response_model=schemas.Task)
def read_task(task_id: int, db: Session = Depends(get_db)):
    task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@app.put("/tasks/{task_id}", response_model=schemas.Task)
def update_task(task_id: int, task: schemas.TaskCreate, db: Session = Depends(get_db)):
    db_task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if db_task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    for key, value in task.dict().items():
        setattr(db_task, key, value)
    db.commit()
    db.refresh(db_task)
    return db_task

@app.delete("/tasks/{task_id}", response_model=schemas.Task)
def delete_task(task_id: int, db: Session = Depends(get_db)):
    task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    db.delete(task)
    db.commit()
    return task
```

## 4. User Interface Design and Integration

Now that we have our backend implemented, let's create a simple frontend to interact with our AI-powered task management system.

### Frontend Implementation

#### `frontend/src/services/api.js`

```javascript
import axios from 'axios';

const API_URL = 'http://localhost:8000';

export const createTask = async (task) => {
  const response = await axios.post(`${API_URL}/tasks/`, task);
  return response.data;
};

export const getTasks = async () => {
  const response = await axios.get(`${API_URL}/tasks/`);
  return response.data;
};

export const updateTask = async (id, task) => {
  const response = await axios.put(`${API_URL}/tasks/${id}`, task);
  return response.data;
};

export const deleteTask = async (id) => {
  const response = await axios.delete(`${API_URL}/tasks/${id}`);
  return response.data;
};
```

#### `frontend/src/components/TaskList.js`

```javascript
import React, { useState, useEffect } from 'react';
import { List, ListItem, ListItemText, ListItemSecondaryAction, IconButton, Typography } from '@material-ui/core';
import { Delete as DeleteIcon, Edit as EditIcon } from '@material-ui/icons';
import { getTasks, deleteTask } from '../services/api';

const TaskList = ({ onEditTask }) => {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    const fetchedTasks = await getTasks();
    setTasks(fetchedTasks);
  };

  const handleDeleteTask = async (id) => {
    await deleteTask(id);
    fetchTasks();
  };

  return (
    <List>
      {tasks.map((task) => (
        <ListItem key={task.id}>
          <ListItemText
            primary={task.title}
            secondary={
              <>
                <Typography component="span" variant="body2" color="textPrimary">
                  {task.description}
                </Typography>
                <br />
                Priority: {task.priority}, Deadline: {new Date(task.deadline).toLocaleDateString()}
              </>
            }
          />
          <ListItemSecondaryAction>
            <IconButton edge="end" aria-label="edit" onClick={() => onEditTask(task)}>
              <EditIcon />
            </IconButton>
            <IconButton edge="end" aria-label="delete" onClick={() => handleDeleteTask(task.id)}>
              <DeleteIcon />
            </IconButton>
          </ListItemSecondaryAction>
        </ListItem>
      ))}
    </List>
  );
};

export default TaskList;
```

#### `frontend/src/components/TaskForm.js`

```javascript
import React, { useState, useEffect } from 'react';
import { TextField, Button, Grid } from '@material-ui/core';
import { createTask, updateTask } from '../services/api';

const TaskForm = ({ task, onTaskAdded, onTaskUpdated }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (task) {
      setTitle(task.title);
      setDescription(task.description);
    }
  }, [task]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const taskData = { title, description };
    if (task) {
      await updateTask(task.id, taskData);
      onTaskUpdated();
    } else {
      await createTask(taskData);
      onTaskAdded();
    }
    setTitle('');
    setDescription('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            multiline
            rows={4}
          />
        </Grid>
        <Grid item xs={12}>
          <Button type="submit" variant="contained" color="primary">
            {task ? 'Update Task' : 'Add Task'}
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default TaskForm;
```

#### `frontend/src/App.js`

```javascript
import React, { useState } from 'react';
import { Container, Typography, Box } from '@material-ui/core';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';

function App() {
  const [editingTask, setEditingTask] = useState(null);

  const handleTaskAdded = () => {
    // Refresh the task list
    // You might want to implement a more efficient way to update the list
    // For simplicity, we'll just force a re-render of TaskList
    setEditingTask(null);
  };

  const handleTaskUpdated = () => {
    setEditingTask(null);
  };

  return (
    <Container maxWidth="md">
      <Box my={4}>
        <Typography variant="h4" component="h1" gutterBottom>
          AI-Powered Task Manager
        </Typography>
        <TaskForm
          task={editingTask}
          onTaskAdded={handleTaskAdded}
          onTaskUpdated={handleTaskUpdated}
        />
        <Box my={4}>
          <TaskList onEditTask={setEditingTask} />
        </Box>
      </Box>
    </Container>
  );
}

export default App;
```

Now that we have implemented both the backend and frontend of our AI-powered Task Management System, let's go through the process of running and testing our application.

## 5. Testing the Application

Testing is a crucial part of the development process. We'll create some basic tests for our backend and manually test our frontend.

### Backend Tests

Create a new file `backend/tests/test_main.py`:

```python
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_create_task():
    response = client.post(
        "/tasks/",
        json={"title": "Test Task", "description": "This is a test task"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "Test Task"
    assert "id" in data

def test_read_tasks():
    response = client.get("/tasks/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_read_task():
    # First, create a task
    create_response = client.post(
        "/tasks/",
        json={"title": "Test Task", "description": "This is a test task"}
    )
    task_id = create_response.json()["id"]

    # Then, read the task
    response = client.get(f"/tasks/{task_id}")
    assert response.status_code == 200
    assert response.json()["id"] == task_id

def test_update_task():
    # First, create a task
    create_response = client.post(
        "/tasks/",
        json={"title": "Test Task", "description": "This is a test task"}
    )
    task_id = create_response.json()["id"]

    # Then, update the task
    update_response = client.put(
        f"/tasks/{task_id}",
        json={"title": "Updated Task", "description": "This is an updated test task"}
    )
    assert update_response.status_code == 200
    assert update_response.json()["title"] == "Updated Task"

def test_delete_task():
    # First, create a task
    create_response = client.post(
        "/tasks/",
        json={"title": "Test Task", "description": "This is a test task"}
    )
    task_id = create_response.json()["id"]

    # Then, delete the task
    delete_response = client.delete(f"/tasks/{task_id}")
    assert delete_response.status_code == 200

    # Verify that the task has been deleted
    get_response = client.get(f"/tasks/{task_id}")
    assert get_response.status_code == 404
```

To run the tests, use the following command in the `backend` directory:

```bash
pytest
```

### Manual Frontend Testing

To test the frontend manually, follow these steps:

1. Start the backend server:

```bash
cd backend
uvicorn app.main:app --reload
```

2. In a new terminal, start the frontend development server:

```bash
cd frontend
npm start
```

3. Open a web browser and navigate to `http://localhost:3000`.

4. Test the following functionalities:
   - Create a new task
   - View the list of tasks
   - Edit an existing task
   - Delete a task

Pay special attention to the AI-generated priorities and deadlines for the tasks you create.

## 6. Deployment and Maintenance

Now that we have a working application, let's discuss deployment and maintenance strategies.

### Deployment

For this example, we'll use a simple deployment strategy. In a production environment, you might want to use more robust solutions like Docker containers and cloud platforms.

#### Backend Deployment

1. Choose a server or cloud platform (e.g., DigitalOcean, AWS, or Heroku).
2. Set up a Python environment on the server.
3. Copy your backend code to the server.
4. Install dependencies:

```bash
pip install -r requirements.txt
```

5. Set up environment variables for your production environment.
6. Run the FastAPI application using a production-grade ASGI server like Gunicorn:

```bash
gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker
```

#### Frontend Deployment

1. Build the React application:

```bash
npm run build
```

2. Deploy the contents of the `build` directory to a static file hosting service (e.g., Netlify, Vercel, or Amazon S3).

3. Update the API_URL in `frontend/src/services/api.js` to point to your production backend URL.

### Maintenance

To keep your application running smoothly and up-to-date, consider the following maintenance tasks:

1. **Regular Updates**: Keep your dependencies up-to-date by periodically running:

```bash
# Backend
pip list --outdated
pip install --upgrade <package_name>

# Frontend
npm outdated
npm update
```

2. **Monitoring**: Set up monitoring for your backend server to track performance, errors, and usage. You can use tools like Prometheus, Grafana, or cloud-specific monitoring solutions.

3. **Logging**: Implement comprehensive logging in your backend to help with debugging and tracking user behavior. Consider using a centralized logging solution like ELK stack (Elasticsearch, Logstash, Kibana) or cloud-based logging services.

4. **Backup**: Regularly backup your database to prevent data loss.

5. **Security Updates**: Stay informed about security vulnerabilities in your dependencies and update them promptly.

6. **Performance Optimization**: Continuously monitor and optimize your application's performance. This may involve database query optimization, caching strategies, or code refactoring.

7. **User Feedback**: Implement a system to collect and analyze user feedback, which can guide future improvements and bug fixes.

## Conclusion

In this lesson, we've built a complete Autogen-based application that demonstrates how to integrate AI agents into a practical task management system. We've covered the entire development process, from planning and implementation to testing and deployment.

Key takeaways from this lesson include:

1. Structuring an Autogen-based project with a clear separation of concerns
2. Integrating Autogen agents with a web application backend
3. Creating a user-friendly frontend to interact with AI-powered features
4. Implementing proper testing strategies for both backend and frontend
5. Considering deployment and maintenance aspects of an AI-powered application

As you continue to develop Autogen-based applications, remember to stay updated with the latest Autogen features and best practices. Always consider the ethical implications of AI-powered systems and strive to create applications that provide genuine value to users while respecting their privacy and data.


```

# lesson-12-autogen-best-practices.md

```
# Lesson 12: Autogen Best Practices and Design Patterns

## Table of Contents
1. [Introduction](#introduction)
2. [Code Organization and Modular Design](#code-organization-and-modular-design)
3. [Error Handling and Graceful Degradation](#error-handling-and-graceful-degradation)
4. [Security Considerations in AI-powered Applications](#security-considerations-in-ai-powered-applications)
5. [Ethical Considerations and Responsible AI Development](#ethical-considerations-and-responsible-ai-development)
6. [Conclusion](#conclusion)

## Introduction

Welcome to Lesson 12 of our Autogen series! In this final lesson, we'll explore best practices and design patterns for developing Autogen-based applications. We'll cover code organization, error handling, security considerations, and ethical aspects of AI development. By the end of this lesson, you'll have a solid understanding of how to build robust, secure, and responsible AI applications using Autogen.

## Code Organization and Modular Design

### Project Structure

Let's start by looking at a well-organized Autogen project structure:

```
autogen_project/
│
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── assistant_agent.py
│   │   ├── user_proxy_agent.py
│   │   └── custom_agent.py
│   │
│   ├── conversations/
│   │   ├── __init__.py
│   │   ├── chat_manager.py
│   │   └── group_chat.py
│   │
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── code_executor.py
│   │   └── web_search.py
│   │
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── config_loader.py
│   │   └── logger.py
│   │
│   └── main.py
│
├── tests/
│   ├── test_agents.py
│   ├── test_conversations.py
│   └── test_tools.py
│
├── configs/
│   ├── agent_config.yaml
│   └── api_config.yaml
│
├── requirements.txt
├── setup.py
└── README.md
```

This structure separates concerns and promotes modularity. Let's break it down:

- `src/`: Contains the main source code.
  - `agents/`: Defines different types of agents.
  - `conversations/`: Manages conversation flows.
  - `tools/`: Implements various tools and utilities.
  - `utils/`: Houses helper functions and utilities.
- `tests/`: Contains unit and integration tests.
- `configs/`: Stores configuration files.

### Modular Design Principles

1. **Single Responsibility Principle (SRP)**: Each module should have one specific purpose. For example:

```python
# src/agents/assistant_agent.py

from autogen import AssistantAgent

class CustomAssistantAgent(AssistantAgent):
    def __init__(self, name: str, system_message: str, **kwargs):
        super().__init__(name=name, system_message=system_message, **kwargs)
        
    def custom_method(self):
        # Implement custom behavior
        pass
```

2. **Dependency Injection**: Pass dependencies as arguments rather than creating them inside the class:

```python
# src/conversations/chat_manager.py

from autogen import ConversableAgent

class ChatManager:
    def __init__(self, agent1: ConversableAgent, agent2: ConversableAgent):
        self.agent1 = agent1
        self.agent2 = agent2
    
    def start_conversation(self, initial_message: str):
        # Manage the conversation flow
        pass
```

3. **Configuration Management**: Use a centralized configuration system:

```python
# src/utils/config_loader.py

import yaml

def load_config(config_path: str) -> dict:
    with open(config_path, 'r') as config_file:
        return yaml.safe_load(config_file)

# Usage
agent_config = load_config('configs/agent_config.yaml')
```

4. **Factory Pattern**: Use factories to create agents and tools:

```python
# src/agents/__init__.py

from .assistant_agent import CustomAssistantAgent
from .user_proxy_agent import CustomUserProxyAgent

def create_agent(agent_type: str, **kwargs):
    if agent_type == 'assistant':
        return CustomAssistantAgent(**kwargs)
    elif agent_type == 'user_proxy':
        return CustomUserProxyAgent(**kwargs)
    else:
        raise ValueError(f"Unknown agent type: {agent_type}")
```

By following these principles, your Autogen project will be more maintainable, testable, and scalable.

## Error Handling and Graceful Degradation

Proper error handling is crucial for building robust AI applications. Here are some best practices:

1. **Use Custom Exceptions**: Define custom exceptions for Autogen-specific errors:

```python
# src/utils/exceptions.py

class AutogenError(Exception):
    """Base class for Autogen exceptions."""
    pass

class AgentCommunicationError(AutogenError):
    """Raised when there's an error in agent communication."""
    pass

class ToolExecutionError(AutogenError):
    """Raised when a tool fails to execute properly."""
    pass
```

2. **Implement Robust Error Handling**: Use try-except blocks to catch and handle errors gracefully:

```python
# src/tools/code_executor.py

from ..utils.exceptions import ToolExecutionError

class CodeExecutor:
    def execute(self, code: str) -> str:
        try:
            # Execute the code
            result = self._run_code(code)
            return result
        except Exception as e:
            raise ToolExecutionError(f"Failed to execute code: {str(e)}")
    
    def _run_code(self, code: str) -> str:
        # Implementation of code execution
        pass
```

3. **Graceful Degradation**: Implement fallback mechanisms when errors occur:

```python
# src/conversations/chat_manager.py

from ..utils.exceptions import AgentCommunicationError

class ChatManager:
    def __init__(self, primary_agent, fallback_agent):
        self.primary_agent = primary_agent
        self.fallback_agent = fallback_agent
    
    def get_response(self, message: str) -> str:
        try:
            return self.primary_agent.get_response(message)
        except AgentCommunicationError:
            print("Primary agent failed. Falling back to secondary agent.")
            return self.fallback_agent.get_response(message)
```

4. **Logging**: Implement comprehensive logging to track errors and system behavior:

```python
# src/utils/logger.py

import logging

def setup_logger(name: str, log_file: str, level=logging.INFO):
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    handler = logging.FileHandler(log_file)
    handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)

    return logger

# Usage
logger = setup_logger('autogen', 'logs/autogen.log')
logger.info("Starting Autogen application")
```

By implementing these error handling strategies, your Autogen application will be more resilient and easier to debug.

## Security Considerations in AI-powered Applications

Security is paramount in AI applications. Here are some key considerations:

1. **Input Validation**: Always validate and sanitize user inputs:

```python
# src/utils/input_validator.py

import re

def sanitize_input(input_string: str) -> str:
    # Remove any potentially harmful characters
    return re.sub(r'[^\w\s.-]', '', input_string)

# Usage
user_input = input("Enter a command: ")
safe_input = sanitize_input(user_input)
```

2. **API Key Management**: Never hardcode API keys. Use environment variables or secure vaults:

```python
# src/utils/api_key_manager.py

import os
from dotenv import load_dotenv

load_dotenv()

def get_api_key(key_name: str) -> str:
    api_key = os.getenv(key_name)
    if not api_key:
        raise ValueError(f"API key '{key_name}' not found in environment variables")
    return api_key

# Usage
openai_api_key = get_api_key('OPENAI_API_KEY')
```

3. **Rate Limiting**: Implement rate limiting to prevent abuse:

```python
# src/utils/rate_limiter.py

import time
from functools import wraps

def rate_limit(max_calls: int, period: int):
    calls = []
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            now = time.time()
            calls_in_period = [call for call in calls if call > now - period]
            
            if len(calls_in_period) >= max_calls:
                raise Exception("Rate limit exceeded")
            
            calls.append(now)
            return func(*args, **kwargs)
        return wrapper
    return decorator

# Usage
@rate_limit(max_calls=5, period=60)
def make_api_call():
    # Make the API call
    pass
```

4. **Secure Code Execution**: When executing code from LLMs, use sandboxing techniques:

```python
# src/tools/secure_code_executor.py

import docker

class SecureCodeExecutor:
    def __init__(self):
        self.client = docker.from_env()
    
    def execute(self, code: str) -> str:
        container = self.client.containers.run(
            "python:3.9-slim",
            f"python -c '{code}'",
            remove=True,
            detach=True,
            mem_limit="100m",
            network_disabled=True
        )
        return container.logs().decode('utf-8')

# Usage
executor = SecureCodeExecutor()
result = executor.execute("print('Hello, World!')")
```

By implementing these security measures, you can protect your Autogen application from common vulnerabilities and threats.

## Ethical Considerations and Responsible AI Development

As AI developers, we have a responsibility to create systems that are ethical and beneficial to society. Here are some key considerations:

1. **Bias Mitigation**: Regularly audit your AI models for bias:

```python
# src/utils/bias_checker.py

from typing import List

def check_for_bias(responses: List[str], sensitive_terms: List[str]) -> List[str]:
    biased_responses = []
    for response in responses:
        if any(term in response.lower() for term in sensitive_terms):
            biased_responses.append(response)
    return biased_responses

# Usage
sensitive_terms = ['gender', 'race', 'age', 'disability']
responses = [agent.get_response("Tell me about a successful person") for _ in range(100)]
biased_responses = check_for_bias(responses, sensitive_terms)
```

2. **Transparency**: Clearly communicate when users are interacting with AI:

```python
# src/agents/transparent_agent.py

from autogen import ConversableAgent

class TransparentAgent(ConversableAgent):
    def __init__(self, name: str, **kwargs):
        super().__init__(name=name, **kwargs)
    
    def get_response(self, message: str) -> str:
        response = super().get_response(message)
        return f"[AI RESPONSE] {response}"

# Usage
transparent_agent = TransparentAgent("TransparentAssistant")
```

3. **Data Privacy**: Implement strong data protection measures:

```python
# src/utils/data_anonymizer.py

import hashlib

def anonymize_data(data: str) -> str:
    return hashlib.sha256(data.encode()).hexdigest()

# Usage
user_data = "sensitive_information"
anonymized_data = anonymize_data(user_data)
```

4. **Ethical Decision Making**: Implement ethical checks in your AI decision-making process:

```python
# src/utils/ethical_checker.py

class EthicalChecker:
    def __init__(self, ethical_guidelines: List[str]):
        self.guidelines = ethical_guidelines
    
    def check_decision(self, decision: str) -> bool:
        return all(guideline in decision for guideline in self.guidelines)

# Usage
checker = EthicalChecker(["respect privacy", "avoid harm", "promote fairness"])
decision = agent.make_decision("How to handle user data?")
if checker.check_decision(decision):
    implement_decision(decision)
else:
    request_human_review(decision)
```

By incorporating these ethical considerations into your Autogen development process, you'll be contributing to the responsible advancement of AI technology.

## Conclusion

In this lesson, we've covered essential best practices and design patterns for Autogen development. By following these guidelines, you'll be able to create well-organized, secure, and ethically sound AI applications. Remember that the field of AI is rapidly evolving, so it's crucial to stay updated with the latest developments and continuously refine your practices.

As you move forward with your Autogen projects, keep these key takeaways in mind:

1. Organize your code modularly and follow solid design principles.
2. Implement robust error handling and graceful degradation.
3. Prioritize security in every aspect of your application.
4. Consider the ethical implications of your AI systems and strive for responsible development.

By applying these practices, you'll be well-equipped to tackle complex AI challenges and create impactful applications with Autogen. Good luck with your future projects!

```

# lesson-2-autogen-architecture-and-project-structure.md

```
# Lesson 2: Autogen Architecture and Project Structure

## Table of Contents
1. [Introduction](#introduction)
2. [High-level Overview of Autogen's Architecture](#high-level-overview-of-autogens-architecture)
3. [File Structure and Main Components](#file-structure-and-main-components)
4. [Key Modules](#key-modules)
   - [agentchat](#agentchat)
   - [oai](#oai)
   - [code_utils](#code_utils)
5. [Configuration and Environment Setup](#configuration-and-environment-setup)
6. [Sample Project Structure](#sample-project-structure)
7. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll dive deep into the architecture of Autogen and explore its project structure. Understanding the underlying design and organization of Autogen is crucial for effectively using the framework and potentially extending its functionality. We'll examine the main components, key modules, and how they interact to create a powerful system for building AI-powered applications.

## High-level Overview of Autogen's Architecture

Autogen is designed with a modular and extensible architecture that allows for flexibility in creating AI agents and managing their interactions. At its core, Autogen consists of several key components:

1. **Agents**: The fundamental building blocks of Autogen, representing entities that can perform actions and engage in conversations.
2. **Conversations**: Mechanisms for managing the exchange of messages between agents.
3. **Language Model Clients**: Interfaces for interacting with various language models (e.g., OpenAI's GPT models).
4. **Code Execution**: Utilities for executing code within the Autogen environment.
5. **Configuration Management**: Tools for managing API keys, model settings, and other configuration options.

These components work together to create a flexible and powerful framework for building AI applications. Let's examine how these components are organized within Autogen's file structure.

## File Structure and Main Components

Autogen's source code is organized into several directories, each containing modules related to specific functionality. Here's an overview of the main directories and their contents:

```
autogen/
├── agentchat/
├── cache/
├── coding/
├── io/
├── logger/
├── oai/
├── runtime_logging/
├── __init__.py
├── cache.py
├── code_utils.py
├── token_count_utils.py
├── formatting_utils.py
├── math_utils.py
└── ...
```

Let's break down the purpose of each main directory:

- **agentchat/**: Contains implementations of various agent types and chat-related functionality.
- **cache/**: Implements caching mechanisms for improved performance.
- **coding/**: Provides utilities for code execution and management.
- **io/**: Handles input/output operations, including console and websocket interfaces.
- **logger/**: Implements logging functionality for debugging and monitoring.
- **oai/**: Contains OpenAI-specific implementations and utilities.
- **runtime_logging/**: Manages runtime logging for tracking agent interactions and performance.

The root directory also contains several utility modules that are used across the project.

## Key Modules

Let's examine three key modules in more detail: agentchat, oai, and code_utils.

### agentchat

The `agentchat` module is central to Autogen's functionality, providing implementations for various types of agents and managing their interactions. Here's a closer look at its structure:

```
agentchat/
├── __init__.py
├── agent.py
├── assistant_agent.py
├── conversable_agent.py
├── groupchat.py
├── human_proxy_agent.py
└── user_proxy_agent.py
```

Key components:

- `agent.py`: Defines the base `Agent` class, which all other agent types inherit from.
- `conversable_agent.py`: Implements the `ConversableAgent` class, a flexible base class for creating agents that can engage in conversations.
- `assistant_agent.py`: Provides the `AssistantAgent` class, representing an AI-powered assistant.
- `user_proxy_agent.py`: Implements the `UserProxyAgent` class, which can represent a human user or execute code.
- `groupchat.py`: Manages group conversations involving multiple agents.

Example of creating an AssistantAgent:

```python
from autogen.agentchat import AssistantAgent

assistant = AssistantAgent(
    name="AI_Assistant",
    llm_config={
        "model": "gpt-3.5-turbo",
        "api_key": "your_api_key_here",
    }
)
```

### oai

The `oai` module handles interactions with OpenAI's language models and provides utilities for managing API calls. Here's its structure:

```
oai/
├── __init__.py
├── client.py
├── completion.py
├── openai_utils.py
└── ...
```

Key components:

- `client.py`: Implements the `OpenAIWrapper` class, which manages API calls to OpenAI's services.
- `completion.py`: Provides utilities for text completion tasks.
- `openai_utils.py`: Contains helper functions for working with OpenAI's API.

Example of using the OpenAIWrapper:

```python
from autogen.oai import OpenAIWrapper

oai_client = OpenAIWrapper(config_list=[{
    "model": "gpt-3.5-turbo",
    "api_key": "your_api_key_here",
}])

response = oai_client.create(messages=[{
    "role": "user",
    "content": "What is the capital of France?"
}])

print(response)
```

### code_utils

The `code_utils.py` module provides utilities for code execution and management within Autogen. It includes functions for:

- Extracting code blocks from text
- Executing code in various languages
- Sanitizing and validating code input

Example of using code_utils to execute Python code:

```python
from autogen import code_utils

code = """
def greet(name):
    return f"Hello, {name}!"

print(greet("Alice"))
"""

result = code_utils.execute_code(code, lang="python")
print(result)
```

## Configuration and Environment Setup

Autogen uses configuration files and environment variables to manage settings such as API keys, model preferences, and other options. Here's how you can set up your environment:

1. Create a `.env` file in your project root:

```
OPENAI_API_KEY=your_api_key_here
```

2. Use the `config_list_from_dotenv` function to load configurations:

```python
from autogen import config_list_from_dotenv

config_list = config_list_from_dotenv(
    dotenv_file_path=".env",
    model_api_key_map={
        "gpt-3.5-turbo": "OPENAI_API_KEY",
        "gpt-4": "OPENAI_API_KEY",
    }
)
```

This approach allows you to keep sensitive information separate from your code and easily manage different configurations for various environments (development, testing, production).

## Sample Project Structure

When building a larger application with Autogen, it's helpful to organize your project in a way that promotes modularity and maintainability. Here's an example of how you might structure a more complex Autogen project:

```
my_autogen_project/
├── .env
├── config/
│   ├── __init__.py
│   └── settings.py
├── src/
│   ├── __init__.py
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── custom_assistant.py
│   │   └── custom_user_proxy.py
│   ├── conversations/
│   │   ├── __init__.py
│   │   └── chat_manager.py
│   ├── tasks/
│   │   ├── __init__.py
│   │   ├── code_generation.py
│   │   └── data_analysis.py
│   └── utils/
│       ├── __init__.py
│       └── helpers.py
├── tests/
│   ├── __init__.py
│   ├── test_agents.py
│   └── test_conversations.py
├── main.py
├── requirements.txt
└── README.md
```

In this structure:

- `config/`: Contains configuration-related code and settings.
- `src/`: Houses the main application code.
  - `agents/`: Custom agent implementations.
  - `conversations/`: Modules for managing different types of conversations.
  - `tasks/`: Specific task implementations using Autogen.
  - `utils/`: Helper functions and utilities.
- `tests/`: Contains unit tests for your application.
- `main.py`: The entry point of your application.
- `requirements.txt`: Lists all the project dependencies.
- `README.md`: Documentation for your project.

This structure allows for easy expansion of your project while keeping related functionality organized and accessible.

## Conclusion

In this lesson, we've explored the architecture and project structure of Autogen. We've examined its key components, including the `agentchat`, `oai`, and `code_utils` modules, and how they work together to provide a powerful framework for building AI-powered applications.

Understanding Autogen's architecture is crucial for effectively using the framework and potentially extending its functionality. By organizing your own projects in a modular and maintainable way, you can leverage Autogen's capabilities to build sophisticated AI applications.

In the next lesson, we'll dive deeper into understanding and working with Autogen agents, exploring their properties, methods, and how to create custom agents for specific use cases.


```

# lesson-3-understanding-autogen-agents.md

```
# Lesson 3: Understanding Autogen Agents

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Types of Agents](#types-of-agents)
   - [ConversableAgent](#conversableagent)
   - [AssistantAgent](#assistantagent)
   - [UserProxyAgent](#userproxyagent)
4. [Creating and Customizing Agents](#creating-and-customizing-agents)
5. [Agent Properties and Methods](#agent-properties-and-methods)
6. [Implementing Custom Agents](#implementing-custom-agents)
7. [Practical Examples](#practical-examples)
8. [Best Practices](#best-practices)
9. [Conclusion](#conclusion)

## Introduction

Agents are the core building blocks of the Autogen framework. They represent different participants in a conversation or workflow, each with their own capabilities and behaviors. Understanding how to work with agents is crucial for leveraging the full power of Autogen in your AI-powered applications.

In this lesson, we'll dive deep into the world of Autogen agents, exploring their types, properties, and how to create and customize them for your specific needs.

## Project Structure

Before we begin, let's take a look at the typical project structure for an Autogen application:

```
autogen_project/
│
├── agents/
│   ├── __init__.py
│   ├── custom_agent.py
│   └── specialized_agent.py
│
├── config/
│   └── agent_config.json
│
├── utils/
│   └── helpers.py
│
├── main.py
├── requirements.txt
└── README.md
```

This structure organizes our code into logical components:
- `agents/`: Contains our custom agent implementations
- `config/`: Stores configuration files for our agents
- `utils/`: Houses helper functions and utilities
- `main.py`: The entry point of our application

Now, let's explore the different types of agents available in Autogen.

## Types of Agents

Autogen provides several built-in agent types, each designed for specific roles in a conversation or workflow. The three main types are:

1. ConversableAgent
2. AssistantAgent
3. UserProxyAgent

Let's examine each of these in detail.

### ConversableAgent

The `ConversableAgent` is the base class for all agents in Autogen. It provides the fundamental capabilities for participating in conversations.

Key features:
- Can send and receive messages
- Supports function calling
- Customizable with various configuration options

Here's a basic example of creating a `ConversableAgent`:

```python
from autogen import ConversableAgent

agent = ConversableAgent(
    name="Basic Agent",
    system_message="You are a helpful assistant.",
    human_input_mode="NEVER",
    llm_config={
        "config_list": [{"model": "gpt-3.5-turbo", "api_key": "your-api-key"}]
    }
)
```

### AssistantAgent

The `AssistantAgent` is a specialized version of `ConversableAgent` designed to act as an AI assistant. It's preconfigured with settings suitable for most assistant-like tasks.

Key features:
- Optimized for assistant-like behavior
- Can execute Python code (if configured)
- Suitable for complex problem-solving tasks

Example of creating an `AssistantAgent`:

```python
from autogen import AssistantAgent

assistant = AssistantAgent(
    name="AI Assistant",
    system_message="You are a knowledgeable AI assistant with expertise in various fields.",
    llm_config={
        "config_list": [{"model": "gpt-4", "api_key": "your-api-key"}]
    }
)
```

### UserProxyAgent

The `UserProxyAgent` is designed to represent a human user in the conversation. It can interact with other agents and execute code on behalf of the user.

Key features:
- Can execute code and provide feedback
- Supports different human input modes
- Useful for automating user-like interactions

Example of creating a `UserProxyAgent`:

```python
from autogen import UserProxyAgent

user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="ALWAYS",
    max_consecutive_auto_reply=3,
    code_execution_config={"work_dir": "coding", "use_docker": True}
)
```

## Creating and Customizing Agents

When creating agents, you have a wide range of configuration options to tailor their behavior to your specific needs. Here are some key parameters you can customize:

- `name`: A unique identifier for the agent
- `system_message`: Instructions that define the agent's role and behavior
- `human_input_mode`: Determines when to ask for human input (e.g., "ALWAYS", "NEVER", "TERMINATE")
- `llm_config`: Configuration for the language model used by the agent
- `code_execution_config`: Settings for code execution capabilities

Let's create a more specialized assistant agent:

```python
from autogen import AssistantAgent

coding_assistant = AssistantAgent(
    name="Coding Assistant",
    system_message="You are an expert Python programmer. Provide clear, efficient, and well-documented code solutions.",
    human_input_mode="TERMINATE",
    llm_config={
        "config_list": [{"model": "gpt-4", "api_key": "your-api-key"}],
        "temperature": 0.7,
        "request_timeout": 120
    },
    code_execution_config={
        "work_dir": "python_workspace",
        "use_docker": False,
        "timeout": 60
    }
)
```

In this example, we've created a coding assistant with specific instructions, a custom LLM configuration, and code execution settings.

## Agent Properties and Methods

Agents in Autogen come with a variety of properties and methods that allow you to interact with them and customize their behavior. Here are some important ones:

Properties:
- `name`: The name of the agent
- `system_message`: The system message defining the agent's role
- `human_input_mode`: The current human input mode
- `llm_config`: The language model configuration

Methods:
- `send(message, recipient)`: Send a message to another agent
- `receive(message, sender)`: Process a received message
- `generate_reply(messages)`: Generate a reply based on the conversation history
- `execute_code(code)`: Execute a piece of code (if code execution is enabled)
- `update_system_message(new_message)`: Update the agent's system message

Example of using agent methods:

```python
from autogen import AssistantAgent, UserProxyAgent

# Create agents
assistant = AssistantAgent("AI Assistant")
user = UserProxyAgent("User")

# Start a conversation
user.send("Hello, can you help me with a Python problem?", assistant)

# Generate and send a reply
reply = assistant.generate_reply(assistant.chat_messages[user])
assistant.send(reply, user)

# Update the assistant's system message
assistant.update_system_message("You are now a data science expert specializing in pandas and numpy.")
```

## Implementing Custom Agents

While Autogen's built-in agents are versatile, you may sometimes need to create custom agents with specialized behaviors. You can do this by subclassing `ConversableAgent` or one of its descendants.

Here's an example of a custom agent that specializes in data analysis:

```python
# File: agents/data_analyst_agent.py

from autogen import AssistantAgent
import pandas as pd

class DataAnalystAgent(AssistantAgent):
    def __init__(self, name, system_message="You are a data analysis expert.", **kwargs):
        super().__init__(name, system_message, **kwargs)
        self.dataframes = {}

    def load_data(self, filename, sheet_name=0):
        """Load data from an Excel file into a pandas DataFrame."""
        self.dataframes[filename] = pd.read_excel(filename, sheet_name=sheet_name)
        return f"Data from {filename} loaded successfully."

    def analyze_data(self, filename, column):
        """Perform basic analysis on a specified column."""
        if filename not in self.dataframes:
            return f"Error: {filename} not loaded. Please load the data first."

        df = self.dataframes[filename]
        if column not in df.columns:
            return f"Error: Column '{column}' not found in {filename}."

        analysis = df[column].describe()
        return f"Analysis of {column} in {filename}:\n{analysis}"

    def generate_reply(self, messages, sender):
        """Override to include data analysis capabilities."""
        last_message = messages[-1]
        if "load_data" in last_message["content"]:
            # Extract filename from the message
            filename = last_message["content"].split("load_data")[-1].strip()
            return self.load_data(filename)
        elif "analyze_data" in last_message["content"]:
            # Extract filename and column from the message
            parts = last_message["content"].split("analyze_data")[-1].strip().split(",")
            if len(parts) != 2:
                return "Error: Please provide both filename and column name."
            filename, column = parts
            return self.analyze_data(filename.strip(), column.strip())
        else:
            # For other messages, use the default generate_reply
            return super().generate_reply(messages, sender)
```

To use this custom agent:

```python
# File: main.py

from agents.data_analyst_agent import DataAnalystAgent

analyst = DataAnalystAgent(
    name="Data Analyst",
    llm_config={
        "config_list": [{"model": "gpt-4", "api_key": "your-api-key"}]
    }
)

# Use the custom agent
analyst.send("Please load_data sales_data.xlsx", analyst)
analyst.send("Now, analyze_data sales_data.xlsx, Revenue", analyst)
```

## Practical Examples

Let's look at a more complex example that demonstrates the interaction between multiple agents:

```python
# File: main.py

from autogen import AssistantAgent, UserProxyAgent
from agents.data_analyst_agent import DataAnalystAgent

# Create agents
user = UserProxyAgent("User")
coding_assistant = AssistantAgent("Coding Assistant", system_message="You are an expert Python programmer.")
data_analyst = DataAnalystAgent("Data Analyst")

# Set up a group chat
agents = [user, coding_assistant, data_analyst]

# Start the conversation
user.send("I need help analyzing our sales data and creating a visualization.", agents)

# The conversation continues with agents collaborating to solve the task
# (In a real scenario, you would implement logic to manage turn-taking and task delegation)
```

This example showcases how different specialized agents can work together to solve a complex task involving data analysis and visualization.

## Best Practices

When working with Autogen agents, keep these best practices in mind:

1. **Clear Role Definition**: Provide clear and specific system messages to define each agent's role and capabilities.

2. **Proper Error Handling**: Implement robust error handling in custom agents to gracefully manage unexpected inputs or situations.

3. **Modular Design**: Create specialized agents for different tasks, allowing for better code organization and reusability.

4. **Security Considerations**: Be cautious when allowing agents to execute code, especially in production environments. Use sandboxing techniques like Docker when possible.

5. **Conversation Management**: Implement proper conversation management to ensure smooth interactions between multiple agents.

6. **Testing**: Thoroughly test your agents with various inputs to ensure they behave as expected in different scenarios.

7. **Documentation**: Maintain clear documentation for your custom agents, including their purpose, capabilities, and any special usage instructions.

## Conclusion

In this lesson, we've explored the world of Autogen agents, from the built-in types to creating custom agents for specialized tasks. We've seen how to create, configure, and use these agents in various scenarios.

By mastering Autogen agents, you'll be well-equipped to build complex, AI-powered applications that can handle a wide range of tasks through natural language interactions. In the next lesson, we'll dive deeper into managing conversations between these agents, allowing you to create even more sophisticated workflows.

Remember to experiment with different agent configurations and custom implementations to find the best approach for your specific use cases. Happy coding!

```

# lesson-4-mastering-conversations-in-autogen (1).md

```
# Lesson 4: Mastering Conversations in Autogen

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Initiating and Managing Conversations](#initiating-and-managing-conversations)
4. [Message Handling and Processing](#message-handling-and-processing)
5. [Implementing Conversation Flows](#implementing-conversation-flows)
6. [Advanced Conversation Techniques](#advanced-conversation-techniques)
   - [Group Chats](#group-chats)
   - [Nested Conversations](#nested-conversations)
7. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll dive deep into mastering conversations in Autogen. We'll explore how to initiate and manage conversations, handle messages, implement various conversation flows, and use advanced techniques like group chats and nested conversations. By the end of this lesson, you'll have a comprehensive understanding of how to create complex, multi-agent conversations using Autogen.

## Project Structure

Before we begin, let's look at the typical project structure for an Autogen application focusing on conversations:

```
autogen_project/
│
├── main.py
├── agents/
│   ├── __init__.py
│   ├── assistant_agent.py
│   ├── user_proxy_agent.py
│   └── custom_agent.py
│
├── conversations/
│   ├── __init__.py
│   ├── basic_conversation.py
│   ├── group_chat.py
│   └── nested_conversation.py
│
├── utils/
│   ├── __init__.py
│   └── message_utils.py
│
└── config/
    └── config.json
```

This structure organizes our code into separate modules for agents, conversations, and utilities, making it easier to manage and extend our application.

## Initiating and Managing Conversations

Let's start by looking at how to initiate and manage a basic conversation between two agents in Autogen.

```python
# File: conversations/basic_conversation.py

from autogen import AssistantAgent, UserProxyAgent, config_list_from_json

# Load LLM inference endpoints from an env variable or a file
# See https://microsoft.github.io/autogen/docs/FAQ#set-your-api-endpoints
config_list = config_list_from_json(env_or_file="OAI_CONFIG_LIST")

assistant = AssistantAgent("assistant", llm_config={"config_list": config_list})
user_proxy = UserProxyAgent("user_proxy", code_execution_config={"work_dir": "coding"})

# Initiate the chat
user_proxy.initiate_chat(
    assistant,
    message="Hello! Can you help me write a Python function to calculate the Fibonacci sequence?"
)
```

In this example, we create an `AssistantAgent` and a `UserProxyAgent`, then initiate a chat between them. The `UserProxyAgent` starts the conversation with a request for help with a Python function.

## Message Handling and Processing

Autogen provides powerful mechanisms for handling and processing messages within conversations. Let's explore how to customize message handling:

```python
# File: utils/message_utils.py

def custom_message_handler(message, sender, recipient):
    print(f"Message from {sender.name} to {recipient.name}: {message}")
    # You can modify the message here if needed
    return message

# File: conversations/basic_conversation.py

from utils.message_utils import custom_message_handler

assistant.register_reply(
    UserProxyAgent,
    reply_func=custom_message_handler,
    config={"memory": None}  # You can add custom configuration here
)
```

By registering a custom reply function, we can intercept and process messages before they're handled by the default logic. This allows for logging, message modification, or triggering custom behaviors based on message content.

## Implementing Conversation Flows

Autogen allows for the implementation of complex conversation flows. Let's create a multi-turn conversation with conditional branching:

```python
# File: conversations/complex_flow.py

from autogen import AssistantAgent, UserProxyAgent, config_list_from_json

config_list = config_list_from_json(env_or_file="OAI_CONFIG_LIST")

assistant = AssistantAgent("assistant", llm_config={"config_list": config_list})
user_proxy = UserProxyAgent("user_proxy", code_execution_config={"work_dir": "coding"})

def conversation_flow():
    response = user_proxy.initiate_chat(
        assistant,
        message="Can you explain the concept of recursion in programming?"
    )
    
    if "example" in response.lower():
        user_proxy.send(
            "Great! Can you provide a Python code example of recursion?",
            assistant
        )
    else:
        user_proxy.send(
            "Could you elaborate more on how recursion works in practice?",
            assistant
        )
    
    # Continue the conversation based on the assistant's responses
    while True:
        last_message = user_proxy.last_message()
        if "thank you" in last_message.lower():
            user_proxy.send("You're welcome! Is there anything else I can help you with?", assistant)
            break

conversation_flow()
```

This example demonstrates a conversation flow with conditional branching based on the content of the assistant's responses. It also shows how to continue a conversation until a certain condition is met.

## Advanced Conversation Techniques

### Group Chats

Autogen supports group chats involving multiple agents. Here's an example of setting up a group chat:

```python
# File: conversations/group_chat.py

from autogen import AssistantAgent, UserProxyAgent, GroupChat, GroupChatManager, config_list_from_json

config_list = config_list_from_json(env_or_file="OAI_CONFIG_LIST")

# Create multiple agents
assistant1 = AssistantAgent("assistant1", llm_config={"config_list": config_list})
assistant2 = AssistantAgent("assistant2", llm_config={"config_list": config_list})
user_proxy = UserProxyAgent("user_proxy", code_execution_config={"work_dir": "coding"})

# Create a group chat
groupchat = GroupChat(agents=[user_proxy, assistant1, assistant2], messages=[], max_round=12)
manager = GroupChatManager(groupchat=groupchat, llm_config={"config_list": config_list})

# Start the group chat
user_proxy.initiate_chat(
    manager,
    message="Let's discuss the pros and cons of different sorting algorithms."
)
```

In this example, we create multiple agents and add them to a `GroupChat`. The `GroupChatManager` orchestrates the conversation, allowing agents to interact in a group setting.

### Nested Conversations

Nested conversations allow for more complex interaction patterns, where one conversation can trigger sub-conversations. Here's an example:

```python
# File: conversations/nested_conversation.py

from autogen import AssistantAgent, UserProxyAgent, config_list_from_json

config_list = config_list_from_json(env_or_file="OAI_CONFIG_LIST")

assistant = AssistantAgent("assistant", llm_config={"config_list": config_list})
researcher = AssistantAgent("researcher", llm_config={"config_list": config_list})
user_proxy = UserProxyAgent("user_proxy", code_execution_config={"work_dir": "coding"})

def nested_conversation():
    user_proxy.initiate_chat(
        assistant,
        message="I need help understanding quantum computing."
    )
    
    # Based on the assistant's response, initiate a nested conversation with the researcher
    last_assistant_message = assistant.last_message()
    if "complex" in last_assistant_message.lower():
        user_proxy.initiate_chat(
            researcher,
            message="Can you provide a more detailed explanation of quantum superposition?"
        )
        
        # Use the researcher's response to continue the conversation with the assistant
        researcher_explanation = researcher.last_message()
        user_proxy.send(
            f"The researcher explained superposition as follows: {researcher_explanation}. "
            "Can you use this to give me a simpler explanation of quantum computing?",
            assistant
        )

nested_conversation()
```

This example demonstrates how to create a nested conversation where the user interacts with an assistant, and based on the response, initiates a sub-conversation with a researcher before returning to the main conversation.

## Conclusion

In this lesson, we've explored the various aspects of mastering conversations in Autogen. We've covered initiating and managing conversations, handling messages, implementing complex conversation flows, and advanced techniques like group chats and nested conversations.

By leveraging these features, you can create sophisticated AI applications that involve multi-agent interactions, conditional conversation flows, and complex information exchange patterns. As you continue to work with Autogen, experiment with combining these techniques to create even more powerful and flexible conversational AI systems.

Remember to always consider the context of your application and the specific requirements of your use case when designing conversation flows. With practice, you'll be able to create highly interactive and dynamic AI-powered conversations using Autogen.

```

# lesson-5-working-with-language-models-in-autogen.md

```
# Lesson 5: Working with Language Models in Autogen

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Integration with OpenAI and Other LLM Providers](#integration-with-openai-and-other-llm-providers)
4. [Configuring and Using Different Models](#configuring-and-using-different-models)
5. [Handling API Calls and Rate Limiting](#handling-api-calls-and-rate-limiting)
6. [Implementing Custom LLM Clients](#implementing-custom-llm-clients)
7. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll dive deep into working with Language Models (LLMs) in Autogen. We'll explore how Autogen integrates with various LLM providers, configure and use different models, handle API calls and rate limiting, and even implement custom LLM clients. This knowledge is crucial for leveraging the full power of Autogen in your AI-powered applications.

## Project Structure

Before we begin, let's look at the project structure we'll be working with:

```
autogen_project/
│
├── src/
│   ├── __init__.py
│   ├── config.py
│   ├── llm_integration.py
│   ├── api_handler.py
│   └── custom_llm_client.py
│
├── tests/
│   ├── __init__.py
│   ├── test_llm_integration.py
│   ├── test_api_handler.py
│   └── test_custom_llm_client.py
│
├── .env
├── requirements.txt
└── main.py
```

This structure organizes our code into separate modules for better maintainability and testing.

## Integration with OpenAI and Other LLM Providers

Autogen provides a flexible framework for integrating with various LLM providers. Let's start by looking at how to integrate with OpenAI, and then we'll explore how to extend this to other providers.

### OpenAI Integration

First, let's set up our configuration in `src/config.py`:

```python
# src/config.py
import os
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1")

OPENAI_CONFIG = {
    "api_key": OPENAI_API_KEY,
    "api_base": OPENAI_API_BASE,
}
```

Now, let's create our LLM integration module in `src/llm_integration.py`:

```python
# src/llm_integration.py
from autogen import OpenAIWrapper
from .config import OPENAI_CONFIG

def get_openai_client():
    return OpenAIWrapper(**OPENAI_CONFIG)

def generate_response(client, prompt, model="gpt-3.5-turbo"):
    response = client.create(model=model, messages=[{"role": "user", "content": prompt}])
    return response.choices[0].message.content

# Usage example
if __name__ == "__main__":
    client = get_openai_client()
    prompt = "Explain the concept of machine learning in simple terms."
    response = generate_response(client, prompt)
    print(response)
```

### Integrating with Other LLM Providers

Autogen's `OpenAIWrapper` class is designed to work with OpenAI-compatible APIs. This means we can use it with other providers that offer OpenAI-compatible endpoints, such as Azure OpenAI or self-hosted models like LLaMA.

Here's an example of how to integrate with Azure OpenAI:

```python
# src/config.py
# ... (previous code)

AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_API_BASE = os.getenv("AZURE_OPENAI_API_BASE")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15")

AZURE_OPENAI_CONFIG = {
    "api_key": AZURE_OPENAI_API_KEY,
    "api_base": AZURE_OPENAI_API_BASE,
    "api_type": "azure",
    "api_version": AZURE_OPENAI_API_VERSION,
}

# src/llm_integration.py
# ... (previous code)

def get_azure_openai_client():
    return OpenAIWrapper(**AZURE_OPENAI_CONFIG)

def generate_azure_response(client, prompt, model="gpt-35-turbo"):
    response = client.create(model=model, messages=[{"role": "user", "content": prompt}])
    return response.choices[0].message.content
```

## Configuring and Using Different Models

Autogen allows you to easily switch between different models. Let's expand our `llm_integration.py` to support multiple models:

```python
# src/llm_integration.py
# ... (previous code)

AVAILABLE_MODELS = {
    "gpt-3.5-turbo": {"provider": "openai", "max_tokens": 4096},
    "gpt-4": {"provider": "openai", "max_tokens": 8192},
    "gpt-35-turbo": {"provider": "azure", "max_tokens": 4096},
    "gpt-4": {"provider": "azure", "max_tokens": 8192},
}

def get_model_config(model_name):
    return AVAILABLE_MODELS.get(model_name, AVAILABLE_MODELS["gpt-3.5-turbo"])

def generate_response_with_model(prompt, model_name="gpt-3.5-turbo"):
    model_config = get_model_config(model_name)
    client = get_openai_client() if model_config["provider"] == "openai" else get_azure_openai_client()
    
    response = client.create(
        model=model_name,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=model_config["max_tokens"]
    )
    return response.choices[0].message.content

# Usage example
if __name__ == "__main__":
    prompt = "Explain the difference between supervised and unsupervised learning."
    response_gpt3 = generate_response_with_model(prompt, "gpt-3.5-turbo")
    response_gpt4 = generate_response_with_model(prompt, "gpt-4")
    
    print("GPT-3.5 Response:", response_gpt3)
    print("GPT-4 Response:", response_gpt4)
```

This setup allows you to easily switch between different models and providers while keeping your main code clean and organized.

## Handling API Calls and Rate Limiting

When working with LLMs, it's crucial to handle API calls efficiently and respect rate limits. Let's create an `api_handler.py` module to manage this:

```python
# src/api_handler.py
import time
import asyncio
from typing import Callable, Any
from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type

class APIHandler:
    def __init__(self, rate_limit_per_minute: int = 60):
        self.rate_limit_per_minute = rate_limit_per_minute
        self.calls_made = 0
        self.start_time = time.time()

    async def _wait_for_rate_limit(self):
        elapsed_time = time.time() - self.start_time
        if elapsed_time < 60 and self.calls_made >= self.rate_limit_per_minute:
            wait_time = 60 - elapsed_time
            await asyncio.sleep(wait_time)
            self.calls_made = 0
            self.start_time = time.time()
        elif elapsed_time >= 60:
            self.calls_made = 0
            self.start_time = time.time()

    @retry(
        wait=wait_exponential(multiplier=1, min=4, max=10),
        stop=stop_after_attempt(5),
        retry=retry_if_exception_type(Exception)
    )
    async def call_api(self, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        await self._wait_for_rate_limit()
        self.calls_made += 1
        return await func(*args, **kwargs)

# Usage example
api_handler = APIHandler(rate_limit_per_minute=60)

async def make_api_call(client, prompt, model):
    return await api_handler.call_api(client.create, model=model, messages=[{"role": "user", "content": prompt}])

# In your main code:
# response = await make_api_call(client, prompt, model)
```

This `APIHandler` class manages rate limiting and implements exponential backoff for retries in case of failures.

## Implementing Custom LLM Clients

While Autogen provides built-in support for OpenAI-compatible APIs, you might need to integrate with other LLM providers or custom models. Let's create a custom LLM client as an example:

```python
# src/custom_llm_client.py
import aiohttp
from typing import List, Dict, Any

class CustomLLMClient:
    def __init__(self, api_base: str, api_key: str):
        self.api_base = api_base
        self.api_key = api_key

    async def create(self, model: str, messages: List[Dict[str, str]], **kwargs: Any) -> Dict[str, Any]:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        data = {
            "model": model,
            "messages": messages,
            **kwargs
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(f"{self.api_base}/v1/chat/completions", headers=headers, json=data) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    raise Exception(f"API call failed with status {response.status}: {await response.text()}")

# Usage example
custom_client = CustomLLMClient(api_base="https://api.customllm.com", api_key="your-api-key")

async def generate_custom_response(prompt: str, model: str = "custom-gpt"):
    response = await custom_client.create(
        model=model,
        messages=[{"role": "user", "content": prompt}]
    )
    return response["choices"][0]["message"]["content"]

# In your main code:
# response = await generate_custom_response("Tell me a joke about programming.")
```

This custom client can be easily integrated into your Autogen project, allowing you to use a wider range of LLM providers or your own models.

## Conclusion

In this lesson, we've explored working with Language Models in Autogen. We covered:

1. Integrating with OpenAI and other LLM providers
2. Configuring and using different models
3. Handling API calls and rate limiting
4. Implementing custom LLM clients

By mastering these concepts, you'll be able to leverage the full power of Autogen in your AI applications, creating more flexible and robust systems that can work with a variety of language models and providers.

Remember to always consider factors such as API usage costs, rate limits, and the specific capabilities of each model when designing your applications. Happy coding!

```

# lesson-6-code-execution-and-tool-usage.md

```
# Lesson 6: Code Execution and Tool Usage in Autogen

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding Code Execution in Autogen](#understanding-code-execution-in-autogen)
   - [CodeExecutor Interface](#codeexecutor-interface)
   - [Local Command Line Executor](#local-command-line-executor)
   - [Docker Command Line Executor](#docker-command-line-executor)
4. [Implementing and Using Tools](#implementing-and-using-tools)
   - [Function-based Tools](#function-based-tools)
   - [Class-based Tools](#class-based-tools)
5. [Code Sanitization and Security Considerations](#code-sanitization-and-security-considerations)
6. [Advanced Code Execution Techniques](#advanced-code-execution-techniques)
   - [Jupyter Integration](#jupyter-integration)
   - [Custom Code Executors](#custom-code-executors)
7. [Practical Examples](#practical-examples)
   - [Example 1: Simple Code Execution](#example-1-simple-code-execution)
   - [Example 2: Implementing a Custom Tool](#example-2-implementing-a-custom-tool)
   - [Example 3: Advanced Code Execution with Docker](#example-3-advanced-code-execution-with-docker)
8. [Conclusion](#conclusion)

## Introduction

Code execution and tool usage are fundamental features of Autogen that allow agents to interact with the environment, perform computations, and utilize external resources. This lesson will dive deep into how Autogen handles code execution, implements tools, and ensures security in these operations.

## Project Structure

Before we delve into the details, let's look at the project structure relevant to code execution and tool usage in Autogen:

```
autogen/
├── coding/
│   ├── base.py
│   ├── docker_commandline_code_executor.py
│   ├── factory.py
│   ├── local_commandline_code_executor.py
│   ├── markdown_code_extractor.py
│   ├── utils.py
│   └── jupyter/
│       ├── base.py
│       ├── embedded_ipython_code_executor.py
│       ├── jupyter_client.py
│       └── jupyter_code_executor.py
├── agentchat/
│   ├── conversable_agent.py
│   └── assistant_agent.py
└── code_utils.py
```

This structure shows the main components involved in code execution and tool usage. The `coding/` directory contains various code executors and utilities, while the `agentchat/` directory includes agent implementations that utilize these features.

## Understanding Code Execution in Autogen

Autogen provides a flexible system for executing code generated or requested by agents. The core of this system is defined in the `coding/base.py` file.

### CodeExecutor Interface

The `CodeExecutor` class defines the interface for all code executors in Autogen:

```python
from abc import ABC, abstractmethod

class CodeExecutor(ABC):
    @abstractmethod
    def execute_code_blocks(self, code_blocks: List[CodeBlock]) -> CodeResult:
        pass

    @abstractmethod
    def restart(self) -> None:
        pass
```

This abstract base class ensures that all code executors implement the `execute_code_blocks` method for running code and the `restart` method for resetting the execution environment.

### Local Command Line Executor

The `LocalCommandLineCodeExecutor` class in `local_commandline_code_executor.py` provides a way to execute code on the local machine:

```python
from autogen.coding.base import CodeExecutor, CodeResult

class LocalCommandLineCodeExecutor(CodeExecutor):
    def __init__(self, timeout: int = 60, work_dir: Union[Path, str] = Path(".")):
        self._timeout = timeout
        self._work_dir = Path(work_dir)

    def execute_code_blocks(self, code_blocks: List[CodeBlock]) -> CodeResult:
        # Implementation details...

    def restart(self) -> None:
        # Implementation details...
```

This executor runs code in a subprocess on the local machine, with configurable timeout and working directory.

### Docker Command Line Executor

For improved isolation and security, Autogen provides the `DockerCommandLineCodeExecutor` in `docker_commandline_code_executor.py`:

```python
import docker
from autogen.coding.base import CodeExecutor, CodeResult

class DockerCommandLineCodeExecutor(CodeExecutor):
    def __init__(
        self,
        image: str = "python:3-slim",
        container_name: Optional[str] = None,
        timeout: int = 60,
        work_dir: Union[Path, str] = Path("."),
    ):
        # Initialization code...

    def execute_code_blocks(self, code_blocks: List[CodeBlock]) -> CodeResult:
        # Implementation details...

    def restart(self) -> None:
        # Implementation details...
```

This executor runs code inside a Docker container, providing better isolation from the host system.

## Implementing and Using Tools

Tools in Autogen are functions or methods that agents can use to perform specific tasks. They can be implemented in two main ways: function-based and class-based.

### Function-based Tools

Function-based tools are simple Python functions that can be registered with an agent:

```python
from autogen import ConversableAgent

def calculator(expression: str) -> float:
    return eval(expression)

agent = ConversableAgent("MathAgent")
agent.register_function(
    function_map={
        "calculator": calculator
    }
)
```

### Class-based Tools

For more complex tools, you can create a class that encapsulates the tool's functionality:

```python
class DatabaseTool:
    def __init__(self, connection_string):
        self.conn = connect_to_database(connection_string)

    def query(self, sql: str) -> List[Dict]:
        cursor = self.conn.cursor()
        cursor.execute(sql)
        return cursor.fetchall()

agent = ConversableAgent("DBAgent")
db_tool = DatabaseTool("connection_string_here")
agent.register_function(
    function_map={
        "db_query": db_tool.query
    }
)
```

## Code Sanitization and Security Considerations

Autogen implements several security measures to prevent malicious code execution:

1. **Input Sanitization**: The `_sanitize_command` method in `LocalCommandLineCodeExecutor` checks for potentially dangerous commands:

```python
def _sanitize_command(lang: str, code: str) -> None:
    dangerous_patterns = [
        (r"\brm\s+-rf\b", "Use of 'rm -rf' command is not allowed."),
        (r"\bmv\b.*?\s+/dev/null", "Moving files to /dev/null is not allowed."),
        # ... more patterns ...
    ]
    for pattern, message in dangerous_patterns:
        if re.search(pattern, code):
            raise ValueError(f"Potentially dangerous command detected: {message}")
```

2. **Execution in Docker**: Using `DockerCommandLineCodeExecutor` provides an additional layer of isolation.

3. **Timeout Limits**: All code executors have a configurable timeout to prevent infinite loops or long-running processes.

## Advanced Code Execution Techniques

### Jupyter Integration

Autogen provides integration with Jupyter notebooks through the `jupyter/` submodule:

```python
from autogen.coding.jupyter import JupyterCodeExecutor

executor = JupyterCodeExecutor(
    kernel_name="python3",
    timeout=120
)

result = executor.execute_code_blocks([
    CodeBlock(code="import pandas as pd\ndf = pd.DataFrame({'A': [1, 2, 3]})\ndf", language="python")
])
```

This allows for interactive code execution and rich output handling.

### Custom Code Executors

You can create custom code executors by subclassing `CodeExecutor` and implementing the required methods:

```python
from autogen.coding.base import CodeExecutor, CodeResult, CodeBlock

class MyCustomExecutor(CodeExecutor):
    def execute_code_blocks(self, code_blocks: List[CodeBlock]) -> CodeResult:
        # Custom implementation...

    def restart(self) -> None:
        # Custom implementation...
```

## Practical Examples

### Example 1: Simple Code Execution

Let's create a simple agent that can execute Python code:

```python
from autogen import ConversableAgent, UserProxyAgent
from autogen.coding import LocalCommandLineCodeExecutor

# Create a code executor
executor = LocalCommandLineCodeExecutor(timeout=30)

# Create an agent with code execution capability
coder_agent = ConversableAgent(
    "PythonCoder",
    code_execution_config={"executor": executor}
)

# Create a user proxy agent
user_proxy = UserProxyAgent("User")

# Start a conversation
user_proxy.initiate_chat(
    coder_agent,
    message="Write a Python function to calculate the fibonacci sequence up to n terms and run it for n=10"
)
```

### Example 2: Implementing a Custom Tool

Let's implement a custom tool for currency conversion:

```python
import requests
from autogen import ConversableAgent, UserProxyAgent

class CurrencyConverter:
    def convert(self, amount: float, from_currency: str, to_currency: str) -> float:
        url = f"https://api.exchangerate-api.com/v4/latest/{from_currency}"
        response = requests.get(url)
        data = response.json()
        rate = data["rates"][to_currency]
        return amount * rate

converter = CurrencyConverter()

agent = ConversableAgent(
    "FinanceAgent",
    function_map={"convert_currency": converter.convert}
)

user_proxy = UserProxyAgent("User")

user_proxy.initiate_chat(
    agent,
    message="Convert 100 USD to EUR"
)
```

### Example 3: Advanced Code Execution with Docker

For secure code execution, we can use the Docker-based executor:

```python
from autogen import ConversableAgent, UserProxyAgent
from autogen.coding import DockerCommandLineCodeExecutor

# Create a Docker-based code executor
executor = DockerCommandLineCodeExecutor(
    image="python:3.9-slim",
    timeout=60
)

# Create an agent with Docker-based code execution
secure_coder = ConversableAgent(
    "SecureCoder",
    code_execution_config={"executor": executor}
)

user_proxy = UserProxyAgent("User")

user_proxy.initiate_chat(
    secure_coder,
    message="Write and run a Python script that reads a file named 'data.txt' and counts the occurrences of each word"
)
```

## Conclusion

In this lesson, we've explored the intricacies of code execution and tool usage in Autogen. We've covered the basic architecture of code executors, how to implement and use tools, security considerations, and advanced techniques like Jupyter integration and custom executors. By mastering these concepts, you can create powerful and flexible agents capable of performing a wide range of tasks securely and efficiently.

Remember to always consider security implications when allowing code execution, especially in production environments. Prefer using isolated environments like Docker when dealing with untrusted code, and always sanitize inputs to prevent potential security vulnerabilities.

In the next lesson, we'll dive into enhancing Autogen with plugins and extensions, which will allow you to further expand the capabilities of your agents and integrate them with external services and APIs.

```

# lesson-7-enhancing-autogen-with-plugins-and-extensions.md

```
# Lesson 7: Enhancing Autogen with Plugins and Extensions

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Creating Custom Plugins](#creating-custom-plugins)
4. [Extending Autogen's Functionality](#extending-autogens-functionality)
5. [Integration with External Services and APIs](#integration-with-external-services-and-apis)
6. [Best Practices for Plugin Development](#best-practices-for-plugin-development)
7. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll explore how to enhance Autogen's capabilities through plugins and extensions. Autogen's flexible architecture allows developers to create custom components that seamlessly integrate with the core functionality. We'll cover creating custom plugins, extending Autogen's functionality, integrating with external services, and best practices for plugin development.

## 2. Project Structure

Before we dive into the details, let's look at a typical project structure for an Autogen application with custom plugins and extensions:

```
autogen_project/
│
├── autogen/
│   ├── __init__.py
│   ├── agentchat/
│   ├── code_utils.py
│   └── ...
│
├── custom_plugins/
│   ├── __init__.py
│   ├── weather_plugin.py
│   ├── database_plugin.py
│   └── nlp_plugin.py
│
├── extensions/
│   ├── __init__.py
│   ├── custom_agent.py
│   └── advanced_conversation.py
│
├── main.py
├── requirements.txt
└── README.md
```

In this structure, we have a `custom_plugins` directory for our plugin implementations and an `extensions` directory for more substantial extensions to Autogen's functionality.

## 3. Creating Custom Plugins

Custom plugins in Autogen are typically implemented as Python classes that extend or interact with Autogen's core components. Let's create a simple weather plugin as an example.

### Example: Weather Plugin

```python
# custom_plugins/weather_plugin.py

import requests
from autogen import ConversableAgent

class WeatherPlugin:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "http://api.openweathermap.org/data/2.5/weather"

    def get_weather(self, city):
        params = {
            "q": city,
            "appid": self.api_key,
            "units": "metric"
        }
        response = requests.get(self.base_url, params=params)
        data = response.json()
        if response.status_code == 200:
            return f"The current temperature in {city} is {data['main']['temp']}°C with {data['weather'][0]['description']}."
        else:
            return f"Error: Unable to fetch weather data for {city}."

class WeatherAgent(ConversableAgent):
    def __init__(self, name, weather_plugin):
        super().__init__(name)
        self.weather_plugin = weather_plugin

    def get_weather(self, city):
        return self.weather_plugin.get_weather(city)

# Usage
weather_plugin = WeatherPlugin("your_api_key_here")
weather_agent = WeatherAgent("WeatherBot", weather_plugin)

# In a conversation
response = weather_agent.get_weather("London")
print(response)
```

In this example, we've created a `WeatherPlugin` class that interacts with an external weather API, and a `WeatherAgent` class that uses this plugin to provide weather information in conversations.

## 4. Extending Autogen's Functionality

To extend Autogen's core functionality, we can create custom classes that inherit from Autogen's base classes. Let's create an advanced conversation handler as an example.

### Example: Advanced Conversation Handler

```python
# extensions/advanced_conversation.py

from autogen import ConversableAgent
from typing import List, Dict, Any

class AdvancedConversationHandler:
    def __init__(self):
        self.conversation_history = []

    def add_message(self, sender: str, message: str):
        self.conversation_history.append({"sender": sender, "message": message})

    def get_summary(self) -> str:
        # Implement a summarization logic here
        return "Summary of the conversation..."

    def get_sentiment(self) -> str:
        # Implement sentiment analysis here
        return "Overall sentiment of the conversation..."

class AdvancedAgent(ConversableAgent):
    def __init__(self, name: str):
        super().__init__(name)
        self.conversation_handler = AdvancedConversationHandler()

    def send(self, message: Union[Dict, str], recipient: Agent, request_reply: Optional[bool] = None, silent: Optional[bool] = False):
        self.conversation_handler.add_message(self.name, message)
        super().send(message, recipient, request_reply, silent)

    def receive(self, message: Union[Dict, str], sender: Agent, request_reply: Optional[bool] = None, silent: Optional[bool] = False):
        self.conversation_handler.add_message(sender.name, message)
        super().receive(message, sender, request_reply, silent)

    def get_conversation_summary(self) -> str:
        return self.conversation_handler.get_summary()

    def get_conversation_sentiment(self) -> str:
        return self.conversation_handler.get_sentiment()

# Usage
advanced_agent = AdvancedAgent("AdvancedBot")
# ... use in a conversation ...
summary = advanced_agent.get_conversation_summary()
sentiment = advanced_agent.get_conversation_sentiment()
```

This example demonstrates how to extend Autogen's `ConversableAgent` class to add advanced conversation handling features like summarization and sentiment analysis.

## 5. Integration with External Services and APIs

Integrating external services and APIs can greatly enhance the capabilities of your Autogen application. Let's create a plugin that integrates with a database service.

### Example: Database Plugin

```python
# custom_plugins/database_plugin.py

import sqlite3
from autogen import ConversableAgent

class DatabasePlugin:
    def __init__(self, db_path):
        self.db_path = db_path

    def execute_query(self, query):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        try:
            cursor.execute(query)
            result = cursor.fetchall()
            conn.commit()
            return result
        except sqlite3.Error as e:
            return f"Database error: {e}"
        finally:
            conn.close()

class DatabaseAgent(ConversableAgent):
    def __init__(self, name, db_plugin):
        super().__init__(name)
        self.db_plugin = db_plugin

    def query_database(self, query):
        return self.db_plugin.execute_query(query)

# Usage
db_plugin = DatabasePlugin("path/to/your/database.db")
db_agent = DatabaseAgent("DBBot", db_plugin)

# In a conversation
result = db_agent.query_database("SELECT * FROM users")
print(result)
```

This example shows how to create a plugin that interacts with a SQLite database, allowing Autogen agents to perform database operations seamlessly.

## 6. Best Practices for Plugin Development

When developing plugins and extensions for Autogen, consider the following best practices:

1. **Modularity**: Keep your plugins focused on specific functionality. This makes them easier to maintain and reuse.

2. **Error Handling**: Implement robust error handling to gracefully manage failures in external services or unexpected inputs.

3. **Configuration Management**: Use configuration files or environment variables for sensitive information like API keys.

4. **Testing**: Write unit tests for your plugins to ensure they behave correctly under various conditions.

5. **Documentation**: Provide clear documentation for your plugins, including usage examples and any required setup.

6. **Version Compatibility**: Clearly specify which versions of Autogen your plugin is compatible with.

7. **Performance Considerations**: Be mindful of the performance impact of your plugins, especially when interacting with external services.

### Example: Implementing Best Practices

```python
# custom_plugins/nlp_plugin.py

import os
from dotenv import load_dotenv
from autogen import ConversableAgent
from transformers import pipeline

load_dotenv()  # Load environment variables

class NLPPlugin:
    def __init__(self):
        self.sentiment_analyzer = pipeline("sentiment-analysis")

    def analyze_sentiment(self, text):
        try:
            result = self.sentiment_analyzer(text)[0]
            return f"Sentiment: {result['label']}, Score: {result['score']:.2f}"
        except Exception as e:
            return f"Error in sentiment analysis: {str(e)}"

class NLPAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)
        self.nlp_plugin = NLPPlugin()

    def get_sentiment(self, text):
        return self.nlp_plugin.analyze_sentiment(text)

# Usage
nlp_agent = NLPAgent("NLPBot")

# In a conversation
sentiment = nlp_agent.get_sentiment("I love using Autogen for AI development!")
print(sentiment)
```

This example demonstrates best practices such as using environment variables for configuration, implementing error handling, and creating a focused, modular plugin for NLP tasks.

## 7. Conclusion

In this lesson, we've explored how to enhance Autogen with plugins and extensions. We've covered creating custom plugins, extending Autogen's core functionality, integrating with external services and APIs, and best practices for plugin development.

By leveraging these techniques, you can create powerful, flexible, and extensible AI applications using Autogen. Remember to keep your plugins modular, handle errors gracefully, and follow best practices for maintainable and efficient code.

In the next lesson, we'll dive into using Autogen for task automation, where we'll apply the concepts learned here to create complex, AI-driven workflows.

```

# lesson-8-autogen-task-automation.md

```
# Lesson 8: Autogen for Task Automation

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Designing Complex Workflows with Autogen](#designing-complex-workflows-with-autogen)
4. [Task Planning and Execution](#task-planning-and-execution)
5. [Error Handling and Recovery in Automated Tasks](#error-handling-and-recovery-in-automated-tasks)
6. [Real-world Examples of Autogen-powered Automation](#real-world-examples-of-autogen-powered-automation)
7. [Conclusion](#conclusion)

## Introduction

Welcome to Lesson 8 of our Autogen series! In this lesson, we'll explore how to leverage Autogen for task automation. We'll cover designing complex workflows, task planning and execution, error handling, and look at some real-world examples of Autogen-powered automation.

Autogen is a powerful framework that allows us to create AI agents capable of performing complex tasks and workflows. By combining these agents with well-designed automation strategies, we can create robust and efficient systems for a wide range of applications.

## Project Structure

Before we dive into the details, let's look at a typical project structure for an Autogen-based task automation system:

```
autogen-task-automation/
│
├── config/
│   ├── __init__.py
│   └── config.py
│
├── agents/
│   ├── __init__.py
│   ├── task_planner.py
│   ├── executor.py
│   └── error_handler.py
│
├── workflows/
│   ├── __init__.py
│   ├── data_processing_workflow.py
│   └── report_generation_workflow.py
│
├── utils/
│   ├── __init__.py
│   └── helpers.py
│
├── tasks/
│   ├── __init__.py
│   ├── data_collection.py
│   ├── data_analysis.py
│   └── report_writing.py
│
├── tests/
│   ├── __init__.py
│   ├── test_agents.py
│   ├── test_workflows.py
│   └── test_tasks.py
│
├── main.py
├── requirements.txt
└── README.md
```

This structure separates concerns and makes it easy to manage different components of our task automation system. Now, let's delve into each major aspect of Autogen for task automation.

## Designing Complex Workflows with Autogen

Autogen allows us to design complex workflows by creating a network of specialized agents that work together to accomplish a task. Each agent can be responsible for a specific part of the workflow, and they can communicate with each other to share information and coordinate their actions.

Let's create a simple workflow for a data processing and report generation task:

```python
# workflows/data_processing_workflow.py

from autogen import AssistantAgent, UserProxyAgent, ConversableAgent
from typing import List

class DataProcessingWorkflow:
    def __init__(self):
        self.planner = AssistantAgent("Planner", system_message="You are a task planner. Your job is to break down complex tasks into smaller, manageable steps.")
        self.data_collector = AssistantAgent("DataCollector", system_message="You are responsible for collecting and preprocessing data.")
        self.analyst = AssistantAgent("Analyst", system_message="You analyze data and draw insights.")
        self.report_writer = AssistantAgent("ReportWriter", system_message="You write clear and concise reports based on data analysis.")
        self.human = UserProxyAgent("Human", human_input_mode="NEVER")

    def run(self, task_description: str):
        # Step 1: Plan the task
        plan = self.human.initiate_chat(self.planner, message=f"Create a plan for this task: {task_description}")
        
        # Step 2: Collect and preprocess data
        data = self.human.initiate_chat(self.data_collector, message=f"Collect and preprocess data according to this plan: {plan}")
        
        # Step 3: Analyze data
        analysis = self.human.initiate_chat(self.analyst, message=f"Analyze this data and provide insights: {data}")
        
        # Step 4: Generate report
        report = self.human.initiate_chat(self.report_writer, message=f"Write a report based on this analysis: {analysis}")
        
        return report

# Usage
workflow = DataProcessingWorkflow()
result = workflow.run("Analyze sales data for Q2 2023 and generate a report on key trends and recommendations.")
print(result)
```

In this example, we've created a workflow with four specialized agents and a user proxy agent. Each agent has a specific role in the workflow, and they work together to complete the task.

## Task Planning and Execution

Effective task planning and execution are crucial for successful automation. Autogen allows us to create agents that can break down complex tasks into smaller, manageable steps and then execute those steps efficiently.

Let's enhance our workflow with a more sophisticated task planner:

```python
# agents/task_planner.py

from autogen import AssistantAgent, UserProxyAgent

class TaskPlanner(AssistantAgent):
    def __init__(self):
        super().__init__("TaskPlanner", system_message="""You are an expert task planner. Your role is to:
1. Analyze the given task and break it down into smaller, actionable steps.
2. Identify dependencies between steps.
3. Estimate the time and resources required for each step.
4. Suggest potential optimizations or parallel processes.
5. Provide a clear, numbered list of steps to accomplish the task.""")

    def plan_task(self, task_description: str) -> str:
        human = UserProxyAgent("Human", human_input_mode="NEVER")
        plan = human.initiate_chat(
            self,
            message=f"""Please create a detailed plan for the following task:
            
            {task_description}
            
            Provide your plan as a numbered list of steps, including any relevant details for each step."""
        )
        return plan

# Usage
planner = TaskPlanner()
task = "Develop a machine learning model to predict customer churn based on historical data."
detailed_plan = planner.plan_task(task)
print(detailed_plan)
```

This enhanced task planner provides a more structured approach to breaking down complex tasks. It considers dependencies, resource requirements, and potential optimizations.

For task execution, we can create an Executor agent that takes the plan and carries out each step:

```python
# agents/executor.py

from autogen import AssistantAgent, UserProxyAgent
from typing import List, Dict

class Executor(AssistantAgent):
    def __init__(self):
        super().__init__("Executor", system_message="""You are a task executor. Your role is to:
1. Take a task plan and execute each step methodically.
2. Report on the progress and outcome of each step.
3. Handle any issues that arise during execution.
4. Adapt the plan if necessary based on intermediate results.
5. Provide a summary of the execution process and final results.""")

    def execute_plan(self, plan: str) -> Dict[str, str]:
        human = UserProxyAgent("Human", human_input_mode="NEVER")
        steps = plan.split('\n')
        results = {}

        for step in steps:
            if not step.strip():
                continue
            execution_result = human.initiate_chat(
                self,
                message=f"Execute the following step and report the result: {step}"
            )
            results[step] = execution_result

        summary = human.initiate_chat(
            self,
            message="Provide a summary of the execution process and final results based on the step-by-step execution."
        )
        results["summary"] = summary

        return results

# Usage
executor = Executor()
plan = """
1. Collect and preprocess customer data
2. Perform exploratory data analysis
3. Select relevant features for the model
4. Split data into training and testing sets
5. Develop and train the machine learning model
6. Evaluate model performance
7. Fine-tune the model if necessary
8. Prepare a report on the model's performance and insights
"""
execution_results = executor.execute_plan(plan)
for step, result in execution_results.items():
    print(f"Step: {step}")
    print(f"Result: {result}\n")
```

This Executor agent takes a plan, executes each step, and provides results for each step as well as an overall summary.

## Error Handling and Recovery in Automated Tasks

Error handling and recovery are critical aspects of any robust automation system. With Autogen, we can create specialized agents to handle errors and implement recovery strategies.

Let's create an ErrorHandler agent:

```python
# agents/error_handler.py

from autogen import AssistantAgent, UserProxyAgent
from typing import Dict, Any

class ErrorHandler(AssistantAgent):
    def __init__(self):
        super().__init__("ErrorHandler", system_message="""You are an error handling expert. Your role is to:
1. Analyze error messages and execution contexts.
2. Identify the root cause of errors.
3. Suggest potential solutions or workarounds.
4. Provide guidance on how to prevent similar errors in the future.
5. If necessary, recommend adjustments to the overall task plan.""")

    def handle_error(self, error_message: str, context: Dict[str, Any]) -> str:
        human = UserProxyAgent("Human", human_input_mode="NEVER")
        error_analysis = human.initiate_chat(
            self,
            message=f"""An error occurred during task execution. Please analyze and provide guidance:

Error message: {error_message}

Execution context:
{context}

Provide your analysis and recommendations in the following format:
1. Root cause
2. Potential solutions
3. Prevention strategies
4. Recommended plan adjustments (if any)
"""
        )
        return error_analysis

# Usage
error_handler = ErrorHandler()
error_message = "ValueError: Input contains NaN, infinity or a value too large for dtype('float64')."
context = {
    "step": "Develop and train the machine learning model",
    "data_shape": "(10000, 50)",
    "model_type": "RandomForestClassifier"
}
error_analysis = error_handler.handle_error(error_message, context)
print(error_analysis)
```

This ErrorHandler agent can be integrated into our workflow to handle errors that occur during task execution. When an error is encountered, the Executor can pass the error information to the ErrorHandler, which will provide analysis and recommendations.

To make our workflow more robust, we can update the Executor to use the ErrorHandler:

```python
# agents/executor.py

from autogen import AssistantAgent, UserProxyAgent
from typing import List, Dict
from agents.error_handler import ErrorHandler

class Executor(AssistantAgent):
    def __init__(self):
        super().__init__("Executor", system_message="""You are a task executor. Your role is to:
1. Take a task plan and execute each step methodically.
2. Report on the progress and outcome of each step.
3. Handle any issues that arise during execution.
4. Adapt the plan if necessary based on intermediate results or error handling recommendations.
5. Provide a summary of the execution process and final results.""")
        self.error_handler = ErrorHandler()

    def execute_plan(self, plan: str) -> Dict[str, str]:
        human = UserProxyAgent("Human", human_input_mode="NEVER")
        steps = plan.split('\n')
        results = {}

        for step in steps:
            if not step.strip():
                continue
            try:
                execution_result = human.initiate_chat(
                    self,
                    message=f"Execute the following step and report the result: {step}"
                )
                results[step] = execution_result
            except Exception as e:
                error_analysis = self.error_handler.handle_error(str(e), {"step": step, "context": results})
                results[step] = f"Error occurred: {str(e)}\nError analysis: {error_analysis}"
                
                # Ask for guidance on how to proceed
                how_to_proceed = human.initiate_chat(
                    self,
                    message=f"An error occurred during step: {step}. Here's the error analysis: {error_analysis}. How should we proceed with the execution?"
                )
                results[f"{step}_recovery"] = how_to_proceed

        summary = human.initiate_chat(
            self,
            message="Provide a summary of the execution process, including any errors encountered and recovery steps taken, as well as the final results."
        )
        results["summary"] = summary

        return results

# Usage remains the same as before
```

This updated Executor now incorporates error handling and can adapt the execution based on error analysis and recommendations.

## Real-world Examples of Autogen-powered Automation

Let's look at a couple of real-world examples where Autogen can be used for task automation:

### 1. Automated Data Pipeline for Business Intelligence

```python
# workflows/data_pipeline_workflow.py

from autogen import AssistantAgent, UserProxyAgent
from agents.task_planner import TaskPlanner
from agents.executor import Executor

class DataPipelineWorkflow:
    def __init__(self):
        self.planner = TaskPlanner()
        self.executor = Executor()
        self.data_engineer = AssistantAgent("DataEngineer", system_message="You are a data engineer responsible for designing and implementing data pipelines.")
        self.data_analyst = AssistantAgent("DataAnalyst", system_message="You are a data analyst responsible for interpreting data and creating visualizations.")
        self.human = UserProxyAgent("Human", human_input_mode="NEVER")

    def run(self, data_sources: List[str], analysis_requirements: str):
        # Step 1: Plan the data pipeline
        pipeline_plan = self.planner.plan_task(f"Create a data pipeline that ingests data from {data_sources} and prepares it for analysis according to these requirements: {analysis_requirements}")
        
        # Step 2: Implement the data pipeline
        implementation = self.human.initiate_chat(self.data_engineer, message=f"Implement this data pipeline: {pipeline_plan}")
        
        # Step 3: Execute the data pipeline
        execution_results = self.executor.execute_plan(implementation)
        
        # Step 4: Analyze the processed data
        analysis_plan = self.planner.plan_task(f"Analyze the processed data according to these requirements: {analysis_requirements}")
        analysis_results = self.human.initiate_chat(self.data_analyst, message=f"Perform this analysis on the processed data: {analysis_plan}")
        
        # Step 5: Generate final report
        report = self.human.initiate_chat(self.data_analyst, message=f"Create a comprehensive report based on this analysis: {analysis_results}")
        
        return report

# Usage
workflow = DataPipelineWorkflow()
data_sources = ["CRM database", "Website logs", "Social media APIs"]
analysis_requirements = "Identify customer segments, analyze purchasing patterns, and predict churn risk"
final_report = workflow.run(data_sources, analysis_requirements)
print(final_report)
```

This example demonstrates how Autogen can be used to create a complex data pipeline workflow, from data ingestion to analysis and reporting.

### 2. Automated Software Testing and Deployment

```python
# workflows/ci_cd_workflow.py

from autogen import AssistantAgent, UserProxyAgent
from agents.task_planner import TaskPlanner
from agents.executor import Executor

class CICDWorkflow:
    def __init__(self):
        self.planner = TaskPlanner()
        self.executor = Executor()
        self.developer = AssistantAgent("Developer", system_message="You are a software developer responsible for implementing features and fixing bugs.")
        self.tester = AssistantAgent("Tester", system_message="You are a QA engineer 
responsible for creating and executing test cases.")
        self.devops = AssistantAgent("DevOps", system_message="You are a DevOps engineer responsible for managing the CI/CD pipeline and infrastructure.")
        self.human = UserProxyAgent("Human", human_input_mode="NEVER")

    def run(self, code_changes: str, test_requirements: str, deployment_target: str):
        # Step 1: Plan the CI/CD process
        cicd_plan = self.planner.plan_task(f"Create a CI/CD plan for these code changes: {code_changes}, with these test requirements: {test_requirements}, targeting deployment to: {deployment_target}")
        
        # Step 2: Implement and commit code changes
        implementation = self.human.initiate_chat(self.developer, message=f"Implement and commit these code changes: {code_changes}")
        
        # Step 3: Create and execute tests
        test_plan = self.human.initiate_chat(self.tester, message=f"Create and execute tests for these changes, considering the requirements: {test_requirements}")
        test_results = self.executor.execute_plan(test_plan)
        
        # Step 4: If tests pass, prepare for deployment
        if "All tests passed" in test_results.get("summary", ""):
            deployment_plan = self.human.initiate_chat(self.devops, message=f"Prepare a deployment plan for {deployment_target} based on these test results: {test_results}")
            deployment_results = self.executor.execute_plan(deployment_plan)
        else:
            deployment_results = {"summary": "Deployment aborted due to test failures"}
        
        # Step 5: Generate final report
        report = self.human.initiate_chat(self.devops, message=f"Create a comprehensive CI/CD report based on these results: {test_results} and {deployment_results}")
        
        return report

# Usage
workflow = CICDWorkflow()
code_changes = "Updated user authentication module to use OAuth 2.0"
test_requirements = "Ensure all auth flows work, check performance impact, verify security"
deployment_target = "production-cluster-a"
cicd_report = workflow.run(code_changes, test_requirements, deployment_target)
print(cicd_report)
```

This example showcases how Autogen can be used to automate a CI/CD workflow, including code implementation, testing, and deployment.

## Conclusion

In this lesson, we've explored how to leverage Autogen for task automation. We've covered:

1. Designing complex workflows by creating networks of specialized agents
2. Implementing robust task planning and execution strategies
3. Handling errors and implementing recovery mechanisms
4. Real-world examples of Autogen-powered automation in data pipelines and CI/CD processes

By using Autogen's powerful agent-based framework, we can create flexible and intelligent automation systems that can handle complex tasks, adapt to changing conditions, and provide detailed insights into their operations.

As you continue to work with Autogen for task automation, consider the following best practices:

1. Design your agents with clear, specific roles and responsibilities
2. Implement comprehensive error handling and recovery strategies
3. Use the task planner to break down complex tasks into manageable steps
4. Leverage the strengths of different agent types (AssistantAgent, UserProxyAgent, etc.) for different aspects of your workflow
5. Regularly review and refine your workflows based on execution results and performance metrics

In the next lesson, we'll dive into performance optimization and scaling techniques for Autogen-based applications, allowing you to handle even larger and more complex automation tasks efficiently.

## Project Structure Recap

Here's a final look at the project structure we've built throughout this lesson:

```
autogen-task-automation/
│
├── config/
│   ├── __init__.py
│   └── config.py
│
├── agents/
│   ├── __init__.py
│   ├── task_planner.py
│   ├── executor.py
│   └── error_handler.py
│
├── workflows/
│   ├── __init__.py
│   ├── data_processing_workflow.py
│   ├── data_pipeline_workflow.py
│   └── ci_cd_workflow.py
│
├── utils/
│   ├── __init__.py
│   └── helpers.py
│
├── tasks/
│   ├── __init__.py
│   ├── data_collection.py
│   ├── data_analysis.py
│   └── report_writing.py
│
├── tests/
│   ├── __init__.py
│   ├── test_agents.py
│   ├── test_workflows.py
│   └── test_tasks.py
│
├── main.py
├── requirements.txt
└── README.md
```

This structure provides a solid foundation for building complex task automation systems with Autogen. As you develop your own automation projects, you may need to adjust or expand this structure to fit your specific requirements.

Remember that the key to successful task automation with Autogen lies in breaking down complex problems into manageable steps, designing specialized agents to handle different aspects of your workflow, and implementing robust error handling and recovery mechanisms.

In your next projects, try to identify tasks in your domain that could benefit from this kind of automation, and experiment with creating custom agents and workflows to handle them efficiently.
```

# lesson-9-performance-optimization.md

```
# Lesson 9: Performance Optimization and Scaling in Autogen

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Optimizing Autogen for Large-Scale Applications](#optimizing-autogen-for-large-scale-applications)
   3.1 [Efficient Agent Design](#efficient-agent-design)
   3.2 [Optimizing Conversations](#optimizing-conversations)
   3.3 [Reducing API Calls](#reducing-api-calls)
4. [Caching Strategies and Implementation](#caching-strategies-and-implementation)
   4.1 [Understanding Autogen's Cache System](#understanding-autogens-cache-system)
   4.2 [Implementing Custom Caching](#implementing-custom-caching)
5. [Parallel Processing and Distributed Systems](#parallel-processing-and-distributed-systems)
   5.1 [Parallelizing Agent Tasks](#parallelizing-agent-tasks)
   5.2 [Distributed Autogen Systems](#distributed-autogen-systems)
6. [Monitoring and Logging in Autogen Applications](#monitoring-and-logging-in-autogen-applications)
   6.1 [Setting Up Logging](#setting-up-logging)
   6.2 [Implementing Monitoring](#implementing-monitoring)
7. [Conclusion](#conclusion)

## 1. Introduction <a name="introduction"></a>

As Autogen applications grow in complexity and scale, it becomes crucial to optimize performance and ensure scalability. In this lesson, we'll explore various techniques to enhance the efficiency of Autogen-based systems, implement effective caching strategies, leverage parallel processing, and set up robust monitoring and logging mechanisms.

## 2. Project Structure <a name="project-structure"></a>

Before we dive into the details, let's look at a typical project structure for a large-scale Autogen application:

```
autogen_project/
├── agents/
│   ├── __init__.py
│   ├── custom_assistant.py
│   └── custom_user_proxy.py
├── caching/
│   ├── __init__.py
│   └── custom_cache.py
├── config/
│   ├── __init__.py
│   └── settings.py
├── distributed/
│   ├── __init__.py
│   └── task_manager.py
├── monitoring/
│   ├── __init__.py
│   ├── logger.py
│   └── metrics.py
├── tasks/
│   ├── __init__.py
│   └── complex_workflow.py
├── utils/
│   ├── __init__.py
│   └── helpers.py
├── main.py
└── requirements.txt
```

This structure organizes our optimized Autogen application into modular components, making it easier to manage and scale.

## 3. Optimizing Autogen for Large-Scale Applications <a name="optimizing-autogen-for-large-scale-applications"></a>

### 3.1 Efficient Agent Design <a name="efficient-agent-design"></a>

When designing agents for large-scale applications, it's important to keep them focused and efficient. Here's an example of an optimized assistant agent:

```python
# agents/custom_assistant.py
from autogen import AssistantAgent

class OptimizedAssistant(AssistantAgent):
    def __init__(self, name, system_message, **kwargs):
        super().__init__(name=name, system_message=system_message, **kwargs)
        self.conversation_memory = []

    def generate_response(self, messages):
        # Implement custom logic to generate responses more efficiently
        # For example, summarize long conversation histories
        relevant_history = self._summarize_history(messages)
        response = super().generate_response(relevant_history)
        return response

    def _summarize_history(self, messages):
        # Implement a method to summarize long conversation histories
        # This can help reduce token usage and processing time
        if len(messages) > 10:
            return messages[-5:]  # Simple example: keep only the last 5 messages
        return messages
```

### 3.2 Optimizing Conversations <a name="optimizing-conversations"></a>

To optimize conversations, especially in group chats or complex workflows, consider implementing a conversation manager:

```python
# utils/conversation_manager.py
class ConversationManager:
    def __init__(self, agents):
        self.agents = agents
        self.conversation_state = {}

    def manage_conversation(self, task):
        # Implement logic to efficiently manage conversations
        # For example, decide which agents should participate based on the task
        relevant_agents = self._select_relevant_agents(task)
        conversation = self._initiate_conversation(relevant_agents, task)
        return self._process_conversation(conversation)

    def _select_relevant_agents(self, task):
        # Implement logic to select only the necessary agents for a given task
        return [agent for agent in self.agents if self._is_relevant(agent, task)]

    def _is_relevant(self, agent, task):
        # Implement logic to determine if an agent is relevant for a task
        return True  # Placeholder implementation

    def _initiate_conversation(self, agents, task):
        # Implement logic to start a conversation with selected agents
        pass

    def _process_conversation(self, conversation):
        # Implement logic to process the conversation and return results
        pass
```

### 3.3 Reducing API Calls <a name="reducing-api-calls"></a>

To optimize performance and reduce costs, it's crucial to minimize the number of API calls made to language models. Here are some strategies:

1. Implement request batching:

```python
# utils/api_optimizer.py
from autogen import OpenAIWrapper

class APIOptimizer:
    def __init__(self, config):
        self.client = OpenAIWrapper(**config)
        self.request_queue = []

    def add_request(self, messages):
        self.request_queue.append(messages)

    def process_queue(self):
        if len(self.request_queue) >= 5:  # Process when queue has 5 or more requests
            batched_messages = self._prepare_batch()
            responses = self.client.create(messages=batched_messages)
            self.request_queue = []
            return self._unbatch_responses(responses)
        return None

    def _prepare_batch(self):
        # Implement logic to combine multiple requests into a single batch
        pass

    def _unbatch_responses(self, batched_response):
        # Implement logic to separate batched response into individual responses
        pass
```

2. Implement response caching (we'll cover this in more detail in the next section).

## 4. Caching Strategies and Implementation <a name="caching-strategies-and-implementation"></a>

### 4.1 Understanding Autogen's Cache System <a name="understanding-autogens-cache-system"></a>

Autogen provides a built-in caching system to store and retrieve responses, which can significantly reduce API calls and improve performance. Let's explore how to use it effectively:

```python
# config/settings.py
from autogen import config_list_from_json

config_list = config_list_from_json(env_or_file="OAI_CONFIG_LIST")
cache_config = {
    "cache_seed": 42,  # Change this seed to create different cache instances
    "cache_path_root": ".cache",  # Directory to store cache files
}

# main.py
from autogen import OpenAIWrapper
from config.settings import config_list, cache_config

# Create an OpenAIWrapper instance with caching enabled
oai_client = OpenAIWrapper(config_list=config_list, cache_config=cache_config)

# Use the client to make API calls
response = oai_client.create(messages=[{"role": "user", "content": "Hello, world!"}])
```

### 4.2 Implementing Custom Caching <a name="implementing-custom-caching"></a>

For more advanced caching needs, you can implement a custom cache system:

```python
# caching/custom_cache.py
import diskcache
from autogen import Cache

class CustomCache(Cache):
    def __init__(self, cache_path_root, cache_seed):
        super().__init__()
        self.cache = diskcache.Cache(cache_path_root)
        self.cache_seed = cache_seed

    def get(self, key, default=None):
        return self.cache.get(f"{self.cache_seed}:{key}", default)

    def set(self, key, value):
        self.cache.set(f"{self.cache_seed}:{key}", value)

    def close(self):
        self.cache.close()

# main.py
from caching.custom_cache import CustomCache
from config.settings import config_list, cache_config

custom_cache = CustomCache(cache_config["cache_path_root"], cache_config["cache_seed"])
oai_client = OpenAIWrapper(config_list=config_list, cache=custom_cache)
```

## 5. Parallel Processing and Distributed Systems <a name="parallel-processing-and-distributed-systems"></a>

### 5.1 Parallelizing Agent Tasks <a name="parallelizing-agent-tasks"></a>

To improve performance in multi-agent systems, we can parallelize tasks using Python's `concurrent.futures` module:

```python
# distributed/task_manager.py
import concurrent.futures
from autogen import ConversableAgent

class ParallelTaskManager:
    def __init__(self, agents):
        self.agents = agents

    def run_parallel_tasks(self, tasks):
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(self.agents)) as executor:
            future_to_task = {executor.submit(self._run_task, task): task for task in tasks}
            results = []
            for future in concurrent.futures.as_completed(future_to_task):
                task = future_to_task[future]
                try:
                    result = future.result()
                    results.append((task, result))
                except Exception as e:
                    results.append((task, str(e)))
        return results

    def _run_task(self, task):
        # Assign task to an appropriate agent and get the result
        agent = self._select_agent_for_task(task)
        return agent.generate_response(task)

    def _select_agent_for_task(self, task):
        # Implement logic to select the best agent for a given task
        return self.agents[0]  # Placeholder implementation

# main.py
from distributed.task_manager import ParallelTaskManager

agents = [ConversableAgent(name=f"Agent{i}") for i in range(5)]
task_manager = ParallelTaskManager(agents)

tasks = ["Task 1", "Task 2", "Task 3", "Task 4", "Task 5"]
results = task_manager.run_parallel_tasks(tasks)
```

### 5.2 Distributed Autogen Systems <a name="distributed-autogen-systems"></a>

For large-scale applications, you might need to distribute Autogen across multiple machines. Here's a basic example using Redis for communication:

```python
# distributed/redis_manager.py
import redis
import json

class RedisManager:
    def __init__(self, host='localhost', port=6379, db=0):
        self.redis = redis.Redis(host=host, port=port, db=db)

    def publish_task(self, task):
        self.redis.publish('tasks', json.dumps(task))

    def get_result(self, task_id, timeout=60):
        return self.redis.blpop(f'result:{task_id}', timeout)

# On worker machines:
import autogen

def process_task(task):
    # Process the task using Autogen
    result = autogen.ConversableAgent().generate_response(task['content'])
    return result

redis_manager = RedisManager()
pubsub = redis_manager.redis.pubsub()
pubsub.subscribe('tasks')

for message in pubsub.listen():
    if message['type'] == 'message':
        task = json.loads(message['data'])
        result = process_task(task)
        redis_manager.redis.rpush(f'result:{task["id"]}', json.dumps(result))

# On the main machine:
task = {"id": "unique_task_id", "content": "Perform this task"}
redis_manager.publish_task(task)
result = redis_manager.get_result(task['id'])
```

## 6. Monitoring and Logging in Autogen Applications <a name="monitoring-and-logging-in-autogen-applications"></a>

### 6.1 Setting Up Logging <a name="setting-up-logging"></a>

Implement a comprehensive logging system to track the behavior of your Autogen application:

```python
# monitoring/logger.py
import logging
from logging.handlers import RotatingFileHandler

def setup_logger(name, log_file, level=logging.INFO):
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    
    handler = RotatingFileHandler(log_file, maxBytes=10*1024*1024, backupCount=5)
    handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)

    return logger

# Usage in other modules:
from monitoring.logger import setup_logger

logger = setup_logger('autogen_app', 'logs/autogen_app.log')
logger.info("Application started")
```

### 6.2 Implementing Monitoring <a name="implementing-monitoring"></a>

Set up a monitoring system to track key metrics of your Autogen application:

```python
# monitoring/metrics.py
import time
from prometheus_client import start_http_server, Summary, Counter

class AutogenMetrics:
    def __init__(self):
        self.request_latency = Summary('request_latency_seconds', 'Latency of API requests')
        self.requests_total = Counter('requests_total', 'Total number of API requests')

    def track_request(self):
        self.requests_total.inc()
        return self.request_latency.time()

# In your main application:
from monitoring.metrics import AutogenMetrics

metrics = AutogenMetrics()
start_http_server(8000)  # Start Prometheus metrics server

# Wrap your API calls with metrics tracking
with metrics.track_request():
    response = oai_client.create(messages=[{"role": "user", "content": "Hello, world!"}])
```

You can then use tools like Prometheus and Grafana to visualize and alert on these metrics.

## 7. Conclusion <a name="conclusion"></a>

In this lesson, we've covered various techniques for optimizing and scaling Autogen applications. We've explored efficient agent design, conversation optimization, API call reduction, caching strategies, parallel processing, and monitoring. By implementing these techniques, you can build robust, high-performance Autogen systems capable of handling large-scale tasks and workflows.

Remember to always profile your application and identify bottlenecks before applying optimizations. Each application may have unique requirements, so adapt these techniques to best suit your specific use case.

In the next lesson, we'll dive into advanced topics in Autogen development, including custom LLM-powered features and integrations with other AI frameworks.

```

# misc.md

```
You are the best coding teacher and an expert in cli and web based agentic tool programming along with AI and python, web etc. You are very methodical in your teaching and always give sample examples to explain things to everyone. Also, you always show the project file structure for better visualization in every lesson.




Please analyze the Autogen code in knowledgebase and plan a series of explanatory lessons for it's usage and workings I want to write a series of articles to help developers create tools like autogen. First should be general awareness and usage of this tool like autogen. Second article should provide general overview and file layout plus basics of creating such tool. next should expand upon various aspects and commands and so on and then next... . Please prepare a plan for a list of articles in order to teach my students concept and hands on code both. please refer file in knowledge base and generate an exhaustive List of lessons from engineer to advanced student level. Try to be precise and methodical in your approach


please refer the lesson list file in knowledge base and generate an exhaustive article for lesson 1 as a single markdown file in artifact and provide project layout always and be methodical


continue in artifact
```

# agentchat\agentchat-lesson-series.md

```
Certainly! I apologize for overlooking the subfolders in the agentchat directory. Let's create a more comprehensive lesson plan that includes the subfolders and their contents. I'll update the lesson structure to cover all aspects of the agentchat module, including its subfolders.

Here's the updated folder structure for the agentchat module:

```
autogen/
└── agentchat/
    ├── __init__.py
    ├── agent.py
    ├── assistant_agent.py
    ├── conversable_agent.py
    ├── groupchat.py
    ├── human_proxy_agent.py
    ├── user_proxy_agent.py
    ├── contrib/
    │   ├── __init__.py
    │   ├── agent_builder.py
    │   ├── gpt_assistant_agent.py
    │   ├── img_utils.py
    │   ├── llava_agent.py
    │   ├── math_user_proxy_agent.py
    │   ├── multimodal_conversable_agent.py
    │   ├── retrieve_assistant_agent.py
    │   ├── retrieve_user_proxy_agent.py
    │   ├── web_surfer.py
    │   ├── agent_eval/
    │   │   ├── __init__.py
    │   │   ├── agent_eval.py
    │   │   ├── criterion.py
    │   │   ├── critic_agent.py
    │   │   ├── quantifier_agent.py
    │   │   ├── subcritic_agent.py
    │   │   └── task.py
    │   ├── capabilities/
    │   │   ├── __init__.py
    │   │   ├── agent_capability.py
    │   │   ├── generate_images.py
    │   │   ├── teachability.py
    │   │   ├── text_compressors.py
    │   │   ├── transforms.py
    │   │   └── vision_capability.py
    │   └── graph_rag/
    │       ├── __init__.py
    │       ├── document.py
    │       ├── graph_query_engine.py
    │       └── graph_rag_capability.py
    └── extensions/
        └── __init__.py
```

Now, let's update our lesson plan to include these subfolders and their contents:

1. Introduction to Autogen's AgentChat Module
   - Overview of the agentchat folder structure
   - Key concepts and components
   - Basic usage patterns

2. Understanding the Agent Base Class
   - Detailed examination of agent.py
   - Core methods and attributes
   - Creating custom agents

3. Deep Dive into ConversableAgent
   - Analysis of conversable_agent.py
   - Message handling and processing
   - Implementing reply functions

4. Specialized Agents: AssistantAgent and UserProxyAgent
   - Exploring assistant_agent.py and user_proxy_agent.py
   - Differences and use cases
   - Customizing specialized agents

5. Group Chats and Collaboration
   - Understanding groupchat.py
   - Implementing multi-agent conversations
   - Group chat management strategies

6. Human Interaction: HumanProxyAgent
   - Examining human_proxy_agent.py
   - Implementing human-in-the-loop systems
   - Balancing automation and human input

7. Contributed Agents and Utilities (Part 1)
   - Overview of the contrib folder
   - Exploring agent_builder.py and gpt_assistant_agent.py
   - Understanding img_utils.py for image handling

8. Contributed Agents and Utilities (Part 2)
   - Deep dive into llava_agent.py and math_user_proxy_agent.py
   - Implementing multimodal conversations with multimodal_conversable_agent.py
   - Web scraping and browsing with web_surfer.py

9. Information Retrieval in Agents
   - Analyzing retrieve_assistant_agent.py and retrieve_user_proxy_agent.py
   - Implementing efficient information retrieval systems
   - Integrating external knowledge bases

10. Agent Evaluation Framework
    - Understanding the agent_eval subfolder
    - Implementing evaluation criteria and tasks
    - Creating critic and subcritic agents for assessment

11. Advanced Agent Capabilities
    - Exploring the capabilities subfolder
    - Implementing image generation with generate_images.py
    - Adding teachability and vision capabilities to agents

12. Text Compression and Transformation
    - Understanding text_compressors.py and transforms.py
    - Implementing efficient message handling
    - Optimizing agent communication

13. Graph-based Retrieval-Augmented Generation (RAG)
    - Exploring the graph_rag subfolder
    - Implementing document-based knowledge graphs
    - Creating graph query engines for enhanced information retrieval

14. Extending AgentChat: Custom Extensions
    - Understanding the extensions folder
    - Creating custom extensions for AgentChat
    - Best practices for modular agent design

15. Advanced Message Handling and Processing
    - In-depth look at message structures across different agent types
    - Customizing message flow in complex agent systems
    - Implementing advanced filtering and routing

16. Function Calling and Tool Usage in Agents
    - Integrating external tools and APIs
    - Implementing and using function maps
    - Best practices for extensibility across different agent types

17. State Management in Autogen Agents
    - Handling conversation history in various agent types
    - Implementing memory and context in contributed agents
    - Strategies for long-term state preservation in complex systems

18. Error Handling and Robustness in Agent Interactions
    - Common pitfalls and how to avoid them
    - Implementing retry mechanisms in different agent types
    - Graceful degradation strategies for multi-agent systems

19. Optimizing Agent Performance
    - Caching strategies for different agent types
    - Efficient message passing in group chats
    - Reducing API calls and latency in retrieval-augmented agents

20. Testing and Debugging Autogen Agents
    - Unit testing various agent behaviors
    - Mocking external services in contributed agents
    - Debugging complex agent interactions and evaluations

21. Security Considerations in AgentChat
    - Handling sensitive information across different agent types
    - Implementing access controls in group chats
    - Sanitizing user inputs in proxy agents

22. Integration with External AI Services
    - Connecting different agent types to various LLM providers
    - Implementing custom AI services for specialized agents
    - Balancing between different AI capabilities in a multi-agent system

23. Advanced Use Cases: Task Planning and Execution
    - Implementing complex workflows with diverse agent types
    - Task decomposition strategies using the agent builder
    - Coordinating multiple specialized agents for task completion

24. Scaling AgentChat for Production
    - Handling high-volume conversations with various agent types
    - Implementing load balancing for complex agent systems
    - Monitoring and logging in production environments with diverse agents

For each lesson, we'll follow this structure:

1. Introduction to the topic
2. Theoretical background and concepts
3. Hands-on code examples
4. Project structure updates (if applicable)
5. Exercises for students
6. Summary and next steps

Let's look at an example lesson that incorporates the subfolder content:

Lesson 7: Contributed Agents and Utilities (Part 1)

1. Introduction
   In this lesson, we'll explore the contrib folder of the AgentChat module, focusing on the agent builder, GPT assistant agent, and image utilities.

2. Overview of the contrib folder
   The contrib folder contains various extensions and specialized agents:

   ```
   autogen/agentchat/contrib/
   ├── __init__.py
   ├── agent_builder.py
   ├── gpt_assistant_agent.py
   ├── img_utils.py
   └── ...
   ```

3. Agent Builder (agent_builder.py)
   The agent builder provides functionality to dynamically create and configure agents.

   Key concepts:
   - Dynamic agent creation
   - Configuration management
   - Agent customization

   Example usage:

   ```python
   from autogen.agentchat.contrib.agent_builder import AgentBuilder

   builder = AgentBuilder()
   custom_agent = builder.create_agent(
       name="CustomAssistant",
       system_message="You are a helpful assistant specialized in Python programming.",
       llm_config={"model": "gpt-4"}
   )
   ```

4. GPT Assistant Agent (gpt_assistant_agent.py)
   This file implements an agent that uses OpenAI's GPT models as its backend.

   Key features:
   - Integration with OpenAI's API
   - Customizable system messages
   - Handling of conversation context

   Example usage:

   ```python
   from autogen.agentchat.contrib.gpt_assistant_agent import GPTAssistantAgent

   gpt_assistant = GPTAssistantAgent(
       name="GPT4Assistant",
       instructions="You are an AI assistant expert in data analysis.",
       llm_config={"model": "gpt-4"}
   )
   ```

5. Image Utilities (img_utils.py)
   This file provides utilities for handling images in agent conversations.

   Key functionalities:
   - Image loading and processing
   - Conversion between different image formats
   - Integration of images in agent messages

   Example usage:

   ```python
   from autogen.agentchat.contrib.img_utils import get_image_data

   image_path = "path/to/image.jpg"
   image_data = get_image_data(image_path)

   # Use image_data in an agent message
   message = {
       "content": "Analyze this image:",
       "image": image_data
   }
   ```

6. Project Structure
   Update your project structure to include examples for this lesson:

   ```
   autogen_tutorial/
   ├── lesson7_contrib_agents/
   │   ├── agent_builder_example.py
   │   ├── gpt_assistant_example.py
   │   ├── image_handling_example.py
   │   └── requirements.txt
   └── README.md
   ```

7. Exercise
   Create a multi-agent system using the agent builder that includes a GPT assistant agent and can handle image-based tasks. Implement a simple workflow where one agent describes an image, and another agent uses that description to answer questions.

8. Summary
   In this lesson, we've explored key components of the contrib folder, including the agent builder, GPT assistant agent, and image utilities. We've seen how these tools can be used to create more flexible and capable agent systems. In the next lesson, we'll continue our exploration of the contrib folder, focusing on specialized agents for math and multimodal conversations.

This updated lesson plan provides a comprehensive coverage of the agentchat module, including its subfolders and specialized components. Each lesson builds upon the previous ones, ensuring that students gain a thorough understanding of both the concepts and the practical implementation of Autogen's AgentChat system, including its extended capabilities and contributed components.
```

# agentchat\lesson-1-introduction-to-autogen-agentchat.md

```
# Lesson 1: Introduction to Autogen's AgentChat Module

## Table of Contents
1. [Introduction](#introduction)
2. [Overview of the agentchat Folder Structure](#overview-of-the-agentchat-folder-structure)
3. [Key Concepts and Components](#key-concepts-and-components)
4. [Basic Usage Patterns](#basic-usage-patterns)
5. [Project Structure](#project-structure)
6. [Hands-on Example](#hands-on-example)
7. [Exercise](#exercise)
8. [Summary and Next Steps](#summary-and-next-steps)

## Introduction

Welcome to the first lesson in our comprehensive series on Autogen's AgentChat module. Autogen is a powerful framework for building AI-powered applications and automating complex tasks. The AgentChat module, in particular, provides a flexible and extensible platform for creating conversational AI agents that can interact with each other and with humans.

In this lesson, we'll introduce you to the core concepts of the AgentChat module, explore its folder structure, and get you started with some basic usage patterns. By the end of this lesson, you'll have a solid foundation for building more complex agent-based systems in future lessons.

## Overview of the agentchat Folder Structure

Let's start by examining the folder structure of the AgentChat module:

```
autogen/
└── agentchat/
    ├── __init__.py
    ├── agent.py
    ├── assistant_agent.py
    ├── conversable_agent.py
    ├── groupchat.py
    ├── human_proxy_agent.py
    ├── user_proxy_agent.py
    ├── contrib/
    │   ├── __init__.py
    │   ├── agent_builder.py
    │   ├── gpt_assistant_agent.py
    │   ├── img_utils.py
    │   ├── llava_agent.py
    │   ├── math_user_proxy_agent.py
    │   ├── multimodal_conversable_agent.py
    │   ├── retrieve_assistant_agent.py
    │   ├── retrieve_user_proxy_agent.py
    │   ├── web_surfer.py
    │   ├── agent_eval/
    │   ├── capabilities/
    │   └── graph_rag/
    └── extensions/
        └── __init__.py
```

This structure shows the main components of the AgentChat module:

- Core agent classes (e.g., `agent.py`, `assistant_agent.py`, `conversable_agent.py`)
- Specialized agents (e.g., `human_proxy_agent.py`, `user_proxy_agent.py`)
- Group chat functionality (`groupchat.py`)
- Contributed extensions and utilities (`contrib/` folder)
- Custom extensions (`extensions/` folder)

## Key Concepts and Components

1. **Agent**: The fundamental building block of the AgentChat module. An agent represents an entity capable of performing actions, processing information, and engaging in conversations.

2. **ConversableAgent**: A base class for agents that can engage in conversations. It provides core functionality for message handling and generation.

3. **AssistantAgent**: A specialized agent designed to act as an AI assistant, capable of understanding and generating human-like text based on the conversation context.

4. **UserProxyAgent**: An agent that can represent a human user, execute code, and provide feedback to other agents.

5. **GroupChat**: A mechanism for managing conversations between multiple agents.

6. **HumanProxyAgent**: An agent designed to facilitate human interaction within the agent system.

7. **Contributed Components**: Additional utilities and specialized agents in the `contrib/` folder, such as the agent builder, GPT assistant, and image handling utilities.

## Basic Usage Patterns

Here's a simple example of how to create and use agents in the AgentChat module:

```python
from autogen import AssistantAgent, UserProxyAgent, config_list_from_json

# Load LLM inference endpoints from an env variable or a file
config_list = config_list_from_json(env_or_file="OAI_CONFIG_LIST")

# Create an AssistantAgent instance
assistant = AssistantAgent(
    name="AI_Assistant",
    llm_config={"config_list": config_list}
)

# Create a UserProxyAgent instance
user_proxy = UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={"work_dir": "coding"}
)

# Start a conversation
user_proxy.initiate_chat(
    assistant,
    message="Hello! Can you help me write a Python function to calculate the Fibonacci sequence?"
)
```

This example demonstrates the basic pattern of creating agents and initiating a conversation between them.

## Project Structure

For this lesson, we'll use the following project structure:

```
autogen_tutorial/
├── lesson1_introduction/
│   ├── basic_agent_chat.py
│   ├── config/
│   │   └── oai_config.json
│   └── requirements.txt
└── README.md
```

## Hands-on Example

Let's create a more detailed example that showcases the basic functionality of the AgentChat module. We'll create a simple task-solving system with an assistant agent and a user proxy agent.

Create a new file `basic_agent_chat.py` in the `lesson1_introduction/` directory:

```python
# basic_agent_chat.py

import autogen

# Configure the agents
config_list = autogen.config_list_from_json(env_or_file="config/oai_config.json")

assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={
        "config_list": config_list,
        "temperature": 0.7,
        "model": "gpt-4",
    },
    system_message="""You are a helpful AI assistant. Your task is to help users solve problems and answer questions to the best of your ability.
    If you're asked to perform a task that requires coding, provide the necessary code and explain how it works."""
)

user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={
        "work_dir": "coding_workspace",
        "use_docker": False,
    }
)

# Define the task
task = """
1. Write a Python function to generate the Fibonacci sequence up to a given number of terms.
2. Use the function to generate the first 10 terms of the Fibonacci sequence.
3. Calculate the sum of these 10 terms.
Please provide the code and explain each step.
"""

# Start the conversation
user_proxy.initiate_chat(
    assistant,
    message=task
)

# The conversation will continue until the termination condition is met or the user types "exit"
```

To run this example, you'll need to create a `config/oai_config.json` file with your OpenAI API configuration:

```json
[
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here"
    }
]
```

Make sure to replace `"your_api_key_here"` with your actual OpenAI API key.

Also, create a `requirements.txt` file in the `lesson1_introduction/` directory:

```
pyautogen
```

To run the example, follow these steps:

1. Set up a virtual environment:
   ```
   python -m venv autogen_env
   source autogen_env/bin/activate  # On Windows, use `autogen_env\Scripts\activate`
   ```

2. Install the required packages:
   ```
   pip install -r requirements.txt
   ```

3. Run the script:
   ```
   python basic_agent_chat.py
   ```

This example demonstrates how to set up a basic conversation between an AI assistant and a user proxy, solve a multi-step task, and handle code execution.

## Exercise

Now that you've seen a basic example, try to extend it with the following features:

1. Add error handling to the code execution process.
2. Implement a simple feedback mechanism where the user can rate the assistant's response.
3. Modify the system message to specialize the assistant in a particular domain (e.g., data science, web development).

## Summary and Next Steps

In this lesson, we've introduced the AgentChat module of Autogen, explored its folder structure, and implemented a basic agent-based task-solving system. We've covered the fundamental concepts of agents, their interactions, and how to set up a simple conversation.

In the next lesson, we'll dive deeper into the Agent base class, examining its core methods and attributes, and learn how to create custom agents tailored to specific tasks.

Remember to experiment with the provided example and try the exercise to reinforce your understanding of the AgentChat module. Happy coding!


```

# agentchat\lesson-10-agent-evaluation-framework.md

```
# Lesson 10: Agent Evaluation Framework

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding the Agent Evaluation Framework](#understanding-the-agent-evaluation-framework)
4. [Key Components](#key-components)
   - [Criterion](#criterion)
   - [Task](#task)
   - [CriticAgent](#criticagent)
   - [SubCriticAgent](#subcriticagent)
   - [QuantifierAgent](#quantifieragent)
5. [Implementing the Evaluation Process](#implementing-the-evaluation-process)
   - [Generating Criteria](#generating-criteria)
   - [Quantifying Criteria](#quantifying-criteria)
6. [Practical Example: Evaluating a Math Problem Solver](#practical-example-evaluating-a-math-problem-solver)
7. [Best Practices and Considerations](#best-practices-and-considerations)
8. [Conclusion](#conclusion)

## Introduction

The Agent Evaluation Framework is a crucial component of the AutoGen library, designed to assess and improve the performance of AI agents. This framework provides a structured approach to evaluate agents based on specific criteria, tasks, and quantifiable metrics. In this lesson, we'll dive deep into the components of the framework, understand how they interact, and learn how to implement an effective evaluation process for your AI agents.

## Project Structure

Before we begin, let's take a look at the project structure for the Agent Evaluation Framework:

```
autogen/
└── agentchat/
    └── contrib/
        └── agent_eval/
            ├── __init__.py
            ├── agent_eval.py
            ├── criterion.py
            ├── critic_agent.py
            ├── quantifier_agent.py
            ├── subcritic_agent.py
            ├── task.py
            └── README.md
```

This structure shows that the Agent Evaluation Framework is part of the `contrib` package within `agentchat`, indicating its experimental nature and potential for community contributions.

## Understanding the Agent Evaluation Framework

The Agent Evaluation Framework is designed to provide a systematic way of assessing the performance of AI agents. It consists of several key components that work together to generate evaluation criteria, assess agent performance, and quantify the results.

The main goals of this framework are:

1. To create a standardized method for evaluating AI agents
2. To provide insights into agent performance across various tasks and criteria
3. To facilitate the improvement of agents based on evaluation results

## Key Components

Let's explore the key components of the Agent Evaluation Framework:

### Criterion

The `Criterion` class, defined in `criterion.py`, represents a single evaluation criterion. It has the following structure:

```python
class Criterion(BaseModel):
    name: str
    description: str
    accepted_values: List[str]
    sub_criteria: List[Criterion] = list()
```

Example usage:

```python
criterion = Criterion(
    name="Mathematical Accuracy",
    description="Assess the correctness of the mathematical calculations",
    accepted_values=["Correct", "Partially Correct", "Incorrect"]
)
```

### Task

The `Task` class, defined in `task.py`, represents a specific task for which an agent is being evaluated. It includes the following attributes:

```python
class Task(BaseModel):
    name: str
    description: str
    successful_response: str
    failed_response: str
```

Example usage:

```python
task = Task(
    name="Solve Quadratic Equation",
    description="Solve the quadratic equation: ax^2 + bx + c = 0",
    successful_response="The agent correctly identified and calculated the roots of the equation.",
    failed_response="The agent failed to solve the equation or provided incorrect roots."
)
```

### CriticAgent

The `CriticAgent`, defined in `critic_agent.py`, is responsible for generating evaluation criteria based on a given task. It extends the `ConversableAgent` class:

```python
class CriticAgent(ConversableAgent):
    DEFAULT_SYSTEM_MESSAGE = """You are a helpful assistant. You suggest criteria for evaluating different tasks. They should be distinguishable, quantifiable and not redundant."""

    def __init__(
        self,
        name="critic",
        system_message: Optional[str] = DEFAULT_SYSTEM_MESSAGE,
        **kwargs,
    ):
        super().__init__(name=name, system_message=system_message, **kwargs)
```

### SubCriticAgent

The `SubCriticAgent`, defined in `subcritic_agent.py`, is used to generate sub-criteria for more detailed evaluation:

```python
class SubCriticAgent(ConversableAgent):
    DEFAULT_SYSTEM_MESSAGE = """You are a helpful assistant to the critic agent. You suggest sub criteria for evaluating different tasks based on the criteria provided by the critic agent (if you feel it is needed)."""

    def __init__(
        self,
        name="subcritic",
        system_message: Optional[str] = DEFAULT_SYSTEM_MESSAGE,
        **kwargs,
    ):
        super().__init__(name=name, system_message=system_message, **kwargs)
```

### QuantifierAgent

The `QuantifierAgent`, defined in `quantifier_agent.py`, is responsible for quantifying the performance of a system based on the provided criteria:

```python
class QuantifierAgent(ConversableAgent):
    DEFAULT_SYSTEM_MESSAGE = """You are a helpful assistant. You quantify the output of different tasks based on the given criteria."""

    def __init__(
        self,
        name="quantifier",
        system_message: Optional[str] = DEFAULT_SYSTEM_MESSAGE,
        **kwargs,
    ):
        super().__init__(name=name, system_message=system_message, **kwargs)
```

## Implementing the Evaluation Process

Now that we understand the key components, let's walk through the process of implementing an agent evaluation:

### Generating Criteria

To generate evaluation criteria, we use the `generate_criteria` function from `agent_eval.py`:

```python
def generate_criteria(
    llm_config: Optional[Union[Dict, Literal[False]]] = None,
    task: Task = None,
    additional_instructions: str = "",
    max_round=2,
    use_subcritic: bool = False,
):
    # Implementation details...
```

Example usage:

```python
from autogen.agentchat.contrib.agent_eval import generate_criteria, Task

task = Task(
    name="Solve Linear Equation",
    description="Solve the linear equation: ax + b = c",
    successful_response="The agent correctly solved for x.",
    failed_response="The agent failed to solve for x or provided an incorrect solution."
)

criteria = generate_criteria(
    llm_config={"model": "gpt-4"},
    task=task,
    additional_instructions="Focus on step-by-step problem-solving approach.",
    max_round=3,
    use_subcritic=True
)

print(criteria)
```

### Quantifying Criteria

To quantify the performance based on the generated criteria, we use the `quantify_criteria` function:

```python
def quantify_criteria(
    llm_config: Optional[Union[Dict, Literal[False]]] = None,
    criteria: List[Criterion] = None,
    task: Task = None,
    test_case: str = "",
    ground_truth: str = "",
):
    # Implementation details...
```

Example usage:

```python
from autogen.agentchat.contrib.agent_eval import quantify_criteria

result = quantify_criteria(
    llm_config={"model": "gpt-4"},
    criteria=criteria,
    task=task,
    test_case="Solve: 2x + 3 = 7",
    ground_truth="x = 2"
)

print(result)
```

## Practical Example: Evaluating a Math Problem Solver

Let's walk through a complete example of evaluating an agent designed to solve math problems:

```python
from autogen.agentchat.contrib.agent_eval import Task, generate_criteria, quantify_criteria
from autogen import AssistantAgent, UserProxyAgent

# Define the task
math_task = Task(
    name="Solve Algebraic Equation",
    description="Solve the given algebraic equation and show your work.",
    successful_response="The agent correctly solved the equation with proper steps.",
    failed_response="The agent failed to solve the equation or made errors in the process."
)

# Generate criteria
criteria = generate_criteria(
    llm_config={"model": "gpt-4"},
    task=math_task,
    additional_instructions="Evaluate both the final answer and the problem-solving process.",
    use_subcritic=True
)

# Create the agent to be evaluated
math_solver = AssistantAgent(
    name="MathSolver",
    llm_config={"model": "gpt-3.5-turbo"},
    system_message="You are an expert mathematics problem solver. Solve algebraic equations step by step."
)

# Create a user proxy to interact with the math solver
user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="NEVER",
    max_consecutive_auto_reply=1
)

# Simulate a conversation to solve a math problem
user_proxy.initiate_chat(
    math_solver,
    message="Solve the equation: 3x + 7 = 22"
)

# Extract the math solver's response
math_solver_response = user_proxy.chat_messages[math_solver][-1]['content']

# Quantify the performance
evaluation_result = quantify_criteria(
    llm_config={"model": "gpt-4"},
    criteria=criteria,
    task=math_task,
    test_case="Solve the equation: 3x + 7 = 22",
    ground_truth="x = 5"
)

print("Math Solver's Response:")
print(math_solver_response)
print("\nEvaluation Result:")
print(evaluation_result)
```

This example demonstrates how to set up a task, generate evaluation criteria, create an agent to solve the task, and then evaluate its performance using the Agent Evaluation Framework.

## Best Practices and Considerations

When using the Agent Evaluation Framework, keep the following best practices in mind:

1. **Clear Task Definition**: Ensure that your tasks are well-defined and specific. This helps in generating more accurate evaluation criteria.

2. **Comprehensive Criteria**: Use the `SubCriticAgent` to generate detailed sub-criteria for a more thorough evaluation.

3. **Diverse Test Cases**: Provide a variety of test cases to get a comprehensive understanding of the agent's performance across different scenarios.

4. **Iterative Improvement**: Use the evaluation results to iteratively improve your agents. Identify weaknesses and refine the agent's capabilities accordingly.

5. **Human Oversight**: While the framework provides automated evaluation, it's important to have human oversight to ensure the relevance and accuracy of the generated criteria and quantification.

6. **Consistency**: Use consistent evaluation methods across different versions of your agents to track improvements over time.

7. **Documentation**: Keep detailed records of your evaluation process, including the criteria used, test cases, and results. This will be valuable for future reference and improvements.

## Conclusion

The Agent Evaluation Framework in AutoGen provides a powerful and flexible way to assess the performance of AI agents. By leveraging components like `CriticAgent`, `SubCriticAgent`, and `QuantifierAgent`, you can create comprehensive evaluation processes that provide valuable insights into your agents' capabilities and areas for improvement.

As you work with this framework, remember that it's part of the `contrib` package, which means it may evolve over time. Stay updated with the latest AutoGen documentation and contribute your own improvements to help advance the field of AI agent evaluation.

In the next lesson, we'll explore advanced topics in AutoGen, including customizing the framework for specific use cases and integrating it into larger AI systems.


```

# agentchat\lesson-11-advanced-agent-capabilities.md

```
# Lesson 11: Advanced Agent Capabilities

In this lesson, we'll dive deep into advanced agent capabilities in AutoGen, exploring various features that enhance the functionality and versatility of agents. We'll cover topics such as image generation, text compression, message transformation, and vision capabilities. These advanced features allow you to create more sophisticated and powerful agent-based applications.

## Table of Contents
1. [Project Structure](#project-structure)
2. [Image Generation Capability](#image-generation-capability)
3. [Text Compression](#text-compression)
4. [Message Transformation](#message-transformation)
5. [Vision Capability](#vision-capability)
6. [Practical Examples](#practical-examples)
7. [Best Practices](#best-practices)
8. [Conclusion](#conclusion)

## Project Structure

Before we dive into the details, let's look at the project structure for this lesson:

```
autogen_project/
│
├── main.py
├── requirements.txt
├── README.md
│
├── agents/
│   ├── __init__.py
│   ├── base_agent.py
│   ├── image_agent.py
│   ├── text_agent.py
│   └── vision_agent.py
│
├── capabilities/
│   ├── __init__.py
│   ├── image_generation.py
│   ├── text_compression.py
│   ├── message_transform.py
│   └── vision_capability.py
│
├── utils/
│   ├── __init__.py
│   └── helpers.py
│
└── config/
    └── config.json
```

This structure organizes our code into separate modules for agents and capabilities, making it easy to manage and extend our project.

## Image Generation Capability

The Image Generation Capability allows agents to generate images based on text descriptions. This is particularly useful for creative tasks or for enhancing the visual output of your agents.

### Implementation

Let's look at how to implement the Image Generation Capability:

```python
# capabilities/image_generation.py

from autogen import ConversableAgent
from autogen.agentchat.contrib.capabilities.agent_capability import AgentCapability
from autogen.agentchat.contrib.capabilities.generate_images import ImageGenerator, DalleImageGenerator

class ImageGenerationCapability(AgentCapability):
    def __init__(self, image_generator: ImageGenerator = None):
        if image_generator is None:
            image_generator = DalleImageGenerator(
                llm_config={"config_list": [{"model": "dall-e-3", "api_key": "your-api-key"}]}
            )
        self.image_generator = image_generator

    def add_to_agent(self, agent: ConversableAgent):
        agent.register_function(
            function_map={
                "generate_image": self.generate_image
            }
        )

    def generate_image(self, prompt: str) -> str:
        image = self.image_generator.generate_image(prompt)
        return f"Image generated successfully. URL: {image.url}"
```

### Usage Example

Here's how you can use the Image Generation Capability with an agent:

```python
# main.py

from autogen import ConversableAgent
from capabilities.image_generation import ImageGenerationCapability

# Create an agent
agent = ConversableAgent(name="ImageCreator")

# Add the Image Generation Capability
image_capability = ImageGenerationCapability()
image_capability.add_to_agent(agent)

# Use the capability
result = agent.generate_image("A futuristic city with flying cars")
print(result)
```

## Text Compression

Text compression is useful for reducing the token count of messages, which can help manage context length and reduce API costs when working with large language models.

### Implementation

Here's an implementation of text compression using LLMLingua:

```python
# capabilities/text_compression.py

from autogen.agentchat.contrib.capabilities.text_compressors import LLMLingua

class TextCompressionCapability:
    def __init__(self):
        self.compressor = LLMLingua()

    def compress_text(self, text: str) -> str:
        result = self.compressor.compress_text(text)
        return result['compressed_text']
```

### Usage Example

```python
# main.py

from capabilities.text_compression import TextCompressionCapability

compressor = TextCompressionCapability()

original_text = "This is a long piece of text that we want to compress..."
compressed_text = compressor.compress_text(original_text)

print(f"Original length: {len(original_text)}")
print(f"Compressed length: {len(compressed_text)}")
```

## Message Transformation

Message transformation allows you to modify messages before they are processed by agents, which can be useful for filtering, formatting, or enhancing the content.

### Implementation

```python
# capabilities/message_transform.py

from typing import List, Dict
from autogen.agentchat.contrib.capabilities.transform_messages import TransformMessages

class MessageLengthLimiter(TransformMessages):
    def __init__(self, max_length: int):
        self.max_length = max_length

    def apply_transform(self, messages: List[Dict]) -> List[Dict]:
        for message in messages:
            if len(message['content']) > self.max_length:
                message['content'] = message['content'][:self.max_length] + "..."
        return messages
```

### Usage Example

```python
# main.py

from autogen import ConversableAgent
from capabilities.message_transform import MessageLengthLimiter

agent = ConversableAgent(name="ConciseAgent")
limiter = MessageLengthLimiter(max_length=100)
limiter.add_to_agent(agent)

# Now, all messages processed by this agent will be limited to 100 characters
```

## Vision Capability

The Vision Capability allows agents to process and understand images, which is crucial for tasks involving visual data.

### Implementation

```python
# capabilities/vision_capability.py

from autogen.agentchat.contrib.capabilities.vision_capability import VisionCapability
from PIL import Image

class CustomVisionCapability(VisionCapability):
    def __init__(self, lmm_config: Dict):
        super().__init__(lmm_config)

    def custom_caption_func(self, img_url: str, img_data: Image, lmm_client) -> str:
        # Implement custom image captioning logic here
        return f"Custom caption for image: {img_url}"
```

### Usage Example

```python
# main.py

from autogen import ConversableAgent
from capabilities.vision_capability import CustomVisionCapability

agent = ConversableAgent(name="VisionAgent")
vision_capability = CustomVisionCapability(lmm_config={...})
vision_capability.add_to_agent(agent)

# Now the agent can process images in its conversations
```

## Practical Examples

Let's look at a more comprehensive example that combines multiple advanced capabilities:

```python
# main.py

from autogen import ConversableAgent
from capabilities.image_generation import ImageGenerationCapability
from capabilities.text_compression import TextCompressionCapability
from capabilities.message_transform import MessageLengthLimiter
from capabilities.vision_capability import CustomVisionCapability

def create_advanced_agent():
    agent = ConversableAgent(name="AdvancedAgent")

    # Add Image Generation Capability
    image_capability = ImageGenerationCapability()
    image_capability.add_to_agent(agent)

    # Add Text Compression Capability
    text_compressor = TextCompressionCapability()
    agent.register_function(
        function_map={
            "compress_text": text_compressor.compress_text
        }
    )

    # Add Message Transformation
    limiter = MessageLengthLimiter(max_length=200)
    limiter.add_to_agent(agent)

    # Add Vision Capability
    vision_capability = CustomVisionCapability(lmm_config={...})
    vision_capability.add_to_agent(agent)

    return agent

# Create and use the advanced agent
advanced_agent = create_advanced_agent()

# Generate an image
image_result = advanced_agent.generate_image("A beautiful sunset over mountains")
print(image_result)

# Compress text
compressed = advanced_agent.compress_text("A very long piece of text...")
print(f"Compressed text: {compressed}")

# The agent can now handle images in conversations and will automatically
# limit message lengths to 200 characters
```

## Best Practices

When working with advanced agent capabilities, keep these best practices in mind:

1. **Modular Design**: Keep capabilities separate and modular, allowing for easy addition or removal.
2. **Error Handling**: Implement robust error handling for each capability, especially when dealing with external APIs or complex operations.
3. **Configuration Management**: Use configuration files to manage API keys and other settings for various capabilities.
4. **Testing**: Create unit tests for each capability to ensure they work correctly in isolation and integration tests for the complete agent.
5. **Performance Monitoring**: Monitor the performance impact of added capabilities, especially for operations like image generation or text compression.
6. **Ethical Considerations**: Be mindful of ethical implications, particularly when generating or processing images and text.

## Conclusion

Advanced agent capabilities significantly enhance the power and flexibility of your AutoGen agents. By incorporating features like image generation, text compression, message transformation, and vision capabilities, you can create sophisticated AI applications that can handle a wide range of tasks.

Remember to always consider the specific requirements of your project when deciding which capabilities to implement. Each capability adds complexity to your agent, so it's important to balance functionality with maintainability.

In the next lesson, we'll explore how to deploy and scale your AutoGen applications in production environments.

```

# agentchat\lesson-12-text-compression-transformation.md

```
# Lesson 12: Text Compression and Transformation in AutoGen

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding Text Compressors](#understanding-text-compressors)
4. [Implementing Efficient Message Handling](#implementing-efficient-message-handling)
5. [Optimizing Agent Communication](#optimizing-agent-communication)
6. [Practical Examples](#practical-examples)
7. [Best Practices](#best-practices)
8. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll dive deep into text compression and transformation techniques in AutoGen. As AI models and agent interactions become more complex, efficient handling of text data becomes crucial. We'll explore how to compress and transform text to optimize communication between agents, reduce token usage, and improve overall system performance.

## 2. Project Structure

Before we begin, let's look at the typical project structure for an AutoGen application focusing on text compression and transformation:

```
autogen_project/
│
├── main.py
├── agents/
│   ├── __init__.py
│   ├── base_agent.py
│   └── compressed_agent.py
│
├── text_handlers/
│   ├── __init__.py
│   ├── compressor.py
│   └── transformer.py
│
├── utils/
│   ├── __init__.py
│   └── text_utils.py
│
└── config/
    └── config.json
```

This structure organizes our code into separate modules for agents, text handlers, and utilities, making it easier to manage and extend our application.

## 3. Understanding Text Compressors

AutoGen provides text compression capabilities through the `LLMLingua` class. Let's examine how to use it:

```python
# text_handlers/compressor.py

from autogen.agentchat.contrib.capabilities.text_compressors import LLMLingua

class TextCompressor:
    def __init__(self):
        self.compressor = LLMLingua(
            model_name="microsoft/llmlingua-2-bert-base-multilingual-cased-meetingbank",
            use_llmlingua2=True,
            device_map="cpu"
        )

    def compress_text(self, text: str, **compression_params) -> Dict[str, Any]:
        return self.compressor.compress_text(text, **compression_params)
```

The `LLMLingua` class uses advanced techniques to compress text while maintaining its semantic meaning. This is particularly useful for reducing token usage in large conversations or when working with limited context windows.

## 4. Implementing Efficient Message Handling

To handle message compression efficiently, we can create a `CompressedAgent` class that automatically compresses outgoing messages and decompresses incoming messages:

```python
# agents/compressed_agent.py

from autogen.agentchat import ConversableAgent
from text_handlers.compressor import TextCompressor

class CompressedAgent(ConversableAgent):
    def __init__(self, name: str, **kwargs):
        super().__init__(name, **kwargs)
        self.compressor = TextCompressor()

    def send(self, message: Union[Dict, str], recipient: Agent, request_reply: Optional[bool] = None, silent: Optional[bool] = False):
        if isinstance(message, str):
            compressed = self.compressor.compress_text(message)
            message = {"content": compressed["compressed_text"], "original_tokens": compressed["origin_tokens"]}
        super().send(message, recipient, request_reply, silent)

    def receive(self, message: Union[Dict, str], sender: Agent, request_reply: Optional[bool] = None, silent: Optional[bool] = False):
        if isinstance(message, dict) and "original_tokens" in message:
            # Decompress the message (in a real scenario, you'd implement a decompression method)
            message = f"Decompressed: {message['content']} (Original tokens: {message['original_tokens']})"
        super().receive(message, sender, request_reply, silent)
```

This `CompressedAgent` automatically compresses outgoing messages and handles compressed incoming messages, making it seamless to integrate text compression into your agent communications.

## 5. Optimizing Agent Communication

To further optimize agent communication, we can implement text transformations that restructure or summarize content without losing essential information. Let's create a `TextTransformer` class:

```python
# text_handlers/transformer.py

from autogen import OpenAIWrapper

class TextTransformer:
    def __init__(self, llm_config: dict):
        self.llm = OpenAIWrapper(**llm_config)

    def summarize(self, text: str, max_tokens: int = 100) -> str:
        prompt = f"Summarize the following text in no more than {max_tokens} tokens:\n\n{text}"
        response = self.llm.create(messages=[{"role": "user", "content": prompt}])
        return response.choices[0].message.content

    def restructure(self, text: str, format: str = "bullet_points") -> str:
        prompt = f"Restructure the following text into {format}:\n\n{text}"
        response = self.llm.create(messages=[{"role": "user", "content": prompt}])
        return response.choices[0].message.content
```

This `TextTransformer` class can be used to summarize or restructure text, which can be particularly useful when agents need to exchange large amounts of information efficiently.

## 6. Practical Examples

Let's look at a practical example that combines text compression and transformation in a multi-agent system:

```python
# main.py

from agents.compressed_agent import CompressedAgent
from text_handlers.transformer import TextTransformer
from autogen import UserProxyAgent, config_list_from_json

def main():
    # Load OpenAI API key
    config_list = config_list_from_json("config/config.json")
    
    # Initialize agents
    user = UserProxyAgent("User")
    assistant = CompressedAgent("Assistant", llm_config={"config_list": config_list})
    
    # Initialize text transformer
    transformer = TextTransformer(llm_config={"config_list": config_list})

    # Start conversation
    user.initiate_chat(
        assistant,
        message="Can you explain the concept of quantum computing and its potential applications?"
    )

    # Get the last message from the assistant
    last_message = assistant.last_message()["content"]

    # Transform the message
    summarized = transformer.summarize(last_message, max_tokens=50)
    restructured = transformer.restructure(last_message, format="bullet_points")

    print(f"Original message tokens: {len(last_message.split())}")
    print(f"Summarized message tokens: {len(summarized.split())}")
    print(f"Summarized message: {summarized}")
    print(f"Restructured message: {restructured}")

if __name__ == "__main__":
    main()
```

This example demonstrates how to use compressed agents for efficient communication and how to apply text transformations to optimize the information exchange between agents.

## 7. Best Practices

When implementing text compression and transformation in AutoGen, keep these best practices in mind:

1. **Balance Compression and Clarity**: While compression can save tokens, ensure that it doesn't compromise the clarity of the message.

2. **Use Context-Aware Compression**: Consider the context of the conversation when compressing text to preserve the most relevant information.

3. **Implement Selective Compression**: Not all messages need compression. Implement logic to decide when to compress based on message length or content type.

4. **Monitor Token Usage**: Regularly monitor and log token usage to ensure that your compression and transformation strategies are effective.

5. **Preserve Original Messages**: Always keep a copy of the original, uncompressed messages for debugging and auditing purposes.

6. **Test Thoroughly**: Rigorously test your compression and transformation methods with various types of content to ensure they work as expected across different scenarios.

7. **Consider Computation Overhead**: Remember that compression and transformation operations also consume computational resources. Balance this overhead against the benefits of reduced token usage.

## 8. Conclusion

Text compression and transformation are powerful techniques for optimizing agent communication in AutoGen. By implementing these methods, you can significantly reduce token usage, improve response times, and enhance the overall efficiency of your multi-agent systems.

In this lesson, we've covered:
- Understanding and implementing text compressors using LLMLingua
- Creating compressed agents for efficient message handling
- Implementing text transformations for summarization and restructuring
- Practical examples of using compression and transformation in a multi-agent system
- Best practices for text compression and transformation in AutoGen

As you continue to work with AutoGen, experiment with different compression and transformation strategies to find the optimal balance between efficiency and clarity in your agent communications. Remember that the goal is to maximize the information exchange while minimizing resource usage.


```

# agentchat\lesson-13-graph-based-rag.md

```
# Lesson 13: Graph-based Retrieval-Augmented Generation (RAG)

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding Graph-based RAG](#understanding-graph-based-rag)
4. [Key Components](#key-components)
   - [Document](#document)
   - [GraphQueryEngine](#graphqueryengine)
   - [GraphRagCapability](#graphragcapability)
5. [Implementing Graph-based RAG](#implementing-graph-based-rag)
   - [Step 1: Setting up the Document Structure](#step-1-setting-up-the-document-structure)
   - [Step 2: Implementing the GraphQueryEngine](#step-2-implementing-the-graphqueryengine)
   - [Step 3: Creating the GraphRagCapability](#step-3-creating-the-graphragcapability)
6. [Usage Example](#usage-example)
7. [Advanced Concepts](#advanced-concepts)
   - [Customizing the Graph Structure](#customizing-the-graph-structure)
   - [Optimizing Query Performance](#optimizing-query-performance)
8. [Best Practices](#best-practices)
9. [Conclusion](#conclusion)

## Introduction

Graph-based Retrieval-Augmented Generation (RAG) is an advanced technique that enhances the capabilities of language models by incorporating structured knowledge in the form of graphs. This approach allows for more contextually relevant and accurate information retrieval, leading to improved performance in various natural language processing tasks.

In this lesson, we'll explore the implementation of Graph-based RAG within the AutoGen framework, focusing on the components provided in the `graph_rag` subfolder.

## Project Structure

Before we dive into the details, let's take a look at the project structure relevant to this lesson:

```
autogen/
└── agentchat/
    └── contrib/
        └── graph_rag/
            ├── __init__.py
            ├── document.py
            ├── graph_query_engine.py
            └── graph_rag_capability.py
```

This structure shows the main components involved in implementing Graph-based RAG within the AutoGen framework.

## Understanding Graph-based RAG

Graph-based RAG is an extension of the traditional RAG approach. Instead of using a flat document structure, it organizes information in a graph format, where nodes represent entities or concepts, and edges represent relationships between them. This structure allows for more nuanced and contextually relevant information retrieval.

Key advantages of Graph-based RAG include:
1. Improved context understanding
2. More accurate information retrieval
3. Ability to capture complex relationships between entities
4. Enhanced reasoning capabilities

## Key Components

Let's examine the key components provided in the `graph_rag` subfolder:

### Document

The `Document` class, defined in `document.py`, represents a basic unit of information in our graph-based RAG system.

```python
from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional

class DocumentType(Enum):
    TEXT = auto()
    HTML = auto()
    PDF = auto()

@dataclass
class Document:
    doctype: DocumentType
    data: Optional[object] = None
    path_or_url: Optional[str] = ""
```

This structure allows us to handle different types of documents (text, HTML, PDF) and store relevant metadata.

### GraphQueryEngine

The `GraphQueryEngine`, defined in `graph_query_engine.py`, is an abstract base class that represents a graph query engine on top of an underlying graph database.

```python
from abc import abstractmethod
from typing import List, Optional, Protocol

from .document import Document

class GraphQueryEngine(Protocol):
    @abstractmethod
    def init_db(self, input_doc: List[Document] | None = None):
        pass

    @abstractmethod
    def add_records(self, new_records: List) -> bool:
        pass

    @abstractmethod
    def query(self, question: str, n_results: int = 1, **kwargs) -> GraphStoreQueryResult:
        pass
```

This interface defines the basic methods for graph RAG, including initializing the database, adding records, and querying the graph.

### GraphRagCapability

The `GraphRagCapability`, defined in `graph_rag_capability.py`, is a capability that can be added to a conversable agent to give it graph RAG abilities.

```python
from autogen.agentchat.contrib.capabilities.agent_capability import AgentCapability
from autogen.agentchat.conversable_agent import ConversableAgent

from .graph_query_engine import GraphQueryEngine

class GraphRagCapability(AgentCapability):
    def __init__(self, query_engine: GraphQueryEngine):
        self.query_engine = query_engine

    def add_to_agent(self, agent: ConversableAgent):
        # Implementation details
        pass
```

This capability allows an agent to create a graph in the underlying database, retrieve relevant information based on received messages, and generate answers from the retrieved information.

## Implementing Graph-based RAG

Now, let's go through the process of implementing Graph-based RAG step by step.

### Step 1: Setting up the Document Structure

First, we need to create our document structure. This is already provided by the `Document` class, but you might want to extend it based on your specific needs.

```python
from autogen.agentchat.contrib.graph_rag.document import Document, DocumentType

# Creating a text document
text_doc = Document(doctype=DocumentType.TEXT, data="This is a sample text document.", path_or_url="sample.txt")

# Creating an HTML document
html_doc = Document(doctype=DocumentType.HTML, data="<html><body>Sample HTML</body></html>", path_or_url="sample.html")
```

### Step 2: Implementing the GraphQueryEngine

Next, we need to implement the `GraphQueryEngine`. This is where you'll integrate with your specific graph database. Here's a simplified example using a hypothetical graph database:

```python
from autogen.agentchat.contrib.graph_rag.graph_query_engine import GraphQueryEngine, GraphStoreQueryResult
from autogen.agentchat.contrib.graph_rag.document import Document

class MyGraphQueryEngine(GraphQueryEngine):
    def __init__(self):
        self.graph_db = HypotheticalGraphDB()  # Initialize your graph database

    def init_db(self, input_doc: List[Document] | None = None):
        if input_doc:
            for doc in input_doc:
                self.graph_db.add_document(doc)

    def add_records(self, new_records: List) -> bool:
        for record in new_records:
            self.graph_db.add_record(record)
        return True

    def query(self, question: str, n_results: int = 1, **kwargs) -> GraphStoreQueryResult:
        results = self.graph_db.query(question, n_results)
        return GraphStoreQueryResult(answer=results.answer, results=results.data)
```

### Step 3: Creating the GraphRagCapability

Finally, we'll create the `GraphRagCapability` and add it to our agent:

```python
from autogen.agentchat.contrib.graph_rag.graph_rag_capability import GraphRagCapability
from autogen.agentchat.conversable_agent import ConversableAgent

# Create the graph query engine
graph_engine = MyGraphQueryEngine()

# Create the GraphRagCapability
graph_rag_capability = GraphRagCapability(graph_engine)

# Create a conversable agent
agent = ConversableAgent("GraphRagAgent")

# Add the capability to the agent
graph_rag_capability.add_to_agent(agent)
```

## Usage Example

Now that we have set up our Graph-based RAG system, let's see how we can use it in a conversation:

```python
from autogen.agentchat import UserProxyAgent

# Create a user proxy agent
user_proxy = UserProxyAgent("User")

# Start a conversation
user_proxy.initiate_chat(agent, message="What can you tell me about the solar system?")

# The agent will now use its Graph-based RAG capability to retrieve relevant information and respond
```

In this example, the agent will use its Graph-based RAG capability to query the underlying graph database for information about the solar system, retrieving relevant facts and relationships to construct a comprehensive response.

## Advanced Concepts

### Customizing the Graph Structure

To get the most out of Graph-based RAG, you'll want to customize the graph structure to best represent your domain knowledge. This might involve creating specific node types for different entities and defining meaningful relationships between them.

For example, in a solar system graph:

```python
class SolarSystemGraph:
    def __init__(self):
        self.graph = NetworkX()  # Using NetworkX as an example

    def add_planet(self, name, mass, distance_from_sun):
        self.graph.add_node(name, type='planet', mass=mass, distance=distance_from_sun)

    def add_moon(self, planet_name, moon_name):
        self.graph.add_node(moon_name, type='moon')
        self.graph.add_edge(planet_name, moon_name, relationship='has_moon')

# Usage
solar_system = SolarSystemGraph()
solar_system.add_planet("Earth", 5.97e24, 1)
solar_system.add_moon("Earth", "Moon")
```

### Optimizing Query Performance

As your graph grows, you'll need to optimize query performance. Some strategies include:

1. Indexing: Implement indexes on frequently queried node properties.
2. Query caching: Cache common query results to reduce database load.
3. Graph partitioning: For very large graphs, consider partitioning the graph to improve query speed.

Example of query caching:

```python
import functools

class CachedGraphQueryEngine(GraphQueryEngine):
    @functools.lru_cache(maxsize=100)
    def query(self, question: str, n_results: int = 1, **kwargs) -> GraphStoreQueryResult:
        # Existing query logic here
        pass
```

## Best Practices

1. **Design your graph schema carefully**: The structure of your graph will significantly impact the effectiveness of your RAG system. Spend time designing a schema that accurately represents your domain.

2. **Use meaningful relationships**: Don't just connect nodes; make sure the relationships between them carry semantic meaning that can be leveraged in queries.

3. **Balance detail and performance**: While it's tempting to create a highly detailed graph, remember that more complexity can lead to slower query times. Strike a balance that provides sufficient detail without sacrificing performance.

4. **Regularly update your graph**: Keep your knowledge graph up-to-date by regularly adding new information and updating existing data.

5. **Implement robust error handling**: Graph queries can be complex. Implement thorough error handling to gracefully manage unexpected results or errors.

6. **Monitor and optimize**: Regularly monitor the performance of your graph-based RAG system and optimize as necessary. This might involve refining your graph structure, optimizing queries, or scaling your infrastructure.

## Conclusion

Graph-based Retrieval-Augmented Generation is a powerful technique that can significantly enhance the capabilities of your AI agents. By structuring knowledge in a graph format, we enable more nuanced and contextually relevant information retrieval, leading to improved performance across a wide range of tasks.

In this lesson, we've explored the key components of implementing Graph-based RAG within the AutoGen framework, including the `Document` structure, `GraphQueryEngine`, and `GraphRagCapability`. We've also looked at how to implement these components, use them in a conversational context, and considered advanced concepts and best practices.

As you continue to work with Graph-based RAG, remember that the true power of this approach lies in its flexibility and ability to represent complex relationships. Experiment with different graph structures and query strategies to find the approach that works best for your specific use case.


```

# agentchat\lesson-14-extending-agentchat-custom-extensions.md

```
# Lesson 14: Extending AgentChat: Custom Extensions

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding the Extensions Folder](#understanding-the-extensions-folder)
4. [Creating a Custom Extension](#creating-a-custom-extension)
   - [Step 1: Define the Extension Class](#step-1-define-the-extension-class)
   - [Step 2: Implement the Extension Logic](#step-2-implement-the-extension-logic)
   - [Step 3: Register the Extension](#step-3-register-the-extension)
5. [Example: Creating a Weather Extension](#example-creating-a-weather-extension)
6. [Integrating Custom Extensions with Agents](#integrating-custom-extensions-with-agents)
7. [Best Practices for Custom Extensions](#best-practices-for-custom-extensions)
8. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll explore how to extend the functionality of AutoGen's AgentChat by creating custom extensions. Custom extensions allow you to add new capabilities to your agents, integrate external services, and create specialized behaviors tailored to your specific use cases.

## Project Structure

Before we dive into creating custom extensions, let's look at the project structure for a typical AutoGen project with custom extensions:

```
autogen_project/
│
├── autogen/
│   ├── agentchat/
│   │   ├── ...
│   │   └── extensions/
│   │       ├── __init__.py
│   │       └── weather_extension.py  # Our custom extension
│   ├── ...
│   └── __init__.py
│
├── examples/
│   └── use_weather_extension.py
│
├── tests/
│   └── test_weather_extension.py
│
└── setup.py
```

This structure shows where our custom extension (`weather_extension.py`) will be placed within the AutoGen project.

## Understanding the Extensions Folder

The `extensions` folder in the `agentchat` module is designed to house custom extensions that enhance the functionality of agents. Each extension is typically implemented as a separate Python module within this folder.

## Creating a Custom Extension

Let's go through the process of creating a custom extension step by step.

### Step 1: Define the Extension Class

First, we need to define a class for our extension. This class will encapsulate the functionality we want to add to our agents.

```python
# autogen/agentchat/extensions/weather_extension.py

from typing import Dict, Any

class WeatherExtension:
    def __init__(self, api_key: str):
        self.api_key = api_key

    def get_weather(self, location: str) -> Dict[str, Any]:
        # Implementation will be added in the next step
        pass
```

### Step 2: Implement the Extension Logic

Next, we'll implement the logic for our extension. In this case, we'll create a method to fetch weather data for a given location.

```python
# autogen/agentchat/extensions/weather_extension.py

import requests
from typing import Dict, Any

class WeatherExtension:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "http://api.openweathermap.org/data/2.5/weather"

    def get_weather(self, location: str) -> Dict[str, Any]:
        params = {
            "q": location,
            "appid": self.api_key,
            "units": "metric"
        }
        response = requests.get(self.base_url, params=params)
        if response.status_code == 200:
            data = response.json()
            return {
                "temperature": data["main"]["temp"],
                "description": data["weather"][0]["description"],
                "humidity": data["main"]["humidity"]
            }
        else:
            raise Exception(f"Failed to fetch weather data: {response.status_code}")
```

### Step 3: Register the Extension

To make the extension available to agents, we need to register it. This is typically done in the `__init__.py` file of the extensions folder.

```python
# autogen/agentchat/extensions/__init__.py

from .weather_extension import WeatherExtension

__all__ = ["WeatherExtension"]
```

## Example: Creating a Weather Extension

Now that we have our `WeatherExtension` class, let's see how we can use it in an agent. We'll create a simple example that demonstrates how an agent can use this extension to provide weather information.

```python
# examples/use_weather_extension.py

from autogen import AssistantAgent, UserProxyAgent
from autogen.agentchat.extensions import WeatherExtension

# Initialize the WeatherExtension
weather_extension = WeatherExtension(api_key="your_openweathermap_api_key")

# Create an assistant that can use the weather extension
weather_assistant = AssistantAgent(
    name="WeatherAssistant",
    llm_config={
        "temperature": 0.7,
        "model": "gpt-4"
    }
)

# Add the weather extension to the assistant
weather_assistant.register_function(
    function_map={
        "get_weather": weather_extension.get_weather
    }
)

# Create a user proxy agent
user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
)

# Start the conversation
user_proxy.initiate_chat(
    weather_assistant,
    message="What's the weather like in New York today?"
)
```

In this example, we've created a `WeatherAssistant` that has access to the `get_weather` function from our `WeatherExtension`. The assistant can now use this function to fetch and provide weather information during conversations.

## Integrating Custom Extensions with Agents

To make the most of custom extensions, consider the following integration techniques:

1. **Function Registration**: As shown in the example, use the `register_function` method to add extension functionality to agents.

2. **Extension-Aware Prompts**: Update the agent's system message to inform it about the new capabilities provided by the extension.

3. **Error Handling**: Implement proper error handling in your extensions and agents to gracefully handle API failures or unexpected responses.

4. **Caching**: For extensions that make external API calls, consider implementing a caching mechanism to improve performance and reduce API usage.

## Best Practices for Custom Extensions

When creating custom extensions for AutoGen, keep these best practices in mind:

1. **Modularity**: Design extensions to be modular and reusable across different agents and projects.

2. **Documentation**: Provide clear documentation for your extensions, including usage examples and any required API keys or setup steps.

3. **Testing**: Write unit tests for your extensions to ensure they work correctly and handle edge cases.

4. **Version Compatibility**: Clearly specify which versions of AutoGen your extension is compatible with.

5. **Security**: Be cautious when handling sensitive information like API keys. Use environment variables or secure configuration management.

6. **Performance**: Optimize your extensions for performance, especially if they involve network requests or heavy computations.

7. **Flexibility**: Design your extensions to be configurable, allowing users to customize their behavior as needed.

Here's an example of how you might implement some of these best practices:

```python
# autogen/agentchat/extensions/weather_extension.py

import os
import requests
from typing import Dict, Any
from cachetools import TTLCache

class WeatherExtension:
    def __init__(self, api_key: str = None, cache_ttl: int = 3600):
        self.api_key = api_key or os.environ.get("OPENWEATHERMAP_API_KEY")
        if not self.api_key:
            raise ValueError("OpenWeatherMap API key is required")
        self.base_url = "http://api.openweathermap.org/data/2.5/weather"
        self.cache = TTLCache(maxsize=100, ttl=cache_ttl)

    def get_weather(self, location: str) -> Dict[str, Any]:
        if location in self.cache:
            return self.cache[location]

        params = {
            "q": location,
            "appid": self.api_key,
            "units": "metric"
        }
        try:
            response = requests.get(self.base_url, params=params, timeout=5)
            response.raise_for_status()
            data = response.json()
            result = {
                "temperature": data["main"]["temp"],
                "description": data["weather"][0]["description"],
                "humidity": data["main"]["humidity"]
            }
            self.cache[location] = result
            return result
        except requests.RequestException as e:
            raise Exception(f"Failed to fetch weather data: {str(e)}")
```

This improved version includes error handling, caching, and the ability to use an environment variable for the API key.

## Conclusion

Custom extensions provide a powerful way to enhance the capabilities of AutoGen agents. By creating well-designed, modular extensions, you can add specialized functionality to your agents, integrate external services, and build more sophisticated AI applications.

Remember to follow best practices when developing extensions, and always consider the security and performance implications of your implementations. With custom extensions, you can tailor AutoGen to meet the specific needs of your projects and create more versatile and capable AI agents.


```

# agentchat\lesson-15-advanced-message-handling.md

```
# Lesson 15: Advanced Message Handling and Processing in AgentChat

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Message Structures Across Different Agent Types](#message-structures)
4. [Customizing Message Flow in Complex Agent Systems](#customizing-message-flow)
5. [Implementing Advanced Filtering and Routing](#advanced-filtering-and-routing)
6. [Practical Examples](#practical-examples)
7. [Best Practices](#best-practices)
8. [Conclusion](#conclusion)

## 1. Introduction <a name="introduction"></a>

In this lesson, we'll dive deep into advanced message handling and processing techniques in the AgentChat module of AutoGen. Understanding how to manipulate and control message flow is crucial for building sophisticated multi-agent systems. We'll explore various aspects of message handling, including different message structures, customizing message flow, and implementing advanced filtering and routing mechanisms.

## 2. Project Structure <a name="project-structure"></a>

Before we begin, let's look at the typical project structure for an application using advanced message handling in AgentChat:

```
autogen_project/
├── main.py
├── agents/
│   ├── __init__.py
│   ├── base_agent.py
│   ├── assistant_agent.py
│   ├── user_proxy_agent.py
│   └── custom_agent.py
├── message_handlers/
│   ├── __init__.py
│   ├── message_processor.py
│   ├── filter.py
│   └── router.py
├── utils/
│   ├── __init__.py
│   └── message_utils.py
├── config/
│   └── config.json
└── requirements.txt
```

This structure organizes our code into separate modules for agents, message handlers, and utilities, making it easier to manage and extend our application.

## 3. Message Structures Across Different Agent Types <a name="message-structures"></a>

Different agent types in AutoGen may use slightly different message structures. Let's examine these structures and how to work with them effectively.

### 3.1 Basic Message Structure

The basic message structure in AutoGen is a dictionary with the following keys:

- `role`: The role of the message sender (e.g., "user", "assistant", "system")
- `content`: The actual content of the message

Example:

```python
basic_message = {
    "role": "user",
    "content": "What's the weather like today?"
}
```

### 3.2 AssistantAgent Message Structure

AssistantAgent may include additional fields in its messages:

```python
assistant_message = {
    "role": "assistant",
    "content": "Based on the current data, it's sunny with a high of 75°F (24°C) today.",
    "function_call": None,
    "context": {"timestamp": "2024-09-17T10:30:00Z"}
}
```

### 3.3 UserProxyAgent Message Structure

UserProxyAgent messages might include metadata about user interactions:

```python
user_proxy_message = {
    "role": "user",
    "content": "Show me the forecast for the next 5 days.",
    "metadata": {
        "user_id": "user123",
        "session_id": "abcd1234",
        "client_info": {"browser": "Chrome", "os": "Windows"}
    }
}
```

To handle these different structures effectively, we can create a `MessageProcessor` class:

```python
# message_handlers/message_processor.py

class MessageProcessor:
    @staticmethod
    def extract_content(message: dict) -> str:
        return message.get("content", "")

    @staticmethod
    def extract_metadata(message: dict) -> dict:
        return message.get("metadata", {})

    @staticmethod
    def extract_function_call(message: dict) -> dict:
        return message.get("function_call")

    @staticmethod
    def create_response(role: str, content: str, **kwargs) -> dict:
        response = {"role": role, "content": content}
        response.update(kwargs)
        return response
```

## 4. Customizing Message Flow in Complex Agent Systems <a name="customizing-message-flow"></a>

In complex multi-agent systems, customizing the message flow can greatly enhance the system's capabilities. Let's explore some techniques to achieve this.

### 4.1 Message Interception and Modification

We can intercept and modify messages before they reach their intended recipient. This is useful for adding context, logging, or transforming message content.

```python
# message_handlers/message_processor.py

class MessageInterceptor:
    def __init__(self, agents):
        self.agents = agents

    def intercept(self, sender, recipient, message):
        # Add timestamp to all messages
        message["timestamp"] = time.time()

        # If the sender is a UserProxyAgent, add user context
        if isinstance(sender, UserProxyAgent):
            message["user_context"] = self.get_user_context(sender)

        return message

    def get_user_context(self, user_agent):
        # Implement logic to fetch user context
        pass
```

### 4.2 Implementing Conversation History

Maintaining conversation history can be crucial for context-aware responses. Here's how we can implement it:

```python
# agents/base_agent.py

class BaseAgent:
    def __init__(self, name):
        self.name = name
        self.conversation_history = []

    def add_to_history(self, message):
        self.conversation_history.append(message)

    def get_recent_history(self, n=5):
        return self.conversation_history[-n:]

    def clear_history(self):
        self.conversation_history = []
```

## 5. Implementing Advanced Filtering and Routing <a name="advanced-filtering-and-routing"></a>

Advanced filtering and routing mechanisms can help direct messages to the appropriate agents or handlers based on content or metadata.

### 5.1 Content-based Filtering

```python
# message_handlers/filter.py

class ContentFilter:
    def __init__(self, keywords):
        self.keywords = keywords

    def filter(self, message):
        content = message.get("content", "").lower()
        return any(keyword in content for keyword in self.keywords)
```

### 5.2 Metadata-based Routing

```python
# message_handlers/router.py

class MessageRouter:
    def __init__(self, agents):
        self.agents = agents

    def route(self, message):
        content = message.get("content", "").lower()
        metadata = message.get("metadata", {})

        if "weather" in content:
            return self.agents["weather_agent"]
        elif "schedule" in content:
            return self.agents["scheduling_agent"]
        elif metadata.get("priority") == "high":
            return self.agents["priority_handler"]
        else:
            return self.agents["default_agent"]
```

## 6. Practical Examples <a name="practical-examples"></a>

Let's put these concepts into practice with a more complex example involving multiple agents and advanced message handling.

```python
# main.py

from agents.assistant_agent import AssistantAgent
from agents.user_proxy_agent import UserProxyAgent
from message_handlers.message_processor import MessageProcessor, MessageInterceptor
from message_handlers.filter import ContentFilter
from message_handlers.router import MessageRouter

def main():
    # Initialize agents
    user_agent = UserProxyAgent("User")
    weather_agent = AssistantAgent("WeatherAgent")
    scheduling_agent = AssistantAgent("SchedulingAgent")
    general_assistant = AssistantAgent("GeneralAssistant")

    agents = {
        "user": user_agent,
        "weather": weather_agent,
        "scheduling": scheduling_agent,
        "general": general_assistant
    }

    # Set up message handling components
    message_processor = MessageProcessor()
    interceptor = MessageInterceptor(agents)
    content_filter = ContentFilter(["urgent", "important", "asap"])
    router = MessageRouter(agents)

    # Simulate a conversation
    user_message = {
        "role": "user",
        "content": "What's the weather like today? Also, can you schedule a meeting for tomorrow?",
        "metadata": {"user_id": "user123"}
    }

    # Process the message
    processed_message = message_processor.create_response(**user_message)
    intercepted_message = interceptor.intercept(user_agent, None, processed_message)

    if content_filter.filter(intercepted_message):
        print("High priority message detected!")

    # Route the message
    target_agent = router.route(intercepted_message)
    print(f"Routing message to: {target_agent.name}")

    # Handle the message (simplified for this example)
    if target_agent == weather_agent:
        response = "It's sunny today with a high of 75°F."
    elif target_agent == scheduling_agent:
        response = "I've scheduled a meeting for tomorrow at 2 PM."
    else:
        response = "I can help you with that. What specific information do you need?"

    print(f"Response: {response}")

if __name__ == "__main__":
    main()
```

This example demonstrates how to use various components for advanced message handling, including message processing, interception, filtering, and routing.

## 7. Best Practices <a name="best-practices"></a>

When implementing advanced message handling and processing, keep these best practices in mind:

1. **Modularity**: Keep message handling components separate and modular for easy maintenance and extensibility.

2. **Consistency**: Maintain a consistent message structure across your system to simplify processing.

3. **Error Handling**: Implement robust error handling to deal with malformed messages or unexpected situations.

4. **Performance**: For large-scale systems, consider optimizing message processing for performance, possibly using asynchronous processing or caching mechanisms.

5. **Security**: Be cautious when processing user input and metadata. Implement proper sanitization and validation.

6. **Logging**: Implement comprehensive logging for message flow to aid in debugging and system analysis.

7. **Scalability**: Design your message handling system to be scalable, allowing for the easy addition of new agents or message types.

## 8. Conclusion <a name="conclusion"></a>

Advanced message handling and processing are crucial components in building sophisticated multi-agent systems with AutoGen. By understanding different message structures, implementing custom message flow, and utilizing advanced filtering and routing techniques, you can create more intelligent and responsive agent-based applications.

In this lesson, we've covered the fundamentals of working with various message structures, customizing message flow, and implementing advanced filtering and routing. We've also provided practical examples and best practices to guide your implementation.

As you continue to work with AutoGen, experiment with these techniques and adapt them to your specific use cases. Remember that effective message handling can greatly enhance the capabilities and user experience of your multi-agent systems.


```

# agentchat\lesson-16-function-calling-and-tool-usage.md

```
# Lesson 16: Function Calling and Tool Usage in Agents

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding Function Calling in Agents](#understanding-function-calling-in-agents)
4. [Implementing Function Calls](#implementing-function-calls)
5. [Tool Usage in Agents](#tool-usage-in-agents)
6. [Best Practices for Function Calling and Tool Usage](#best-practices-for-function-calling-and-tool-usage)
7. [Advanced Techniques](#advanced-techniques)
8. [Practical Examples](#practical-examples)
9. [Conclusion](#conclusion)

## 1. Introduction

Function calling and tool usage are essential features in agent-based systems, allowing agents to perform specific tasks, access external resources, and enhance their capabilities. In this lesson, we'll explore how to implement and utilize these features effectively in AutoGen agents.

## 2. Project Structure

Before we dive into the details, let's look at the typical project structure for an AutoGen application that includes function calling and tool usage:

```
autogen_project/
│
├── main.py
├── agents/
│   ├── __init__.py
│   ├── assistant_agent.py
│   ├── user_proxy_agent.py
│   └── tool_using_agent.py
│
├── functions/
│   ├── __init__.py
│   ├── math_operations.py
│   ├── data_processing.py
│   └── web_utils.py
│
├── tools/
│   ├── __init__.py
│   ├── weather_api.py
│   ├── database_connector.py
│   └── file_manager.py
│
├── config/
│   └── config.json
│
└── requirements.txt
```

This structure organizes our code into separate modules for agents, functions, and tools, making it easier to manage and extend our application.

## 3. Understanding Function Calling in Agents

Function calling in agents allows them to execute predefined functions to perform specific tasks. These functions can be built-in Python functions, custom-defined functions, or even API calls to external services.

### Key Concepts:

1. **Function Registry**: A collection of functions that an agent can call.
2. **Function Signature**: The definition of a function, including its name, parameters, and return type.
3. **Function Execution**: The process of calling a function and handling its result.

## 4. Implementing Function Calls

Let's implement a basic function call system in our agents. We'll start by creating a simple math operation function and then integrate it into an agent.

First, let's create the math operation function in `functions/math_operations.py`:

```python
# functions/math_operations.py

def add_numbers(a: float, b: float) -> float:
    """Add two numbers and return the result."""
    return a + b
```

Now, let's create an agent that can use this function in `agents/tool_using_agent.py`:

```python
# agents/tool_using_agent.py

from autogen import ConversableAgent
from functions.math_operations import add_numbers

class MathAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name=name)
        self.register_function(
            function_map={
                "add_numbers": add_numbers
            }
        )

    def generate_reply(self, messages, sender):
        """Custom reply generation with function calling capability."""
        last_message = messages[-1]
        if "add" in last_message.lower():
            # Extract numbers from the message (simplified for demonstration)
            numbers = [float(s) for s in last_message.split() if s.isdigit()]
            if len(numbers) >= 2:
                result = self.execute_function(
                    function_name="add_numbers",
                    arguments={
                        "a": numbers[0],
                        "b": numbers[1]
                    }
                )
                return f"The sum is: {result}"
        
        # Default response if no function call is needed
        return "I can add numbers for you. Just ask!"

```

In this example, we've created a `MathAgent` that registers the `add_numbers` function and can use it when appropriate in the conversation.

## 5. Tool Usage in Agents

Tools are more complex than simple functions and often represent external services or APIs. They can be used to extend an agent's capabilities beyond basic computations.

Let's create a weather tool as an example:

```python
# tools/weather_api.py

import requests

class WeatherTool:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.openweathermap.org/data/2.5/weather"

    def get_weather(self, city: str) -> str:
        params = {
            "q": city,
            "appid": self.api_key,
            "units": "metric"
        }
        response = requests.get(self.base_url, params=params)
        data = response.json()
        if response.status_code == 200:
            temp = data["main"]["temp"]
            description = data["weather"][0]["description"]
            return f"The weather in {city} is {description} with a temperature of {temp}°C."
        else:
            return f"Error: Unable to fetch weather data for {city}."

```

Now, let's create an agent that can use this weather tool:

```python
# agents/tool_using_agent.py

from autogen import ConversableAgent
from tools.weather_api import WeatherTool

class WeatherAgent(ConversableAgent):
    def __init__(self, name, api_key):
        super().__init__(name=name)
        self.weather_tool = WeatherTool(api_key)

    def generate_reply(self, messages, sender):
        """Custom reply generation with weather tool usage."""
        last_message = messages[-1]
        if "weather" in last_message.lower():
            # Extract city name (simplified for demonstration)
            city = last_message.split("in")[-1].strip()
            weather_info = self.weather_tool.get_weather(city)
            return weather_info
        
        # Default response if no tool usage is needed
        return "I can provide weather information for cities. Just ask!"

```

## 6. Best Practices for Function Calling and Tool Usage

1. **Error Handling**: Always implement proper error handling for function calls and tool usage to manage unexpected inputs or API failures.

2. **Input Validation**: Validate inputs before passing them to functions or tools to ensure data integrity and prevent errors.

3. **Modular Design**: Keep functions and tools modular and reusable across different agents or projects.

4. **Documentation**: Provide clear documentation for each function and tool, including expected inputs, outputs, and any side effects.

5. **Configuration Management**: Use configuration files to manage API keys and other sensitive information for tools.

6. **Rate Limiting**: Implement rate limiting for API calls to avoid overusing external services.

7. **Caching**: Consider implementing caching mechanisms for frequently used function results or API responses to improve performance.

## 7. Advanced Techniques

### 7.1 Dynamic Function Discovery

Implement a system where agents can dynamically discover available functions based on the conversation context:

```python
# agents/dynamic_agent.py

import importlib
import inspect

class DynamicAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name=name)
        self.function_modules = {}

    def load_functions(self, module_name):
        module = importlib.import_module(module_name)
        functions = inspect.getmembers(module, inspect.isfunction)
        self.function_modules[module_name] = dict(functions)

    def generate_reply(self, messages, sender):
        last_message = messages[-1]
        for module_name, functions in self.function_modules.items():
            for func_name, func in functions.items():
                if func_name.lower() in last_message.lower():
                    # Execute the function (simplified for demonstration)
                    result = func()
                    return f"Result of {func_name}: {result}"
        return "I couldn't find a suitable function for your request."

```

### 7.2 Tool Chaining

Implement a system where multiple tools can be chained together to perform complex tasks:

```python
# agents/tool_chaining_agent.py

class ToolChainingAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name=name)
        self.tools = {}

    def add_tool(self, name, tool):
        self.tools[name] = tool

    def execute_tool_chain(self, chain):
        result = None
        for tool_name, args in chain:
            if tool_name in self.tools:
                tool = self.tools[tool_name]
                result = tool(**args)
            else:
                return f"Error: Tool '{tool_name}' not found."
        return result

    def generate_reply(self, messages, sender):
        # Logic to determine the tool chain based on the message
        # (Simplified for demonstration)
        chain = [
            ("weather_tool", {"city": "New York"}),
            ("translation_tool", {"text": "result", "target_lang": "fr"})
        ]
        result = self.execute_tool_chain(chain)
        return f"Result of tool chain: {result}"

```

## 8. Practical Examples

Let's look at a few practical examples of how to use function calling and tool usage in a real-world scenario.

### 8.1 Data Analysis Agent

```python
# agents/data_analysis_agent.py

import pandas as pd
from autogen import ConversableAgent

class DataAnalysisAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name=name)
        self.register_function(
            function_map={
                "load_csv": self.load_csv,
                "get_summary": self.get_summary,
                "plot_histogram": self.plot_histogram
            }
        )
        self.data = None

    def load_csv(self, file_path: str) -> str:
        self.data = pd.read_csv(file_path)
        return f"Loaded CSV file with {len(self.data)} rows and {len(self.data.columns)} columns."

    def get_summary(self) -> str:
        if self.data is None:
            return "No data loaded. Please load a CSV file first."
        return self.data.describe().to_string()

    def plot_histogram(self, column: str) -> str:
        if self.data is None:
            return "No data loaded. Please load a CSV file first."
        if column not in self.data.columns:
            return f"Column '{column}' not found in the data."
        plot = self.data[column].hist()
        plot_path = f"{column}_histogram.png"
        plot.figure.savefig(plot_path)
        return f"Histogram saved as {plot_path}"

    def generate_reply(self, messages, sender):
        last_message = messages[-1]
        if "load" in last_message.lower() and "csv" in last_message.lower():
            file_path = last_message.split()[-1]  # Simplified extraction
            return self.execute_function("load_csv", {"file_path": file_path})
        elif "summary" in last_message.lower():
            return self.execute_function("get_summary")
        elif "histogram" in last_message.lower():
            column = last_message.split()[-1]  # Simplified extraction
            return self.execute_function("plot_histogram", {"column": column})
        return "I can load CSV files, provide summaries, and plot histograms. How can I help you?"

```

### 8.2 Multi-Tool Agent

```python
# agents/multi_tool_agent.py

from autogen import ConversableAgent
from tools.weather_api import WeatherTool
from tools.database_connector import DatabaseConnector
from tools.file_manager import FileManager

class MultiToolAgent(ConversableAgent):
    def __init__(self, name, weather_api_key, db_config, file_dir):
        super().__init__(name=name)
        self.weather_tool = WeatherTool(weather_api_key)
        self.db_tool = DatabaseConnector(**db_config)
        self.file_tool = FileManager(file_dir)

    def generate_reply(self, messages, sender):
        last_message = messages[-1].lower()
        
        if "weather" in last_message:
            city = last_message.split("in")[-1].strip()
            return self.weather_tool.get_weather(city)
        
        elif "database" in last_message:
            if "query" in last_message:
                query = last_message.split("query")[-1].strip()
                return self.db_tool.execute_query(query)
            else:
                return "I can execute database queries. Please provide a query."
        
        elif "file" in last_message:
            if "list" in last_message:
                return self.file_tool.list_files()
            elif "read" in last_message:
                file_name = last_message.split("read")[-1].strip()
                return self.file_tool.read_file(file_name)
            elif "write" in last_message:
                # Simplified for demonstration
                file_name, content = last_message.split("write")[-1].split(":")
                return self.file_tool.write_file(file_name.strip(), content.strip())
            else:
                return "I can list, read, and write files. Please specify an action."
        
        return "I can help with weather information, database queries, and file operations. What would you like to do?"

```

## 9. Conclusion

Function calling and tool usage are powerful features that greatly enhance the capabilities of AutoGen agents. By implementing these features, you can create more versatile and efficient AI systems that can perform a wide range of tasks, from simple calculations to complex data analysis and external API interactions.

Remember to follow best practices, such as error handling, input validation, and modular design, to ensure your agents are robust and maintainable. As you build more complex systems, consider advanced techniques like dynamic function discovery and tool chaining to create even more flexible and powerful agents.

Practice implementing these concepts in your own projects, and don't hesitate to explore new ways to combine functions and tools to solve unique challenges in your AI applications.


```

# agentchat\lesson-17-state-management.md

```
# Lesson 17: State Management in Autogen Agents

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Handling Conversation History](#handling-conversation-history)
4. [Implementing Memory in Contributed Agents](#implementing-memory-in-contributed-agents)
5. [Strategies for Long-Term State Preservation](#strategies-for-long-term-state-preservation)
6. [Best Practices and Considerations](#best-practices-and-considerations)
7. [Practical Examples](#practical-examples)
8. [Conclusion](#conclusion)

## 1. Introduction

State management is a critical aspect of building intelligent and context-aware agents using Autogen. It involves handling conversation history, implementing memory mechanisms, and preserving long-term state in complex systems. In this lesson, we'll explore various techniques and strategies for effective state management in Autogen agents.

## 2. Project Structure

Before we dive into the details, let's look at a typical project structure for an Autogen application that implements state management:

```
autogen_state_management/
│
├── agents/
│   ├── __init__.py
│   ├── base_agent.py
│   ├── stateful_agent.py
│   └── memory_enhanced_agent.py
│
├── memory/
│   ├── __init__.py
│   ├── conversation_memory.py
│   └── long_term_memory.py
│
├── utils/
│   ├── __init__.py
│   └── state_utils.py
│
├── config/
│   └── config.json
│
├── main.py
├── requirements.txt
└── README.md
```

This structure organizes our code into logical components:
- `agents/`: Contains our agent implementations
- `memory/`: Includes modules for handling different types of memory
- `utils/`: Utility functions for state management
- `config/`: Configuration files
- `main.py`: The entry point of our application

Now, let's explore each aspect of state management in detail.

## 3. Handling Conversation History

Autogen provides built-in mechanisms for handling conversation history in its agents. The `ConversableAgent` class, which is the base class for most Autogen agents, maintains a history of messages for each conversation partner.

### Example: Accessing Conversation History

```python
# agents/stateful_agent.py

from autogen import ConversableAgent

class StatefulAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)

    def summarize_conversation(self, partner):
        history = self.chat_messages[partner]
        summary = f"Conversation with {partner.name}:\n"
        for message in history:
            summary += f"{message['role']}: {message['content'][:50]}...\n"
        return summary

# Usage
agent1 = StatefulAgent("Agent1")
agent2 = StatefulAgent("Agent2")

agent1.send("Hello, how are you?", agent2)
agent2.send("I'm doing well, thank you!", agent1)

print(agent1.summarize_conversation(agent2))
```

In this example, we create a `StatefulAgent` class that can summarize its conversation history with a particular partner.

## 4. Implementing Memory in Contributed Agents

For more advanced memory capabilities, we can implement custom memory mechanisms in contributed agents. This allows us to maintain state beyond just the conversation history.

### Example: Memory-Enhanced Agent

```python
# memory/conversation_memory.py

class ConversationMemory:
    def __init__(self):
        self.short_term = []
        self.long_term = {}

    def add_to_short_term(self, message):
        self.short_term.append(message)
        if len(self.short_term) > 10:
            self.short_term.pop(0)

    def add_to_long_term(self, key, value):
        self.long_term[key] = value

# agents/memory_enhanced_agent.py

from autogen import ConversableAgent
from memory.conversation_memory import ConversationMemory

class MemoryEnhancedAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)
        self.memory = ConversationMemory()

    def process_message(self, message, sender):
        self.memory.add_to_short_term({"sender": sender.name, "content": message})
        # Process the message and potentially add important info to long-term memory
        if "important_fact" in message:
            self.memory.add_to_long_term("fact", message)

    def generate_reply(self, messages, sender):
        # Use both short-term and long-term memory to generate a reply
        context = self.memory.short_term + list(self.memory.long_term.values())
        # Use the context to inform the response generation
        # ...

# Usage
agent = MemoryEnhancedAgent("MemoryAgent")
human = ConversableAgent("Human")

human.send("Hello, I have an important fact: The sky is blue.", agent)
human.send("What was the important fact I told you?", agent)
```

This example demonstrates a `MemoryEnhancedAgent` that maintains both short-term and long-term memory, allowing it to recall important information from past interactions.

## 5. Strategies for Long-Term State Preservation

For complex systems that require maintaining state across multiple sessions or long periods, we need to implement strategies for long-term state preservation.

### Example: Persistent State Agent

```python
# memory/long_term_memory.py

import json

class LongTermMemory:
    def __init__(self, file_path):
        self.file_path = file_path
        self.data = self.load()

    def load(self):
        try:
            with open(self.file_path, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return {}

    def save(self):
        with open(self.file_path, 'w') as f:
            json.dump(self.data, f)

    def add(self, key, value):
        self.data[key] = value
        self.save()

    def get(self, key):
        return self.data.get(key)

# agents/persistent_agent.py

from autogen import ConversableAgent
from memory.long_term_memory import LongTermMemory

class PersistentAgent(ConversableAgent):
    def __init__(self, name, memory_file):
        super().__init__(name)
        self.long_term_memory = LongTermMemory(memory_file)

    def remember(self, key, value):
        self.long_term_memory.add(key, value)

    def recall(self, key):
        return self.long_term_memory.get(key)

# Usage
agent = PersistentAgent("PersistentAgent", "agent_memory.json")
human = ConversableAgent("Human")

human.send("Remember that my favorite color is blue", agent)
agent.remember("favorite_color", "blue")

# In a later session or after restarting the application
recalled_color = agent.recall("favorite_color")
print(f"The human's favorite color is {recalled_color}")
```

This example shows a `PersistentAgent` that can store and retrieve information across multiple sessions using a JSON file for persistence.

## 6. Best Practices and Considerations

When implementing state management in Autogen agents, consider the following best practices:

1. **Privacy and Security**: Be cautious about what information is stored, especially when dealing with sensitive data.
2. **Scalability**: Design your state management system to handle growing amounts of data efficiently.
3. **Consistency**: Ensure that state is updated consistently across all components of your system.
4. **Versioning**: Implement a versioning system for your state data to handle changes in data structure over time.
5. **Cleanup**: Implement mechanisms to clean up or archive old state data to prevent unbounded growth.

## 7. Practical Examples

Let's look at a more complex example that combines various state management techniques:

```python
# main.py

from autogen import ConversableAgent
from agents.memory_enhanced_agent import MemoryEnhancedAgent
from agents.persistent_agent import PersistentAgent

def run_complex_scenario():
    human = ConversableAgent("Human")
    memory_agent = MemoryEnhancedAgent("MemoryAgent")
    persistent_agent = PersistentAgent("PersistentAgent", "persistent_memory.json")

    # Scenario 1: Short-term memory
    human.send("My name is Alice", memory_agent)
    human.send("What's my name?", memory_agent)

    # Scenario 2: Long-term memory
    human.send("Remember that I like pizza", persistent_agent)
    persistent_agent.remember("food_preference", "pizza")

    # Scenario 3: Combining agents
    human.send("Tell MemoryAgent that I like pizza", persistent_agent)
    persistent_agent.send(f"The human likes {persistent_agent.recall('food_preference')}", memory_agent)

    # Scenario 4: Complex interaction
    human.send("What do you know about me?", memory_agent)
    # MemoryAgent should be able to recall the name and food preference

if __name__ == "__main__":
    run_complex_scenario()
```

This example demonstrates how different types of agents with various state management capabilities can interact in a complex scenario.

## 8. Conclusion

Effective state management is crucial for building sophisticated AI agents with Autogen. By leveraging built-in conversation history, implementing custom memory mechanisms, and using strategies for long-term state preservation, we can create agents that maintain context, learn from interactions, and provide more intelligent and personalized responses.

Remember to always consider the specific requirements of your application when designing your state management system, and be mindful of the trade-offs between complexity, performance, and functionality.

In the next lesson, we'll explore advanced topics in Autogen, including integration with external services and scaling agent systems for production use.

```

# agentchat\lesson-18-error-handling.md

```
# Lesson 18: Error Handling and Robustness in Agent Interactions

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Common Pitfalls in Agent Interactions](#common-pitfalls-in-agent-interactions)
4. [Implementing Retry Mechanisms](#implementing-retry-mechanisms)
5. [Graceful Degradation Strategies](#graceful-degradation-strategies)
6. [Error Handling in Different Agent Types](#error-handling-in-different-agent-types)
7. [Practical Examples](#practical-examples)
8. [Best Practices](#best-practices)
9. [Conclusion](#conclusion)

## 1. Introduction

In the world of AI agents and multi-agent systems, error handling and robustness are crucial aspects that can make or break the effectiveness of your application. This lesson focuses on identifying common pitfalls, implementing retry mechanisms, and developing strategies for graceful degradation when things don't go as planned.

## 2. Project Structure

Before we dive into the details, let's look at a typical project structure for an AutoGen application that implements robust error handling:

```
autogen_project/
│
├── agents/
│   ├── __init__.py
│   ├── base_agent.py
│   ├── assistant_agent.py
│   ├── user_proxy_agent.py
│   └── error_handling_agent.py
│
├── error_handlers/
│   ├── __init__.py
│   ├── retry_handler.py
│   └── graceful_degradation.py
│
├── utils/
│   ├── __init__.py
│   └── error_logging.py
│
├── config/
│   └── error_config.json
│
├── main.py
├── requirements.txt
└── README.md
```

This structure separates our agents, error handling mechanisms, and utility functions into different modules, making the codebase more organized and maintainable.

## 3. Common Pitfalls in Agent Interactions

Let's explore some common pitfalls that can occur during agent interactions:

1. **Network Failures**: When agents communicate over a network, connections can fail or time out.
2. **API Rate Limiting**: Many LLM providers have rate limits that can be exceeded during intense agent interactions.
3. **Unexpected Input Formats**: Agents might receive inputs in formats they're not designed to handle.
4. **Infinite Loops**: Poorly designed agent logic can lead to endless back-and-forth interactions.
5. **Resource Exhaustion**: Long-running agent tasks can consume excessive memory or CPU resources.

Example of a network failure scenario:

```python
# agents/assistant_agent.py

import requests
from autogen import AssistantAgent

class RobustAssistantAgent(AssistantAgent):
    def generate_reply(self, messages):
        try:
            response = requests.post("https://api.example.com/generate", json={"messages": messages})
            response.raise_for_status()
            return response.json()["reply"]
        except requests.RequestException as e:
            print(f"Network error occurred: {e}")
            return None
```

## 4. Implementing Retry Mechanisms

Retry mechanisms are essential for handling transient errors. Let's implement a simple retry decorator:

```python
# error_handlers/retry_handler.py

import time
from functools import wraps

def retry_with_exponential_backoff(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        max_retries = 5
        retry_delay = 1
        for attempt in range(max_retries):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                if attempt == max_retries - 1:
                    raise e
                time.sleep(retry_delay)
                retry_delay *= 2
    return wrapper
```

Now we can use this decorator in our agent:

```python
# agents/error_handling_agent.py

from autogen import ConversableAgent
from error_handlers.retry_handler import retry_with_exponential_backoff

class ErrorHandlingAgent(ConversableAgent):
    @retry_with_exponential_backoff
    def generate_reply(self, messages):
        # Your implementation here
        pass
```

## 5. Graceful Degradation Strategies

When errors persist, it's important to have fallback strategies. Let's implement a graceful degradation handler:

```python
# error_handlers/graceful_degradation.py

class GracefulDegradationHandler:
    def __init__(self, primary_function, fallback_function):
        self.primary_function = primary_function
        self.fallback_function = fallback_function

    def execute(self, *args, **kwargs):
        try:
            return self.primary_function(*args, **kwargs)
        except Exception as e:
            print(f"Primary function failed: {e}. Falling back to alternative.")
            return self.fallback_function(*args, **kwargs)
```

Usage in an agent:

```python
# agents/error_handling_agent.py

from error_handlers.graceful_degradation import GracefulDegradationHandler

class ErrorHandlingAgent(ConversableAgent):
    def __init__(self, name, llm_config, fallback_config):
        super().__init__(name, llm_config)
        self.fallback_config = fallback_config
        self.reply_handler = GracefulDegradationHandler(
            self.generate_reply_primary,
            self.generate_reply_fallback
        )

    def generate_reply_primary(self, messages):
        # Primary reply generation logic
        pass

    def generate_reply_fallback(self, messages):
        # Fallback reply generation logic
        pass

    def generate_reply(self, messages):
        return self.reply_handler.execute(messages)
```

## 6. Error Handling in Different Agent Types

Different types of agents may require specific error handling strategies. Let's look at examples for AssistantAgent and UserProxyAgent:

```python
# agents/assistant_agent.py

from autogen import AssistantAgent
from error_handlers.retry_handler import retry_with_exponential_backoff

class RobustAssistantAgent(AssistantAgent):
    @retry_with_exponential_backoff
    def generate_reply(self, messages):
        try:
            return super().generate_reply(messages)
        except Exception as e:
            print(f"Error in AssistantAgent: {e}")
            return "I apologize, but I'm having trouble generating a response right now."

# agents/user_proxy_agent.py

from autogen import UserProxyAgent

class RobustUserProxyAgent(UserProxyAgent):
    def get_human_input(self, prompt):
        while True:
            try:
                return super().get_human_input(prompt)
            except KeyboardInterrupt:
                print("\nInput interrupted. Please try again or type 'exit' to quit.")
            except Exception as e:
                print(f"An error occurred: {e}. Please try again.")
```

## 7. Practical Examples

Let's put it all together in a practical example:

```python
# main.py

from agents.error_handling_agent import ErrorHandlingAgent
from agents.assistant_agent import RobustAssistantAgent
from agents.user_proxy_agent import RobustUserProxyAgent

def main():
    assistant = RobustAssistantAgent(
        name="Assistant",
        llm_config={
            "temperature": 0.7,
            "model": "gpt-3.5-turbo"
        }
    )

    user_proxy = RobustUserProxyAgent(
        name="User",
        human_input_mode="ALWAYS"
    )

    error_handler = ErrorHandlingAgent(
        name="ErrorHandler",
        llm_config={
            "temperature": 0.5,
            "model": "gpt-3.5-turbo"
        },
        fallback_config={
            "temperature": 0.3,
            "model": "gpt-3.5-turbo-instruct"
        }
    )

    # Start a conversation
    user_proxy.initiate_chat(
        assistant,
        message="Hello! Can you help me with a task?",
        error_handler=error_handler
    )

if __name__ == "__main__":
    main()
```

This example demonstrates how to use our robust agents and error handling mechanisms in a simple conversation scenario.

## 8. Best Practices

1. **Log Everything**: Implement comprehensive logging to track errors and their context.
2. **Use Configuration Files**: Store error-related configurations (e.g., retry attempts, timeouts) in external config files.
3. **Monitor and Alert**: Set up monitoring and alerting systems to notify you of recurring errors.
4. **Test Edge Cases**: Develop thorough test suites that cover various error scenarios.
5. **Implement Circuit Breakers**: Use the circuit breaker pattern to prevent repeated calls to failing services.

Example of implementing logging:

```python
# utils/error_logging.py

import logging

def setup_logger():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        filename='agent_errors.log'
    )
    return logging.getLogger(__name__)

logger = setup_logger()

# Usage in an agent
class LoggingAgent(ConversableAgent):
    def generate_reply(self, messages):
        try:
            reply = super().generate_reply(messages)
            logger.info(f"Generated reply: {reply}")
            return reply
        except Exception as e:
            logger.error(f"Error generating reply: {e}", exc_info=True)
            raise
```

## 9. Conclusion

Error handling and robustness are critical aspects of building reliable multi-agent systems. By implementing retry mechanisms, graceful degradation strategies, and following best practices, you can create agents that are resilient to various types of failures and provide a smooth user experience even in the face of unexpected issues.

Remember to always test your error handling thoroughly and continuously monitor your system in production to catch and address any new error patterns that may emerge.

In the next lesson, we'll explore advanced techniques for optimizing agent performance, including caching strategies and efficient message passing in group chats.

```

# agentchat\lesson-19-optimizing-agent-performance.md

```
# Lesson 19: Optimizing Agent Performance

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Caching Strategies](#caching-strategies)
   - [3.1 Message Caching](#message-caching)
   - [3.2 Embedding Caching](#embedding-caching)
4. [Efficient Message Passing in Group Chats](#efficient-message-passing-in-group-chats)
5. [Reducing API Calls and Latency](#reducing-api-calls-and-latency)
   - [5.1 Batching Requests](#batching-requests)
   - [5.2 Parallel Processing](#parallel-processing)
6. [Memory Management](#memory-management)
7. [Optimizing Retrieval-Augmented Agents](#optimizing-retrieval-augmented-agents)
8. [Performance Monitoring and Profiling](#performance-monitoring-and-profiling)
9. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll dive deep into optimizing the performance of Autogen agents. As AI applications become more complex and handle larger volumes of data, it's crucial to implement strategies that enhance efficiency, reduce latency, and manage resources effectively. We'll explore various techniques, from caching to efficient message passing, that can significantly improve the performance of your Autogen-based systems.

## 2. Project Structure

Before we begin, let's look at the typical project structure for an optimized Autogen application:

```
autogen_optimized_project/
│
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── base_agent.py
│   │   ├── assistant_agent.py
│   │   └── user_proxy_agent.py
│   ├── caching/
│   │   ├── __init__.py
│   │   ├── message_cache.py
│   │   └── embedding_cache.py
│   ├── group_chat/
│   │   ├── __init__.py
│   │   └── efficient_group_chat.py
│   ├── retrieval/
│   │   ├── __init__.py
│   │   └── optimized_retriever.py
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── api_utils.py
│   │   └── memory_utils.py
│   └── main.py
├── tests/
│   ├── test_caching.py
│   ├── test_group_chat.py
│   └── test_retrieval.py
├── config/
│   └── config.yaml
├── requirements.txt
└── README.md
```

This structure organizes our optimization efforts into separate modules, making it easier to implement and maintain performance improvements.

## 3. Caching Strategies

Caching is one of the most effective ways to optimize agent performance. By storing and reusing previously computed results, we can significantly reduce API calls and computation time.

### 3.1 Message Caching

Message caching involves storing the responses of language models to avoid redundant API calls. Here's an example of how to implement a simple message cache:

```python
# src/caching/message_cache.py

import hashlib
from typing import Dict, List

class MessageCache:
    def __init__(self):
        self.cache: Dict[str, str] = {}

    def get_cache_key(self, messages: List[Dict[str, str]]) -> str:
        """Generate a unique cache key for a list of messages."""
        message_str = str(messages)
        return hashlib.md5(message_str.encode()).hexdigest()

    def get(self, messages: List[Dict[str, str]]) -> str:
        """Retrieve a cached response for given messages."""
        key = self.get_cache_key(messages)
        return self.cache.get(key)

    def set(self, messages: List[Dict[str, str]], response: str) -> None:
        """Cache a response for given messages."""
        key = self.get_cache_key(messages)
        self.cache[key] = response

# Usage in an agent
class OptimizedAgent(BaseAgent):
    def __init__(self):
        self.message_cache = MessageCache()

    def generate_response(self, messages: List[Dict[str, str]]) -> str:
        cached_response = self.message_cache.get(messages)
        if cached_response:
            return cached_response

        # Generate response using LLM
        response = self._call_llm_api(messages)

        # Cache the response
        self.message_cache.set(messages, response)

        return response
```

### 3.2 Embedding Caching

For retrieval-augmented agents, caching embeddings can significantly speed up similarity searches:

```python
# src/caching/embedding_cache.py

import numpy as np
from typing import Dict, List

class EmbeddingCache:
    def __init__(self):
        self.cache: Dict[str, np.ndarray] = {}

    def get(self, text: str) -> np.ndarray:
        """Retrieve cached embedding for given text."""
        return self.cache.get(text)

    def set(self, text: str, embedding: np.ndarray) -> None:
        """Cache embedding for given text."""
        self.cache[text] = embedding

# Usage in a retriever
class OptimizedRetriever:
    def __init__(self):
        self.embedding_cache = EmbeddingCache()

    def get_embedding(self, text: str) -> np.ndarray:
        cached_embedding = self.embedding_cache.get(text)
        if cached_embedding is not None:
            return cached_embedding

        # Generate embedding using an embedding model
        embedding = self._generate_embedding(text)

        # Cache the embedding
        self.embedding_cache.set(text, embedding)

        return embedding
```

## 4. Efficient Message Passing in Group Chats

In group chats with multiple agents, efficient message passing is crucial for performance. We can optimize this by implementing a selective message passing strategy:

```python
# src/group_chat/efficient_group_chat.py

from typing import List, Dict

class EfficientGroupChat:
    def __init__(self, agents: List[BaseAgent]):
        self.agents = agents

    def run_chat(self, initial_message: str):
        messages = [{"role": "user", "content": initial_message}]
        for i, agent in enumerate(self.agents):
            if i == 0:
                response = agent.generate_response(messages)
            else:
                # Only pass relevant messages to subsequent agents
                relevant_messages = self._get_relevant_messages(messages, agent)
                response = agent.generate_response(relevant_messages)
            messages.append({"role": "assistant", "content": response})

    def _get_relevant_messages(self, messages: List[Dict[str, str]], agent: BaseAgent) -> List[Dict[str, str]]:
        # Implement logic to select relevant messages for the agent
        # This could be based on agent-specific keywords, recent message history, etc.
        return messages[-5:]  # For example, only pass the last 5 messages
```

This approach reduces the number of messages each agent needs to process, improving overall performance in large group chats.

## 5. Reducing API Calls and Latency

### 5.1 Batching Requests

When dealing with multiple similar requests, batching them into a single API call can significantly reduce latency:

```python
# src/utils/api_utils.py

from typing import List
import asyncio

class BatchProcessor:
    def __init__(self, batch_size: int = 10):
        self.batch_size = batch_size

    async def process_batch(self, items: List[str], process_func):
        results = []
        for i in range(0, len(items), self.batch_size):
            batch = items[i:i + self.batch_size]
            batch_results = await asyncio.gather(*[process_func(item) for item in batch])
            results.extend(batch_results)
        return results

# Usage
async def main():
    processor = BatchProcessor()
    items = ["item1", "item2", "item3", ..., "item100"]
    results = await processor.process_batch(items, some_api_call_function)
```

### 5.2 Parallel Processing

For tasks that can be executed independently, parallel processing can significantly reduce overall execution time:

```python
# src/utils/api_utils.py

import concurrent.futures
from typing import List, Callable

def parallel_process(items: List[str], process_func: Callable, max_workers: int = 5):
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(executor.map(process_func, items))
    return results

# Usage
def some_api_call(item: str):
    # Simulate API call
    return f"Processed {item}"

items = ["item1", "item2", "item3", ..., "item100"]
results = parallel_process(items, some_api_call)
```

## 6. Memory Management

Efficient memory management is crucial, especially for long-running agent conversations. Implement a strategy to periodically clear or compress the conversation history:

```python
# src/utils/memory_utils.py

from typing import List, Dict

class MemoryManager:
    def __init__(self, max_messages: int = 100):
        self.max_messages = max_messages

    def compress_history(self, messages: List[Dict[str, str]]) -> List[Dict[str, str]]:
        if len(messages) <= self.max_messages:
            return messages

        # Keep the first message (usually system message) and the last max_messages - 1
        return [messages[0]] + messages[-(self.max_messages - 1):]

# Usage in an agent
class MemoryEfficientAgent(BaseAgent):
    def __init__(self):
        self.memory_manager = MemoryManager()

    def process_messages(self, messages: List[Dict[str, str]]):
        compressed_messages = self.memory_manager.compress_history(messages)
        # Process the compressed messages
        ...
```

## 7. Optimizing Retrieval-Augmented Agents

For retrieval-augmented agents, optimize the retrieval process:

```python
# src/retrieval/optimized_retriever.py

import faiss
import numpy as np
from typing import List, Tuple

class OptimizedRetriever:
    def __init__(self, embedding_dimension: int):
        self.index = faiss.IndexFlatL2(embedding_dimension)
        self.documents = []

    def add_documents(self, documents: List[str], embeddings: List[np.ndarray]):
        self.index.add(np.array(embeddings))
        self.documents.extend(documents)

    def retrieve(self, query_embedding: np.ndarray, k: int = 5) -> List[Tuple[str, float]]:
        distances, indices = self.index.search(query_embedding.reshape(1, -1), k)
        return [(self.documents[i], distances[0][j]) for j, i in enumerate(indices[0])]

# Usage
retriever = OptimizedRetriever(embedding_dimension=768)
documents = ["doc1", "doc2", "doc3", ...]
embeddings = [np.random.rand(768) for _ in documents]  # In practice, generate these using an embedding model
retriever.add_documents(documents, embeddings)

query_embedding = np.random.rand(768)  # In practice, generate this from the query
results = retriever.retrieve(query_embedding)
```

This implementation uses FAISS for efficient similarity search, which is much faster than naive approaches, especially for large document collections.

## 8. Performance Monitoring and Profiling

Implement performance monitoring to identify bottlenecks:

```python
# src/utils/profiling.py

import time
from functools import wraps

def profile(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        print(f"{func.__name__} took {end_time - start_time:.2f} seconds to execute.")
        return result
    return wrapper

# Usage
@profile
def some_function():
    # Function implementation
    ...

# This will print the execution time of some_function
some_function()
```

## 9. Conclusion

Optimizing agent performance is crucial for building efficient and scalable AI systems. By implementing caching strategies, efficient message passing, reducing API calls, managing memory effectively, and optimizing retrieval processes, you can significantly enhance the performance of your Autogen agents.

Remember to profile your code and continuously monitor performance metrics to identify and address bottlenecks. As your system grows, you may need to implement more advanced optimization techniques or consider distributed computing solutions for handling larger workloads.

In the next lesson, we'll explore advanced use cases and real-world applications of optimized Autogen agents, demonstrating how these performance improvements can be leveraged in complex AI systems.

```

# agentchat\lesson-2-understanding-agent-base-class.md

```
# Lesson 2: Understanding the Agent Base Class

## Table of Contents
1. [Introduction](#introduction)
2. [The Agent Base Class](#the-agent-base-class)
3. [Core Methods and Attributes](#core-methods-and-attributes)
4. [Creating Custom Agents](#creating-custom-agents)
5. [Project Structure](#project-structure)
6. [Hands-on Example](#hands-on-example)
7. [Exercise](#exercise)
8. [Summary and Next Steps](#summary-and-next-steps)

## Introduction

Welcome to Lesson 2 of our Autogen AgentChat module series. In this lesson, we'll take a deep dive into the Agent base class, which serves as the foundation for all agent types in the Autogen framework. Understanding this base class is crucial for creating custom agents and extending the functionality of existing ones.

We'll examine the core methods and attributes of the Agent class, explore how to create custom agents, and provide hands-on examples to reinforce your understanding.

## The Agent Base Class

The Agent base class is defined in the `agent.py` file within the AgentChat module. It provides the basic structure and interface that all other agent types build upon. Let's take a closer look at its structure:

```python
# Simplified version of the Agent base class

from typing import Any, Dict, List, Optional, Union

class Agent:
    def __init__(self, name: str):
        self.name = name

    def send(
        self,
        message: Union[Dict, str],
        recipient: "Agent",
        request_reply: Optional[bool] = None,
    ) -> None:
        pass

    def receive(
        self,
        message: Union[Dict, str],
        sender: "Agent",
        request_reply: Optional[bool] = None,
    ) -> None:
        pass

    def generate_reply(
        self,
        messages: Optional[List[Dict]] = None,
        sender: Optional["Agent"] = None,
        **kwargs: Any,
    ) -> Union[str, Dict, None]:
        pass
```

This simplified version shows the basic structure of the Agent class. The actual implementation includes additional methods and attributes, but these are the core components we'll focus on.

## Core Methods and Attributes

Let's examine the core methods and attributes of the Agent base class:

1. `__init__(self, name: str)`:
   - The constructor initializes the agent with a name.
   - The `name` attribute is used to identify the agent in multi-agent systems.

2. `send(self, message, recipient, request_reply=None)`:
   - This method is used to send a message to another agent.
   - `message` can be a string or a dictionary containing the message content.
   - `recipient` is the agent object that will receive the message.
   - `request_reply` is an optional boolean indicating whether a reply is expected.

3. `receive(self, message, sender, request_reply=None)`:
   - This method is called when an agent receives a message from another agent.
   - `message` is the received message (string or dictionary).
   - `sender` is the agent object that sent the message.
   - `request_reply` indicates whether the sender is expecting a reply.

4. `generate_reply(self, messages=None, sender=None, **kwargs)`:
   - This method generates a reply based on the received messages.
   - `messages` is an optional list of message dictionaries representing the conversation history.
   - `sender` is the agent that sent the last message.
   - Additional keyword arguments can be passed to customize the reply generation.

These methods provide the basic framework for agent communication and interaction. When creating custom agents, you'll often override these methods to implement specific behaviors.

## Creating Custom Agents

To create a custom agent, you'll typically subclass the Agent base class or one of its more specialized subclasses (like ConversableAgent). Here's a basic example of how to create a custom agent:

```python
from autogen import Agent

class CustomAgent(Agent):
    def __init__(self, name: str, expertise: str):
        super().__init__(name)
        self.expertise = expertise

    def generate_reply(self, messages=None, sender=None, **kwargs):
        if messages:
            last_message = messages[-1]["content"]
            return f"As an expert in {self.expertise}, I suggest: {last_message.upper()}"
        return None

    def receive(self, message, sender, request_reply=None):
        print(f"{self.name} received: {message}")
        if request_reply:
            return self.generate_reply([{"content": message}], sender)
```

This CustomAgent has an additional `expertise` attribute and overrides the `generate_reply` and `receive` methods to implement custom behavior.

## Project Structure

For this lesson, we'll use the following project structure:

```
autogen_tutorial/
├── lesson2_agent_base_class/
│   ├── custom_agent_example.py
│   ├── agent_interaction_example.py
│   ├── config/
│   │   └── oai_config.json
│   └── requirements.txt
└── README.md
```

## Hands-on Example

Let's create two example files to demonstrate the usage of custom agents and their interactions.

First, create `custom_agent_example.py`:

```python
# custom_agent_example.py

from autogen import Agent, ConversableAgent

class EchoAgent(Agent):
    def generate_reply(self, messages=None, sender=None, **kwargs):
        if messages:
            return f"Echo: {messages[-1]['content']}"
        return None

class CapitalizerAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)
        
    def generate_reply(self, messages=None, sender=None, **kwargs):
        if messages:
            return messages[-1]["content"].upper()
        return None

# Usage
echo_agent = EchoAgent("Echo")
cap_agent = CapitalizerAgent("Capitalizer")

# Test EchoAgent
reply = echo_agent.generate_reply([{"content": "Hello, World!"}])
print(reply)  # Output: Echo: Hello, World!

# Test CapitalizerAgent
reply = cap_agent.generate_reply([{"content": "make me uppercase"}])
print(reply)  # Output: MAKE ME UPPERCASE
```

Now, let's create `agent_interaction_example.py` to demonstrate how agents interact:

```python
# agent_interaction_example.py

from autogen import Agent, UserProxyAgent, ConversableAgent, config_list_from_json

# Load LLM config
config_list = config_list_from_json(env_or_file="config/oai_config.json")

class AnalyzerAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name, llm_config={"config_list": config_list})

    def generate_reply(self, messages=None, sender=None, **kwargs):
        if messages:
            last_message = messages[-1]["content"]
            analysis = f"Analysis of '{last_message}':\n"
            analysis += f"- Length: {len(last_message)} characters\n"
            analysis += f"- Words: {len(last_message.split())} words\n"
            analysis += f"- Uppercase: {sum(1 for c in last_message if c.isupper())}\n"
            analysis += f"- Lowercase: {sum(1 for c in last_message if c.islower())}\n"
            return analysis
        return None

# Create agents
user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=0
)

analyzer = AnalyzerAgent(name="Analyzer")

# Start the conversation
user_proxy.initiate_chat(
    analyzer,
    message="Analyze this sentence: The quick brown fox jumps over the lazy dog."
)
```

To run these examples, make sure you have the `requirements.txt` file in the `lesson2_agent_base_class/` directory:

```
pyautogen
```

And update the `config/oai_config.json` file with your OpenAI API configuration:

```json
[
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here"
    }
]
```

To run the examples, follow these steps:

1. Ensure your virtual environment is activated:
   ```
   source autogen_env/bin/activate  # On Windows, use `autogen_env\Scripts\activate`
   ```

2. Install the required packages (if not already installed):
   ```
   pip install -r requirements.txt
   ```

3. Run the scripts:
   ```
   python custom_agent_example.py
   python agent_interaction_example.py
   ```

These examples demonstrate how to create custom agents by subclassing the Agent and ConversableAgent classes, and how to set up interactions between agents.

## Exercise

Now that you've seen examples of custom agents and their interactions, try the following exercise:

1. Create a new agent called `SentimentAnalyzer` that inherits from `ConversableAgent`.
2. Implement the `generate_reply` method to perform a simple sentiment analysis on the input text. You can use a basic approach, such as counting positive and negative words.
3. Integrate the `SentimentAnalyzer` into the `agent_interaction_example.py` script, allowing the user to request sentiment analysis on their input.

Hint: You can use a predefined list of positive and negative words for a simple sentiment analysis approach.

## Summary and Next Steps

In this lesson, we've explored the Agent base class, its core methods and attributes, and how to create custom agents. We've seen practical examples of creating specialized agents and setting up interactions between them.

Key takeaways from this lesson include:
- Understanding the structure and purpose of the Agent base class
- Learning how to override core methods to create custom agent behaviors
- Exploring the interaction between different agent types

In the next lesson, we'll take a deep dive into the ConversableAgent class, which builds upon the Agent base class to provide more advanced conversational capabilities. We'll explore its additional methods and attributes, and learn how to create more sophisticated conversational agents.

Remember to experiment with the provided examples and try the exercise to reinforce your understanding of custom agent creation and interaction. Happy coding!


```

# agentchat\lesson-20-testing-debugging-autogen-agents.md

```
# Lesson 20: Testing and Debugging Autogen Agents

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Setting Up a Testing Environment](#setting-up-a-testing-environment)
4. [Unit Testing Autogen Agents](#unit-testing-autogen-agents)
5. [Integration Testing with Multiple Agents](#integration-testing-with-multiple-agents)
6. [Mocking External Services](#mocking-external-services)
7. [Debugging Techniques for Autogen Agents](#debugging-techniques-for-autogen-agents)
8. [Performance Testing and Optimization](#performance-testing-and-optimization)
9. [Continuous Integration for Autogen Projects](#continuous-integration-for-autogen-projects)
10. [Best Practices and Common Pitfalls](#best-practices-and-common-pitfalls)
11. [Conclusion](#conclusion)

## 1. Introduction

Testing and debugging are crucial aspects of developing robust and reliable Autogen agents. In this lesson, we'll explore various techniques and best practices for ensuring the quality and correctness of your Autogen-based applications. We'll cover unit testing, integration testing, mocking external services, debugging strategies, and performance optimization.

## 2. Project Structure

Before we dive into the details, let's look at a typical project structure for an Autogen application with a focus on testing:

```
autogen_project/
│
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── assistant_agent.py
│   │   ├── user_proxy_agent.py
│   │   └── custom_agent.py
│   ├── utils/
│   │   ├── __init__.py
│   │   └── helpers.py
│   └── main.py
│
├── tests/
│   ├── unit/
│   │   ├── __init__.py
│   │   ├── test_assistant_agent.py
│   │   ├── test_user_proxy_agent.py
│   │   └── test_custom_agent.py
│   ├── integration/
│   │   ├── __init__.py
│   │   └── test_agent_interactions.py
│   └── conftest.py
│
├── .env
├── requirements.txt
├── setup.py
└── README.md
```

This structure separates the source code (`src/`) from the tests (`tests/`), making it easy to organize and run tests independently.

## 3. Setting Up a Testing Environment

To begin testing your Autogen agents, you'll need to set up a proper testing environment. We'll use pytest as our testing framework.

1. Install pytest and other dependencies:

```bash
pip install pytest pytest-mock pytest-asyncio
```

2. Create a `conftest.py` file in your `tests/` directory to define fixtures:

```python
# tests/conftest.py
import pytest
from autogen import OpenAIWrapper

@pytest.fixture
def mock_openai_client(mocker):
    mock_client = mocker.Mock(spec=OpenAIWrapper)
    mock_client.create.return_value = mocker.Mock(choices=[mocker.Mock(message=mocker.Mock(content="Mocked response"))])
    return mock_client

@pytest.fixture
def test_config():
    return {
        "model": "gpt-3.5-turbo",
        "temperature": 0.7,
        "max_tokens": 150
    }
```

These fixtures will be available to all your test files, allowing you to easily mock the OpenAI client and provide a test configuration.

## 4. Unit Testing Autogen Agents

Unit tests focus on testing individual components in isolation. Let's create a unit test for an AssistantAgent:

```python
# tests/unit/test_assistant_agent.py
import pytest
from autogen import AssistantAgent

def test_assistant_agent_initialization(test_config):
    agent = AssistantAgent("TestAssistant", llm_config=test_config)
    assert agent.name == "TestAssistant"
    assert agent.llm_config == test_config

def test_assistant_agent_generate_reply(mock_openai_client, test_config):
    agent = AssistantAgent("TestAssistant", llm_config=test_config)
    agent.client = mock_openai_client

    reply = agent.generate_reply("Hello, can you help me?")
    assert reply == "Mocked response"
    mock_openai_client.create.assert_called_once()

@pytest.mark.asyncio
async def test_assistant_agent_a_generate_reply(mock_openai_client, test_config):
    agent = AssistantAgent("TestAssistant", llm_config=test_config)
    agent.client = mock_openai_client

    reply = await agent.a_generate_reply("Hello, can you help me?")
    assert reply == "Mocked response"
    mock_openai_client.create.assert_called_once()
```

These tests verify the initialization of the AssistantAgent and its ability to generate replies, both synchronously and asynchronously.

## 5. Integration Testing with Multiple Agents

Integration tests ensure that different components of your system work together correctly. Let's create an integration test for a conversation between an AssistantAgent and a UserProxyAgent:

```python
# tests/integration/test_agent_interactions.py
import pytest
from autogen import AssistantAgent, UserProxyAgent, ConversableAgent

@pytest.fixture
def assistant_agent(mock_openai_client, test_config):
    agent = AssistantAgent("Assistant", llm_config=test_config)
    agent.client = mock_openai_client
    return agent

@pytest.fixture
def user_proxy_agent():
    return UserProxyAgent("User", human_input_mode="NEVER")

def test_agent_conversation(assistant_agent, user_proxy_agent):
    user_proxy_agent.initiate_chat(
        assistant_agent,
        message="What's the capital of France?"
    )

    assert len(user_proxy_agent.chat_messages[assistant_agent]) > 1
    assert "Mocked response" in user_proxy_agent.last_message()["content"]

@pytest.mark.asyncio
async def test_agent_conversation_async(assistant_agent, user_proxy_agent):
    await user_proxy_agent.a_initiate_chat(
        assistant_agent,
        message="What's the capital of France?"
    )

    assert len(user_proxy_agent.chat_messages[assistant_agent]) > 1
    assert "Mocked response" in user_proxy_agent.last_message()["content"]
```

These tests verify that the agents can interact with each other correctly, both synchronously and asynchronously.

## 6. Mocking External Services

When testing Autogen agents, you often need to mock external services like APIs or databases. We've already seen how to mock the OpenAI client, but let's look at a more complex example involving a custom function:

```python
# src/agents/custom_agent.py
import requests
from autogen import ConversableAgent

class WeatherAgent(ConversableAgent):
    def __init__(self, name, api_key):
        super().__init__(name)
        self.api_key = api_key

    def get_weather(self, city):
        url = f"http://api.weatherapi.com/v1/current.json?key={self.api_key}&q={city}"
        response = requests.get(url)
        data = response.json()
        return f"The current temperature in {city} is {data['current']['temp_c']}°C"

# tests/unit/test_custom_agent.py
import pytest
from src.agents.custom_agent import WeatherAgent

def test_weather_agent(mocker):
    mock_response = mocker.Mock()
    mock_response.json.return_value = {
        "current": {
            "temp_c": 25
        }
    }
    mocker.patch('requests.get', return_value=mock_response)

    agent = WeatherAgent("WeatherBot", api_key="fake_key")
    result = agent.get_weather("London")

    assert result == "The current temperature in London is 25°C"
    requests.get.assert_called_once_with(
        "http://api.weatherapi.com/v1/current.json?key=fake_key&q=London"
    )
```

This test mocks the external weather API, allowing us to test the WeatherAgent without making actual API calls.

## 7. Debugging Techniques for Autogen Agents

Debugging Autogen agents can be challenging due to their conversational nature. Here are some techniques to help you debug effectively:

1. Use logging:
   Add logging statements to your agents to track their internal state and decision-making process.

```python
import logging

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class DebuggableAgent(ConversableAgent):
    def generate_reply(self, messages, sender):
        logger.debug(f"Generating reply for messages: {messages}")
        reply = super().generate_reply(messages, sender)
        logger.debug(f"Generated reply: {reply}")
        return reply
```

2. Implement a debug mode:
   Add a debug mode to your agents that provides more verbose output or allows for step-by-step execution.

```python
class DebuggableAgent(ConversableAgent):
    def __init__(self, name, debug_mode=False):
        super().__init__(name)
        self.debug_mode = debug_mode

    def generate_reply(self, messages, sender):
        if self.debug_mode:
            user_input = input("Press Enter to generate reply, or type 'q' to quit: ")
            if user_input.lower() == 'q':
                return "TERMINATE"
        return super().generate_reply(messages, sender)
```

3. Use breakpoints:
   Place breakpoints in your code to pause execution and inspect the agent's state at specific points.

4. Implement custom error handling:
   Add try-except blocks to catch and log specific errors that may occur during agent execution.

```python
class ErrorHandlingAgent(ConversableAgent):
    def generate_reply(self, messages, sender):
        try:
            return super().generate_reply(messages, sender)
        except Exception as e:
            logger.error(f"Error generating reply: {str(e)}")
            return "I encountered an error. Please try again."
```

## 8. Performance Testing and Optimization

To ensure your Autogen agents perform well under various conditions, consider implementing performance tests:

1. Response time testing:
   Measure the time it takes for agents to generate responses under different loads.

```python
import time
import statistics

def test_agent_response_time(agent, num_requests=100):
    response_times = []
    for _ in range(num_requests):
        start_time = time.time()
        agent.generate_reply("Test message")
        end_time = time.time()
        response_times.append(end_time - start_time)

    avg_time = statistics.mean(response_times)
    max_time = max(response_times)
    min_time = min(response_times)

    print(f"Average response time: {avg_time:.2f}s")
    print(f"Max response time: {max_time:.2f}s")
    print(f"Min response time: {min_time:.2f}s")
```

2. Memory usage monitoring:
   Track memory usage during long-running conversations or complex tasks.

```python
import psutil
import os

def monitor_memory_usage(func):
    def wrapper(*args, **kwargs):
        process = psutil.Process(os.getpid())
        mem_before = process.memory_info().rss
        result = func(*args, **kwargs)
        mem_after = process.memory_info().rss
        print(f"Memory usage: {(mem_after - mem_before) / 1024 / 1024:.2f} MB")
        return result
    return wrapper

@monitor_memory_usage
def run_complex_task(agent):
    # Perform a complex task with the agent
    pass
```

3. Concurrency testing:
   Test how well your agents perform when handling multiple conversations simultaneously.

```python
import asyncio

async def concurrent_conversations(agent, num_conversations):
    async def single_conversation(conversation_id):
        return await agent.a_generate_reply(f"Hello from conversation {conversation_id}")

    tasks = [single_conversation(i) for i in range(num_conversations)]
    results = await asyncio.gather(*tasks)
    return results

# Usage
results = asyncio.run(concurrent_conversations(agent, 10))
```

## 9. Continuous Integration for Autogen Projects

Setting up continuous integration (CI) for your Autogen project helps ensure that your tests are run automatically whenever changes are made to your codebase. Here's an example of a GitHub Actions workflow for running tests:

```yaml
# .github/workflows/tests.yml
name: Run Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Run tests
      env:
        OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
      run: |
        pytest tests/
```

This workflow will run your tests on every push and pull request, helping you catch issues early in the development process.

## 10. Best Practices and Common Pitfalls

Here are some best practices to follow when testing and debugging Autogen agents:

1. Write tests for both happy paths and edge cases.
2. Use meaningful names for your test functions and variables.
3. Keep your tests independent and isolated from each other.
4. Avoid hardcoding API keys or sensitive information in your tests.
5. Regularly update your mock data to reflect changes in external services.
6. Use parameterized tests to cover multiple scenarios efficiently.

Common pitfalls to avoid:

1. Relying too heavily on integration tests at the expense of unit tests.
2. Neglecting to test error handling and edge cases.
3. Using actual API calls in tests, which can be slow and unreliable.
4. Not properly mocking or stubbing external dependencies.
5. Ignoring performance considerations in your tests.

## 11. Conclusion

Testing and debugging Autogen agents requires a combination of traditional software testing techniques and specialized approaches for dealing with AI-powered conversational systems. By following the practices outlined in this lesson, you'll be better equipped to create robust, reliable, and high-performing Autogen applications.

Remember to:
- Write comprehensive unit and integration tests
- Mock external services and dependencies
- Implement effective debugging techniques
- Monitor and optimize performance
- Set up continuous integration for your project

As you continue to work with Autogen, you'll develop a deeper understanding of how to test and debug these complex systems effectively.


```

# agentchat\lesson-21-security-considerations.md

```
# Lesson 21: Security Considerations in AgentChat

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Handling Sensitive Information](#handling-sensitive-information)
   - [API Keys and Credentials](#api-keys-and-credentials)
   - [User Data](#user-data)
4. [Input Sanitization](#input-sanitization)
5. [Access Controls in Group Chats](#access-controls-in-group-chats)
6. [Secure Code Execution](#secure-code-execution)
7. [Rate Limiting and Quota Management](#rate-limiting-and-quota-management)
8. [Logging and Auditing](#logging-and-auditing)
9. [Secure Communication](#secure-communication)
10. [Regular Security Audits](#regular-security-audits)
11. [Conclusion](#conclusion)

## Introduction

Security is a critical aspect of any AI-powered application, especially when dealing with conversational agents that may handle sensitive information or execute code. In this lesson, we'll explore various security considerations for AgentChat implementations and discuss best practices to mitigate potential risks.

## Project Structure

Before we dive into the security considerations, let's look at a typical project structure for an AgentChat application:

```
agentchat_project/
│
├── .env                    # Environment variables (API keys, etc.)
├── requirements.txt        # Project dependencies
├── main.py                 # Main application entry point
│
├── agents/
│   ├── __init__.py
│   ├── base_agent.py       # Base agent class
│   ├── assistant_agent.py  # AI assistant agent
│   └── user_proxy_agent.py # User proxy agent
│
├── security/
│   ├── __init__.py
│   ├── input_sanitizer.py  # Input sanitization utilities
│   ├── access_control.py   # Access control mechanisms
│   └── rate_limiter.py     # Rate limiting implementation
│
├── utils/
│   ├── __init__.py
│   ├── config.py           # Configuration management
│   ├── logging.py          # Logging utilities
│   └── encryption.py       # Encryption utilities
│
├── tests/
│   ├── __init__.py
│   ├── test_agents.py
│   └── test_security.py
│
└── docs/
    └── security_guidelines.md  # Security documentation
```

This structure separates concerns and makes it easier to implement and maintain security measures throughout the application.

## Handling Sensitive Information

### API Keys and Credentials

One of the most critical security considerations is the proper handling of API keys and other credentials. These should never be hardcoded in your application.

Example of secure API key handling:

```python
# utils/config.py

import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

class Config:
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    DATABASE_URL = os.getenv("DATABASE_URL")

    @classmethod
    def get_api_key(cls):
        if not cls.OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY is not set in the environment variables")
        return cls.OPENAI_API_KEY
```

Usage in an agent:

```python
# agents/assistant_agent.py

from utils.config import Config

class AssistantAgent:
    def __init__(self):
        self.api_key = Config.get_api_key()
        # Initialize the agent with the API key
```

### User Data

When handling user data, always follow data protection regulations (e.g., GDPR, CCPA) and implement proper encryption for sensitive information.

Example of encrypting user data:

```python
# utils/encryption.py

from cryptography.fernet import Fernet

class Encryptor:
    def __init__(self, key):
        self.fernet = Fernet(key)

    def encrypt(self, data: str) -> bytes:
        return self.fernet.encrypt(data.encode())

    def decrypt(self, encrypted_data: bytes) -> str:
        return self.fernet.decrypt(encrypted_data).decode()

# Usage
encryptor = Encryptor(Config.ENCRYPTION_KEY)
encrypted_user_data = encryptor.encrypt("sensitive user information")
decrypted_user_data = encryptor.decrypt(encrypted_user_data)
```

## Input Sanitization

Always sanitize user inputs to prevent injection attacks and other security vulnerabilities.

Example of input sanitization:

```python
# security/input_sanitizer.py

import re

class InputSanitizer:
    @staticmethod
    def sanitize_input(input_string: str) -> str:
        # Remove any potential HTML tags
        sanitized = re.sub(r'<[^>]*?>', '', input_string)
        # Remove any potential script tags
        sanitized = re.sub(r'<script.*?>.*?</script>', '', sanitized, flags=re.DOTALL)
        # Escape special characters
        sanitized = re.sub(r'[&<>\'"]', lambda m: {'&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'}[m.group()], sanitized)
        return sanitized

# Usage
user_input = "<script>alert('XSS')</script>Hello, world!"
safe_input = InputSanitizer.sanitize_input(user_input)
print(safe_input)  # Output: Hello, world!
```

## Access Controls in Group Chats

Implement proper access controls to ensure that agents in a group chat can only access the information and perform actions they are authorized for.

Example of implementing access controls:

```python
# security/access_control.py

from enum import Enum, auto

class AccessLevel(Enum):
    READ = auto()
    WRITE = auto()
    EXECUTE = auto()

class AccessControl:
    def __init__(self):
        self.access_levels = {}

    def set_access(self, agent_id: str, level: AccessLevel):
        self.access_levels[agent_id] = level

    def check_access(self, agent_id: str, required_level: AccessLevel) -> bool:
        if agent_id not in self.access_levels:
            return False
        return self.access_levels[agent_id].value >= required_level.value

# Usage in a group chat
access_control = AccessControl()
access_control.set_access("assistant_agent", AccessLevel.READ)
access_control.set_access("user_proxy_agent", AccessLevel.WRITE)

def perform_action(agent_id: str, action_type: AccessLevel):
    if access_control.check_access(agent_id, action_type):
        print(f"Agent {agent_id} is authorized to perform {action_type.name} action")
    else:
        print(f"Agent {agent_id} is not authorized to perform {action_type.name} action")

perform_action("assistant_agent", AccessLevel.READ)  # Authorized
perform_action("assistant_agent", AccessLevel.WRITE)  # Not authorized
```

## Secure Code Execution

When allowing agents to execute code, use sandboxing techniques to isolate the execution environment and prevent potential security breaches.

Example of using Docker for secure code execution:

```python
# agents/user_proxy_agent.py

import docker

class UserProxyAgent:
    def __init__(self):
        self.docker_client = docker.from_env()

    def execute_code(self, code: str):
        container = self.docker_client.containers.run(
            "python:3.9-slim",
            f"python -c '{code}'",
            remove=True,
            detach=True,
            mem_limit="50m",
            pids_limit=50,
            network_disabled=True
        )
        return container.logs().decode('utf-8')

# Usage
user_proxy = UserProxyAgent()
result = user_proxy.execute_code("print('Hello from a sandboxed environment')")
print(result)
```

## Rate Limiting and Quota Management

Implement rate limiting to prevent abuse and ensure fair usage of resources.

Example of a simple rate limiter:

```python
# security/rate_limiter.py

import time
from collections import defaultdict

class RateLimiter:
    def __init__(self, limit: int, window: int):
        self.limit = limit
        self.window = window
        self.requests = defaultdict(list)

    def is_allowed(self, key: str) -> bool:
        now = time.time()
        self.requests[key] = [req for req in self.requests[key] if req > now - self.window]
        if len(self.requests[key]) < self.limit:
            self.requests[key].append(now)
            return True
        return False

# Usage
rate_limiter = RateLimiter(limit=5, window=60)  # 5 requests per minute

def make_api_request(agent_id: str):
    if rate_limiter.is_allowed(agent_id):
        print(f"Request allowed for agent {agent_id}")
    else:
        print(f"Rate limit exceeded for agent {agent_id}")

# Simulate requests
for _ in range(7):
    make_api_request("agent1")
```

## Logging and Auditing

Implement comprehensive logging to track agent activities and detect potential security issues.

Example of a logging decorator:

```python
# utils/logging.py

import logging
from functools import wraps

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def log_action(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        logger.info(f"Executing {func.__name__} with args: {args}, kwargs: {kwargs}")
        result = func(*args, **kwargs)
        logger.info(f"{func.__name__} completed. Result: {result}")
        return result
    return wrapper

# Usage
class AssistantAgent:
    @log_action
    def generate_response(self, prompt: str):
        # Generate response logic here
        return "Generated response"

assistant = AssistantAgent()
assistant.generate_response("Tell me a joke")
```

## Secure Communication

Ensure that all communication between agents and external services is encrypted using HTTPS.

Example of making secure API requests:

```python
# agents/assistant_agent.py

import requests
from utils.config import Config

class AssistantAgent:
    def __init__(self):
        self.api_key = Config.get_api_key()
        self.api_url = "https://api.openai.com/v1/chat/completions"

    def generate_response(self, prompt: str):
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        data = {
            "model": "gpt-3.5-turbo",
            "messages": [{"role": "user", "content": prompt}]
        }
        response = requests.post(self.api_url, headers=headers, json=data)
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
```

## Regular Security Audits

Regularly audit your codebase and dependencies for potential security vulnerabilities.

Example of using safety to check for vulnerabilities in dependencies:

```bash
# Add safety to your requirements.txt
echo "safety" >> requirements.txt

# Install safety
pip install safety

# Run a security audit
safety check
```

## Conclusion

Security in AgentChat applications is crucial to protect sensitive information, prevent unauthorized access, and ensure the integrity of the system. By implementing the security measures discussed in this lesson, you can significantly reduce the risk of security breaches and create a more robust and trustworthy AI-powered chat system.

Remember to stay updated on the latest security best practices and regularly review and update your security measures as new threats emerge and your application evolves.

```

# agentchat\lesson-22-integration-external-ai-services.md

```
# Lesson 22: Integration with External AI Services

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Setting Up External AI Services](#setting-up-external-ai-services)
4. [Integrating OpenAI](#integrating-openai)
5. [Integrating Google Cloud Vision API](#integrating-google-cloud-vision-api)
6. [Integrating Hugging Face Models](#integrating-hugging-face-models)
7. [Creating a Multi-Service Agent](#creating-a-multi-service-agent)
8. [Best Practices and Considerations](#best-practices-and-considerations)
9. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll explore how to integrate external AI services into your AutoGen agents. By leveraging various AI services, you can enhance your agents' capabilities and create more powerful and versatile applications. We'll cover integration with popular services like OpenAI, Google Cloud Vision API, and Hugging Face models.

## Project Structure

Before we dive into the integration details, let's look at a typical project structure for an AutoGen application that integrates multiple AI services:

```
autogen_external_ai/
│
├── config/
│   ├── __init__.py
│   └── api_keys.py
│
├── services/
│   ├── __init__.py
│   ├── openai_service.py
│   ├── google_vision_service.py
│   └── huggingface_service.py
│
├── agents/
│   ├── __init__.py
│   ├── multi_service_agent.py
│   └── specialized_agents.py
│
├── utils/
│   ├── __init__.py
│   └── helpers.py
│
├── main.py
├── requirements.txt
└── README.md
```

This structure organizes our code into separate modules for configuration, services, agents, and utilities. The `main.py` file will serve as the entry point for our application.

## Setting Up External AI Services

Before integrating external AI services, you need to set up accounts and obtain API keys for each service. Here's a general process:

1. Create an account on the AI service provider's platform.
2. Navigate to the API or developer section.
3. Generate an API key or access token.
4. Store the API key securely (we'll use environment variables).

Let's set up our `api_keys.py` file to manage our API keys:

```python
# config/api_keys.py

import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GOOGLE_CLOUD_API_KEY = os.getenv("GOOGLE_CLOUD_API_KEY")
HUGGINGFACE_API_KEY = os.getenv("HUGGINGFACE_API_KEY")
```

Make sure to create a `.env` file in your project root and add your API keys:

```
OPENAI_API_KEY=your_openai_api_key
GOOGLE_CLOUD_API_KEY=your_google_cloud_api_key
HUGGINGFACE_API_KEY=your_huggingface_api_key
```

## Integrating OpenAI

Let's start by integrating OpenAI's GPT models into our AutoGen application. We'll create a service class to handle OpenAI API calls:

```python
# services/openai_service.py

import openai
from config.api_keys import OPENAI_API_KEY

class OpenAIService:
    def __init__(self):
        openai.api_key = OPENAI_API_KEY

    def generate_text(self, prompt, max_tokens=100):
        try:
            response = openai.Completion.create(
                engine="text-davinci-002",
                prompt=prompt,
                max_tokens=max_tokens
            )
            return response.choices[0].text.strip()
        except Exception as e:
            print(f"Error in OpenAI API call: {e}")
            return None
```

Now, let's create an agent that uses this service:

```python
# agents/specialized_agents.py

from autogen import ConversableAgent
from services.openai_service import OpenAIService

class OpenAIAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)
        self.openai_service = OpenAIService()

    def generate_reply(self, messages, sender):
        last_message = messages[-1]['content']
        response = self.openai_service.generate_text(last_message)
        return response if response else "I couldn't generate a response."
```

## Integrating Google Cloud Vision API

Next, let's integrate the Google Cloud Vision API for image analysis:

```python
# services/google_vision_service.py

from google.cloud import vision
from config.api_keys import GOOGLE_CLOUD_API_KEY
import os

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = GOOGLE_CLOUD_API_KEY

class GoogleVisionService:
    def __init__(self):
        self.client = vision.ImageAnnotatorClient()

    def analyze_image(self, image_path):
        try:
            with open(image_path, "rb") as image_file:
                content = image_file.read()

            image = vision.Image(content=content)
            response = self.client.label_detection(image=image)
            labels = response.label_annotations

            return [label.description for label in labels]
        except Exception as e:
            print(f"Error in Google Vision API call: {e}")
            return None
```

Now, let's create an agent that uses this service:

```python
# agents/specialized_agents.py

from autogen import ConversableAgent
from services.google_vision_service import GoogleVisionService

class VisionAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)
        self.vision_service = GoogleVisionService()

    def analyze_image(self, image_path):
        labels = self.vision_service.analyze_image(image_path)
        if labels:
            return f"I see the following in the image: {', '.join(labels)}"
        else:
            return "I couldn't analyze the image."
```

## Integrating Hugging Face Models

Lastly, let's integrate Hugging Face models for various NLP tasks:

```python
# services/huggingface_service.py

from transformers import pipeline
from config.api_keys import HUGGINGFACE_API_KEY

class HuggingFaceService:
    def __init__(self):
        self.summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
        self.translator = pipeline("translation_en_to_fr", model="Helsinki-NLP/opus-mt-en-fr")

    def summarize_text(self, text):
        try:
            summary = self.summarizer(text, max_length=130, min_length=30, do_sample=False)
            return summary[0]['summary_text']
        except Exception as e:
            print(f"Error in Hugging Face summarization: {e}")
            return None

    def translate_text(self, text):
        try:
            translation = self.translator(text, max_length=40)
            return translation[0]['translation_text']
        except Exception as e:
            print(f"Error in Hugging Face translation: {e}")
            return None
```

Now, let's create an agent that uses this service:

```python
# agents/specialized_agents.py

from autogen import ConversableAgent
from services.huggingface_service import HuggingFaceService

class NLPAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)
        self.nlp_service = HuggingFaceService()

    def summarize(self, text):
        summary = self.nlp_service.summarize_text(text)
        return summary if summary else "I couldn't summarize the text."

    def translate(self, text):
        translation = self.nlp_service.translate_text(text)
        return translation if translation else "I couldn't translate the text."
```

## Creating a Multi-Service Agent

Now that we have integrated multiple AI services, let's create a multi-service agent that can leverage all of these capabilities:

```python
# agents/multi_service_agent.py

from autogen import ConversableAgent
from services.openai_service import OpenAIService
from services.google_vision_service import GoogleVisionService
from services.huggingface_service import HuggingFaceService

class MultiServiceAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)
        self.openai_service = OpenAIService()
        self.vision_service = GoogleVisionService()
        self.nlp_service = HuggingFaceService()

    def generate_reply(self, messages, sender):
        last_message = messages[-1]['content']
        
        if "analyze image" in last_message.lower():
            # Assume the image path is provided in the message
            image_path = last_message.split(":")[-1].strip()
            return self.analyze_image(image_path)
        elif "summarize" in last_message.lower():
            text = last_message.split("summarize:")[-1].strip()
            return self.summarize(text)
        elif "translate" in last_message.lower():
            text = last_message.split("translate:")[-1].strip()
            return self.translate(text)
        else:
            return self.generate_text(last_message)

    def generate_text(self, prompt):
        response = self.openai_service.generate_text(prompt)
        return response if response else "I couldn't generate a response."

    def analyze_image(self, image_path):
        labels = self.vision_service.analyze_image(image_path)
        if labels:
            return f"I see the following in the image: {', '.join(labels)}"
        else:
            return "I couldn't analyze the image."

    def summarize(self, text):
        summary = self.nlp_service.summarize_text(text)
        return summary if summary else "I couldn't summarize the text."

    def translate(self, text):
        translation = self.nlp_service.translate_text(text)
        return translation if translation else "I couldn't translate the text."
```

## Best Practices and Considerations

When integrating external AI services into your AutoGen agents, keep these best practices in mind:

1. **Error Handling**: Implement robust error handling for API calls to external services.
2. **Rate Limiting**: Be aware of and respect the rate limits of each service.
3. **Caching**: Implement caching mechanisms to reduce API calls and improve performance.
4. **Fallback Mechanisms**: Have fallback options in case a service is unavailable.
5. **Security**: Always keep API keys secure and never expose them in your code.
6. **Costs**: Be mindful of the costs associated with using external AI services.

## Conclusion

In this lesson, we've explored how to integrate external AI services into AutoGen agents. We've created a multi-service agent that can leverage the capabilities of OpenAI, Google Cloud Vision, and Hugging Face models. This approach allows you to create more powerful and versatile agents that can handle a wide range of tasks.

To use the MultiServiceAgent, you can create an instance and interact with it like this:

```python
# main.py

from agents.multi_service_agent import MultiServiceAgent

def main():
    agent = MultiServiceAgent("MultiServiceAgent")

    # Test text generation
    response = agent.generate_reply([{"content": "What is the capital of France?"}], None)
    print("Text Generation:", response)

    # Test image analysis
    response = agent.generate_reply([{"content": "analyze image: path/to/image.jpg"}], None)
    print("Image Analysis:", response)

    # Test summarization
    text_to_summarize = "Long text to summarize..."
    response = agent.generate_reply([{"content": f"summarize: {text_to_summarize}"}], None)
    print("Summarization:", response)

    # Test translation
    text_to_translate = "Hello, how are you?"
    response = agent.generate_reply([{"content": f"translate: {text_to_translate}"}], None)
    print("Translation:", response)

if __name__ == "__main__":
    main()
```

This integration of external AI services greatly expands the capabilities of your AutoGen agents, allowing them to perform a wide range of tasks from text generation to image analysis and language processing. As AI services continue to evolve, you can easily update and expand your agents' capabilities by integrating new services or upgrading existing ones.


```

# agentchat\lesson-23-advanced-use-cases.txt

```
# Lesson 23: Advanced Use Cases: Task Planning and Execution

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Task Planning with Autogen](#task-planning-with-autogen)
   3.1. [Using the Agent Builder](#using-the-agent-builder)
   3.2. [Task Decomposition](#task-decomposition)
4. [Task Execution](#task-execution)
   4.1. [Implementing Complex Workflows](#implementing-complex-workflows)
   4.2. [Coordinating Multiple Specialized Agents](#coordinating-multiple-specialized-agents)
5. [Advanced Techniques](#advanced-techniques)
   5.1. [Dynamic Agent Creation](#dynamic-agent-creation)
   5.2. [Adaptive Task Planning](#adaptive-task-planning)
6. [Case Study: Building a Research Assistant](#case-study-building-a-research-assistant)
7. [Best Practices and Considerations](#best-practices-and-considerations)
8. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll explore advanced use cases for task planning and execution using Autogen's AgentChat module. We'll learn how to implement complex workflows, coordinate multiple specialized agents, and create dynamic systems that can adapt to various tasks. This knowledge will enable you to build sophisticated AI-powered applications capable of handling intricate, multi-step processes.

## 2. Project Structure

Before we dive into the details, let's look at a typical project structure for an advanced Autogen application:

```
autogen_advanced_project/
│
├── main.py
├── config.json
├── requirements.txt
├── README.md
│
├── agents/
│   ├── __init__.py
│   ├── planner.py
│   ├── researcher.py
│   ├── writer.py
│   └── reviewer.py
│
├── tasks/
│   ├── __init__.py
│   ├── task_decomposition.py
│   └── workflow.py
│
├── utils/
│   ├── __init__.py
│   ├── agent_utils.py
│   └── data_processing.py
│
└── data/
    ├── research_papers/
    └── output/
```

This structure organizes our code into logical components, making it easier to manage and extend our application.

## 3. Task Planning with Autogen

### 3.1. Using the Agent Builder

Autogen provides an `AgentBuilder` class that allows us to dynamically create agents based on task requirements. Let's see how we can use it for task planning:

```python
# agents/planner.py
from autogen import AgentBuilder, UserProxyAgent

class TaskPlanner:
    def __init__(self, config):
        self.builder = AgentBuilder(config)
        self.user_proxy = UserProxyAgent("user")

    def create_plan(self, task):
        planner_agent = self.builder.create_agent(
            "TaskPlanner",
            system_message="You are an expert task planner. Break down complex tasks into manageable steps."
        )
        
        self.user_proxy.initiate_chat(planner_agent, message=f"Create a plan for the following task: {task}")
        plan = self.user_proxy.last_message()["content"]
        return plan
```

In this example, we create a `TaskPlanner` class that uses the `AgentBuilder` to dynamically create a planning agent. This agent can break down complex tasks into manageable steps.

### 3.2. Task Decomposition

Task decomposition is crucial for handling complex problems. Let's implement a task decomposition module:

```python
# tasks/task_decomposition.py
from autogen import AssistantAgent, UserProxyAgent

def decompose_task(task):
    decomposer = AssistantAgent("TaskDecomposer", system_message="You break down complex tasks into subtasks.")
    user_proxy = UserProxyAgent("user")
    
    user_proxy.initiate_chat(decomposer, message=f"Decompose the following task into subtasks: {task}")
    subtasks = user_proxy.last_message()["content"]
    return subtasks.split("\n")
```

This function uses an `AssistantAgent` to break down a complex task into subtasks, which can then be assigned to specialized agents.

## 4. Task Execution

### 4.1. Implementing Complex Workflows

To handle complex workflows, we can create a `Workflow` class that manages the execution of multiple subtasks:

```python
# tasks/workflow.py
from autogen import GroupChat, GroupChatManager

class Workflow:
    def __init__(self, agents):
        self.agents = agents
        self.group_chat = GroupChat(agents=agents, messages=[], max_round=50)
        self.manager = GroupChatManager(groupchat=self.group_chat, llm_config={"config_list": [{"model": "gpt-4"}]})

    def execute(self, task):
        subtasks = decompose_task(task)
        for subtask in subtasks:
            self.manager.initiate_chat(self.agents[0], message=subtask)
        
        result = self.group_chat.messages[-1]["content"]
        return result
```

This `Workflow` class uses a `GroupChat` and `GroupChatManager` to coordinate the execution of subtasks among multiple agents.

### 4.2. Coordinating Multiple Specialized Agents

Let's create some specialized agents for our workflow:

```python
# agents/researcher.py
from autogen import AssistantAgent

class ResearcherAgent(AssistantAgent):
    def __init__(self):
        super().__init__(
            name="Researcher",
            system_message="You are an expert researcher. Find and summarize relevant information.",
            llm_config={"config_list": [{"model": "gpt-4"}]}
        )

# agents/writer.py
class WriterAgent(AssistantAgent):
    def __init__(self):
        super().__init__(
            name="Writer",
            system_message="You are a skilled writer. Create well-structured content based on research.",
            llm_config={"config_list": [{"model": "gpt-4"}]}
        )

# agents/reviewer.py
class ReviewerAgent(AssistantAgent):
    def __init__(self):
        super().__init__(
            name="Reviewer",
            system_message="You are a detail-oriented reviewer. Check content for accuracy and clarity.",
            llm_config={"config_list": [{"model": "gpt-4"}]}
        )
```

Now we can use these specialized agents in our workflow:

```python
# main.py
from agents.researcher import ResearcherAgent
from agents.writer import WriterAgent
from agents.reviewer import ReviewerAgent
from tasks.workflow import Workflow

def main():
    agents = [ResearcherAgent(), WriterAgent(), ReviewerAgent()]
    workflow = Workflow(agents)
    
    task = "Create a comprehensive report on the impact of artificial intelligence on job markets."
    result = workflow.execute(task)
    print(result)

if __name__ == "__main__":
    main()
```

## 5. Advanced Techniques

### 5.1. Dynamic Agent Creation

We can extend our system to dynamically create agents based on task requirements:

```python
# utils/agent_utils.py
from autogen import AgentBuilder

def create_dynamic_agent(task):
    builder = AgentBuilder()
    task_analysis = builder.create_agent(
        "TaskAnalyzer",
        system_message="Analyze tasks and determine required agent capabilities."
    )
    
    capabilities = task_analysis.get_task_capabilities(task)
    
    dynamic_agent = builder.create_agent(
        f"DynamicAgent_{task[:10]}",
        system_message=f"You are an agent with the following capabilities: {capabilities}"
    )
    
    return dynamic_agent
```

This function analyzes a task and creates a custom agent with the required capabilities.

### 5.2. Adaptive Task Planning

We can implement an adaptive task planning system that adjusts the workflow based on intermediate results:

```python
# tasks/workflow.py
class AdaptiveWorkflow(Workflow):
    def execute(self, task):
        plan = self.create_initial_plan(task)
        for step in plan:
            result = self.execute_step(step)
            if self.needs_adjustment(result):
                plan = self.adjust_plan(plan, result)
        return self.compile_results()

    def needs_adjustment(self, result):
        # Implement logic to determine if the plan needs adjustment
        pass

    def adjust_plan(self, plan, result):
        # Implement logic to adjust the plan based on intermediate results
        pass
```

This `AdaptiveWorkflow` class extends our basic `Workflow` to include adaptive planning capabilities.

## 6. Case Study: Building a Research Assistant

Let's put everything together to build a research assistant that can gather information, write reports, and review content:

```python
# main.py
from autogen import UserProxyAgent
from agents.researcher import ResearcherAgent
from agents.writer import WriterAgent
from agents.reviewer import ReviewerAgent
from tasks.workflow import AdaptiveWorkflow
from utils.agent_utils import create_dynamic_agent

def main():
    user_proxy = UserProxyAgent("User")
    researcher = ResearcherAgent()
    writer = WriterAgent()
    reviewer = ReviewerAgent()
    
    workflow = AdaptiveWorkflow([researcher, writer, reviewer])
    
    task = "Research the latest advancements in quantum computing and prepare a report."
    
    # Create a dynamic agent if needed
    if "quantum computing" in task.lower():
        quantum_expert = create_dynamic_agent("quantum computing expert")
        workflow.agents.append(quantum_expert)
    
    result = workflow.execute(task)
    
    user_proxy.initiate_chat(reviewer, message=f"Review this report:\n\n{result}")
    final_report = user_proxy.last_message()["content"]
    
    print(final_report)

if __name__ == "__main__":
    main()
```

This example demonstrates how we can combine various advanced techniques to create a sophisticated research assistant that can adapt to specific tasks and leverage specialized knowledge when needed.

## 7. Best Practices and Considerations

When implementing advanced task planning and execution systems with Autogen, keep the following best practices in mind:

1. **Modularity**: Design your agents and tasks as modular components that can be easily combined and reconfigured.

2. **Error Handling**: Implement robust error handling to deal with unexpected situations or agent failures.

3. **Monitoring and Logging**: Add comprehensive logging to track the progress of complex workflows and aid in debugging.

4. **Scalability**: Design your system to scale horizontally, allowing for the addition of more agents or parallel task execution.

5. **Security**: Implement proper security measures, especially when dealing with sensitive data or executing code.

6. **Ethical Considerations**: Ensure your AI system adheres to ethical guidelines and respects user privacy.

7. **Performance Optimization**: Monitor and optimize the performance of your system, particularly for long-running tasks.

## 8. Conclusion

In this lesson, we've explored advanced use cases for task planning and execution using Autogen. We've learned how to implement complex workflows, coordinate multiple specialized agents, and create dynamic, adaptive systems. By leveraging these techniques, you can build sophisticated AI-powered applications capable of handling a wide range of complex tasks.

Remember that the field of AI and agent-based systems is rapidly evolving. Stay updated with the latest developments in Autogen and related technologies to continually improve your task planning and execution capabilities.


```

# agentchat\lesson-24-scaling-agentchat-for-production.txt

```
# Lesson 24: Scaling AgentChat for Production

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Handling High-Volume Conversations](#handling-high-volume-conversations)
   - [Asynchronous Processing](#asynchronous-processing)
   - [Message Queues](#message-queues)
4. [Implementing Load Balancing](#implementing-load-balancing)
   - [Horizontal Scaling](#horizontal-scaling)
   - [Load Balancer Configuration](#load-balancer-configuration)
5. [Optimizing Database Performance](#optimizing-database-performance)
   - [Database Indexing](#database-indexing)
   - [Caching Strategies](#caching-strategies)
6. [Monitoring and Logging](#monitoring-and-logging)
   - [Centralized Logging](#centralized-logging)
   - [Performance Metrics](#performance-metrics)
7. [Error Handling and Resilience](#error-handling-and-resilience)
   - [Graceful Degradation](#graceful-degradation)
   - [Circuit Breakers](#circuit-breakers)
8. [Security Considerations](#security-considerations)
   - [API Authentication](#api-authentication)
   - [Data Encryption](#data-encryption)
9. [Continuous Integration and Deployment](#continuous-integration-and-deployment)
10. [Conclusion](#conclusion)

## 1. Introduction

As AutoGen's AgentChat system grows in popularity and usage, it becomes crucial to scale the application for production environments. This lesson focuses on the key aspects of scaling AgentChat to handle high-volume conversations, implement load balancing, optimize performance, and ensure robust monitoring and logging.

## 2. Project Structure

Before we dive into the details, let's look at a typical project structure for a production-ready AgentChat application:

```
agentchat_production/
│
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── assistant_agent.py
│   │   ├── user_proxy_agent.py
│   │   └── custom_agents.py
│   ├── config/
│   │   ├── __init__.py
│   │   ├── settings.py
│   │   └── logging_config.py
│   ├── database/
│   │   ├── __init__.py
│   │   ├── models.py
│   │   └── db_utils.py
│   ├── api/
│   │   ├── __init__.py
│   │   ├── routes.py
│   │   └── middleware.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── message_queue.py
│   │   └── cache_service.py
│   └── utils/
│       ├── __init__.py
│       └── helpers.py
├── tests/
│   ├── unit/
│   │   └── test_agents.py
│   └── integration/
│       └── test_api.py
├── docker/
│   ├── Dockerfile
│   └── docker-compose.yml
├── scripts/
│   ├── run_tests.sh
│   └── deploy.sh
├── requirements.txt
├── README.md
└── .env.example
```

This structure separates concerns and makes it easier to maintain and scale the application. Now, let's explore each aspect of scaling AgentChat for production.

## 3. Handling High-Volume Conversations

### Asynchronous Processing

To handle high-volume conversations, it's crucial to implement asynchronous processing. This allows the system to manage multiple conversations concurrently without blocking.

Example implementation using FastAPI and asyncio:

```python
# src/api/routes.py

from fastapi import FastAPI, BackgroundTasks
from src.agents import AssistantAgent, UserProxyAgent
from src.services.message_queue import enqueue_message

app = FastAPI()

@app.post("/chat")
async def chat(message: str, background_tasks: BackgroundTasks):
    background_tasks.add_task(process_message, message)
    return {"status": "Message received and processing"}

async def process_message(message: str):
    assistant = AssistantAgent("AI_Assistant")
    user_proxy = UserProxyAgent("User")
    
    response = await user_proxy.a_initiate_chat(assistant, message=message)
    await enqueue_message(response)
```

### Message Queues

Implement a message queue system to handle the influx of messages and distribute the workload across multiple worker processes.

Example using Redis as a message queue:

```python
# src/services/message_queue.py

import aioredis
from src.config.settings import REDIS_URL

redis = aioredis.from_url(REDIS_URL)

async def enqueue_message(message: str):
    await redis.lpush("message_queue", message)

async def dequeue_message():
    return await redis.rpop("message_queue")

# Worker process
async def process_messages():
    while True:
        message = await dequeue_message()
        if message:
            # Process the message
            await process_chat(message)
```

## 4. Implementing Load Balancing

### Horizontal Scaling

To handle increased load, implement horizontal scaling by adding more instances of your application.

Example Docker Compose configuration for scaling:

```yaml
# docker/docker-compose.yml

version: '3'
services:
  agentchat:
    build: .
    image: agentchat:latest
    deploy:
      replicas: 3
    environment:
      - DATABASE_URL=postgresql://user:password@db:5432/agentchat
  
  db:
    image: postgres:13
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
      - POSTGRES_DB=agentchat

  redis:
    image: redis:6

  nginx:
    image: nginx:latest
    ports:
      - "80:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
    depends_on:
      - agentchat
```

### Load Balancer Configuration

Configure a load balancer to distribute incoming requests across multiple instances.

Example Nginx configuration:

```nginx
# docker/nginx.conf

events {
    worker_connections 1024;
}

http {
    upstream agentchat {
        server agentchat:8000;
        server agentchat:8001;
        server agentchat:8002;
    }

    server {
        listen 80;
        
        location / {
            proxy_pass http://agentchat;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }
    }
}
```

## 5. Optimizing Database Performance

### Database Indexing

Optimize database queries by adding appropriate indexes.

Example using SQLAlchemy:

```python
# src/database/models.py

from sqlalchemy import Column, Integer, String, Index
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class Conversation(Base):
    __tablename__ = 'conversations'

    id = Column(Integer, primary_key=True)
    user_id = Column(String, nullable=False)
    content = Column(String, nullable=False)
    timestamp = Column(Integer, nullable=False)

    # Add an index on user_id and timestamp for faster queries
    __table_args__ = (Index('idx_user_timestamp', user_id, timestamp),)
```

### Caching Strategies

Implement caching to reduce database load and improve response times.

Example using Redis for caching:

```python
# src/services/cache_service.py

import aioredis
import json
from src.config.settings import REDIS_URL

redis = aioredis.from_url(REDIS_URL)

async def cache_conversation(user_id: str, conversation: dict):
    await redis.setex(f"conversation:{user_id}", 3600, json.dumps(conversation))

async def get_cached_conversation(user_id: str):
    cached = await redis.get(f"conversation:{user_id}")
    if cached:
        return json.loads(cached)
    return None

# Usage in API routes
@app.get("/conversation/{user_id}")
async def get_conversation(user_id: str):
    cached = await get_cached_conversation(user_id)
    if cached:
        return cached
    
    # If not in cache, fetch from database
    conversation = await fetch_conversation_from_db(user_id)
    await cache_conversation(user_id, conversation)
    return conversation
```

## 6. Monitoring and Logging

### Centralized Logging

Implement centralized logging to aggregate logs from all instances.

Example using Python's logging module with ELK stack:

```python
# src/config/logging_config.py

import logging
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
from src.config.settings import ELK_URL

class ElasticsearchHandler(logging.Handler):
    def __init__(self, es_url):
        super().__init__()
        self.es = Elasticsearch(es_url)

    def emit(self, record):
        doc = {
            'message': self.format(record),
            'level': record.levelname,
            'timestamp': record.created,
        }
        self.es.index(index="agentchat-logs", document=doc)

def setup_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    # Add Elasticsearch handler
    es_handler = ElasticsearchHandler(ELK_URL)
    logger.addHandler(es_handler)

    # Add console handler for local debugging
    console_handler = logging.StreamHandler()
    logger.addHandler(console_handler)

# Usage in application
from src.config.logging_config import setup_logging

setup_logging()
logging.info("AgentChat application started")
```

### Performance Metrics

Collect and monitor performance metrics to identify bottlenecks and optimize system performance.

Example using Prometheus and Grafana:

```python
# src/api/middleware.py

from prometheus_client import Counter, Histogram
from fastapi import Request

REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP Requests')
REQUEST_LATENCY = Histogram('http_request_duration_seconds', 'HTTP Request Latency')

@app.middleware("http")
async def metrics_middleware(request: Request, call_next):
    REQUEST_COUNT.inc()
    with REQUEST_LATENCY.time():
        response = await call_next(request)
    return response

# Expose metrics endpoint for Prometheus
from prometheus_client import generate_latest

@app.get("/metrics")
async def metrics():
    return generate_latest()
```

## 7. Error Handling and Resilience

### Graceful Degradation

Implement graceful degradation to maintain partial functionality during system failures.

Example of graceful degradation:

```python
# src/agents/assistant_agent.py

from src.services.llm_service import get_llm_response
from src.services.fallback_service import get_fallback_response

class AssistantAgent:
    async def generate_response(self, message: str):
        try:
            return await get_llm_response(message)
        except Exception as e:
            logging.error(f"LLM service error: {e}")
            return await get_fallback_response(message)

# Fallback service
async def get_fallback_response(message: str):
    # Implement a simpler, rule-based response system
    if "hello" in message.lower():
        return "Hello! I'm having trouble with my advanced capabilities right now, but I can still assist you with basic queries."
    # Add more fallback rules as needed
    return "I apologize, but I'm experiencing some issues right now. Please try again later or contact support if this persists."
```

### Circuit Breakers

Implement circuit breakers to prevent cascading failures in distributed systems.

Example using the `circuitbreaker` library:

```python
# src/services/llm_service.py

from circuitbreaker import circuit

@circuit(failure_threshold=5, recovery_timeout=30)
async def get_llm_response(message: str):
    # Actual LLM API call
    response = await llm_api_call(message)
    return response

# Usage in AssistantAgent
class AssistantAgent:
    async def generate_response(self, message: str):
        try:
            return await get_llm_response(message)
        except Exception as e:
            logging.error(f"LLM service error: {e}")
            return await get_fallback_response(message)
```

## 8. Security Considerations

### API Authentication

Implement secure API authentication to protect your endpoints.

Example using FastAPI and JWT:

```python
# src/api/routes.py

from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from src.config.settings import SECRET_KEY, ALGORITHM

app = FastAPI()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(status_code=401, detail="Could not validate credentials")
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    return username

@app.post("/chat")
async def chat(message: str, current_user: str = Depends(get_current_user)):
    # Process the chat message
    return {"message": "Processed", "user": current_user}
```

### Data Encryption

Ensure all sensitive data is encrypted, both in transit and at rest.

Example of encrypting sensitive data:

```python
# src/utils/encryption.py

from cryptography.fernet import Fernet
from src.config.settings import ENCRYPTION_KEY

fernet = Fernet(ENCRYPTION_KEY)

def encrypt_data(data: str) -> str:
    return fernet.encrypt(data.encode()).decode()

def decrypt_data(encrypted_data: str) -> str:
    return fernet.decrypt(encrypted_data.encode()).decode()

# Usage in database operations
from src.utils.encryption import encrypt_data, decrypt_data

class Conversation(Base):
    __tablename__ = 'conversations'

    id = Column(Integer, primary_key=True)
    user_id = Column(String, nullable=False)
    content = Column(String, nullable=False)

    def set_content(self, content: str):
        self.content = encrypt_data(content)

    def get_content(self) -> str:
        return decrypt_data(self.content)
```

## 9. Continuous Integration and Deployment

Implement a CI/CD pipeline to automate testing and deployment processes.

Example GitHub Actions workflow:

```yaml
# .github/workflows/ci-cd.yml

name: CI/CD

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements
        - name: Run tests
      run: |
        pytest tests/

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main' && github.event_name == 'push'
    steps:
    - uses: actions/checkout@v2
    - name: Set up Docker Buildx
      uses: docker/setup-buildx-action@v1
    - name: Login to DockerHub
      uses: docker/login-action@v1
      with:
        username: ${{ secrets.DOCKERHUB_USERNAME }}
        password: ${{ secrets.DOCKERHUB_TOKEN }}
    - name: Build and push
      uses: docker/build-push-action@v2
      with:
        context: .
        push: true
        tags: yourusername/agentchat:latest
    - name: Deploy to production
      run: |
        # Add your deployment script here, e.g., using kubectl for Kubernetes deployment
        ./scripts/deploy.sh
```

This CI/CD pipeline does the following:
1. Runs tests on every push and pull request.
2. If tests pass and it's a push to the main branch, it builds a Docker image and pushes it to DockerHub.
3. Finally, it deploys the new version to the production environment.

Make sure to create a `deploy.sh` script in the `scripts/` directory to handle the actual deployment process. This script might use `kubectl` to update a Kubernetes deployment, or any other deployment method you prefer.

Example `deploy.sh`:

```bash
#!/bin/bash
# scripts/deploy.sh

# Assuming you're using Kubernetes
kubectl set image deployment/agentchat agentchat=yourusername/agentchat:latest
kubectl rollout status deployment/agentchat
```

Remember to make this script executable:

```bash
chmod +x scripts/deploy.sh
```

## 10. Conclusion

Scaling AgentChat for production involves several critical aspects:

1. **Handling High-Volume Conversations**: By implementing asynchronous processing and message queues, you can manage a large number of concurrent conversations efficiently.

2. **Load Balancing**: Horizontal scaling and proper load balancer configuration ensure that incoming requests are distributed evenly across multiple instances of your application.

3. **Database Optimization**: Implementing database indexing and caching strategies significantly improves the performance of data retrieval and storage operations.

4. **Monitoring and Logging**: Centralized logging and performance metrics collection are crucial for maintaining visibility into your system's health and performance.

5. **Error Handling and Resilience**: Graceful degradation and circuit breakers help maintain system stability even when components fail.

6. **Security**: Proper API authentication and data encryption protect your system and user data from unauthorized access and breaches.

7. **Continuous Integration and Deployment**: A robust CI/CD pipeline automates testing and deployment, ensuring that new changes are thoroughly tested before being deployed to production.

By addressing these aspects, you can create a scalable, resilient, and secure production environment for AgentChat. Remember that scaling is an ongoing process – continuously monitor your system's performance, gather user feedback, and iterate on your architecture to meet evolving demands.

As you scale AgentChat, consider the following best practices:

- Regularly review and update your scaling strategies based on actual usage patterns and growth.
- Implement A/B testing capabilities to safely roll out new features or optimizations.
- Set up alerts and on-call rotations to quickly respond to any production issues.
- Regularly conduct security audits and penetration testing to identify and address vulnerabilities.
- Document your architecture, deployment processes, and troubleshooting procedures for your team.

By following these guidelines and continuously improving your system, you'll be well-equipped to handle the challenges of running AgentChat at scale in a production environment.
```

# agentchat\lesson-3-conversable-agent.md

```
# Lesson 3: Deep Dive into ConversableAgent

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding ConversableAgent](#understanding-conversable-agent)
4. [Key Components of ConversableAgent](#key-components-of-conversable-agent)
5. [Initialization and Configuration](#initialization-and-configuration)
6. [Message Handling](#message-handling)
7. [Reply Generation](#reply-generation)
8. [Function and Tool Execution](#function-and-tool-execution)
9. [Human Input Handling](#human-input-handling)
10. [Code Execution](#code-execution)
11. [Advanced Features](#advanced-features)
12. [Best Practices and Tips](#best-practices-and-tips)
13. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll take a deep dive into the `ConversableAgent` class, which is a fundamental component of the Autogen library. The `ConversableAgent` serves as a base class for various types of agents that can engage in conversations, execute functions, and perform tasks. Understanding this class is crucial for creating sophisticated AI agents and building complex conversational systems.

## 2. Project Structure

Before we delve into the details, let's look at a typical project structure when working with `ConversableAgent`:

```
autogen_project/
│
├── agents/
│   ├── __init__.py
│   ├── custom_assistant.py
│   └── custom_user_proxy.py
│
├── configs/
│   └── agent_config.json
│
├── functions/
│   ├── __init__.py
│   └── custom_functions.py
│
├── utils/
│   └── helpers.py
│
├── main.py
├── requirements.txt
└── README.md
```

This structure organizes our code into logical components:
- `agents/`: Contains our custom agent implementations
- `configs/`: Stores configuration files for our agents
- `functions/`: Houses custom functions that our agents can use
- `utils/`: Contains helper functions and utilities
- `main.py`: The entry point of our application

## 3. Understanding ConversableAgent

The `ConversableAgent` class is designed to be a versatile base for creating agents that can engage in conversations, execute functions, and perform various tasks. It provides a rich set of features that allow for complex interactions and decision-making processes.

Key characteristics of `ConversableAgent`:
- Can send and receive messages
- Supports function calling and execution
- Handles human input when needed
- Manages conversation history
- Provides hooks for customizing behavior

Let's look at a basic example of how to create a `ConversableAgent`:

```python
from autogen import ConversableAgent

agent = ConversableAgent(
    name="MyAgent",
    system_message="You are a helpful AI assistant.",
    human_input_mode="NEVER",
    llm_config={
        "config_list": [{"model": "gpt-4", "api_key": "your-api-key"}],
    }
)
```

In this example, we create a simple agent named "MyAgent" with a system message and configuration for the language model.

## 4. Key Components of ConversableAgent

The `ConversableAgent` class consists of several key components:

1. **Messaging System**: Handles sending and receiving messages between agents.
2. **Function Map**: Stores registered functions that the agent can execute.
3. **LLM Config**: Configuration for the language model used by the agent.
4. **Reply Functions**: A list of functions used to generate replies.
5. **Code Execution Config**: Configuration for executing code (if enabled).
6. **Human Input Handling**: Manages when and how to request human input.

Let's explore each of these components in more detail.

## 5. Initialization and Configuration

When initializing a `ConversableAgent`, you can customize various parameters to suit your needs. Here's a more detailed example:

```python
from autogen import ConversableAgent

def custom_function(x, y):
    return x + y

agent = ConversableAgent(
    name="CustomAgent",
    system_message="You are a specialized AI assistant for mathematical operations.",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=5,
    code_execution_config={"work_dir": "tmp", "use_docker": False},
    function_map={"add_numbers": custom_function},
    llm_config={
        "config_list": [{"model": "gpt-4", "api_key": "your-api-key"}],
        "temperature": 0.7,
    }
)
```

In this example, we:
- Set a custom name and system message
- Configure the human input mode to only request input on termination
- Limit the number of consecutive auto-replies
- Set up a code execution environment
- Register a custom function
- Configure the language model with specific parameters

## 6. Message Handling

The `ConversableAgent` class provides methods for sending and receiving messages. Here's how you can use them:

```python
# Sending a message
agent.send(
    message="Hello, can you help me with a math problem?",
    recipient=another_agent,
    request_reply=True
)

# Receiving a message
agent.receive(
    message="Sure, what's the problem?",
    sender=another_agent
)
```

The `send` method allows you to specify the message content, the recipient agent, and whether you want to request a reply. The `receive` method handles incoming messages, updating the conversation history and potentially triggering a reply.

## 7. Reply Generation

One of the most important aspects of `ConversableAgent` is its ability to generate replies. This is handled through a series of reply functions that are called in order. Here's a simplified version of how reply generation works:

```python
def generate_reply(self, messages, sender):
    for reply_func, trigger in self._reply_func_list:
        if self._match_trigger(trigger, sender):
            reply = reply_func(self, messages, sender)
            if reply is not None:
                return reply
    return None
```

You can register custom reply functions to customize the agent's behavior:

```python
def custom_reply_func(agent, messages, sender):
    # Custom logic here
    return "This is a custom reply."

agent.register_reply(
    trigger=[AnotherAgentClass],
    reply_func=custom_reply_func
)
```

This allows you to create specialized agents that can handle different types of messages or respond differently to various senders.

## 8. Function and Tool Execution

`ConversableAgent` supports function calling and tool execution, which allows agents to perform actions or retrieve information. Here's how you can register and use functions:

```python
def get_weather(location):
    # Simulated weather API call
    return f"The weather in {location} is sunny."

agent.register_function(
    function_map={
        "get_weather": get_weather
    }
)
```

When the agent encounters a function call in a message, it will execute the function and return the result:

```python
message = {
    "content": "What's the weather like?",
    "function_call": {
        "name": "get_weather",
        "arguments": '{"location": "New York"}'
    }
}

result = agent.generate_function_call_reply(messages=[message])
print(result)  # ('The weather in New York is sunny.', True)
```

## 9. Human Input Handling

`ConversableAgent` can be configured to handle human input in different ways using the `human_input_mode` parameter:

- `"ALWAYS"`: Always prompt for human input
- `"NEVER"`: Never prompt for human input
- `"TERMINATE"`: Only prompt for human input when terminating the conversation

Here's an example of how human input is handled:

```python
class CustomAgent(ConversableAgent):
    def get_human_input(self, prompt):
        return input(f"{prompt} (type 'exit' to end conversation): ")

agent = CustomAgent(
    name="HumanInteractiveAgent",
    human_input_mode="ALWAYS"
)

# This will prompt for human input before generating a reply
agent.generate_reply(messages=[{"content": "Hello, how are you?"}], sender=another_agent)
```

## 10. Code Execution

`ConversableAgent` can be configured to execute code, which is particularly useful for agents that need to perform computations or interact with external systems. Here's how you can set up code execution:

```python
agent = ConversableAgent(
    name="CodeExecutor",
    code_execution_config={
        "work_dir": "./tmp",
        "use_docker": False,
        "timeout": 60,
    }
)

# Example of executing code
code = """
def fibonacci(n):
    if n <= 1:
        return n
    else:
        return fibonacci(n-1) + fibonacci(n-2)

print(fibonacci(10))
"""

result = agent.execute_code_blocks([(None, code)])
print(result)  # (0, '55\n', None)
```

The `execute_code_blocks` method returns a tuple containing the exit code, output, and any error messages.

## 11. Advanced Features

### 11.1 Nested Chats

`ConversableAgent` supports nested chats, allowing for more complex conversation structures:

```python
def nested_chat_func(chat_queue, recipient, messages, sender, config):
    # Implement nested chat logic here
    pass

agent.register_nested_chats(
    chat_queue=[
        {"sender": agent, "recipient": another_agent, "message": "Hello!"},
        {"sender": another_agent, "recipient": agent, "message": "Hi there!"},
    ],
    reply_func_from_nested_chats=nested_chat_func
)
```

### 11.2 Hooks

You can use hooks to modify the agent's behavior at specific points in the conversation flow:

```python
def pre_reply_hook(agent, messages, sender):
    # Modify messages or perform actions before generating a reply
    return messages

agent.register_hook(
    hookable_method="process_all_messages_before_reply",
    hook=pre_reply_hook
)
```

## 12. Best Practices and Tips

1. **Modular Design**: Create specialized agents for different tasks and compose them to build complex systems.

2. **Error Handling**: Implement robust error handling in custom functions and reply generators.

3. **Testing**: Thoroughly test your agents with various inputs and scenarios.

4. **Documentation**: Maintain clear documentation for your custom agents and functions.

5. **Security**: Be cautious when allowing agents to execute code, especially in production environments.

6. **Performance**: Monitor and optimize the performance of your agents, especially when dealing with large conversations or complex tasks.

7. **Conversation Management**: Implement proper conversation management to ensure smooth interactions between multiple agents.

## 13. Conclusion

The `ConversableAgent` class in Autogen provides a powerful foundation for building sophisticated AI agents. By understanding its components and capabilities, you can create agents that can engage in complex conversations, execute functions, and perform a wide range of tasks.

In this lesson, we've covered the key aspects of `ConversableAgent`, including initialization, message handling, reply generation, function execution, and advanced features. With this knowledge, you're well-equipped to start building your own custom agents and creating intricate multi-agent systems.

Remember to experiment with different configurations and customizations to find the best setup for your specific use case. Happy coding!

```

# agentchat\lesson-4-specialized-agents.md

```
# Lesson 4: Specialized Agents - AssistantAgent and UserProxyAgent

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [AssistantAgent](#assistantagent)
   - [Overview](#assistantagent-overview)
   - [Key Features](#assistantagent-key-features)
   - [Implementation](#assistantagent-implementation)
4. [UserProxyAgent](#userproxyagent)
   - [Overview](#userproxyagent-overview)
   - [Key Features](#userproxyagent-key-features)
   - [Implementation](#userproxyagent-implementation)
5. [Differences and Use Cases](#differences-and-use-cases)
6. [Customizing Specialized Agents](#customizing-specialized-agents)
7. [Practical Examples](#practical-examples)
8. [Exercises](#exercises)
9. [Summary](#summary)

## 1. Introduction

Welcome to Lesson 4 of our Autogen AgentChat series. In this lesson, we'll explore two specialized agent types: AssistantAgent and UserProxyAgent. These agents build upon the base Agent class we discussed in the previous lesson and provide specific functionalities for different roles in conversational AI systems.

## 2. Project Structure

Before we dive in, let's set up our project structure for this lesson:

```
autogen_tutorial/
├── lesson4_specialized_agents/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── custom_assistant.py
│   │   └── custom_user_proxy.py
│   ├── examples/
│   │   ├── __init__.py
│   │   ├── assistant_example.py
│   │   └── user_proxy_example.py
│   ├── exercises/
│   │   ├── __init__.py
│   │   └── exercise_1.py
│   ├── main.py
│   └── requirements.txt
└── README.md
```

Create these directories and files. We'll use them throughout the lesson to implement and test our specialized agents.

## 3. AssistantAgent

### AssistantAgent Overview

The AssistantAgent is designed to act as an AI assistant in conversations. It's primarily used to generate responses based on given prompts or questions.

### AssistantAgent Key Features

1. Customizable system message
2. Integration with language models (e.g., GPT-3.5, GPT-4)
3. Ability to generate human-like responses
4. Optional code execution capabilities

### AssistantAgent Implementation

Let's implement a custom AssistantAgent:

```python
# agents/custom_assistant.py

from autogen import AssistantAgent
from typing import Dict, Union

class CustomAssistantAgent(AssistantAgent):
    def __init__(self, name: str, system_message: str, llm_config: Dict[str, Union[str, int, float]]):
        super().__init__(name, system_message, llm_config=llm_config)
        self.conversation_history = []

    def generate_response(self, message: str) -> str:
        # In a real scenario, this would use the LLM. For this example, we'll simulate it.
        response = f"As an AI assistant named {self.name}, I respond: {message.upper()}"
        self.conversation_history.append({"role": "user", "content": message})
        self.conversation_history.append({"role": "assistant", "content": response})
        return response

    def get_conversation_history(self) -> list:
        return self.conversation_history
```

This custom AssistantAgent extends the base AssistantAgent with a conversation history feature and a simulated response generation method.

## 4. UserProxyAgent

### UserProxyAgent Overview

The UserProxyAgent acts as an interface between the AI system and a human user. It can handle user inputs, execute code, and manage the flow of conversation.

### UserProxyAgent Key Features

1. Human input handling
2. Code execution capabilities
3. Customizable auto-reply settings
4. Ability to terminate conversations based on specific conditions

### UserProxyAgent Implementation

Let's create a custom UserProxyAgent:

```python
# agents/custom_user_proxy.py

from autogen import UserProxyAgent
from typing import Dict, Union, List

class CustomUserProxyAgent(UserProxyAgent):
    def __init__(self, name: str, human_input_mode: str, max_consecutive_auto_reply: int = 2):
        super().__init__(name, human_input_mode=human_input_mode, max_consecutive_auto_reply=max_consecutive_auto_reply)
        self.query_history = []

    def get_human_input(self, prompt: str) -> str:
        # In a real scenario, this would get input from a human. Here, we'll simulate it.
        simulated_input = f"Simulated human input for: {prompt}"
        self.query_history.append({"prompt": prompt, "response": simulated_input})
        return simulated_input

    def execute_code(self, code: str) -> str:
        # Simulate code execution
        result = f"Executed code: {code}\nResult: Success"
        return result

    def get_query_history(self) -> List[Dict[str, str]]:
        return self.query_history
```

This custom UserProxyAgent extends the base UserProxyAgent with a query history feature and simulated methods for human input and code execution.

## 5. Differences and Use Cases

| Feature | AssistantAgent | UserProxyAgent |
|---------|----------------|----------------|
| Primary Role | Generate AI responses | Interface with human users |
| Input Handling | Processes messages from other agents | Can receive direct human input |
| Code Execution | Optional | Built-in capability |
| Auto-reply | Always auto-replies | Configurable auto-reply settings |
| Use Cases | AI chatbots, knowledge-based assistants | Human-in-the-loop systems, interactive coding environments |

## 6. Customizing Specialized Agents

To customize these specialized agents further, you can:

1. Override specific methods to change behavior
2. Add new methods for additional functionality
3. Modify the initialization process to include new parameters

Example of adding a new method to AssistantAgent:

```python
# agents/custom_assistant.py

class CustomAssistantAgent(AssistantAgent):
    # ... (previous code)

    def summarize_conversation(self) -> str:
        summary = "Conversation Summary:\n"
        for entry in self.conversation_history:
            summary += f"{entry['role'].capitalize()}: {entry['content'][:50]}...\n"
        return summary
```

## 7. Practical Examples

Let's create a simple scenario where an AssistantAgent and a UserProxyAgent interact:

```python
# examples/assistant_user_interaction.py

from agents.custom_assistant import CustomAssistantAgent
from agents.custom_user_proxy import CustomUserProxyAgent

def run_conversation():
    assistant = CustomAssistantAgent(
        name="AI_Assistant",
        system_message="You are a helpful AI assistant.",
        llm_config={"model": "gpt-3.5-turbo", "temperature": 0.7}
    )

    user_proxy = CustomUserProxyAgent(
        name="Human_User",
        human_input_mode="ALWAYS",
        max_consecutive_auto_reply=2
    )

    # Simulate a conversation
    user_message = "Can you help me understand how neural networks work?"
    print(f"Human: {user_message}")
    
    assistant_response = assistant.generate_response(user_message)
    print(f"AI Assistant: {assistant_response}")

    user_input = user_proxy.get_human_input("Do you have any follow-up questions?")
    print(f"Human: {user_input}")

    assistant_response = assistant.generate_response(user_input)
    print(f"AI Assistant: {assistant_response}")

    # Display conversation summary
    print("\nAssistant's Conversation Summary:")
    print(assistant.summarize_conversation())

    print("\nUser's Query History:")
    for query in user_proxy.get_query_history():
        print(f"Prompt: {query['prompt']}")
        print(f"Response: {query['response']}")
        print()

if __name__ == "__main__":
    run_conversation()
```

This example demonstrates how the AssistantAgent and UserProxyAgent can be used together to create an interactive conversation system.

## 8. Exercises

To reinforce your understanding of specialized agents, complete the following exercise:

```python
# exercises/exercise_1.py

from autogen import AssistantAgent, UserProxyAgent
from typing import List, Dict

class CodeAssistant(AssistantAgent):
    def __init__(self, name: str):
        super().__init__(name, system_message="You are a Python coding expert.")
        # TODO: Initialize any additional attributes

    def generate_code(self, task: str) -> str:
        # TODO: Implement a method to generate Python code based on the given task
        pass

    def explain_code(self, code: str) -> str:
        # TODO: Implement a method to explain the given code
        pass

class CodeTester(UserProxyAgent):
    def __init__(self, name: str):
        super().__init__(name, human_input_mode="NEVER")
        # TODO: Initialize any additional attributes

    def test_code(self, code: str) -> Dict[str, Union[bool, str]]:
        # TODO: Implement a method to test the given code and return the result
        pass

    def provide_feedback(self, test_result: Dict[str, Union[bool, str]]) -> str:
        # TODO: Implement a method to provide feedback based on the test result
        pass

# TODO: Create a main function that demonstrates the interaction between CodeAssistant and CodeTester
```

Exercise: Complete the `CodeAssistant` and `CodeTester` classes by implementing the required methods. Create a main function that demonstrates how these specialized agents can work together in a coding task scenario.

## 9. Summary

In this lesson, we've explored two specialized agent types in the Autogen framework: AssistantAgent and UserProxyAgent. We've learned about their key features, implementation details, and how to customize them for specific use cases.

Key takeaways:
1. AssistantAgent is designed for generating AI responses in conversations.
2. UserProxyAgent serves as an interface between the AI system and human users.
3. Both agent types can be customized and extended to fit specific requirements.
4. The choice between AssistantAgent and UserProxyAgent depends on the role needed in the conversation system.

In the next lesson, we'll dive into group chats and explore how multiple agents can collaborate in more complex conversational scenarios.


```

# agentchat\lesson-5-group-chats-and-collaboration.md

```
# Lesson 5: Group Chats and Collaboration

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding GroupChat](#understanding-groupchat)
   3.1 [GroupChat Initialization](#groupchat-initialization)
   3.2 [Key Attributes and Methods](#key-attributes-and-methods)
4. [GroupChatManager](#groupchatmanager)
   4.1 [Initializing GroupChatManager](#initializing-groupchatmanager)
   4.2 [Running a Group Chat](#running-a-group-chat)
5. [Speaker Selection Methods](#speaker-selection-methods)
6. [Advanced Features](#advanced-features)
   6.1 [Message Transformations](#message-transformations)
   6.2 [Resuming Conversations](#resuming-conversations)
7. [Practical Example: Multi-Agent Problem Solving](#practical-example-multi-agent-problem-solving)
8. [Best Practices and Considerations](#best-practices-and-considerations)
9. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll explore the powerful group chat and collaboration features of Autogen. We'll focus on the `GroupChat` and `GroupChatManager` classes, which enable multi-agent conversations and complex problem-solving scenarios. By the end of this lesson, you'll be able to create and manage group chats with multiple AI agents, control the flow of conversation, and implement sophisticated collaboration patterns.

## 2. Project Structure

Before we dive into the details, let's look at a typical project structure for an Autogen application that utilizes group chats:

```
autogen_group_chat_project/
│
├── agents/
│   ├── __init__.py
│   ├── custom_agent.py
│   └── specialized_agent.py
│
├── group_chats/
│   ├── __init__.py
│   ├── problem_solving_chat.py
│   └── brainstorming_chat.py
│
├── utils/
│   ├── __init__.py
│   └── message_utils.py
│
├── config/
│   └── config.json
│
├── main.py
├── requirements.txt
└── README.md
```

This structure organizes our code into logical components:
- `agents/`: Contains custom agent implementations.
- `group_chats/`: Holds different group chat configurations and implementations.
- `utils/`: Utility functions and helpers.
- `config/`: Configuration files for LLM settings, etc.
- `main.py`: The entry point of our application.

## 3. Understanding GroupChat

The `GroupChat` class is the core component for managing multi-agent conversations. It handles the logistics of message passing, speaker selection, and conversation flow.

### 3.1 GroupChat Initialization

Let's look at how to initialize a `GroupChat`:

```python
from autogen import GroupChat, AssistantAgent, UserProxyAgent

# Create agents
assistant = AssistantAgent("AI_Assistant", llm_config={"config_list": [{"model": "gpt-4"}]})
user_proxy = UserProxyAgent("User", code_execution_config={"work_dir": "coding"})
expert = AssistantAgent("Expert", llm_config={"config_list": [{"model": "gpt-4"}]})

# Initialize GroupChat
groupchat = GroupChat(
    agents=[user_proxy, assistant, expert],
    messages=[],
    max_round=10,
    speaker_selection_method="auto",
    allow_repeat_speaker=True
)
```

In this example, we create three agents: a user proxy, an AI assistant, and an expert. We then initialize a `GroupChat` with these agents, setting a maximum of 10 rounds and using the "auto" speaker selection method.

### 3.2 Key Attributes and Methods

The `GroupChat` class has several important attributes and methods:

- `agents`: List of participating agents.
- `messages`: List of messages in the group chat.
- `max_round`: Maximum number of conversation rounds.
- `speaker_selection_method`: Method for selecting the next speaker.
- `select_speaker`: Method to choose the next speaker.
- `append`: Method to add a message to the chat history.

## 4. GroupChatManager

The `GroupChatManager` is a special agent that manages the group chat. It's responsible for running the conversation and coordinating between agents.

### 4.1 Initializing GroupChatManager

Here's how to create a `GroupChatManager`:

```python
from autogen import GroupChatManager

# Initialize GroupChatManager
manager = GroupChatManager(
    groupchat=groupchat,
    name="Manager",
    human_input_mode="NEVER",
    system_message="You are managing a group chat."
)
```

### 4.2 Running a Group Chat

To start a group chat, we use the `initiate_chat` method of the `GroupChatManager`:

```python
user_proxy.initiate_chat(
    manager,
    message="Let's solve a complex math problem as a team."
)
```

This will start the group chat, with the user proxy initiating the conversation.

## 5. Speaker Selection Methods

Autogen supports several methods for selecting the next speaker in a group chat:

1. "auto": The next speaker is selected automatically by the LLM.
2. "manual": The next speaker is selected manually by user input.
3. "random": The next speaker is selected randomly.
4. "round_robin": The next speaker is selected in a round-robin fashion.

You can also implement a custom speaker selection function:

```python
def custom_speaker_selection(last_speaker: Agent, groupchat: GroupChat) -> Union[Agent, str, None]:
    # Your custom logic here
    return next_speaker

groupchat = GroupChat(
    agents=[user_proxy, assistant, expert],
    speaker_selection_method=custom_speaker_selection
)
```

## 6. Advanced Features

### 6.1 Message Transformations

Autogen allows you to apply transformations to messages before they are processed. This can be useful for tasks like truncating long messages or filtering sensitive information.

```python
from autogen.agentchat.contrib.capabilities import TransformMessages
from autogen.agentchat.contrib.capabilities.transforms import MessageHistoryLimiter

# Create a message transformation
message_limiter = MessageHistoryLimiter(max_messages=5)

# Apply the transformation to the GroupChatManager
transform_messages = TransformMessages(transforms=[message_limiter])
transform_messages.add_to_agent(manager)
```

### 6.2 Resuming Conversations

GroupChatManager provides methods to resume a previous conversation:

```python
# Save conversation state
conversation_state = manager.messages_to_string(groupchat.messages)

# ... Later, to resume the conversation
last_speaker, last_message = manager.resume(
    conversation_state,
    remove_termination_string="TERMINATE",
)

# Continue the conversation
user_proxy.send(
    "Let's continue our discussion.",
    manager
)
```

## 7. Practical Example: Multi-Agent Problem Solving

Let's put everything together in a practical example of multi-agent problem solving. We'll create a group chat to solve a complex task that requires different areas of expertise.

```python
# agents/custom_agent.py
from autogen import AssistantAgent

class MathExpert(AssistantAgent):
    def __init__(self, name):
        super().__init__(
            name=name,
            system_message="You are a mathematics expert. Solve complex math problems step by step.",
            llm_config={"config_list": [{"model": "gpt-4"}]}
        )

class ProgrammingExpert(AssistantAgent):
    def __init__(self, name):
        super().__init__(
            name=name,
            system_message="You are a programming expert. Implement solutions in Python with clear explanations.",
            llm_config={"config_list": [{"model": "gpt-4"}]}
        )

# group_chats/problem_solving_chat.py
from autogen import GroupChat, GroupChatManager, UserProxyAgent
from agents.custom_agent import MathExpert, ProgrammingExpert

def create_problem_solving_chat():
    user_proxy = UserProxyAgent("User", code_execution_config={"work_dir": "coding"})
    math_expert = MathExpert("MathExpert")
    programming_expert = ProgrammingExpert("ProgrammingExpert")
    
    groupchat = GroupChat(
        agents=[user_proxy, math_expert, programming_expert],
        messages=[],
        max_round=20,
        speaker_selection_method="auto"
    )
    
    manager = GroupChatManager(groupchat=groupchat, name="Manager")
    return user_proxy, manager

# main.py
from group_chats.problem_solving_chat import create_problem_solving_chat

def main():
    user_proxy, manager = create_problem_solving_chat()
    
    user_proxy.initiate_chat(
        manager,
        message="We need to create a Python function that calculates the nth Fibonacci number using dynamic programming and analyzes its time complexity. Can you help?"
    )

if __name__ == "__main__":
    main()
```

In this example, we've created a group chat with a user proxy, a math expert, and a programming expert. The group is tasked with creating and analyzing a Fibonacci function. The agents will collaborate, with the math expert providing the mathematical insights and the programming expert implementing the solution.

## 8. Best Practices and Considerations

When working with group chats in Autogen, keep these best practices in mind:

1. **Agent Roles**: Clearly define the role and expertise of each agent in the group chat.
2. **Conversation Flow**: Choose an appropriate speaker selection method based on your use case.
3. **Message Handling**: Implement message transformations to manage conversation history and content.
4. **Error Handling**: Implement proper error handling, especially when dealing with code execution in group chats.
5. **Scalability**: Be mindful of the number of agents and conversation rounds to manage computational resources.
6. **Testing**: Thoroughly test your group chat setups with various scenarios to ensure robust performance.

## 9. Conclusion

In this lesson, we've explored the powerful group chat and collaboration features of Autogen. We've learned how to:

- Initialize and configure `GroupChat` and `GroupChatManager`
- Implement custom agents for specialized tasks
- Use different speaker selection methods
- Apply advanced features like message transformations and conversation resumption
- Create a practical multi-agent problem-solving scenario

Group chats in Autogen open up exciting possibilities for complex problem-solving, brainstorming, and collaborative AI applications. By leveraging these features, you can create sophisticated multi-agent systems that tackle a wide range of tasks and challenges.

In the next lesson, we'll dive deeper into advanced topics such as fine-tuning agent behaviors, optimizing performance, and integrating Autogen with external services and APIs.

```

# agentchat\lesson-6-human-proxy-agent.md

```
# Lesson 6: Human Interaction: HumanProxyAgent

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding HumanProxyAgent](#understanding-humanproxyagent)
4. [Implementing Human-in-the-Loop Systems](#implementing-human-in-the-loop-systems)
5. [Balancing Automation and Human Input](#balancing-automation-and-human-input)
6. [Practical Examples](#practical-examples)
7. [Exercise](#exercise)
8. [Summary](#summary)

## 1. Introduction

In this lesson, we'll dive deep into the HumanProxyAgent, a crucial component of the Autogen framework that allows for human interaction within AI-driven conversations. We'll explore how to implement human-in-the-loop systems, balance automation with human input, and create more robust and flexible AI applications.

The HumanProxyAgent is defined in the `human_proxy_agent.py` file within the Autogen library. This agent type is designed to represent a human user in the conversation, allowing for real-time human input and interaction with other AI agents.

## 2. Project Structure

Before we begin, let's set up our project structure for this lesson:

```
autogen_tutorial/
├── lesson6_human_proxy_agent/
│   ├── basic_human_interaction.py
│   ├── advanced_human_interaction.py
│   ├── hybrid_workflow.py
│   ├── custom_human_proxy.py
│   └── requirements.txt
├── data/
│   └── sample_tasks.json
└── README.md
```

Make sure to install the required dependencies:

```bash
pip install -r lesson6_human_proxy_agent/requirements.txt
```

## 3. Understanding HumanProxyAgent

The HumanProxyAgent is a subclass of the UserProxyAgent, which itself is a subclass of the ConversableAgent. It's designed to simulate or facilitate human interaction within an agent-based conversation system.

Key features of the HumanProxyAgent include:

1. Human input handling
2. Code execution capabilities
3. Flexible configuration options

Let's examine the basic structure of the HumanProxyAgent:

```python
# basic_human_interaction.py

from autogen import AssistantAgent, HumanProxyAgent

# Create an AI assistant
assistant = AssistantAgent(
    name="AI_Assistant",
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7,
    }
)

# Create a HumanProxyAgent
human = HumanProxyAgent(
    name="Human",
    human_input_mode="ALWAYS",
    max_consecutive_auto_reply=1,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={"work_dir": "coding"}
)

# Start a conversation
human.initiate_chat(assistant, message="Hello, can you help me with a Python problem?")
```

In this example, we create a HumanProxyAgent that always prompts for human input (`human_input_mode="ALWAYS"`), limits consecutive auto-replies to 1, and can execute code in a specified working directory.

## 4. Implementing Human-in-the-Loop Systems

Human-in-the-loop systems combine the strengths of AI with human expertise and decision-making. The HumanProxyAgent facilitates this by allowing seamless integration of human input into AI-driven workflows.

Let's implement a more advanced example that demonstrates a human-in-the-loop system:

```python
# advanced_human_interaction.py

import autogen

# Configure the AI assistant
assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7,
    }
)

# Configure the HumanProxyAgent
human = autogen.HumanProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=3,
    is_termination_msg=lambda x: "FINAL ANSWER:" in x.get("content", "").upper(),
    code_execution_config={
        "work_dir": "coding",
        "use_docker": False,
    }
)

# Define the task
task = """
1. Generate a Python function to calculate the Fibonacci sequence.
2. Implement error handling for invalid inputs.
3. Write unit tests for the function.
4. Ask for human review and approval before finalizing.
"""

# Start the conversation
human.initiate_chat(
    assistant,
    message=f"Let's work on this programming task together: {task}"
)

# The conversation will continue until the human sends a message containing "FINAL ANSWER:"
```

In this example, the HumanProxyAgent is configured to allow up to 3 consecutive auto-replies from the AI assistant before prompting for human input. The conversation continues until the human sends a message containing "FINAL ANSWER:", indicating that the task is complete.

## 5. Balancing Automation and Human Input

One of the key challenges in human-in-the-loop systems is finding the right balance between automation and human input. The HumanProxyAgent provides several configuration options to help achieve this balance:

1. `human_input_mode`: Determines when to ask for human input
   - "ALWAYS": Always ask for human input
   - "NEVER": Never ask for human input
   - "TERMINATE": Only ask for human input when a termination message is received

2. `max_consecutive_auto_reply`: Limits the number of consecutive automated responses

3. `is_termination_msg`: A function that determines if a message should terminate the conversation

Let's create a hybrid workflow that demonstrates this balance:

```python
# hybrid_workflow.py

import autogen

def is_complex_task(message):
    # Define criteria for complex tasks that require human intervention
    complex_keywords = ["complex", "difficult", "advanced", "expert"]
    return any(keyword in message.get("content", "").lower() for keyword in complex_keywords)

# Configure the AI assistant
assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7,
    }
)

# Configure the HumanProxyAgent with dynamic human input
human = autogen.HumanProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=5,
    is_termination_msg=lambda x: is_complex_task(x) or "HUMAN_INTERVENTION_REQUIRED" in x.get("content", "").upper(),
    code_execution_config={
        "work_dir": "coding",
        "use_docker": False,
    }
)

# Define a list of tasks
tasks = [
    "Generate a Python function to calculate the sum of even numbers in a list.",
    "Create a complex algorithm to optimize database queries for a large-scale system.",
    "Write a simple 'Hello, World!' program in Python.",
    "Develop an advanced machine learning model for predictive maintenance.",
]

# Process tasks
for task in tasks:
    print(f"\nProcessing task: {task}")
    human.initiate_chat(
        assistant,
        message=f"Please help me with the following task: {task}"
    )
    print("Task completed. Moving to the next task.")

print("All tasks processed.")
```

In this hybrid workflow, the system automatically handles simple tasks while requesting human intervention for complex ones. The `is_complex_task` function determines when human input is required based on the content of the message.

## 6. Practical Examples

Now, let's look at a more practical example where we create a custom HumanProxyAgent for a specific use case:

```python
# custom_human_proxy.py

import autogen
import json

class DataAnalystHumanProxy(autogen.HumanProxyAgent):
    def __init__(self, name, data_source, **kwargs):
        super().__init__(name, **kwargs)
        self.data_source = data_source

    def get_human_input(self, prompt):
        print(f"\n{prompt}")
        print("Options:")
        print("1. Provide input")
        print("2. Run data analysis")
        print("3. Terminate conversation")
        choice = input("Enter your choice (1-3): ")

        if choice == '1':
            return input("Enter your input: ")
        elif choice == '2':
            return self.run_data_analysis()
        elif choice == '3':
            return "TERMINATE"
        else:
            return "Invalid choice. Please try again."

    def run_data_analysis(self):
        print(f"Running data analysis on {self.data_source}")
        # Simulating data analysis
        with open(self.data_source, 'r') as f:
            data = json.load(f)
        
        total_tasks = len(data['tasks'])
        completed_tasks = sum(1 for task in data['tasks'] if task['status'] == 'completed')
        completion_rate = (completed_tasks / total_tasks) * 100

        analysis_result = f"Data Analysis Result:\n"
        analysis_result += f"Total tasks: {total_tasks}\n"
        analysis_result += f"Completed tasks: {completed_tasks}\n"
        analysis_result += f"Completion rate: {completion_rate:.2f}%"

        return analysis_result

# Configure the AI assistant
assistant = autogen.AssistantAgent(
    name="DataAnalysisAssistant",
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7,
    }
)

# Configure the custom HumanProxyAgent
human_analyst = DataAnalystHumanProxy(
    name="DataAnalyst",
    data_source="data/sample_tasks.json",
    human_input_mode="ALWAYS",
    max_consecutive_auto_reply=2,
    code_execution_config={"work_dir": "analysis"}
)

# Start the conversation
human_analyst.initiate_chat(
    assistant,
    message="Let's analyze our task completion data and generate a report."
)
```

In this example, we've created a custom `DataAnalystHumanProxy` that can interact with a data source and perform basic data analysis. This demonstrates how the HumanProxyAgent can be extended to fit specific use cases and workflows.

## 7. Exercise

Now it's your turn to practice! Create a HumanProxyAgent-based system for a customer support scenario. The system should:

1. Handle basic customer inquiries automatically
2. Escalate complex issues to a human representative
3. Allow the human representative to take control of the conversation when necessary
4. Provide a summary of each customer interaction

Use the concepts and techniques we've covered in this lesson to implement this system.

## 8. Summary

In this lesson, we've explored the HumanProxyAgent and its role in creating human-in-the-loop systems with Autogen. We've covered:

1. The basic structure and features of the HumanProxyAgent
2. Implementing human-in-the-loop systems for various scenarios
3. Balancing automation and human input in AI-driven workflows
4. Creating custom HumanProxyAgent classes for specific use cases

The HumanProxyAgent is a powerful tool for creating more flexible, robust, and human-centered AI applications. By effectively combining human expertise with AI capabilities, you can build systems that leverage the strengths of both humans and machines.

In the next lesson, we'll dive into the contrib folder of the AgentChat module, exploring additional agents and utilities that can further enhance your Autogen-based applications.

```

# agentchat\lesson-7-contributed-agents-and-utilities.md

```
# Lesson 7: Contributed Agents and Utilities (Part 1)

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Overview of the contrib folder](#overview-of-the-contrib-folder)
4. [Agent Builder (agent_builder.py)](#agent-builder-agent_builderpy)
5. [GPT Assistant Agent (gpt_assistant_agent.py)](#gpt-assistant-agent-gpt_assistant_agentpy)
6. [Image Utilities (img_utils.py)](#image-utilities-img_utilspy)
7. [Hands-on Project: Multi-Agent Image Analysis System](#hands-on-project-multi-agent-image-analysis-system)
8. [Exercises](#exercises)
9. [Summary and Next Steps](#summary-and-next-steps)

## 1. Introduction

Welcome to Lesson 7 of our Autogen AgentChat series! In this lesson, we'll dive deep into the `contrib` folder of the AgentChat module, focusing on three key components: the agent builder, GPT assistant agent, and image utilities. These tools provide powerful extensions to the core AgentChat functionality, allowing you to create more flexible and capable agent systems.

By the end of this lesson, you'll be able to:
- Understand the structure and purpose of the `contrib` folder
- Use the agent builder to dynamically create and configure agents
- Implement a GPT assistant agent for advanced language tasks
- Handle images in agent conversations using image utilities
- Create a multi-agent system that combines these components

Let's get started by setting up our project structure for this lesson.

## 2. Project Structure

Before we dive into the code, let's set up our project structure. Create a new directory for this lesson and organize it as follows:

```
autogen_tutorial/
├── lesson7_contrib_agents/
│   ├── agent_builder_example.py
│   ├── gpt_assistant_example.py
│   ├── image_handling_example.py
│   ├── multi_agent_image_analysis.py
│   ├── images/
│   │   ├── sample_image1.jpg
│   │   └── sample_image2.jpg
│   ├── requirements.txt
│   └── README.md
└── README.md
```

Create these files and directories. We'll populate them as we progress through the lesson.

In the `requirements.txt` file, add the following dependencies:

```
pyautogen
Pillow
requests
```

Now, let's install these dependencies:

```bash
cd autogen_tutorial/lesson7_contrib_agents
pip install -r requirements.txt
```

## 3. Overview of the contrib folder

The `contrib` folder in the AgentChat module contains various extensions and specialized agents that enhance the core functionality of Autogen. Here's the structure of the `contrib` folder:

```
autogen/agentchat/contrib/
├── __init__.py
├── agent_builder.py
├── gpt_assistant_agent.py
├── img_utils.py
├── llava_agent.py
├── math_user_proxy_agent.py
├── multimodal_conversable_agent.py
├── retrieve_assistant_agent.py
├── retrieve_user_proxy_agent.py
├── web_surfer.py
├── agent_eval/
├── capabilities/
└── graph_rag/
```

In this lesson, we'll focus on `agent_builder.py`, `gpt_assistant_agent.py`, and `img_utils.py`. These components provide powerful tools for creating dynamic agent systems, integrating advanced language models, and handling image-based tasks.

## 4. Agent Builder (agent_builder.py)

The agent builder provides functionality to dynamically create and configure agents. This is particularly useful when you need to create agents with varying capabilities or configurations based on runtime conditions.

Key concepts:
- Dynamic agent creation
- Configuration management
- Agent customization

Let's create an example using the agent builder. Open `agent_builder_example.py` and add the following code:

```python
# agent_builder_example.py

import autogen
from autogen.agentchat.contrib.agent_builder import AgentBuilder

def main():
    # Initialize the agent builder
    builder = AgentBuilder()

    # Create a custom assistant agent
    custom_assistant = builder.create_agent(
        name="CustomAssistant",
        system_message="You are a helpful assistant specialized in Python programming.",
        llm_config={"model": "gpt-4", "temperature": 0.7}
    )

    # Create a user proxy agent
    user_proxy = autogen.UserProxyAgent(
        name="User",
        human_input_mode="TERMINATE",
        max_consecutive_auto_reply=10,
        is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
        code_execution_config={"work_dir": "coding"}
    )

    # Start a conversation
    user_proxy.initiate_chat(
        custom_assistant,
        message="Can you explain the concept of decorators in Python and provide a simple example?"
    )

if __name__ == "__main__":
    main()
```

In this example, we use the `AgentBuilder` to create a custom assistant specialized in Python programming. We then create a user proxy agent and initiate a conversation about Python decorators.

To run this example:

```bash
python agent_builder_example.py
```

The agent builder allows you to create agents with specific configurations, making it easier to tailor agents for particular tasks or domains.

## 5. GPT Assistant Agent (gpt_assistant_agent.py)

The GPT Assistant Agent is a specialized agent that leverages OpenAI's GPT models. It provides a powerful interface for creating agents with advanced language understanding and generation capabilities.

Key features:
- Integration with OpenAI's API
- Customizable system messages
- Handling of conversation context

Let's create an example using the GPT Assistant Agent. Open `gpt_assistant_example.py` and add the following code:

```python
# gpt_assistant_example.py

import autogen
from autogen.agentchat.contrib.gpt_assistant_agent import GPTAssistantAgent

def main():
    # Create a GPT Assistant Agent
    gpt_assistant = GPTAssistantAgent(
        name="DataAnalyst",
        instructions="You are an AI assistant expert in data analysis and visualization. Provide detailed explanations and code examples when appropriate.",
        llm_config={
            "model": "gpt-4",
            "temperature": 0.5,
            "config_list": [{"api_key": "your-openai-api-key"}]
        }
    )

    # Create a user proxy agent
    user_proxy = autogen.UserProxyAgent(
        name="User",
        human_input_mode="TERMINATE",
        max_consecutive_auto_reply=10,
        is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
        code_execution_config={"work_dir": "coding"}
    )

    # Start a conversation
    user_proxy.initiate_chat(
        gpt_assistant,
        message="Can you explain the difference between a bar plot and a histogram, and when to use each? Please provide Python code examples using matplotlib."
    )

if __name__ == "__main__":
    main()
```

In this example, we create a GPT Assistant Agent specialized in data analysis and visualization. We then initiate a conversation about the difference between bar plots and histograms, requesting Python code examples.

To run this example:

```bash
python gpt_assistant_example.py
```

Remember to replace `"your-openai-api-key"` with your actual OpenAI API key.

The GPT Assistant Agent allows you to create highly capable agents with specific expertise, leveraging the power of large language models.

## 6. Image Utilities (img_utils.py)

The `img_utils.py` file provides utilities for handling images in agent conversations. These utilities are particularly useful when working with agents that need to process or analyze image data.

Key functionalities:
- Image loading and processing
- Conversion between different image formats
- Integration of images in agent messages

Let's create an example that demonstrates how to use these image utilities. Open `image_handling_example.py` and add the following code:

```python
# image_handling_example.py

import autogen
from autogen.agentchat.contrib.img_utils import get_image_data, get_pil_image, pil_to_data_uri
from PIL import Image
import base64
import io

def main():
    # Load an image
    image_path = "images/sample_image1.jpg"
    image_data = get_image_data(image_path)

    # Create an agent that can handle images
    image_analyst = autogen.AssistantAgent(
        name="ImageAnalyst",
        system_message="You are an AI assistant capable of analyzing images. Describe the contents of images in detail.",
        llm_config={"model": "gpt-4-vision-preview", "max_tokens": 1000}
    )

    # Create a user proxy agent
    user_proxy = autogen.UserProxyAgent(
        name="User",
        human_input_mode="TERMINATE",
        max_consecutive_auto_reply=10,
        is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    )

    # Start a conversation with an image
    user_proxy.initiate_chat(
        image_analyst,
        message=[
            {
                "type": "text",
                "text": "What can you see in this image? Please provide a detailed description."
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{image_data}"
                }
            }
        ]
    )

if __name__ == "__main__":
    main()
```

This example demonstrates how to load an image, convert it to a format suitable for agent messages, and use it in a conversation with an image analysis agent.

To run this example:

```bash
python image_handling_example.py
```

Make sure you have an image file named `sample_image1.jpg` in the `images/` directory before running the script.

These image utilities make it easy to incorporate image-based tasks into your agent systems, enabling a wide range of multimodal applications.

## 7. Hands-on Project: Multi-Agent Image Analysis System

Now that we've explored the individual components, let's create a more complex system that combines these elements. We'll build a multi-agent image analysis system that uses the agent builder, GPT assistant, and image utilities.

Open `multi_agent_image_analysis.py` and add the following code:

```python
# multi_agent_image_analysis.py

import autogen
from autogen.agentchat.contrib.agent_builder import AgentBuilder
from autogen.agentchat.contrib.gpt_assistant_agent import GPTAssistantAgent
from autogen.agentchat.contrib.img_utils import get_image_data
import json

def main():
    # Initialize the agent builder
    builder = AgentBuilder()

    # Create an image description agent
    image_describer = builder.create_agent(
        name="ImageDescriber",
        system_message="You are an AI assistant specialized in describing images in detail. Provide comprehensive descriptions of image contents.",
        llm_config={"model": "gpt-4-vision-preview", "max_tokens": 1000}
    )

    # Create a GPT Assistant Agent for analysis
    analyst = GPTAssistantAgent(
        name="ImageAnalyst",
        instructions="You are an AI assistant expert in analyzing image descriptions and answering questions about them. Provide detailed answers and insights based on the image descriptions you receive.",
        llm_config={
            "model": "gpt-4",
            "temperature": 0.7,
            "config_list": [{"api_key": "your-openai-api-key"}]
        }
    )

    # Create a user proxy agent
    user_proxy = autogen.UserProxyAgent(
        name="User",
        human_input_mode="TERMINATE",
        max_consecutive_auto_reply=10,
        is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    )

    # Load images
    image1_data = get_image_data("images/sample_image1.jpg")
    image2_data = get_image_data("images/sample_image2.jpg")

    # Function to get image description
    def get_image_description(image_data):
        message = [
            {
                "type": "text",
                "text": "Please provide a detailed description of this image."
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{image_data}"
                }
            }
        ]
        response = user_proxy.initiate_chat(image_describer, message=message)
        return response.get("content", "")

    # Get descriptions for both images
    description1 = get_image_description(image1_data)
    description2 = get_image_description(image2_data)

    # Analyze the descriptions
    analysis_prompt = f"""
    I have descriptions of two images:

    Image 1: {description1}

    Image 2: {description2}

    Please analyze these descriptions and answer the following questions:
    1. What are the main similarities between the two images?
    2. What are the key differences between the two images?
    3. Based on these descriptions, what can you infer about the context or setting of these images?
    4. Are there any interesting details or patterns you notice across both images?

    Provide a detailed analysis for each question.
    """

    user_proxy.initiate_chat(analyst, message=analysis_prompt)

if __name__ == "__main__":
    main()
```

This project demonstrates a multi-agent system where:
1. An image description agent (created using the agent builder) provides detailed descriptions of two images.
2. A GPT Assistant Agent analyzes these descriptions and answers questions about the images.
3. Image utilities are used to load and process the images for use in the agent messages.

To run this project:

```bash
python multi_agent_image_analysis.py
```

Make sure you have two image files (`sample_image1.jpg` and `sample_image2.jpg`) in the `images/` directory, and replace `"your-openai-api-key"` with your actual OpenAI API key.

This hands-on project showcases how the different components we've learned about can be combined to create a sophisticated multi-agent system capable of advanced image analysis tasks.

## 8. Exercises

To reinforce your understanding of the concepts covered in this lesson, try the following exercises:

1. Modify the `agent_builder_example.py` to create an agent specialized in a different domain (e.g., history, literature, or science). Use this agent to answer domain-specific questions.

2. Extend the `gpt_assistant_example.py` to include a conversation about a complex topic that requires multiple turns of dialogue. Implement follow-up questions and clarifications.

3. Create a new script that uses the image utilities to implement a simple image classification system. Load multiple images, describe them using an image analysis agent, and then use another agent to categorize the images based on their descriptions.

4. Enhance the `multi_agent_image_analysis.py` project to include a third agent that generates creative writing prompts based on the image descriptions and analysis. Implement a workflow where this agent receives the output from the analyst and produces a short story prompt.

5. Implement error handling and input validation in the multi-agent project. Consider scenarios such as missing image files, API failures, or unexpected agent responses.

## 9. Summary and Next Steps

In this lesson, we've explored three key components from the `contrib` folder of the AgentChat module:

1. The agent builder, which allows for dynamic creation and configuration of
```

# agentchat\lesson-8-contributed-agents-and-utilities-part-2.md

```
# Lesson 8: Contributed Agents and Utilities (Part 2)

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [LLaVA Agent](#llava-agent)
4. [Math User Proxy Agent](#math-user-proxy-agent)
5. [Multimodal Conversable Agent](#multimodal-conversable-agent)
6. [Web Surfer Agent](#web-surfer-agent)
7. [Practical Examples](#practical-examples)
8. [Exercises](#exercises)
9. [Conclusion](#conclusion)

## 1. Introduction <a name="introduction"></a>

Welcome to Lesson 8 of our Autogen AgentChat series! In this lesson, we'll continue our exploration of the `contrib` folder, focusing on specialized agents and utilities that extend the capabilities of the AgentChat module. We'll cover the LLaVA agent, Math User Proxy agent, Multimodal Conversable agent, and the Web Surfer agent. These components allow us to create more sophisticated and specialized AI systems capable of handling a wide range of tasks.

## 2. Project Structure <a name="project-structure"></a>

Before we dive into the details, let's look at the project structure for this lesson:

```
autogen_tutorial/
├── lesson8_advanced_agents/
│   ├── llava_example.py
│   ├── math_proxy_example.py
│   ├── multimodal_example.py
│   ├── web_surfer_example.py
│   ├── data/
│   │   ├── sample_image.jpg
│   │   └── math_problem.txt
│   ├── requirements.txt
│   └── README.md
└── README.md
```

Make sure to set up a virtual environment and install the required dependencies:

```bash
python -m venv venv
source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
pip install -r requirements.txt
```

## 3. LLaVA Agent <a name="llava-agent"></a>

The LLaVA (Large Language and Vision Assistant) agent is designed to handle both text and image inputs, making it suitable for multimodal tasks. Let's examine its key features and usage.

### Key Features:
- Handles both text and image inputs
- Uses a vision-language model for processing
- Supports various image formats and sources

### Implementation:

```python
# llava_example.py
from autogen.agentchat.contrib.llava_agent import LLaVAAgent
from autogen import UserProxyAgent
import autogen

# Configure the LLaVA agent
llava_config = {
    "base_url": "http://localhost:8000",  # Replace with your LLaVA server URL
    "model": "llava-v1.5-7b",
}

# Create the LLaVA agent
llava_agent = LLaVAAgent(
    name="llava_agent",
    llm_config={"config_list": [llava_config]},
)

# Create a user proxy agent
user_proxy = UserProxyAgent(
    name="user_proxy",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
)

# Start a conversation
user_proxy.initiate_chat(
    llava_agent,
    message="What's in this image?",
    image="data/sample_image.jpg"
)
```

In this example, we create a LLaVA agent and a user proxy agent. The user proxy initiates a chat with the LLaVA agent, asking about the contents of an image. The LLaVA agent processes both the text question and the image, providing a response based on its multimodal understanding.

## 4. Math User Proxy Agent <a name="math-user-proxy-agent"></a>

The Math User Proxy Agent is specialized for handling mathematical problems and computations. It can interpret mathematical queries, perform calculations, and provide step-by-step solutions.

### Key Features:
- Interprets mathematical questions and problems
- Performs calculations and provides detailed solutions
- Supports various mathematical operations and concepts

### Implementation:

```python
# math_proxy_example.py
from autogen.agentchat.contrib.math_user_proxy_agent import MathUserProxyAgent
from autogen import AssistantAgent
import autogen

# Configure the Math User Proxy agent
math_config = {
    "use_docker": False,  # Set to True if you want to use Docker for code execution
    "timeout": 60,
    "ask_human": False,
}

# Create the Math User Proxy agent
math_agent = MathUserProxyAgent(
    name="math_agent",
    llm_config={"config_list": [{"model": "gpt-4"}]},
    code_execution_config=math_config,
)

# Create an assistant agent
assistant = AssistantAgent(
    name="assistant",
    llm_config={"config_list": [{"model": "gpt-4"}]},
)

# Start a conversation
math_agent.initiate_chat(
    assistant,
    message="Solve the quadratic equation: x^2 + 5x + 6 = 0"
)
```

In this example, we create a Math User Proxy agent and an assistant agent. The Math User Proxy agent initiates a chat with the assistant, asking to solve a quadratic equation. The assistant provides the solution, and the Math User Proxy agent can interpret and verify the results.

## 5. Multimodal Conversable Agent <a name="multimodal-conversable-agent"></a>

The Multimodal Conversable Agent extends the capabilities of the standard ConversableAgent to handle multiple types of input, including text, images, and potentially other modalities.

### Key Features:
- Processes multiple input types (text, images, etc.)
- Integrates various AI models for different modalities
- Provides a unified interface for multimodal conversations

### Implementation:

```python
# multimodal_example.py
from autogen.agentchat.contrib.multimodal_conversable_agent import MultimodalConversableAgent
from autogen import UserProxyAgent
import autogen

# Configure the Multimodal Conversable agent
multimodal_config = {
    "llm_config": {
        "config_list": [{"model": "gpt-4-vision-preview"}],
    },
    "image_model": "clip-vit-base-patch32",
}

# Create the Multimodal Conversable agent
multimodal_agent = MultimodalConversableAgent(
    name="multimodal_agent",
    **multimodal_config
)

# Create a user proxy agent
user_proxy = UserProxyAgent(
    name="user_proxy",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
)

# Start a conversation
user_proxy.initiate_chat(
    multimodal_agent,
    message=[
        {"type": "text", "content": "Describe this image in detail:"},
        {"type": "image", "image_url": "data/sample_image.jpg"}
    ]
)
```

In this example, we create a Multimodal Conversable agent and a user proxy agent. The user proxy initiates a chat with the multimodal agent, sending both text and an image. The multimodal agent processes both inputs and provides a detailed description of the image.

## 6. Web Surfer Agent <a name="web-surfer-agent"></a>

The Web Surfer Agent is designed to browse the internet, search for information, and interact with web content. It can be used for tasks that require up-to-date information or specific web-based research.

### Key Features:
- Performs web searches
- Navigates web pages
- Extracts relevant information from websites

### Implementation:

```python
# web_surfer_example.py
from autogen.agentchat.contrib.web_surfer import WebSurferAgent
from autogen import UserProxyAgent
import autogen

# Configure the Web Surfer agent
web_surfer_config = {
    "browser_config": {
        "viewport_size": {"width": 1280, "height": 720},
    },
    "llm_config": {
        "config_list": [{"model": "gpt-4"}],
    },
}

# Create the Web Surfer agent
web_surfer = WebSurferAgent(
    name="web_surfer",
    **web_surfer_config
)

# Create a user proxy agent
user_proxy = UserProxyAgent(
    name="user_proxy",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
)

# Start a conversation
user_proxy.initiate_chat(
    web_surfer,
    message="Find the latest news about artificial intelligence breakthroughs"
)
```

In this example, we create a Web Surfer agent and a user proxy agent. The user proxy initiates a chat with the web surfer, asking for the latest news about AI breakthroughs. The web surfer agent searches the internet, navigates relevant web pages, and provides a summary of the latest AI news.

## 7. Practical Examples <a name="practical-examples"></a>

Now that we've covered the individual agents, let's look at a more complex example that combines multiple agents to solve a real-world problem.

### Multi-Agent Research System

In this example, we'll create a system that combines the LLaVA agent, Math User Proxy agent, and Web Surfer agent to perform a comprehensive research task.

```python
# multi_agent_research.py
from autogen.agentchat.contrib.llava_agent import LLaVAAgent
from autogen.agentchat.contrib.math_user_proxy_agent import MathUserProxyAgent
from autogen.agentchat.contrib.web_surfer import WebSurferAgent
from autogen import UserProxyAgent, AssistantAgent, GroupChat, GroupChatManager
import autogen

# Create agents
llava_agent = LLaVAAgent(name="llava", llm_config={"config_list": [{"model": "llava-v1.5-7b"}]})
math_agent = MathUserProxyAgent(name="math_expert", llm_config={"config_list": [{"model": "gpt-4"}]})
web_surfer = WebSurferAgent(name="web_researcher", llm_config={"config_list": [{"model": "gpt-4"}]})
assistant = AssistantAgent(name="assistant", llm_config={"config_list": [{"model": "gpt-4"}]})
user_proxy = UserProxyAgent(name="user_proxy", human_input_mode="TERMINATE")

# Create a group chat
agents = [user_proxy, llava_agent, math_agent, web_surfer, assistant]
groupchat = GroupChat(agents=agents, messages=[], max_round=50)
manager = GroupChatManager(groupchat=groupchat, llm_config={"config_list": [{"model": "gpt-4"}]})

# Start the research task
user_proxy.initiate_chat(
    manager,
    message="""
    Research task:
    1. Find the latest advancements in quantum computing (use web_researcher)
    2. Analyze an image of a quantum computer and describe its components (use llava)
    3. Calculate the potential speed-up of a quantum algorithm compared to its classical counterpart (use math_expert)
    4. Summarize the findings and their implications for the future of computing (use assistant)
    """
)
```

This example demonstrates how different specialized agents can work together to perform a complex research task involving web searches, image analysis, mathematical calculations, and summarization.

## 8. Exercises <a name="exercises"></a>

To reinforce your understanding of these advanced agents, try the following exercises:

1. Create a system that uses the LLaVA agent to analyze a series of images and the Math User Proxy agent to perform statistical analysis on the results.

2. Implement a web-based fact-checking system using the Web Surfer agent and the Multimodal Conversable agent to verify claims in both text and images.

3. Design a scientific research assistant that combines all four agents to help with literature reviews, data analysis, and hypothesis generation.

## 9. Conclusion <a name="conclusion"></a>

In this lesson, we've explored four powerful contributed agents in the Autogen AgentChat module: the LLaVA agent, Math User Proxy agent, Multimodal Conversable agent, and Web Surfer agent. These specialized agents extend the capabilities of the basic AgentChat system, allowing for more sophisticated and diverse applications.

By combining these agents, we can create complex AI systems capable of handling a wide range of tasks, from image analysis and mathematical problem-solving to web research and multimodal interactions. As you continue to work with Autogen, experiment with different combinations of these agents to solve real-world problems and create innovative AI applications.

In the next lesson, we'll dive into advanced topics such as agent evaluation, custom capabilities, and graph-based retrieval-augmented generation (RAG) systems.

```

# agentchat\lesson-9-information-retrieval-in-agents.md

```
# Lesson 9: Information Retrieval in Agents

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding Retrieve Assistant Agent](#understanding-retrieve-assistant-agent)
4. [Exploring Retrieve User Proxy Agent](#exploring-retrieve-user-proxy-agent)
5. [Implementing Efficient Information Retrieval Systems](#implementing-efficient-information-retrieval-systems)
6. [Integrating External Knowledge Bases](#integrating-external-knowledge-bases)
7. [Practical Examples](#practical-examples)
8. [Exercises](#exercises)
9. [Summary](#summary)

## 1. Introduction <a name="introduction"></a>

In this lesson, we'll dive deep into the information retrieval capabilities of Autogen's AgentChat module. We'll focus on two key components: the Retrieve Assistant Agent and the Retrieve User Proxy Agent. These agents are designed to enhance the ability of our AI systems to access and utilize external information effectively.

Information retrieval is crucial for creating more knowledgeable and capable AI agents. By integrating external knowledge bases and implementing efficient retrieval mechanisms, we can significantly improve the performance and utility of our agents in various tasks.

## 2. Project Structure <a name="project-structure"></a>

Before we begin, let's look at the project structure for this lesson:

```
autogen_tutorial/
├── lesson9_information_retrieval/
│   ├── retrieve_assistant_example.py
│   ├── retrieve_user_proxy_example.py
│   ├── custom_retrieval_system.py
│   ├── knowledge_base/
│   │   ├── article1.txt
│   │   ├── article2.txt
│   │   └── article3.txt
│   ├── requirements.txt
│   └── README.md
└── README.md
```

This structure organizes our code and resources for the lesson, including example implementations and a sample knowledge base.

## 3. Understanding Retrieve Assistant Agent <a name="understanding-retrieve-assistant-agent"></a>

The Retrieve Assistant Agent is an extension of the standard Assistant Agent that can access and utilize external information sources. Let's examine its key features and how to use it effectively.

### Key Features

1. External knowledge access
2. Contextual information retrieval
3. Seamless integration with conversation flow

### Implementation

First, let's look at a basic implementation of the Retrieve Assistant Agent:

```python
# retrieve_assistant_example.py

from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent
from autogen.agentchat.contrib.retrieve_user_proxy_agent import RetrieveUserProxyAgent

# Initialize the retrieval configuration
retrieve_config = {
    "task": "qa",
    "docs_path": "./knowledge_base",
    "chunk_token_size": 1000,
    "model": "gpt-3.5-turbo",
    "client": None,  # Add your vector store client here if using a specific one
    "embedding_model": "text-embedding-ada-002",
    "customized_prompt": None,  # Add a custom prompt if needed
}

# Create the Retrieve Assistant Agent
retrieve_assistant = RetrieveAssistantAgent(
    name="retrieve_assistant",
    system_message="You are a helpful AI assistant with access to a knowledge base. Use this information to answer questions accurately.",
    llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]},
    retrieve_config=retrieve_config
)

# Create a Retrieve User Proxy Agent for interaction
user_proxy = RetrieveUserProxyAgent(
    name="user_proxy",
    human_input_mode="ALWAYS",
    retrieve_config=retrieve_config
)

# Start a conversation
user_proxy.initiate_chat(
    retrieve_assistant,
    message="What can you tell me about the benefits of regular exercise?"
)
```

In this example, we create a Retrieve Assistant Agent with access to a knowledge base located in the `knowledge_base` directory. The agent can use this information to provide more accurate and informed responses.

## 4. Exploring Retrieve User Proxy Agent <a name="exploring-retrieve-user-proxy-agent"></a>

The Retrieve User Proxy Agent is designed to simulate a user with access to external information. This agent can be particularly useful for testing and development scenarios where you want to emulate a knowledgeable user.

### Key Features

1. Simulates a user with external knowledge
2. Can retrieve information to formulate questions or responses
3. Useful for testing and development of information retrieval systems

### Implementation

Let's implement a scenario using the Retrieve User Proxy Agent:

```python
# retrieve_user_proxy_example.py

from autogen.agentchat.contrib.retrieve_user_proxy_agent import RetrieveUserProxyAgent
from autogen.agentchat.assistant_agent import AssistantAgent

# Initialize the retrieval configuration
retrieve_config = {
    "task": "qa",
    "docs_path": "./knowledge_base",
    "chunk_token_size": 1000,
    "model": "gpt-3.5-turbo",
    "client": None,
    "embedding_model": "text-embedding-ada-002",
}

# Create the Retrieve User Proxy Agent
retrieve_user = RetrieveUserProxyAgent(
    name="retrieve_user",
    retrieve_config=retrieve_config,
    human_input_mode="NEVER"  # Simulate fully automated retrieval
)

# Create a standard Assistant Agent for interaction
assistant = AssistantAgent(
    name="assistant",
    llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]}
)

# Start a conversation
retrieve_user.initiate_chat(
    assistant,
    message="Ask me about the benefits of meditation based on scientific studies."
)
```

In this example, the Retrieve User Proxy Agent acts as a knowledgeable user who can ask informed questions based on the information in the knowledge base.

## 5. Implementing Efficient Information Retrieval Systems <a name="implementing-efficient-information-retrieval-systems"></a>

To create an efficient information retrieval system, we need to consider several factors:

1. Indexing and storage of information
2. Efficient search algorithms
3. Relevance ranking of retrieved information

Let's implement a custom retrieval system that addresses these factors:

```python
# custom_retrieval_system.py

import os
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from collections import defaultdict
import math

nltk.download('punkt')
nltk.download('stopwords')

class CustomRetrievalSystem:
    def __init__(self, docs_path):
        self.docs_path = docs_path
        self.documents = {}
        self.inverted_index = defaultdict(dict)
        self.doc_lengths = {}
        self.load_documents()
        self.build_index()

    def load_documents(self):
        for filename in os.listdir(self.docs_path):
            if filename.endswith('.txt'):
                with open(os.path.join(self.docs_path, filename), 'r') as file:
                    self.documents[filename] = file.read()

    def build_index(self):
        stop_words = set(stopwords.words('english'))
        for doc_id, content in self.documents.items():
            tokens = word_tokenize(content.lower())
            tokens = [token for token in tokens if token.isalnum() and token not in stop_words]
            
            term_freq = defaultdict(int)
            for token in tokens:
                term_freq[token] += 1
            
            self.doc_lengths[doc_id] = math.sqrt(sum(tf ** 2 for tf in term_freq.values()))
            
            for term, freq in term_freq.items():
                self.inverted_index[term][doc_id] = freq

    def search(self, query, top_k=5):
        query_tokens = word_tokenize(query.lower())
        query_tokens = [token for token in query_tokens if token.isalnum() and token not in stopwords.words('english')]
        
        scores = defaultdict(float)
        for token in query_tokens:
            if token in self.inverted_index:
                idf = math.log(len(self.documents) / len(self.inverted_index[token]))
                for doc_id, tf in self.inverted_index[token].items():
                    tfidf = tf * idf
                    scores[doc_id] += tfidf / self.doc_lengths[doc_id]
        
        ranked_results = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
        return [(doc_id, self.documents[doc_id][:200] + '...') for doc_id, score in ranked_results]

# Usage
retrieval_system = CustomRetrievalSystem('./knowledge_base')
results = retrieval_system.search("benefits of regular exercise")
for doc_id, snippet in results:
    print(f"Document: {doc_id}")
    print(f"Snippet: {snippet}")
    print()
```

This custom retrieval system implements a basic TF-IDF (Term Frequency-Inverse Document Frequency) based search algorithm. It indexes the documents, removes stop words, and ranks the results based on relevance to the query.

## 6. Integrating External Knowledge Bases <a name="integrating-external-knowledge-bases"></a>

Integrating external knowledge bases can greatly enhance the capabilities of our retrieval agents. Let's explore how to integrate a popular vector database, Pinecone, with our Retrieve Assistant Agent:

```python
# First, install the necessary package:
# pip install pinecone-client

import pinecone
from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent

# Initialize Pinecone
pinecone.init(api_key="YOUR_PINECONE_API_KEY", environment="YOUR_PINECONE_ENVIRONMENT")

# Create or connect to an existing index
index_name = "your_index_name"
if index_name not in pinecone.list_indexes():
    pinecone.create_index(index_name, dimension=1536)  # 1536 is the dimension for 'text-embedding-ada-002'
index = pinecone.Index(index_name)

# Function to convert Pinecone results to the format expected by RetrieveAssistantAgent
def pinecone_to_retrieve_result(pinecone_results):
    return {
        "ids": [item["id"] for item in pinecone_results["matches"]],
        "documents": [item["metadata"]["text"] for item in pinecone_results["matches"]],
        "metadatas": [item["metadata"] for item in pinecone_results["matches"]],
        "distances": [item["score"] for item in pinecone_results["matches"]],
    }

# Custom retrieval function using Pinecone
def retrieve_from_pinecone(query, n_results=5):
    query_embedding = get_embedding(query)  # You need to implement this function to get embeddings
    results = index.query(query_embedding, top_k=n_results, include_metadata=True)
    return pinecone_to_retrieve_result(results)

# Create the Retrieve Assistant Agent with Pinecone integration
retrieve_config = {
    "task": "qa",
    "retriever": retrieve_from_pinecone,
    "chunk_token_size": 1000,
    "model": "gpt-3.5-turbo",
    "client": None,
    "embedding_model": "text-embedding-ada-002",
}

pinecone_assistant = RetrieveAssistantAgent(
    name="pinecone_assistant",
    system_message="You are a helpful AI assistant with access to a Pinecone knowledge base. Use this information to answer questions accurately.",
    llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]},
    retrieve_config=retrieve_config
)

# Use the Pinecone-integrated assistant in a conversation
user_proxy.initiate_chat(
    pinecone_assistant,
    message="What are the latest developments in renewable energy?"
)
```

This example demonstrates how to integrate Pinecone, a vector database, with our Retrieve Assistant Agent. By using a vector database, we can perform more efficient similarity searches on large datasets, which is particularly useful for handling extensive knowledge bases.

## 7. Practical Examples <a name="practical-examples"></a>

Let's explore some practical examples of using our information retrieval agents in real-world scenarios.

### Example 1: Research Assistant

```python
# research_assistant.py

from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent
from autogen.agentchat.contrib.retrieve_user_proxy_agent import RetrieveUserProxyAgent

retrieve_config = {
    "task": "qa",
    "docs_path": "./research_papers",
    "chunk_token_size": 1000,
    "model": "gpt-4",
    "embedding_model": "text-embedding-ada-002",
}

research_assistant = RetrieveAssistantAgent(
    name="research_assistant",
    system_message="You are a knowledgeable research assistant with access to a database of scientific papers. Provide accurate and up-to-date information based on these papers.",
    llm_config={"config_list": [{"model": "gpt-4"}]},
    retrieve_config=retrieve_config
)

user = RetrieveUserProxyAgent(
    name="researcher",
    human_input_mode="ALWAYS",
    retrieve_config=retrieve_config
)

user.initiate_chat(
    research_assistant,
    message="What are the latest findings on the effectiveness of mRNA vaccines?"
)
```

This example creates a research assistant that can access and summarize information from scientific papers.

### Example 2: Technical Support Agent

```python
# tech_support_agent.py

from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent
from autogen.agentchat.human_proxy_agent import HumanProxyAgent

retrieve_config = {
    "task": "qa",
    "docs_path": "./technical_manuals",
    "chunk_token_size": 500,
    "model": "gpt-3.5-turbo",
    "embedding_model": "text-embedding-ada-002",
}

tech_support = RetrieveAssistantAgent(
    name="tech_support",
    system_message="You are a helpful technical support agent with access to product manuals and troubleshooting guides. Provide clear and concise solutions to technical issues.",
    llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]},
    retrieve_config=retrieve_config
)

user = HumanProxyAgent(
    name="customer",
    human_input_mode="ALWAYS"
)

user.initiate_chat(
    tech_support,
    message="I'm having trouble connecting my printer to Wi-Fi. Can you help me troubleshoot?"
)
```

This example creates a technical support agent that can access product manuals and troubleshooting guides to assist customers with technical issues.

## 8. Exercises <a name="exercises"></a>

To reinforce your understanding of information retrieval in agents, try the following exercises:

1. Implement a Retrieve Assistant Agent that specializes in answering questions about a specific topic (e.g., history, science, literature). Use a curated knowledge base for this topic.

2. Create a custom retrieval system that uses a different ranking algorithm (e.g., BM25) instead of TF-IDF. Compare its performance with the TF-IDF based system we implemented earlier.

3. Extend the Retrieve User Proxy Agent to simulate a user with varying levels of knowledge. Implement a "knowledge level" parameter that affects the complexity and depth of the questions it asks.

4. Implement a multi-agent system where a Retrieve Assistant Agent collaborates with a standard Assistant Agent to answer complex queries. The Retrieve Assistant should provide relevant information, while the standard Assistant formulates the final response.

5. Create a Retrieve Assistant Agent that can handle multi-lingual queries and documents. Use a translation service to translate queries and documents as needed.

Here's a starting point for Exercise 4:

```python
# multi_agent_retrieval_system.py

from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent
from autogen.agentchat.assistant_agent import AssistantAgent
from autogen.agentchat.user_proxy_agent import UserProxyAgent

# Initialize retrieval configuration
retrieve_config = {
    "task": "qa",
    "docs_path": "./knowledge_base",
    "chunk_token_size": 1000,
    "model": "gpt-3.5-turbo",
    "embedding_model": "text-embedding-ada-002",
}

# Create a Retrieve Assistant Agent
retrieve_agent = RetrieveAssistantAgent(
    name="retriever",
    system_message="You are a retrieval specialist. Your role is to find and provide relevant information from the knowledge base.",
    llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]},
    retrieve_config=retrieve_config
)

# Create a standard Assistant Agent
assistant = AssistantAgent(
    name="assistant",
    system_message="You are a helpful assistant. Your role is to formulate clear and concise answers based on the information provided by the retrieval specialist.",
    llm_config={"config_list": [{"model": "gpt-4"}]}
)

# Create a User Proxy Agent
user = UserProxyAgent(
    name="user",
    human_input_mode="ALWAYS"
)

# Function to manage the multi-agent conversation
def multi_agent_query(user_query):
    # Step 1: Retrieve relevant information
    retrieval_result = retrieve_agent.generate_response(user_query)
    
    # Step 2: Formulate a response using the retrieved information
    assistant_prompt = f"Based on the following retrieved information, please answer the user's query: '{user_query}'\n\nRetrieved Information: {retrieval_result}"
    final_response = assistant.generate_response(assistant_prompt)
    
    return final_response

# Example usage
user_query = "What are the potential applications of CRISPR technology in agriculture?"
response = multi_agent_query(user_query)
print(f"User Query: {user_query}")
print(f"Final Response: {response}")
```

## 9. Summary <a name="summary"></a>

In this lesson, we've explored the powerful information retrieval capabilities of Autogen's AgentChat module, focusing on the Retrieve Assistant Agent and Retrieve User Proxy Agent. We've covered:

1. The fundamentals of information retrieval in AI agents
2. Implementing and customizing Retrieve Assistant Agents
3. Utilizing Retrieve User Proxy Agents for testing and development
4. Creating efficient information retrieval systems
5. Integrating external knowledge bases, such as Pinecone
6. Practical examples of information retrieval agents in real-world scenarios
7. Exercises to reinforce understanding and encourage experimentation

Key takeaways:

- Information retrieval greatly enhances the capabilities of AI agents, allowing them to access and utilize vast amounts of external knowledge.
- The Retrieve Assistant Agent and Retrieve User Proxy Agent provide flexible frameworks for implementing information retrieval in conversational AI systems.
- Custom retrieval systems can be tailored to specific needs, using techniques like TF-IDF or more advanced algorithms.
- Integration with vector databases like Pinecone can significantly improve retrieval performance for large-scale applications.
- Multi-agent systems can leverage the strengths of different agent types to create more powerful and flexible information retrieval solutions.

As you continue to work with Autogen's AgentChat module, consider how you can leverage these information retrieval capabilities to create more knowledgeable and capable AI agents. Experiment with different retrieval methods, knowledge bases, and agent configurations to find the best approach for your specific use cases.

In the next lesson, we'll explore advanced topics in agent evaluation, focusing on the agent_eval subfolder and its components. This will help you assess and improve the performance of your information retrieval agents and other AI systems built with Autogen.

```

# agentchat\extra\lesson-3-understanding-agent-base-class.md

```
# Lesson 3: Understanding the Agent Base Class

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [The Agent Base Class](#the-agent-base-class)
   - [Core Attributes](#core-attributes)
   - [Key Methods](#key-methods)
4. [Creating Custom Agents](#creating-custom-agents)
5. [Practical Examples](#practical-examples)
6. [Exercises](#exercises)
7. [Summary](#summary)

## 1. Introduction

Welcome to Lesson 3 of our Autogen AgentChat series. In this lesson, we'll dive deep into the Agent base class, which forms the foundation for all agent types in the Autogen framework. Understanding this base class is crucial for creating custom agents and comprehending the inner workings of the agent system.

## 2. Project Structure

Before we begin, let's set up our project structure for this lesson:

```
autogen_tutorial/
├── lesson3_agent_base_class/
│   ├── agent_examples/
│   │   ├── __init__.py
│   │   ├── custom_agent.py
│   │   └── agent_tester.py
│   ├── exercises/
│   │   ├── __init__.py
│   │   └── exercise_1.py
│   ├── main.py
│   └── requirements.txt
└── README.md
```

Make sure to create these directories and files. We'll be using them throughout the lesson.

## 3. The Agent Base Class

The Agent base class is defined in the `agent.py` file within the `autogen/agentchat/` directory. Let's examine its core attributes and key methods.

### Core Attributes

```python
# agent_examples/custom_agent.py

from autogen.agentchat import Agent

class SimpleAgent(Agent):
    def __init__(self, name: str):
        super().__init__(name)
        self.name = name
        self.description = "A simple custom agent"
        self.system_message = "You are a helpful assistant."
```

The core attributes of the Agent base class include:

1. `name`: A string identifier for the agent.
2. `description`: A brief description of the agent's purpose or capabilities.
3. `system_message`: Instructions or context provided to the agent.

### Key Methods

The Agent base class defines several key methods that all derived agents should implement:

```python
# agent_examples/custom_agent.py

from typing import Dict, List, Union
from autogen.agentchat import Agent

class SimpleAgent(Agent):
    def __init__(self, name: str):
        super().__init__(name)
        self.name = name
        self.description = "A simple custom agent"
        self.system_message = "You are a helpful assistant."

    def send(self, message: Union[Dict, str], recipient: Agent) -> None:
        print(f"{self.name} sending message to {recipient.name}: {message}")

    def receive(self, message: Union[Dict, str], sender: Agent) -> None:
        print(f"{self.name} received message from {sender.name}: {message}")

    def generate_reply(self, messages: List[Dict], sender: Agent) -> Union[str, Dict, None]:
        return f"Hello, {sender.name}! This is a simple reply from {self.name}."
```

Let's break down these key methods:

1. `send(message, recipient)`: This method is used to send a message to another agent.
2. `receive(message, sender)`: This method is called when the agent receives a message from another agent.
3. `generate_reply(messages, sender)`: This method generates a reply based on the conversation history and the sender.

## 4. Creating Custom Agents

To create a custom agent, you need to inherit from the Agent base class and implement its key methods. Here's an example of a more advanced custom agent:

```python
# agent_examples/custom_agent.py

from typing import Dict, List, Union
from autogen.agentchat import Agent

class AdvancedAgent(Agent):
    def __init__(self, name: str, expertise: str):
        super().__init__(name)
        self.name = name
        self.expertise = expertise
        self.description = f"An advanced agent specialized in {expertise}"
        self.system_message = f"You are an AI assistant with expertise in {expertise}."
        self.conversation_history = []

    def send(self, message: Union[Dict, str], recipient: Agent) -> None:
        formatted_message = f"{self.name} to {recipient.name}: {message}"
        self.conversation_history.append(formatted_message)
        print(formatted_message)

    def receive(self, message: Union[Dict, str], sender: Agent) -> None:
        formatted_message = f"{sender.name} to {self.name}: {message}"
        self.conversation_history.append(formatted_message)
        print(formatted_message)

    def generate_reply(self, messages: List[Dict], sender: Agent) -> Union[str, Dict, None]:
        # In a real scenario, you might use an LLM here
        last_message = messages[-1]['content'] if isinstance(messages[-1], dict) else messages[-1]
        return f"Based on my {self.expertise} expertise, I suggest: {last_message.upper()}"

    def summarize_conversation(self) -> str:
        return f"Conversation summary for {self.name}:\n" + "\n".join(self.conversation_history)
```

This `AdvancedAgent` class demonstrates how you can extend the base Agent class to create more sophisticated agents with additional functionality.

## 5. Practical Examples

Let's create a simple scenario to demonstrate how these custom agents can interact:

```python
# agent_examples/agent_tester.py

from custom_agent import SimpleAgent, AdvancedAgent

def test_agents():
    simple_agent = SimpleAgent("SimpleBot")
    advanced_agent = AdvancedAgent("AdvancedBot", "machine learning")

    # Simulate a conversation
    simple_agent.send("Hello, can you help me with machine learning?", advanced_agent)
    advanced_agent.receive("Hello, can you help me with machine learning?", simple_agent)
    
    reply = advanced_agent.generate_reply([{"content": "How do I choose the right algorithm for my data?"}], simple_agent)
    advanced_agent.send(reply, simple_agent)
    simple_agent.receive(reply, advanced_agent)

    # Print conversation summary
    print(advanced_agent.summarize_conversation())

if __name__ == "__main__":
    test_agents()
```

This example demonstrates how different agent types can interact, send and receive messages, and generate replies based on their specific implementations.

## 6. Exercises

To reinforce your understanding of the Agent base class and custom agent creation, try the following exercise:

```python
# exercises/exercise_1.py

from typing import Dict, List, Union
from autogen.agentchat import Agent

class DataAnalystAgent(Agent):
    def __init__(self, name: str):
        super().__init__(name)
        # TODO: Initialize the agent with appropriate attributes

    def send(self, message: Union[Dict, str], recipient: Agent) -> None:
        # TODO: Implement the send method

    def receive(self, message: Union[Dict, str], sender: Agent) -> None:
        # TODO: Implement the receive method

    def generate_reply(self, messages: List[Dict], sender: Agent) -> Union[str, Dict, None]:
        # TODO: Implement a method to generate a reply based on data analysis expertise

    def analyze_data(self, data: List[float]) -> str:
        # TODO: Implement a simple data analysis method (e.g., calculate mean, median, mode)

# Test your implementation
if __name__ == "__main__":
    analyst = DataAnalystAgent("DataBot")
    # TODO: Create a test scenario to demonstrate your agent's capabilities
```

Exercise: Complete the `DataAnalystAgent` class by implementing the required methods. Add a simple data analysis capability and demonstrate how this agent can interact with other agents to provide data insights.

## 7. Summary

In this lesson, we've explored the Agent base class in depth, including its core attributes and key methods. We've learned how to create custom agents by inheriting from the base class and implementing the necessary functionality. Through practical examples and exercises, we've seen how these agents can interact and perform specialized tasks.

Key takeaways:
1. The Agent base class provides a foundation for all agent types in Autogen.
2. Custom agents can be created by inheriting from the Agent class and implementing key methods.
3. Agents can have specialized capabilities while maintaining a consistent interface for interaction.

In the next lesson, we'll dive into more advanced agent types and explore how they can be used in complex conversational scenarios.


```

# agentchat\extra\lesson-5-specialized-agents (1).md

```
a. Web scrape the current weather information for a given city using the Beautiful Soup library.
   b. Process the scraped data to extract temperature, humidity, and weather conditions.
   c. Create a simple text-based weather report.
   d. Save the report to a file named "weather_report.txt".

3. Use appropriate error handling and make sure the UserProxyAgent can execute the code suggested by the AssistantAgent.
4. Test your implementation with at least two different cities.

Here's a starter template for your exercise:

```python
# lesson5_specialized_agents/exercise_specialized_agents.py

import autogen

# Configure the AI model
config_list = [
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here",
    }
]

# Create an AssistantAgent instance
assistant = autogen.AssistantAgent(
    name="WeatherAssistant",
    llm_config={"config_list": config_list},
    system_message="You are a helpful AI assistant specializing in web scraping and data processing for weather information."
)

# Create a UserProxyAgent for human interaction
user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={
        "work_dir": "weather_data",
        "use_docker": False,
    }
)

# Start the conversation
user_proxy.initiate_chat(
    assistant,
    message="Can you help me create a weather report for New York City and Tokyo? Please follow these steps:\n"
            "1. Web scrape the current weather information for each city.\n"
            "2. Process the scraped data to extract temperature, humidity, and weather conditions.\n"
            "3. Create a simple text-based weather report for each city.\n"
            "4. Save the reports to files named 'nyc_weather_report.txt' and 'tokyo_weather_report.txt'."
)

# Add your implementation here
```

Complete this exercise to practice working with specialized agents in a real-world scenario.

## 8. Summary <a name="summary"></a>

In this lesson, we explored two specialized agents provided by Autogen's AgentChat module: AssistantAgent and UserProxyAgent. We covered their key features, implementation details, and how to use them effectively in various scenarios. Here's a quick recap of what we learned:

1. AssistantAgent:
   - Designed to act as an AI assistant with pre-configured settings
   - Supports code execution and complex problem-solving tasks
   - Can be easily customized for specific use cases

2. UserProxyAgent:
   - Represents a human user in the conversation
   - Supports code execution and provides feedback
   - Offers flexible configuration options for human input and termination conditions

3. Combining specialized agents:
   - AssistantAgent and UserProxyAgent can work together to solve complex tasks
   - The combination allows for interactive problem-solving and code execution

4. Customizing specialized agents:
   - Both agent types can be extended to create custom specialized agents
   - Custom methods and behaviors can be added to fit specific requirements

By mastering these specialized agents, you can create more sophisticated and capable AI systems that can handle a wide range of tasks, from simple conversations to complex data analysis and automation.

In the next lesson, we'll explore group chats and collaboration techniques using Autogen's AgentChat module, building on the knowledge we've gained about specialized agents.

## Project Structure Recap

Here's the final project structure for this lesson:

```
autogen_tutorial/
├── lesson5_specialized_agents/
│   ├── assistant_agent_example.py
│   ├── user_proxy_agent_example.py
│   ├── combined_agents_example.py
│   ├── custom_specialized_agent.py
│   ├── exercise_specialized_agents.py
│   └── requirements.txt
├── autogen/
│   └── agentchat/
│       ├── assistant_agent.py
│       └── user_proxy_agent.py
└── README.md
```

Make sure to keep your project organized and your code well-documented as you continue to explore and experiment with Autogen's specialized agents.


```

# agentchat\extra\lesson-5-specialized-agents.md

```
# Lesson 5: Specialized Agents - AssistantAgent and UserProxyAgent

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [AssistantAgent](#assistantagent)
   - [Overview](#assistantagent-overview)
   - [Key Features](#assistantagent-key-features)
   - [Implementation](#assistantagent-implementation)
   - [Example Usage](#assistantagent-example-usage)
4. [UserProxyAgent](#userproxyagent)
   - [Overview](#userproxyagent-overview)
   - [Key Features](#userproxyagent-key-features)
   - [Implementation](#userproxyagent-implementation)
   - [Example Usage](#userproxyagent-example-usage)
5. [Combining AssistantAgent and UserProxyAgent](#combining-agents)
6. [Customizing Specialized Agents](#customizing-agents)
7. [Exercise](#exercise)
8. [Summary](#summary)

## 1. Introduction <a name="introduction"></a>

In this lesson, we'll dive deep into two specialized agents provided by Autogen's AgentChat module: AssistantAgent and UserProxyAgent. These agents are designed to handle specific roles in conversational AI systems, offering enhanced functionality over the base ConversableAgent class.

We'll explore the implementation details of each agent, their unique features, and how to use them effectively in your projects. By the end of this lesson, you'll be able to create and customize these specialized agents for various applications.

## 2. Project Structure <a name="project-structure"></a>

Before we begin, let's set up our project structure for this lesson:

```
autogen_tutorial/
├── lesson5_specialized_agents/
│   ├── assistant_agent_example.py
│   ├── user_proxy_agent_example.py
│   ├── combined_agents_example.py
│   ├── custom_specialized_agent.py
│   └── requirements.txt
├── autogen/
│   └── agentchat/
│       ├── assistant_agent.py
│       └── user_proxy_agent.py
└── README.md
```

Make sure you have the necessary dependencies installed. Create a `requirements.txt` file in the `lesson5_specialized_agents` directory with the following content:

```
pyautogen==0.2.0
openai==0.27.8
```

Install the requirements using:

```bash
pip install -r requirements.txt
```

## 3. AssistantAgent <a name="assistantagent"></a>

### Overview <a name="assistantagent-overview"></a>

The AssistantAgent is a specialized version of the ConversableAgent designed to act as an AI assistant. It's pre-configured with settings suitable for most assistant-like tasks and can be easily customized for specific use cases.

### Key Features <a name="assistantagent-key-features"></a>

1. Pre-configured system message for assistant-like behavior
2. Built-in support for code execution (if configured)
3. Optimized for complex problem-solving tasks
4. Easy integration with language models like GPT-4

### Implementation <a name="assistantagent-implementation"></a>

Let's take a look at the key parts of the AssistantAgent implementation:

```python
# autogen/agentchat/assistant_agent.py

from typing import Dict, Optional, Union

from .conversable_agent import ConversableAgent

class AssistantAgent(ConversableAgent):
    DEFAULT_SYSTEM_MESSAGE = """You are a helpful AI assistant.
Solve tasks using your coding and language skills.
In the following cases, suggest python code (in a python coding block) or shell script (in a sh coding block) for the user to execute:
1. When you need to collect info, use the code to output the info you need, for example, browse or search the web, download/read a file, print the content of a webpage or a file, get the current date/time, check the operating system etc.
2. When you need to perform some task with code, use the code to perform the task and output the result.
Solve the task step by step if you need to. If a plan is not provided, explain your plan first. Be clear which step uses code, and which step uses your language skill.
When using code, you must indicate the script type in the code block. The user cannot provide any other feedback or perform any other action beyond executing the code you suggest. The user can't modify your code. So do not suggest incomplete code which requires users to modify. Don't use a code block if it's not intended to be executed by the user.
If you want the user to save the code in a file before executing it, put # filename: <filename> inside the code block as the first line.
Don't include multiple code blocks in one response. Do not ask users to copy and paste the result. Instead, use 'print' function for the output when relevant. Check the execution result returned by the user.
If the result indicates there is an error, fix the error and output the code again. Suggest the full code instead of partial code or code changes. If the error can't be fixed or if the task is not solved even after the code is executed successfully, analyze the problem, revisit your assumption, collect additional info you need, and think of a different approach to try.
When you find an answer, verify the answer carefully. Include verifiable evidence in your response if possible.
Reply "TERMINATE" in the end when everything is done.
"""

    def __init__(
        self,
        name: str,
        system_message: Optional[str] = DEFAULT_SYSTEM_MESSAGE,
        llm_config: Optional[Union[Dict, bool]] = None,
        **kwargs,
    ):
        super().__init__(
            name,
            system_message,
            llm_config=llm_config,
            **kwargs,
        )
```

The AssistantAgent class inherits from ConversableAgent and provides a default system message that defines its behavior. This system message instructs the agent to:

1. Solve tasks using coding and language skills
2. Suggest Python code or shell scripts when necessary
3. Break down complex tasks into steps
4. Handle code execution and error correction
5. Verify answers and provide evidence

### Example Usage <a name="assistantagent-example-usage"></a>

Let's create an example that demonstrates how to use the AssistantAgent:

```python
# lesson5_specialized_agents/assistant_agent_example.py

import autogen

# Configure the AI model
config_list = [
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here",
    }
]

# Create an AssistantAgent instance
assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={"config_list": config_list},
    system_message="You are a helpful AI assistant specializing in Python programming."
)

# Create a UserProxyAgent for human interaction
user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={"work_dir": "coding"}
)

# Start the conversation
user_proxy.initiate_chat(
    assistant,
    message="Can you help me write a Python function to calculate the factorial of a number?"
)
```

In this example, we create an AssistantAgent specialized in Python programming and a UserProxyAgent to simulate human interaction. The AssistantAgent will help write a Python function to calculate the factorial of a number.

## 4. UserProxyAgent <a name="userproxyagent"></a>

### Overview <a name="userproxyagent-overview"></a>

The UserProxyAgent is designed to represent a human user in the conversation. It can interact with other agents, execute code, and provide feedback to the system.

### Key Features <a name="userproxyagent-key-features"></a>

1. Ability to execute code and provide feedback
2. Support for different human input modes (ALWAYS, NEVER, TERMINATE)
3. Customizable code execution configuration
4. Flexible termination message handling

### Implementation <a name="userproxyagent-implementation"></a>

Let's examine the key parts of the UserProxyAgent implementation:

```python
# autogen/agentchat/user_proxy_agent.py

from typing import Callable, Dict, Optional, Union

from .conversable_agent import ConversableAgent

class UserProxyAgent(ConversableAgent):
    def __init__(
        self,
        name: str,
        human_input_mode: str = "ALWAYS",
        max_consecutive_auto_reply: Optional[int] = None,
        human_input_mode: Literal["ALWAYS", "TERMINATE", "NEVER"] = "TERMINATE",
        code_execution_config: Optional[Dict] = None,
        default_auto_reply: Optional[Union[str, Dict, None]] = "",
        is_termination_msg: Optional[Callable[[Dict], bool]] = None,
        **kwargs,
    ):
        super().__init__(
            name,
            max_consecutive_auto_reply=max_consecutive_auto_reply,
            human_input_mode=human_input_mode,
            system_message="""Human Admin/User.""",
            code_execution_config=code_execution_config,
            default_auto_reply=default_auto_reply,
            is_termination_msg=is_termination_msg,
            **kwargs,
        )
```

The UserProxyAgent class inherits from ConversableAgent and is configured to represent a human user. It supports different human input modes, code execution, and customizable termination message handling.

### Example Usage <a name="userproxyagent-example-usage"></a>

Let's create an example that demonstrates how to use the UserProxyAgent:

```python
# lesson5_specialized_agents/user_proxy_agent_example.py

import autogen

# Configure the AI model
config_list = [
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here",
    }
]

# Create an AssistantAgent instance
assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={"config_list": config_list},
)

# Create a UserProxyAgent for human interaction
user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={
        "work_dir": "coding",
        "use_docker": False,
    }
)

# Start the conversation
user_proxy.initiate_chat(
    assistant,
    message="Can you write a Python script that reads a CSV file and calculates the average of a specific column?"
)
```

In this example, we create a UserProxyAgent that can execute code and interact with an AssistantAgent. The UserProxyAgent is configured to terminate the conversation when the message ends with "TERMINATE" and has a specific code execution configuration.

## 5. Combining AssistantAgent and UserProxyAgent <a name="combining-agents"></a>

Now, let's create an example that combines both AssistantAgent and UserProxyAgent to solve a more complex task:

```python
# lesson5_specialized_agents/combined_agents_example.py

import autogen

# Configure the AI model
config_list = [
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here",
    }
]

# Create an AssistantAgent instance
assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={"config_list": config_list},
    system_message="You are a helpful AI assistant specializing in data analysis and visualization."
)

# Create a UserProxyAgent for human interaction
user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={
        "work_dir": "data_analysis",
        "use_docker": False,
    }
)

# Start the conversation
user_proxy.initiate_chat(
    assistant,
    message="""
    I have a CSV file named 'sales_data.csv' with columns 'Date', 'Product', 'Quantity', and 'Price'.
    Can you help me with the following tasks?
    1. Read the CSV file and calculate the total sales for each product.
    2. Create a bar plot showing the top 5 products by total sales.
    3. Save the plot as 'top_5_products.png'.
    """
)
```

In this example, we combine an AssistantAgent specialized in data analysis and visualization with a UserProxyAgent capable of executing code. The AssistantAgent will guide the process of analyzing the sales data and creating a visualization, while the UserProxyAgent will execute the necessary code.

## 6. Customizing Specialized Agents <a name="customizing-agents"></a>

Both AssistantAgent and UserProxyAgent can be customized to fit specific use cases. Here's an example of how to create a custom specialized agent:

```python
# lesson5_specialized_agents/custom_specialized_agent.py

import autogen

class CustomAssistantAgent(autogen.AssistantAgent):
    def __init__(self, name: str, specialized_skill: str, **kwargs):
        custom_system_message = f"""You are a helpful AI assistant specializing in {specialized_skill}.
        Use your expertise to provide detailed and accurate information and guidance in this area.
        When appropriate, suggest relevant resources or tools that can aid in solving problems related to {specialized_skill}."""
        
        super().__init__(name, system_message=custom_system_message, **kwargs)

    def analyze_problem(self, problem_description: str) -> str:
        """Custom method to analyze problems in the specialized area"""
        return self.generate_reply(messages=[{
            "role": "user",
            "content": f"Analyze the following problem in the context of {self.specialized_skill}: {problem_description}"
        }])

# Usage example
config_list = [
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here",
    }
]

custom_assistant = CustomAssistantAgent(
    name="AI_Machine_Learning_Expert",
    specialized_skill="machine learning",
    llm_config={"config_list": config_list},
)

user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
)

# Start the conversation
user_proxy.initiate_chat(
    custom_assistant,
    message="Can you help me understand the difference between supervised and unsupervised learning in machine learning?"
)

# Use the custom method
problem_analysis = custom_assistant.analyze_problem("I have a dataset of customer transactions and I want to identify unusual patterns. What machine learning approach should I use?")
print("Problem Analysis:", problem_analysis)
```

In this example, we create a CustomAssistantAgent that specializes in a specific skill and includes a custom method for problem analysis. This demonstrates how you can extend the functionality of specialized agents to fit your specific requirements.

## 7. Exercise <a name="exercise"></a>

Now it's your turn to practice working with specialized agents. Complete the following exercise:

1. Create a new file called `exercise_specialized_agents.py` in the `lesson5_specialized_agents` directory.
2. Implement a scenario where an AssistantAgent helps a UserProxyAgent perform the following tasks:
   a. Web scrape the current weather information for a given city using the
```

# agentchat\extra\lesson-7-contributed-agents-part-1.md

```
# Lesson 7: Contributed Agents and Utilities (Part 1)

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Overview of the contrib folder](#overview-of-the-contrib-folder)
4. [Agent Builder](#agent-builder)
5. [GPT Assistant Agent](#gpt-assistant-agent)
6. [Image Utilities](#image-utilities)
7. [Practical Examples](#practical-examples)
8. [Exercise](#exercise)
9. [Summary](#summary)

## 1. Introduction

In this lesson, we'll explore the `contrib` folder of the AgentChat module in Autogen. This folder contains various extensions and specialized agents that can enhance your AI applications. We'll focus on three key components:

1. Agent Builder
2. GPT Assistant Agent
3. Image Utilities

These tools provide additional flexibility and capabilities to your Autogen-based projects, allowing you to create more sophisticated and specialized AI agents.

## 2. Project Structure

Let's set up our project structure for this lesson:

```
autogen_tutorial/
├── lesson7_contrib_agents/
│   ├── agent_builder_example.py
│   ├── gpt_assistant_example.py
│   ├── image_utils_example.py
│   ├── combined_example.py
│   └── requirements.txt
├── data/
│   ├── sample_image.jpg
│   └── agent_configs.json
└── README.md
```

Ensure you have the required dependencies installed:

```bash
pip install -r lesson7_contrib_agents/requirements.txt
```

## 3. Overview of the contrib folder

The `contrib` folder in the AgentChat module contains various contributed agents and utilities. Here's a brief overview of its structure:

```
autogen/agentchat/contrib/
├── __init__.py
├── agent_builder.py
├── gpt_assistant_agent.py
├── img_utils.py
└── ...
```

In this lesson, we'll focus on `agent_builder.py`, `gpt_assistant_agent.py`, and `img_utils.py`.

## 4. Agent Builder

The Agent Builder provides functionality to dynamically create and configure agents. It's particularly useful when you need to create multiple agents with different configurations or when you want to generate agents based on runtime conditions.

Key features of the Agent Builder include:
- Dynamic agent creation
- Configuration management
- Agent customization

Let's look at an example of how to use the Agent Builder:

```python
# agent_builder_example.py

from autogen.agentchat.contrib.agent_builder import AgentBuilder
import json

# Load agent configurations from a JSON file
with open('data/agent_configs.json', 'r') as f:
    agent_configs = json.load(f)

# Create an AgentBuilder instance
builder = AgentBuilder()

# Create agents based on the configurations
agents = []
for config in agent_configs:
    agent = builder.create_agent(
        name=config['name'],
        agent_type=config['type'],
        system_message=config['system_message'],
        llm_config=config['llm_config']
    )
    agents.append(agent)

# Use the created agents
for agent in agents:
    print(f"Agent: {agent.name}")
    response = agent.generate_response("Hello! What can you do?")
    print(f"Response: {response}")
    print()
```

In this example, we load agent configurations from a JSON file and use the AgentBuilder to create multiple agents with different settings. This approach allows for flexible and dynamic agent creation based on external configurations or runtime conditions.

## 5. GPT Assistant Agent

The GPT Assistant Agent is a specialized agent that leverages OpenAI's GPT models. It provides a more streamlined interface for creating assistants based on these powerful language models.

Key features of the GPT Assistant Agent include:
- Easy integration with OpenAI's API
- Customizable system messages
- Handling of conversation context

Here's an example of how to use the GPT Assistant Agent:

```python
# gpt_assistant_example.py

from autogen.agentchat.contrib.gpt_assistant_agent import GPTAssistantAgent
from autogen import UserProxyAgent

# Create a GPT Assistant Agent
assistant = GPTAssistantAgent(
    name="DataAnalysisExpert",
    instructions="You are an AI assistant specialized in data analysis. Provide insights and answer questions about data.",
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7,
    }
)

# Create a user proxy for interaction
user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=1,
    is_termination_msg=lambda x: "TERMINATE" in x.get("content", "").upper(),
)

# Start a conversation
user_proxy.initiate_chat(
    assistant,
    message="I have a dataset of customer purchases. How can I identify the most valuable customers?"
)
```

This example demonstrates how to create a GPT Assistant Agent specialized in data analysis and interact with it using a UserProxyAgent.

## 6. Image Utilities

The Image Utilities provide functions for handling images in agent conversations. These utilities are particularly useful when working with multimodal agents or when you need to process image data within your AI system.

Key functionalities of the Image Utilities include:
- Image loading and processing
- Conversion between different image formats
- Integration of images in agent messages

Let's look at an example of how to use the Image Utilities:

```python
# image_utils_example.py

from autogen.agentchat.contrib.img_utils import get_image_data, is_image
from autogen.agentchat.contrib.multimodal_conversable_agent import MultimodalConversableAgent
from autogen import UserProxyAgent

# Function to create a message with an image
def create_image_message(image_path, caption):
    image_data = get_image_data(image_path)
    return {
        "content": caption,
        "image": image_data
    }

# Create a multimodal agent capable of processing images
image_analyst = MultimodalConversableAgent(
    name="ImageAnalyst",
    llm_config={
        "model": "gpt-4-vision-preview",
        "temperature": 0.7,
    },
    system_message="You are an AI assistant capable of analyzing images and providing insights."
)

# Create a user proxy for interaction
user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=1,
    is_termination_msg=lambda x: "TERMINATE" in x.get("content", "").upper(),
)

# Create a message with an image
image_message = create_image_message(
    'data/sample_image.jpg',
    "Analyze this image and describe what you see."
)

# Start a conversation with the image message
user_proxy.initiate_chat(
    image_analyst,
    message=image_message
)
```

This example shows how to use the Image Utilities to load an image, create a message with image data, and use it in a conversation with a multimodal agent capable of analyzing images.

## 7. Practical Examples

Now, let's combine these contributed agents and utilities into a more complex example:

```python
# combined_example.py

from autogen.agentchat.contrib.agent_builder import AgentBuilder
from autogen.agentchat.contrib.gpt_assistant_agent import GPTAssistantAgent
from autogen.agentchat.contrib.img_utils import get_image_data
from autogen import UserProxyAgent

# Create an AgentBuilder
builder = AgentBuilder()

# Create a GPT Assistant Agent for data analysis
data_analyst = builder.create_agent(
    name="DataAnalyst",
    agent_type=GPTAssistantAgent,
    instructions="You are an AI assistant specialized in data analysis and visualization.",
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7,
    }
)

# Create a GPT Assistant Agent for image analysis
image_analyst = builder.create_agent(
    name="ImageAnalyst",
    agent_type=GPTAssistantAgent,
    instructions="You are an AI assistant specialized in analyzing images and providing insights.",
    llm_config={
        "model": "gpt-4-vision-preview",
        "temperature": 0.7,
    }
)

# Create a user proxy for interaction
user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=1,
    is_termination_msg=lambda x: "TERMINATE" in x.get("content", "").upper(),
)

# Function to create a message with an image
def create_image_message(image_path, caption):
    image_data = get_image_data(image_path)
    return {
        "content": caption,
        "image": image_data
    }

# Start a conversation with the data analyst
user_proxy.initiate_chat(
    data_analyst,
    message="I have sales data for the past year. Can you suggest some visualizations that would be helpful?"
)

# Start a conversation with the image analyst
image_message = create_image_message(
    'data/sample_image.jpg',
    "This is a chart of our sales data. Can you analyze it and provide insights?"
)
user_proxy.initiate_chat(
    image_analyst,
    message=image_message
)
```

This combined example demonstrates how to use the Agent Builder to create specialized GPT Assistant Agents for different tasks, and how to incorporate image analysis using the Image Utilities.

## 8. Exercise

Now it's your turn to practice! Create a system that combines the Agent Builder, GPT Assistant Agent, and Image Utilities to solve a real-world problem. Here's your task:

1. Use the Agent Builder to create three agents:
   - A data analysis expert
   - An image recognition specialist
   - A report generation assistant

2. Implement a workflow that:
   - Analyzes a dataset (you can use a sample dataset or generate one)
   - Processes an image related to the data (e.g., a chart or graph)
   - Generates a comprehensive report combining insights from both the data and image analysis

3. Use the Image Utilities to handle the image processing and inclusion in messages

4. Create a main script that orchestrates the interaction between these agents and a user proxy

Be creative with your implementation and think about how these tools can be combined to solve complex, multi-step problems.

## 9. Summary

In this lesson, we've explored key components of the `contrib` folder in Autogen's AgentChat module:

1. The Agent Builder, which allows for dynamic creation and configuration of agents
2. The GPT Assistant Agent, a specialized agent leveraging OpenAI's powerful language models
3. Image Utilities, providing tools for handling and processing images in agent conversations

These contributed agents and utilities extend the capabilities of Autogen, allowing for more flexible, powerful, and specialized AI systems. By combining these tools, you can create sophisticated applications that handle complex tasks involving data analysis, image processing, and natural language interaction.

In the next lesson, we'll continue our exploration of the `contrib` folder, focusing on additional specialized agents and advanced capabilities.

```

# logger\autogen-logger-series.md

```
Certainly! I'd be happy to create a series of lessons to explain the logger implementation in the Autogen project. Based on the provided information about the logger folder, I'll plan a small series of explanatory lessons to help developers understand the details of the implementation. Let's break this down into several lessons:

# Logger Lesson Series: Understanding Autogen's Logging System

1. Lesson 1: Introduction to Autogen's Logging System
2. Lesson 2: The BaseLogger Abstract Class
3. Lesson 3: Implementing File-based Logging with FileLogger
4. Lesson 4: SQLite-based Logging with SqliteLogger
5. Lesson 5: The LoggerFactory and Practical Usage

Let's start with an outline for the first lesson:

Lesson 1: Introduction to Autogen's Logging System

1. Overview of Autogen's Logging System
2. Project Structure
3. Key Components
4. Logging Capabilities
5. Use Cases and Benefits

---


```

# logger\Lesson 1 Introduction to Autogen's Logging System.md

```
# Lesson 1: Introduction to Autogen's Logging System

## 1. Overview of Autogen's Logging System

Autogen's logging system is a flexible and extensible framework designed to capture various events and interactions within the Autogen ecosystem. It provides developers with valuable insights into the behavior of agents, chat completions, and other critical components of the system.

## 2. Project Structure

The logging system is organized within the `logger` folder of the Autogen project. Here's the structure of the logger component:

```
autogen/
└── logger/
    ├── __init__.py
    ├── base_logger.py
    ├── file_logger.py
    ├── logger_factory.py
    ├── logger_utils.py
    └── sqlite_logger.py
```

This structure allows for easy extension and maintenance of the logging system.

## 3. Key Components

The logging system consists of several key components:

1. `BaseLogger`: An abstract base class that defines the interface for all logger implementations.
2. `FileLogger`: A concrete implementation that logs events to a file.
3. `SqliteLogger`: A concrete implementation that logs events to a SQLite database.
4. `LoggerFactory`: A factory class for creating logger instances.
5. `logger_utils.py`: A collection of utility functions used across the logging system.

## 4. Logging Capabilities

Autogen's logging system can capture various types of events, including:

- Chat completions
- Creation of new agents
- Custom events
- Creation of new OpenAI wrappers and clients
- Function calls

These capabilities allow developers to track and analyze the behavior of their Autogen-based applications in detail.

## 5. Use Cases and Benefits

The logging system provides several benefits for developers:

1. **Debugging**: Easily trace the flow of conversations and agent interactions.
2. **Performance Analysis**: Monitor the cost and timing of API calls.
3. **Behavioral Analysis**: Understand how agents make decisions and interact with each other.
4. **Compliance**: Keep records of AI interactions for auditing purposes.
5. **Optimization**: Identify areas for improvement in agent configurations and prompts.

Example: Basic usage of the logging system

```python
from autogen import LoggerFactory

# Create a logger instance
logger = LoggerFactory.get_logger(logger_type="sqlite")

# Start the logging session
session_id = logger.start()

# Log a custom event
logger.log_event(source="MyAgent", name="custom_event", data={"key": "value"})

# Stop the logging session
logger.stop()
```

This example demonstrates how to create a logger, start a session, log a custom event, and stop the session.

In the upcoming lessons, we'll dive deeper into each component of the logging system, exploring their implementations and usage in detail.

---

This first lesson provides an overview of Autogen's logging system, introducing its structure, key components, capabilities, and benefits. In the next lesson, we'll explore the `BaseLogger` abstract class, which forms the foundation of the logging system.
```

# logger\lesson-2-baselogger.md

```
# Lesson 2: The BaseLogger Abstract Class

## 1. Introduction to BaseLogger

The `BaseLogger` abstract class is the foundation of Autogen's logging system. It defines the interface that all concrete logger implementations must adhere to. By using an abstract base class, Autogen ensures consistency across different logging implementations while allowing for flexibility in how logging is actually performed.

## 2. Project Structure

Let's revisit where `BaseLogger` fits in the project structure:

```
autogen/
└── logger/
    ├── __init__.py
    ├── base_logger.py  <- We are here
    ├── file_logger.py
    ├── logger_factory.py
    ├── logger_utils.py
    └── sqlite_logger.py
```

## 3. BaseLogger Class Definition

Here's the basic structure of the `BaseLogger` class:

```python
from abc import ABC, abstractmethod

class BaseLogger(ABC):
    @abstractmethod
    def start(self) -> str:
        ...

    @abstractmethod
    def log_chat_completion(self, ...):
        ...

    @abstractmethod
    def log_new_agent(self, agent: ConversableAgent, init_args: Dict[str, Any]) -> None:
        ...

    @abstractmethod
    def log_event(self, source: Union[str, Agent], name: str, **kwargs: Dict[str, Any]) -> None:
        ...

    @abstractmethod
    def log_new_wrapper(self, wrapper: OpenAIWrapper, init_args: Dict[str, Union[LLMConfig, List[LLMConfig]]]) -> None:
        ...

    @abstractmethod
    def log_new_client(self, client: Union[AzureOpenAI, OpenAI], wrapper: OpenAIWrapper, init_args: Dict[str, Any]) -> None:
        ...

    @abstractmethod
    def log_function_use(self, source: Union[str, Agent], function: F, args: Dict[str, Any], returns: Any) -> None:
        ...

    @abstractmethod
    def stop(self) -> None:
        ...

    @abstractmethod
    def get_connection(self) -> Union[None, sqlite3.Connection]:
        ...
```

## 4. Key Methods

Let's break down the key methods of the `BaseLogger` class:

### 4.1 start()

- Purpose: Initializes the logging session.
- Returns: A unique session ID as a string.

### 4.2 log_chat_completion()

- Purpose: Logs details of a chat completion.
- Parameters include:
  - invocation_id: Unique identifier for the OpenAIWrapper.create method call
  - client_id: Identifier for the OpenAI client instance
  - wrapper_id: Identifier for the OpenAIWrapper instance
  - source: The source of the event (either a string or an Agent)
  - request: The request sent to the OpenAI API
  - response: The response received from OpenAI
  - is_cached: Whether the response was cached
  - cost: The cost of the API call
  - start_time: When the request was initiated

### 4.3 log_new_agent()

- Purpose: Logs the creation of a new agent.
- Parameters:
  - agent: The ConversableAgent instance
  - init_args: Arguments used to initialize the agent

### 4.4 log_event()

- Purpose: Logs a custom event.
- Parameters:
  - source: The source of the event (either a string or an Agent)
  - name: The name of the event
  - **kwargs: Additional event details

### 4.5 log_new_wrapper()

- Purpose: Logs the creation of a new OpenAIWrapper.
- Parameters:
  - wrapper: The OpenAIWrapper instance
  - init_args: Arguments used to initialize the wrapper

### 4.6 log_new_client()

- Purpose: Logs the creation of a new OpenAI client.
- Parameters:
  - client: The OpenAI client instance
  - wrapper: The associated OpenAIWrapper instance
  - init_args: Arguments used to initialize the client

### 4.7 log_function_use()

- Purpose: Logs the use of a registered function (could be a tool).
- Parameters:
  - source: The source of the function call (either a string or an Agent)
  - function: The function that was called
  - args: Arguments passed to the function
  - returns: The return value of the function

### 4.8 stop()

- Purpose: Stops the logging session and performs any necessary cleanup.

### 4.9 get_connection()

- Purpose: Returns a connection to the logging database (if applicable).
- Returns: A SQLite connection object or None.

## 5. Usage Example

Here's a simple example of how a concrete logger implementation might use the `BaseLogger` class:

```python
from autogen.logger import BaseLogger

class MyCustomLogger(BaseLogger):
    def __init__(self):
        self.logs = []

    def start(self) -> str:
        session_id = generate_unique_id()  # Implement this function
        self.logs.append(f"Started session: {session_id}")
        return session_id

    def log_event(self, source: Union[str, Agent], name: str, **kwargs: Dict[str, Any]) -> None:
        event_details = f"Event: {name}, Source: {source}, Details: {kwargs}"
        self.logs.append(event_details)

    # Implement other abstract methods...

    def stop(self) -> None:
        self.logs.append("Logging session stopped")

    def get_connection(self) -> None:
        return None  # This logger doesn't use a database connection
```

This example shows a basic in-memory logger that implements the `BaseLogger` interface. In practice, you would implement all the abstract methods to create a fully functional logger.

## 6. Conclusion

The `BaseLogger` abstract class provides a solid foundation for Autogen's logging system. By defining a common interface, it ensures that all logger implementations can be used interchangeably within the Autogen ecosystem. This design allows for easy extension of the logging system to support different storage backends or logging formats while maintaining a consistent API for the rest of the application to interact with.

In the next lesson, we'll explore the `FileLogger` class, which provides a concrete implementation of the `BaseLogger` interface for logging to files.


```

# logger\lesson-3-filelogger.md

```
# Lesson 3: Implementing File-based Logging with FileLogger

## 1. Introduction to FileLogger

The `FileLogger` class is a concrete implementation of the `BaseLogger` abstract class. It provides a mechanism for logging Autogen events to a file, which is useful for persistent storage and easy review of logs.

## 2. Project Structure

Let's look at where `FileLogger` fits in the project structure:

```
autogen/
└── logger/
    ├── __init__.py
    ├── base_logger.py
    ├── file_logger.py  <- We are here
    ├── logger_factory.py
    ├── logger_utils.py
    └── sqlite_logger.py
```

## 3. FileLogger Class Overview

The `FileLogger` class is defined in `file_logger.py`. Here's a simplified version of its structure:

```python
import json
import logging
import os
import threading
import uuid
from typing import Any, Dict, Union

from autogen.logger.base_logger import BaseLogger
from autogen.logger.logger_utils import get_current_ts, to_dict

class FileLogger(BaseLogger):
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.session_id = str(uuid.uuid4())
        self.log_dir = os.path.join(os.getcwd(), "autogen_logs")
        os.makedirs(self.log_dir, exist_ok=True)
        self.log_file = os.path.join(self.log_dir, self.config.get("filename", "runtime.log"))
        # ... (setup logger)

    def start(self) -> str:
        # ... (implementation)

    def log_chat_completion(self, ...):
        # ... (implementation)

    def log_new_agent(self, agent: ConversableAgent, init_args: Dict[str, Any] = {}):
        # ... (implementation)

    def log_event(self, source: Union[str, Agent], name: str, **kwargs: Dict[str, Any]):
        # ... (implementation)

    def log_new_wrapper(self, wrapper: OpenAIWrapper, init_args: Dict[str, Union[LLMConfig, List[LLMConfig]]] = {}):
        # ... (implementation)

    def log_new_client(self, client: Union[AzureOpenAI, OpenAI], wrapper: OpenAIWrapper, init_args: Dict[str, Any]):
        # ... (implementation)

    def log_function_use(self, source: Union[str, Agent], function: F, args: Dict[str, Any], returns: Any):
        # ... (implementation)

    def stop(self):
        # ... (implementation)

    def get_connection(self) -> None:
        pass
```

## 4. Key Features of FileLogger

### 4.1 Initialization

The `FileLogger` is initialized with a configuration dictionary. It sets up a logging directory and file, and creates a unique session ID.

```python
def __init__(self, config: Dict[str, Any]):
    self.config = config
    self.session_id = str(uuid.uuid4())
    self.log_dir = os.path.join(os.getcwd(), "autogen_logs")
    os.makedirs(self.log_dir, exist_ok=True)
    self.log_file = os.path.join(self.log_dir, self.config.get("filename", "runtime.log"))
    # ... (setup logger)
```

### 4.2 Logging Format

The `FileLogger` uses JSON formatting for log entries, which makes it easy to parse and analyze logs programmatically.

### 4.3 Thread Safety

The `FileLogger` uses Python's built-in `logging` module, which is thread-safe, allowing for use in multi-threaded environments.

## 5. Implementing BaseLogger Methods

Let's look at how `FileLogger` implements some of the key methods from `BaseLogger`:

### 5.1 start()

```python
def start(self) -> str:
    try:
        self.logger.info(f"Started new session with Session ID: {self.session_id}")
    except Exception as e:
        logger.error(f"[file_logger] Failed to create logging file: {e}")
    finally:
        return self.session_id
```

This method logs the start of a new session and returns the session ID.

### 5.2 log_chat_completion()

```python
def log_chat_completion(self, invocation_id: uuid.UUID, client_id: int, wrapper_id: int, source: Union[str, Agent],
                        request: Dict[str, Union[float, str, List[Dict[str, str]]]], response: Union[str, ChatCompletion],
                        is_cached: int, cost: float, start_time: str) -> None:
    thread_id = threading.get_ident()
    source_name = source.name if hasattr(source, 'name') else source
    try:
        log_data = json.dumps({
            "invocation_id": str(invocation_id),
            "client_id": client_id,
            "wrapper_id": wrapper_id,
            "request": to_dict(request),
            "response": str(response),
            "is_cached": is_cached,
            "cost": cost,
            "start_time": start_time,
            "end_time": get_current_ts(),
            "thread_id": thread_id,
            "source_name": source_name,
        })
        self.logger.info(log_data)
    except Exception as e:
        self.logger.error(f"[file_logger] Failed to log chat completion: {e}")
```

This method logs details of a chat completion, including request and response data, timing, and cost.

## 6. Error Handling

The `FileLogger` includes robust error handling to ensure that logging failures don't disrupt the main application flow. For example:

```python
try:
    # ... (logging logic)
except Exception as e:
    self.logger.error(f"[file_logger] Failed to log event: {e}")
```

## 7. Usage Example

Here's an example of how to use the `FileLogger`:

```python
from autogen import LoggerFactory

# Create a FileLogger instance
config = {"filename": "my_logs.log"}
logger = LoggerFactory.get_logger(logger_type="file", config=config)

# Start the logging session
session_id = logger.start()

# Log a custom event
logger.log_event(source="MyAgent", name="custom_event", data={"key": "value"})

# Log a chat completion
logger.log_chat_completion(
    invocation_id=uuid.uuid4(),
    client_id=1,
    wrapper_id=1,
    source="MyAgent",
    request={"prompt": "Hello, world!"},
    response="Hi there!",
    is_cached=0,
    cost=0.001,
    start_time="2023-09-17 10:00:00.000000"
)

# Stop the logging session
logger.stop()
```

This example demonstrates creating a `FileLogger`, starting a session, logging various events, and stopping the session.

## 8. Advantages and Considerations

Advantages of `FileLogger`:
1. Simple setup and usage
2. Persistent storage of logs
3. Easy to read and analyze manually
4. JSON formatting allows for programmatic analysis

Considerations:
1. File I/O can be slower than in-memory logging
2. May require log rotation for long-running applications
3. Not suitable for distributed systems without additional setup

## 9. Conclusion

The `FileLogger` provides a straightforward implementation of the `BaseLogger` interface, offering file-based logging for Autogen applications. Its use of JSON formatting and robust error handling make it a reliable choice for many use cases. However, for applications with high-volume logging or distributed architectures, other logging solutions might be more appropriate.

In the next lesson, we'll explore the `SqliteLogger`, which offers a database-backed alternative to file-based logging.


```

# logger\lesson-4-sqlitelogger.md

```
# Lesson 4: SQLite-based Logging with SqliteLogger

## 1. Introduction to SqliteLogger

The `SqliteLogger` class is another concrete implementation of the `BaseLogger` abstract class. It provides a mechanism for logging Autogen events to a SQLite database, which offers structured storage and efficient querying capabilities.

## 2. Project Structure

Let's revisit where `SqliteLogger` fits in the project structure:

```
autogen/
└── logger/
    ├── __init__.py
    ├── base_logger.py
    ├── file_logger.py
    ├── logger_factory.py
    ├── logger_utils.py
    └── sqlite_logger.py  <- We are here
```

## 3. SqliteLogger Class Overview

The `SqliteLogger` class is defined in `sqlite_logger.py`. Here's a simplified version of its structure:

```python
import json
import logging
import sqlite3
import threading
import uuid
from typing import Any, Dict, Union

from autogen.logger.base_logger import BaseLogger
from autogen.logger.logger_utils import get_current_ts, to_dict

class SqliteLogger(BaseLogger):
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.dbname = self.config.get("dbname", "logs.db")
        self.con = sqlite3.connect(self.dbname, check_same_thread=False)
        self.cur = self.con.cursor()
        self.session_id = str(uuid.uuid4())

    def start(self) -> str:
        # ... (implementation)

    def log_chat_completion(self, ...):
        # ... (implementation)

    def log_new_agent(self, agent: ConversableAgent, init_args: Dict[str, Any] = {}):
        # ... (implementation)

    def log_event(self, source: Union[str, Agent], name: str, **kwargs: Dict[str, Any]):
        # ... (implementation)

    def log_new_wrapper(self, wrapper: OpenAIWrapper, init_args: Dict[str, Union[LLMConfig, List[LLMConfig]]] = {}):
        # ... (implementation)

    def log_new_client(self, client: Union[AzureOpenAI, OpenAI], wrapper: OpenAIWrapper, init_args: Dict[str, Any]):
        # ... (implementation)

    def log_function_use(self, source: Union[str, Agent], function: F, args: Dict[str, Any], returns: Any):
        # ... (implementation)

    def stop(self):
        # ... (implementation)

    def get_connection(self) -> Union[None, sqlite3.Connection]:
        # ... (implementation)

    def _run_query(self, query: str, args: Tuple[Any, ...] = ()):
        # ... (implementation)
```

## 4. Key Features of SqliteLogger

### 4.1 Initialization

The `SqliteLogger` is initialized with a configuration dictionary. It sets up a connection to a SQLite database and creates a unique session ID.

```python
def __init__(self, config: Dict[str, Any]):
    self.config = config
    self.dbname = self.config.get("dbname", "logs.db")
    self.con = sqlite3.connect(self.dbname, check_same_thread=False)
    self.cur = self.con.cursor()
    self.session_id = str(uuid.uuid4())
```

### 4.2 Database Schema

The `SqliteLogger` sets up several tables to store different types of logs:

- `chat_completions`: Stores details of chat completion calls
- `agents`: Stores information about created agents
- `oai_wrappers`: Stores information about OpenAI wrappers
- `oai_clients`: Stores information about OpenAI clients
- `events`: Stores custom events
- `function_calls`: Stores information about function calls

### 4.3 Thread Safety

The `SqliteLogger` uses a lock to ensure thread-safe database operations:

```python
lock = threading.Lock()

def _run_query(self, query: str, args: Tuple[Any, ...] = ()):
    try:
        with lock:
            self.cur.execute(query, args)
            self.con.commit()
    except Exception as e:
        logger.error("[sqlite logger]Error running query with query %s and args %s: %s", query, args, e)
```

## 5. Implementing BaseLogger Methods

Let's look at how `SqliteLogger` implements some of the key methods from `BaseLogger`:

### 5.1 start()

```python
def start(self) -> str:
    try:
        # Create tables if they don't exist
        self._run_query("""
            CREATE TABLE IF NOT EXISTS chat_completions(
                id INTEGER PRIMARY KEY,
                invocation_id TEXT,
                client_id INTEGER,
                wrapper_id INTEGER,
                session_id TEXT,
                source_name TEXT,
                request TEXT,
                response TEXT,
                is_cached INTEGER,
                cost REAL,
                start_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                end_time DATETIME DEFAULT CURRENT_TIMESTAMP)
        """)
        # ... (create other tables)
    except sqlite3.Error as e:
        logger.error(f"[SqliteLogger] start logging error: {e}")
    finally:
        return self.session_id
```

This method sets up the necessary database tables and returns the session ID.

### 5.2 log_chat_completion()

```python
def log_chat_completion(self, invocation_id: uuid.UUID, client_id: int, wrapper_id: int, source: Union[str, Agent],
                        request: Dict[str, Union[float, str, List[Dict[str, str]]]], response: Union[str, ChatCompletion],
                        is_cached: int, cost: float, start_time: str) -> None:
    end_time = get_current_ts()
    
    response_messages = json.dumps({"response": response}) if response is None or isinstance(response, str) else json.dumps(to_dict(response), indent=4)
    
    source_name = source if isinstance(source, str) else source.name

    query = """
        INSERT INTO chat_completions (
            invocation_id, client_id, wrapper_id, session_id, request, response, is_cached, cost, start_time, end_time, source_name
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """
    args = (str(invocation_id), client_id, wrapper_id, self.session_id, json.dumps(request), response_messages, is_cached, cost, start_time, end_time, source_name)

    self._run_query(query=query, args=args)
```

This method logs details of a chat completion to the `chat_completions` table.

## 6. Error Handling and Migration

The `SqliteLogger` includes error handling and a basic migration system:

```python
def _apply_migration(self, migrations_dir: str = "./migrations") -> None:
    current_version = self._get_current_db_version()
    current_version = SqliteLogger.schema_version if current_version is None else current_version

    if os.path.isdir(migrations_dir):
        migrations = sorted(os.listdir(migrations_dir))
    else:
        logger.info("no migration scripts, skip...")
        return

    migrations_to_apply = [m for m in migrations if int(m.split("_")[0]) > current_version]

    for script in migrations_to_apply:
        with open(script, "r") as f:
            migration_sql = f.read()
            self._run_query_script(script=migration_sql)

            latest_version = int(script.split("_")[0])
            query = "UPDATE version SET version_number = ? WHERE id = 1"
            args = (latest_version,)
            self._run_query(query=query, args=args)
```

This method allows for future schema updates without breaking existing logs.

## 7. Usage Example

Here's an example of how to use the `SqliteLogger`:

```python
from autogen import LoggerFactory

# Create a SqliteLogger instance
config = {"dbname": "my_logs.db"}
logger = LoggerFactory.get_logger(logger_type="sqlite", config=config)

# Start the logging session
session_id = logger.start()

# Log a custom event
logger.log_event(source="MyAgent", name="custom_event", data={"key": "value"})

# Log a chat completion
logger.log_chat_completion(
    invocation_id=uuid.uuid4(),
    client_id=1,
    wrapper_id=1,
    source="MyAgent",
    request={"prompt": "Hello, world!"},
    response="Hi there!",
    is_cached=0,
    cost=0.001,
    start_time="2023-09-17 10:00:00.000000"
)

# Stop the logging session
logger.stop()
```

This example demonstrates creating a `SqliteLogger`, starting a session, logging various events, and stopping the session.

## 8. Advantages and Considerations

Advantages of `SqliteLogger`:
1. Structured data storage
2. Efficient querying capabilities
3. Supports complex data relationships
4. Built-in support for concurrent access

Considerations:
1. Requires SQLite to be installed
2. May have slower write performance compared to file-based logging for very high volume logging
3. Requires database management (e.g., periodic vacuuming)

## 9. Conclusion

The `SqliteLogger` provides a robust, database-backed implementation of the `BaseLogger` interface. It offers structured storage and efficient querying capabilities, making it suitable for applications that require complex log analysis or high-volume logging. Its use of SQLite makes it portable and easy to set up, while still providing many of the benefits of a full-fledged database system.

In the next and final lesson, we'll explore the `LoggerFactory` class and discuss practical usage patterns for the Autogen logging system.


```

# logger\lesson-5-loggerfactory-and-usage.md

```
# Lesson 5: The LoggerFactory and Practical Usage

## 1. Introduction to LoggerFactory

The `LoggerFactory` class in Autogen provides a simple and flexible way to create logger instances. It acts as an abstraction layer, allowing developers to switch between different logging implementations without changing their application code.

## 2. Project Structure

Let's revisit where `LoggerFactory` fits in the project structure:

```
autogen/
└── logger/
    ├── __init__.py
    ├── base_logger.py
    ├── file_logger.py
    ├── logger_factory.py  <- We are here
    ├── logger_utils.py
    └── sqlite_logger.py
```

## 3. LoggerFactory Implementation

The `LoggerFactory` is implemented as a static class in `logger_factory.py`. Here's its implementation:

```python
from typing import Any, Dict, Literal, Optional

from autogen.logger.base_logger import BaseLogger
from autogen.logger.file_logger import FileLogger
from autogen.logger.sqlite_logger import SqliteLogger

class LoggerFactory:
    @staticmethod
    def get_logger(
        logger_type: Literal["sqlite", "file"] = "sqlite",
        config: Optional[Dict[str, Any]] = None
    ) -> BaseLogger:
        if config is None:
            config = {}

        if logger_type == "sqlite":
            return SqliteLogger(config)
        elif logger_type == "file":
            return FileLogger(config)
        else:
            raise ValueError(f"[logger_factory] Unknown logger type: {logger_type}")
```

This implementation allows for easy extension to support additional logger types in the future.

## 4. Using LoggerFactory

Here's how to use the `LoggerFactory` to create logger instances:

```python
from autogen import LoggerFactory

# Create a SQLite logger
sqlite_logger = LoggerFactory.get_logger(logger_type="sqlite", config={"dbname": "my_logs.db"})

# Create a File logger
file_logger = LoggerFactory.get_logger(logger_type="file", config={"filename": "my_logs.log"})
```

## 5. Practical Usage Patterns

Let's explore some practical usage patterns for the Autogen logging system.

### 5.1 Logging in a Simple Agent Interaction

```python
from autogen import ConversableAgent, OpenAIWrapper, LoggerFactory

# Create a logger
logger = LoggerFactory.get_logger(logger_type="sqlite")

# Start the logging session
session_id = logger.start()

# Create an OpenAI wrapper
oai_wrapper = OpenAIWrapper()
logger.log_new_wrapper(oai_wrapper, {"config_list": [{"model": "gpt-3.5-turbo"}]})

# Create agents
assistant = ConversableAgent("assistant", llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]})
user = ConversableAgent("user")

logger.log_new_agent(assistant, {"name": "assistant", "llm_config": {"config_list": [{"model": "gpt-3.5-turbo"}]}})
logger.log_new_agent(user, {"name": "user"})

# Simulate a conversation
user_message = "Hello, can you help me with a math problem?"
logger.log_event(user, "send_message", message=user_message)

assistant_response = assistant.generate_reply(user_message)
logger.log_event(assistant, "generate_reply", message=assistant_response)

# Stop the logging session
logger.stop()
```

### 5.2 Logging in a Group Chat Scenario

```python
from autogen import ConversableAgent, GroupChat, GroupChatManager, LoggerFactory

# Create a logger
logger = LoggerFactory.get_logger(logger_type="file", config={"filename": "group_chat_logs.log"})

# Start the logging session
session_id = logger.start()

# Create agents
user_proxy = ConversableAgent("user_proxy")
assistant1 = ConversableAgent("assistant1", llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]})
assistant2 = ConversableAgent("assistant2", llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]})

logger.log_new_agent(user_proxy, {"name": "user_proxy"})
logger.log_new_agent(assistant1, {"name": "assistant1", "llm_config": {"config_list": [{"model": "gpt-3.5-turbo"}]}})
logger.log_new_agent(assistant2, {"name": "assistant2", "llm_config": {"config_list": [{"model": "gpt-3.5-turbo"}]}})

# Create a group chat
groupchat = GroupChat(agents=[user_proxy, assistant1, assistant2], messages=[], max_round=10)
manager = GroupChatManager(groupchat=groupchat, llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]})

logger.log_event("system", "create_group_chat", agents=[agent.name for agent in groupchat.agents])

# Initiate the group chat
user_proxy.initiate_chat(
    manager,
    message="Let's discuss the pros and cons of renewable energy sources."
)

# Log the entire conversation
for message in groupchat.messages:
    logger.log_event(message["sender"], "group_chat_message", content=message["content"])

# Stop the logging session
logger.stop()
```

### 5.3 Logging Custom Events and Function Calls

```python
from autogen import ConversableAgent, LoggerFactory

def custom_function(x: int, y: int) -> int:
    return x + y

# Create a logger
logger = LoggerFactory.get_logger(logger_type="sqlite", config={"dbname": "function_logs.db"})

# Start the logging session
session_id = logger.start()

# Create an agent
agent = ConversableAgent("math_agent")
logger.log_new_agent(agent, {"name": "math_agent"})

# Log a custom event
logger.log_event(agent, "custom_event", data={"key": "value"})

# Log a function call
result = custom_function(5, 3)
logger.log_function_use(agent, custom_function, {"x": 5, "y": 3}, result)

# Stop the logging session
logger.stop()
```

## 6. Best Practices

1. **Choose the Right Logger**: Use `SqliteLogger` for structured data and complex querying needs, and `FileLogger` for simple logging and easy manual review.

2. **Log Consistently**: Log all significant events and interactions to maintain a comprehensive record of your application's behavior.

3. **Use Meaningful Event Names**: Choose clear and descriptive names for custom events to make log analysis easier.

4. **Include Relevant Context**: When logging events or function calls, include all relevant context that might be useful for debugging or analysis.

5. **Handle Errors Gracefully**: Ensure that logging errors don't disrupt your main application flow.

6. **Regularly Review Logs**: Periodically review your logs to identify patterns, issues, or areas for improvement in your application.

7. **Implement Log Rotation**: For long-running applications, implement log rotation to manage file sizes and maintain performance.

8. **Secure Sensitive Information**: Be cautious about logging sensitive information. Consider implementing log redaction for sensitive data.

## 7. Advanced Usage: Custom Logger Implementation

If you need a logger with specific functionality not covered by the existing implementations, you can create your own by subclassing `BaseLogger`:

```python
from autogen.logger import BaseLogger

class MyCustomLogger(BaseLogger):
    def __init__(self, config):
        # Custom initialization

    def start(self) -> str:
        # Custom start implementation

    def log_chat_completion(self, ...):
        # Custom chat completion logging

    # Implement other required methods...

# Register your custom logger with the LoggerFactory
LoggerFactory.register_logger("custom", MyCustomLogger)

# Use your custom logger
custom_logger = LoggerFactory.get_logger(logger_type="custom", config={...})
```

## 8. Conclusion

The Autogen logging system, with its `LoggerFactory` and various logger implementations, provides a flexible and powerful way to capture and analyze the behavior of your AI agents and applications. By following the patterns and best practices outlined in this lesson, you can effectively leverage logging to improve debugging, optimize performance, and gain valuable insights into your Autogen-based systems.

Remember that logging is not just about capturing data – it's about telling the story of your application's execution. Use it wisely to narrate that story in the most informative and useful way possible.


```

