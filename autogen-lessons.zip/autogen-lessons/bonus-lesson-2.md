# Bonus Lesson 2: Advanced Agent Interactions and Collaboration in Autogen

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Advanced Agent Types](#advanced-agent-types)
   3.1 [Specialized Agents](#specialized-agents)
   3.2 [Meta-Agents](#meta-agents)
4. [Complex Interaction Patterns](#complex-interaction-patterns)
   4.1 [Multi-Stage Conversations](#multi-stage-conversations)
   4.2 [Branching Dialogues](#branching-dialogues)
5. [Collaborative Problem Solving](#collaborative-problem-solving)
   5.1 [Task Decomposition](#task-decomposition)
   5.2 [Parallel Processing](#parallel-processing)
6. [Dynamic Agent Creation](#dynamic-agent-creation)
7. [Inter-Agent Learning and Knowledge Sharing](#inter-agent-learning-and-knowledge-sharing)
8. [Conflict Resolution and Consensus Building](#conflict-resolution-and-consensus-building)
9. [Advanced GroupChat Techniques](#advanced-groupchat-techniques)
10. [Integrating External Knowledge and APIs](#integrating-external-knowledge-and-apis)
11. [Performance Optimization for Multi-Agent Systems](#performance-optimization-for-multi-agent-systems)
12. [Best Practices and Design Patterns](#best-practices-and-design-patterns)
13. [Conclusion](#conclusion)

## 1. Introduction

In this bonus lesson, we'll explore advanced techniques for creating complex, collaborative multi-agent systems using Autogen. We'll build upon the foundational concepts covered in previous lessons and dive into sophisticated agent interactions, dynamic agent creation, and strategies for efficient problem-solving in a multi-agent environment.

## 2. Project Structure

Before we begin, let's look at the project structure for our advanced multi-agent system:

```
advanced_autogen_project/
│
├── agents/
│   ├── __init__.py
│   ├── specialized_agents.py
│   ├── meta_agents.py
│   └── dynamic_agent_factory.py
│
├── interaction_patterns/
│   ├── __init__.py
│   ├── multi_stage_conversation.py
│   └── branching_dialogue.py
│
├── collaboration/
│   ├── __init__.py
│   ├── task_decomposer.py
│   ├── parallel_processor.py
│   └── knowledge_sharing.py
│
├── utils/
│   ├── __init__.py
│   ├── conflict_resolver.py
│   └── external_api_integrator.py
│
├── config/
│   └── agent_config.yaml
│
├── main.py
├── requirements.txt
└── README.md
```

This structure organizes our code into logical modules, making it easier to manage and extend our advanced multi-agent system.

## 3. Advanced Agent Types

### 3.1 Specialized Agents

Let's create specialized agents that excel at specific tasks. These agents will have custom behaviors and capabilities beyond the standard Autogen agents.

```python
# agents/specialized_agents.py
from autogen import ConversableAgent

class DataAnalysisAgent(ConversableAgent):
    def __init__(self, name, **kwargs):
        super().__init__(name, **kwargs)
        self.data_analysis_tools = self._load_data_analysis_tools()

    def _load_data_analysis_tools(self):
        # Load specialized data analysis libraries and tools
        return {
            "pandas": __import__("pandas"),
            "numpy": __import__("numpy"),
            "matplotlib": __import__("matplotlib.pyplot"),
        }

    async def a_generate_reply(self, messages, sender, config):
        if "analyze_data" in messages[-1]["content"]:
            # Perform data analysis using specialized tools
            result = self._analyze_data(messages[-1]["content"])
            return True, f"Data analysis result: {result}"
        return await super().a_generate_reply(messages, sender, config)

    def _analyze_data(self, message):
        # Implement data analysis logic here
        pass

# Usage
data_analyst = DataAnalysisAgent("DataAnalyst")
```

### 3.2 Meta-Agents

Meta-agents can manage and coordinate other agents, making high-level decisions about task allocation and workflow.

```python
# agents/meta_agents.py
from autogen import ConversableAgent

class ProjectManagerAgent(ConversableAgent):
    def __init__(self, name, team, **kwargs):
        super().__init__(name, **kwargs)
        self.team = team
        self.task_queue = []

    async def a_generate_reply(self, messages, sender, config):
        if "new_task" in messages[-1]["content"]:
            task = self._parse_task(messages[-1]["content"])
            assigned_agent = self._assign_task(task)
            return True, f"Task assigned to {assigned_agent.name}: {task}"
        return await super().a_generate_reply(messages, sender, config)

    def _parse_task(self, message):
        # Parse task details from the message
        pass

    def _assign_task(self, task):
        # Assign task to the most suitable agent in the team
        pass

# Usage
team = [DataAnalysisAgent("DataAnalyst"), ConversableAgent("GeneralAssistant")]
project_manager = ProjectManagerAgent("ProjectManager", team)
```

## 4. Complex Interaction Patterns

### 4.1 Multi-Stage Conversations

Implement multi-stage conversations where agents collaborate through a series of predefined stages to solve complex problems.

```python
# interaction_patterns/multi_stage_conversation.py
from autogen import ConversableAgent

class MultiStageConversation:
    def __init__(self, agents, stages):
        self.agents = agents
        self.stages = stages
        self.current_stage = 0

    async def execute(self):
        while self.current_stage < len(self.stages):
            stage = self.stages[self.current_stage]
            agent = self.agents[stage["agent"]]
            message = stage["message"]
            
            response = await agent.a_generate_reply([{"role": "user", "content": message}], None, None)
            
            if stage.get("transition_condition", lambda x: True)(response):
                self.current_stage += 1
            
        return "Multi-stage conversation completed"

# Usage
agents = {
    "analyst": DataAnalysisAgent("DataAnalyst"),
    "manager": ProjectManagerAgent("ProjectManager", [])
}

stages = [
    {"agent": "analyst", "message": "Analyze the latest sales data"},
    {"agent": "manager", "message": "Review the analysis and make recommendations",
     "transition_condition": lambda x: "recommendation" in x[1].lower()},
    {"agent": "analyst", "message": "Implement the recommended changes"}
]

conversation = MultiStageConversation(agents, stages)
result = await conversation.execute()
```

### 4.2 Branching Dialogues

Create branching dialogues where the conversation flow depends on the agents' responses.

```python
# interaction_patterns/branching_dialogue.py
from autogen import ConversableAgent

class BranchingDialogue:
    def __init__(self, root_agent, branches):
        self.root_agent = root_agent
        self.branches = branches

    async def execute(self, initial_message):
        current_agent = self.root_agent
        message = initial_message

        while True:
            response = await current_agent.a_generate_reply([{"role": "user", "content": message}], None, None)
            
            if response[0]:  # If a reply was generated
                for branch in self.branches:
                    if branch["condition"](response[1]):
                        current_agent = branch["agent"]
                        message = branch["message"]
                        break
                else:
                    return "Conversation ended"
            else:
                return "No response generated"

# Usage
root_agent = ConversableAgent("RootAgent")
branch_a = ConversableAgent("BranchA")
branch_b = ConversableAgent("BranchB")

branches = [
    {"condition": lambda x: "option a" in x.lower(), "agent": branch_a, "message": "You chose option A"},
    {"condition": lambda x: "option b" in x.lower(), "agent": branch_b, "message": "You chose option B"}
]

dialogue = BranchingDialogue(root_agent, branches)
result = await dialogue.execute("What option do you prefer, A or B?")
```

## 5. Collaborative Problem Solving

### 5.1 Task Decomposition

Implement a system for breaking down complex tasks into smaller, manageable subtasks that can be distributed among specialized agents.

```python
# collaboration/task_decomposer.py
from autogen import ConversableAgent

class TaskDecomposer(ConversableAgent):
    def __init__(self, name, **kwargs):
        super().__init__(name, **kwargs)

    async def a_generate_reply(self, messages, sender, config):
        if "decompose_task" in messages[-1]["content"]:
            task = messages[-1]["content"].split("decompose_task: ")[1]
            subtasks = self._decompose_task(task)
            return True, f"Task decomposed into subtasks: {subtasks}"
        return await super().a_generate_reply(messages, sender, config)

    def _decompose_task(self, task):
        # Implement task decomposition logic
        # This could involve using the LLM to generate subtasks
        subtasks = [
            "Subtask 1: Gather data",
            "Subtask 2: Analyze data",
            "Subtask 3: Generate report"
        ]
        return subtasks

# Usage
decomposer = TaskDecomposer("TaskDecomposer")
```

### 5.2 Parallel Processing

Implement parallel processing of subtasks for efficient problem-solving.

```python
# collaboration/parallel_processor.py
import asyncio
from autogen import ConversableAgent

class ParallelTaskProcessor:
    def __init__(self, agents):
        self.agents = agents

    async def process_tasks(self, tasks):
        async def process_task(agent, task):
            return await agent.a_generate_reply([{"role": "user", "content": task}], None, None)

        tasks = [process_task(agent, task) for agent, task in zip(self.agents, tasks)]
        results = await asyncio.gather(*tasks)
        return results

# Usage
agents = [ConversableAgent(f"Agent{i}") for i in range(3)]
processor = ParallelTaskProcessor(agents)
tasks = ["Task 1", "Task 2", "Task 3"]
results = await processor.process_tasks(tasks)
```

## 6. Dynamic Agent Creation

Implement a factory for creating agents dynamically based on the current needs of the system.

```python
# agents/dynamic_agent_factory.py
from autogen import ConversableAgent

class DynamicAgentFactory:
    @staticmethod
    def create_agent(agent_type, name, **kwargs):
        if agent_type == "data_analyst":
            return DataAnalysisAgent(name, **kwargs)
        elif agent_type == "project_manager":
            return ProjectManagerAgent(name, **kwargs)
        else:
            return ConversableAgent(name, **kwargs)

# Usage
factory = DynamicAgentFactory()
new_agent = factory.create_agent("data_analyst", "DynamicDataAnalyst")
```

## 7. Inter-Agent Learning and Knowledge Sharing

Implement a mechanism for agents to share knowledge and learn from each other.

```python
# collaboration/knowledge_sharing.py
from autogen import ConversableAgent

class KnowledgeSharingAgent(ConversableAgent):
    def __init__(self, name, **kwargs):
        super().__init__(name, **kwargs)
        self.knowledge_base = {}

    async def a_generate_reply(self, messages, sender, config):
        if "share_knowledge" in messages[-1]["content"]:
            topic, knowledge = self._parse_knowledge(messages[-1]["content"])
            self.knowledge_base[topic] = knowledge
            return True, f"Knowledge about {topic} has been shared and stored"
        elif "request_knowledge" in messages[-1]["content"]:
            topic = messages[-1]["content"].split("request_knowledge: ")[1]
            if topic in self.knowledge_base:
                return True, f"Knowledge about {topic}: {self.knowledge_base[topic]}"
            else:
                return True, f"No knowledge found about {topic}"
        return await super().a_generate_reply(messages, sender, config)

    def _parse_knowledge(self, message):
        # Parse topic and knowledge from the message
        pass

# Usage
agent1 = KnowledgeSharingAgent("Agent1")
agent2 = KnowledgeSharingAgent("Agent2")

# Agent1 shares knowledge
await agent1.a_generate_reply([{"role": "user", "content": "share_knowledge: Python: Python is a versatile programming language"}], None, None)

# Agent2 requests knowledge
result = await agent2.a_generate_reply([{"role": "user", "content": "request_knowledge: Python"}], agent1, None)
```

## 8. Conflict Resolution and Consensus Building

Implement mechanisms for resolving conflicts and building consensus among agents with differing opinions.

```python
# utils/conflict_resolver.py
from autogen import ConversableAgent

class ConflictResolver(ConversableAgent):
    def __init__(self, name, agents, **kwargs):
        super().__init__(name, **kwargs)
        self.agents = agents

    async def resolve_conflict(self, topic):
        opinions = []
        for agent in self.agents:
            opinion = await agent.a_generate_reply([{"role": "user", "content": f"Your opinion on {topic}?"}], None, None)
            opinions.append(opinion[1])

        resolution = await self.a_generate_reply([{"role": "user", "content": f"Resolve conflict on {topic}: {opinions}"}], None, None)
        return resolution[1]

# Usage
agents = [ConversableAgent(f"Agent{i}") for i in range(3)]
resolver = ConflictResolver("ConflictResolver", agents)
resolution = await resolver.resolve_conflict("best programming language")
```

## 9. Advanced GroupChat Techniques

Enhance the GroupChat functionality with dynamic role assignment and topic-based discussions.

```python
# main.py
from autogen import GroupChat, GroupChatManager

class AdvancedGroupChat(GroupChat):
    def __init__(self, agents, dynamic_roles=False, **kwargs):
        super().__init__(agents, **kwargs)
        self.dynamic_roles = dynamic_roles

    def select_speaker(self, last_speaker, message):
        if self.dynamic_roles:
            # Implement dynamic role assignment based on message content
            return self._assign_dynamic_role(message)
        return super().select_speaker(last_speaker, message)

    def _assign_dynamic_role(self, message):
        # Implement logic to assign the most suitable agent based on message content
        pass

# Usage
agents = [DataAnalysisAgent("DataAnalyst"), ProjectManagerAgent("ProjectManager", []), ConversableAgent("GeneralAssistant")]
advanced_group_chat = AdvancedGroupChat(agents, dynamic_roles=True)
manager = GroupChatManager(advanced_group_chat)

result = await manager.a_initiate_chat("Let's discuss the project timeline and data analysis requirements")
```

## 10. Integrating External Knowledge and APIs

To make our multi-agent system more powerful and versatile, we can integrate external knowledge sources and APIs. This allows agents to access up-to-date information and perform actions beyond their built-in capabilities.

### 10.1 External API Integration

Let's create a utility class for integrating external APIs:

```python
# utils/external_api_integrator.py
import aiohttp
from autogen import ConversableAgent

class ExternalAPIIntegrator:
    def __init__(self):
        self.session = None

    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.session.close()

    async def fetch_data(self, url, params=None):
        async with self.session.get(url, params=params) as response:
            return await response.json()

class APIEnabledAgent(ConversableAgent):
    def __init__(self, name, api_integrator, **kwargs):
        super().__init__(name, **kwargs)
        self.api_integrator = api_integrator

    async def a_generate_reply(self, messages, sender, config):
        if "fetch_weather" in messages[-1]["content"]:
            city = messages[-1]["content"].split("fetch_weather: ")[1]
            weather_data = await self.fetch_weather(city)
            return True, f"Weather in {city}: {weather_data}"
        return await super().a_generate_reply(messages, sender, config)

    async def fetch_weather(self, city):
        url = "https://api.openweathermap.org/data/2.5/weather"
        params = {
            "q": city,
            "appid": "YOUR_API_KEY",  # Replace with your actual API key
            "units": "metric"
        }
        data = await self.api_integrator.fetch_data(url, params)
        return f"{data['weather'][0]['description']}, {data['main']['temp']}°C"

# Usage
async with ExternalAPIIntegrator() as api_integrator:
    weather_agent = APIEnabledAgent("WeatherAgent", api_integrator)
    result = await weather_agent.a_generate_reply([{"role": "user", "content": "fetch_weather: London"}], None, None)
    print(result[1])
```

This example demonstrates how to create an agent that can fetch real-time weather data from an external API.

### 10.2 Knowledge Base Integration

We can also integrate external knowledge bases to enhance our agents' capabilities:

```python
# utils/knowledge_base_integrator.py
import sqlite3
from autogen import ConversableAgent

class KnowledgeBaseIntegrator:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()

    def query_knowledge(self, topic):
        self.cursor.execute("SELECT information FROM knowledge_base WHERE topic = ?", (topic,))
        result = self.cursor.fetchone()
        return result[0] if result else None

    def add_knowledge(self, topic, information):
        self.cursor.execute("INSERT OR REPLACE INTO knowledge_base (topic, information) VALUES (?, ?)", (topic, information))
        self.conn.commit()

    def close(self):
        self.conn.close()

class KnowledgeEnhancedAgent(ConversableAgent):
    def __init__(self, name, knowledge_base, **kwargs):
        super().__init__(name, **kwargs)
        self.knowledge_base = knowledge_base

    async def a_generate_reply(self, messages, sender, config):
        if "query_knowledge" in messages[-1]["content"]:
            topic = messages[-1]["content"].split("query_knowledge: ")[1]
            knowledge = self.knowledge_base.query_knowledge(topic)
            if knowledge:
                return True, f"Knowledge about {topic}: {knowledge}"
            else:
                return True, f"No knowledge found about {topic}"
        elif "add_knowledge" in messages[-1]["content"]:
            parts = messages[-1]["content"].split("add_knowledge: ")[1].split(" | ")
            topic, information = parts[0], parts[1]
            self.knowledge_base.add_knowledge(topic, information)
            return True, f"Added knowledge about {topic}"
        return await super().a_generate_reply(messages, sender, config)

# Usage
kb_integrator = KnowledgeBaseIntegrator("knowledge.db")
enhanced_agent = KnowledgeEnhancedAgent("EnhancedAgent", kb_integrator)

# Add knowledge
await enhanced_agent.a_generate_reply([{"role": "user", "content": "add_knowledge: Python | Python is a high-level programming language"}], None, None)

# Query knowledge
result = await enhanced_agent.a_generate_reply([{"role": "user", "content": "query_knowledge: Python"}], None, None)
print(result[1])

kb_integrator.close()
```

This example shows how to create an agent that can query and update a SQLite-based knowledge base.

## 11. Performance Optimization for Multi-Agent Systems

As multi-agent systems grow in complexity, it's important to optimize their performance. Here are some techniques:

### 11.1 Caching

Implement a caching mechanism to store and reuse frequently accessed information:

```python
# utils/cache.py
from functools import lru_cache
from autogen import ConversableAgent

class CachedAgent(ConversableAgent):
    def __init__(self, name, **kwargs):
        super().__init__(name, **kwargs)

    @lru_cache(maxsize=100)
    def cached_operation(self, input_data):
        # Perform expensive operation here
        return f"Processed: {input_data}"

    async def a_generate_reply(self, messages, sender, config):
        if "process_data" in messages[-1]["content"]:
            data = messages[-1]["content"].split("process_data: ")[1]
            result = self.cached_operation(data)
            return True, result
        return await super().a_generate_reply(messages, sender, config)

# Usage
cached_agent = CachedAgent("CachedAgent")
result1 = await cached_agent.a_generate_reply([{"role": "user", "content": "process_data: example"}], None, None)
result2 = await cached_agent.a_generate_reply([{"role": "user", "content": "process_data: example"}], None, None)
# The second call will use the cached result
```

### 11.2 Asynchronous Processing

Utilize asynchronous programming to improve the overall system responsiveness:

```python
# main.py
import asyncio
from autogen import ConversableAgent

async def process_multiple_agents(agents, message):
    tasks = [agent.a_generate_reply([{"role": "user", "content": message}], None, None) for agent in agents]
    results = await asyncio.gather(*tasks)
    return results

# Usage
agents = [ConversableAgent(f"Agent{i}") for i in range(5)]
results = await process_multiple_agents(agents, "Perform your specific task")
```

## 12. Best Practices and Design Patterns

When working with advanced multi-agent systems in Autogen, consider the following best practices and design patterns:

1. **Separation of Concerns**: Keep agent definitions, interaction patterns, and utility functions in separate modules for better organization and reusability.

2. **Configuration Management**: Use configuration files (e.g., YAML) to manage agent properties and system settings:

```python
# config/agent_config.yaml
agents:
  - name: DataAnalyst
    type: DataAnalysisAgent
    tools:
      - pandas
      - numpy
      - matplotlib
  - name: ProjectManager
    type: ProjectManagerAgent
    team_size: 5

# main.py
import yaml
from agents.dynamic_agent_factory import DynamicAgentFactory

with open("config/agent_config.yaml", "r") as config_file:
    config = yaml.safe_load(config_file)

factory = DynamicAgentFactory()
agents = [factory.create_agent(agent["type"], agent["name"], **agent) for agent in config["agents"]]
```

3. **Error Handling and Logging**: Implement robust error handling and logging mechanisms:

```python
# utils/logging.py
import logging

def setup_logging():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# main.py
from utils.logging import setup_logging

setup_logging()
logger = logging.getLogger(__name__)

try:
    # Your multi-agent system code here
    pass
except Exception as e:
    logger.error(f"An error occurred: {str(e)}", exc_info=True)
```

4. **Modular Design**: Design your system with modularity in mind, allowing for easy addition or removal of agents and functionalities:

```python
# main.py
class MultiAgentSystem:
    def __init__(self):
        self.agents = {}
        self.interaction_patterns = {}

    def add_agent(self, agent):
        self.agents[agent.name] = agent

    def add_interaction_pattern(self, name, pattern):
        self.interaction_patterns[name] = pattern

    async def run_interaction(self, pattern_name, *args, **kwargs):
        if pattern_name in self.interaction_patterns:
            return await self.interaction_patterns[pattern_name].execute(*args, **kwargs)
        else:
            raise ValueError(f"Interaction pattern {pattern_name} not found")

# Usage
system = MultiAgentSystem()
system.add_agent(DataAnalysisAgent("DataAnalyst"))
system.add_agent(ProjectManagerAgent("ProjectManager", []))
system.add_interaction_pattern("multi_stage", MultiStageConversation(system.agents, stages))

result = await system.run_interaction("multi_stage")
```

5. **Testing**: Implement comprehensive unit tests and integration tests for your multi-agent system:

```python
# tests/test_agents.py
import unittest
from unittest.mock import AsyncMock, patch
from agents.specialized_agents import DataAnalysisAgent

class TestDataAnalysisAgent(unittest.TestCase):
    def setUp(self):
        self.agent = DataAnalysisAgent("TestDataAnalyst")

    @patch("agents.specialized_agents.DataAnalysisAgent._analyze_data")
    async def test_generate_reply(self, mock_analyze_data):
        mock_analyze_data.return_value = "Mocked analysis result"
        messages = [{"role": "user", "content": "analyze_data: sample_data.csv"}]
        
        result = await self.agent.a_generate_reply(messages, None, None)
        
        self.assertTrue(result[0])
        self.assertIn("Mocked analysis result", result[1])
        mock_analyze_data.assert_called_once_with("sample_data.csv")

if __name__ == "__main__":
    unittest.main()
```

## 13. Conclusion

In this bonus lesson, we've explored advanced techniques for creating sophisticated multi-agent systems using Autogen. We've covered topics such as specialized agents, complex interaction patterns, collaborative problem-solving, dynamic agent creation, knowledge sharing, and integration with external APIs and knowledge bases.

By applying these advanced concepts and best practices, you can build powerful, flexible, and efficient multi-agent systems capable of tackling complex tasks and problems. Remember to always consider the specific requirements of your project and adapt these techniques accordingly.

As you continue to work with Autogen, keep exploring new ways to enhance agent capabilities, optimize system performance, and create innovative solutions to challenging problems in the field of AI and automation.