# Lesson 2: The BaseLogger Abstract Class

## 1. Introduction to BaseLogger

The `BaseLogger` abstract class is the foundation of Autogen's logging system. It defines the interface that all concrete logger implementations must adhere to. By using an abstract base class, Autogen ensures consistency across different logging implementations while allowing for flexibility in how logging is actually performed.

## 2. Project Structure

Let's revisit where `BaseLogger` fits in the project structure:

```
autogen/
└── logger/
    ├── __init__.py
    ├── base_logger.py  <- We are here
    ├── file_logger.py
    ├── logger_factory.py
    ├── logger_utils.py
    └── sqlite_logger.py
```

## 3. BaseLogger Class Definition

Here's the basic structure of the `BaseLogger` class:

```python
from abc import ABC, abstractmethod

class BaseLogger(ABC):
    @abstractmethod
    def start(self) -> str:
        ...

    @abstractmethod
    def log_chat_completion(self, ...):
        ...

    @abstractmethod
    def log_new_agent(self, agent: ConversableAgent, init_args: Dict[str, Any]) -> None:
        ...

    @abstractmethod
    def log_event(self, source: Union[str, Agent], name: str, **kwargs: Dict[str, Any]) -> None:
        ...

    @abstractmethod
    def log_new_wrapper(self, wrapper: OpenAIWrapper, init_args: Dict[str, Union[LLMConfig, List[LLMConfig]]]) -> None:
        ...

    @abstractmethod
    def log_new_client(self, client: Union[AzureOpenAI, OpenAI], wrapper: OpenAIWrapper, init_args: Dict[str, Any]) -> None:
        ...

    @abstractmethod
    def log_function_use(self, source: Union[str, Agent], function: F, args: Dict[str, Any], returns: Any) -> None:
        ...

    @abstractmethod
    def stop(self) -> None:
        ...

    @abstractmethod
    def get_connection(self) -> Union[None, sqlite3.Connection]:
        ...
```

## 4. Key Methods

Let's break down the key methods of the `BaseLogger` class:

### 4.1 start()

- Purpose: Initializes the logging session.
- Returns: A unique session ID as a string.

### 4.2 log_chat_completion()

- Purpose: Logs details of a chat completion.
- Parameters include:
  - invocation_id: Unique identifier for the OpenAIWrapper.create method call
  - client_id: Identifier for the OpenAI client instance
  - wrapper_id: Identifier for the OpenAIWrapper instance
  - source: The source of the event (either a string or an Agent)
  - request: The request sent to the OpenAI API
  - response: The response received from OpenAI
  - is_cached: Whether the response was cached
  - cost: The cost of the API call
  - start_time: When the request was initiated

### 4.3 log_new_agent()

- Purpose: Logs the creation of a new agent.
- Parameters:
  - agent: The ConversableAgent instance
  - init_args: Arguments used to initialize the agent

### 4.4 log_event()

- Purpose: Logs a custom event.
- Parameters:
  - source: The source of the event (either a string or an Agent)
  - name: The name of the event
  - **kwargs: Additional event details

### 4.5 log_new_wrapper()

- Purpose: Logs the creation of a new OpenAIWrapper.
- Parameters:
  - wrapper: The OpenAIWrapper instance
  - init_args: Arguments used to initialize the wrapper

### 4.6 log_new_client()

- Purpose: Logs the creation of a new OpenAI client.
- Parameters:
  - client: The OpenAI client instance
  - wrapper: The associated OpenAIWrapper instance
  - init_args: Arguments used to initialize the client

### 4.7 log_function_use()

- Purpose: Logs the use of a registered function (could be a tool).
- Parameters:
  - source: The source of the function call (either a string or an Agent)
  - function: The function that was called
  - args: Arguments passed to the function
  - returns: The return value of the function

### 4.8 stop()

- Purpose: Stops the logging session and performs any necessary cleanup.

### 4.9 get_connection()

- Purpose: Returns a connection to the logging database (if applicable).
- Returns: A SQLite connection object or None.

## 5. Usage Example

Here's a simple example of how a concrete logger implementation might use the `BaseLogger` class:

```python
from autogen.logger import BaseLogger

class MyCustomLogger(BaseLogger):
    def __init__(self):
        self.logs = []

    def start(self) -> str:
        session_id = generate_unique_id()  # Implement this function
        self.logs.append(f"Started session: {session_id}")
        return session_id

    def log_event(self, source: Union[str, Agent], name: str, **kwargs: Dict[str, Any]) -> None:
        event_details = f"Event: {name}, Source: {source}, Details: {kwargs}"
        self.logs.append(event_details)

    # Implement other abstract methods...

    def stop(self) -> None:
        self.logs.append("Logging session stopped")

    def get_connection(self) -> None:
        return None  # This logger doesn't use a database connection
```

This example shows a basic in-memory logger that implements the `BaseLogger` interface. In practice, you would implement all the abstract methods to create a fully functional logger.

## 6. Conclusion

The `BaseLogger` abstract class provides a solid foundation for Autogen's logging system. By defining a common interface, it ensures that all logger implementations can be used interchangeably within the Autogen ecosystem. This design allows for easy extension of the logging system to support different storage backends or logging formats while maintaining a consistent API for the rest of the application to interact with.

In the next lesson, we'll explore the `FileLogger` class, which provides a concrete implementation of the `BaseLogger` interface for logging to files.

