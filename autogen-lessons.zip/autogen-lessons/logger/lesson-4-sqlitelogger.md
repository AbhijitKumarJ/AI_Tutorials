# Lesson 4: SQLite-based Logging with SqliteLogger

## 1. Introduction to SqliteLogger

The `SqliteLogger` class is another concrete implementation of the `BaseLogger` abstract class. It provides a mechanism for logging Autogen events to a SQLite database, which offers structured storage and efficient querying capabilities.

## 2. Project Structure

Let's revisit where `SqliteLogger` fits in the project structure:

```
autogen/
└── logger/
    ├── __init__.py
    ├── base_logger.py
    ├── file_logger.py
    ├── logger_factory.py
    ├── logger_utils.py
    └── sqlite_logger.py  <- We are here
```

## 3. SqliteLogger Class Overview

The `SqliteLogger` class is defined in `sqlite_logger.py`. Here's a simplified version of its structure:

```python
import json
import logging
import sqlite3
import threading
import uuid
from typing import Any, Dict, Union

from autogen.logger.base_logger import BaseLogger
from autogen.logger.logger_utils import get_current_ts, to_dict

class SqliteLogger(BaseLogger):
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.dbname = self.config.get("dbname", "logs.db")
        self.con = sqlite3.connect(self.dbname, check_same_thread=False)
        self.cur = self.con.cursor()
        self.session_id = str(uuid.uuid4())

    def start(self) -> str:
        # ... (implementation)

    def log_chat_completion(self, ...):
        # ... (implementation)

    def log_new_agent(self, agent: ConversableAgent, init_args: Dict[str, Any] = {}):
        # ... (implementation)

    def log_event(self, source: Union[str, Agent], name: str, **kwargs: Dict[str, Any]):
        # ... (implementation)

    def log_new_wrapper(self, wrapper: OpenAIWrapper, init_args: Dict[str, Union[LLMConfig, List[LLMConfig]]] = {}):
        # ... (implementation)

    def log_new_client(self, client: Union[AzureOpenAI, OpenAI], wrapper: OpenAIWrapper, init_args: Dict[str, Any]):
        # ... (implementation)

    def log_function_use(self, source: Union[str, Agent], function: F, args: Dict[str, Any], returns: Any):
        # ... (implementation)

    def stop(self):
        # ... (implementation)

    def get_connection(self) -> Union[None, sqlite3.Connection]:
        # ... (implementation)

    def _run_query(self, query: str, args: Tuple[Any, ...] = ()):
        # ... (implementation)
```

## 4. Key Features of SqliteLogger

### 4.1 Initialization

The `SqliteLogger` is initialized with a configuration dictionary. It sets up a connection to a SQLite database and creates a unique session ID.

```python
def __init__(self, config: Dict[str, Any]):
    self.config = config
    self.dbname = self.config.get("dbname", "logs.db")
    self.con = sqlite3.connect(self.dbname, check_same_thread=False)
    self.cur = self.con.cursor()
    self.session_id = str(uuid.uuid4())
```

### 4.2 Database Schema

The `SqliteLogger` sets up several tables to store different types of logs:

- `chat_completions`: Stores details of chat completion calls
- `agents`: Stores information about created agents
- `oai_wrappers`: Stores information about OpenAI wrappers
- `oai_clients`: Stores information about OpenAI clients
- `events`: Stores custom events
- `function_calls`: Stores information about function calls

### 4.3 Thread Safety

The `SqliteLogger` uses a lock to ensure thread-safe database operations:

```python
lock = threading.Lock()

def _run_query(self, query: str, args: Tuple[Any, ...] = ()):
    try:
        with lock:
            self.cur.execute(query, args)
            self.con.commit()
    except Exception as e:
        logger.error("[sqlite logger]Error running query with query %s and args %s: %s", query, args, e)
```

## 5. Implementing BaseLogger Methods

Let's look at how `SqliteLogger` implements some of the key methods from `BaseLogger`:

### 5.1 start()

```python
def start(self) -> str:
    try:
        # Create tables if they don't exist
        self._run_query("""
            CREATE TABLE IF NOT EXISTS chat_completions(
                id INTEGER PRIMARY KEY,
                invocation_id TEXT,
                client_id INTEGER,
                wrapper_id INTEGER,
                session_id TEXT,
                source_name TEXT,
                request TEXT,
                response TEXT,
                is_cached INTEGER,
                cost REAL,
                start_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                end_time DATETIME DEFAULT CURRENT_TIMESTAMP)
        """)
        # ... (create other tables)
    except sqlite3.Error as e:
        logger.error(f"[SqliteLogger] start logging error: {e}")
    finally:
        return self.session_id
```

This method sets up the necessary database tables and returns the session ID.

### 5.2 log_chat_completion()

```python
def log_chat_completion(self, invocation_id: uuid.UUID, client_id: int, wrapper_id: int, source: Union[str, Agent],
                        request: Dict[str, Union[float, str, List[Dict[str, str]]]], response: Union[str, ChatCompletion],
                        is_cached: int, cost: float, start_time: str) -> None:
    end_time = get_current_ts()
    
    response_messages = json.dumps({"response": response}) if response is None or isinstance(response, str) else json.dumps(to_dict(response), indent=4)
    
    source_name = source if isinstance(source, str) else source.name

    query = """
        INSERT INTO chat_completions (
            invocation_id, client_id, wrapper_id, session_id, request, response, is_cached, cost, start_time, end_time, source_name
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """
    args = (str(invocation_id), client_id, wrapper_id, self.session_id, json.dumps(request), response_messages, is_cached, cost, start_time, end_time, source_name)

    self._run_query(query=query, args=args)
```

This method logs details of a chat completion to the `chat_completions` table.

## 6. Error Handling and Migration

The `SqliteLogger` includes error handling and a basic migration system:

```python
def _apply_migration(self, migrations_dir: str = "./migrations") -> None:
    current_version = self._get_current_db_version()
    current_version = SqliteLogger.schema_version if current_version is None else current_version

    if os.path.isdir(migrations_dir):
        migrations = sorted(os.listdir(migrations_dir))
    else:
        logger.info("no migration scripts, skip...")
        return

    migrations_to_apply = [m for m in migrations if int(m.split("_")[0]) > current_version]

    for script in migrations_to_apply:
        with open(script, "r") as f:
            migration_sql = f.read()
            self._run_query_script(script=migration_sql)

            latest_version = int(script.split("_")[0])
            query = "UPDATE version SET version_number = ? WHERE id = 1"
            args = (latest_version,)
            self._run_query(query=query, args=args)
```

This method allows for future schema updates without breaking existing logs.

## 7. Usage Example

Here's an example of how to use the `SqliteLogger`:

```python
from autogen import LoggerFactory

# Create a SqliteLogger instance
config = {"dbname": "my_logs.db"}
logger = LoggerFactory.get_logger(logger_type="sqlite", config=config)

# Start the logging session
session_id = logger.start()

# Log a custom event
logger.log_event(source="MyAgent", name="custom_event", data={"key": "value"})

# Log a chat completion
logger.log_chat_completion(
    invocation_id=uuid.uuid4(),
    client_id=1,
    wrapper_id=1,
    source="MyAgent",
    request={"prompt": "Hello, world!"},
    response="Hi there!",
    is_cached=0,
    cost=0.001,
    start_time="2023-09-17 10:00:00.000000"
)

# Stop the logging session
logger.stop()
```

This example demonstrates creating a `SqliteLogger`, starting a session, logging various events, and stopping the session.

## 8. Advantages and Considerations

Advantages of `SqliteLogger`:
1. Structured data storage
2. Efficient querying capabilities
3. Supports complex data relationships
4. Built-in support for concurrent access

Considerations:
1. Requires SQLite to be installed
2. May have slower write performance compared to file-based logging for very high volume logging
3. Requires database management (e.g., periodic vacuuming)

## 9. Conclusion

The `SqliteLogger` provides a robust, database-backed implementation of the `BaseLogger` interface. It offers structured storage and efficient querying capabilities, making it suitable for applications that require complex log analysis or high-volume logging. Its use of SQLite makes it portable and easy to set up, while still providing many of the benefits of a full-fledged database system.

In the next and final lesson, we'll explore the `LoggerFactory` class and discuss practical usage patterns for the Autogen logging system.

