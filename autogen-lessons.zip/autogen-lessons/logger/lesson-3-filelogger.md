# Lesson 3: Implementing File-based Logging with FileLogger

## 1. Introduction to FileLogger

The `FileLogger` class is a concrete implementation of the `BaseLogger` abstract class. It provides a mechanism for logging Autogen events to a file, which is useful for persistent storage and easy review of logs.

## 2. Project Structure

Let's look at where `FileLogger` fits in the project structure:

```
autogen/
└── logger/
    ├── __init__.py
    ├── base_logger.py
    ├── file_logger.py  <- We are here
    ├── logger_factory.py
    ├── logger_utils.py
    └── sqlite_logger.py
```

## 3. FileLogger Class Overview

The `FileLogger` class is defined in `file_logger.py`. Here's a simplified version of its structure:

```python
import json
import logging
import os
import threading
import uuid
from typing import Any, Dict, Union

from autogen.logger.base_logger import BaseLogger
from autogen.logger.logger_utils import get_current_ts, to_dict

class FileLogger(BaseLogger):
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.session_id = str(uuid.uuid4())
        self.log_dir = os.path.join(os.getcwd(), "autogen_logs")
        os.makedirs(self.log_dir, exist_ok=True)
        self.log_file = os.path.join(self.log_dir, self.config.get("filename", "runtime.log"))
        # ... (setup logger)

    def start(self) -> str:
        # ... (implementation)

    def log_chat_completion(self, ...):
        # ... (implementation)

    def log_new_agent(self, agent: ConversableAgent, init_args: Dict[str, Any] = {}):
        # ... (implementation)

    def log_event(self, source: Union[str, Agent], name: str, **kwargs: Dict[str, Any]):
        # ... (implementation)

    def log_new_wrapper(self, wrapper: OpenAIWrapper, init_args: Dict[str, Union[LLMConfig, List[LLMConfig]]] = {}):
        # ... (implementation)

    def log_new_client(self, client: Union[AzureOpenAI, OpenAI], wrapper: OpenAIWrapper, init_args: Dict[str, Any]):
        # ... (implementation)

    def log_function_use(self, source: Union[str, Agent], function: F, args: Dict[str, Any], returns: Any):
        # ... (implementation)

    def stop(self):
        # ... (implementation)

    def get_connection(self) -> None:
        pass
```

## 4. Key Features of FileLogger

### 4.1 Initialization

The `FileLogger` is initialized with a configuration dictionary. It sets up a logging directory and file, and creates a unique session ID.

```python
def __init__(self, config: Dict[str, Any]):
    self.config = config
    self.session_id = str(uuid.uuid4())
    self.log_dir = os.path.join(os.getcwd(), "autogen_logs")
    os.makedirs(self.log_dir, exist_ok=True)
    self.log_file = os.path.join(self.log_dir, self.config.get("filename", "runtime.log"))
    # ... (setup logger)
```

### 4.2 Logging Format

The `FileLogger` uses JSON formatting for log entries, which makes it easy to parse and analyze logs programmatically.

### 4.3 Thread Safety

The `FileLogger` uses Python's built-in `logging` module, which is thread-safe, allowing for use in multi-threaded environments.

## 5. Implementing BaseLogger Methods

Let's look at how `FileLogger` implements some of the key methods from `BaseLogger`:

### 5.1 start()

```python
def start(self) -> str:
    try:
        self.logger.info(f"Started new session with Session ID: {self.session_id}")
    except Exception as e:
        logger.error(f"[file_logger] Failed to create logging file: {e}")
    finally:
        return self.session_id
```

This method logs the start of a new session and returns the session ID.

### 5.2 log_chat_completion()

```python
def log_chat_completion(self, invocation_id: uuid.UUID, client_id: int, wrapper_id: int, source: Union[str, Agent],
                        request: Dict[str, Union[float, str, List[Dict[str, str]]]], response: Union[str, ChatCompletion],
                        is_cached: int, cost: float, start_time: str) -> None:
    thread_id = threading.get_ident()
    source_name = source.name if hasattr(source, 'name') else source
    try:
        log_data = json.dumps({
            "invocation_id": str(invocation_id),
            "client_id": client_id,
            "wrapper_id": wrapper_id,
            "request": to_dict(request),
            "response": str(response),
            "is_cached": is_cached,
            "cost": cost,
            "start_time": start_time,
            "end_time": get_current_ts(),
            "thread_id": thread_id,
            "source_name": source_name,
        })
        self.logger.info(log_data)
    except Exception as e:
        self.logger.error(f"[file_logger] Failed to log chat completion: {e}")
```

This method logs details of a chat completion, including request and response data, timing, and cost.

## 6. Error Handling

The `FileLogger` includes robust error handling to ensure that logging failures don't disrupt the main application flow. For example:

```python
try:
    # ... (logging logic)
except Exception as e:
    self.logger.error(f"[file_logger] Failed to log event: {e}")
```

## 7. Usage Example

Here's an example of how to use the `FileLogger`:

```python
from autogen import LoggerFactory

# Create a FileLogger instance
config = {"filename": "my_logs.log"}
logger = LoggerFactory.get_logger(logger_type="file", config=config)

# Start the logging session
session_id = logger.start()

# Log a custom event
logger.log_event(source="MyAgent", name="custom_event", data={"key": "value"})

# Log a chat completion
logger.log_chat_completion(
    invocation_id=uuid.uuid4(),
    client_id=1,
    wrapper_id=1,
    source="MyAgent",
    request={"prompt": "Hello, world!"},
    response="Hi there!",
    is_cached=0,
    cost=0.001,
    start_time="2023-09-17 10:00:00.000000"
)

# Stop the logging session
logger.stop()
```

This example demonstrates creating a `FileLogger`, starting a session, logging various events, and stopping the session.

## 8. Advantages and Considerations

Advantages of `FileLogger`:
1. Simple setup and usage
2. Persistent storage of logs
3. Easy to read and analyze manually
4. JSON formatting allows for programmatic analysis

Considerations:
1. File I/O can be slower than in-memory logging
2. May require log rotation for long-running applications
3. Not suitable for distributed systems without additional setup

## 9. Conclusion

The `FileLogger` provides a straightforward implementation of the `BaseLogger` interface, offering file-based logging for Autogen applications. Its use of JSON formatting and robust error handling make it a reliable choice for many use cases. However, for applications with high-volume logging or distributed architectures, other logging solutions might be more appropriate.

In the next lesson, we'll explore the `SqliteLogger`, which offers a database-backed alternative to file-based logging.

