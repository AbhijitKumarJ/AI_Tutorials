# Lesson 5: The LoggerFactory and Practical Usage

## 1. Introduction to LoggerFactory

The `LoggerFactory` class in Autogen provides a simple and flexible way to create logger instances. It acts as an abstraction layer, allowing developers to switch between different logging implementations without changing their application code.

## 2. Project Structure

Let's revisit where `LoggerFactory` fits in the project structure:

```
autogen/
└── logger/
    ├── __init__.py
    ├── base_logger.py
    ├── file_logger.py
    ├── logger_factory.py  <- We are here
    ├── logger_utils.py
    └── sqlite_logger.py
```

## 3. LoggerFactory Implementation

The `LoggerFactory` is implemented as a static class in `logger_factory.py`. Here's its implementation:

```python
from typing import Any, Dict, Literal, Optional

from autogen.logger.base_logger import BaseLogger
from autogen.logger.file_logger import FileLogger
from autogen.logger.sqlite_logger import SqliteLogger

class LoggerFactory:
    @staticmethod
    def get_logger(
        logger_type: Literal["sqlite", "file"] = "sqlite",
        config: Optional[Dict[str, Any]] = None
    ) -> BaseLogger:
        if config is None:
            config = {}

        if logger_type == "sqlite":
            return SqliteLogger(config)
        elif logger_type == "file":
            return FileLogger(config)
        else:
            raise ValueError(f"[logger_factory] Unknown logger type: {logger_type}")
```

This implementation allows for easy extension to support additional logger types in the future.

## 4. Using LoggerFactory

Here's how to use the `LoggerFactory` to create logger instances:

```python
from autogen import LoggerFactory

# Create a SQLite logger
sqlite_logger = LoggerFactory.get_logger(logger_type="sqlite", config={"dbname": "my_logs.db"})

# Create a File logger
file_logger = LoggerFactory.get_logger(logger_type="file", config={"filename": "my_logs.log"})
```

## 5. Practical Usage Patterns

Let's explore some practical usage patterns for the Autogen logging system.

### 5.1 Logging in a Simple Agent Interaction

```python
from autogen import ConversableAgent, OpenAIWrapper, LoggerFactory

# Create a logger
logger = LoggerFactory.get_logger(logger_type="sqlite")

# Start the logging session
session_id = logger.start()

# Create an OpenAI wrapper
oai_wrapper = OpenAIWrapper()
logger.log_new_wrapper(oai_wrapper, {"config_list": [{"model": "gpt-3.5-turbo"}]})

# Create agents
assistant = ConversableAgent("assistant", llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]})
user = ConversableAgent("user")

logger.log_new_agent(assistant, {"name": "assistant", "llm_config": {"config_list": [{"model": "gpt-3.5-turbo"}]}})
logger.log_new_agent(user, {"name": "user"})

# Simulate a conversation
user_message = "Hello, can you help me with a math problem?"
logger.log_event(user, "send_message", message=user_message)

assistant_response = assistant.generate_reply(user_message)
logger.log_event(assistant, "generate_reply", message=assistant_response)

# Stop the logging session
logger.stop()
```

### 5.2 Logging in a Group Chat Scenario

```python
from autogen import ConversableAgent, GroupChat, GroupChatManager, LoggerFactory

# Create a logger
logger = LoggerFactory.get_logger(logger_type="file", config={"filename": "group_chat_logs.log"})

# Start the logging session
session_id = logger.start()

# Create agents
user_proxy = ConversableAgent("user_proxy")
assistant1 = ConversableAgent("assistant1", llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]})
assistant2 = ConversableAgent("assistant2", llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]})

logger.log_new_agent(user_proxy, {"name": "user_proxy"})
logger.log_new_agent(assistant1, {"name": "assistant1", "llm_config": {"config_list": [{"model": "gpt-3.5-turbo"}]}})
logger.log_new_agent(assistant2, {"name": "assistant2", "llm_config": {"config_list": [{"model": "gpt-3.5-turbo"}]}})

# Create a group chat
groupchat = GroupChat(agents=[user_proxy, assistant1, assistant2], messages=[], max_round=10)
manager = GroupChatManager(groupchat=groupchat, llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]})

logger.log_event("system", "create_group_chat", agents=[agent.name for agent in groupchat.agents])

# Initiate the group chat
user_proxy.initiate_chat(
    manager,
    message="Let's discuss the pros and cons of renewable energy sources."
)

# Log the entire conversation
for message in groupchat.messages:
    logger.log_event(message["sender"], "group_chat_message", content=message["content"])

# Stop the logging session
logger.stop()
```

### 5.3 Logging Custom Events and Function Calls

```python
from autogen import ConversableAgent, LoggerFactory

def custom_function(x: int, y: int) -> int:
    return x + y

# Create a logger
logger = LoggerFactory.get_logger(logger_type="sqlite", config={"dbname": "function_logs.db"})

# Start the logging session
session_id = logger.start()

# Create an agent
agent = ConversableAgent("math_agent")
logger.log_new_agent(agent, {"name": "math_agent"})

# Log a custom event
logger.log_event(agent, "custom_event", data={"key": "value"})

# Log a function call
result = custom_function(5, 3)
logger.log_function_use(agent, custom_function, {"x": 5, "y": 3}, result)

# Stop the logging session
logger.stop()
```

## 6. Best Practices

1. **Choose the Right Logger**: Use `SqliteLogger` for structured data and complex querying needs, and `FileLogger` for simple logging and easy manual review.

2. **Log Consistently**: Log all significant events and interactions to maintain a comprehensive record of your application's behavior.

3. **Use Meaningful Event Names**: Choose clear and descriptive names for custom events to make log analysis easier.

4. **Include Relevant Context**: When logging events or function calls, include all relevant context that might be useful for debugging or analysis.

5. **Handle Errors Gracefully**: Ensure that logging errors don't disrupt your main application flow.

6. **Regularly Review Logs**: Periodically review your logs to identify patterns, issues, or areas for improvement in your application.

7. **Implement Log Rotation**: For long-running applications, implement log rotation to manage file sizes and maintain performance.

8. **Secure Sensitive Information**: Be cautious about logging sensitive information. Consider implementing log redaction for sensitive data.

## 7. Advanced Usage: Custom Logger Implementation

If you need a logger with specific functionality not covered by the existing implementations, you can create your own by subclassing `BaseLogger`:

```python
from autogen.logger import BaseLogger

class MyCustomLogger(BaseLogger):
    def __init__(self, config):
        # Custom initialization

    def start(self) -> str:
        # Custom start implementation

    def log_chat_completion(self, ...):
        # Custom chat completion logging

    # Implement other required methods...

# Register your custom logger with the LoggerFactory
LoggerFactory.register_logger("custom", MyCustomLogger)

# Use your custom logger
custom_logger = LoggerFactory.get_logger(logger_type="custom", config={...})
```

## 8. Conclusion

The Autogen logging system, with its `LoggerFactory` and various logger implementations, provides a flexible and powerful way to capture and analyze the behavior of your AI agents and applications. By following the patterns and best practices outlined in this lesson, you can effectively leverage logging to improve debugging, optimize performance, and gain valuable insights into your Autogen-based systems.

Remember that logging is not just about capturing data – it's about telling the story of your application's execution. Use it wisely to narrate that story in the most informative and useful way possible.

