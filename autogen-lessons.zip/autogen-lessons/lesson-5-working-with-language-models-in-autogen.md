# Lesson 5: Working with Language Models in Autogen

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Integration with OpenAI and Other LLM Providers](#integration-with-openai-and-other-llm-providers)
4. [Configuring and Using Different Models](#configuring-and-using-different-models)
5. [Handling API Calls and Rate Limiting](#handling-api-calls-and-rate-limiting)
6. [Implementing Custom LLM Clients](#implementing-custom-llm-clients)
7. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll dive deep into working with Language Models (LLMs) in Autogen. We'll explore how Autogen integrates with various LLM providers, configure and use different models, handle API calls and rate limiting, and even implement custom LLM clients. This knowledge is crucial for leveraging the full power of Autogen in your AI-powered applications.

## Project Structure

Before we begin, let's look at the project structure we'll be working with:

```
autogen_project/
│
├── src/
│   ├── __init__.py
│   ├── config.py
│   ├── llm_integration.py
│   ├── api_handler.py
│   └── custom_llm_client.py
│
├── tests/
│   ├── __init__.py
│   ├── test_llm_integration.py
│   ├── test_api_handler.py
│   └── test_custom_llm_client.py
│
├── .env
├── requirements.txt
└── main.py
```

This structure organizes our code into separate modules for better maintainability and testing.

## Integration with OpenAI and Other LLM Providers

Autogen provides a flexible framework for integrating with various LLM providers. Let's start by looking at how to integrate with OpenAI, and then we'll explore how to extend this to other providers.

### OpenAI Integration

First, let's set up our configuration in `src/config.py`:

```python
# src/config.py
import os
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1")

OPENAI_CONFIG = {
    "api_key": OPENAI_API_KEY,
    "api_base": OPENAI_API_BASE,
}
```

Now, let's create our LLM integration module in `src/llm_integration.py`:

```python
# src/llm_integration.py
from autogen import OpenAIWrapper
from .config import OPENAI_CONFIG

def get_openai_client():
    return OpenAIWrapper(**OPENAI_CONFIG)

def generate_response(client, prompt, model="gpt-3.5-turbo"):
    response = client.create(model=model, messages=[{"role": "user", "content": prompt}])
    return response.choices[0].message.content

# Usage example
if __name__ == "__main__":
    client = get_openai_client()
    prompt = "Explain the concept of machine learning in simple terms."
    response = generate_response(client, prompt)
    print(response)
```

### Integrating with Other LLM Providers

Autogen's `OpenAIWrapper` class is designed to work with OpenAI-compatible APIs. This means we can use it with other providers that offer OpenAI-compatible endpoints, such as Azure OpenAI or self-hosted models like LLaMA.

Here's an example of how to integrate with Azure OpenAI:

```python
# src/config.py
# ... (previous code)

AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_API_BASE = os.getenv("AZURE_OPENAI_API_BASE")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15")

AZURE_OPENAI_CONFIG = {
    "api_key": AZURE_OPENAI_API_KEY,
    "api_base": AZURE_OPENAI_API_BASE,
    "api_type": "azure",
    "api_version": AZURE_OPENAI_API_VERSION,
}

# src/llm_integration.py
# ... (previous code)

def get_azure_openai_client():
    return OpenAIWrapper(**AZURE_OPENAI_CONFIG)

def generate_azure_response(client, prompt, model="gpt-35-turbo"):
    response = client.create(model=model, messages=[{"role": "user", "content": prompt}])
    return response.choices[0].message.content
```

## Configuring and Using Different Models

Autogen allows you to easily switch between different models. Let's expand our `llm_integration.py` to support multiple models:

```python
# src/llm_integration.py
# ... (previous code)

AVAILABLE_MODELS = {
    "gpt-3.5-turbo": {"provider": "openai", "max_tokens": 4096},
    "gpt-4": {"provider": "openai", "max_tokens": 8192},
    "gpt-35-turbo": {"provider": "azure", "max_tokens": 4096},
    "gpt-4": {"provider": "azure", "max_tokens": 8192},
}

def get_model_config(model_name):
    return AVAILABLE_MODELS.get(model_name, AVAILABLE_MODELS["gpt-3.5-turbo"])

def generate_response_with_model(prompt, model_name="gpt-3.5-turbo"):
    model_config = get_model_config(model_name)
    client = get_openai_client() if model_config["provider"] == "openai" else get_azure_openai_client()
    
    response = client.create(
        model=model_name,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=model_config["max_tokens"]
    )
    return response.choices[0].message.content

# Usage example
if __name__ == "__main__":
    prompt = "Explain the difference between supervised and unsupervised learning."
    response_gpt3 = generate_response_with_model(prompt, "gpt-3.5-turbo")
    response_gpt4 = generate_response_with_model(prompt, "gpt-4")
    
    print("GPT-3.5 Response:", response_gpt3)
    print("GPT-4 Response:", response_gpt4)
```

This setup allows you to easily switch between different models and providers while keeping your main code clean and organized.

## Handling API Calls and Rate Limiting

When working with LLMs, it's crucial to handle API calls efficiently and respect rate limits. Let's create an `api_handler.py` module to manage this:

```python
# src/api_handler.py
import time
import asyncio
from typing import Callable, Any
from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type

class APIHandler:
    def __init__(self, rate_limit_per_minute: int = 60):
        self.rate_limit_per_minute = rate_limit_per_minute
        self.calls_made = 0
        self.start_time = time.time()

    async def _wait_for_rate_limit(self):
        elapsed_time = time.time() - self.start_time
        if elapsed_time < 60 and self.calls_made >= self.rate_limit_per_minute:
            wait_time = 60 - elapsed_time
            await asyncio.sleep(wait_time)
            self.calls_made = 0
            self.start_time = time.time()
        elif elapsed_time >= 60:
            self.calls_made = 0
            self.start_time = time.time()

    @retry(
        wait=wait_exponential(multiplier=1, min=4, max=10),
        stop=stop_after_attempt(5),
        retry=retry_if_exception_type(Exception)
    )
    async def call_api(self, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        await self._wait_for_rate_limit()
        self.calls_made += 1
        return await func(*args, **kwargs)

# Usage example
api_handler = APIHandler(rate_limit_per_minute=60)

async def make_api_call(client, prompt, model):
    return await api_handler.call_api(client.create, model=model, messages=[{"role": "user", "content": prompt}])

# In your main code:
# response = await make_api_call(client, prompt, model)
```

This `APIHandler` class manages rate limiting and implements exponential backoff for retries in case of failures.

## Implementing Custom LLM Clients

While Autogen provides built-in support for OpenAI-compatible APIs, you might need to integrate with other LLM providers or custom models. Let's create a custom LLM client as an example:

```python
# src/custom_llm_client.py
import aiohttp
from typing import List, Dict, Any

class CustomLLMClient:
    def __init__(self, api_base: str, api_key: str):
        self.api_base = api_base
        self.api_key = api_key

    async def create(self, model: str, messages: List[Dict[str, str]], **kwargs: Any) -> Dict[str, Any]:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        data = {
            "model": model,
            "messages": messages,
            **kwargs
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(f"{self.api_base}/v1/chat/completions", headers=headers, json=data) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    raise Exception(f"API call failed with status {response.status}: {await response.text()}")

# Usage example
custom_client = CustomLLMClient(api_base="https://api.customllm.com", api_key="your-api-key")

async def generate_custom_response(prompt: str, model: str = "custom-gpt"):
    response = await custom_client.create(
        model=model,
        messages=[{"role": "user", "content": prompt}]
    )
    return response["choices"][0]["message"]["content"]

# In your main code:
# response = await generate_custom_response("Tell me a joke about programming.")
```

This custom client can be easily integrated into your Autogen project, allowing you to use a wider range of LLM providers or your own models.

## Conclusion

In this lesson, we've explored working with Language Models in Autogen. We covered:

1. Integrating with OpenAI and other LLM providers
2. Configuring and using different models
3. Handling API calls and rate limiting
4. Implementing custom LLM clients

By mastering these concepts, you'll be able to leverage the full power of Autogen in your AI applications, creating more flexible and robust systems that can work with a variety of language models and providers.

Remember to always consider factors such as API usage costs, rate limits, and the specific capabilities of each model when designing your applications. Happy coding!
