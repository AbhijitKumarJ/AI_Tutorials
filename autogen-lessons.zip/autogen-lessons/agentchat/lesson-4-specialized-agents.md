# Lesson 4: Specialized Agents - AssistantAgent and UserProxyAgent

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [AssistantAgent](#assistantagent)
   - [Overview](#assistantagent-overview)
   - [Key Features](#assistantagent-key-features)
   - [Implementation](#assistantagent-implementation)
4. [UserProxyAgent](#userproxyagent)
   - [Overview](#userproxyagent-overview)
   - [Key Features](#userproxyagent-key-features)
   - [Implementation](#userproxyagent-implementation)
5. [Differences and Use Cases](#differences-and-use-cases)
6. [Customizing Specialized Agents](#customizing-specialized-agents)
7. [Practical Examples](#practical-examples)
8. [Exercises](#exercises)
9. [Summary](#summary)

## 1. Introduction

Welcome to Lesson 4 of our Autogen AgentChat series. In this lesson, we'll explore two specialized agent types: AssistantAgent and UserProxyAgent. These agents build upon the base Agent class we discussed in the previous lesson and provide specific functionalities for different roles in conversational AI systems.

## 2. Project Structure

Before we dive in, let's set up our project structure for this lesson:

```
autogen_tutorial/
├── lesson4_specialized_agents/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── custom_assistant.py
│   │   └── custom_user_proxy.py
│   ├── examples/
│   │   ├── __init__.py
│   │   ├── assistant_example.py
│   │   └── user_proxy_example.py
│   ├── exercises/
│   │   ├── __init__.py
│   │   └── exercise_1.py
│   ├── main.py
│   └── requirements.txt
└── README.md
```

Create these directories and files. We'll use them throughout the lesson to implement and test our specialized agents.

## 3. AssistantAgent

### AssistantAgent Overview

The AssistantAgent is designed to act as an AI assistant in conversations. It's primarily used to generate responses based on given prompts or questions.

### AssistantAgent Key Features

1. Customizable system message
2. Integration with language models (e.g., GPT-3.5, GPT-4)
3. Ability to generate human-like responses
4. Optional code execution capabilities

### AssistantAgent Implementation

Let's implement a custom AssistantAgent:

```python
# agents/custom_assistant.py

from autogen import AssistantAgent
from typing import Dict, Union

class CustomAssistantAgent(AssistantAgent):
    def __init__(self, name: str, system_message: str, llm_config: Dict[str, Union[str, int, float]]):
        super().__init__(name, system_message, llm_config=llm_config)
        self.conversation_history = []

    def generate_response(self, message: str) -> str:
        # In a real scenario, this would use the LLM. For this example, we'll simulate it.
        response = f"As an AI assistant named {self.name}, I respond: {message.upper()}"
        self.conversation_history.append({"role": "user", "content": message})
        self.conversation_history.append({"role": "assistant", "content": response})
        return response

    def get_conversation_history(self) -> list:
        return self.conversation_history
```

This custom AssistantAgent extends the base AssistantAgent with a conversation history feature and a simulated response generation method.

## 4. UserProxyAgent

### UserProxyAgent Overview

The UserProxyAgent acts as an interface between the AI system and a human user. It can handle user inputs, execute code, and manage the flow of conversation.

### UserProxyAgent Key Features

1. Human input handling
2. Code execution capabilities
3. Customizable auto-reply settings
4. Ability to terminate conversations based on specific conditions

### UserProxyAgent Implementation

Let's create a custom UserProxyAgent:

```python
# agents/custom_user_proxy.py

from autogen import UserProxyAgent
from typing import Dict, Union, List

class CustomUserProxyAgent(UserProxyAgent):
    def __init__(self, name: str, human_input_mode: str, max_consecutive_auto_reply: int = 2):
        super().__init__(name, human_input_mode=human_input_mode, max_consecutive_auto_reply=max_consecutive_auto_reply)
        self.query_history = []

    def get_human_input(self, prompt: str) -> str:
        # In a real scenario, this would get input from a human. Here, we'll simulate it.
        simulated_input = f"Simulated human input for: {prompt}"
        self.query_history.append({"prompt": prompt, "response": simulated_input})
        return simulated_input

    def execute_code(self, code: str) -> str:
        # Simulate code execution
        result = f"Executed code: {code}\nResult: Success"
        return result

    def get_query_history(self) -> List[Dict[str, str]]:
        return self.query_history
```

This custom UserProxyAgent extends the base UserProxyAgent with a query history feature and simulated methods for human input and code execution.

## 5. Differences and Use Cases

| Feature | AssistantAgent | UserProxyAgent |
|---------|----------------|----------------|
| Primary Role | Generate AI responses | Interface with human users |
| Input Handling | Processes messages from other agents | Can receive direct human input |
| Code Execution | Optional | Built-in capability |
| Auto-reply | Always auto-replies | Configurable auto-reply settings |
| Use Cases | AI chatbots, knowledge-based assistants | Human-in-the-loop systems, interactive coding environments |

## 6. Customizing Specialized Agents

To customize these specialized agents further, you can:

1. Override specific methods to change behavior
2. Add new methods for additional functionality
3. Modify the initialization process to include new parameters

Example of adding a new method to AssistantAgent:

```python
# agents/custom_assistant.py

class CustomAssistantAgent(AssistantAgent):
    # ... (previous code)

    def summarize_conversation(self) -> str:
        summary = "Conversation Summary:\n"
        for entry in self.conversation_history:
            summary += f"{entry['role'].capitalize()}: {entry['content'][:50]}...\n"
        return summary
```

## 7. Practical Examples

Let's create a simple scenario where an AssistantAgent and a UserProxyAgent interact:

```python
# examples/assistant_user_interaction.py

from agents.custom_assistant import CustomAssistantAgent
from agents.custom_user_proxy import CustomUserProxyAgent

def run_conversation():
    assistant = CustomAssistantAgent(
        name="AI_Assistant",
        system_message="You are a helpful AI assistant.",
        llm_config={"model": "gpt-3.5-turbo", "temperature": 0.7}
    )

    user_proxy = CustomUserProxyAgent(
        name="Human_User",
        human_input_mode="ALWAYS",
        max_consecutive_auto_reply=2
    )

    # Simulate a conversation
    user_message = "Can you help me understand how neural networks work?"
    print(f"Human: {user_message}")
    
    assistant_response = assistant.generate_response(user_message)
    print(f"AI Assistant: {assistant_response}")

    user_input = user_proxy.get_human_input("Do you have any follow-up questions?")
    print(f"Human: {user_input}")

    assistant_response = assistant.generate_response(user_input)
    print(f"AI Assistant: {assistant_response}")

    # Display conversation summary
    print("\nAssistant's Conversation Summary:")
    print(assistant.summarize_conversation())

    print("\nUser's Query History:")
    for query in user_proxy.get_query_history():
        print(f"Prompt: {query['prompt']}")
        print(f"Response: {query['response']}")
        print()

if __name__ == "__main__":
    run_conversation()
```

This example demonstrates how the AssistantAgent and UserProxyAgent can be used together to create an interactive conversation system.

## 8. Exercises

To reinforce your understanding of specialized agents, complete the following exercise:

```python
# exercises/exercise_1.py

from autogen import AssistantAgent, UserProxyAgent
from typing import List, Dict

class CodeAssistant(AssistantAgent):
    def __init__(self, name: str):
        super().__init__(name, system_message="You are a Python coding expert.")
        # TODO: Initialize any additional attributes

    def generate_code(self, task: str) -> str:
        # TODO: Implement a method to generate Python code based on the given task
        pass

    def explain_code(self, code: str) -> str:
        # TODO: Implement a method to explain the given code
        pass

class CodeTester(UserProxyAgent):
    def __init__(self, name: str):
        super().__init__(name, human_input_mode="NEVER")
        # TODO: Initialize any additional attributes

    def test_code(self, code: str) -> Dict[str, Union[bool, str]]:
        # TODO: Implement a method to test the given code and return the result
        pass

    def provide_feedback(self, test_result: Dict[str, Union[bool, str]]) -> str:
        # TODO: Implement a method to provide feedback based on the test result
        pass

# TODO: Create a main function that demonstrates the interaction between CodeAssistant and CodeTester
```

Exercise: Complete the `CodeAssistant` and `CodeTester` classes by implementing the required methods. Create a main function that demonstrates how these specialized agents can work together in a coding task scenario.

## 9. Summary

In this lesson, we've explored two specialized agent types in the Autogen framework: AssistantAgent and UserProxyAgent. We've learned about their key features, implementation details, and how to customize them for specific use cases.

Key takeaways:
1. AssistantAgent is designed for generating AI responses in conversations.
2. UserProxyAgent serves as an interface between the AI system and human users.
3. Both agent types can be customized and extended to fit specific requirements.
4. The choice between AssistantAgent and UserProxyAgent depends on the role needed in the conversation system.

In the next lesson, we'll dive into group chats and explore how multiple agents can collaborate in more complex conversational scenarios.

