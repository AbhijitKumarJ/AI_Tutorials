# Lesson 5: Group Chats and Collaboration

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding GroupChat](#understanding-groupchat)
   3.1 [GroupChat Initialization](#groupchat-initialization)
   3.2 [Key Attributes and Methods](#key-attributes-and-methods)
4. [GroupChatManager](#groupchatmanager)
   4.1 [Initializing GroupChatManager](#initializing-groupchatmanager)
   4.2 [Running a Group Chat](#running-a-group-chat)
5. [Speaker Selection Methods](#speaker-selection-methods)
6. [Advanced Features](#advanced-features)
   6.1 [Message Transformations](#message-transformations)
   6.2 [Resuming Conversations](#resuming-conversations)
7. [Practical Example: Multi-Agent Problem Solving](#practical-example-multi-agent-problem-solving)
8. [Best Practices and Considerations](#best-practices-and-considerations)
9. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll explore the powerful group chat and collaboration features of Autogen. We'll focus on the `GroupChat` and `GroupChatManager` classes, which enable multi-agent conversations and complex problem-solving scenarios. By the end of this lesson, you'll be able to create and manage group chats with multiple AI agents, control the flow of conversation, and implement sophisticated collaboration patterns.

## 2. Project Structure

Before we dive into the details, let's look at a typical project structure for an Autogen application that utilizes group chats:

```
autogen_group_chat_project/
│
├── agents/
│   ├── __init__.py
│   ├── custom_agent.py
│   └── specialized_agent.py
│
├── group_chats/
│   ├── __init__.py
│   ├── problem_solving_chat.py
│   └── brainstorming_chat.py
│
├── utils/
│   ├── __init__.py
│   └── message_utils.py
│
├── config/
│   └── config.json
│
├── main.py
├── requirements.txt
└── README.md
```

This structure organizes our code into logical components:
- `agents/`: Contains custom agent implementations.
- `group_chats/`: Holds different group chat configurations and implementations.
- `utils/`: Utility functions and helpers.
- `config/`: Configuration files for LLM settings, etc.
- `main.py`: The entry point of our application.

## 3. Understanding GroupChat

The `GroupChat` class is the core component for managing multi-agent conversations. It handles the logistics of message passing, speaker selection, and conversation flow.

### 3.1 GroupChat Initialization

Let's look at how to initialize a `GroupChat`:

```python
from autogen import GroupChat, AssistantAgent, UserProxyAgent

# Create agents
assistant = AssistantAgent("AI_Assistant", llm_config={"config_list": [{"model": "gpt-4"}]})
user_proxy = UserProxyAgent("User", code_execution_config={"work_dir": "coding"})
expert = AssistantAgent("Expert", llm_config={"config_list": [{"model": "gpt-4"}]})

# Initialize GroupChat
groupchat = GroupChat(
    agents=[user_proxy, assistant, expert],
    messages=[],
    max_round=10,
    speaker_selection_method="auto",
    allow_repeat_speaker=True
)
```

In this example, we create three agents: a user proxy, an AI assistant, and an expert. We then initialize a `GroupChat` with these agents, setting a maximum of 10 rounds and using the "auto" speaker selection method.

### 3.2 Key Attributes and Methods

The `GroupChat` class has several important attributes and methods:

- `agents`: List of participating agents.
- `messages`: List of messages in the group chat.
- `max_round`: Maximum number of conversation rounds.
- `speaker_selection_method`: Method for selecting the next speaker.
- `select_speaker`: Method to choose the next speaker.
- `append`: Method to add a message to the chat history.

## 4. GroupChatManager

The `GroupChatManager` is a special agent that manages the group chat. It's responsible for running the conversation and coordinating between agents.

### 4.1 Initializing GroupChatManager

Here's how to create a `GroupChatManager`:

```python
from autogen import GroupChatManager

# Initialize GroupChatManager
manager = GroupChatManager(
    groupchat=groupchat,
    name="Manager",
    human_input_mode="NEVER",
    system_message="You are managing a group chat."
)
```

### 4.2 Running a Group Chat

To start a group chat, we use the `initiate_chat` method of the `GroupChatManager`:

```python
user_proxy.initiate_chat(
    manager,
    message="Let's solve a complex math problem as a team."
)
```

This will start the group chat, with the user proxy initiating the conversation.

## 5. Speaker Selection Methods

Autogen supports several methods for selecting the next speaker in a group chat:

1. "auto": The next speaker is selected automatically by the LLM.
2. "manual": The next speaker is selected manually by user input.
3. "random": The next speaker is selected randomly.
4. "round_robin": The next speaker is selected in a round-robin fashion.

You can also implement a custom speaker selection function:

```python
def custom_speaker_selection(last_speaker: Agent, groupchat: GroupChat) -> Union[Agent, str, None]:
    # Your custom logic here
    return next_speaker

groupchat = GroupChat(
    agents=[user_proxy, assistant, expert],
    speaker_selection_method=custom_speaker_selection
)
```

## 6. Advanced Features

### 6.1 Message Transformations

Autogen allows you to apply transformations to messages before they are processed. This can be useful for tasks like truncating long messages or filtering sensitive information.

```python
from autogen.agentchat.contrib.capabilities import TransformMessages
from autogen.agentchat.contrib.capabilities.transforms import MessageHistoryLimiter

# Create a message transformation
message_limiter = MessageHistoryLimiter(max_messages=5)

# Apply the transformation to the GroupChatManager
transform_messages = TransformMessages(transforms=[message_limiter])
transform_messages.add_to_agent(manager)
```

### 6.2 Resuming Conversations

GroupChatManager provides methods to resume a previous conversation:

```python
# Save conversation state
conversation_state = manager.messages_to_string(groupchat.messages)

# ... Later, to resume the conversation
last_speaker, last_message = manager.resume(
    conversation_state,
    remove_termination_string="TERMINATE",
)

# Continue the conversation
user_proxy.send(
    "Let's continue our discussion.",
    manager
)
```

## 7. Practical Example: Multi-Agent Problem Solving

Let's put everything together in a practical example of multi-agent problem solving. We'll create a group chat to solve a complex task that requires different areas of expertise.

```python
# agents/custom_agent.py
from autogen import AssistantAgent

class MathExpert(AssistantAgent):
    def __init__(self, name):
        super().__init__(
            name=name,
            system_message="You are a mathematics expert. Solve complex math problems step by step.",
            llm_config={"config_list": [{"model": "gpt-4"}]}
        )

class ProgrammingExpert(AssistantAgent):
    def __init__(self, name):
        super().__init__(
            name=name,
            system_message="You are a programming expert. Implement solutions in Python with clear explanations.",
            llm_config={"config_list": [{"model": "gpt-4"}]}
        )

# group_chats/problem_solving_chat.py
from autogen import GroupChat, GroupChatManager, UserProxyAgent
from agents.custom_agent import MathExpert, ProgrammingExpert

def create_problem_solving_chat():
    user_proxy = UserProxyAgent("User", code_execution_config={"work_dir": "coding"})
    math_expert = MathExpert("MathExpert")
    programming_expert = ProgrammingExpert("ProgrammingExpert")
    
    groupchat = GroupChat(
        agents=[user_proxy, math_expert, programming_expert],
        messages=[],
        max_round=20,
        speaker_selection_method="auto"
    )
    
    manager = GroupChatManager(groupchat=groupchat, name="Manager")
    return user_proxy, manager

# main.py
from group_chats.problem_solving_chat import create_problem_solving_chat

def main():
    user_proxy, manager = create_problem_solving_chat()
    
    user_proxy.initiate_chat(
        manager,
        message="We need to create a Python function that calculates the nth Fibonacci number using dynamic programming and analyzes its time complexity. Can you help?"
    )

if __name__ == "__main__":
    main()
```

In this example, we've created a group chat with a user proxy, a math expert, and a programming expert. The group is tasked with creating and analyzing a Fibonacci function. The agents will collaborate, with the math expert providing the mathematical insights and the programming expert implementing the solution.

## 8. Best Practices and Considerations

When working with group chats in Autogen, keep these best practices in mind:

1. **Agent Roles**: Clearly define the role and expertise of each agent in the group chat.
2. **Conversation Flow**: Choose an appropriate speaker selection method based on your use case.
3. **Message Handling**: Implement message transformations to manage conversation history and content.
4. **Error Handling**: Implement proper error handling, especially when dealing with code execution in group chats.
5. **Scalability**: Be mindful of the number of agents and conversation rounds to manage computational resources.
6. **Testing**: Thoroughly test your group chat setups with various scenarios to ensure robust performance.

## 9. Conclusion

In this lesson, we've explored the powerful group chat and collaboration features of Autogen. We've learned how to:

- Initialize and configure `GroupChat` and `GroupChatManager`
- Implement custom agents for specialized tasks
- Use different speaker selection methods
- Apply advanced features like message transformations and conversation resumption
- Create a practical multi-agent problem-solving scenario

Group chats in Autogen open up exciting possibilities for complex problem-solving, brainstorming, and collaborative AI applications. By leveraging these features, you can create sophisticated multi-agent systems that tackle a wide range of tasks and challenges.

In the next lesson, we'll dive deeper into advanced topics such as fine-tuning agent behaviors, optimizing performance, and integrating Autogen with external services and APIs.
