# Lesson 8: Contributed Agents and Utilities (Part 2)

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [LLaVA Agent](#llava-agent)
4. [Math User Proxy Agent](#math-user-proxy-agent)
5. [Multimodal Conversable Agent](#multimodal-conversable-agent)
6. [Web Surfer Agent](#web-surfer-agent)
7. [Practical Examples](#practical-examples)
8. [Exercises](#exercises)
9. [Conclusion](#conclusion)

## 1. Introduction <a name="introduction"></a>

Welcome to Lesson 8 of our Autogen AgentChat series! In this lesson, we'll continue our exploration of the `contrib` folder, focusing on specialized agents and utilities that extend the capabilities of the AgentChat module. We'll cover the LLaVA agent, Math User Proxy agent, Multimodal Conversable agent, and the Web Surfer agent. These components allow us to create more sophisticated and specialized AI systems capable of handling a wide range of tasks.

## 2. Project Structure <a name="project-structure"></a>

Before we dive into the details, let's look at the project structure for this lesson:

```
autogen_tutorial/
├── lesson8_advanced_agents/
│   ├── llava_example.py
│   ├── math_proxy_example.py
│   ├── multimodal_example.py
│   ├── web_surfer_example.py
│   ├── data/
│   │   ├── sample_image.jpg
│   │   └── math_problem.txt
│   ├── requirements.txt
│   └── README.md
└── README.md
```

Make sure to set up a virtual environment and install the required dependencies:

```bash
python -m venv venv
source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
pip install -r requirements.txt
```

## 3. LLaVA Agent <a name="llava-agent"></a>

The LLaVA (Large Language and Vision Assistant) agent is designed to handle both text and image inputs, making it suitable for multimodal tasks. Let's examine its key features and usage.

### Key Features:
- Handles both text and image inputs
- Uses a vision-language model for processing
- Supports various image formats and sources

### Implementation:

```python
# llava_example.py
from autogen.agentchat.contrib.llava_agent import LLaVAAgent
from autogen import UserProxyAgent
import autogen

# Configure the LLaVA agent
llava_config = {
    "base_url": "http://localhost:8000",  # Replace with your LLaVA server URL
    "model": "llava-v1.5-7b",
}

# Create the LLaVA agent
llava_agent = LLaVAAgent(
    name="llava_agent",
    llm_config={"config_list": [llava_config]},
)

# Create a user proxy agent
user_proxy = UserProxyAgent(
    name="user_proxy",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
)

# Start a conversation
user_proxy.initiate_chat(
    llava_agent,
    message="What's in this image?",
    image="data/sample_image.jpg"
)
```

In this example, we create a LLaVA agent and a user proxy agent. The user proxy initiates a chat with the LLaVA agent, asking about the contents of an image. The LLaVA agent processes both the text question and the image, providing a response based on its multimodal understanding.

## 4. Math User Proxy Agent <a name="math-user-proxy-agent"></a>

The Math User Proxy Agent is specialized for handling mathematical problems and computations. It can interpret mathematical queries, perform calculations, and provide step-by-step solutions.

### Key Features:
- Interprets mathematical questions and problems
- Performs calculations and provides detailed solutions
- Supports various mathematical operations and concepts

### Implementation:

```python
# math_proxy_example.py
from autogen.agentchat.contrib.math_user_proxy_agent import MathUserProxyAgent
from autogen import AssistantAgent
import autogen

# Configure the Math User Proxy agent
math_config = {
    "use_docker": False,  # Set to True if you want to use Docker for code execution
    "timeout": 60,
    "ask_human": False,
}

# Create the Math User Proxy agent
math_agent = MathUserProxyAgent(
    name="math_agent",
    llm_config={"config_list": [{"model": "gpt-4"}]},
    code_execution_config=math_config,
)

# Create an assistant agent
assistant = AssistantAgent(
    name="assistant",
    llm_config={"config_list": [{"model": "gpt-4"}]},
)

# Start a conversation
math_agent.initiate_chat(
    assistant,
    message="Solve the quadratic equation: x^2 + 5x + 6 = 0"
)
```

In this example, we create a Math User Proxy agent and an assistant agent. The Math User Proxy agent initiates a chat with the assistant, asking to solve a quadratic equation. The assistant provides the solution, and the Math User Proxy agent can interpret and verify the results.

## 5. Multimodal Conversable Agent <a name="multimodal-conversable-agent"></a>

The Multimodal Conversable Agent extends the capabilities of the standard ConversableAgent to handle multiple types of input, including text, images, and potentially other modalities.

### Key Features:
- Processes multiple input types (text, images, etc.)
- Integrates various AI models for different modalities
- Provides a unified interface for multimodal conversations

### Implementation:

```python
# multimodal_example.py
from autogen.agentchat.contrib.multimodal_conversable_agent import MultimodalConversableAgent
from autogen import UserProxyAgent
import autogen

# Configure the Multimodal Conversable agent
multimodal_config = {
    "llm_config": {
        "config_list": [{"model": "gpt-4-vision-preview"}],
    },
    "image_model": "clip-vit-base-patch32",
}

# Create the Multimodal Conversable agent
multimodal_agent = MultimodalConversableAgent(
    name="multimodal_agent",
    **multimodal_config
)

# Create a user proxy agent
user_proxy = UserProxyAgent(
    name="user_proxy",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
)

# Start a conversation
user_proxy.initiate_chat(
    multimodal_agent,
    message=[
        {"type": "text", "content": "Describe this image in detail:"},
        {"type": "image", "image_url": "data/sample_image.jpg"}
    ]
)
```

In this example, we create a Multimodal Conversable agent and a user proxy agent. The user proxy initiates a chat with the multimodal agent, sending both text and an image. The multimodal agent processes both inputs and provides a detailed description of the image.

## 6. Web Surfer Agent <a name="web-surfer-agent"></a>

The Web Surfer Agent is designed to browse the internet, search for information, and interact with web content. It can be used for tasks that require up-to-date information or specific web-based research.

### Key Features:
- Performs web searches
- Navigates web pages
- Extracts relevant information from websites

### Implementation:

```python
# web_surfer_example.py
from autogen.agentchat.contrib.web_surfer import WebSurferAgent
from autogen import UserProxyAgent
import autogen

# Configure the Web Surfer agent
web_surfer_config = {
    "browser_config": {
        "viewport_size": {"width": 1280, "height": 720},
    },
    "llm_config": {
        "config_list": [{"model": "gpt-4"}],
    },
}

# Create the Web Surfer agent
web_surfer = WebSurferAgent(
    name="web_surfer",
    **web_surfer_config
)

# Create a user proxy agent
user_proxy = UserProxyAgent(
    name="user_proxy",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
)

# Start a conversation
user_proxy.initiate_chat(
    web_surfer,
    message="Find the latest news about artificial intelligence breakthroughs"
)
```

In this example, we create a Web Surfer agent and a user proxy agent. The user proxy initiates a chat with the web surfer, asking for the latest news about AI breakthroughs. The web surfer agent searches the internet, navigates relevant web pages, and provides a summary of the latest AI news.

## 7. Practical Examples <a name="practical-examples"></a>

Now that we've covered the individual agents, let's look at a more complex example that combines multiple agents to solve a real-world problem.

### Multi-Agent Research System

In this example, we'll create a system that combines the LLaVA agent, Math User Proxy agent, and Web Surfer agent to perform a comprehensive research task.

```python
# multi_agent_research.py
from autogen.agentchat.contrib.llava_agent import LLaVAAgent
from autogen.agentchat.contrib.math_user_proxy_agent import MathUserProxyAgent
from autogen.agentchat.contrib.web_surfer import WebSurferAgent
from autogen import UserProxyAgent, AssistantAgent, GroupChat, GroupChatManager
import autogen

# Create agents
llava_agent = LLaVAAgent(name="llava", llm_config={"config_list": [{"model": "llava-v1.5-7b"}]})
math_agent = MathUserProxyAgent(name="math_expert", llm_config={"config_list": [{"model": "gpt-4"}]})
web_surfer = WebSurferAgent(name="web_researcher", llm_config={"config_list": [{"model": "gpt-4"}]})
assistant = AssistantAgent(name="assistant", llm_config={"config_list": [{"model": "gpt-4"}]})
user_proxy = UserProxyAgent(name="user_proxy", human_input_mode="TERMINATE")

# Create a group chat
agents = [user_proxy, llava_agent, math_agent, web_surfer, assistant]
groupchat = GroupChat(agents=agents, messages=[], max_round=50)
manager = GroupChatManager(groupchat=groupchat, llm_config={"config_list": [{"model": "gpt-4"}]})

# Start the research task
user_proxy.initiate_chat(
    manager,
    message="""
    Research task:
    1. Find the latest advancements in quantum computing (use web_researcher)
    2. Analyze an image of a quantum computer and describe its components (use llava)
    3. Calculate the potential speed-up of a quantum algorithm compared to its classical counterpart (use math_expert)
    4. Summarize the findings and their implications for the future of computing (use assistant)
    """
)
```

This example demonstrates how different specialized agents can work together to perform a complex research task involving web searches, image analysis, mathematical calculations, and summarization.

## 8. Exercises <a name="exercises"></a>

To reinforce your understanding of these advanced agents, try the following exercises:

1. Create a system that uses the LLaVA agent to analyze a series of images and the Math User Proxy agent to perform statistical analysis on the results.

2. Implement a web-based fact-checking system using the Web Surfer agent and the Multimodal Conversable agent to verify claims in both text and images.

3. Design a scientific research assistant that combines all four agents to help with literature reviews, data analysis, and hypothesis generation.

## 9. Conclusion <a name="conclusion"></a>

In this lesson, we've explored four powerful contributed agents in the Autogen AgentChat module: the LLaVA agent, Math User Proxy agent, Multimodal Conversable agent, and Web Surfer agent. These specialized agents extend the capabilities of the basic AgentChat system, allowing for more sophisticated and diverse applications.

By combining these agents, we can create complex AI systems capable of handling a wide range of tasks, from image analysis and mathematical problem-solving to web research and multimodal interactions. As you continue to work with Autogen, experiment with different combinations of these agents to solve real-world problems and create innovative AI applications.

In the next lesson, we'll dive into advanced topics such as agent evaluation, custom capabilities, and graph-based retrieval-augmented generation (RAG) systems.
