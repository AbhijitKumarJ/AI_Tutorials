# Lesson 6: Human Interaction: HumanProxyAgent

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding HumanProxyAgent](#understanding-humanproxyagent)
4. [Implementing Human-in-the-Loop Systems](#implementing-human-in-the-loop-systems)
5. [Balancing Automation and Human Input](#balancing-automation-and-human-input)
6. [Practical Examples](#practical-examples)
7. [Exercise](#exercise)
8. [Summary](#summary)

## 1. Introduction

In this lesson, we'll dive deep into the HumanProxyAgent, a crucial component of the Autogen framework that allows for human interaction within AI-driven conversations. We'll explore how to implement human-in-the-loop systems, balance automation with human input, and create more robust and flexible AI applications.

The HumanProxyAgent is defined in the `human_proxy_agent.py` file within the Autogen library. This agent type is designed to represent a human user in the conversation, allowing for real-time human input and interaction with other AI agents.

## 2. Project Structure

Before we begin, let's set up our project structure for this lesson:

```
autogen_tutorial/
├── lesson6_human_proxy_agent/
│   ├── basic_human_interaction.py
│   ├── advanced_human_interaction.py
│   ├── hybrid_workflow.py
│   ├── custom_human_proxy.py
│   └── requirements.txt
├── data/
│   └── sample_tasks.json
└── README.md
```

Make sure to install the required dependencies:

```bash
pip install -r lesson6_human_proxy_agent/requirements.txt
```

## 3. Understanding HumanProxyAgent

The HumanProxyAgent is a subclass of the UserProxyAgent, which itself is a subclass of the ConversableAgent. It's designed to simulate or facilitate human interaction within an agent-based conversation system.

Key features of the HumanProxyAgent include:

1. Human input handling
2. Code execution capabilities
3. Flexible configuration options

Let's examine the basic structure of the HumanProxyAgent:

```python
# basic_human_interaction.py

from autogen import AssistantAgent, HumanProxyAgent

# Create an AI assistant
assistant = AssistantAgent(
    name="AI_Assistant",
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7,
    }
)

# Create a HumanProxyAgent
human = HumanProxyAgent(
    name="Human",
    human_input_mode="ALWAYS",
    max_consecutive_auto_reply=1,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={"work_dir": "coding"}
)

# Start a conversation
human.initiate_chat(assistant, message="Hello, can you help me with a Python problem?")
```

In this example, we create a HumanProxyAgent that always prompts for human input (`human_input_mode="ALWAYS"`), limits consecutive auto-replies to 1, and can execute code in a specified working directory.

## 4. Implementing Human-in-the-Loop Systems

Human-in-the-loop systems combine the strengths of AI with human expertise and decision-making. The HumanProxyAgent facilitates this by allowing seamless integration of human input into AI-driven workflows.

Let's implement a more advanced example that demonstrates a human-in-the-loop system:

```python
# advanced_human_interaction.py

import autogen

# Configure the AI assistant
assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7,
    }
)

# Configure the HumanProxyAgent
human = autogen.HumanProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=3,
    is_termination_msg=lambda x: "FINAL ANSWER:" in x.get("content", "").upper(),
    code_execution_config={
        "work_dir": "coding",
        "use_docker": False,
    }
)

# Define the task
task = """
1. Generate a Python function to calculate the Fibonacci sequence.
2. Implement error handling for invalid inputs.
3. Write unit tests for the function.
4. Ask for human review and approval before finalizing.
"""

# Start the conversation
human.initiate_chat(
    assistant,
    message=f"Let's work on this programming task together: {task}"
)

# The conversation will continue until the human sends a message containing "FINAL ANSWER:"
```

In this example, the HumanProxyAgent is configured to allow up to 3 consecutive auto-replies from the AI assistant before prompting for human input. The conversation continues until the human sends a message containing "FINAL ANSWER:", indicating that the task is complete.

## 5. Balancing Automation and Human Input

One of the key challenges in human-in-the-loop systems is finding the right balance between automation and human input. The HumanProxyAgent provides several configuration options to help achieve this balance:

1. `human_input_mode`: Determines when to ask for human input
   - "ALWAYS": Always ask for human input
   - "NEVER": Never ask for human input
   - "TERMINATE": Only ask for human input when a termination message is received

2. `max_consecutive_auto_reply`: Limits the number of consecutive automated responses

3. `is_termination_msg`: A function that determines if a message should terminate the conversation

Let's create a hybrid workflow that demonstrates this balance:

```python
# hybrid_workflow.py

import autogen

def is_complex_task(message):
    # Define criteria for complex tasks that require human intervention
    complex_keywords = ["complex", "difficult", "advanced", "expert"]
    return any(keyword in message.get("content", "").lower() for keyword in complex_keywords)

# Configure the AI assistant
assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7,
    }
)

# Configure the HumanProxyAgent with dynamic human input
human = autogen.HumanProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=5,
    is_termination_msg=lambda x: is_complex_task(x) or "HUMAN_INTERVENTION_REQUIRED" in x.get("content", "").upper(),
    code_execution_config={
        "work_dir": "coding",
        "use_docker": False,
    }
)

# Define a list of tasks
tasks = [
    "Generate a Python function to calculate the sum of even numbers in a list.",
    "Create a complex algorithm to optimize database queries for a large-scale system.",
    "Write a simple 'Hello, World!' program in Python.",
    "Develop an advanced machine learning model for predictive maintenance.",
]

# Process tasks
for task in tasks:
    print(f"\nProcessing task: {task}")
    human.initiate_chat(
        assistant,
        message=f"Please help me with the following task: {task}"
    )
    print("Task completed. Moving to the next task.")

print("All tasks processed.")
```

In this hybrid workflow, the system automatically handles simple tasks while requesting human intervention for complex ones. The `is_complex_task` function determines when human input is required based on the content of the message.

## 6. Practical Examples

Now, let's look at a more practical example where we create a custom HumanProxyAgent for a specific use case:

```python
# custom_human_proxy.py

import autogen
import json

class DataAnalystHumanProxy(autogen.HumanProxyAgent):
    def __init__(self, name, data_source, **kwargs):
        super().__init__(name, **kwargs)
        self.data_source = data_source

    def get_human_input(self, prompt):
        print(f"\n{prompt}")
        print("Options:")
        print("1. Provide input")
        print("2. Run data analysis")
        print("3. Terminate conversation")
        choice = input("Enter your choice (1-3): ")

        if choice == '1':
            return input("Enter your input: ")
        elif choice == '2':
            return self.run_data_analysis()
        elif choice == '3':
            return "TERMINATE"
        else:
            return "Invalid choice. Please try again."

    def run_data_analysis(self):
        print(f"Running data analysis on {self.data_source}")
        # Simulating data analysis
        with open(self.data_source, 'r') as f:
            data = json.load(f)
        
        total_tasks = len(data['tasks'])
        completed_tasks = sum(1 for task in data['tasks'] if task['status'] == 'completed')
        completion_rate = (completed_tasks / total_tasks) * 100

        analysis_result = f"Data Analysis Result:\n"
        analysis_result += f"Total tasks: {total_tasks}\n"
        analysis_result += f"Completed tasks: {completed_tasks}\n"
        analysis_result += f"Completion rate: {completion_rate:.2f}%"

        return analysis_result

# Configure the AI assistant
assistant = autogen.AssistantAgent(
    name="DataAnalysisAssistant",
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7,
    }
)

# Configure the custom HumanProxyAgent
human_analyst = DataAnalystHumanProxy(
    name="DataAnalyst",
    data_source="data/sample_tasks.json",
    human_input_mode="ALWAYS",
    max_consecutive_auto_reply=2,
    code_execution_config={"work_dir": "analysis"}
)

# Start the conversation
human_analyst.initiate_chat(
    assistant,
    message="Let's analyze our task completion data and generate a report."
)
```

In this example, we've created a custom `DataAnalystHumanProxy` that can interact with a data source and perform basic data analysis. This demonstrates how the HumanProxyAgent can be extended to fit specific use cases and workflows.

## 7. Exercise

Now it's your turn to practice! Create a HumanProxyAgent-based system for a customer support scenario. The system should:

1. Handle basic customer inquiries automatically
2. Escalate complex issues to a human representative
3. Allow the human representative to take control of the conversation when necessary
4. Provide a summary of each customer interaction

Use the concepts and techniques we've covered in this lesson to implement this system.

## 8. Summary

In this lesson, we've explored the HumanProxyAgent and its role in creating human-in-the-loop systems with Autogen. We've covered:

1. The basic structure and features of the HumanProxyAgent
2. Implementing human-in-the-loop systems for various scenarios
3. Balancing automation and human input in AI-driven workflows
4. Creating custom HumanProxyAgent classes for specific use cases

The HumanProxyAgent is a powerful tool for creating more flexible, robust, and human-centered AI applications. By effectively combining human expertise with AI capabilities, you can build systems that leverage the strengths of both humans and machines.

In the next lesson, we'll dive into the contrib folder of the AgentChat module, exploring additional agents and utilities that can further enhance your Autogen-based applications.
