# Lesson 3: Deep Dive into ConversableAgent

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding ConversableAgent](#understanding-conversable-agent)
4. [Key Components of ConversableAgent](#key-components-of-conversable-agent)
5. [Initialization and Configuration](#initialization-and-configuration)
6. [Message Handling](#message-handling)
7. [Reply Generation](#reply-generation)
8. [Function and Tool Execution](#function-and-tool-execution)
9. [Human Input Handling](#human-input-handling)
10. [Code Execution](#code-execution)
11. [Advanced Features](#advanced-features)
12. [Best Practices and Tips](#best-practices-and-tips)
13. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll take a deep dive into the `ConversableAgent` class, which is a fundamental component of the Autogen library. The `ConversableAgent` serves as a base class for various types of agents that can engage in conversations, execute functions, and perform tasks. Understanding this class is crucial for creating sophisticated AI agents and building complex conversational systems.

## 2. Project Structure

Before we delve into the details, let's look at a typical project structure when working with `ConversableAgent`:

```
autogen_project/
│
├── agents/
│   ├── __init__.py
│   ├── custom_assistant.py
│   └── custom_user_proxy.py
│
├── configs/
│   └── agent_config.json
│
├── functions/
│   ├── __init__.py
│   └── custom_functions.py
│
├── utils/
│   └── helpers.py
│
├── main.py
├── requirements.txt
└── README.md
```

This structure organizes our code into logical components:
- `agents/`: Contains our custom agent implementations
- `configs/`: Stores configuration files for our agents
- `functions/`: Houses custom functions that our agents can use
- `utils/`: Contains helper functions and utilities
- `main.py`: The entry point of our application

## 3. Understanding ConversableAgent

The `ConversableAgent` class is designed to be a versatile base for creating agents that can engage in conversations, execute functions, and perform various tasks. It provides a rich set of features that allow for complex interactions and decision-making processes.

Key characteristics of `ConversableAgent`:
- Can send and receive messages
- Supports function calling and execution
- Handles human input when needed
- Manages conversation history
- Provides hooks for customizing behavior

Let's look at a basic example of how to create a `ConversableAgent`:

```python
from autogen import ConversableAgent

agent = ConversableAgent(
    name="MyAgent",
    system_message="You are a helpful AI assistant.",
    human_input_mode="NEVER",
    llm_config={
        "config_list": [{"model": "gpt-4", "api_key": "your-api-key"}],
    }
)
```

In this example, we create a simple agent named "MyAgent" with a system message and configuration for the language model.

## 4. Key Components of ConversableAgent

The `ConversableAgent` class consists of several key components:

1. **Messaging System**: Handles sending and receiving messages between agents.
2. **Function Map**: Stores registered functions that the agent can execute.
3. **LLM Config**: Configuration for the language model used by the agent.
4. **Reply Functions**: A list of functions used to generate replies.
5. **Code Execution Config**: Configuration for executing code (if enabled).
6. **Human Input Handling**: Manages when and how to request human input.

Let's explore each of these components in more detail.

## 5. Initialization and Configuration

When initializing a `ConversableAgent`, you can customize various parameters to suit your needs. Here's a more detailed example:

```python
from autogen import ConversableAgent

def custom_function(x, y):
    return x + y

agent = ConversableAgent(
    name="CustomAgent",
    system_message="You are a specialized AI assistant for mathematical operations.",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=5,
    code_execution_config={"work_dir": "tmp", "use_docker": False},
    function_map={"add_numbers": custom_function},
    llm_config={
        "config_list": [{"model": "gpt-4", "api_key": "your-api-key"}],
        "temperature": 0.7,
    }
)
```

In this example, we:
- Set a custom name and system message
- Configure the human input mode to only request input on termination
- Limit the number of consecutive auto-replies
- Set up a code execution environment
- Register a custom function
- Configure the language model with specific parameters

## 6. Message Handling

The `ConversableAgent` class provides methods for sending and receiving messages. Here's how you can use them:

```python
# Sending a message
agent.send(
    message="Hello, can you help me with a math problem?",
    recipient=another_agent,
    request_reply=True
)

# Receiving a message
agent.receive(
    message="Sure, what's the problem?",
    sender=another_agent
)
```

The `send` method allows you to specify the message content, the recipient agent, and whether you want to request a reply. The `receive` method handles incoming messages, updating the conversation history and potentially triggering a reply.

## 7. Reply Generation

One of the most important aspects of `ConversableAgent` is its ability to generate replies. This is handled through a series of reply functions that are called in order. Here's a simplified version of how reply generation works:

```python
def generate_reply(self, messages, sender):
    for reply_func, trigger in self._reply_func_list:
        if self._match_trigger(trigger, sender):
            reply = reply_func(self, messages, sender)
            if reply is not None:
                return reply
    return None
```

You can register custom reply functions to customize the agent's behavior:

```python
def custom_reply_func(agent, messages, sender):
    # Custom logic here
    return "This is a custom reply."

agent.register_reply(
    trigger=[AnotherAgentClass],
    reply_func=custom_reply_func
)
```

This allows you to create specialized agents that can handle different types of messages or respond differently to various senders.

## 8. Function and Tool Execution

`ConversableAgent` supports function calling and tool execution, which allows agents to perform actions or retrieve information. Here's how you can register and use functions:

```python
def get_weather(location):
    # Simulated weather API call
    return f"The weather in {location} is sunny."

agent.register_function(
    function_map={
        "get_weather": get_weather
    }
)
```

When the agent encounters a function call in a message, it will execute the function and return the result:

```python
message = {
    "content": "What's the weather like?",
    "function_call": {
        "name": "get_weather",
        "arguments": '{"location": "New York"}'
    }
}

result = agent.generate_function_call_reply(messages=[message])
print(result)  # ('The weather in New York is sunny.', True)
```

## 9. Human Input Handling

`ConversableAgent` can be configured to handle human input in different ways using the `human_input_mode` parameter:

- `"ALWAYS"`: Always prompt for human input
- `"NEVER"`: Never prompt for human input
- `"TERMINATE"`: Only prompt for human input when terminating the conversation

Here's an example of how human input is handled:

```python
class CustomAgent(ConversableAgent):
    def get_human_input(self, prompt):
        return input(f"{prompt} (type 'exit' to end conversation): ")

agent = CustomAgent(
    name="HumanInteractiveAgent",
    human_input_mode="ALWAYS"
)

# This will prompt for human input before generating a reply
agent.generate_reply(messages=[{"content": "Hello, how are you?"}], sender=another_agent)
```

## 10. Code Execution

`ConversableAgent` can be configured to execute code, which is particularly useful for agents that need to perform computations or interact with external systems. Here's how you can set up code execution:

```python
agent = ConversableAgent(
    name="CodeExecutor",
    code_execution_config={
        "work_dir": "./tmp",
        "use_docker": False,
        "timeout": 60,
    }
)

# Example of executing code
code = """
def fibonacci(n):
    if n <= 1:
        return n
    else:
        return fibonacci(n-1) + fibonacci(n-2)

print(fibonacci(10))
"""

result = agent.execute_code_blocks([(None, code)])
print(result)  # (0, '55\n', None)
```

The `execute_code_blocks` method returns a tuple containing the exit code, output, and any error messages.

## 11. Advanced Features

### 11.1 Nested Chats

`ConversableAgent` supports nested chats, allowing for more complex conversation structures:

```python
def nested_chat_func(chat_queue, recipient, messages, sender, config):
    # Implement nested chat logic here
    pass

agent.register_nested_chats(
    chat_queue=[
        {"sender": agent, "recipient": another_agent, "message": "Hello!"},
        {"sender": another_agent, "recipient": agent, "message": "Hi there!"},
    ],
    reply_func_from_nested_chats=nested_chat_func
)
```

### 11.2 Hooks

You can use hooks to modify the agent's behavior at specific points in the conversation flow:

```python
def pre_reply_hook(agent, messages, sender):
    # Modify messages or perform actions before generating a reply
    return messages

agent.register_hook(
    hookable_method="process_all_messages_before_reply",
    hook=pre_reply_hook
)
```

## 12. Best Practices and Tips

1. **Modular Design**: Create specialized agents for different tasks and compose them to build complex systems.

2. **Error Handling**: Implement robust error handling in custom functions and reply generators.

3. **Testing**: Thoroughly test your agents with various inputs and scenarios.

4. **Documentation**: Maintain clear documentation for your custom agents and functions.

5. **Security**: Be cautious when allowing agents to execute code, especially in production environments.

6. **Performance**: Monitor and optimize the performance of your agents, especially when dealing with large conversations or complex tasks.

7. **Conversation Management**: Implement proper conversation management to ensure smooth interactions between multiple agents.

## 13. Conclusion

The `ConversableAgent` class in Autogen provides a powerful foundation for building sophisticated AI agents. By understanding its components and capabilities, you can create agents that can engage in complex conversations, execute functions, and perform a wide range of tasks.

In this lesson, we've covered the key aspects of `ConversableAgent`, including initialization, message handling, reply generation, function execution, and advanced features. With this knowledge, you're well-equipped to start building your own custom agents and creating intricate multi-agent systems.

Remember to experiment with different configurations and customizations to find the best setup for your specific use case. Happy coding!
