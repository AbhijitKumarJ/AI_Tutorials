# Lesson 7: Contributed Agents and Utilities (Part 1)

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Overview of the contrib folder](#overview-of-the-contrib-folder)
4. [Agent Builder](#agent-builder)
5. [GPT Assistant Agent](#gpt-assistant-agent)
6. [Image Utilities](#image-utilities)
7. [Practical Examples](#practical-examples)
8. [Exercise](#exercise)
9. [Summary](#summary)

## 1. Introduction

In this lesson, we'll explore the `contrib` folder of the AgentChat module in Autogen. This folder contains various extensions and specialized agents that can enhance your AI applications. We'll focus on three key components:

1. Agent Builder
2. GPT Assistant Agent
3. Image Utilities

These tools provide additional flexibility and capabilities to your Autogen-based projects, allowing you to create more sophisticated and specialized AI agents.

## 2. Project Structure

Let's set up our project structure for this lesson:

```
autogen_tutorial/
├── lesson7_contrib_agents/
│   ├── agent_builder_example.py
│   ├── gpt_assistant_example.py
│   ├── image_utils_example.py
│   ├── combined_example.py
│   └── requirements.txt
├── data/
│   ├── sample_image.jpg
│   └── agent_configs.json
└── README.md
```

Ensure you have the required dependencies installed:

```bash
pip install -r lesson7_contrib_agents/requirements.txt
```

## 3. Overview of the contrib folder

The `contrib` folder in the AgentChat module contains various contributed agents and utilities. Here's a brief overview of its structure:

```
autogen/agentchat/contrib/
├── __init__.py
├── agent_builder.py
├── gpt_assistant_agent.py
├── img_utils.py
└── ...
```

In this lesson, we'll focus on `agent_builder.py`, `gpt_assistant_agent.py`, and `img_utils.py`.

## 4. Agent Builder

The Agent Builder provides functionality to dynamically create and configure agents. It's particularly useful when you need to create multiple agents with different configurations or when you want to generate agents based on runtime conditions.

Key features of the Agent Builder include:
- Dynamic agent creation
- Configuration management
- Agent customization

Let's look at an example of how to use the Agent Builder:

```python
# agent_builder_example.py

from autogen.agentchat.contrib.agent_builder import AgentBuilder
import json

# Load agent configurations from a JSON file
with open('data/agent_configs.json', 'r') as f:
    agent_configs = json.load(f)

# Create an AgentBuilder instance
builder = AgentBuilder()

# Create agents based on the configurations
agents = []
for config in agent_configs:
    agent = builder.create_agent(
        name=config['name'],
        agent_type=config['type'],
        system_message=config['system_message'],
        llm_config=config['llm_config']
    )
    agents.append(agent)

# Use the created agents
for agent in agents:
    print(f"Agent: {agent.name}")
    response = agent.generate_response("Hello! What can you do?")
    print(f"Response: {response}")
    print()
```

In this example, we load agent configurations from a JSON file and use the AgentBuilder to create multiple agents with different settings. This approach allows for flexible and dynamic agent creation based on external configurations or runtime conditions.

## 5. GPT Assistant Agent

The GPT Assistant Agent is a specialized agent that leverages OpenAI's GPT models. It provides a more streamlined interface for creating assistants based on these powerful language models.

Key features of the GPT Assistant Agent include:
- Easy integration with OpenAI's API
- Customizable system messages
- Handling of conversation context

Here's an example of how to use the GPT Assistant Agent:

```python
# gpt_assistant_example.py

from autogen.agentchat.contrib.gpt_assistant_agent import GPTAssistantAgent
from autogen import UserProxyAgent

# Create a GPT Assistant Agent
assistant = GPTAssistantAgent(
    name="DataAnalysisExpert",
    instructions="You are an AI assistant specialized in data analysis. Provide insights and answer questions about data.",
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7,
    }
)

# Create a user proxy for interaction
user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=1,
    is_termination_msg=lambda x: "TERMINATE" in x.get("content", "").upper(),
)

# Start a conversation
user_proxy.initiate_chat(
    assistant,
    message="I have a dataset of customer purchases. How can I identify the most valuable customers?"
)
```

This example demonstrates how to create a GPT Assistant Agent specialized in data analysis and interact with it using a UserProxyAgent.

## 6. Image Utilities

The Image Utilities provide functions for handling images in agent conversations. These utilities are particularly useful when working with multimodal agents or when you need to process image data within your AI system.

Key functionalities of the Image Utilities include:
- Image loading and processing
- Conversion between different image formats
- Integration of images in agent messages

Let's look at an example of how to use the Image Utilities:

```python
# image_utils_example.py

from autogen.agentchat.contrib.img_utils import get_image_data, is_image
from autogen.agentchat.contrib.multimodal_conversable_agent import MultimodalConversableAgent
from autogen import UserProxyAgent

# Function to create a message with an image
def create_image_message(image_path, caption):
    image_data = get_image_data(image_path)
    return {
        "content": caption,
        "image": image_data
    }

# Create a multimodal agent capable of processing images
image_analyst = MultimodalConversableAgent(
    name="ImageAnalyst",
    llm_config={
        "model": "gpt-4-vision-preview",
        "temperature": 0.7,
    },
    system_message="You are an AI assistant capable of analyzing images and providing insights."
)

# Create a user proxy for interaction
user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=1,
    is_termination_msg=lambda x: "TERMINATE" in x.get("content", "").upper(),
)

# Create a message with an image
image_message = create_image_message(
    'data/sample_image.jpg',
    "Analyze this image and describe what you see."
)

# Start a conversation with the image message
user_proxy.initiate_chat(
    image_analyst,
    message=image_message
)
```

This example shows how to use the Image Utilities to load an image, create a message with image data, and use it in a conversation with a multimodal agent capable of analyzing images.

## 7. Practical Examples

Now, let's combine these contributed agents and utilities into a more complex example:

```python
# combined_example.py

from autogen.agentchat.contrib.agent_builder import AgentBuilder
from autogen.agentchat.contrib.gpt_assistant_agent import GPTAssistantAgent
from autogen.agentchat.contrib.img_utils import get_image_data
from autogen import UserProxyAgent

# Create an AgentBuilder
builder = AgentBuilder()

# Create a GPT Assistant Agent for data analysis
data_analyst = builder.create_agent(
    name="DataAnalyst",
    agent_type=GPTAssistantAgent,
    instructions="You are an AI assistant specialized in data analysis and visualization.",
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7,
    }
)

# Create a GPT Assistant Agent for image analysis
image_analyst = builder.create_agent(
    name="ImageAnalyst",
    agent_type=GPTAssistantAgent,
    instructions="You are an AI assistant specialized in analyzing images and providing insights.",
    llm_config={
        "model": "gpt-4-vision-preview",
        "temperature": 0.7,
    }
)

# Create a user proxy for interaction
user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=1,
    is_termination_msg=lambda x: "TERMINATE" in x.get("content", "").upper(),
)

# Function to create a message with an image
def create_image_message(image_path, caption):
    image_data = get_image_data(image_path)
    return {
        "content": caption,
        "image": image_data
    }

# Start a conversation with the data analyst
user_proxy.initiate_chat(
    data_analyst,
    message="I have sales data for the past year. Can you suggest some visualizations that would be helpful?"
)

# Start a conversation with the image analyst
image_message = create_image_message(
    'data/sample_image.jpg',
    "This is a chart of our sales data. Can you analyze it and provide insights?"
)
user_proxy.initiate_chat(
    image_analyst,
    message=image_message
)
```

This combined example demonstrates how to use the Agent Builder to create specialized GPT Assistant Agents for different tasks, and how to incorporate image analysis using the Image Utilities.

## 8. Exercise

Now it's your turn to practice! Create a system that combines the Agent Builder, GPT Assistant Agent, and Image Utilities to solve a real-world problem. Here's your task:

1. Use the Agent Builder to create three agents:
   - A data analysis expert
   - An image recognition specialist
   - A report generation assistant

2. Implement a workflow that:
   - Analyzes a dataset (you can use a sample dataset or generate one)
   - Processes an image related to the data (e.g., a chart or graph)
   - Generates a comprehensive report combining insights from both the data and image analysis

3. Use the Image Utilities to handle the image processing and inclusion in messages

4. Create a main script that orchestrates the interaction between these agents and a user proxy

Be creative with your implementation and think about how these tools can be combined to solve complex, multi-step problems.

## 9. Summary

In this lesson, we've explored key components of the `contrib` folder in Autogen's AgentChat module:

1. The Agent Builder, which allows for dynamic creation and configuration of agents
2. The GPT Assistant Agent, a specialized agent leveraging OpenAI's powerful language models
3. Image Utilities, providing tools for handling and processing images in agent conversations

These contributed agents and utilities extend the capabilities of Autogen, allowing for more flexible, powerful, and specialized AI systems. By combining these tools, you can create sophisticated applications that handle complex tasks involving data analysis, image processing, and natural language interaction.

In the next lesson, we'll continue our exploration of the `contrib` folder, focusing on additional specialized agents and advanced capabilities.
