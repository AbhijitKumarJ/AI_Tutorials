# Lesson 5: Specialized Agents - AssistantAgent and UserProxyAgent

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [AssistantAgent](#assistantagent)
   - [Overview](#assistantagent-overview)
   - [Key Features](#assistantagent-key-features)
   - [Implementation](#assistantagent-implementation)
   - [Example Usage](#assistantagent-example-usage)
4. [UserProxyAgent](#userproxyagent)
   - [Overview](#userproxyagent-overview)
   - [Key Features](#userproxyagent-key-features)
   - [Implementation](#userproxyagent-implementation)
   - [Example Usage](#userproxyagent-example-usage)
5. [Combining AssistantAgent and UserProxyAgent](#combining-agents)
6. [Customizing Specialized Agents](#customizing-agents)
7. [Exercise](#exercise)
8. [Summary](#summary)

## 1. Introduction <a name="introduction"></a>

In this lesson, we'll dive deep into two specialized agents provided by Autogen's AgentChat module: AssistantAgent and UserProxyAgent. These agents are designed to handle specific roles in conversational AI systems, offering enhanced functionality over the base ConversableAgent class.

We'll explore the implementation details of each agent, their unique features, and how to use them effectively in your projects. By the end of this lesson, you'll be able to create and customize these specialized agents for various applications.

## 2. Project Structure <a name="project-structure"></a>

Before we begin, let's set up our project structure for this lesson:

```
autogen_tutorial/
├── lesson5_specialized_agents/
│   ├── assistant_agent_example.py
│   ├── user_proxy_agent_example.py
│   ├── combined_agents_example.py
│   ├── custom_specialized_agent.py
│   └── requirements.txt
├── autogen/
│   └── agentchat/
│       ├── assistant_agent.py
│       └── user_proxy_agent.py
└── README.md
```

Make sure you have the necessary dependencies installed. Create a `requirements.txt` file in the `lesson5_specialized_agents` directory with the following content:

```
pyautogen==0.2.0
openai==0.27.8
```

Install the requirements using:

```bash
pip install -r requirements.txt
```

## 3. AssistantAgent <a name="assistantagent"></a>

### Overview <a name="assistantagent-overview"></a>

The AssistantAgent is a specialized version of the ConversableAgent designed to act as an AI assistant. It's pre-configured with settings suitable for most assistant-like tasks and can be easily customized for specific use cases.

### Key Features <a name="assistantagent-key-features"></a>

1. Pre-configured system message for assistant-like behavior
2. Built-in support for code execution (if configured)
3. Optimized for complex problem-solving tasks
4. Easy integration with language models like GPT-4

### Implementation <a name="assistantagent-implementation"></a>

Let's take a look at the key parts of the AssistantAgent implementation:

```python
# autogen/agentchat/assistant_agent.py

from typing import Dict, Optional, Union

from .conversable_agent import ConversableAgent

class AssistantAgent(ConversableAgent):
    DEFAULT_SYSTEM_MESSAGE = """You are a helpful AI assistant.
Solve tasks using your coding and language skills.
In the following cases, suggest python code (in a python coding block) or shell script (in a sh coding block) for the user to execute:
1. When you need to collect info, use the code to output the info you need, for example, browse or search the web, download/read a file, print the content of a webpage or a file, get the current date/time, check the operating system etc.
2. When you need to perform some task with code, use the code to perform the task and output the result.
Solve the task step by step if you need to. If a plan is not provided, explain your plan first. Be clear which step uses code, and which step uses your language skill.
When using code, you must indicate the script type in the code block. The user cannot provide any other feedback or perform any other action beyond executing the code you suggest. The user can't modify your code. So do not suggest incomplete code which requires users to modify. Don't use a code block if it's not intended to be executed by the user.
If you want the user to save the code in a file before executing it, put # filename: <filename> inside the code block as the first line.
Don't include multiple code blocks in one response. Do not ask users to copy and paste the result. Instead, use 'print' function for the output when relevant. Check the execution result returned by the user.
If the result indicates there is an error, fix the error and output the code again. Suggest the full code instead of partial code or code changes. If the error can't be fixed or if the task is not solved even after the code is executed successfully, analyze the problem, revisit your assumption, collect additional info you need, and think of a different approach to try.
When you find an answer, verify the answer carefully. Include verifiable evidence in your response if possible.
Reply "TERMINATE" in the end when everything is done.
"""

    def __init__(
        self,
        name: str,
        system_message: Optional[str] = DEFAULT_SYSTEM_MESSAGE,
        llm_config: Optional[Union[Dict, bool]] = None,
        **kwargs,
    ):
        super().__init__(
            name,
            system_message,
            llm_config=llm_config,
            **kwargs,
        )
```

The AssistantAgent class inherits from ConversableAgent and provides a default system message that defines its behavior. This system message instructs the agent to:

1. Solve tasks using coding and language skills
2. Suggest Python code or shell scripts when necessary
3. Break down complex tasks into steps
4. Handle code execution and error correction
5. Verify answers and provide evidence

### Example Usage <a name="assistantagent-example-usage"></a>

Let's create an example that demonstrates how to use the AssistantAgent:

```python
# lesson5_specialized_agents/assistant_agent_example.py

import autogen

# Configure the AI model
config_list = [
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here",
    }
]

# Create an AssistantAgent instance
assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={"config_list": config_list},
    system_message="You are a helpful AI assistant specializing in Python programming."
)

# Create a UserProxyAgent for human interaction
user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={"work_dir": "coding"}
)

# Start the conversation
user_proxy.initiate_chat(
    assistant,
    message="Can you help me write a Python function to calculate the factorial of a number?"
)
```

In this example, we create an AssistantAgent specialized in Python programming and a UserProxyAgent to simulate human interaction. The AssistantAgent will help write a Python function to calculate the factorial of a number.

## 4. UserProxyAgent <a name="userproxyagent"></a>

### Overview <a name="userproxyagent-overview"></a>

The UserProxyAgent is designed to represent a human user in the conversation. It can interact with other agents, execute code, and provide feedback to the system.

### Key Features <a name="userproxyagent-key-features"></a>

1. Ability to execute code and provide feedback
2. Support for different human input modes (ALWAYS, NEVER, TERMINATE)
3. Customizable code execution configuration
4. Flexible termination message handling

### Implementation <a name="userproxyagent-implementation"></a>

Let's examine the key parts of the UserProxyAgent implementation:

```python
# autogen/agentchat/user_proxy_agent.py

from typing import Callable, Dict, Optional, Union

from .conversable_agent import ConversableAgent

class UserProxyAgent(ConversableAgent):
    def __init__(
        self,
        name: str,
        human_input_mode: str = "ALWAYS",
        max_consecutive_auto_reply: Optional[int] = None,
        human_input_mode: Literal["ALWAYS", "TERMINATE", "NEVER"] = "TERMINATE",
        code_execution_config: Optional[Dict] = None,
        default_auto_reply: Optional[Union[str, Dict, None]] = "",
        is_termination_msg: Optional[Callable[[Dict], bool]] = None,
        **kwargs,
    ):
        super().__init__(
            name,
            max_consecutive_auto_reply=max_consecutive_auto_reply,
            human_input_mode=human_input_mode,
            system_message="""Human Admin/User.""",
            code_execution_config=code_execution_config,
            default_auto_reply=default_auto_reply,
            is_termination_msg=is_termination_msg,
            **kwargs,
        )
```

The UserProxyAgent class inherits from ConversableAgent and is configured to represent a human user. It supports different human input modes, code execution, and customizable termination message handling.

### Example Usage <a name="userproxyagent-example-usage"></a>

Let's create an example that demonstrates how to use the UserProxyAgent:

```python
# lesson5_specialized_agents/user_proxy_agent_example.py

import autogen

# Configure the AI model
config_list = [
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here",
    }
]

# Create an AssistantAgent instance
assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={"config_list": config_list},
)

# Create a UserProxyAgent for human interaction
user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={
        "work_dir": "coding",
        "use_docker": False,
    }
)

# Start the conversation
user_proxy.initiate_chat(
    assistant,
    message="Can you write a Python script that reads a CSV file and calculates the average of a specific column?"
)
```

In this example, we create a UserProxyAgent that can execute code and interact with an AssistantAgent. The UserProxyAgent is configured to terminate the conversation when the message ends with "TERMINATE" and has a specific code execution configuration.

## 5. Combining AssistantAgent and UserProxyAgent <a name="combining-agents"></a>

Now, let's create an example that combines both AssistantAgent and UserProxyAgent to solve a more complex task:

```python
# lesson5_specialized_agents/combined_agents_example.py

import autogen

# Configure the AI model
config_list = [
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here",
    }
]

# Create an AssistantAgent instance
assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={"config_list": config_list},
    system_message="You are a helpful AI assistant specializing in data analysis and visualization."
)

# Create a UserProxyAgent for human interaction
user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={
        "work_dir": "data_analysis",
        "use_docker": False,
    }
)

# Start the conversation
user_proxy.initiate_chat(
    assistant,
    message="""
    I have a CSV file named 'sales_data.csv' with columns 'Date', 'Product', 'Quantity', and 'Price'.
    Can you help me with the following tasks?
    1. Read the CSV file and calculate the total sales for each product.
    2. Create a bar plot showing the top 5 products by total sales.
    3. Save the plot as 'top_5_products.png'.
    """
)
```

In this example, we combine an AssistantAgent specialized in data analysis and visualization with a UserProxyAgent capable of executing code. The AssistantAgent will guide the process of analyzing the sales data and creating a visualization, while the UserProxyAgent will execute the necessary code.

## 6. Customizing Specialized Agents <a name="customizing-agents"></a>

Both AssistantAgent and UserProxyAgent can be customized to fit specific use cases. Here's an example of how to create a custom specialized agent:

```python
# lesson5_specialized_agents/custom_specialized_agent.py

import autogen

class CustomAssistantAgent(autogen.AssistantAgent):
    def __init__(self, name: str, specialized_skill: str, **kwargs):
        custom_system_message = f"""You are a helpful AI assistant specializing in {specialized_skill}.
        Use your expertise to provide detailed and accurate information and guidance in this area.
        When appropriate, suggest relevant resources or tools that can aid in solving problems related to {specialized_skill}."""
        
        super().__init__(name, system_message=custom_system_message, **kwargs)

    def analyze_problem(self, problem_description: str) -> str:
        """Custom method to analyze problems in the specialized area"""
        return self.generate_reply(messages=[{
            "role": "user",
            "content": f"Analyze the following problem in the context of {self.specialized_skill}: {problem_description}"
        }])

# Usage example
config_list = [
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here",
    }
]

custom_assistant = CustomAssistantAgent(
    name="AI_Machine_Learning_Expert",
    specialized_skill="machine learning",
    llm_config={"config_list": config_list},
)

user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
)

# Start the conversation
user_proxy.initiate_chat(
    custom_assistant,
    message="Can you help me understand the difference between supervised and unsupervised learning in machine learning?"
)

# Use the custom method
problem_analysis = custom_assistant.analyze_problem("I have a dataset of customer transactions and I want to identify unusual patterns. What machine learning approach should I use?")
print("Problem Analysis:", problem_analysis)
```

In this example, we create a CustomAssistantAgent that specializes in a specific skill and includes a custom method for problem analysis. This demonstrates how you can extend the functionality of specialized agents to fit your specific requirements.

## 7. Exercise <a name="exercise"></a>

Now it's your turn to practice working with specialized agents. Complete the following exercise:

1. Create a new file called `exercise_specialized_agents.py` in the `lesson5_specialized_agents` directory.
2. Implement a scenario where an AssistantAgent helps a UserProxyAgent perform the following tasks:
   a. Web scrape the current weather information for a given city using the