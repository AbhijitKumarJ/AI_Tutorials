# Lesson 3: Understanding the Agent Base Class

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [The Agent Base Class](#the-agent-base-class)
   - [Core Attributes](#core-attributes)
   - [Key Methods](#key-methods)
4. [Creating Custom Agents](#creating-custom-agents)
5. [Practical Examples](#practical-examples)
6. [Exercises](#exercises)
7. [Summary](#summary)

## 1. Introduction

Welcome to Lesson 3 of our Autogen AgentChat series. In this lesson, we'll dive deep into the Agent base class, which forms the foundation for all agent types in the Autogen framework. Understanding this base class is crucial for creating custom agents and comprehending the inner workings of the agent system.

## 2. Project Structure

Before we begin, let's set up our project structure for this lesson:

```
autogen_tutorial/
├── lesson3_agent_base_class/
│   ├── agent_examples/
│   │   ├── __init__.py
│   │   ├── custom_agent.py
│   │   └── agent_tester.py
│   ├── exercises/
│   │   ├── __init__.py
│   │   └── exercise_1.py
│   ├── main.py
│   └── requirements.txt
└── README.md
```

Make sure to create these directories and files. We'll be using them throughout the lesson.

## 3. The Agent Base Class

The Agent base class is defined in the `agent.py` file within the `autogen/agentchat/` directory. Let's examine its core attributes and key methods.

### Core Attributes

```python
# agent_examples/custom_agent.py

from autogen.agentchat import Agent

class SimpleAgent(Agent):
    def __init__(self, name: str):
        super().__init__(name)
        self.name = name
        self.description = "A simple custom agent"
        self.system_message = "You are a helpful assistant."
```

The core attributes of the Agent base class include:

1. `name`: A string identifier for the agent.
2. `description`: A brief description of the agent's purpose or capabilities.
3. `system_message`: Instructions or context provided to the agent.

### Key Methods

The Agent base class defines several key methods that all derived agents should implement:

```python
# agent_examples/custom_agent.py

from typing import Dict, List, Union
from autogen.agentchat import Agent

class SimpleAgent(Agent):
    def __init__(self, name: str):
        super().__init__(name)
        self.name = name
        self.description = "A simple custom agent"
        self.system_message = "You are a helpful assistant."

    def send(self, message: Union[Dict, str], recipient: Agent) -> None:
        print(f"{self.name} sending message to {recipient.name}: {message}")

    def receive(self, message: Union[Dict, str], sender: Agent) -> None:
        print(f"{self.name} received message from {sender.name}: {message}")

    def generate_reply(self, messages: List[Dict], sender: Agent) -> Union[str, Dict, None]:
        return f"Hello, {sender.name}! This is a simple reply from {self.name}."
```

Let's break down these key methods:

1. `send(message, recipient)`: This method is used to send a message to another agent.
2. `receive(message, sender)`: This method is called when the agent receives a message from another agent.
3. `generate_reply(messages, sender)`: This method generates a reply based on the conversation history and the sender.

## 4. Creating Custom Agents

To create a custom agent, you need to inherit from the Agent base class and implement its key methods. Here's an example of a more advanced custom agent:

```python
# agent_examples/custom_agent.py

from typing import Dict, List, Union
from autogen.agentchat import Agent

class AdvancedAgent(Agent):
    def __init__(self, name: str, expertise: str):
        super().__init__(name)
        self.name = name
        self.expertise = expertise
        self.description = f"An advanced agent specialized in {expertise}"
        self.system_message = f"You are an AI assistant with expertise in {expertise}."
        self.conversation_history = []

    def send(self, message: Union[Dict, str], recipient: Agent) -> None:
        formatted_message = f"{self.name} to {recipient.name}: {message}"
        self.conversation_history.append(formatted_message)
        print(formatted_message)

    def receive(self, message: Union[Dict, str], sender: Agent) -> None:
        formatted_message = f"{sender.name} to {self.name}: {message}"
        self.conversation_history.append(formatted_message)
        print(formatted_message)

    def generate_reply(self, messages: List[Dict], sender: Agent) -> Union[str, Dict, None]:
        # In a real scenario, you might use an LLM here
        last_message = messages[-1]['content'] if isinstance(messages[-1], dict) else messages[-1]
        return f"Based on my {self.expertise} expertise, I suggest: {last_message.upper()}"

    def summarize_conversation(self) -> str:
        return f"Conversation summary for {self.name}:\n" + "\n".join(self.conversation_history)
```

This `AdvancedAgent` class demonstrates how you can extend the base Agent class to create more sophisticated agents with additional functionality.

## 5. Practical Examples

Let's create a simple scenario to demonstrate how these custom agents can interact:

```python
# agent_examples/agent_tester.py

from custom_agent import SimpleAgent, AdvancedAgent

def test_agents():
    simple_agent = SimpleAgent("SimpleBot")
    advanced_agent = AdvancedAgent("AdvancedBot", "machine learning")

    # Simulate a conversation
    simple_agent.send("Hello, can you help me with machine learning?", advanced_agent)
    advanced_agent.receive("Hello, can you help me with machine learning?", simple_agent)
    
    reply = advanced_agent.generate_reply([{"content": "How do I choose the right algorithm for my data?"}], simple_agent)
    advanced_agent.send(reply, simple_agent)
    simple_agent.receive(reply, advanced_agent)

    # Print conversation summary
    print(advanced_agent.summarize_conversation())

if __name__ == "__main__":
    test_agents()
```

This example demonstrates how different agent types can interact, send and receive messages, and generate replies based on their specific implementations.

## 6. Exercises

To reinforce your understanding of the Agent base class and custom agent creation, try the following exercise:

```python
# exercises/exercise_1.py

from typing import Dict, List, Union
from autogen.agentchat import Agent

class DataAnalystAgent(Agent):
    def __init__(self, name: str):
        super().__init__(name)
        # TODO: Initialize the agent with appropriate attributes

    def send(self, message: Union[Dict, str], recipient: Agent) -> None:
        # TODO: Implement the send method

    def receive(self, message: Union[Dict, str], sender: Agent) -> None:
        # TODO: Implement the receive method

    def generate_reply(self, messages: List[Dict], sender: Agent) -> Union[str, Dict, None]:
        # TODO: Implement a method to generate a reply based on data analysis expertise

    def analyze_data(self, data: List[float]) -> str:
        # TODO: Implement a simple data analysis method (e.g., calculate mean, median, mode)

# Test your implementation
if __name__ == "__main__":
    analyst = DataAnalystAgent("DataBot")
    # TODO: Create a test scenario to demonstrate your agent's capabilities
```

Exercise: Complete the `DataAnalystAgent` class by implementing the required methods. Add a simple data analysis capability and demonstrate how this agent can interact with other agents to provide data insights.

## 7. Summary

In this lesson, we've explored the Agent base class in depth, including its core attributes and key methods. We've learned how to create custom agents by inheriting from the base class and implementing the necessary functionality. Through practical examples and exercises, we've seen how these agents can interact and perform specialized tasks.

Key takeaways:
1. The Agent base class provides a foundation for all agent types in Autogen.
2. Custom agents can be created by inheriting from the Agent class and implementing key methods.
3. Agents can have specialized capabilities while maintaining a consistent interface for interaction.

In the next lesson, we'll dive into more advanced agent types and explore how they can be used in complex conversational scenarios.

