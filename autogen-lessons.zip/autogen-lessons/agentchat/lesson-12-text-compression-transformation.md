# Lesson 12: Text Compression and Transformation in AutoGen

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding Text Compressors](#understanding-text-compressors)
4. [Implementing Efficient Message Handling](#implementing-efficient-message-handling)
5. [Optimizing Agent Communication](#optimizing-agent-communication)
6. [Practical Examples](#practical-examples)
7. [Best Practices](#best-practices)
8. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll dive deep into text compression and transformation techniques in AutoGen. As AI models and agent interactions become more complex, efficient handling of text data becomes crucial. We'll explore how to compress and transform text to optimize communication between agents, reduce token usage, and improve overall system performance.

## 2. Project Structure

Before we begin, let's look at the typical project structure for an AutoGen application focusing on text compression and transformation:

```
autogen_project/
│
├── main.py
├── agents/
│   ├── __init__.py
│   ├── base_agent.py
│   └── compressed_agent.py
│
├── text_handlers/
│   ├── __init__.py
│   ├── compressor.py
│   └── transformer.py
│
├── utils/
│   ├── __init__.py
│   └── text_utils.py
│
└── config/
    └── config.json
```

This structure organizes our code into separate modules for agents, text handlers, and utilities, making it easier to manage and extend our application.

## 3. Understanding Text Compressors

AutoGen provides text compression capabilities through the `LLMLingua` class. Let's examine how to use it:

```python
# text_handlers/compressor.py

from autogen.agentchat.contrib.capabilities.text_compressors import LLMLingua

class TextCompressor:
    def __init__(self):
        self.compressor = LLMLingua(
            model_name="microsoft/llmlingua-2-bert-base-multilingual-cased-meetingbank",
            use_llmlingua2=True,
            device_map="cpu"
        )

    def compress_text(self, text: str, **compression_params) -> Dict[str, Any]:
        return self.compressor.compress_text(text, **compression_params)
```

The `LLMLingua` class uses advanced techniques to compress text while maintaining its semantic meaning. This is particularly useful for reducing token usage in large conversations or when working with limited context windows.

## 4. Implementing Efficient Message Handling

To handle message compression efficiently, we can create a `CompressedAgent` class that automatically compresses outgoing messages and decompresses incoming messages:

```python
# agents/compressed_agent.py

from autogen.agentchat import ConversableAgent
from text_handlers.compressor import TextCompressor

class CompressedAgent(ConversableAgent):
    def __init__(self, name: str, **kwargs):
        super().__init__(name, **kwargs)
        self.compressor = TextCompressor()

    def send(self, message: Union[Dict, str], recipient: Agent, request_reply: Optional[bool] = None, silent: Optional[bool] = False):
        if isinstance(message, str):
            compressed = self.compressor.compress_text(message)
            message = {"content": compressed["compressed_text"], "original_tokens": compressed["origin_tokens"]}
        super().send(message, recipient, request_reply, silent)

    def receive(self, message: Union[Dict, str], sender: Agent, request_reply: Optional[bool] = None, silent: Optional[bool] = False):
        if isinstance(message, dict) and "original_tokens" in message:
            # Decompress the message (in a real scenario, you'd implement a decompression method)
            message = f"Decompressed: {message['content']} (Original tokens: {message['original_tokens']})"
        super().receive(message, sender, request_reply, silent)
```

This `CompressedAgent` automatically compresses outgoing messages and handles compressed incoming messages, making it seamless to integrate text compression into your agent communications.

## 5. Optimizing Agent Communication

To further optimize agent communication, we can implement text transformations that restructure or summarize content without losing essential information. Let's create a `TextTransformer` class:

```python
# text_handlers/transformer.py

from autogen import OpenAIWrapper

class TextTransformer:
    def __init__(self, llm_config: dict):
        self.llm = OpenAIWrapper(**llm_config)

    def summarize(self, text: str, max_tokens: int = 100) -> str:
        prompt = f"Summarize the following text in no more than {max_tokens} tokens:\n\n{text}"
        response = self.llm.create(messages=[{"role": "user", "content": prompt}])
        return response.choices[0].message.content

    def restructure(self, text: str, format: str = "bullet_points") -> str:
        prompt = f"Restructure the following text into {format}:\n\n{text}"
        response = self.llm.create(messages=[{"role": "user", "content": prompt}])
        return response.choices[0].message.content
```

This `TextTransformer` class can be used to summarize or restructure text, which can be particularly useful when agents need to exchange large amounts of information efficiently.

## 6. Practical Examples

Let's look at a practical example that combines text compression and transformation in a multi-agent system:

```python
# main.py

from agents.compressed_agent import CompressedAgent
from text_handlers.transformer import TextTransformer
from autogen import UserProxyAgent, config_list_from_json

def main():
    # Load OpenAI API key
    config_list = config_list_from_json("config/config.json")
    
    # Initialize agents
    user = UserProxyAgent("User")
    assistant = CompressedAgent("Assistant", llm_config={"config_list": config_list})
    
    # Initialize text transformer
    transformer = TextTransformer(llm_config={"config_list": config_list})

    # Start conversation
    user.initiate_chat(
        assistant,
        message="Can you explain the concept of quantum computing and its potential applications?"
    )

    # Get the last message from the assistant
    last_message = assistant.last_message()["content"]

    # Transform the message
    summarized = transformer.summarize(last_message, max_tokens=50)
    restructured = transformer.restructure(last_message, format="bullet_points")

    print(f"Original message tokens: {len(last_message.split())}")
    print(f"Summarized message tokens: {len(summarized.split())}")
    print(f"Summarized message: {summarized}")
    print(f"Restructured message: {restructured}")

if __name__ == "__main__":
    main()
```

This example demonstrates how to use compressed agents for efficient communication and how to apply text transformations to optimize the information exchange between agents.

## 7. Best Practices

When implementing text compression and transformation in AutoGen, keep these best practices in mind:

1. **Balance Compression and Clarity**: While compression can save tokens, ensure that it doesn't compromise the clarity of the message.

2. **Use Context-Aware Compression**: Consider the context of the conversation when compressing text to preserve the most relevant information.

3. **Implement Selective Compression**: Not all messages need compression. Implement logic to decide when to compress based on message length or content type.

4. **Monitor Token Usage**: Regularly monitor and log token usage to ensure that your compression and transformation strategies are effective.

5. **Preserve Original Messages**: Always keep a copy of the original, uncompressed messages for debugging and auditing purposes.

6. **Test Thoroughly**: Rigorously test your compression and transformation methods with various types of content to ensure they work as expected across different scenarios.

7. **Consider Computation Overhead**: Remember that compression and transformation operations also consume computational resources. Balance this overhead against the benefits of reduced token usage.

## 8. Conclusion

Text compression and transformation are powerful techniques for optimizing agent communication in AutoGen. By implementing these methods, you can significantly reduce token usage, improve response times, and enhance the overall efficiency of your multi-agent systems.

In this lesson, we've covered:
- Understanding and implementing text compressors using LLMLingua
- Creating compressed agents for efficient message handling
- Implementing text transformations for summarization and restructuring
- Practical examples of using compression and transformation in a multi-agent system
- Best practices for text compression and transformation in AutoGen

As you continue to work with AutoGen, experiment with different compression and transformation strategies to find the optimal balance between efficiency and clarity in your agent communications. Remember that the goal is to maximize the information exchange while minimizing resource usage.

