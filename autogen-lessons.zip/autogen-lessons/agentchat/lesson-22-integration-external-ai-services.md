# Lesson 22: Integration with External AI Services

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Setting Up External AI Services](#setting-up-external-ai-services)
4. [Integrating OpenAI](#integrating-openai)
5. [Integrating Google Cloud Vision API](#integrating-google-cloud-vision-api)
6. [Integrating Hugging Face Models](#integrating-hugging-face-models)
7. [Creating a Multi-Service Agent](#creating-a-multi-service-agent)
8. [Best Practices and Considerations](#best-practices-and-considerations)
9. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll explore how to integrate external AI services into your AutoGen agents. By leveraging various AI services, you can enhance your agents' capabilities and create more powerful and versatile applications. We'll cover integration with popular services like OpenAI, Google Cloud Vision API, and Hugging Face models.

## Project Structure

Before we dive into the integration details, let's look at a typical project structure for an AutoGen application that integrates multiple AI services:

```
autogen_external_ai/
│
├── config/
│   ├── __init__.py
│   └── api_keys.py
│
├── services/
│   ├── __init__.py
│   ├── openai_service.py
│   ├── google_vision_service.py
│   └── huggingface_service.py
│
├── agents/
│   ├── __init__.py
│   ├── multi_service_agent.py
│   └── specialized_agents.py
│
├── utils/
│   ├── __init__.py
│   └── helpers.py
│
├── main.py
├── requirements.txt
└── README.md
```

This structure organizes our code into separate modules for configuration, services, agents, and utilities. The `main.py` file will serve as the entry point for our application.

## Setting Up External AI Services

Before integrating external AI services, you need to set up accounts and obtain API keys for each service. Here's a general process:

1. Create an account on the AI service provider's platform.
2. Navigate to the API or developer section.
3. Generate an API key or access token.
4. Store the API key securely (we'll use environment variables).

Let's set up our `api_keys.py` file to manage our API keys:

```python
# config/api_keys.py

import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GOOGLE_CLOUD_API_KEY = os.getenv("GOOGLE_CLOUD_API_KEY")
HUGGINGFACE_API_KEY = os.getenv("HUGGINGFACE_API_KEY")
```

Make sure to create a `.env` file in your project root and add your API keys:

```
OPENAI_API_KEY=your_openai_api_key
GOOGLE_CLOUD_API_KEY=your_google_cloud_api_key
HUGGINGFACE_API_KEY=your_huggingface_api_key
```

## Integrating OpenAI

Let's start by integrating OpenAI's GPT models into our AutoGen application. We'll create a service class to handle OpenAI API calls:

```python
# services/openai_service.py

import openai
from config.api_keys import OPENAI_API_KEY

class OpenAIService:
    def __init__(self):
        openai.api_key = OPENAI_API_KEY

    def generate_text(self, prompt, max_tokens=100):
        try:
            response = openai.Completion.create(
                engine="text-davinci-002",
                prompt=prompt,
                max_tokens=max_tokens
            )
            return response.choices[0].text.strip()
        except Exception as e:
            print(f"Error in OpenAI API call: {e}")
            return None
```

Now, let's create an agent that uses this service:

```python
# agents/specialized_agents.py

from autogen import ConversableAgent
from services.openai_service import OpenAIService

class OpenAIAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)
        self.openai_service = OpenAIService()

    def generate_reply(self, messages, sender):
        last_message = messages[-1]['content']
        response = self.openai_service.generate_text(last_message)
        return response if response else "I couldn't generate a response."
```

## Integrating Google Cloud Vision API

Next, let's integrate the Google Cloud Vision API for image analysis:

```python
# services/google_vision_service.py

from google.cloud import vision
from config.api_keys import GOOGLE_CLOUD_API_KEY
import os

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = GOOGLE_CLOUD_API_KEY

class GoogleVisionService:
    def __init__(self):
        self.client = vision.ImageAnnotatorClient()

    def analyze_image(self, image_path):
        try:
            with open(image_path, "rb") as image_file:
                content = image_file.read()

            image = vision.Image(content=content)
            response = self.client.label_detection(image=image)
            labels = response.label_annotations

            return [label.description for label in labels]
        except Exception as e:
            print(f"Error in Google Vision API call: {e}")
            return None
```

Now, let's create an agent that uses this service:

```python
# agents/specialized_agents.py

from autogen import ConversableAgent
from services.google_vision_service import GoogleVisionService

class VisionAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)
        self.vision_service = GoogleVisionService()

    def analyze_image(self, image_path):
        labels = self.vision_service.analyze_image(image_path)
        if labels:
            return f"I see the following in the image: {', '.join(labels)}"
        else:
            return "I couldn't analyze the image."
```

## Integrating Hugging Face Models

Lastly, let's integrate Hugging Face models for various NLP tasks:

```python
# services/huggingface_service.py

from transformers import pipeline
from config.api_keys import HUGGINGFACE_API_KEY

class HuggingFaceService:
    def __init__(self):
        self.summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
        self.translator = pipeline("translation_en_to_fr", model="Helsinki-NLP/opus-mt-en-fr")

    def summarize_text(self, text):
        try:
            summary = self.summarizer(text, max_length=130, min_length=30, do_sample=False)
            return summary[0]['summary_text']
        except Exception as e:
            print(f"Error in Hugging Face summarization: {e}")
            return None

    def translate_text(self, text):
        try:
            translation = self.translator(text, max_length=40)
            return translation[0]['translation_text']
        except Exception as e:
            print(f"Error in Hugging Face translation: {e}")
            return None
```

Now, let's create an agent that uses this service:

```python
# agents/specialized_agents.py

from autogen import ConversableAgent
from services.huggingface_service import HuggingFaceService

class NLPAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)
        self.nlp_service = HuggingFaceService()

    def summarize(self, text):
        summary = self.nlp_service.summarize_text(text)
        return summary if summary else "I couldn't summarize the text."

    def translate(self, text):
        translation = self.nlp_service.translate_text(text)
        return translation if translation else "I couldn't translate the text."
```

## Creating a Multi-Service Agent

Now that we have integrated multiple AI services, let's create a multi-service agent that can leverage all of these capabilities:

```python
# agents/multi_service_agent.py

from autogen import ConversableAgent
from services.openai_service import OpenAIService
from services.google_vision_service import GoogleVisionService
from services.huggingface_service import HuggingFaceService

class MultiServiceAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)
        self.openai_service = OpenAIService()
        self.vision_service = GoogleVisionService()
        self.nlp_service = HuggingFaceService()

    def generate_reply(self, messages, sender):
        last_message = messages[-1]['content']
        
        if "analyze image" in last_message.lower():
            # Assume the image path is provided in the message
            image_path = last_message.split(":")[-1].strip()
            return self.analyze_image(image_path)
        elif "summarize" in last_message.lower():
            text = last_message.split("summarize:")[-1].strip()
            return self.summarize(text)
        elif "translate" in last_message.lower():
            text = last_message.split("translate:")[-1].strip()
            return self.translate(text)
        else:
            return self.generate_text(last_message)

    def generate_text(self, prompt):
        response = self.openai_service.generate_text(prompt)
        return response if response else "I couldn't generate a response."

    def analyze_image(self, image_path):
        labels = self.vision_service.analyze_image(image_path)
        if labels:
            return f"I see the following in the image: {', '.join(labels)}"
        else:
            return "I couldn't analyze the image."

    def summarize(self, text):
        summary = self.nlp_service.summarize_text(text)
        return summary if summary else "I couldn't summarize the text."

    def translate(self, text):
        translation = self.nlp_service.translate_text(text)
        return translation if translation else "I couldn't translate the text."
```

## Best Practices and Considerations

When integrating external AI services into your AutoGen agents, keep these best practices in mind:

1. **Error Handling**: Implement robust error handling for API calls to external services.
2. **Rate Limiting**: Be aware of and respect the rate limits of each service.
3. **Caching**: Implement caching mechanisms to reduce API calls and improve performance.
4. **Fallback Mechanisms**: Have fallback options in case a service is unavailable.
5. **Security**: Always keep API keys secure and never expose them in your code.
6. **Costs**: Be mindful of the costs associated with using external AI services.

## Conclusion

In this lesson, we've explored how to integrate external AI services into AutoGen agents. We've created a multi-service agent that can leverage the capabilities of OpenAI, Google Cloud Vision, and Hugging Face models. This approach allows you to create more powerful and versatile agents that can handle a wide range of tasks.

To use the MultiServiceAgent, you can create an instance and interact with it like this:

```python
# main.py

from agents.multi_service_agent import MultiServiceAgent

def main():
    agent = MultiServiceAgent("MultiServiceAgent")

    # Test text generation
    response = agent.generate_reply([{"content": "What is the capital of France?"}], None)
    print("Text Generation:", response)

    # Test image analysis
    response = agent.generate_reply([{"content": "analyze image: path/to/image.jpg"}], None)
    print("Image Analysis:", response)

    # Test summarization
    text_to_summarize = "Long text to summarize..."
    response = agent.generate_reply([{"content": f"summarize: {text_to_summarize}"}], None)
    print("Summarization:", response)

    # Test translation
    text_to_translate = "Hello, how are you?"
    response = agent.generate_reply([{"content": f"translate: {text_to_translate}"}], None)
    print("Translation:", response)

if __name__ == "__main__":
    main()
```

This integration of external AI services greatly expands the capabilities of your AutoGen agents, allowing them to perform a wide range of tasks from text generation to image analysis and language processing. As AI services continue to evolve, you can easily update and expand your agents' capabilities by integrating new services or upgrading existing ones.

