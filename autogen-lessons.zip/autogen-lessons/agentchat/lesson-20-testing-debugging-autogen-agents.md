# Lesson 20: Testing and Debugging Autogen Agents

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Setting Up a Testing Environment](#setting-up-a-testing-environment)
4. [Unit Testing Autogen Agents](#unit-testing-autogen-agents)
5. [Integration Testing with Multiple Agents](#integration-testing-with-multiple-agents)
6. [Mocking External Services](#mocking-external-services)
7. [Debugging Techniques for Autogen Agents](#debugging-techniques-for-autogen-agents)
8. [Performance Testing and Optimization](#performance-testing-and-optimization)
9. [Continuous Integration for Autogen Projects](#continuous-integration-for-autogen-projects)
10. [Best Practices and Common Pitfalls](#best-practices-and-common-pitfalls)
11. [Conclusion](#conclusion)

## 1. Introduction

Testing and debugging are crucial aspects of developing robust and reliable Autogen agents. In this lesson, we'll explore various techniques and best practices for ensuring the quality and correctness of your Autogen-based applications. We'll cover unit testing, integration testing, mocking external services, debugging strategies, and performance optimization.

## 2. Project Structure

Before we dive into the details, let's look at a typical project structure for an Autogen application with a focus on testing:

```
autogen_project/
│
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── assistant_agent.py
│   │   ├── user_proxy_agent.py
│   │   └── custom_agent.py
│   ├── utils/
│   │   ├── __init__.py
│   │   └── helpers.py
│   └── main.py
│
├── tests/
│   ├── unit/
│   │   ├── __init__.py
│   │   ├── test_assistant_agent.py
│   │   ├── test_user_proxy_agent.py
│   │   └── test_custom_agent.py
│   ├── integration/
│   │   ├── __init__.py
│   │   └── test_agent_interactions.py
│   └── conftest.py
│
├── .env
├── requirements.txt
├── setup.py
└── README.md
```

This structure separates the source code (`src/`) from the tests (`tests/`), making it easy to organize and run tests independently.

## 3. Setting Up a Testing Environment

To begin testing your Autogen agents, you'll need to set up a proper testing environment. We'll use pytest as our testing framework.

1. Install pytest and other dependencies:

```bash
pip install pytest pytest-mock pytest-asyncio
```

2. Create a `conftest.py` file in your `tests/` directory to define fixtures:

```python
# tests/conftest.py
import pytest
from autogen import OpenAIWrapper

@pytest.fixture
def mock_openai_client(mocker):
    mock_client = mocker.Mock(spec=OpenAIWrapper)
    mock_client.create.return_value = mocker.Mock(choices=[mocker.Mock(message=mocker.Mock(content="Mocked response"))])
    return mock_client

@pytest.fixture
def test_config():
    return {
        "model": "gpt-3.5-turbo",
        "temperature": 0.7,
        "max_tokens": 150
    }
```

These fixtures will be available to all your test files, allowing you to easily mock the OpenAI client and provide a test configuration.

## 4. Unit Testing Autogen Agents

Unit tests focus on testing individual components in isolation. Let's create a unit test for an AssistantAgent:

```python
# tests/unit/test_assistant_agent.py
import pytest
from autogen import AssistantAgent

def test_assistant_agent_initialization(test_config):
    agent = AssistantAgent("TestAssistant", llm_config=test_config)
    assert agent.name == "TestAssistant"
    assert agent.llm_config == test_config

def test_assistant_agent_generate_reply(mock_openai_client, test_config):
    agent = AssistantAgent("TestAssistant", llm_config=test_config)
    agent.client = mock_openai_client

    reply = agent.generate_reply("Hello, can you help me?")
    assert reply == "Mocked response"
    mock_openai_client.create.assert_called_once()

@pytest.mark.asyncio
async def test_assistant_agent_a_generate_reply(mock_openai_client, test_config):
    agent = AssistantAgent("TestAssistant", llm_config=test_config)
    agent.client = mock_openai_client

    reply = await agent.a_generate_reply("Hello, can you help me?")
    assert reply == "Mocked response"
    mock_openai_client.create.assert_called_once()
```

These tests verify the initialization of the AssistantAgent and its ability to generate replies, both synchronously and asynchronously.

## 5. Integration Testing with Multiple Agents

Integration tests ensure that different components of your system work together correctly. Let's create an integration test for a conversation between an AssistantAgent and a UserProxyAgent:

```python
# tests/integration/test_agent_interactions.py
import pytest
from autogen import AssistantAgent, UserProxyAgent, ConversableAgent

@pytest.fixture
def assistant_agent(mock_openai_client, test_config):
    agent = AssistantAgent("Assistant", llm_config=test_config)
    agent.client = mock_openai_client
    return agent

@pytest.fixture
def user_proxy_agent():
    return UserProxyAgent("User", human_input_mode="NEVER")

def test_agent_conversation(assistant_agent, user_proxy_agent):
    user_proxy_agent.initiate_chat(
        assistant_agent,
        message="What's the capital of France?"
    )

    assert len(user_proxy_agent.chat_messages[assistant_agent]) > 1
    assert "Mocked response" in user_proxy_agent.last_message()["content"]

@pytest.mark.asyncio
async def test_agent_conversation_async(assistant_agent, user_proxy_agent):
    await user_proxy_agent.a_initiate_chat(
        assistant_agent,
        message="What's the capital of France?"
    )

    assert len(user_proxy_agent.chat_messages[assistant_agent]) > 1
    assert "Mocked response" in user_proxy_agent.last_message()["content"]
```

These tests verify that the agents can interact with each other correctly, both synchronously and asynchronously.

## 6. Mocking External Services

When testing Autogen agents, you often need to mock external services like APIs or databases. We've already seen how to mock the OpenAI client, but let's look at a more complex example involving a custom function:

```python
# src/agents/custom_agent.py
import requests
from autogen import ConversableAgent

class WeatherAgent(ConversableAgent):
    def __init__(self, name, api_key):
        super().__init__(name)
        self.api_key = api_key

    def get_weather(self, city):
        url = f"http://api.weatherapi.com/v1/current.json?key={self.api_key}&q={city}"
        response = requests.get(url)
        data = response.json()
        return f"The current temperature in {city} is {data['current']['temp_c']}°C"

# tests/unit/test_custom_agent.py
import pytest
from src.agents.custom_agent import WeatherAgent

def test_weather_agent(mocker):
    mock_response = mocker.Mock()
    mock_response.json.return_value = {
        "current": {
            "temp_c": 25
        }
    }
    mocker.patch('requests.get', return_value=mock_response)

    agent = WeatherAgent("WeatherBot", api_key="fake_key")
    result = agent.get_weather("London")

    assert result == "The current temperature in London is 25°C"
    requests.get.assert_called_once_with(
        "http://api.weatherapi.com/v1/current.json?key=fake_key&q=London"
    )
```

This test mocks the external weather API, allowing us to test the WeatherAgent without making actual API calls.

## 7. Debugging Techniques for Autogen Agents

Debugging Autogen agents can be challenging due to their conversational nature. Here are some techniques to help you debug effectively:

1. Use logging:
   Add logging statements to your agents to track their internal state and decision-making process.

```python
import logging

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class DebuggableAgent(ConversableAgent):
    def generate_reply(self, messages, sender):
        logger.debug(f"Generating reply for messages: {messages}")
        reply = super().generate_reply(messages, sender)
        logger.debug(f"Generated reply: {reply}")
        return reply
```

2. Implement a debug mode:
   Add a debug mode to your agents that provides more verbose output or allows for step-by-step execution.

```python
class DebuggableAgent(ConversableAgent):
    def __init__(self, name, debug_mode=False):
        super().__init__(name)
        self.debug_mode = debug_mode

    def generate_reply(self, messages, sender):
        if self.debug_mode:
            user_input = input("Press Enter to generate reply, or type 'q' to quit: ")
            if user_input.lower() == 'q':
                return "TERMINATE"
        return super().generate_reply(messages, sender)
```

3. Use breakpoints:
   Place breakpoints in your code to pause execution and inspect the agent's state at specific points.

4. Implement custom error handling:
   Add try-except blocks to catch and log specific errors that may occur during agent execution.

```python
class ErrorHandlingAgent(ConversableAgent):
    def generate_reply(self, messages, sender):
        try:
            return super().generate_reply(messages, sender)
        except Exception as e:
            logger.error(f"Error generating reply: {str(e)}")
            return "I encountered an error. Please try again."
```

## 8. Performance Testing and Optimization

To ensure your Autogen agents perform well under various conditions, consider implementing performance tests:

1. Response time testing:
   Measure the time it takes for agents to generate responses under different loads.

```python
import time
import statistics

def test_agent_response_time(agent, num_requests=100):
    response_times = []
    for _ in range(num_requests):
        start_time = time.time()
        agent.generate_reply("Test message")
        end_time = time.time()
        response_times.append(end_time - start_time)

    avg_time = statistics.mean(response_times)
    max_time = max(response_times)
    min_time = min(response_times)

    print(f"Average response time: {avg_time:.2f}s")
    print(f"Max response time: {max_time:.2f}s")
    print(f"Min response time: {min_time:.2f}s")
```

2. Memory usage monitoring:
   Track memory usage during long-running conversations or complex tasks.

```python
import psutil
import os

def monitor_memory_usage(func):
    def wrapper(*args, **kwargs):
        process = psutil.Process(os.getpid())
        mem_before = process.memory_info().rss
        result = func(*args, **kwargs)
        mem_after = process.memory_info().rss
        print(f"Memory usage: {(mem_after - mem_before) / 1024 / 1024:.2f} MB")
        return result
    return wrapper

@monitor_memory_usage
def run_complex_task(agent):
    # Perform a complex task with the agent
    pass
```

3. Concurrency testing:
   Test how well your agents perform when handling multiple conversations simultaneously.

```python
import asyncio

async def concurrent_conversations(agent, num_conversations):
    async def single_conversation(conversation_id):
        return await agent.a_generate_reply(f"Hello from conversation {conversation_id}")

    tasks = [single_conversation(i) for i in range(num_conversations)]
    results = await asyncio.gather(*tasks)
    return results

# Usage
results = asyncio.run(concurrent_conversations(agent, 10))
```

## 9. Continuous Integration for Autogen Projects

Setting up continuous integration (CI) for your Autogen project helps ensure that your tests are run automatically whenever changes are made to your codebase. Here's an example of a GitHub Actions workflow for running tests:

```yaml
# .github/workflows/tests.yml
name: Run Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Run tests
      env:
        OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
      run: |
        pytest tests/
```

This workflow will run your tests on every push and pull request, helping you catch issues early in the development process.

## 10. Best Practices and Common Pitfalls

Here are some best practices to follow when testing and debugging Autogen agents:

1. Write tests for both happy paths and edge cases.
2. Use meaningful names for your test functions and variables.
3. Keep your tests independent and isolated from each other.
4. Avoid hardcoding API keys or sensitive information in your tests.
5. Regularly update your mock data to reflect changes in external services.
6. Use parameterized tests to cover multiple scenarios efficiently.

Common pitfalls to avoid:

1. Relying too heavily on integration tests at the expense of unit tests.
2. Neglecting to test error handling and edge cases.
3. Using actual API calls in tests, which can be slow and unreliable.
4. Not properly mocking or stubbing external dependencies.
5. Ignoring performance considerations in your tests.

## 11. Conclusion

Testing and debugging Autogen agents requires a combination of traditional software testing techniques and specialized approaches for dealing with AI-powered conversational systems. By following the practices outlined in this lesson, you'll be better equipped to create robust, reliable, and high-performing Autogen applications.

Remember to:
- Write comprehensive unit and integration tests
- Mock external services and dependencies
- Implement effective debugging techniques
- Monitor and optimize performance
- Set up continuous integration for your project

As you continue to work with Autogen, you'll develop a deeper understanding of how to test and debug these complex systems effectively.

