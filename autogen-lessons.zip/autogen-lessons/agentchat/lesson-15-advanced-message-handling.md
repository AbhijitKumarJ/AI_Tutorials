# Lesson 15: Advanced Message Handling and Processing in AgentChat

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Message Structures Across Different Agent Types](#message-structures)
4. [Customizing Message Flow in Complex Agent Systems](#customizing-message-flow)
5. [Implementing Advanced Filtering and Routing](#advanced-filtering-and-routing)
6. [Practical Examples](#practical-examples)
7. [Best Practices](#best-practices)
8. [Conclusion](#conclusion)

## 1. Introduction <a name="introduction"></a>

In this lesson, we'll dive deep into advanced message handling and processing techniques in the AgentChat module of AutoGen. Understanding how to manipulate and control message flow is crucial for building sophisticated multi-agent systems. We'll explore various aspects of message handling, including different message structures, customizing message flow, and implementing advanced filtering and routing mechanisms.

## 2. Project Structure <a name="project-structure"></a>

Before we begin, let's look at the typical project structure for an application using advanced message handling in AgentChat:

```
autogen_project/
├── main.py
├── agents/
│   ├── __init__.py
│   ├── base_agent.py
│   ├── assistant_agent.py
│   ├── user_proxy_agent.py
│   └── custom_agent.py
├── message_handlers/
│   ├── __init__.py
│   ├── message_processor.py
│   ├── filter.py
│   └── router.py
├── utils/
│   ├── __init__.py
│   └── message_utils.py
├── config/
│   └── config.json
└── requirements.txt
```

This structure organizes our code into separate modules for agents, message handlers, and utilities, making it easier to manage and extend our application.

## 3. Message Structures Across Different Agent Types <a name="message-structures"></a>

Different agent types in AutoGen may use slightly different message structures. Let's examine these structures and how to work with them effectively.

### 3.1 Basic Message Structure

The basic message structure in AutoGen is a dictionary with the following keys:

- `role`: The role of the message sender (e.g., "user", "assistant", "system")
- `content`: The actual content of the message

Example:

```python
basic_message = {
    "role": "user",
    "content": "What's the weather like today?"
}
```

### 3.2 AssistantAgent Message Structure

AssistantAgent may include additional fields in its messages:

```python
assistant_message = {
    "role": "assistant",
    "content": "Based on the current data, it's sunny with a high of 75°F (24°C) today.",
    "function_call": None,
    "context": {"timestamp": "2024-09-17T10:30:00Z"}
}
```

### 3.3 UserProxyAgent Message Structure

UserProxyAgent messages might include metadata about user interactions:

```python
user_proxy_message = {
    "role": "user",
    "content": "Show me the forecast for the next 5 days.",
    "metadata": {
        "user_id": "user123",
        "session_id": "abcd1234",
        "client_info": {"browser": "Chrome", "os": "Windows"}
    }
}
```

To handle these different structures effectively, we can create a `MessageProcessor` class:

```python
# message_handlers/message_processor.py

class MessageProcessor:
    @staticmethod
    def extract_content(message: dict) -> str:
        return message.get("content", "")

    @staticmethod
    def extract_metadata(message: dict) -> dict:
        return message.get("metadata", {})

    @staticmethod
    def extract_function_call(message: dict) -> dict:
        return message.get("function_call")

    @staticmethod
    def create_response(role: str, content: str, **kwargs) -> dict:
        response = {"role": role, "content": content}
        response.update(kwargs)
        return response
```

## 4. Customizing Message Flow in Complex Agent Systems <a name="customizing-message-flow"></a>

In complex multi-agent systems, customizing the message flow can greatly enhance the system's capabilities. Let's explore some techniques to achieve this.

### 4.1 Message Interception and Modification

We can intercept and modify messages before they reach their intended recipient. This is useful for adding context, logging, or transforming message content.

```python
# message_handlers/message_processor.py

class MessageInterceptor:
    def __init__(self, agents):
        self.agents = agents

    def intercept(self, sender, recipient, message):
        # Add timestamp to all messages
        message["timestamp"] = time.time()

        # If the sender is a UserProxyAgent, add user context
        if isinstance(sender, UserProxyAgent):
            message["user_context"] = self.get_user_context(sender)

        return message

    def get_user_context(self, user_agent):
        # Implement logic to fetch user context
        pass
```

### 4.2 Implementing Conversation History

Maintaining conversation history can be crucial for context-aware responses. Here's how we can implement it:

```python
# agents/base_agent.py

class BaseAgent:
    def __init__(self, name):
        self.name = name
        self.conversation_history = []

    def add_to_history(self, message):
        self.conversation_history.append(message)

    def get_recent_history(self, n=5):
        return self.conversation_history[-n:]

    def clear_history(self):
        self.conversation_history = []
```

## 5. Implementing Advanced Filtering and Routing <a name="advanced-filtering-and-routing"></a>

Advanced filtering and routing mechanisms can help direct messages to the appropriate agents or handlers based on content or metadata.

### 5.1 Content-based Filtering

```python
# message_handlers/filter.py

class ContentFilter:
    def __init__(self, keywords):
        self.keywords = keywords

    def filter(self, message):
        content = message.get("content", "").lower()
        return any(keyword in content for keyword in self.keywords)
```

### 5.2 Metadata-based Routing

```python
# message_handlers/router.py

class MessageRouter:
    def __init__(self, agents):
        self.agents = agents

    def route(self, message):
        content = message.get("content", "").lower()
        metadata = message.get("metadata", {})

        if "weather" in content:
            return self.agents["weather_agent"]
        elif "schedule" in content:
            return self.agents["scheduling_agent"]
        elif metadata.get("priority") == "high":
            return self.agents["priority_handler"]
        else:
            return self.agents["default_agent"]
```

## 6. Practical Examples <a name="practical-examples"></a>

Let's put these concepts into practice with a more complex example involving multiple agents and advanced message handling.

```python
# main.py

from agents.assistant_agent import AssistantAgent
from agents.user_proxy_agent import UserProxyAgent
from message_handlers.message_processor import MessageProcessor, MessageInterceptor
from message_handlers.filter import ContentFilter
from message_handlers.router import MessageRouter

def main():
    # Initialize agents
    user_agent = UserProxyAgent("User")
    weather_agent = AssistantAgent("WeatherAgent")
    scheduling_agent = AssistantAgent("SchedulingAgent")
    general_assistant = AssistantAgent("GeneralAssistant")

    agents = {
        "user": user_agent,
        "weather": weather_agent,
        "scheduling": scheduling_agent,
        "general": general_assistant
    }

    # Set up message handling components
    message_processor = MessageProcessor()
    interceptor = MessageInterceptor(agents)
    content_filter = ContentFilter(["urgent", "important", "asap"])
    router = MessageRouter(agents)

    # Simulate a conversation
    user_message = {
        "role": "user",
        "content": "What's the weather like today? Also, can you schedule a meeting for tomorrow?",
        "metadata": {"user_id": "user123"}
    }

    # Process the message
    processed_message = message_processor.create_response(**user_message)
    intercepted_message = interceptor.intercept(user_agent, None, processed_message)

    if content_filter.filter(intercepted_message):
        print("High priority message detected!")

    # Route the message
    target_agent = router.route(intercepted_message)
    print(f"Routing message to: {target_agent.name}")

    # Handle the message (simplified for this example)
    if target_agent == weather_agent:
        response = "It's sunny today with a high of 75°F."
    elif target_agent == scheduling_agent:
        response = "I've scheduled a meeting for tomorrow at 2 PM."
    else:
        response = "I can help you with that. What specific information do you need?"

    print(f"Response: {response}")

if __name__ == "__main__":
    main()
```

This example demonstrates how to use various components for advanced message handling, including message processing, interception, filtering, and routing.

## 7. Best Practices <a name="best-practices"></a>

When implementing advanced message handling and processing, keep these best practices in mind:

1. **Modularity**: Keep message handling components separate and modular for easy maintenance and extensibility.

2. **Consistency**: Maintain a consistent message structure across your system to simplify processing.

3. **Error Handling**: Implement robust error handling to deal with malformed messages or unexpected situations.

4. **Performance**: For large-scale systems, consider optimizing message processing for performance, possibly using asynchronous processing or caching mechanisms.

5. **Security**: Be cautious when processing user input and metadata. Implement proper sanitization and validation.

6. **Logging**: Implement comprehensive logging for message flow to aid in debugging and system analysis.

7. **Scalability**: Design your message handling system to be scalable, allowing for the easy addition of new agents or message types.

## 8. Conclusion <a name="conclusion"></a>

Advanced message handling and processing are crucial components in building sophisticated multi-agent systems with AutoGen. By understanding different message structures, implementing custom message flow, and utilizing advanced filtering and routing techniques, you can create more intelligent and responsive agent-based applications.

In this lesson, we've covered the fundamentals of working with various message structures, customizing message flow, and implementing advanced filtering and routing. We've also provided practical examples and best practices to guide your implementation.

As you continue to work with AutoGen, experiment with these techniques and adapt them to your specific use cases. Remember that effective message handling can greatly enhance the capabilities and user experience of your multi-agent systems.

