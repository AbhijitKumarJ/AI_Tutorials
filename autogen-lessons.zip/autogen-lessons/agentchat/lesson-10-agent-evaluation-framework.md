# Lesson 10: Agent Evaluation Framework

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding the Agent Evaluation Framework](#understanding-the-agent-evaluation-framework)
4. [Key Components](#key-components)
   - [Criterion](#criterion)
   - [Task](#task)
   - [CriticAgent](#criticagent)
   - [SubCriticAgent](#subcriticagent)
   - [QuantifierAgent](#quantifieragent)
5. [Implementing the Evaluation Process](#implementing-the-evaluation-process)
   - [Generating Criteria](#generating-criteria)
   - [Quantifying Criteria](#quantifying-criteria)
6. [Practical Example: Evaluating a Math Problem Solver](#practical-example-evaluating-a-math-problem-solver)
7. [Best Practices and Considerations](#best-practices-and-considerations)
8. [Conclusion](#conclusion)

## Introduction

The Agent Evaluation Framework is a crucial component of the AutoGen library, designed to assess and improve the performance of AI agents. This framework provides a structured approach to evaluate agents based on specific criteria, tasks, and quantifiable metrics. In this lesson, we'll dive deep into the components of the framework, understand how they interact, and learn how to implement an effective evaluation process for your AI agents.

## Project Structure

Before we begin, let's take a look at the project structure for the Agent Evaluation Framework:

```
autogen/
└── agentchat/
    └── contrib/
        └── agent_eval/
            ├── __init__.py
            ├── agent_eval.py
            ├── criterion.py
            ├── critic_agent.py
            ├── quantifier_agent.py
            ├── subcritic_agent.py
            ├── task.py
            └── README.md
```

This structure shows that the Agent Evaluation Framework is part of the `contrib` package within `agentchat`, indicating its experimental nature and potential for community contributions.

## Understanding the Agent Evaluation Framework

The Agent Evaluation Framework is designed to provide a systematic way of assessing the performance of AI agents. It consists of several key components that work together to generate evaluation criteria, assess agent performance, and quantify the results.

The main goals of this framework are:

1. To create a standardized method for evaluating AI agents
2. To provide insights into agent performance across various tasks and criteria
3. To facilitate the improvement of agents based on evaluation results

## Key Components

Let's explore the key components of the Agent Evaluation Framework:

### Criterion

The `Criterion` class, defined in `criterion.py`, represents a single evaluation criterion. It has the following structure:

```python
class Criterion(BaseModel):
    name: str
    description: str
    accepted_values: List[str]
    sub_criteria: List[Criterion] = list()
```

Example usage:

```python
criterion = Criterion(
    name="Mathematical Accuracy",
    description="Assess the correctness of the mathematical calculations",
    accepted_values=["Correct", "Partially Correct", "Incorrect"]
)
```

### Task

The `Task` class, defined in `task.py`, represents a specific task for which an agent is being evaluated. It includes the following attributes:

```python
class Task(BaseModel):
    name: str
    description: str
    successful_response: str
    failed_response: str
```

Example usage:

```python
task = Task(
    name="Solve Quadratic Equation",
    description="Solve the quadratic equation: ax^2 + bx + c = 0",
    successful_response="The agent correctly identified and calculated the roots of the equation.",
    failed_response="The agent failed to solve the equation or provided incorrect roots."
)
```

### CriticAgent

The `CriticAgent`, defined in `critic_agent.py`, is responsible for generating evaluation criteria based on a given task. It extends the `ConversableAgent` class:

```python
class CriticAgent(ConversableAgent):
    DEFAULT_SYSTEM_MESSAGE = """You are a helpful assistant. You suggest criteria for evaluating different tasks. They should be distinguishable, quantifiable and not redundant."""

    def __init__(
        self,
        name="critic",
        system_message: Optional[str] = DEFAULT_SYSTEM_MESSAGE,
        **kwargs,
    ):
        super().__init__(name=name, system_message=system_message, **kwargs)
```

### SubCriticAgent

The `SubCriticAgent`, defined in `subcritic_agent.py`, is used to generate sub-criteria for more detailed evaluation:

```python
class SubCriticAgent(ConversableAgent):
    DEFAULT_SYSTEM_MESSAGE = """You are a helpful assistant to the critic agent. You suggest sub criteria for evaluating different tasks based on the criteria provided by the critic agent (if you feel it is needed)."""

    def __init__(
        self,
        name="subcritic",
        system_message: Optional[str] = DEFAULT_SYSTEM_MESSAGE,
        **kwargs,
    ):
        super().__init__(name=name, system_message=system_message, **kwargs)
```

### QuantifierAgent

The `QuantifierAgent`, defined in `quantifier_agent.py`, is responsible for quantifying the performance of a system based on the provided criteria:

```python
class QuantifierAgent(ConversableAgent):
    DEFAULT_SYSTEM_MESSAGE = """You are a helpful assistant. You quantify the output of different tasks based on the given criteria."""

    def __init__(
        self,
        name="quantifier",
        system_message: Optional[str] = DEFAULT_SYSTEM_MESSAGE,
        **kwargs,
    ):
        super().__init__(name=name, system_message=system_message, **kwargs)
```

## Implementing the Evaluation Process

Now that we understand the key components, let's walk through the process of implementing an agent evaluation:

### Generating Criteria

To generate evaluation criteria, we use the `generate_criteria` function from `agent_eval.py`:

```python
def generate_criteria(
    llm_config: Optional[Union[Dict, Literal[False]]] = None,
    task: Task = None,
    additional_instructions: str = "",
    max_round=2,
    use_subcritic: bool = False,
):
    # Implementation details...
```

Example usage:

```python
from autogen.agentchat.contrib.agent_eval import generate_criteria, Task

task = Task(
    name="Solve Linear Equation",
    description="Solve the linear equation: ax + b = c",
    successful_response="The agent correctly solved for x.",
    failed_response="The agent failed to solve for x or provided an incorrect solution."
)

criteria = generate_criteria(
    llm_config={"model": "gpt-4"},
    task=task,
    additional_instructions="Focus on step-by-step problem-solving approach.",
    max_round=3,
    use_subcritic=True
)

print(criteria)
```

### Quantifying Criteria

To quantify the performance based on the generated criteria, we use the `quantify_criteria` function:

```python
def quantify_criteria(
    llm_config: Optional[Union[Dict, Literal[False]]] = None,
    criteria: List[Criterion] = None,
    task: Task = None,
    test_case: str = "",
    ground_truth: str = "",
):
    # Implementation details...
```

Example usage:

```python
from autogen.agentchat.contrib.agent_eval import quantify_criteria

result = quantify_criteria(
    llm_config={"model": "gpt-4"},
    criteria=criteria,
    task=task,
    test_case="Solve: 2x + 3 = 7",
    ground_truth="x = 2"
)

print(result)
```

## Practical Example: Evaluating a Math Problem Solver

Let's walk through a complete example of evaluating an agent designed to solve math problems:

```python
from autogen.agentchat.contrib.agent_eval import Task, generate_criteria, quantify_criteria
from autogen import AssistantAgent, UserProxyAgent

# Define the task
math_task = Task(
    name="Solve Algebraic Equation",
    description="Solve the given algebraic equation and show your work.",
    successful_response="The agent correctly solved the equation with proper steps.",
    failed_response="The agent failed to solve the equation or made errors in the process."
)

# Generate criteria
criteria = generate_criteria(
    llm_config={"model": "gpt-4"},
    task=math_task,
    additional_instructions="Evaluate both the final answer and the problem-solving process.",
    use_subcritic=True
)

# Create the agent to be evaluated
math_solver = AssistantAgent(
    name="MathSolver",
    llm_config={"model": "gpt-3.5-turbo"},
    system_message="You are an expert mathematics problem solver. Solve algebraic equations step by step."
)

# Create a user proxy to interact with the math solver
user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="NEVER",
    max_consecutive_auto_reply=1
)

# Simulate a conversation to solve a math problem
user_proxy.initiate_chat(
    math_solver,
    message="Solve the equation: 3x + 7 = 22"
)

# Extract the math solver's response
math_solver_response = user_proxy.chat_messages[math_solver][-1]['content']

# Quantify the performance
evaluation_result = quantify_criteria(
    llm_config={"model": "gpt-4"},
    criteria=criteria,
    task=math_task,
    test_case="Solve the equation: 3x + 7 = 22",
    ground_truth="x = 5"
)

print("Math Solver's Response:")
print(math_solver_response)
print("\nEvaluation Result:")
print(evaluation_result)
```

This example demonstrates how to set up a task, generate evaluation criteria, create an agent to solve the task, and then evaluate its performance using the Agent Evaluation Framework.

## Best Practices and Considerations

When using the Agent Evaluation Framework, keep the following best practices in mind:

1. **Clear Task Definition**: Ensure that your tasks are well-defined and specific. This helps in generating more accurate evaluation criteria.

2. **Comprehensive Criteria**: Use the `SubCriticAgent` to generate detailed sub-criteria for a more thorough evaluation.

3. **Diverse Test Cases**: Provide a variety of test cases to get a comprehensive understanding of the agent's performance across different scenarios.

4. **Iterative Improvement**: Use the evaluation results to iteratively improve your agents. Identify weaknesses and refine the agent's capabilities accordingly.

5. **Human Oversight**: While the framework provides automated evaluation, it's important to have human oversight to ensure the relevance and accuracy of the generated criteria and quantification.

6. **Consistency**: Use consistent evaluation methods across different versions of your agents to track improvements over time.

7. **Documentation**: Keep detailed records of your evaluation process, including the criteria used, test cases, and results. This will be valuable for future reference and improvements.

## Conclusion

The Agent Evaluation Framework in AutoGen provides a powerful and flexible way to assess the performance of AI agents. By leveraging components like `CriticAgent`, `SubCriticAgent`, and `QuantifierAgent`, you can create comprehensive evaluation processes that provide valuable insights into your agents' capabilities and areas for improvement.

As you work with this framework, remember that it's part of the `contrib` package, which means it may evolve over time. Stay updated with the latest AutoGen documentation and contribute your own improvements to help advance the field of AI agent evaluation.

In the next lesson, we'll explore advanced topics in AutoGen, including customizing the framework for specific use cases and integrating it into larger AI systems.

