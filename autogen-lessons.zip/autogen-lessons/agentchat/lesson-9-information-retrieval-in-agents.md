# Lesson 9: Information Retrieval in Agents

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding Retrieve Assistant Agent](#understanding-retrieve-assistant-agent)
4. [Exploring Retrieve User Proxy Agent](#exploring-retrieve-user-proxy-agent)
5. [Implementing Efficient Information Retrieval Systems](#implementing-efficient-information-retrieval-systems)
6. [Integrating External Knowledge Bases](#integrating-external-knowledge-bases)
7. [Practical Examples](#practical-examples)
8. [Exercises](#exercises)
9. [Summary](#summary)

## 1. Introduction <a name="introduction"></a>

In this lesson, we'll dive deep into the information retrieval capabilities of Autogen's AgentChat module. We'll focus on two key components: the Retrieve Assistant Agent and the Retrieve User Proxy Agent. These agents are designed to enhance the ability of our AI systems to access and utilize external information effectively.

Information retrieval is crucial for creating more knowledgeable and capable AI agents. By integrating external knowledge bases and implementing efficient retrieval mechanisms, we can significantly improve the performance and utility of our agents in various tasks.

## 2. Project Structure <a name="project-structure"></a>

Before we begin, let's look at the project structure for this lesson:

```
autogen_tutorial/
├── lesson9_information_retrieval/
│   ├── retrieve_assistant_example.py
│   ├── retrieve_user_proxy_example.py
│   ├── custom_retrieval_system.py
│   ├── knowledge_base/
│   │   ├── article1.txt
│   │   ├── article2.txt
│   │   └── article3.txt
│   ├── requirements.txt
│   └── README.md
└── README.md
```

This structure organizes our code and resources for the lesson, including example implementations and a sample knowledge base.

## 3. Understanding Retrieve Assistant Agent <a name="understanding-retrieve-assistant-agent"></a>

The Retrieve Assistant Agent is an extension of the standard Assistant Agent that can access and utilize external information sources. Let's examine its key features and how to use it effectively.

### Key Features

1. External knowledge access
2. Contextual information retrieval
3. Seamless integration with conversation flow

### Implementation

First, let's look at a basic implementation of the Retrieve Assistant Agent:

```python
# retrieve_assistant_example.py

from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent
from autogen.agentchat.contrib.retrieve_user_proxy_agent import RetrieveUserProxyAgent

# Initialize the retrieval configuration
retrieve_config = {
    "task": "qa",
    "docs_path": "./knowledge_base",
    "chunk_token_size": 1000,
    "model": "gpt-3.5-turbo",
    "client": None,  # Add your vector store client here if using a specific one
    "embedding_model": "text-embedding-ada-002",
    "customized_prompt": None,  # Add a custom prompt if needed
}

# Create the Retrieve Assistant Agent
retrieve_assistant = RetrieveAssistantAgent(
    name="retrieve_assistant",
    system_message="You are a helpful AI assistant with access to a knowledge base. Use this information to answer questions accurately.",
    llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]},
    retrieve_config=retrieve_config
)

# Create a Retrieve User Proxy Agent for interaction
user_proxy = RetrieveUserProxyAgent(
    name="user_proxy",
    human_input_mode="ALWAYS",
    retrieve_config=retrieve_config
)

# Start a conversation
user_proxy.initiate_chat(
    retrieve_assistant,
    message="What can you tell me about the benefits of regular exercise?"
)
```

In this example, we create a Retrieve Assistant Agent with access to a knowledge base located in the `knowledge_base` directory. The agent can use this information to provide more accurate and informed responses.

## 4. Exploring Retrieve User Proxy Agent <a name="exploring-retrieve-user-proxy-agent"></a>

The Retrieve User Proxy Agent is designed to simulate a user with access to external information. This agent can be particularly useful for testing and development scenarios where you want to emulate a knowledgeable user.

### Key Features

1. Simulates a user with external knowledge
2. Can retrieve information to formulate questions or responses
3. Useful for testing and development of information retrieval systems

### Implementation

Let's implement a scenario using the Retrieve User Proxy Agent:

```python
# retrieve_user_proxy_example.py

from autogen.agentchat.contrib.retrieve_user_proxy_agent import RetrieveUserProxyAgent
from autogen.agentchat.assistant_agent import AssistantAgent

# Initialize the retrieval configuration
retrieve_config = {
    "task": "qa",
    "docs_path": "./knowledge_base",
    "chunk_token_size": 1000,
    "model": "gpt-3.5-turbo",
    "client": None,
    "embedding_model": "text-embedding-ada-002",
}

# Create the Retrieve User Proxy Agent
retrieve_user = RetrieveUserProxyAgent(
    name="retrieve_user",
    retrieve_config=retrieve_config,
    human_input_mode="NEVER"  # Simulate fully automated retrieval
)

# Create a standard Assistant Agent for interaction
assistant = AssistantAgent(
    name="assistant",
    llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]}
)

# Start a conversation
retrieve_user.initiate_chat(
    assistant,
    message="Ask me about the benefits of meditation based on scientific studies."
)
```

In this example, the Retrieve User Proxy Agent acts as a knowledgeable user who can ask informed questions based on the information in the knowledge base.

## 5. Implementing Efficient Information Retrieval Systems <a name="implementing-efficient-information-retrieval-systems"></a>

To create an efficient information retrieval system, we need to consider several factors:

1. Indexing and storage of information
2. Efficient search algorithms
3. Relevance ranking of retrieved information

Let's implement a custom retrieval system that addresses these factors:

```python
# custom_retrieval_system.py

import os
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from collections import defaultdict
import math

nltk.download('punkt')
nltk.download('stopwords')

class CustomRetrievalSystem:
    def __init__(self, docs_path):
        self.docs_path = docs_path
        self.documents = {}
        self.inverted_index = defaultdict(dict)
        self.doc_lengths = {}
        self.load_documents()
        self.build_index()

    def load_documents(self):
        for filename in os.listdir(self.docs_path):
            if filename.endswith('.txt'):
                with open(os.path.join(self.docs_path, filename), 'r') as file:
                    self.documents[filename] = file.read()

    def build_index(self):
        stop_words = set(stopwords.words('english'))
        for doc_id, content in self.documents.items():
            tokens = word_tokenize(content.lower())
            tokens = [token for token in tokens if token.isalnum() and token not in stop_words]
            
            term_freq = defaultdict(int)
            for token in tokens:
                term_freq[token] += 1
            
            self.doc_lengths[doc_id] = math.sqrt(sum(tf ** 2 for tf in term_freq.values()))
            
            for term, freq in term_freq.items():
                self.inverted_index[term][doc_id] = freq

    def search(self, query, top_k=5):
        query_tokens = word_tokenize(query.lower())
        query_tokens = [token for token in query_tokens if token.isalnum() and token not in stopwords.words('english')]
        
        scores = defaultdict(float)
        for token in query_tokens:
            if token in self.inverted_index:
                idf = math.log(len(self.documents) / len(self.inverted_index[token]))
                for doc_id, tf in self.inverted_index[token].items():
                    tfidf = tf * idf
                    scores[doc_id] += tfidf / self.doc_lengths[doc_id]
        
        ranked_results = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
        return [(doc_id, self.documents[doc_id][:200] + '...') for doc_id, score in ranked_results]

# Usage
retrieval_system = CustomRetrievalSystem('./knowledge_base')
results = retrieval_system.search("benefits of regular exercise")
for doc_id, snippet in results:
    print(f"Document: {doc_id}")
    print(f"Snippet: {snippet}")
    print()
```

This custom retrieval system implements a basic TF-IDF (Term Frequency-Inverse Document Frequency) based search algorithm. It indexes the documents, removes stop words, and ranks the results based on relevance to the query.

## 6. Integrating External Knowledge Bases <a name="integrating-external-knowledge-bases"></a>

Integrating external knowledge bases can greatly enhance the capabilities of our retrieval agents. Let's explore how to integrate a popular vector database, Pinecone, with our Retrieve Assistant Agent:

```python
# First, install the necessary package:
# pip install pinecone-client

import pinecone
from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent

# Initialize Pinecone
pinecone.init(api_key="YOUR_PINECONE_API_KEY", environment="YOUR_PINECONE_ENVIRONMENT")

# Create or connect to an existing index
index_name = "your_index_name"
if index_name not in pinecone.list_indexes():
    pinecone.create_index(index_name, dimension=1536)  # 1536 is the dimension for 'text-embedding-ada-002'
index = pinecone.Index(index_name)

# Function to convert Pinecone results to the format expected by RetrieveAssistantAgent
def pinecone_to_retrieve_result(pinecone_results):
    return {
        "ids": [item["id"] for item in pinecone_results["matches"]],
        "documents": [item["metadata"]["text"] for item in pinecone_results["matches"]],
        "metadatas": [item["metadata"] for item in pinecone_results["matches"]],
        "distances": [item["score"] for item in pinecone_results["matches"]],
    }

# Custom retrieval function using Pinecone
def retrieve_from_pinecone(query, n_results=5):
    query_embedding = get_embedding(query)  # You need to implement this function to get embeddings
    results = index.query(query_embedding, top_k=n_results, include_metadata=True)
    return pinecone_to_retrieve_result(results)

# Create the Retrieve Assistant Agent with Pinecone integration
retrieve_config = {
    "task": "qa",
    "retriever": retrieve_from_pinecone,
    "chunk_token_size": 1000,
    "model": "gpt-3.5-turbo",
    "client": None,
    "embedding_model": "text-embedding-ada-002",
}

pinecone_assistant = RetrieveAssistantAgent(
    name="pinecone_assistant",
    system_message="You are a helpful AI assistant with access to a Pinecone knowledge base. Use this information to answer questions accurately.",
    llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]},
    retrieve_config=retrieve_config
)

# Use the Pinecone-integrated assistant in a conversation
user_proxy.initiate_chat(
    pinecone_assistant,
    message="What are the latest developments in renewable energy?"
)
```

This example demonstrates how to integrate Pinecone, a vector database, with our Retrieve Assistant Agent. By using a vector database, we can perform more efficient similarity searches on large datasets, which is particularly useful for handling extensive knowledge bases.

## 7. Practical Examples <a name="practical-examples"></a>

Let's explore some practical examples of using our information retrieval agents in real-world scenarios.

### Example 1: Research Assistant

```python
# research_assistant.py

from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent
from autogen.agentchat.contrib.retrieve_user_proxy_agent import RetrieveUserProxyAgent

retrieve_config = {
    "task": "qa",
    "docs_path": "./research_papers",
    "chunk_token_size": 1000,
    "model": "gpt-4",
    "embedding_model": "text-embedding-ada-002",
}

research_assistant = RetrieveAssistantAgent(
    name="research_assistant",
    system_message="You are a knowledgeable research assistant with access to a database of scientific papers. Provide accurate and up-to-date information based on these papers.",
    llm_config={"config_list": [{"model": "gpt-4"}]},
    retrieve_config=retrieve_config
)

user = RetrieveUserProxyAgent(
    name="researcher",
    human_input_mode="ALWAYS",
    retrieve_config=retrieve_config
)

user.initiate_chat(
    research_assistant,
    message="What are the latest findings on the effectiveness of mRNA vaccines?"
)
```

This example creates a research assistant that can access and summarize information from scientific papers.

### Example 2: Technical Support Agent

```python
# tech_support_agent.py

from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent
from autogen.agentchat.human_proxy_agent import HumanProxyAgent

retrieve_config = {
    "task": "qa",
    "docs_path": "./technical_manuals",
    "chunk_token_size": 500,
    "model": "gpt-3.5-turbo",
    "embedding_model": "text-embedding-ada-002",
}

tech_support = RetrieveAssistantAgent(
    name="tech_support",
    system_message="You are a helpful technical support agent with access to product manuals and troubleshooting guides. Provide clear and concise solutions to technical issues.",
    llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]},
    retrieve_config=retrieve_config
)

user = HumanProxyAgent(
    name="customer",
    human_input_mode="ALWAYS"
)

user.initiate_chat(
    tech_support,
    message="I'm having trouble connecting my printer to Wi-Fi. Can you help me troubleshoot?"
)
```

This example creates a technical support agent that can access product manuals and troubleshooting guides to assist customers with technical issues.

## 8. Exercises <a name="exercises"></a>

To reinforce your understanding of information retrieval in agents, try the following exercises:

1. Implement a Retrieve Assistant Agent that specializes in answering questions about a specific topic (e.g., history, science, literature). Use a curated knowledge base for this topic.

2. Create a custom retrieval system that uses a different ranking algorithm (e.g., BM25) instead of TF-IDF. Compare its performance with the TF-IDF based system we implemented earlier.

3. Extend the Retrieve User Proxy Agent to simulate a user with varying levels of knowledge. Implement a "knowledge level" parameter that affects the complexity and depth of the questions it asks.

4. Implement a multi-agent system where a Retrieve Assistant Agent collaborates with a standard Assistant Agent to answer complex queries. The Retrieve Assistant should provide relevant information, while the standard Assistant formulates the final response.

5. Create a Retrieve Assistant Agent that can handle multi-lingual queries and documents. Use a translation service to translate queries and documents as needed.

Here's a starting point for Exercise 4:

```python
# multi_agent_retrieval_system.py

from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent
from autogen.agentchat.assistant_agent import AssistantAgent
from autogen.agentchat.user_proxy_agent import UserProxyAgent

# Initialize retrieval configuration
retrieve_config = {
    "task": "qa",
    "docs_path": "./knowledge_base",
    "chunk_token_size": 1000,
    "model": "gpt-3.5-turbo",
    "embedding_model": "text-embedding-ada-002",
}

# Create a Retrieve Assistant Agent
retrieve_agent = RetrieveAssistantAgent(
    name="retriever",
    system_message="You are a retrieval specialist. Your role is to find and provide relevant information from the knowledge base.",
    llm_config={"config_list": [{"model": "gpt-3.5-turbo"}]},
    retrieve_config=retrieve_config
)

# Create a standard Assistant Agent
assistant = AssistantAgent(
    name="assistant",
    system_message="You are a helpful assistant. Your role is to formulate clear and concise answers based on the information provided by the retrieval specialist.",
    llm_config={"config_list": [{"model": "gpt-4"}]}
)

# Create a User Proxy Agent
user = UserProxyAgent(
    name="user",
    human_input_mode="ALWAYS"
)

# Function to manage the multi-agent conversation
def multi_agent_query(user_query):
    # Step 1: Retrieve relevant information
    retrieval_result = retrieve_agent.generate_response(user_query)
    
    # Step 2: Formulate a response using the retrieved information
    assistant_prompt = f"Based on the following retrieved information, please answer the user's query: '{user_query}'\n\nRetrieved Information: {retrieval_result}"
    final_response = assistant.generate_response(assistant_prompt)
    
    return final_response

# Example usage
user_query = "What are the potential applications of CRISPR technology in agriculture?"
response = multi_agent_query(user_query)
print(f"User Query: {user_query}")
print(f"Final Response: {response}")
```

## 9. Summary <a name="summary"></a>

In this lesson, we've explored the powerful information retrieval capabilities of Autogen's AgentChat module, focusing on the Retrieve Assistant Agent and Retrieve User Proxy Agent. We've covered:

1. The fundamentals of information retrieval in AI agents
2. Implementing and customizing Retrieve Assistant Agents
3. Utilizing Retrieve User Proxy Agents for testing and development
4. Creating efficient information retrieval systems
5. Integrating external knowledge bases, such as Pinecone
6. Practical examples of information retrieval agents in real-world scenarios
7. Exercises to reinforce understanding and encourage experimentation

Key takeaways:

- Information retrieval greatly enhances the capabilities of AI agents, allowing them to access and utilize vast amounts of external knowledge.
- The Retrieve Assistant Agent and Retrieve User Proxy Agent provide flexible frameworks for implementing information retrieval in conversational AI systems.
- Custom retrieval systems can be tailored to specific needs, using techniques like TF-IDF or more advanced algorithms.
- Integration with vector databases like Pinecone can significantly improve retrieval performance for large-scale applications.
- Multi-agent systems can leverage the strengths of different agent types to create more powerful and flexible information retrieval solutions.

As you continue to work with Autogen's AgentChat module, consider how you can leverage these information retrieval capabilities to create more knowledgeable and capable AI agents. Experiment with different retrieval methods, knowledge bases, and agent configurations to find the best approach for your specific use cases.

In the next lesson, we'll explore advanced topics in agent evaluation, focusing on the agent_eval subfolder and its components. This will help you assess and improve the performance of your information retrieval agents and other AI systems built with Autogen.
