# Lesson 7: Contributed Agents and Utilities (Part 1)

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Overview of the contrib folder](#overview-of-the-contrib-folder)
4. [Agent Builder (agent_builder.py)](#agent-builder-agent_builderpy)
5. [GPT Assistant Agent (gpt_assistant_agent.py)](#gpt-assistant-agent-gpt_assistant_agentpy)
6. [Image Utilities (img_utils.py)](#image-utilities-img_utilspy)
7. [Hands-on Project: Multi-Agent Image Analysis System](#hands-on-project-multi-agent-image-analysis-system)
8. [Exercises](#exercises)
9. [Summary and Next Steps](#summary-and-next-steps)

## 1. Introduction

Welcome to Lesson 7 of our Autogen AgentChat series! In this lesson, we'll dive deep into the `contrib` folder of the AgentChat module, focusing on three key components: the agent builder, GPT assistant agent, and image utilities. These tools provide powerful extensions to the core AgentChat functionality, allowing you to create more flexible and capable agent systems.

By the end of this lesson, you'll be able to:
- Understand the structure and purpose of the `contrib` folder
- Use the agent builder to dynamically create and configure agents
- Implement a GPT assistant agent for advanced language tasks
- Handle images in agent conversations using image utilities
- Create a multi-agent system that combines these components

Let's get started by setting up our project structure for this lesson.

## 2. Project Structure

Before we dive into the code, let's set up our project structure. Create a new directory for this lesson and organize it as follows:

```
autogen_tutorial/
├── lesson7_contrib_agents/
│   ├── agent_builder_example.py
│   ├── gpt_assistant_example.py
│   ├── image_handling_example.py
│   ├── multi_agent_image_analysis.py
│   ├── images/
│   │   ├── sample_image1.jpg
│   │   └── sample_image2.jpg
│   ├── requirements.txt
│   └── README.md
└── README.md
```

Create these files and directories. We'll populate them as we progress through the lesson.

In the `requirements.txt` file, add the following dependencies:

```
pyautogen
Pillow
requests
```

Now, let's install these dependencies:

```bash
cd autogen_tutorial/lesson7_contrib_agents
pip install -r requirements.txt
```

## 3. Overview of the contrib folder

The `contrib` folder in the AgentChat module contains various extensions and specialized agents that enhance the core functionality of Autogen. Here's the structure of the `contrib` folder:

```
autogen/agentchat/contrib/
├── __init__.py
├── agent_builder.py
├── gpt_assistant_agent.py
├── img_utils.py
├── llava_agent.py
├── math_user_proxy_agent.py
├── multimodal_conversable_agent.py
├── retrieve_assistant_agent.py
├── retrieve_user_proxy_agent.py
├── web_surfer.py
├── agent_eval/
├── capabilities/
└── graph_rag/
```

In this lesson, we'll focus on `agent_builder.py`, `gpt_assistant_agent.py`, and `img_utils.py`. These components provide powerful tools for creating dynamic agent systems, integrating advanced language models, and handling image-based tasks.

## 4. Agent Builder (agent_builder.py)

The agent builder provides functionality to dynamically create and configure agents. This is particularly useful when you need to create agents with varying capabilities or configurations based on runtime conditions.

Key concepts:
- Dynamic agent creation
- Configuration management
- Agent customization

Let's create an example using the agent builder. Open `agent_builder_example.py` and add the following code:

```python
# agent_builder_example.py

import autogen
from autogen.agentchat.contrib.agent_builder import AgentBuilder

def main():
    # Initialize the agent builder
    builder = AgentBuilder()

    # Create a custom assistant agent
    custom_assistant = builder.create_agent(
        name="CustomAssistant",
        system_message="You are a helpful assistant specialized in Python programming.",
        llm_config={"model": "gpt-4", "temperature": 0.7}
    )

    # Create a user proxy agent
    user_proxy = autogen.UserProxyAgent(
        name="User",
        human_input_mode="TERMINATE",
        max_consecutive_auto_reply=10,
        is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
        code_execution_config={"work_dir": "coding"}
    )

    # Start a conversation
    user_proxy.initiate_chat(
        custom_assistant,
        message="Can you explain the concept of decorators in Python and provide a simple example?"
    )

if __name__ == "__main__":
    main()
```

In this example, we use the `AgentBuilder` to create a custom assistant specialized in Python programming. We then create a user proxy agent and initiate a conversation about Python decorators.

To run this example:

```bash
python agent_builder_example.py
```

The agent builder allows you to create agents with specific configurations, making it easier to tailor agents for particular tasks or domains.

## 5. GPT Assistant Agent (gpt_assistant_agent.py)

The GPT Assistant Agent is a specialized agent that leverages OpenAI's GPT models. It provides a powerful interface for creating agents with advanced language understanding and generation capabilities.

Key features:
- Integration with OpenAI's API
- Customizable system messages
- Handling of conversation context

Let's create an example using the GPT Assistant Agent. Open `gpt_assistant_example.py` and add the following code:

```python
# gpt_assistant_example.py

import autogen
from autogen.agentchat.contrib.gpt_assistant_agent import GPTAssistantAgent

def main():
    # Create a GPT Assistant Agent
    gpt_assistant = GPTAssistantAgent(
        name="DataAnalyst",
        instructions="You are an AI assistant expert in data analysis and visualization. Provide detailed explanations and code examples when appropriate.",
        llm_config={
            "model": "gpt-4",
            "temperature": 0.5,
            "config_list": [{"api_key": "your-openai-api-key"}]
        }
    )

    # Create a user proxy agent
    user_proxy = autogen.UserProxyAgent(
        name="User",
        human_input_mode="TERMINATE",
        max_consecutive_auto_reply=10,
        is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
        code_execution_config={"work_dir": "coding"}
    )

    # Start a conversation
    user_proxy.initiate_chat(
        gpt_assistant,
        message="Can you explain the difference between a bar plot and a histogram, and when to use each? Please provide Python code examples using matplotlib."
    )

if __name__ == "__main__":
    main()
```

In this example, we create a GPT Assistant Agent specialized in data analysis and visualization. We then initiate a conversation about the difference between bar plots and histograms, requesting Python code examples.

To run this example:

```bash
python gpt_assistant_example.py
```

Remember to replace `"your-openai-api-key"` with your actual OpenAI API key.

The GPT Assistant Agent allows you to create highly capable agents with specific expertise, leveraging the power of large language models.

## 6. Image Utilities (img_utils.py)

The `img_utils.py` file provides utilities for handling images in agent conversations. These utilities are particularly useful when working with agents that need to process or analyze image data.

Key functionalities:
- Image loading and processing
- Conversion between different image formats
- Integration of images in agent messages

Let's create an example that demonstrates how to use these image utilities. Open `image_handling_example.py` and add the following code:

```python
# image_handling_example.py

import autogen
from autogen.agentchat.contrib.img_utils import get_image_data, get_pil_image, pil_to_data_uri
from PIL import Image
import base64
import io

def main():
    # Load an image
    image_path = "images/sample_image1.jpg"
    image_data = get_image_data(image_path)

    # Create an agent that can handle images
    image_analyst = autogen.AssistantAgent(
        name="ImageAnalyst",
        system_message="You are an AI assistant capable of analyzing images. Describe the contents of images in detail.",
        llm_config={"model": "gpt-4-vision-preview", "max_tokens": 1000}
    )

    # Create a user proxy agent
    user_proxy = autogen.UserProxyAgent(
        name="User",
        human_input_mode="TERMINATE",
        max_consecutive_auto_reply=10,
        is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    )

    # Start a conversation with an image
    user_proxy.initiate_chat(
        image_analyst,
        message=[
            {
                "type": "text",
                "text": "What can you see in this image? Please provide a detailed description."
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{image_data}"
                }
            }
        ]
    )

if __name__ == "__main__":
    main()
```

This example demonstrates how to load an image, convert it to a format suitable for agent messages, and use it in a conversation with an image analysis agent.

To run this example:

```bash
python image_handling_example.py
```

Make sure you have an image file named `sample_image1.jpg` in the `images/` directory before running the script.

These image utilities make it easy to incorporate image-based tasks into your agent systems, enabling a wide range of multimodal applications.

## 7. Hands-on Project: Multi-Agent Image Analysis System

Now that we've explored the individual components, let's create a more complex system that combines these elements. We'll build a multi-agent image analysis system that uses the agent builder, GPT assistant, and image utilities.

Open `multi_agent_image_analysis.py` and add the following code:

```python
# multi_agent_image_analysis.py

import autogen
from autogen.agentchat.contrib.agent_builder import AgentBuilder
from autogen.agentchat.contrib.gpt_assistant_agent import GPTAssistantAgent
from autogen.agentchat.contrib.img_utils import get_image_data
import json

def main():
    # Initialize the agent builder
    builder = AgentBuilder()

    # Create an image description agent
    image_describer = builder.create_agent(
        name="ImageDescriber",
        system_message="You are an AI assistant specialized in describing images in detail. Provide comprehensive descriptions of image contents.",
        llm_config={"model": "gpt-4-vision-preview", "max_tokens": 1000}
    )

    # Create a GPT Assistant Agent for analysis
    analyst = GPTAssistantAgent(
        name="ImageAnalyst",
        instructions="You are an AI assistant expert in analyzing image descriptions and answering questions about them. Provide detailed answers and insights based on the image descriptions you receive.",
        llm_config={
            "model": "gpt-4",
            "temperature": 0.7,
            "config_list": [{"api_key": "your-openai-api-key"}]
        }
    )

    # Create a user proxy agent
    user_proxy = autogen.UserProxyAgent(
        name="User",
        human_input_mode="TERMINATE",
        max_consecutive_auto_reply=10,
        is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    )

    # Load images
    image1_data = get_image_data("images/sample_image1.jpg")
    image2_data = get_image_data("images/sample_image2.jpg")

    # Function to get image description
    def get_image_description(image_data):
        message = [
            {
                "type": "text",
                "text": "Please provide a detailed description of this image."
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{image_data}"
                }
            }
        ]
        response = user_proxy.initiate_chat(image_describer, message=message)
        return response.get("content", "")

    # Get descriptions for both images
    description1 = get_image_description(image1_data)
    description2 = get_image_description(image2_data)

    # Analyze the descriptions
    analysis_prompt = f"""
    I have descriptions of two images:

    Image 1: {description1}

    Image 2: {description2}

    Please analyze these descriptions and answer the following questions:
    1. What are the main similarities between the two images?
    2. What are the key differences between the two images?
    3. Based on these descriptions, what can you infer about the context or setting of these images?
    4. Are there any interesting details or patterns you notice across both images?

    Provide a detailed analysis for each question.
    """

    user_proxy.initiate_chat(analyst, message=analysis_prompt)

if __name__ == "__main__":
    main()
```

This project demonstrates a multi-agent system where:
1. An image description agent (created using the agent builder) provides detailed descriptions of two images.
2. A GPT Assistant Agent analyzes these descriptions and answers questions about the images.
3. Image utilities are used to load and process the images for use in the agent messages.

To run this project:

```bash
python multi_agent_image_analysis.py
```

Make sure you have two image files (`sample_image1.jpg` and `sample_image2.jpg`) in the `images/` directory, and replace `"your-openai-api-key"` with your actual OpenAI API key.

This hands-on project showcases how the different components we've learned about can be combined to create a sophisticated multi-agent system capable of advanced image analysis tasks.

## 8. Exercises

To reinforce your understanding of the concepts covered in this lesson, try the following exercises:

1. Modify the `agent_builder_example.py` to create an agent specialized in a different domain (e.g., history, literature, or science). Use this agent to answer domain-specific questions.

2. Extend the `gpt_assistant_example.py` to include a conversation about a complex topic that requires multiple turns of dialogue. Implement follow-up questions and clarifications.

3. Create a new script that uses the image utilities to implement a simple image classification system. Load multiple images, describe them using an image analysis agent, and then use another agent to categorize the images based on their descriptions.

4. Enhance the `multi_agent_image_analysis.py` project to include a third agent that generates creative writing prompts based on the image descriptions and analysis. Implement a workflow where this agent receives the output from the analyst and produces a short story prompt.

5. Implement error handling and input validation in the multi-agent project. Consider scenarios such as missing image files, API failures, or unexpected agent responses.

## 9. Summary and Next Steps

In this lesson, we've explored three key components from the `contrib` folder of the AgentChat module:

1. The agent builder, which allows for dynamic creation and configuration of