# Lesson 14: Extending AgentChat: Custom Extensions

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding the Extensions Folder](#understanding-the-extensions-folder)
4. [Creating a Custom Extension](#creating-a-custom-extension)
   - [Step 1: Define the Extension Class](#step-1-define-the-extension-class)
   - [Step 2: Implement the Extension Logic](#step-2-implement-the-extension-logic)
   - [Step 3: Register the Extension](#step-3-register-the-extension)
5. [Example: Creating a Weather Extension](#example-creating-a-weather-extension)
6. [Integrating Custom Extensions with Agents](#integrating-custom-extensions-with-agents)
7. [Best Practices for Custom Extensions](#best-practices-for-custom-extensions)
8. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll explore how to extend the functionality of AutoGen's AgentChat by creating custom extensions. Custom extensions allow you to add new capabilities to your agents, integrate external services, and create specialized behaviors tailored to your specific use cases.

## Project Structure

Before we dive into creating custom extensions, let's look at the project structure for a typical AutoGen project with custom extensions:

```
autogen_project/
│
├── autogen/
│   ├── agentchat/
│   │   ├── ...
│   │   └── extensions/
│   │       ├── __init__.py
│   │       └── weather_extension.py  # Our custom extension
│   ├── ...
│   └── __init__.py
│
├── examples/
│   └── use_weather_extension.py
│
├── tests/
│   └── test_weather_extension.py
│
└── setup.py
```

This structure shows where our custom extension (`weather_extension.py`) will be placed within the AutoGen project.

## Understanding the Extensions Folder

The `extensions` folder in the `agentchat` module is designed to house custom extensions that enhance the functionality of agents. Each extension is typically implemented as a separate Python module within this folder.

## Creating a Custom Extension

Let's go through the process of creating a custom extension step by step.

### Step 1: Define the Extension Class

First, we need to define a class for our extension. This class will encapsulate the functionality we want to add to our agents.

```python
# autogen/agentchat/extensions/weather_extension.py

from typing import Dict, Any

class WeatherExtension:
    def __init__(self, api_key: str):
        self.api_key = api_key

    def get_weather(self, location: str) -> Dict[str, Any]:
        # Implementation will be added in the next step
        pass
```

### Step 2: Implement the Extension Logic

Next, we'll implement the logic for our extension. In this case, we'll create a method to fetch weather data for a given location.

```python
# autogen/agentchat/extensions/weather_extension.py

import requests
from typing import Dict, Any

class WeatherExtension:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "http://api.openweathermap.org/data/2.5/weather"

    def get_weather(self, location: str) -> Dict[str, Any]:
        params = {
            "q": location,
            "appid": self.api_key,
            "units": "metric"
        }
        response = requests.get(self.base_url, params=params)
        if response.status_code == 200:
            data = response.json()
            return {
                "temperature": data["main"]["temp"],
                "description": data["weather"][0]["description"],
                "humidity": data["main"]["humidity"]
            }
        else:
            raise Exception(f"Failed to fetch weather data: {response.status_code}")
```

### Step 3: Register the Extension

To make the extension available to agents, we need to register it. This is typically done in the `__init__.py` file of the extensions folder.

```python
# autogen/agentchat/extensions/__init__.py

from .weather_extension import WeatherExtension

__all__ = ["WeatherExtension"]
```

## Example: Creating a Weather Extension

Now that we have our `WeatherExtension` class, let's see how we can use it in an agent. We'll create a simple example that demonstrates how an agent can use this extension to provide weather information.

```python
# examples/use_weather_extension.py

from autogen import AssistantAgent, UserProxyAgent
from autogen.agentchat.extensions import WeatherExtension

# Initialize the WeatherExtension
weather_extension = WeatherExtension(api_key="your_openweathermap_api_key")

# Create an assistant that can use the weather extension
weather_assistant = AssistantAgent(
    name="WeatherAssistant",
    llm_config={
        "temperature": 0.7,
        "model": "gpt-4"
    }
)

# Add the weather extension to the assistant
weather_assistant.register_function(
    function_map={
        "get_weather": weather_extension.get_weather
    }
)

# Create a user proxy agent
user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
)

# Start the conversation
user_proxy.initiate_chat(
    weather_assistant,
    message="What's the weather like in New York today?"
)
```

In this example, we've created a `WeatherAssistant` that has access to the `get_weather` function from our `WeatherExtension`. The assistant can now use this function to fetch and provide weather information during conversations.

## Integrating Custom Extensions with Agents

To make the most of custom extensions, consider the following integration techniques:

1. **Function Registration**: As shown in the example, use the `register_function` method to add extension functionality to agents.

2. **Extension-Aware Prompts**: Update the agent's system message to inform it about the new capabilities provided by the extension.

3. **Error Handling**: Implement proper error handling in your extensions and agents to gracefully handle API failures or unexpected responses.

4. **Caching**: For extensions that make external API calls, consider implementing a caching mechanism to improve performance and reduce API usage.

## Best Practices for Custom Extensions

When creating custom extensions for AutoGen, keep these best practices in mind:

1. **Modularity**: Design extensions to be modular and reusable across different agents and projects.

2. **Documentation**: Provide clear documentation for your extensions, including usage examples and any required API keys or setup steps.

3. **Testing**: Write unit tests for your extensions to ensure they work correctly and handle edge cases.

4. **Version Compatibility**: Clearly specify which versions of AutoGen your extension is compatible with.

5. **Security**: Be cautious when handling sensitive information like API keys. Use environment variables or secure configuration management.

6. **Performance**: Optimize your extensions for performance, especially if they involve network requests or heavy computations.

7. **Flexibility**: Design your extensions to be configurable, allowing users to customize their behavior as needed.

Here's an example of how you might implement some of these best practices:

```python
# autogen/agentchat/extensions/weather_extension.py

import os
import requests
from typing import Dict, Any
from cachetools import TTLCache

class WeatherExtension:
    def __init__(self, api_key: str = None, cache_ttl: int = 3600):
        self.api_key = api_key or os.environ.get("OPENWEATHERMAP_API_KEY")
        if not self.api_key:
            raise ValueError("OpenWeatherMap API key is required")
        self.base_url = "http://api.openweathermap.org/data/2.5/weather"
        self.cache = TTLCache(maxsize=100, ttl=cache_ttl)

    def get_weather(self, location: str) -> Dict[str, Any]:
        if location in self.cache:
            return self.cache[location]

        params = {
            "q": location,
            "appid": self.api_key,
            "units": "metric"
        }
        try:
            response = requests.get(self.base_url, params=params, timeout=5)
            response.raise_for_status()
            data = response.json()
            result = {
                "temperature": data["main"]["temp"],
                "description": data["weather"][0]["description"],
                "humidity": data["main"]["humidity"]
            }
            self.cache[location] = result
            return result
        except requests.RequestException as e:
            raise Exception(f"Failed to fetch weather data: {str(e)}")
```

This improved version includes error handling, caching, and the ability to use an environment variable for the API key.

## Conclusion

Custom extensions provide a powerful way to enhance the capabilities of AutoGen agents. By creating well-designed, modular extensions, you can add specialized functionality to your agents, integrate external services, and build more sophisticated AI applications.

Remember to follow best practices when developing extensions, and always consider the security and performance implications of your implementations. With custom extensions, you can tailor AutoGen to meet the specific needs of your projects and create more versatile and capable AI agents.

