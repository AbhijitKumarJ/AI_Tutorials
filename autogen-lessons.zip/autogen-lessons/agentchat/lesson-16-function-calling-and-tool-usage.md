# Lesson 16: Function Calling and Tool Usage in Agents

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding Function Calling in Agents](#understanding-function-calling-in-agents)
4. [Implementing Function Calls](#implementing-function-calls)
5. [Tool Usage in Agents](#tool-usage-in-agents)
6. [Best Practices for Function Calling and Tool Usage](#best-practices-for-function-calling-and-tool-usage)
7. [Advanced Techniques](#advanced-techniques)
8. [Practical Examples](#practical-examples)
9. [Conclusion](#conclusion)

## 1. Introduction

Function calling and tool usage are essential features in agent-based systems, allowing agents to perform specific tasks, access external resources, and enhance their capabilities. In this lesson, we'll explore how to implement and utilize these features effectively in AutoGen agents.

## 2. Project Structure

Before we dive into the details, let's look at the typical project structure for an AutoGen application that includes function calling and tool usage:

```
autogen_project/
│
├── main.py
├── agents/
│   ├── __init__.py
│   ├── assistant_agent.py
│   ├── user_proxy_agent.py
│   └── tool_using_agent.py
│
├── functions/
│   ├── __init__.py
│   ├── math_operations.py
│   ├── data_processing.py
│   └── web_utils.py
│
├── tools/
│   ├── __init__.py
│   ├── weather_api.py
│   ├── database_connector.py
│   └── file_manager.py
│
├── config/
│   └── config.json
│
└── requirements.txt
```

This structure organizes our code into separate modules for agents, functions, and tools, making it easier to manage and extend our application.

## 3. Understanding Function Calling in Agents

Function calling in agents allows them to execute predefined functions to perform specific tasks. These functions can be built-in Python functions, custom-defined functions, or even API calls to external services.

### Key Concepts:

1. **Function Registry**: A collection of functions that an agent can call.
2. **Function Signature**: The definition of a function, including its name, parameters, and return type.
3. **Function Execution**: The process of calling a function and handling its result.

## 4. Implementing Function Calls

Let's implement a basic function call system in our agents. We'll start by creating a simple math operation function and then integrate it into an agent.

First, let's create the math operation function in `functions/math_operations.py`:

```python
# functions/math_operations.py

def add_numbers(a: float, b: float) -> float:
    """Add two numbers and return the result."""
    return a + b
```

Now, let's create an agent that can use this function in `agents/tool_using_agent.py`:

```python
# agents/tool_using_agent.py

from autogen import ConversableAgent
from functions.math_operations import add_numbers

class MathAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name=name)
        self.register_function(
            function_map={
                "add_numbers": add_numbers
            }
        )

    def generate_reply(self, messages, sender):
        """Custom reply generation with function calling capability."""
        last_message = messages[-1]
        if "add" in last_message.lower():
            # Extract numbers from the message (simplified for demonstration)
            numbers = [float(s) for s in last_message.split() if s.isdigit()]
            if len(numbers) >= 2:
                result = self.execute_function(
                    function_name="add_numbers",
                    arguments={
                        "a": numbers[0],
                        "b": numbers[1]
                    }
                )
                return f"The sum is: {result}"
        
        # Default response if no function call is needed
        return "I can add numbers for you. Just ask!"

```

In this example, we've created a `MathAgent` that registers the `add_numbers` function and can use it when appropriate in the conversation.

## 5. Tool Usage in Agents

Tools are more complex than simple functions and often represent external services or APIs. They can be used to extend an agent's capabilities beyond basic computations.

Let's create a weather tool as an example:

```python
# tools/weather_api.py

import requests

class WeatherTool:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.openweathermap.org/data/2.5/weather"

    def get_weather(self, city: str) -> str:
        params = {
            "q": city,
            "appid": self.api_key,
            "units": "metric"
        }
        response = requests.get(self.base_url, params=params)
        data = response.json()
        if response.status_code == 200:
            temp = data["main"]["temp"]
            description = data["weather"][0]["description"]
            return f"The weather in {city} is {description} with a temperature of {temp}°C."
        else:
            return f"Error: Unable to fetch weather data for {city}."

```

Now, let's create an agent that can use this weather tool:

```python
# agents/tool_using_agent.py

from autogen import ConversableAgent
from tools.weather_api import WeatherTool

class WeatherAgent(ConversableAgent):
    def __init__(self, name, api_key):
        super().__init__(name=name)
        self.weather_tool = WeatherTool(api_key)

    def generate_reply(self, messages, sender):
        """Custom reply generation with weather tool usage."""
        last_message = messages[-1]
        if "weather" in last_message.lower():
            # Extract city name (simplified for demonstration)
            city = last_message.split("in")[-1].strip()
            weather_info = self.weather_tool.get_weather(city)
            return weather_info
        
        # Default response if no tool usage is needed
        return "I can provide weather information for cities. Just ask!"

```

## 6. Best Practices for Function Calling and Tool Usage

1. **Error Handling**: Always implement proper error handling for function calls and tool usage to manage unexpected inputs or API failures.

2. **Input Validation**: Validate inputs before passing them to functions or tools to ensure data integrity and prevent errors.

3. **Modular Design**: Keep functions and tools modular and reusable across different agents or projects.

4. **Documentation**: Provide clear documentation for each function and tool, including expected inputs, outputs, and any side effects.

5. **Configuration Management**: Use configuration files to manage API keys and other sensitive information for tools.

6. **Rate Limiting**: Implement rate limiting for API calls to avoid overusing external services.

7. **Caching**: Consider implementing caching mechanisms for frequently used function results or API responses to improve performance.

## 7. Advanced Techniques

### 7.1 Dynamic Function Discovery

Implement a system where agents can dynamically discover available functions based on the conversation context:

```python
# agents/dynamic_agent.py

import importlib
import inspect

class DynamicAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name=name)
        self.function_modules = {}

    def load_functions(self, module_name):
        module = importlib.import_module(module_name)
        functions = inspect.getmembers(module, inspect.isfunction)
        self.function_modules[module_name] = dict(functions)

    def generate_reply(self, messages, sender):
        last_message = messages[-1]
        for module_name, functions in self.function_modules.items():
            for func_name, func in functions.items():
                if func_name.lower() in last_message.lower():
                    # Execute the function (simplified for demonstration)
                    result = func()
                    return f"Result of {func_name}: {result}"
        return "I couldn't find a suitable function for your request."

```

### 7.2 Tool Chaining

Implement a system where multiple tools can be chained together to perform complex tasks:

```python
# agents/tool_chaining_agent.py

class ToolChainingAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name=name)
        self.tools = {}

    def add_tool(self, name, tool):
        self.tools[name] = tool

    def execute_tool_chain(self, chain):
        result = None
        for tool_name, args in chain:
            if tool_name in self.tools:
                tool = self.tools[tool_name]
                result = tool(**args)
            else:
                return f"Error: Tool '{tool_name}' not found."
        return result

    def generate_reply(self, messages, sender):
        # Logic to determine the tool chain based on the message
        # (Simplified for demonstration)
        chain = [
            ("weather_tool", {"city": "New York"}),
            ("translation_tool", {"text": "result", "target_lang": "fr"})
        ]
        result = self.execute_tool_chain(chain)
        return f"Result of tool chain: {result}"

```

## 8. Practical Examples

Let's look at a few practical examples of how to use function calling and tool usage in a real-world scenario.

### 8.1 Data Analysis Agent

```python
# agents/data_analysis_agent.py

import pandas as pd
from autogen import ConversableAgent

class DataAnalysisAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name=name)
        self.register_function(
            function_map={
                "load_csv": self.load_csv,
                "get_summary": self.get_summary,
                "plot_histogram": self.plot_histogram
            }
        )
        self.data = None

    def load_csv(self, file_path: str) -> str:
        self.data = pd.read_csv(file_path)
        return f"Loaded CSV file with {len(self.data)} rows and {len(self.data.columns)} columns."

    def get_summary(self) -> str:
        if self.data is None:
            return "No data loaded. Please load a CSV file first."
        return self.data.describe().to_string()

    def plot_histogram(self, column: str) -> str:
        if self.data is None:
            return "No data loaded. Please load a CSV file first."
        if column not in self.data.columns:
            return f"Column '{column}' not found in the data."
        plot = self.data[column].hist()
        plot_path = f"{column}_histogram.png"
        plot.figure.savefig(plot_path)
        return f"Histogram saved as {plot_path}"

    def generate_reply(self, messages, sender):
        last_message = messages[-1]
        if "load" in last_message.lower() and "csv" in last_message.lower():
            file_path = last_message.split()[-1]  # Simplified extraction
            return self.execute_function("load_csv", {"file_path": file_path})
        elif "summary" in last_message.lower():
            return self.execute_function("get_summary")
        elif "histogram" in last_message.lower():
            column = last_message.split()[-1]  # Simplified extraction
            return self.execute_function("plot_histogram", {"column": column})
        return "I can load CSV files, provide summaries, and plot histograms. How can I help you?"

```

### 8.2 Multi-Tool Agent

```python
# agents/multi_tool_agent.py

from autogen import ConversableAgent
from tools.weather_api import WeatherTool
from tools.database_connector import DatabaseConnector
from tools.file_manager import FileManager

class MultiToolAgent(ConversableAgent):
    def __init__(self, name, weather_api_key, db_config, file_dir):
        super().__init__(name=name)
        self.weather_tool = WeatherTool(weather_api_key)
        self.db_tool = DatabaseConnector(**db_config)
        self.file_tool = FileManager(file_dir)

    def generate_reply(self, messages, sender):
        last_message = messages[-1].lower()
        
        if "weather" in last_message:
            city = last_message.split("in")[-1].strip()
            return self.weather_tool.get_weather(city)
        
        elif "database" in last_message:
            if "query" in last_message:
                query = last_message.split("query")[-1].strip()
                return self.db_tool.execute_query(query)
            else:
                return "I can execute database queries. Please provide a query."
        
        elif "file" in last_message:
            if "list" in last_message:
                return self.file_tool.list_files()
            elif "read" in last_message:
                file_name = last_message.split("read")[-1].strip()
                return self.file_tool.read_file(file_name)
            elif "write" in last_message:
                # Simplified for demonstration
                file_name, content = last_message.split("write")[-1].split(":")
                return self.file_tool.write_file(file_name.strip(), content.strip())
            else:
                return "I can list, read, and write files. Please specify an action."
        
        return "I can help with weather information, database queries, and file operations. What would you like to do?"

```

## 9. Conclusion

Function calling and tool usage are powerful features that greatly enhance the capabilities of AutoGen agents. By implementing these features, you can create more versatile and efficient AI systems that can perform a wide range of tasks, from simple calculations to complex data analysis and external API interactions.

Remember to follow best practices, such as error handling, input validation, and modular design, to ensure your agents are robust and maintainable. As you build more complex systems, consider advanced techniques like dynamic function discovery and tool chaining to create even more flexible and powerful agents.

Practice implementing these concepts in your own projects, and don't hesitate to explore new ways to combine functions and tools to solve unique challenges in your AI applications.

