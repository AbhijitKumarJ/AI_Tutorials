# Lesson 1: Introduction to Autogen's AgentChat Module

## Table of Contents
1. [Introduction](#introduction)
2. [Overview of the agentchat Folder Structure](#overview-of-the-agentchat-folder-structure)
3. [Key Concepts and Components](#key-concepts-and-components)
4. [Basic Usage Patterns](#basic-usage-patterns)
5. [Project Structure](#project-structure)
6. [Hands-on Example](#hands-on-example)
7. [Exercise](#exercise)
8. [Summary and Next Steps](#summary-and-next-steps)

## Introduction

Welcome to the first lesson in our comprehensive series on Autogen's AgentChat module. Autogen is a powerful framework for building AI-powered applications and automating complex tasks. The AgentChat module, in particular, provides a flexible and extensible platform for creating conversational AI agents that can interact with each other and with humans.

In this lesson, we'll introduce you to the core concepts of the AgentChat module, explore its folder structure, and get you started with some basic usage patterns. By the end of this lesson, you'll have a solid foundation for building more complex agent-based systems in future lessons.

## Overview of the agentchat Folder Structure

Let's start by examining the folder structure of the AgentChat module:

```
autogen/
└── agentchat/
    ├── __init__.py
    ├── agent.py
    ├── assistant_agent.py
    ├── conversable_agent.py
    ├── groupchat.py
    ├── human_proxy_agent.py
    ├── user_proxy_agent.py
    ├── contrib/
    │   ├── __init__.py
    │   ├── agent_builder.py
    │   ├── gpt_assistant_agent.py
    │   ├── img_utils.py
    │   ├── llava_agent.py
    │   ├── math_user_proxy_agent.py
    │   ├── multimodal_conversable_agent.py
    │   ├── retrieve_assistant_agent.py
    │   ├── retrieve_user_proxy_agent.py
    │   ├── web_surfer.py
    │   ├── agent_eval/
    │   ├── capabilities/
    │   └── graph_rag/
    └── extensions/
        └── __init__.py
```

This structure shows the main components of the AgentChat module:

- Core agent classes (e.g., `agent.py`, `assistant_agent.py`, `conversable_agent.py`)
- Specialized agents (e.g., `human_proxy_agent.py`, `user_proxy_agent.py`)
- Group chat functionality (`groupchat.py`)
- Contributed extensions and utilities (`contrib/` folder)
- Custom extensions (`extensions/` folder)

## Key Concepts and Components

1. **Agent**: The fundamental building block of the AgentChat module. An agent represents an entity capable of performing actions, processing information, and engaging in conversations.

2. **ConversableAgent**: A base class for agents that can engage in conversations. It provides core functionality for message handling and generation.

3. **AssistantAgent**: A specialized agent designed to act as an AI assistant, capable of understanding and generating human-like text based on the conversation context.

4. **UserProxyAgent**: An agent that can represent a human user, execute code, and provide feedback to other agents.

5. **GroupChat**: A mechanism for managing conversations between multiple agents.

6. **HumanProxyAgent**: An agent designed to facilitate human interaction within the agent system.

7. **Contributed Components**: Additional utilities and specialized agents in the `contrib/` folder, such as the agent builder, GPT assistant, and image handling utilities.

## Basic Usage Patterns

Here's a simple example of how to create and use agents in the AgentChat module:

```python
from autogen import AssistantAgent, UserProxyAgent, config_list_from_json

# Load LLM inference endpoints from an env variable or a file
config_list = config_list_from_json(env_or_file="OAI_CONFIG_LIST")

# Create an AssistantAgent instance
assistant = AssistantAgent(
    name="AI_Assistant",
    llm_config={"config_list": config_list}
)

# Create a UserProxyAgent instance
user_proxy = UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={"work_dir": "coding"}
)

# Start a conversation
user_proxy.initiate_chat(
    assistant,
    message="Hello! Can you help me write a Python function to calculate the Fibonacci sequence?"
)
```

This example demonstrates the basic pattern of creating agents and initiating a conversation between them.

## Project Structure

For this lesson, we'll use the following project structure:

```
autogen_tutorial/
├── lesson1_introduction/
│   ├── basic_agent_chat.py
│   ├── config/
│   │   └── oai_config.json
│   └── requirements.txt
└── README.md
```

## Hands-on Example

Let's create a more detailed example that showcases the basic functionality of the AgentChat module. We'll create a simple task-solving system with an assistant agent and a user proxy agent.

Create a new file `basic_agent_chat.py` in the `lesson1_introduction/` directory:

```python
# basic_agent_chat.py

import autogen

# Configure the agents
config_list = autogen.config_list_from_json(env_or_file="config/oai_config.json")

assistant = autogen.AssistantAgent(
    name="AI_Assistant",
    llm_config={
        "config_list": config_list,
        "temperature": 0.7,
        "model": "gpt-4",
    },
    system_message="""You are a helpful AI assistant. Your task is to help users solve problems and answer questions to the best of your ability.
    If you're asked to perform a task that requires coding, provide the necessary code and explain how it works."""
)

user_proxy = autogen.UserProxyAgent(
    name="Human",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={
        "work_dir": "coding_workspace",
        "use_docker": False,
    }
)

# Define the task
task = """
1. Write a Python function to generate the Fibonacci sequence up to a given number of terms.
2. Use the function to generate the first 10 terms of the Fibonacci sequence.
3. Calculate the sum of these 10 terms.
Please provide the code and explain each step.
"""

# Start the conversation
user_proxy.initiate_chat(
    assistant,
    message=task
)

# The conversation will continue until the termination condition is met or the user types "exit"
```

To run this example, you'll need to create a `config/oai_config.json` file with your OpenAI API configuration:

```json
[
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here"
    }
]
```

Make sure to replace `"your_api_key_here"` with your actual OpenAI API key.

Also, create a `requirements.txt` file in the `lesson1_introduction/` directory:

```
pyautogen
```

To run the example, follow these steps:

1. Set up a virtual environment:
   ```
   python -m venv autogen_env
   source autogen_env/bin/activate  # On Windows, use `autogen_env\Scripts\activate`
   ```

2. Install the required packages:
   ```
   pip install -r requirements.txt
   ```

3. Run the script:
   ```
   python basic_agent_chat.py
   ```

This example demonstrates how to set up a basic conversation between an AI assistant and a user proxy, solve a multi-step task, and handle code execution.

## Exercise

Now that you've seen a basic example, try to extend it with the following features:

1. Add error handling to the code execution process.
2. Implement a simple feedback mechanism where the user can rate the assistant's response.
3. Modify the system message to specialize the assistant in a particular domain (e.g., data science, web development).

## Summary and Next Steps

In this lesson, we've introduced the AgentChat module of Autogen, explored its folder structure, and implemented a basic agent-based task-solving system. We've covered the fundamental concepts of agents, their interactions, and how to set up a simple conversation.

In the next lesson, we'll dive deeper into the Agent base class, examining its core methods and attributes, and learn how to create custom agents tailored to specific tasks.

Remember to experiment with the provided example and try the exercise to reinforce your understanding of the AgentChat module. Happy coding!

