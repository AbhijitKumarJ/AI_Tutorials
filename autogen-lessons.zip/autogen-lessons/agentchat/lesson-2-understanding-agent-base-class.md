# Lesson 2: Understanding the Agent Base Class

## Table of Contents
1. [Introduction](#introduction)
2. [The Agent Base Class](#the-agent-base-class)
3. [Core Methods and Attributes](#core-methods-and-attributes)
4. [Creating Custom Agents](#creating-custom-agents)
5. [Project Structure](#project-structure)
6. [Hands-on Example](#hands-on-example)
7. [Exercise](#exercise)
8. [Summary and Next Steps](#summary-and-next-steps)

## Introduction

Welcome to Lesson 2 of our Autogen AgentChat module series. In this lesson, we'll take a deep dive into the Agent base class, which serves as the foundation for all agent types in the Autogen framework. Understanding this base class is crucial for creating custom agents and extending the functionality of existing ones.

We'll examine the core methods and attributes of the Agent class, explore how to create custom agents, and provide hands-on examples to reinforce your understanding.

## The Agent Base Class

The Agent base class is defined in the `agent.py` file within the AgentChat module. It provides the basic structure and interface that all other agent types build upon. Let's take a closer look at its structure:

```python
# Simplified version of the Agent base class

from typing import Any, Dict, List, Optional, Union

class Agent:
    def __init__(self, name: str):
        self.name = name

    def send(
        self,
        message: Union[Dict, str],
        recipient: "Agent",
        request_reply: Optional[bool] = None,
    ) -> None:
        pass

    def receive(
        self,
        message: Union[Dict, str],
        sender: "Agent",
        request_reply: Optional[bool] = None,
    ) -> None:
        pass

    def generate_reply(
        self,
        messages: Optional[List[Dict]] = None,
        sender: Optional["Agent"] = None,
        **kwargs: Any,
    ) -> Union[str, Dict, None]:
        pass
```

This simplified version shows the basic structure of the Agent class. The actual implementation includes additional methods and attributes, but these are the core components we'll focus on.

## Core Methods and Attributes

Let's examine the core methods and attributes of the Agent base class:

1. `__init__(self, name: str)`:
   - The constructor initializes the agent with a name.
   - The `name` attribute is used to identify the agent in multi-agent systems.

2. `send(self, message, recipient, request_reply=None)`:
   - This method is used to send a message to another agent.
   - `message` can be a string or a dictionary containing the message content.
   - `recipient` is the agent object that will receive the message.
   - `request_reply` is an optional boolean indicating whether a reply is expected.

3. `receive(self, message, sender, request_reply=None)`:
   - This method is called when an agent receives a message from another agent.
   - `message` is the received message (string or dictionary).
   - `sender` is the agent object that sent the message.
   - `request_reply` indicates whether the sender is expecting a reply.

4. `generate_reply(self, messages=None, sender=None, **kwargs)`:
   - This method generates a reply based on the received messages.
   - `messages` is an optional list of message dictionaries representing the conversation history.
   - `sender` is the agent that sent the last message.
   - Additional keyword arguments can be passed to customize the reply generation.

These methods provide the basic framework for agent communication and interaction. When creating custom agents, you'll often override these methods to implement specific behaviors.

## Creating Custom Agents

To create a custom agent, you'll typically subclass the Agent base class or one of its more specialized subclasses (like ConversableAgent). Here's a basic example of how to create a custom agent:

```python
from autogen import Agent

class CustomAgent(Agent):
    def __init__(self, name: str, expertise: str):
        super().__init__(name)
        self.expertise = expertise

    def generate_reply(self, messages=None, sender=None, **kwargs):
        if messages:
            last_message = messages[-1]["content"]
            return f"As an expert in {self.expertise}, I suggest: {last_message.upper()}"
        return None

    def receive(self, message, sender, request_reply=None):
        print(f"{self.name} received: {message}")
        if request_reply:
            return self.generate_reply([{"content": message}], sender)
```

This CustomAgent has an additional `expertise` attribute and overrides the `generate_reply` and `receive` methods to implement custom behavior.

## Project Structure

For this lesson, we'll use the following project structure:

```
autogen_tutorial/
├── lesson2_agent_base_class/
│   ├── custom_agent_example.py
│   ├── agent_interaction_example.py
│   ├── config/
│   │   └── oai_config.json
│   └── requirements.txt
└── README.md
```

## Hands-on Example

Let's create two example files to demonstrate the usage of custom agents and their interactions.

First, create `custom_agent_example.py`:

```python
# custom_agent_example.py

from autogen import Agent, ConversableAgent

class EchoAgent(Agent):
    def generate_reply(self, messages=None, sender=None, **kwargs):
        if messages:
            return f"Echo: {messages[-1]['content']}"
        return None

class CapitalizerAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name)
        
    def generate_reply(self, messages=None, sender=None, **kwargs):
        if messages:
            return messages[-1]["content"].upper()
        return None

# Usage
echo_agent = EchoAgent("Echo")
cap_agent = CapitalizerAgent("Capitalizer")

# Test EchoAgent
reply = echo_agent.generate_reply([{"content": "Hello, World!"}])
print(reply)  # Output: Echo: Hello, World!

# Test CapitalizerAgent
reply = cap_agent.generate_reply([{"content": "make me uppercase"}])
print(reply)  # Output: MAKE ME UPPERCASE
```

Now, let's create `agent_interaction_example.py` to demonstrate how agents interact:

```python
# agent_interaction_example.py

from autogen import Agent, UserProxyAgent, ConversableAgent, config_list_from_json

# Load LLM config
config_list = config_list_from_json(env_or_file="config/oai_config.json")

class AnalyzerAgent(ConversableAgent):
    def __init__(self, name):
        super().__init__(name, llm_config={"config_list": config_list})

    def generate_reply(self, messages=None, sender=None, **kwargs):
        if messages:
            last_message = messages[-1]["content"]
            analysis = f"Analysis of '{last_message}':\n"
            analysis += f"- Length: {len(last_message)} characters\n"
            analysis += f"- Words: {len(last_message.split())} words\n"
            analysis += f"- Uppercase: {sum(1 for c in last_message if c.isupper())}\n"
            analysis += f"- Lowercase: {sum(1 for c in last_message if c.islower())}\n"
            return analysis
        return None

# Create agents
user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=0
)

analyzer = AnalyzerAgent(name="Analyzer")

# Start the conversation
user_proxy.initiate_chat(
    analyzer,
    message="Analyze this sentence: The quick brown fox jumps over the lazy dog."
)
```

To run these examples, make sure you have the `requirements.txt` file in the `lesson2_agent_base_class/` directory:

```
pyautogen
```

And update the `config/oai_config.json` file with your OpenAI API configuration:

```json
[
    {
        "model": "gpt-4",
        "api_key": "your_api_key_here"
    }
]
```

To run the examples, follow these steps:

1. Ensure your virtual environment is activated:
   ```
   source autogen_env/bin/activate  # On Windows, use `autogen_env\Scripts\activate`
   ```

2. Install the required packages (if not already installed):
   ```
   pip install -r requirements.txt
   ```

3. Run the scripts:
   ```
   python custom_agent_example.py
   python agent_interaction_example.py
   ```

These examples demonstrate how to create custom agents by subclassing the Agent and ConversableAgent classes, and how to set up interactions between agents.

## Exercise

Now that you've seen examples of custom agents and their interactions, try the following exercise:

1. Create a new agent called `SentimentAnalyzer` that inherits from `ConversableAgent`.
2. Implement the `generate_reply` method to perform a simple sentiment analysis on the input text. You can use a basic approach, such as counting positive and negative words.
3. Integrate the `SentimentAnalyzer` into the `agent_interaction_example.py` script, allowing the user to request sentiment analysis on their input.

Hint: You can use a predefined list of positive and negative words for a simple sentiment analysis approach.

## Summary and Next Steps

In this lesson, we've explored the Agent base class, its core methods and attributes, and how to create custom agents. We've seen practical examples of creating specialized agents and setting up interactions between them.

Key takeaways from this lesson include:
- Understanding the structure and purpose of the Agent base class
- Learning how to override core methods to create custom agent behaviors
- Exploring the interaction between different agent types

In the next lesson, we'll take a deep dive into the ConversableAgent class, which builds upon the Agent base class to provide more advanced conversational capabilities. We'll explore its additional methods and attributes, and learn how to create more sophisticated conversational agents.

Remember to experiment with the provided examples and try the exercise to reinforce your understanding of custom agent creation and interaction. Happy coding!

