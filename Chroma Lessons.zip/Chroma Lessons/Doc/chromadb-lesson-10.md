# Lesson 10: ChromaDB in Production

In this lesson, we'll explore how to effectively use ChromaDB in a production environment. We'll cover setting up a ChromaDB server, using the HttpClient for remote connections, security considerations and best practices, scaling ChromaDB for larger datasets, and monitoring and logging in production environments.

## Table of Contents
1. [Setting up ChromaDB Server](#1-setting-up-chromadb-server)
2. [Using HttpClient for Remote Connections](#2-using-httpclient-for-remote-connections)
3. [Security Considerations and Best Practices](#3-security-considerations-and-best-practices)
4. [Scaling ChromaDB for Larger Datasets](#4-scaling-chromadb-for-larger-datasets)
5. [Monitoring and Logging in Production Environments](#5-monitoring-and-logging-in-production-environments)
6. [Deployment Strategies](#6-deployment-strategies)
7. [Hands-on Exercise](#7-hands-on-exercise)
8. [Summary](#8-summary)
9. [Quiz](#9-quiz)

## 1. Setting up ChromaDB Server

To set up a ChromaDB server for production use, you'll need to run ChromaDB in server mode. Here's how you can do it:

1. First, ensure you have ChromaDB installed:

```bash
pip install chromadb
```

2. Create a configuration file named `config.yaml`:

```yaml
chroma_server:
  host: 0.0.0.0
  port: 8000
  ssl_keyfile: /path/to/key.pem  # Optional: for HTTPS
  ssl_certfile: /path/to/cert.pem  # Optional: for HTTPS

chroma_data:
  persist_directory: /path/to/persist

```

3. Start the ChromaDB server:

```bash
chroma run --path /path/to/persist --config-file config.yaml
```

This will start a ChromaDB server that listens on all network interfaces (0.0.0.0) on port 8000.

## 2. Using HttpClient for Remote Connections

Once your ChromaDB server is running, you can connect to it from other machines using the HttpClient:

```python
import chromadb

client = chromadb.HttpClient(host="your-server-ip", port=8000)

# Now you can use this client to interact with your ChromaDB server
collection = client.create_collection("remote_collection")

# Add some data
collection.add(
    documents=["This is a document in a remote ChromaDB server"],
    metadatas=[{"source": "lesson 10"}],
    ids=["doc1"]
)

# Query the data
results = collection.query(
    query_texts=["remote document"],
    n_results=1
)
print(results)
```

## 3. Security Considerations and Best Practices

When running ChromaDB in production, security should be a top priority. Here are some key considerations and best practices:

1. **Use HTTPS**: Always use SSL/TLS in production. Update your `config.yaml` with `ssl_keyfile` and `ssl_certfile`.

2. **Implement Authentication**: ChromaDB supports different authentication methods. Here's how to set up token-based authentication:

   Update your `config.yaml`:

   ```yaml
   chroma_server:
     host: 0.0.0.0
     port: 8000
     ssl_keyfile: /path/to/key.pem
     ssl_certfile: /path/to/cert.pem
   
   chroma_data:
     persist_directory: /path/to/persist
   
   auth:
     type: token
     token: your-secret-token
   ```

   Then, in your client code:

   ```python
   client = chromadb.HttpClient(
       host="your-server-ip",
       port=8000,
       ssl=True,
       headers={"Authorization": "Bearer your-secret-token"}
   )
   ```

3. **Network Security**: Use firewalls to restrict access to your ChromaDB server. Only allow connections from trusted IP addresses.

4. **Regular Updates**: Keep your ChromaDB installation up to date to benefit from the latest security patches.

5. **Principle of Least Privilege**: Ensure that the ChromaDB process runs with minimal necessary permissions.

## 4. Scaling ChromaDB for Larger Datasets

As your dataset grows, you may need to scale your ChromaDB setup. Here are some strategies:

1. **Vertical Scaling**: Increase the resources (CPU, RAM, SSD) of your ChromaDB server. This is simpler but has limits.

2. **Horizontal Scaling**: ChromaDB doesn't natively support horizontal scaling, but you can implement a sharding strategy at the application level:

   ```python
   import hashlib

   def get_shard(key, num_shards):
       return int(hashlib.md5(key.encode()).hexdigest(), 16) % num_shards

   # Create multiple ChromaDB clients, one for each shard
   clients = [chromadb.HttpClient(host=f"shard-{i}.example.com", port=8000) for i in range(num_shards)]

   def add_to_shard(document, metadata, id):
       shard = get_shard(id, len(clients))
       clients[shard].get_or_create_collection("main").add(
           documents=[document],
           metadatas=[metadata],
           ids=[id]
       )

   def query_all_shards(query_text, n_results):
       results = []
       for client in clients:
           results.extend(client.get_collection("main").query(
               query_texts=[query_text],
               n_results=n_results
           ))
       return sorted(results, key=lambda x: x['distance'])[:n_results]
   ```

3. **Caching**: Implement a caching layer (e.g., Redis) for frequently accessed embeddings or query results.

## 5. Monitoring and Logging in Production Environments

Effective monitoring and logging are crucial for maintaining a healthy ChromaDB production environment:

1. **Prometheus Integration**: ChromaDB exposes metrics that can be scraped by Prometheus. Add this to your `config.yaml`:

   ```yaml
   telemetry:
     type: prometheus
     prometheus:
       port: 9090
   ```

2. **Logging**: ChromaDB uses Python's logging module. You can configure it in your application:

   ```python
   import logging

   logging.basicConfig(level=logging.INFO)
   logger = logging.getLogger("chromadb")
   logger.setLevel(logging.DEBUG)

   # Add a file handler
   file_handler = logging.FileHandler("chromadb.log")
   file_handler.setLevel(logging.DEBUG)
   logger.addHandler(file_handler)
   ```

3. **Health Checks**: Implement regular health checks in your application:

   ```python
   def check_chromadb_health(client):
       try:
           client.heartbeat()
           return True
       except Exception as e:
           logger.error(f"ChromaDB health check failed: {e}")
           return False
   ```

4. **Performance Monitoring**: Keep track of query times and resource usage. You can use the `time` module for basic timing:

   ```python
   import time

   def timed_query(collection, query_text):
       start_time = time.time()
       results = collection.query(query_texts=[query_text], n_results=10)
       end_time = time.time()
       logger.info(f"Query took {end_time - start_time:.2f} seconds")
       return results
   ```

## 6. Deployment Strategies

When deploying ChromaDB to production, consider these strategies:

1. **Containerization**: Use Docker to containerize your ChromaDB server for easier deployment and scaling.

   Example Dockerfile:

   ```dockerfile
   FROM python:3.9

   WORKDIR /app

   RUN pip install chromadb

   COPY config.yaml .

   EXPOSE 8000

   CMD ["chroma", "run", "--config-file", "config.yaml"]
   ```

2. **CI/CD**: Implement a CI/CD pipeline for automated testing and deployment of your ChromaDB setup.

3. **Blue-Green Deployment**: Use this strategy to minimize downtime during updates.

4. **Backup and Disaster Recovery**: Regularly backup your ChromaDB data and have a disaster recovery plan in place.

## 7. Hands-on Exercise

Create a basic production-ready ChromaDB setup:

1. Set up a ChromaDB server with HTTPS and token authentication.
2. Create a client application that connects to this server.
3. Implement basic monitoring and logging in your client application.
4. Create a Docker container for your ChromaDB server.
5. Write a simple health check script that periodically checks the server status.

## 8. Summary

In this lesson, we covered the essential aspects of running ChromaDB in a production environment. We discussed setting up a ChromaDB server, using the HttpClient for remote connections, implementing security best practices, strategies for scaling, monitoring and logging techniques, and deployment considerations. By following these guidelines, you can create a robust, secure, and scalable ChromaDB production environment.

## 9. Quiz

1. What is the main difference between using ChromaDB with PersistentClient and HttpClient?
2. Name three security best practices for running ChromaDB in production.
3. How can you implement basic horizontal scaling with ChromaDB?
4. What are two ways to monitor the health and performance of a ChromaDB server?
5. Why might you use Docker to deploy ChromaDB in production?

Remember, running ChromaDB in production requires careful planning and ongoing maintenance. Always prioritize security, scalability, and reliability in your production setups.

