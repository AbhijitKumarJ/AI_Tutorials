# Lesson 3: Working with Collections in ChromaDB

## 1. Introduction to Collections

Collections in ChromaDB are logical groupings of embeddings, documents, and associated metadata. They provide a way to organize and manage related data efficiently. In this lesson, we'll explore how to create, manage, and work with collections in depth.

## 2. Creating Collections

### Basic Collection Creation

To create a new collection, use the `create_collection` method:

```python
import chromadb

client = chromadb.Client()
collection = client.create_collection(name="my_collection")
```

### Creating Collections with Metadata

You can associate metadata with a collection during creation:

```python
collection = client.create_collection(
    name="movies",
    metadata={"description": "A collection of movie data"}
)
```

### Creating Collections with Custom Embedding Functions

ChromaDB allows you to specify a custom embedding function for a collection:

```python
from chromadb.utils import embedding_functions

openai_ef = embedding_functions.OpenAIEmbeddingFunction(
    api_key="your-api-key",
    model_name="text-embedding-ada-002"
)

collection = client.create_collection(
    name="openai_embeddings",
    embedding_function=openai_ef
)
```

## 3. Listing and Counting Collections

### Listing All Collections

To get a list of all collections:

```python
collections = client.list_collections()
for collection in collections:
    print(f"Collection name: {collection.name}, ID: {collection.id}")
```

### Counting Collections

To get the total number of collections:

```python
count = client.count_collections()
print(f"Total number of collections: {count}")
```

## 4. Modifying Collection Properties

### Changing Collection Name

To change the name of a collection:

```python
collection.modify(name="new_collection_name")
```

### Updating Collection Metadata

To update the metadata of a collection:

```python
collection.modify(metadata={"description": "Updated description"})
```

## 5. Deleting Collections

To delete a collection:

```python
client.delete_collection("collection_name")
```

Be cautious when deleting collections, as this operation is irreversible.

## 6. Understanding Collection Configurations

Collections in ChromaDB can be configured with various parameters to optimize their behavior for specific use cases.

### Specifying Distance Functions

You can specify the distance function used for similarity calculations:

```python
collection = client.create_collection(
    name="cosine_similarity",
    metadata={"hnsw:space": "cosine"}
)
```

Available options for `hnsw:space` are:
- "l2" (Euclidean distance, default)
- "ip" (Inner Product)
- "cosine" (Cosine Similarity)

### Setting Index Parameters

You can fine-tune the HNSW index used by ChromaDB:

```python
collection = client.create_collection(
    name="optimized_collection",
    metadata={
        "hnsw:construction_ef": 100,
        "hnsw:search_ef": 10,
        "hnsw:M": 16
    }
)
```

- `hnsw:construction_ef`: Controls index quality and build time (higher values = better quality, slower build)
- `hnsw:search_ef`: Controls search quality and speed (higher values = more accurate, slower search)
- `hnsw:M`: Controls index size and quality (higher values = better quality, larger index)

## 7. Advanced Collection Operations

### Batch Operations

For improved performance when working with large datasets, use batch operations:

```python
collection.add(
    ids=["id1", "id2", "id3"],
    documents=["doc1", "doc2", "doc3"],
    metadatas=[{"key1": "value1"}, {"key2": "value2"}, {"key3": "value3"}]
)
```

### Upsert Operation

To add new items or update existing ones:

```python
collection.upsert(
    ids=["id1", "id4"],
    documents=["updated doc1", "new doc4"],
    metadatas=[{"key1": "new_value1"}, {"key4": "value4"}]
)
```

### Peek Operation

To quickly inspect the first few items in a collection:

```python
results = collection.peek(limit=5)
print(results)
```

## 8. Working with Multiple Collections

ChromaDB allows you to work with multiple collections simultaneously:

```python
collection1 = client.create_collection("collection1")
collection2 = client.create_collection("collection2")

# Add data to collections
collection1.add(ids=["1", "2"], documents=["doc1", "doc2"])
collection2.add(ids=["3", "4"], documents=["doc3", "doc4"])

# Query across multiple collections
results1 = collection1.query(query_texts=["sample query"], n_results=2)
results2 = collection2.query(query_texts=["sample query"], n_results=2)

# Combine results
combined_results = results1 + results2
```

## 9. Best Practices for Collection Management

1. Use meaningful names and metadata for collections to easily identify their purpose.
2. Organize related data into separate collections for better management and querying efficiency.
3. Be cautious with delete operations, as they are irreversible.
4. Use batch operations for adding or updating large amounts of data.
5. Consider the trade-offs when configuring index parameters for performance optimization.

## Conclusion

In this lesson, we've explored the various aspects of working with collections in ChromaDB. We've covered creation, management, configuration, and advanced operations. Collections are a fundamental concept in ChromaDB, and understanding how to work with them effectively is crucial for building efficient vector search applications.

## Exercise

1. Create a script that demonstrates the following operations:
   - Create two collections: "books" and "movies"
   - Add at least 10 items to each collection, including metadata
   - Modify the metadata of one collection
   - Perform a query on each collection
   - Delete one item from each collection
   - Peek at the remaining items in each collection
   - Delete the "movies" collection

2. Experiment with different distance functions and index parameters. Create collections with different configurations and compare their performance for adding data and querying.

## Additional Resources

- ChromaDB Collection API Documentation: https://docs.trychroma.com/reference/Collection
- "Understanding HNSW for Approximate Nearest Neighbor Search" by PineCone: https://www.pinecone.io/learn/hnsw/
- "Vector Similarity Search: From Basics to Production" by Eugene Yan: https://eugeneyan.com/writing/vector-similarity-search/

