# Lesson 17: Building a Real-world Application with ChromaDB

## Table of Contents
1. Introduction
2. Application Overview: E-commerce Product Recommendation System
3. Setting Up the Project Structure
4. Implementing Core Functionality
5. Building the API Layer
6. Creating a Simple Web Interface
7. Testing and Deployment Considerations
8. Scalability and Maintainability
9. Practical Exercise
10. Summary and Quiz

## 1. Introduction

In this lesson, we'll apply the knowledge gained from previous lessons to build a real-world application using ChromaDB. We'll create an e-commerce product recommendation system that demonstrates how to use ChromaDB in a practical, production-ready context.

## 2. Application Overview: E-commerce Product Recommendation System

Our application will be an e-commerce product recommendation system with the following features:
- Product catalog management (add, update, delete products)
- Semantic search for products
- Personalized product recommendations based on user browsing history
- Similar product recommendations
- API endpoints for integration with an e-commerce platform
- A simple web interface for demonstration purposes

## 3. Setting Up the Project Structure

Let's start by setting up our project structure:

```
ecommerce_recommender/
│
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── database.py
│   ├── models.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── product_service.py
│   │   ├── recommendation_service.py
│   │   └── search_service.py
│   ├── api/
│   │   ├── __init__.py
│   │   └── routes.py
│   └── web/
│       ├── __init__.py
│       └── templates/
│           ├── index.html
│           └── search_results.html
│
├── tests/
│   ├── __init__.py
│   ├── test_product_service.py
│   ├── test_recommendation_service.py
│   └── test_search_service.py
│
├── data/
│   └── sample_products.json
│
├── requirements.txt
├── Dockerfile
└── README.md
```

## 4. Implementing Core Functionality

Let's start by implementing the core functionality of our application:

```python
# app/config.py
import os

CHROMA_PERSIST_DIR = os.environ.get("CHROMA_PERSIST_DIR", "./chroma_db")
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

# app/database.py
import chromadb
from chromadb.config import Settings
from app.config import CHROMA_PERSIST_DIR

def get_chroma_client():
    return chromadb.PersistentClient(path=CHROMA_PERSIST_DIR)

# app/models.py
from pydantic import BaseModel
from typing import List, Optional

class Product(BaseModel):
    id: str
    name: str
    description: str
    category: str
    price: float
    image_url: str

class ProductCreate(BaseModel):
    name: str
    description: str
    category: str
    price: float
    image_url: str

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    price: Optional[float] = None
    image_url: Optional[str] = None

# app/services/product_service.py
from app.database import get_chroma_client
from app.models import Product, ProductCreate, ProductUpdate
from sentence_transformers import SentenceTransformer
from app.config import EMBEDDING_MODEL
import uuid

class ProductService:
    def __init__(self):
        self.client = get_chroma_client()
        self.collection = self.client.get_or_create_collection("products")
        self.model = SentenceTransformer(EMBEDDING_MODEL)

    def create_product(self, product: ProductCreate) -> Product:
        product_id = str(uuid.uuid4())
        embedding = self.model.encode(f"{product.name} {product.description}").tolist()
        
        self.collection.add(
            ids=[product_id],
            embeddings=[embedding],
            metadatas=[product.dict()]
        )
        
        return Product(id=product_id, **product.dict())

    def get_product(self, product_id: str) -> Product:
        result = self.collection.get(ids=[product_id])
        if not result['ids']:
            raise ValueError(f"Product with id {product_id} not found")
        return Product(id=product_id, **result['metadatas'][0])

    def update_product(self, product_id: str, product_update: ProductUpdate) -> Product:
        existing_product = self.get_product(product_id)
        updated_data = existing_product.dict()
        updated_data.update(product_update.dict(exclude_unset=True))
        
        updated_product = Product(**updated_data)
        embedding = self.model.encode(f"{updated_product.name} {updated_product.description}").tolist()
        
        self.collection.update(
            ids=[product_id],
            embeddings=[embedding],
            metadatas=[updated_product.dict()]
        )
        
        return updated_product

    def delete_product(self, product_id: str):
        self.collection.delete(ids=[product_id])

# app/services/search_service.py
from app.database import get_chroma_client
from app.models import Product
from sentence_transformers import SentenceTransformer
from app.config import EMBEDDING_MODEL

class SearchService:
    def __init__(self):
        self.client = get_chroma_client()
        self.collection = self.client.get_or_create_collection("products")
        self.model = SentenceTransformer(EMBEDDING_MODEL)

    def search_products(self, query: str, n_results: int = 10) -> List[Product]:
        query_embedding = self.model.encode(query).tolist()
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=n_results
        )
        
        products = []
        for id, metadata in zip(results['ids'][0], results['metadatas'][0]):
            products.append(Product(id=id, **metadata))
        
        return products

# app/services/recommendation_service.py
from app.database import get_chroma_client
from app.models import Product
from typing import List

class RecommendationService:
    def __init__(self):
        self.client = get_chroma_client()
        self.collection = self.client.get_or_create_collection("products")

    def get_similar_products(self, product_id: str, n_results: int = 5) -> List[Product]:
        results = self.collection.query(
            query_embeddings=self.collection.get(ids=[product_id])['embeddings'],
            n_results=n_results + 1  # Add 1 to exclude the query product itself
        )
        
        similar_products = []
        for id, metadata in zip(results['ids'][0][1:], results['metadatas'][0][1:]):  # Skip the first result (query product)
            similar_products.append(Product(id=id, **metadata))
        
        return similar_products

    def get_personalized_recommendations(self, user_history: List[str], n_results: int = 10) -> List[Product]:
        # For simplicity, we'll just average the embeddings of the user's history
        # In a real-world scenario, you might want to use a more sophisticated approach
        history_embeddings = self.collection.get(ids=user_history)['embeddings']
        avg_embedding = [sum(e) / len(e) for e in zip(*history_embeddings)]
        
        results = self.collection.query(
            query_embeddings=[avg_embedding],
            n_results=n_results
        )
        
        recommendations = []
        for id, metadata in zip(results['ids'][0], results['metadatas'][0]):
            recommendations.append(Product(id=id, **metadata))
        
        return recommendations
```

## 5. Building the API Layer

Now, let's create the API layer using FastAPI:

```python
# app/main.py
from fastapi import FastAPI
from app.api.routes import router

app = FastAPI(title="E-commerce Recommender API")
app.include_router(router)

# app/api/routes.py
from fastapi import APIRouter, HTTPException
from app.models import Product, ProductCreate, ProductUpdate
from app.services.product_service import ProductService
from app.services.search_service import SearchService
from app.services.recommendation_service import RecommendationService
from typing import List

router = APIRouter()
product_service = ProductService()
search_service = SearchService()
recommendation_service = RecommendationService()

@router.post("/products", response_model=Product)
def create_product(product: ProductCreate):
    return product_service.create_product(product)

@router.get("/products/{product_id}", response_model=Product)
def get_product(product_id: str):
    try:
        return product_service.get_product(product_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Product not found")

@router.put("/products/{product_id}", response_model=Product)
def update_product(product_id: str, product_update: ProductUpdate):
    try:
        return product_service.update_product(product_id, product_update)
    except ValueError:
        raise HTTPException(status_code=404, detail="Product not found")

@router.delete("/products/{product_id}")
def delete_product(product_id: str):
    try:
        product_service.delete_product(product_id)
        return {"message": "Product deleted successfully"}
    except ValueError:
        raise HTTPException(status_code=404, detail="Product not found")

@router.get("/search", response_model=List[Product])
def search_products(query: str, n_results: int = 10):
    return search_service.search_products(query, n_results)

@router.get("/recommendations/similar/{product_id}", response_model=List[Product])
def get_similar_products(product_id: str, n_results: int = 5):
    try:
        return recommendation_service.get_similar_products(product_id, n_results)
    except ValueError:
        raise HTTPException(status_code=404, detail="Product not found")

@router.post("/recommendations/personalized", response_model=List[Product])
def get_personalized_recommendations(user_history: List[str], n_results: int = 10):
    return recommendation_service.get_personalized_recommendations(user_history, n_results)
```

## 6. Creating a Simple Web Interface

Let's create a simple web interface to demonstrate our application:

```html
<!-- app/web/templates/index.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-commerce Recommender</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-4xl font-bold mb-8">E-commerce Recommender</h1>
        <div class="mb-8">
            <h2 class="text-2xl font-semibold mb-4">Search Products</h2>
            <form action="/search" method="get" class="flex">
                <input type="text" name="query" placeholder="Search for products..." class="flex-grow px-4 py-2 border rounded-l-md">
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-r-md">Search</button>
            </form>
        </div>
        <div>
            <h2 class="text-2xl font-semibold mb-4">Personalized Recommendations</h2>
            <form action="/recommendations" method="post" class="flex flex-col">
                <textarea name="user_history" placeholder="Enter product IDs (one per line)" class="px-4 py-2 border rounded-md mb-4" rows="5"></textarea>
                <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded-md">Get Recommendations</button>
            </form>
        </div>
    </div>
</body>
</html>

<!-- app/web/templates/search_results.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-4xl font-bold mb-8">Search Results</h1>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {% for product in products %}
            <div class="bg-white rounded-lg shadow-md p-6">
                <img src="{{ product.image_url }}" alt="{{ product.name }}" class="w-full h-48 object-cover mb-4 rounded">
                <h2 class="text-xl font-semibold mb-2">{{ product.name }}</h2>
                <p class="text-gray-600 mb-2">{{ product.description }}</p>
                <p class="text-lg font-bold text-blue-600">${{ product.price }}</p>
                <p class="text-sm text-gray-500">{{ product.category }}</p>
            </div>
            {% endfor %}
        </div>
    </div>
</body>
</html>
```

Now, let's update our `main.py` to include the web interface:

```python
# app/main.py
from fastapi import FastAPI, Request, Form
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from app.api.routes import router
from app.services.search_service import SearchService
from app.services.recommendation_service import RecommendationService

app = FastAPI(title="E-commerce Recommender API")
app.include_router(router)

templates = Jinja2Templates(directory="app/web/templates")
search_service = SearchService()
recommendation_service = RecommendationService()

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
    
@app.get("/search", response_class=HTMLResponse)
async def search(request: Request, query: str):
    products = search_service.search_products(query)
    return templates.TemplateResponse("search_results.html", {"request": request, "products": products})

@app.post("/recommendations", response_class=HTMLResponse)
async def recommendations(request: Request, user_history: str = Form(...)):
    product_ids = [id.strip() for id in user_history.split('\n') if id.strip()]
    recommendations = recommendation_service.get_personalized_recommendations(product_ids)
    return templates.TemplateResponse("search_results.html", {"request": request, "products": recommendations})
```

## 7. Testing and Deployment Considerations

### Testing

Let's create some basic tests for our services:

```python
# tests/test_product_service.py
import pytest
from app.services.product_service import ProductService
from app.models import ProductCreate, ProductUpdate

@pytest.fixture
def product_service():
    return ProductService()

def test_create_product(product_service):
    product = ProductCreate(
        name="Test Product",
        description="This is a test product",
        category="Test Category",
        price=9.99,
        image_url="https://example.com/test.jpg"
    )
    created_product = product_service.create_product(product)
    assert created_product.name == "Test Product"
    assert created_product.id is not None

def test_get_product(product_service):
    product = ProductCreate(
        name="Test Product",
        description="This is a test product",
        category="Test Category",
        price=9.99,
        image_url="https://example.com/test.jpg"
    )
    created_product = product_service.create_product(product)
    retrieved_product = product_service.get_product(created_product.id)
    assert retrieved_product.id == created_product.id
    assert retrieved_product.name == created_product.name

def test_update_product(product_service):
    product = ProductCreate(
        name="Test Product",
        description="This is a test product",
        category="Test Category",
        price=9.99,
        image_url="https://example.com/test.jpg"
    )
    created_product = product_service.create_product(product)
    update = ProductUpdate(name="Updated Test Product")
    updated_product = product_service.update_product(created_product.id, update)
    assert updated_product.name == "Updated Test Product"

def test_delete_product(product_service):
    product = ProductCreate(
        name="Test Product",
        description="This is a test product",
        category="Test Category",
        price=9.99,
        image_url="https://example.com/test.jpg"
    )
    created_product = product_service.create_product(product)
    product_service.delete_product(created_product.id)
    with pytest.raises(ValueError):
        product_service.get_product(created_product.id)
```

### Deployment Considerations

For deploying our application, we'll use Docker. Here's a sample Dockerfile:

```dockerfile
# Dockerfile
FROM python:3.9

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

Make sure to include all necessary dependencies in the `requirements.txt` file:

```
fastapi
uvicorn
chromadb
sentence-transformers
pydantic
jinja2
python-multipart
```

To deploy the application:

1. Build the Docker image: `docker build -t ecommerce-recommender .`
2. Run the container: `docker run -p 8000:8000 -v /path/to/chroma_db:/app/chroma_db ecommerce-recommender`

For production deployment, consider using a reverse proxy like Nginx and deploying on a cloud platform like AWS, Google Cloud, or DigitalOcean.

## 8. Scalability and Maintainability

To ensure our application is scalable and maintainable, consider the following:

1. **Database Scaling**: As the product catalog grows, you may need to scale ChromaDB. Consider using ChromaDB's distributed setup for larger datasets.

2. **Caching**: Implement caching for frequently accessed products and search results to reduce the load on ChromaDB.

3. **Asynchronous Processing**: For time-consuming tasks like updating embeddings, consider using background workers (e.g., Celery) to process these tasks asynchronously.

4. **Monitoring and Logging**: Implement comprehensive logging and monitoring to track the performance of your application and quickly identify issues.

5. **API Versioning**: As your API evolves, implement versioning to ensure backward compatibility for existing clients.

6. **Regular Backups**: Implement a backup strategy for your ChromaDB data to prevent data loss.

Here's an example of how you might implement caching:

```python
# app/services/cache.py
from functools import lru_cache
from app.models import Product

class CacheService:
    @lru_cache(maxsize=1000)
    def get_product(self, product_id: str) -> Product:
        # This is a placeholder. In a real application, you'd fetch the product from the database here.
        pass

    @lru_cache(maxsize=100)
    def get_popular_products(self, limit: int = 10) -> List[Product]:
        # This is a placeholder. In a real application, you'd fetch popular products here.
        pass

cache_service = CacheService()

# Usage in product_service.py
from app.services.cache import cache_service

class ProductService:
    # ...

    def get_product(self, product_id: str) -> Product:
        cached_product = cache_service.get_product(product_id)
        if cached_product:
            return cached_product
        
        # If not in cache, fetch from ChromaDB and update cache
        product = super().get_product(product_id)
        cache_service.get_product.cache_clear()  # Clear the cache before updating
        cache_service.get_product(product_id)  # Update the cache
        return product
```

## 9. Practical Exercise

Extend the e-commerce recommendation system with the following features:

1. Implement user authentication and store user browsing history.
2. Add a feature to generate "trending products" based on recent user interactions.
3. Implement A/B testing for different recommendation algorithms.
4. Create a simple admin interface for managing products and viewing analytics.
5. Implement rate limiting on the API to prevent abuse.

## 10. Summary and Quiz

In this lesson, we've built a real-world e-commerce product recommendation system using ChromaDB. We covered:

- Setting up the project structure
- Implementing core services for product management, search, and recommendations
- Building an API layer with FastAPI
- Creating a simple web interface
- Testing and deployment considerations
- Scalability and maintainability best practices

Quiz:
1. What embedding model did we use for product descriptions, and how was it applied?
2. How did we implement personalized recommendations based on user history?
3. What are some key considerations for deploying the application in a production environment?
4. How can we improve the scalability of our ChromaDB usage as the product catalog grows?
5. Why is caching important in this application, and how did we implement it?

Answers:
1. We used the "sentence-transformers/all-MiniLM-L6-v2" model to create embeddings for product names and descriptions.
2. We averaged the embeddings of the products in the user's history and used this average embedding to query similar products.
3. Key considerations include using Docker for containerization, implementing a reverse proxy, choosing a suitable cloud platform, and ensuring data persistence.
4. We can consider using ChromaDB's distributed setup for larger datasets and implement caching for frequently accessed data.
5. Caching is important to reduce the load on ChromaDB and improve response times. We implemented it using Python's `lru_cache` decorator for product and popular product retrieval.

This lesson has provided a comprehensive example of building a real-world application with ChromaDB. By working through this e-commerce recommendation system, you've gained practical experience in applying ChromaDB to solve complex, real-world problems.
