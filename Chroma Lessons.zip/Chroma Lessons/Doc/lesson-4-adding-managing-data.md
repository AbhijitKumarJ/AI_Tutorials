# Lesson 4: Adding and Managing Data in ChromaDB

## 1. Introduction to Data Management in ChromaDB

Efficient data management is crucial for getting the most out of ChromaDB. In this lesson, we'll explore how to add, update, and delete data in ChromaDB collections, as well as best practices for managing large datasets.

## 2. Understanding Data Components in ChromaDB

Before we dive into operations, let's review the main components of data in ChromaDB:

1. **IDs**: Unique identifiers for each item in a collection.
2. **Embeddings**: Vector representations of your data.
3. **Metadata**: Additional information associated with each item.
4. **Documents**: The original text or data that the embeddings represent.

## 3. Adding Documents and Embeddings to Collections

### Basic Addition

To add data to a collection, use the `add` method:

```python
import chromadb

client = chromadb.Client()
collection = client.create_collection("my_collection")

collection.add(
    ids=["id1", "id2"],
    documents=["This is the first document", "This is the second document"],
    metadatas=[{"source": "book"}, {"source": "article"}]
)
```

### Adding with Custom Embeddings

If you have pre-computed embeddings, you can add them directly:

```python
collection.add(
    ids=["id3", "id4"],
    embeddings=[[1.1, 2.3, 3.2], [4.5, 6.7, 8.9]],
    metadatas=[{"source": "image"}, {"source": "audio"}]
)
```

### Batch Addition

For better performance with large datasets, use batch addition:

```python
collection.add(
    ids=["id5", "id6", "id7", "id8"],
    documents=[
        "Document 5", "Document 6", "Document 7", "Document 8"
    ],
    metadatas=[
        {"key": "value5"}, {"key": "value6"},
        {"key": "value7"}, {"key": "value8"}
    ]
)
```

## 4. Understanding IDs, Embeddings, Metadata, and Documents

- **IDs**: Must be unique within a collection. They are used to identify and retrieve specific items.
- **Embeddings**: Vector representations of your data. If not provided, ChromaDB will generate them using the collection's embedding function.
- **Metadata**: Optional key-value pairs that provide additional information about each item. Useful for filtering and organization.
- **Documents**: The original text or data. If provided, ChromaDB will generate embeddings for them.

## 5. Updating Existing Data

To update existing items in a collection, use the `update` method:

```python
collection.update(
    ids=["id1"],
    documents=["This is the updated first document"],
    metadatas=[{"source": "book", "updated": True}]
)
```

## 6. Upserting Data (Add or Update)

The `upsert` method adds new items or updates existing ones:

```python
collection.upsert(
    ids=["id1", "id9"],
    documents=["Updated document 1", "New document 9"],
    metadatas=[{"source": "book", "updated": True}, {"source": "web"}]
)
```

## 7. Deleting Data from Collections

### Deleting by ID

To delete specific items:

```python
collection.delete(ids=["id1", "id2"])
```

### Deleting with Filters

You can delete items based on metadata filters:

```python
collection.delete(where={"source": "book"})
```

### Deleting with Document Content Filters

Delete items based on document content:

```python
collection.delete(where_document={"$contains": "specific text"})
```

## 8. Batch Operations for Efficiency

When working with large datasets, use batch operations for better performance:

```python
# Batch add
collection.add(
    ids=["batch1", "batch2", "batch3"],
    documents=["Batch doc 1", "Batch doc 2", "Batch doc 3"],
    metadatas=[{"batch": 1}, {"batch": 2}, {"batch": 3}]
)

# Batch update
collection.update(
    ids=["batch1", "batch2"],
    documents=["Updated batch 1", "Updated batch 2"],
    metadatas=[{"batch": 1, "updated": True}, {"batch": 2, "updated": True}]
)

# Batch delete
collection.delete(ids=["batch1", "batch2", "batch3"])
```

## 9. Best Practices for Data Management

1. **Use Meaningful IDs**: Choose IDs that are easy to understand and relate to your data.

2. **Consistent Metadata**: Maintain a consistent schema for your metadata across items.

3. **Batch Operations**: Use batch operations when adding, updating, or deleting multiple items.

4. **Error Handling**: Implement try-except blocks to handle potential errors during data operations.

5. **Regular Maintenance**: Periodically clean up and optimize your collections.

6. **Versioning**: Consider including version information in your metadata for tracking changes.

7. **Backup**: Regularly backup your ChromaDB data, especially before major operations.

## 10. Advanced Data Management Techniques

### Using Where Filters

You can use complex where filters to select specific data:

```python
results = collection.get(
    where={"source": "book", "year": {"$gte": 2000}}
)
```

### Combining Where and Where_Document Filters

Combine metadata and document content filters:

```python
results = collection.get(
    where={"source": "article"},
    where_document={"$contains": "ChromaDB"}
)
```

### Handling Large Datasets

When working with very large datasets, consider:

1. Splitting data into multiple collections
2. Implementing pagination in your queries
3. Using asynchronous operations for better performance

```python
import asyncio
from chromadb.config import Settings

async_client = chromadb.AsyncClient(Settings(allow_reset=True))

async def add_large_dataset(data):
    collection = await async_client.create_collection("large_collection")
    for batch in chunk_data(data, batch_size=1000):
        await collection.add(
            ids=batch['ids'],
            documents=batch['documents'],
            metadatas=batch['metadatas']
        )

asyncio.run(add_large_dataset(large_data))
```

## Conclusion

In this lesson, we've covered the essentials of adding and managing data in ChromaDB. We've explored how to add, update, upsert, and delete data, as well as best practices for efficient data management. Understanding these concepts is crucial for building robust and efficient applications with ChromaDB.

## Exercise

1. Create a script that demonstrates the following operations:
   - Create a collection named "library"
   - Add at least 20 books to the collection, including metadata such as author, publication year, and genre
   - Update the information for 3 books
   - Upsert 5 books (3 existing and 2 new)
   - Delete 2 books by ID
   - Delete all books from a specific author using a where filter
   - Retrieve and print all remaining books in the collection

2. Implement error handling for all operations in your script.

3. Create a function that simulates adding a large dataset (1000+ items) to a collection using batch operations. Measure and print the time taken for this operation.

## Additional Resources

- ChromaDB API Documentation: https://docs.trychroma.com/reference/Collection
- "Effective Data Management in Vector Databases" by Qi Zhao: https://towardsdatascience.com/effective-data-management-in-vector-databases-7cb4b776ef4f
- "Scaling Vector Databases: Lessons Learned" by Adrian Krebs: https://www.pinecone.io/learn/scaling-vector-databases/

