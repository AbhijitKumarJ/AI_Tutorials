# Lesson 7: Embedding Functions in ChromaDB

## Table of Contents
1. Introduction
2. File Structure
3. What are Embedding Functions?
4. Built-in Embedding Functions in ChromaDB
5. Creating Custom Embedding Functions
6. Integrating Popular Embedding Models
   6.1. OpenAI
   6.2. Hugging Face
   6.3. Cohere
7. Best Practices for Choosing and Using Embedding Functions
8. Practical Exercises
9. Summary and Quiz

## 1. Introduction

In this lesson, we'll dive deep into embedding functions in ChromaDB. Embedding functions are crucial for converting text or other data types into vector representations that can be efficiently stored and queried in a vector database. Understanding how to use and create embedding functions is key to getting the most out of ChromaDB.

## 2. File Structure

Let's continue with our project structure, adding a new file for this lesson:

```
chroma_project/
│
├── main.py
├── query_examples.py
├── advanced_query_examples.py
├── embedding_functions_examples.py  # New file for this lesson
├── data/
│   └── sample_documents.txt
│
└── requirements.txt
```

We'll primarily work with `embedding_functions_examples.py` in this lesson.

## 3. What are Embedding Functions?

Embedding functions are algorithms that transform raw data (usually text) into dense vector representations. These vectors capture semantic meaning, allowing for efficient similarity comparisons.

```python
# embedding_functions_examples.py

import chromadb
from chromadb.utils import embedding_functions

# Basic example of how an embedding function works
default_ef = embedding_functions.DefaultEmbeddingFunction()
text = "Hello, world!"
embedding = default_ef([text])

print(f"Embedding for '{text}':")
print(embedding)
```

## 4. Built-in Embedding Functions in ChromaDB

ChromaDB comes with several built-in embedding functions:

```python
# Default embedding function (Sentence Transformers)
default_ef = embedding_functions.DefaultEmbeddingFunction()

# Text embedding function
text_ef = embedding_functions.SentenceTransformerEmbeddingFunction(model_name="all-MiniLM-L6-v2")

# Creating a collection with a specific embedding function
client = chromadb.Client()
collection = client.create_collection(name="my_collection", embedding_function=text_ef)

# Add some documents
collection.add(
    documents=["This is a test document", "Another example text"],
    ids=["doc1", "doc2"]
)

# Query the collection
results = collection.query(
    query_texts=["test document"],
    n_results=1
)

print("Query results:", results)
```

## 5. Creating Custom Embedding Functions

You can create custom embedding functions to suit your specific needs:

```python
from chromadb.api.types import Documents, EmbeddingFunction, Embeddings
import numpy as np

class RandomEmbeddingFunction(EmbeddingFunction):
    def __init__(self, dim=128):
        self.dim = dim

    def __call__(self, texts: Documents) -> Embeddings:
        return [list(np.random.rand(self.dim)) for _ in texts]

# Use the custom embedding function
random_ef = RandomEmbeddingFunction(dim=64)
custom_collection = client.create_collection(name="custom_collection", embedding_function=random_ef)

custom_collection.add(
    documents=["Custom embedding test", "Another custom example"],
    ids=["custom1", "custom2"]
)

custom_results = custom_collection.query(
    query_texts=["custom test"],
    n_results=1
)

print("Custom embedding results:", custom_results)
```

## 6. Integrating Popular Embedding Models

### 6.1. OpenAI

To use OpenAI's embedding models, you'll need to install the `openai` package and have an API key.

```python
import os
from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction

# Set your OpenAI API key
os.environ["OPENAI_API_KEY"] = "your-api-key-here"

openai_ef = OpenAIEmbeddingFunction(
    api_key=os.environ["OPENAI_API_KEY"],
    model_name="text-embedding-ada-002"
)

openai_collection = client.create_collection(name="openai_collection", embedding_function=openai_ef)

openai_collection.add(
    documents=["OpenAI embedding test", "Another OpenAI example"],
    ids=["openai1", "openai2"]
)

openai_results = openai_collection.query(
    query_texts=["OpenAI test"],
    n_results=1
)

print("OpenAI embedding results:", openai_results)
```

### 6.2. Hugging Face

To use Hugging Face models, you'll need to install the `sentence_transformers` package.

```python
from chromadb.utils.embedding_functions import HuggingFaceEmbeddingFunction

huggingface_ef = HuggingFaceEmbeddingFunction(model_name="sentence-transformers/all-MiniLM-L6-v2")

huggingface_collection = client.create_collection(name="huggingface_collection", embedding_function=huggingface_ef)

huggingface_collection.add(
    documents=["Hugging Face embedding test", "Another Hugging Face example"],
    ids=["hf1", "hf2"]
)

huggingface_results = huggingface_collection.query(
    query_texts=["Hugging Face test"],
    n_results=1
)

print("Hugging Face embedding results:", huggingface_results)
```

### 6.3. Cohere

To use Cohere's embedding models, you'll need to install the `cohere` package and have an API key.

```python
from chromadb.utils.embedding_functions import CohereEmbeddingFunction

cohere_ef = CohereEmbeddingFunction(api_key="your-cohere-api-key")

cohere_collection = client.create_collection(name="cohere_collection", embedding_function=cohere_ef)

cohere_collection.add(
    documents=["Cohere embedding test", "Another Cohere example"],
    ids=["cohere1", "cohere2"]
)

cohere_results = cohere_collection.query(
    query_texts=["Cohere test"],
    n_results=1
)

print("Cohere embedding results:", cohere_results)
```

## 7. Best Practices for Choosing and Using Embedding Functions

1. Consider your data: Choose an embedding function that's appropriate for your data type and domain.
2. Evaluate performance: Test different embedding functions to see which performs best for your specific use case.
3. Consistency: Use the same embedding function for both indexing and querying.
4. Dimensionality: Higher-dimensional embeddings can capture more information but require more storage and computation.
5. Speed vs. Quality: Balance between embedding quality and computation speed based on your application's needs.
6. API Costs: Be aware of potential API costs when using cloud-based embedding services.
7. Privacy: Consider data privacy when using third-party embedding services.

## 8. Practical Exercises

1. Create a collection using the default embedding function and another using a custom embedding function. Compare their performance on a set of sample queries.
2. Implement a custom embedding function that combines multiple embedding models (e.g., averaging their outputs).
3. Use different Hugging Face models as embedding functions and compare their performance on a domain-specific dataset.
4. Create a collection using OpenAI embeddings and test its performance on a challenging semantic similarity task.
5. Implement a caching mechanism for your embedding function to improve performance for repeated queries.

## 9. Summary and Quiz

In this lesson, we covered:
- The concept and importance of embedding functions
- Built-in embedding functions in ChromaDB
- Creating custom embedding functions
- Integrating popular embedding models (OpenAI, Hugging Face, Cohere)
- Best practices for choosing and using embedding functions

Quiz:
1. What is the purpose of an embedding function in ChromaDB?
2. How can you create a custom embedding function in ChromaDB?
3. Name three popular embedding model providers discussed in this lesson.
4. Why is it important to use the same embedding function for both indexing and querying?
5. What are some factors to consider when choosing an embedding function for your project?

Answers:
1. An embedding function transforms raw data (usually text) into dense vector representations for efficient storage and similarity comparisons.
2. By creating a class that inherits from `EmbeddingFunction` and implements the `__call__` method.
3. OpenAI, Hugging Face, and Cohere.
4. To ensure consistency in how data is represented, allowing for accurate similarity comparisons.
5. Factors include the type and domain of your data, performance requirements, dimensionality, speed vs. quality trade-offs, API costs, and privacy considerations.

This lesson provides a comprehensive overview of embedding functions in ChromaDB. Practice implementing and using different embedding functions to gain a deeper understanding of their impact on your vector database applications.

