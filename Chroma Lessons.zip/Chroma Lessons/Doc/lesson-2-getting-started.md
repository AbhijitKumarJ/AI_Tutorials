# Lesson 2: Getting Started with ChromaDB

## 1. Installing ChromaDB

ChromaDB can be installed using different package managers and methods. Here are the most common approaches:

### Using pip (recommended for most users)

```bash
pip install chromadb
```

### Using conda

```bash
conda install -c conda-forge chromadb
```

### Using Docker

```bash
docker pull ghcr.io/chroma-core/chroma:latest
docker run -p 8000:8000 ghcr.io/chroma-core/chroma
```

## 2. Basic Concepts

Before we dive into using ChromaDB, let's understand some key concepts:

1. **Clients**: The entry point for interacting with ChromaDB. Different client types are available for various use cases.

2. **Collections**: Logical groupings of embeddings and their associated metadata and documents.

3. **Embeddings**: Vector representations of data, typically used for similarity search and other machine learning tasks.

4. **Documents**: The original text or data that the embeddings represent.

5. **Metadata**: Additional information associated with each embedding or document.

## 3. Creating Your First ChromaDB Client

ChromaDB offers several client types to suit different needs. Let's explore each type:

### EphemeralClient

This client stores data in-memory and is ideal for testing and development.

```python
import chromadb

client = chromadb.EphemeralClient()
```

### PersistentClient

This client stores data on disk, allowing data to persist between sessions.

```python
import chromadb

client = chromadb.PersistentClient(path="/path/to/save/data")
```

### HttpClient

This client connects to a running ChromaDB server, suitable for production deployments.

```python
import chromadb

client = chromadb.HttpClient(host="localhost", port=8000)
```

## 4. Understanding Different Client Types

Let's compare the different client types:

1. **EphemeralClient**:
   - Data is stored in memory
   - Data is lost when the client is closed
   - Fast performance
   - Ideal for testing and rapid prototyping

2. **PersistentClient**:
   - Data is stored on disk
   - Data persists between sessions
   - Slower than EphemeralClient but faster than HttpClient
   - Suitable for local applications and development

3. **HttpClient**:
   - Connects to a remote ChromaDB server
   - Allows multiple clients to connect to the same database
   - Suitable for production deployments
   - Enables separation of database and application logic

## 5. Basic Operations

Now that we have a client, let's perform some basic operations:

### Heartbeat

The heartbeat function checks if the ChromaDB server is alive and returns the current server time.

```python
heartbeat = client.heartbeat()
print(f"Heartbeat: {heartbeat}")
```

### Reset

The reset function clears all data from the database. Use with caution!

```python
reset_result = client.reset()
print(f"Reset result: {reset_result}")
```

### Version Check

You can check the version of ChromaDB you're using:

```python
import chromadb
print(f"ChromaDB version: {chromadb.__version__}")
```

## 6. Creating and Managing Collections

Collections are the primary way to organize data in ChromaDB. Let's create and manage collections:

### Create a Collection

```python
collection = client.create_collection(name="my_collection")
```

### List Collections

```python
collections = client.list_collections()
print(f"Collections: {collections}")
```

### Get or Create a Collection

This method creates a new collection if it doesn't exist, or returns the existing one if it does.

```python
collection = client.get_or_create_collection(name="my_collection")
```

### Delete a Collection

```python
client.delete_collection(name="my_collection")
```

## 7. Adding Data to a Collection

Let's add some data to our collection:

```python
collection.add(
    documents=["This is a document about cats", "This is a document about dogs"],
    metadatas=[{"source": "book"}, {"source": "article"}],
    ids=["doc1", "doc2"]
)
```

## 8. Querying Data

Now that we have data in our collection, let's perform a simple query:

```python
results = collection.query(
    query_texts=["Tell me about pets"],
    n_results=2
)
print(f"Query results: {results}")
```

## Conclusion

In this lesson, we've covered the basics of getting started with ChromaDB. We've learned how to install ChromaDB, create different types of clients, perform basic operations, and work with collections. In the next lesson, we'll dive deeper into working with collections and explore more advanced features of ChromaDB.

## Exercise

1. Create a new Python script named `chroma_basics.py`.
2. In this script, perform the following tasks:
   - Create a PersistentClient
   - Create a new collection named "movies"
   - Add at least 5 movie descriptions to the collection, with appropriate metadata (e.g., genre, year)
   - Perform a query to find movies similar to a given description
   - Print the results of your query

## Additional Resources

- ChromaDB Documentation: https://docs.trychroma.com/
- ChromaDB GitHub Repository: https://github.com/chroma-core/chroma
- "Vector Databases: A Comprehensive Survey" by Jayendra Shinde: https://arxiv.org/abs/2208.00829
