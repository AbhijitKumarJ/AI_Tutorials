# Lesson 13: ChromaDB and Natural Language Processing

In this lesson, we'll explore how to use ChromaDB for various Natural Language Processing (NLP) tasks. We'll cover using ChromaDB for semantic search, building a question-answering system, document similarity and clustering, and implementing a chatbot with ChromaDB as a knowledge base.

## Table of Contents
1. [Using ChromaDB for Semantic Search](#1-using-chromadb-for-semantic-search)
2. [Building a Question-Answering System](#2-building-a-question-answering-system)
3. [Document Similarity and Clustering with ChromaDB](#3-document-similarity-and-clustering-with-chromadb)
4. [Implementing a Chatbot with ChromaDB as Knowledge Base](#4-implementing-a-chatbot-with-chromadb-as-knowledge-base)
5. [Best Practices for NLP with ChromaDB](#5-best-practices-for-nlp-with-chromadb)
6. [Hands-on Exercise](#6-hands-on-exercise)
7. [Summary](#7-summary)
8. [Quiz](#8-quiz)

## 1. Using ChromaDB for Semantic Search

Semantic search goes beyond keyword matching, understanding the intent and contextual meaning of the search query. ChromaDB's vector search capabilities make it ideal for implementing semantic search.

Here's an example of implementing semantic search with ChromaDB and a pre-trained sentence transformer:

```python
import chromadb
from sentence_transformers import SentenceTransformer
import numpy as np

# Initialize ChromaDB
client = chromadb.Client()
collection = client.create_collection("semantic_search")

# Initialize sentence transformer
model = SentenceTransformer('all-MiniLM-L6-v2')

# Sample documents
documents = [
    "The quick brown fox jumps over the lazy dog",
    "A journey of a thousand miles begins with a single step",
    "To be or not to be, that is the question",
    "I think, therefore I am"
]

# Create embeddings and add to ChromaDB
embeddings = model.encode(documents)
collection.add(
    embeddings=embeddings.tolist(),
    documents=documents,
    ids=[f"doc_{i}" for i in range(len(documents))]
)

# Function to perform semantic search
def semantic_search(query, n_results=2):
    query_embedding = model.encode([query])
    results = collection.query(
        query_embeddings=query_embedding.tolist(),
        n_results=n_results
    )
    return results['documents'][0]

# Example usage
search_results = semantic_search("Philosophy quotes")
print("Search results for 'Philosophy quotes':")
for result in search_results:
    print(result)
```

## 2. Building a Question-Answering System

We can use ChromaDB to build a simple question-answering system by combining it with a pre-trained language model. Here's an example using ChromaDB and the Hugging Face Transformers library:

```python
import chromadb
from sentence_transformers import SentenceTransformer
from transformers import pipeline

# Initialize ChromaDB
client = chromadb.Client()
collection = client.create_collection("qa_system")

# Initialize sentence transformer and QA pipeline
embed_model = SentenceTransformer('all-MiniLM-L6-v2')
qa_model = pipeline("question-answering", model="distilbert-base-cased-distilled-squad")

# Sample paragraphs
paragraphs = [
    "The Python programming language was created by Guido van Rossum and first released in 1991. It is known for its simplicity and readability.",
    "Machine learning is a subset of artificial intelligence that focuses on the development of algorithms that can learn from and make predictions or decisions based on data.",
    "Natural Language Processing (NLP) is a field of AI that deals with the interaction between computers and humans using natural language. It combines computational linguistics, machine learning, and deep learning."
]

# Create embeddings and add to ChromaDB
embeddings = embed_model.encode(paragraphs)
collection.add(
    embeddings=embeddings.tolist(),
    documents=paragraphs,
    ids=[f"para_{i}" for i in range(len(paragraphs))]
)

# Function to answer questions
def answer_question(question, n_results=2):
    question_embedding = embed_model.encode([question])
    results = collection.query(
        query_embeddings=question_embedding.tolist(),
        n_results=n_results
    )
    
    context = " ".join(results['documents'][0])
    answer = qa_model(question=question, context=context)
    return answer['answer']

# Example usage
question = "Who created Python?"
answer = answer_question(question)
print(f"Question: {question}")
print(f"Answer: {answer}")
```

## 3. Document Similarity and Clustering with ChromaDB

ChromaDB can be used for document similarity analysis and clustering. Here's an example that combines ChromaDB with K-means clustering:

```python
import chromadb
from sentence_transformers import SentenceTransformer
from sklearn.cluster import KMeans
import numpy as np

# Initialize ChromaDB
client = chromadb.Client()
collection = client.create_collection("document_clustering")

# Initialize sentence transformer
model = SentenceTransformer('all-MiniLM-L6-v2')

# Sample documents
documents = [
    "The cat sits on the mat",
    "Dogs are man's best friend",
    "It's raining cats and dogs",
    "The dog chases the cat",
    "Artificial intelligence is transforming industries",
    "Machine learning algorithms learn from data",
    "Deep learning is a subset of machine learning",
    "Neural networks are inspired by the human brain"
]

# Create embeddings and add to ChromaDB
embeddings = model.encode(documents)
collection.add(
    embeddings=embeddings.tolist(),
    documents=documents,
    ids=[f"doc_{i}" for i in range(len(documents))]
)

# Perform K-means clustering
n_clusters = 2
kmeans = KMeans(n_clusters=n_clusters, random_state=42)
cluster_labels = kmeans.fit_predict(embeddings)

# Function to get similar documents
def get_similar_documents(query, n_results=3):
    query_embedding = model.encode([query])
    results = collection.query(
        query_embeddings=query_embedding.tolist(),
        n_results=n_results
    )
    return results['documents'][0]

# Example usage
print("Clusters:")
for i in range(n_clusters):
    print(f"Cluster {i}:")
    for j, label in enumerate(cluster_labels):
        if label == i:
            print(f"  - {documents[j]}")
    print()

query = "AI and machine learning"
similar_docs = get_similar_documents(query)
print(f"Documents similar to '{query}':")
for doc in similar_docs:
    print(f"  - {doc}")
```

## 4. Implementing a Chatbot with ChromaDB as Knowledge Base

We can use ChromaDB as a knowledge base for a simple chatbot. Here's an example that combines ChromaDB with a pre-trained language model:

```python
import chromadb
from sentence_transformers import SentenceTransformer
from transformers import pipeline, AutoModelForCausalLM, AutoTokenizer

# Initialize ChromaDB
client = chromadb.Client()
collection = client.create_collection("chatbot_kb")

# Initialize sentence transformer and language model
embed_model = SentenceTransformer('all-MiniLM-L6-v2')
model_name = "microsoft/DialoGPT-medium"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)

# Sample knowledge base
knowledge_base = [
    "ChromaDB is a vector database for storing and querying embeddings.",
    "Natural Language Processing involves the interaction between computers and human language.",
    "Machine learning algorithms improve their performance with experience.",
    "Python is a popular programming language for data science and AI.",
    "Deep learning models are based on artificial neural networks with multiple layers."
]

# Create embeddings and add to ChromaDB
embeddings = embed_model.encode(knowledge_base)
collection.add(
    embeddings=embeddings.tolist(),
    documents=knowledge_base,
    ids=[f"kb_{i}" for i in range(len(knowledge_base))]
)

# Function to generate response
def generate_response(user_input, chat_history=""):
    # Retrieve relevant information from knowledge base
    input_embedding = embed_model.encode([user_input])
    results = collection.query(
        query_embeddings=input_embedding.tolist(),
        n_results=2
    )
    context = " ".join(results['documents'][0])
    
    # Prepare input for the language model
    full_input = f"{chat_history}\nHuman: {user_input}\nAI: Based on my knowledge: {context}\nAI:"
    input_ids = tokenizer.encode(full_input, return_tensors="pt")
    
    # Generate response
    output = model.generate(input_ids, max_length=200, num_return_sequences=1, no_repeat_ngram_size=2)
    response = tokenizer.decode(output[0], skip_special_tokens=True)
    
    # Extract only the AI's response
    ai_response = response.split("AI:")[-1].strip()
    return ai_response

# Example conversation
chat_history = ""
while True:
    user_input = input("Human: ")
    if user_input.lower() in ['exit', 'quit', 'bye']:
        print("AI: Goodbye!")
        break
    response = generate_response(user_input, chat_history)
    print(f"AI: {response}")
    chat_history += f"\nHuman: {user_input}\nAI: {response}"
```

## 5. Best Practices for NLP with ChromaDB

1. **Choose appropriate embedding models**: Select embedding models that are suited to your specific NLP task and domain.
2. **Preprocess text data**: Implement consistent text preprocessing (e.g., lowercasing, removing punctuation) before creating embeddings.
3. **Use batching**: When working with large datasets, use batching to efficiently add or query data in ChromaDB.
4. **Implement caching**: Cache frequently used embeddings or query results to improve performance.
5. **Regularly update your knowledge base**: For chatbots or QA systems, regularly update the knowledge base in ChromaDB with new information.
6. **Combine with traditional NLP techniques**: Use ChromaDB in conjunction with other NLP techniques like named entity recognition or sentiment analysis for more comprehensive solutions.
7. **Monitor and evaluate**: Regularly evaluate the performance of your NLP system and monitor ChromaDB's performance metrics.

## 6. Hands-on Exercise

Create a document summarization system using ChromaDB:

1. Collect a dataset of articles or long documents.
2. Split each document into smaller chunks and create embeddings for each chunk.
3. Store the embeddings and text chunks in ChromaDB.
4. Implement a function that, given a long document:
   a. Splits it into chunks and creates embeddings.
   b. Queries ChromaDB to find the most similar existing chunks.
   c. Uses a language model to generate a summary based on the retrieved similar chunks.
5. Evaluate the quality of the generated summaries.

## 7. Summary

In this lesson, we explored various applications of ChromaDB in Natural Language Processing tasks. We implemented semantic search, built a question-answering system, performed document similarity analysis and clustering, and created a simple chatbot using ChromaDB as a knowledge base. These examples demonstrate how ChromaDB's efficient vector storage and similarity search capabilities can enhance various NLP applications, from information retrieval to conversational AI.

## 8. Quiz

1. How does semantic search differ from traditional keyword-based search, and how does ChromaDB facilitate semantic search?
2. In the question-answering system example, what role does ChromaDB play, and how is it combined with the QA model?
3. How can ChromaDB be used for document clustering, and what additional tools or libraries might you need?
4. In the chatbot example, how is ChromaDB used to enhance the chatbot's responses?
5. Name three best practices for using ChromaDB in NLP applications.

Remember, ChromaDB's vector search capabilities make it a powerful tool for many NLP tasks, especially those involving semantic similarity or large-scale text data management. As you develop more complex NLP applications, consider how ChromaDB can be integrated to improve efficiency and performance.

