# Lesson 12: Integration with Machine Learning Pipelines

In this lesson, we'll explore how to integrate ChromaDB into machine learning (ML) pipelines. We'll cover using ChromaDB in ML workflows, integrating with popular ML frameworks, building a simple recommendation system, and using ChromaDB for model feature storage and retrieval.

## Table of Contents
1. [Using ChromaDB in ML Workflows](#1-using-chromadb-in-ml-workflows)
2. [Integrating with Popular ML Frameworks](#2-integrating-with-popular-ml-frameworks)
3. [Building a Simple Recommendation System with ChromaDB](#3-building-a-simple-recommendation-system-with-chromadb)
4. [Using ChromaDB for Model Feature Storage and Retrieval](#4-using-chromadb-for-model-feature-storage-and-retrieval)
5. [Best Practices for ML Integration](#5-best-practices-for-ml-integration)
6. [Hands-on Exercise](#6-hands-on-exercise)
7. [Summary](#7-summary)
8. [Quiz](#8-quiz)

## 1. Using ChromaDB in ML Workflows

ChromaDB can be a powerful tool in various stages of ML workflows:

1. **Data Preparation**: Store and retrieve preprocessed data or embeddings.
2. **Feature Engineering**: Use ChromaDB to store and query complex features.
3. **Model Training**: Efficiently retrieve relevant data for training.
4. **Inference**: Quick similarity search for real-time predictions.

Here's a basic example of using ChromaDB in a ML workflow:

```python
import chromadb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier

# Initialize ChromaDB client
client = chromadb.Client()
collection = client.create_collection("ml_data")

# Assume X and y are your features and labels
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Store training data in ChromaDB
collection.add(
    embeddings=X_train.tolist(),
    metadatas=[{"label": label} for label in y_train],
    ids=[f"train_{i}" for i in range(len(X_train))]
)

# Retrieve data for training
train_data = collection.get(ids=[f"train_{i}" for i in range(len(X_train))])

# Train model
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(train_data['embeddings'])
model = RandomForestClassifier()
model.fit(X_train_scaled, train_data['metadatas']['label'])

# Use model for prediction
X_test_scaled = scaler.transform(X_test)
predictions = model.predict(X_test_scaled)
```

## 2. Integrating with Popular ML Frameworks

ChromaDB can be integrated with popular ML frameworks like TensorFlow and PyTorch. Here are examples for both:

### TensorFlow Integration

```python
import chromadb
import tensorflow as tf

# Initialize ChromaDB
client = chromadb.Client()
collection = client.create_collection("tf_data")

# Assume you have data in X_train and y_train
collection.add(
    embeddings=X_train.tolist(),
    metadatas=[{"label": int(label)} for label in y_train],
    ids=[f"train_{i}" for i in range(len(X_train))]
)

# Create a tf.data.Dataset
def generate_data():
    data = collection.get(ids=[f"train_{i}" for i in range(len(X_train))])
    for embedding, metadata in zip(data['embeddings'], data['metadatas']):
        yield tf.constant(embedding), tf.constant(metadata['label'])

dataset = tf.data.Dataset.from_generator(
    generate_data,
    output_signature=(
        tf.TensorSpec(shape=(X_train.shape[1],), dtype=tf.float32),
        tf.TensorSpec(shape=(), dtype=tf.int32)
    )
)

# Use the dataset in your TensorFlow model
model = tf.keras.Sequential([
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(1, activation='sigmoid')
])

model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
model.fit(dataset.batch(32), epochs=5)
```

### PyTorch Integration

```python
import chromadb
import torch
from torch.utils.data import Dataset, DataLoader

# Initialize ChromaDB
client = chromadb.Client()
collection = client.create_collection("pytorch_data")

# Assume you have data in X_train and y_train
collection.add(
    embeddings=X_train.tolist(),
    metadatas=[{"label": int(label)} for label in y_train],
    ids=[f"train_{i}" for i in range(len(X_train))]
)

# Create a PyTorch Dataset
class ChromaDataset(Dataset):
    def __init__(self, collection, num_samples):
        self.collection = collection
        self.num_samples = num_samples

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        data = self.collection.get(ids=[f"train_{idx}"])
        return torch.tensor(data['embeddings'][0], dtype=torch.float32), torch.tensor(data['metadatas'][0]['label'], dtype=torch.long)

dataset = ChromaDataset(collection, len(X_train))
dataloader = DataLoader(dataset, batch_size=32, shuffle=True)

# Use the dataloader in your PyTorch model
model = torch.nn.Sequential(
    torch.nn.Linear(X_train.shape[1], 64),
    torch.nn.ReLU(),
    torch.nn.Linear(64, 1),
    torch.nn.Sigmoid()
)

criterion = torch.nn.BCELoss()
optimizer = torch.optim.Adam(model.parameters())

for epoch in range(5):
    for inputs, labels in dataloader:
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels.float().unsqueeze(1))
        loss.backward()
        optimizer.step()
```

## 3. Building a Simple Recommendation System with ChromaDB

Let's build a simple content-based recommendation system using ChromaDB:

```python
import chromadb
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

# Initialize ChromaDB
client = chromadb.Client()
collection = client.create_collection("movies")

# Sample movie data
movies = [
    {"id": "1", "title": "The Shawshank Redemption", "genre": "Drama"},
    {"id": "2", "title": "The Godfather", "genre": "Crime, Drama"},
    {"id": "3", "title": "The Dark Knight", "genre": "Action, Crime, Drama"},
    {"id": "4", "title": "12 Angry Men", "genre": "Crime, Drama"},
    {"id": "5", "title": "Schindler's List", "genre": "Biography, Drama, History"}
]

# Create TF-IDF vectors
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform([f"{m['title']} {m['genre']}" for m in movies])

# Add movies to ChromaDB
collection.add(
    embeddings=tfidf_matrix.toarray().tolist(),
    documents=[f"{m['title']} - {m['genre']}" for m in movies],
    metadatas=[{"id": m["id"], "title": m["title"], "genre": m["genre"]} for m in movies],
    ids=[m["id"] for m in movies]
)

# Function to get recommendations
def get_recommendations(movie_id, n=3):
    movie = collection.get(ids=[movie_id])
    results = collection.query(
        query_embeddings=movie['embeddings'],
        n_results=n+1  # +1 because the movie itself will be included
    )
    # Filter out the input movie
    return [r for r in results['metadatas'][0] if r['id'] != movie_id]

# Get recommendations
recommendations = get_recommendations("1")
print("Recommendations for The Shawshank Redemption:")
for movie in recommendations:
    print(f"{movie['title']} - {movie['genre']}")
```

## 4. Using ChromaDB for Model Feature Storage and Retrieval

ChromaDB can be used to efficiently store and retrieve features for ML models:

```python
import chromadb
import numpy as np
from sklearn.preprocessing import StandardScaler

# Initialize ChromaDB
client = chromadb.Client()
feature_collection = client.create_collection("model_features")

# Assume you have a function to extract features
def extract_features(data):
    # This is a placeholder. In reality, this would be your feature extraction logic
    return np.random.rand(len(data), 10)  # 10 features per data point

# Sample data
data = ["sample1", "sample2", "sample3", "sample4", "sample5"]

# Extract and store features
features = extract_features(data)
scaler = StandardScaler()
scaled_features = scaler.fit_transform(features)

feature_collection.add(
    embeddings=scaled_features.tolist(),
    metadatas=[{"original_data": d} for d in data],
    ids=[f"feature_{i}" for i in range(len(data))]
)

# Retrieve features for model training or inference
def get_features(ids):
    results = feature_collection.get(ids=ids)
    return np.array(results['embeddings']), results['metadatas']

# Example usage
train_features, train_metadata = get_features([f"feature_{i}" for i in range(3)])
test_features, test_metadata = get_features([f"feature_{i}" for i in range(3, 5)])

print("Train features shape:", train_features.shape)
print("Test features shape:", test_features.shape)
```

## 5. Best Practices for ML Integration

1. **Consistency**: Ensure consistent preprocessing and feature extraction across training and inference.
2. **Versioning**: Use metadata to version your data and models.
3. **Batching**: Use batching for efficient data retrieval and processing.
4. **Caching**: Implement caching for frequently accessed data.
5. **Monitoring**: Monitor ChromaDB performance in your ML pipeline.

## 6. Hands-on Exercise

Create a text classification pipeline using ChromaDB:

1. Load a text dataset (e.g., news articles with categories).
2. Preprocess the text and create embeddings (use a pre-trained model like BERT).
3. Store the embeddings and metadata in ChromaDB.
4. Implement a k-Nearest Neighbors classifier using ChromaDB for similarity search.
5. Evaluate the classifier's performance.

## 7. Summary

In this lesson, we explored how to integrate ChromaDB into machine learning pipelines. We covered using ChromaDB in various stages of ML workflows, integrating with popular frameworks like TensorFlow and PyTorch, building a simple recommendation system, and using ChromaDB for feature storage and retrieval. By leveraging ChromaDB's efficient similarity search capabilities, you can enhance various aspects of your ML pipelines, from data preparation to model serving.

## 8. Quiz

1. How can ChromaDB be used in the data preparation stage of an ML workflow?
2. What are the key steps to integrate ChromaDB with TensorFlow's `tf.data.Dataset`?
3. In the recommendation system example, how did we create embeddings for the movies?
4. How can ChromaDB be used for efficient feature storage and retrieval?
5. Name three best practices for integrating ChromaDB in ML pipelines.

Remember, integrating ChromaDB into your ML pipelines can significantly improve efficiency, especially for tasks involving similarity search or large-scale feature management. Always consider the specific requirements of your ML task when deciding how to best utilize ChromaDB in your workflow.

