# Lesson 15: Advanced Features and Techniques in ChromaDB

## Table of Contents
1. Introduction
2. Using the ChromaDB CLI
3. Implementing Custom Distance Functions
4. Working with Multiple Collections
5. Handling Versioning in ChromaDB
6. Advanced Filtering Techniques
7. Practical Exercise
8. Summary and Quiz

## File Layout

```
project/
│
├── custom_functions/
│   ├── distance_functions.py
│   └── filters.py
│
├── multi_collection_manager.py
├── version_manager.py
├── advanced_queries.py
├── requirements.txt
└── README.md
```

## 1. Introduction

In this lesson, we'll explore advanced features and techniques in ChromaDB that allow for more sophisticated and powerful use of the database. We'll cover topics such as using the CLI, implementing custom distance functions, managing multiple collections, versioning, and advanced filtering techniques.

## 2. Using the ChromaDB CLI

ChromaDB provides a Command Line Interface (CLI) for performing various operations without writing Python code. This can be useful for quick operations, maintenance tasks, or scripting.

To use the CLI, make sure you have ChromaDB installed:

```bash
pip install chromadb
```

Here are some common CLI commands:

1. Start a Chroma server:
   ```bash
   chroma run --path /path/to/your/persistence/directory
   ```

2. Check the version of ChromaDB:
   ```bash
   chroma version
   ```

3. Reset the database (use with caution):
   ```bash
   chroma reset
   ```

4. List all collections:
   ```bash
   chroma list
   ```

5. Create a new collection:
   ```bash
   chroma create my_collection
   ```

6. Delete a collection:
   ```bash
   chroma delete my_collection
   ```

7. Get information about a collection:
   ```bash
   chroma describe my_collection
   ```

The CLI can be particularly useful for automating tasks or performing quick maintenance operations without the need to write and run Python scripts.

## 3. Implementing Custom Distance Functions

ChromaDB uses distance functions to measure the similarity between embeddings. By default, it uses Euclidean distance (L2 norm). However, you can implement custom distance functions for more specific use cases.

Here's an example of how to implement a custom distance function:

```python
# custom_functions/distance_functions.py
import numpy as np
from chromadb.api.types import EmbeddingFunction, Embeddings

class CustomDistanceFunction(EmbeddingFunction):
    def __init__(self):
        pass

    def __call__(self, input: Embeddings) -> Embeddings:
        return input

    def distance(self, a: Embeddings, b: Embeddings) -> float:
        # Implement your custom distance function here
        # This example uses cosine similarity
        return 1 - np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

# Usage
custom_distance = CustomDistanceFunction()
client = chromadb.Client()
collection = client.create_collection("custom_distance_collection", embedding_function=custom_distance)
```

In this example, we've implemented cosine similarity as our custom distance function. You can modify the `distance` method to implement any distance metric that suits your specific use case.

## 4. Working with Multiple Collections

When working with complex applications, you might need to manage multiple collections. Here's an example of a multi-collection manager:

```python
# multi_collection_manager.py
import chromadb

class MultiCollectionManager:
    def __init__(self):
        self.client = chromadb.Client()
        self.collections = {}

    def create_collection(self, name, **kwargs):
        collection = self.client.create_collection(name, **kwargs)
        self.collections[name] = collection
        return collection

    def get_collection(self, name):
        if name not in self.collections:
            self.collections[name] = self.client.get_collection(name)
        return self.collections[name]

    def delete_collection(self, name):
        if name in self.collections:
            self.client.delete_collection(name)
            del self.collections[name]

    def query_across_collections(self, query_embeddings, n_results=10):
        results = []
        for name, collection in self.collections.items():
            collection_results = collection.query(
                query_embeddings=query_embeddings,
                n_results=n_results
            )
            results.extend([(name, r) for r in collection_results['ids'][0]])
        return sorted(results, key=lambda x: x[1])[:n_results]

# Usage
manager = MultiCollectionManager()
manager.create_collection("images")
manager.create_collection("texts")

# Query across all collections
query_embedding = [0.1, 0.2, 0.3]  # Your query embedding
results = manager.query_across_collections([query_embedding])
```

This `MultiCollectionManager` allows you to create, manage, and query across multiple collections easily.

## 5. Handling Versioning in ChromaDB

ChromaDB doesn't have built-in versioning, but we can implement a simple versioning system on top of it:

```python
# version_manager.py
import chromadb
from datetime import datetime

class VersionManager:
    def __init__(self, collection_name):
        self.client = chromadb.Client()
        self.base_name = collection_name
        self.current_version = self._get_latest_version()

    def _get_latest_version(self):
        collections = self.client.list_collections()
        versions = [c.name.split('_v')[-1] for c in collections if c.name.startswith(self.base_name)]
        return max(map(int, versions)) if versions else 0

    def create_new_version(self):
        self.current_version += 1
        new_collection_name = f"{self.base_name}_v{self.current_version}"
        return self.client.create_collection(new_collection_name)

    def get_current_version(self):
        return self.client.get_collection(f"{self.base_name}_v{self.current_version}")

    def get_version(self, version):
        return self.client.get_collection(f"{self.base_name}_v{version}")

    def list_versions(self):
        collections = self.client.list_collections()
        return [c.name for c in collections if c.name.startswith(self.base_name)]

# Usage
version_manager = VersionManager("my_dataset")
new_version = version_manager.create_new_version()
current_version = version_manager.get_current_version()
all_versions = version_manager.list_versions()
```

This `VersionManager` creates new versions of a collection by appending version numbers to the collection name. It allows you to create new versions, retrieve specific versions, and list all versions of a collection.

## 6. Advanced Filtering Techniques

ChromaDB supports advanced filtering using metadata. Here are some advanced filtering techniques:

```python
# advanced_queries.py
import chromadb

client = chromadb.Client()
collection = client.get_collection("advanced_collection")

# Numeric range queries
results = collection.query(
    query_embeddings=[query_embedding],
    where={"price": {"$gte": 10, "$lte": 50}}
)

# Combining multiple conditions
results = collection.query(
    query_embeddings=[query_embedding],
    where={"$and": [
        {"category": "electronics"},
        {"price": {"$lt": 1000}},
        {"in_stock": True}
    ]}
)

# Full-text search in metadata
results = collection.query(
    query_embeddings=[query_embedding],
    where_document={"$contains": "keyword"}
)

# Negation
results = collection.query(
    query_embeddings=[query_embedding],
    where={"category": {"$ne": "furniture"}}
)

# Nested metadata queries
results = collection.query(
    query_embeddings=[query_embedding],
    where={"specs.color": "red"}
)

# Custom filtering function
def custom_filter(metadata):
    return metadata["price"] / metadata["weight"] < 5

filtered_results = [
    item for item in results
    if custom_filter(item['metadatas'][0])
]
```

These advanced filtering techniques allow you to create complex queries that combine metadata filtering with embedding-based similarity search.

## 7. Practical Exercise

Create a system that demonstrates the advanced features we've covered in this lesson:

1. Implement a custom distance function that combines cosine similarity with a metadata-based boost.
2. Create a version-controlled collection for a hypothetical product catalog.
3. Implement a multi-collection search system that can search across different product categories (e.g., electronics, clothing, books) and versions.
4. Use advanced filtering to find products within a specific price range, with high customer ratings, and containing certain keywords in their descriptions.
5. Create a CLI tool that allows users to perform these operations from the command line.

## 8. Summary and Quiz

In this lesson, we've covered advanced features and techniques in ChromaDB, including:
- Using the ChromaDB CLI for quick operations and maintenance
- Implementing custom distance functions for specialized similarity measurements
- Managing and querying across multiple collections
- Implementing a simple versioning system for ChromaDB collections
- Advanced filtering techniques for complex queries

Quiz:
1. What is the command to start a Chroma server using the CLI?
2. How can you implement a custom distance function in ChromaDB?
3. What is the advantage of using a multi-collection manager?
4. How does the versioning system we implemented work?
5. Give an example of an advanced filtering technique in ChromaDB.

Answers:
1. The command to start a Chroma server is `chroma run --path /path/to/your/persistence/directory`.
2. You can implement a custom distance function by creating a class that inherits from `EmbeddingFunction` and overrides the `distance` method.
3. A multi-collection manager allows for easier management of multiple collections and enables querying across all collections simultaneously.
4. The versioning system works by appending version numbers to collection names and managing these versioned collections.
5. An example of an advanced filtering technique is combining multiple conditions using the `$and` operator in the `where` clause of a query.

This lesson has provided an in-depth look at advanced features and techniques in ChromaDB. Practice with the provided code examples and complete the practical exercise to gain hands-on experience with these advanced concepts.
