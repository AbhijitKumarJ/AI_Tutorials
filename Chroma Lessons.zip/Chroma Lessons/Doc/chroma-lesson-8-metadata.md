# Lesson 8: Working with Metadata in ChromaDB

## Table of Contents
1. Introduction
2. File Structure
3. Designing Effective Metadata Schemas
4. Adding and Updating Metadata
5. Querying Based on Metadata
6. Best Practices for Metadata Management
7. Using Metadata for Advanced Filtering and Organization
8. Practical Exercises
9. Summary and Quiz

## 1. Introduction

In this lesson, we'll explore the powerful metadata capabilities of ChromaDB. Metadata allows you to add structured information to your embeddings, enabling more sophisticated querying, filtering, and organization of your data. Understanding how to effectively use metadata is crucial for building robust and flexible applications with ChromaDB.

## 2. File Structure

Let's continue with our project structure, adding a new file for this lesson:

```
chroma_project/
│
├── main.py
├── query_examples.py
├── advanced_query_examples.py
├── embedding_functions_examples.py
├── metadata_examples.py  # New file for this lesson
├── data/
│   └── sample_documents.txt
│
└── requirements.txt
```

We'll primarily work with `metadata_examples.py` in this lesson.

## 3. Designing Effective Metadata Schemas

When designing metadata schemas, consider the following:
- What additional information about your data is important for your use case?
- How will you want to filter or organize your data?
- What types of queries will you need to support?

Here's an example of a metadata schema for a document management system:

```python
# metadata_examples.py

import chromadb
from chromadb.utils import embedding_functions

client = chromadb.Client()
ef = embedding_functions.DefaultEmbeddingFunction()

# Create a collection with a specific embedding function
collection = client.create_collection(name="document_management", embedding_function=ef)

# Example metadata schema
document_metadata = {
    "title": "Annual Report 2023",
    "author": "John Doe",
    "department": "Finance",
    "date_created": "2023-05-15",
    "document_type": "report",
    "tags": ["financial", "annual", "2023"],
    "version": 1,
    "is_confidential": True
}

# Add a document with metadata
collection.add(
    documents=["This is the annual financial report for the year 2023..."],
    metadatas=[document_metadata],
    ids=["doc1"]
)

print("Document added with metadata:", document_metadata)
```

## 4. Adding and Updating Metadata

You can add metadata when inserting new items or update metadata for existing items:

```python
# Adding multiple items with metadata
collection.add(
    ids=["doc2", "doc3"],
    documents=[
        "Quarterly sales report for Q2 2023...",
        "Employee handbook updated for 2023..."
    ],
    metadatas=[
        {"title": "Q2 Sales Report", "department": "Sales", "document_type": "report"},
        {"title": "Employee Handbook", "department": "HR", "document_type": "guide"}
    ]
)

# Updating metadata for an existing item
collection.update(
    ids=["doc1"],
    metadatas=[{
        "title": "Updated Annual Report 2023",
        "version": 2,
        "last_modified": "2023-06-01"
    }]
)

print("Metadata updated for doc1")
```

## 5. Querying Based on Metadata

ChromaDB allows you to query and filter results based on metadata:

```python
# Simple metadata query
results = collection.query(
    query_texts=["financial report"],
    where={"department": "Finance"},
    include=["documents", "metadatas"]
)

print("Query results filtered by department:", results)

# More complex metadata query
results = collection.query(
    query_texts=["report"],
    where={
        "$and": [
            {"document_type": "report"},
            {"date_created": {"$gte": "2023-01-01"}},
            {"is_confidential": True}
        ]
    },
    include=["documents", "metadatas"]
)

print("Complex query results:", results)
```

## 6. Best Practices for Metadata Management

1. Consistency: Maintain a consistent schema across your documents.
2. Scalability: Design your schema to accommodate future growth and changes.
3. Indexing: Consider which fields will be frequently queried and ensure they're efficiently indexed.
4. Data types: Use appropriate data types for your metadata (e.g., dates as ISO 8601 strings).
5. Nested structures: Use nested structures when it makes sense, but be aware of query complexity.
6. Versioning: Include version information if your documents may be updated over time.
7. Naming conventions: Use clear, consistent naming conventions for your metadata fields.

## 7. Using Metadata for Advanced Filtering and Organization

Metadata can be used for advanced filtering and organization of your data:

```python
# Filtering by multiple criteria
results = collection.get(
    where={
        "$and": [
            {"department": {"$in": ["Finance", "Sales"]}},
            {"document_type": "report"},
            {"date_created": {"$gte": "2023-01-01", "$lt": "2024-01-01"}}
        ]
    },
    include=["documents", "metadatas"]
)

print("Advanced filtering results:", results)

# Organization: Grouping by metadata
def group_by_department(results):
    grouped = {}
    for doc, metadata in zip(results['documents'], results['metadatas']):
        dept = metadata['department']
        if dept not in grouped:
            grouped[dept] = []
        grouped[dept].append((doc, metadata))
    return grouped

all_docs = collection.get(include=["documents", "metadatas"])
grouped_docs = group_by_department(all_docs)

for dept, docs in grouped_docs.items():
    print(f"\nDepartment: {dept}")
    for doc, metadata in docs:
        print(f"- {metadata['title']}")
```

## 8. Practical Exercises

1. Design a metadata schema for a music library. Include fields like artist, album, genre, release date, and user ratings. Implement this schema in a ChromaDB collection.

2. Create a collection of news articles with metadata including source, publication date, author, and categories. Implement a query that finds all articles from a specific source published in the last week.

3. Implement a version control system using metadata. Add multiple versions of a document and use metadata to track changes and retrieve specific versions.

4. Design and implement a tagging system using metadata. Allow for multiple tags per document and create queries that can filter by tag combinations.

5. Create a metadata schema for e-commerce product data. Include fields like price, category, brand, and availability. Implement advanced queries that could be used in a product search feature.

## 9. Summary and Quiz

In this lesson, we covered:
- Designing effective metadata schemas
- Adding and updating metadata in ChromaDB
- Querying based on metadata
- Best practices for metadata management
- Using metadata for advanced filtering and organization

Quiz:
1. What is the purpose of metadata in ChromaDB?
2. How can you update metadata for an existing item in ChromaDB?
3. What is the `where` parameter used for in ChromaDB queries?
4. Name three best practices for metadata management in ChromaDB.
5. How can metadata be used for advanced organization of data in ChromaDB?

Answers:
1. Metadata allows you to add structured information to your embeddings, enabling more sophisticated querying, filtering, and organization of your data.
2. You can use the `update` method of a collection, specifying the `ids` of the items to update and providing new `metadatas`.
3. The `where` parameter is used to filter query results based on metadata conditions.
4. Three best practices are: maintaining consistency in schema, designing for scalability, and using appropriate data types for metadata fields.
5. Metadata can be used for grouping documents by specific fields (e.g., department), implementing tagging systems, and creating hierarchical organization structures.

This lesson provides a comprehensive overview of working with metadata in ChromaDB. Practice designing and implementing metadata schemas, and experiment with different querying and filtering techniques to gain a deeper understanding of how metadata can enhance your ChromaDB applications.

