# Lesson 5: Querying Data in ChromaDB

## Table of Contents
1. Introduction
2. File Structure
3. Basic Querying Techniques
   3.1. Get Method
   3.2. Peek Method
4. Filtering Results with 'Where' Clauses
5. Using 'Where_Document' for Content-Based Filtering
6. Limiting and Offsetting Results
7. Including Specific Data in Query Results
8. Understanding Query Return Types
9. Practical Exercises
10. Summary and Quiz

## 1. Introduction

In this lesson, we'll dive deep into querying data in ChromaDB. Effective querying is crucial for retrieving relevant information from your vector database. We'll cover various techniques, from basic retrieval to advanced filtering and customization of query results.

## 2. File Structure

Before we begin, let's look at a typical file structure for a ChromaDB project:

```
chroma_project/
│
├── main.py
├── query_examples.py
├── data/
│   └── sample_documents.txt
│
└── requirements.txt
```

In this lesson, we'll primarily work with `query_examples.py`.

## 3. Basic Querying Techniques

### 3.1. Get Method

The `get` method is used to retrieve items from a collection based on their IDs or other criteria.

```python
# query_examples.py

import chromadb

client = chromadb.Client()
collection = client.create_collection("my_collection")

# Add some sample data
collection.add(
    ids=["id1", "id2", "id3"],
    documents=["This is a sample document.", "Another example.", "Yet another document."],
    metadatas=[{"source": "web"}, {"source": "book"}, {"source": "article"}]
)

# Get items by ID
result = collection.get(
    ids=["id1", "id3"],
    include=["documents", "metadatas"]
)

print("Get result:", result)
```

### 3.2. Peek Method

The `peek` method allows you to quickly view the first few items in a collection.

```python
# Peek at the first 2 items
peek_result = collection.peek(limit=2)
print("Peek result:", peek_result)
```

## 4. Filtering Results with 'Where' Clauses

The `where` parameter allows you to filter results based on metadata.

```python
# Query with a 'where' clause
where_result = collection.get(
    where={"source": "web"},
    include=["documents", "metadatas"]
)

print("Where clause result:", where_result)
```

You can use various operators in your `where` clause:

```python
# Using different operators
operators_result = collection.get(
    where={
        "source": {"$eq": "book"},  # Equality
        "rating": {"$gt": 3},       # Greater than
        "tags": {"$in": ["fiction", "mystery"]}  # In a list
    },
    include=["documents", "metadatas"]
)

print("Operators result:", operators_result)
```

## 5. Using 'Where_Document' for Content-Based Filtering

The `where_document` parameter allows you to filter based on the content of the documents.

```python
# Query with 'where_document'
content_result = collection.get(
    where_document={"$contains": "sample"},
    include=["documents", "metadatas"]
)

print("Content-based filtering result:", content_result)
```

## 6. Limiting and Offsetting Results

You can use `limit` and `offset` parameters to paginate through results.

```python
# Limit and offset example
paginated_result = collection.get(
    limit=2,
    offset=1,
    include=["documents", "metadatas"]
)

print("Paginated result:", paginated_result)
```

## 7. Including Specific Data in Query Results

The `include` parameter allows you to specify which data to return in the query results.

```python
# Include specific data
custom_include_result = collection.get(
    include=["embeddings", "documents"],
    limit=2
)

print("Custom include result:", custom_include_result)
```

## 8. Understanding Query Return Types

Query methods typically return a dictionary-like object with the following structure:

```python
{
    'ids': List[str],
    'embeddings': Optional[List[List[float]]],
    'documents': Optional[List[str]],
    'metadatas': Optional[List[dict]],
    'distances': Optional[List[float]]  # Only for query method
}
```

It's important to handle these return types appropriately in your code.

## 9. Practical Exercises

1. Create a new collection and add at least 10 items with varied metadata and documents.
2. Write a query that retrieves all items with a specific metadata value.
3. Use the `where_document` parameter to find documents containing a specific word.
4. Implement a paginated query that returns 5 items per page.
5. Write a query that returns only the embeddings and ids of the items.

## 10. Summary and Quiz

In this lesson, we covered:
- Basic querying techniques using `get` and `peek`
- Filtering results with `where` clauses
- Content-based filtering with `where_document`
- Limiting and offsetting results for pagination
- Customizing query results with the `include` parameter
- Understanding query return types

Quiz:
1. What method would you use to quickly view the first few items in a collection?
2. How can you filter results based on metadata in ChromaDB?
3. What parameter allows you to filter based on the content of the documents?
4. How would you implement pagination in your queries?
5. What are the possible values for the `include` parameter in a query?

Answers:
1. The `peek` method
2. Using the `where` parameter
3. The `where_document` parameter
4. Using the `limit` and `offset` parameters
5. "embeddings", "documents", "metadatas", and "distances" (for the query method)

This lesson provides a comprehensive overview of querying data in ChromaDB. Practice these concepts with real data to solidify your understanding. In the next lesson, we'll explore advanced querying and similarity search techniques.

