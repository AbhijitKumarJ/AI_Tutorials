# Lesson 14: Multi-modal Data in ChromaDB

## Table of Contents
1. Introduction to Multi-modal Data
2. Working with Image Embeddings
3. Combining Text and Image Data in ChromaDB
4. Creating a Multi-modal Search System
5. Handling Audio and Video Data in ChromaDB
6. Practical Exercise
7. Summary and Quiz

## File Layout

```
project/
│
├── data/
│   ├── images/
│   │   ├── image1.jpg
│   │   ├── image2.jpg
│   │   └── ...
│   ├── audio/
│   │   ├── audio1.mp3
│   │   ├── audio2.mp3
│   │   └── ...
│   └── video/
│       ├── video1.mp4
│       ├── video2.mp4
│       └── ...
│
├── embeddings/
│   ├── image_embedder.py
│   ├── text_embedder.py
│   ├── audio_embedder.py
│   └── video_embedder.py
│
├── multi_modal_search.py
├── requirements.txt
└── README.md
```

## 1. Introduction to Multi-modal Data

Multi-modal data refers to information that comes from multiple sources or modalities, such as text, images, audio, and video. In the context of vector databases like ChromaDB, working with multi-modal data involves creating and managing embeddings for different types of data within the same system.

By leveraging multi-modal data, we can create more sophisticated and comprehensive search and retrieval systems that can understand and process various types of information simultaneously.

## 2. Working with Image Embeddings

To work with image embeddings in ChromaDB, we need to use a pre-trained model that can convert images into vector representations. For this lesson, we'll use the CLIP (Contrastive Language-Image Pre-Training) model from OpenAI, which can generate embeddings for both images and text.

First, let's set up our image embedder:

```python
# embeddings/image_embedder.py
import torch
from PIL import Image
from torchvision.transforms import Compose, Resize, CenterCrop, ToTensor, Normalize
from transformers import CLIPProcessor, CLIPModel

class ImageEmbedder:
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32").to(self.device)
        self.processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")

    def get_image_embedding(self, image_path):
        image = Image.open(image_path).convert("RGB")
        inputs = self.processor(images=image, return_tensors="pt", padding=True).to(self.device)
        with torch.no_grad():
            image_features = self.model.get_image_features(**inputs)
        return image_features.cpu().numpy().flatten()

# Usage
embedder = ImageEmbedder()
image_embedding = embedder.get_image_embedding("data/images/image1.jpg")
```

Now that we have our image embedder, we can add image embeddings to ChromaDB:

```python
import chromadb
from embeddings.image_embedder import ImageEmbedder

client = chromadb.Client()
collection = client.create_collection("image_collection")

image_embedder = ImageEmbedder()

# Add image embeddings to ChromaDB
image_paths = ["data/images/image1.jpg", "data/images/image2.jpg", "data/images/image3.jpg"]
embeddings = [image_embedder.get_image_embedding(path) for path in image_paths]
metadata = [{"filename": path.split("/")[-1]} for path in image_paths]

collection.add(
    embeddings=embeddings,
    metadatas=metadata,
    ids=[f"img_{i}" for i in range(len(image_paths))]
)
```

## 3. Combining Text and Image Data in ChromaDB

To create a multi-modal system that combines text and image data, we need to ensure that both text and image embeddings are in the same vector space. CLIP is particularly useful for this because it's trained to align text and image embeddings.

Let's create a text embedder using CLIP:

```python
# embeddings/text_embedder.py
import torch
from transformers import CLIPProcessor, CLIPModel

class TextEmbedder:
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32").to(self.device)
        self.processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")

    def get_text_embedding(self, text):
        inputs = self.processor(text=text, return_tensors="pt", padding=True).to(self.device)
        with torch.no_grad():
            text_features = self.model.get_text_features(**inputs)
        return text_features.cpu().numpy().flatten()

# Usage
text_embedder = TextEmbedder()
text_embedding = text_embedder.get_text_embedding("A beautiful sunset over the ocean")
```

Now we can create a collection that contains both image and text embeddings:

```python
import chromadb
from embeddings.image_embedder import ImageEmbedder
from embeddings.text_embedder import TextEmbedder

client = chromadb.Client()
collection = client.create_collection("multi_modal_collection")

image_embedder = ImageEmbedder()
text_embedder = TextEmbedder()

# Add image embeddings
image_paths = ["data/images/image1.jpg", "data/images/image2.jpg"]
image_embeddings = [image_embedder.get_image_embedding(path) for path in image_paths]
image_metadata = [{"type": "image", "filename": path.split("/")[-1]} for path in image_paths]

# Add text embeddings
texts = ["A beautiful sunset over the ocean", "A bustling city street at night"]
text_embeddings = [text_embedder.get_text_embedding(text) for text in texts]
text_metadata = [{"type": "text", "content": text} for text in texts]

# Combine embeddings and metadata
embeddings = image_embeddings + text_embeddings
metadata = image_metadata + text_metadata
ids = [f"img_{i}" for i in range(len(image_paths))] + [f"text_{i}" for i in range(len(texts))]

# Add to collection
collection.add(
    embeddings=embeddings,
    metadatas=metadata,
    ids=ids
)
```

## 4. Creating a Multi-modal Search System

With our multi-modal collection in place, we can now create a search system that can handle both image and text queries:

```python
# multi_modal_search.py
import chromadb
from embeddings.image_embedder import ImageEmbedder
from embeddings.text_embedder import TextEmbedder

class MultiModalSearch:
    def __init__(self):
        self.client = chromadb.Client()
        self.collection = self.client.get_collection("multi_modal_collection")
        self.image_embedder = ImageEmbedder()
        self.text_embedder = TextEmbedder()

    def search(self, query, query_type="text", n_results=5):
        if query_type == "text":
            query_embedding = self.text_embedder.get_text_embedding(query)
        elif query_type == "image":
            query_embedding = self.image_embedder.get_image_embedding(query)
        else:
            raise ValueError("Invalid query type. Use 'text' or 'image'.")

        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=n_results,
            include=["metadatas", "distances"]
        )

        return results

# Usage
searcher = MultiModalSearch()

# Text-based search
text_results = searcher.search("A city at night", query_type="text")
print("Text search results:", text_results)

# Image-based search
image_results = searcher.search("data/images/query_image.jpg", query_type="image")
print("Image search results:", image_results)
```

This multi-modal search system can handle both text and image queries, returning the most similar items from our collection regardless of their original modality.

## 5. Handling Audio and Video Data in ChromaDB

While ChromaDB doesn't directly support audio and video data, we can work with these modalities by extracting relevant features and creating embeddings. Here's a basic approach for audio and video data:

### Audio Data

For audio data, we can use a pre-trained model like YAMNET to extract embeddings:

```python
# embeddings/audio_embedder.py
import tensorflow as tf
import tensorflow_hub as hub
import tensorflow_io as tfio

class AudioEmbedder:
    def __init__(self):
        self.model = hub.load('https://tfhub.dev/google/yamnet/1')

    def get_audio_embedding(self, file_path):
        audio_file = tf.io.read_file(file_path)
        audio_tensor, sample_rate = tf.audio.decode_wav(audio_file)
        audio_samples = tf.squeeze(audio_tensor, axis=-1)
        embeddings = self.model(audio_samples)
        return embeddings['embeddings'].numpy().mean(axis=0)

# Usage
audio_embedder = AudioEmbedder()
audio_embedding = audio_embedder.get_audio_embedding("data/audio/audio1.mp3")
```

### Video Data

For video data, we can extract frames and use our image embedder, or use a specialized video model:

```python
# embeddings/video_embedder.py
import cv2
import numpy as np
from embeddings.image_embedder import ImageEmbedder

class VideoEmbedder:
    def __init__(self):
        self.image_embedder = ImageEmbedder()

    def get_video_embedding(self, file_path, num_frames=5):
        cap = cv2.VideoCapture(file_path)
        frames = []
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        for i in range(num_frames):
            cap.set(cv2.CAP_PROP_POS_FRAMES, i * frame_count // num_frames)
            ret, frame = cap.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frames.append(frame)
        cap.release()
        
        embeddings = [self.image_embedder.get_image_embedding(frame) for frame in frames]
        return np.mean(embeddings, axis=0)

# Usage
video_embedder = VideoEmbedder()
video_embedding = video_embedder.get_video_embedding("data/video/video1.mp4")
```

Now we can add audio and video embeddings to our multi-modal collection:

```python
from embeddings.audio_embedder import AudioEmbedder
from embeddings.video_embedder import VideoEmbedder

audio_embedder = AudioEmbedder()
video_embedder = VideoEmbedder()

# Add audio embeddings
audio_paths = ["data/audio/audio1.mp3", "data/audio/audio2.mp3"]
audio_embeddings = [audio_embedder.get_audio_embedding(path) for path in audio_paths]
audio_metadata = [{"type": "audio", "filename": path.split("/")[-1]} for path in audio_paths]

# Add video embeddings
video_paths = ["data/video/video1.mp4", "data/video/video2.mp4"]
video_embeddings = [video_embedder.get_video_embedding(path) for path in video_paths]
video_metadata = [{"type": "video", "filename": path.split("/")[-1]} for path in video_paths]

# Add to collection
collection.add(
    embeddings=audio_embeddings + video_embeddings,
    metadatas=audio_metadata + video_metadata,
    ids=[f"audio_{i}" for i in range(len(audio_paths))] + [f"video_{i}" for i in range(len(video_paths))]
)
```

## 6. Practical Exercise

Create a multi-modal search engine that can handle queries across text, images, audio, and video. Implement the following features:

1. Add at least 10 items of each type (text, image, audio, video) to your ChromaDB collection.
2. Implement a function that can take a query of any type and return the most similar items across all modalities.
3. Create a simple command-line interface that allows users to input queries and see results.

## 7. Summary and Quiz

In this lesson, we've learned how to work with multi-modal data in ChromaDB, including:
- Creating embeddings for images, text, audio, and video
- Combining different types of data in a single ChromaDB collection
- Implementing a multi-modal search system
- Handling audio and video data through feature extraction

Quiz:
1. What is multi-modal data?
2. How does CLIP help in creating a multi-modal system with text and images?
3. Why do we need to create embeddings for audio and video data?
4. How can we handle video data in our multi-modal system?
5. What are some challenges in creating a multi-modal search system?

Answers:
1. Multi-modal data refers to information from multiple sources or types, such as text, images, audio, and video.
2. CLIP creates aligned embeddings for both text and images in the same vector space, allowing for direct comparison.
3. ChromaDB works with vector embeddings, so we need to convert audio and video data into vector representations.
4. We can extract frames from the video and use an image embedder, or use a specialized video embedding model.
5. Challenges include ensuring compatibility between different embedding types, handling varying dimensions, and balancing the importance of different modalities in search results.

This lesson has provided a comprehensive introduction to working with multi-modal data in ChromaDB. Practice with the provided code examples and complete the practical exercise to solidify your understanding of these concepts.
