# Lesson 6: Advanced Querying and Similarity Search in ChromaDB

## Table of Contents
1. Introduction
2. File Structure
3. Performing Similarity Searches with Query Embeddings
4. Using Query Texts for Text-Based Similarity Search
5. Combining Filters with Similarity Search
6. Understanding and Using Distance Metrics
   6.1. L2 Distance
   6.2. Cosine Similarity
   6.3. Dot Product
7. Adjusting n_results for Different Use Cases
8. Practical Exercises
9. Summary and Quiz

## 1. Introduction

In this lesson, we'll explore advanced querying techniques and similarity search in ChromaDB. These powerful features allow you to find the most relevant data based on semantic similarity, which is crucial for many AI and machine learning applications.

## 2. File Structure

Let's continue with our project structure from the previous lesson:

```
chroma_project/
│
├── main.py
├── query_examples.py
├── advanced_query_examples.py  # New file for this lesson
├── data/
│   └── sample_documents.txt
│
└── requirements.txt
```

We'll primarily work with `advanced_query_examples.py` in this lesson.

## 3. Performing Similarity Searches with Query Embeddings

Similarity search allows you to find the most similar items to a given query embedding.

```python
# advanced_query_examples.py

import chromadb
from chromadb.utils import embedding_functions

# Initialize the client and create a collection
client = chromadb.Client()
ef = embedding_functions.DefaultEmbeddingFunction()
collection = client.create_collection("similarity_search", embedding_function=ef)

# Add some sample data
collection.add(
    ids=["id1", "id2", "id3", "id4"],
    documents=[
        "The quick brown fox jumps over the lazy dog",
        "A journey of a thousand miles begins with a single step",
        "To be or not to be, that is the question",
        "All that glitters is not gold"
    ]
)

# Perform a similarity search with a query embedding
query_embedding = ef(["A cunning canine leaps over a sleepy hound"])
results = collection.query(
    query_embeddings=query_embedding,
    n_results=2,
    include=["documents", "distances"]
)

print("Similarity search results:", results)
```

## 4. Using Query Texts for Text-Based Similarity Search

ChromaDB allows you to perform similarity searches using raw text, which it will automatically convert to embeddings.

```python
# Text-based similarity search
text_results = collection.query(
    query_texts=["A clever animal jumps"],
    n_results=2,
    include=["documents", "distances"]
)

print("Text-based similarity search results:", text_results)
```

## 5. Combining Filters with Similarity Search

You can combine similarity search with metadata filters to refine your results.

```python
# Add metadata to our collection
collection.update(
    ids=["id1", "id2", "id3", "id4"],
    metadatas=[
        {"category": "nature"},
        {"category": "philosophy"},
        {"category": "literature"},
        {"category": "proverb"}
    ]
)

# Combine similarity search with metadata filter
combined_results = collection.query(
    query_texts=["An animal's action"],
    where={"category": "nature"},
    n_results=1,
    include=["documents", "metadatas", "distances"]
)

print("Combined similarity and metadata filter results:", combined_results)
```

## 6. Understanding and Using Distance Metrics

ChromaDB supports different distance metrics for similarity search. The choice of metric can significantly impact your results.

### 6.1. L2 Distance (Euclidean Distance)

L2 distance is the default metric in ChromaDB. It measures the straight-line distance between two points in Euclidean space.

```python
# L2 distance is the default, so no need to specify it
l2_results = collection.query(
    query_texts=["A clever animal jumps"],
    n_results=2,
    include=["documents", "distances"]
)

print("L2 distance results:", l2_results)
```

### 6.2. Cosine Similarity

Cosine similarity measures the cosine of the angle between two vectors. It's often used when the magnitude of the vectors is not important.

```python
# Create a new collection with cosine similarity
cosine_collection = client.create_collection(
    "cosine_similarity",
    embedding_function=ef,
    metadata={"hnsw:space": "cosine"}
)

# Add the same data as before
cosine_collection.add(
    ids=["id1", "id2", "id3", "id4"],
    documents=[
        "The quick brown fox jumps over the lazy dog",
        "A journey of a thousand miles begins with a single step",
        "To be or not to be, that is the question",
        "All that glitters is not gold"
    ]
)

cosine_results = cosine_collection.query(
    query_texts=["A clever animal jumps"],
    n_results=2,
    include=["documents", "distances"]
)

print("Cosine similarity results:", cosine_results)
```

### 6.3. Dot Product

The dot product is another similarity measure, which can be useful in certain scenarios.

```python
# Create a new collection with dot product similarity
dot_collection = client.create_collection(
    "dot_product_similarity",
    embedding_function=ef,
    metadata={"hnsw:space": "ip"}  # "ip" stands for Inner Product
)

# Add the same data as before
dot_collection.add(
    ids=["id1", "id2", "id3", "id4"],
    documents=[
        "The quick brown fox jumps over the lazy dog",
        "A journey of a thousand miles begins with a single step",
        "To be or not to be, that is the question",
        "All that glitters is not gold"
    ]
)

dot_results = dot_collection.query(
    query_texts=["A clever animal jumps"],
    n_results=2,
    include=["documents", "distances"]
)

print("Dot product similarity results:", dot_results)
```

## 7. Adjusting n_results for Different Use Cases

The `n_results` parameter allows you to control how many similar items are returned. This can be adjusted based on your specific use case.

```python
# Adjusting n_results for different scenarios
few_results = collection.query(
    query_texts=["A clever animal jumps"],
    n_results=1,
    include=["documents", "distances"]
)

many_results = collection.query(
    query_texts=["A clever animal jumps"],
    n_results=4,
    include=["documents", "distances"]
)

print("Few results:", few_results)
print("Many results:", many_results)
```

## 8. Practical Exercises

1. Create a new collection with at least 20 diverse text documents.
2. Perform a similarity search using a query embedding and analyze the results.
3. Conduct a text-based similarity search and compare the results with the embedding-based search.
4. Implement a combined search using both similarity and metadata filters.
5. Create three collections using different distance metrics (L2, cosine, dot product) and compare the results for the same query.
6. Experiment with different values of `n_results` and discuss how it affects the relevance of returned items.

## 9. Summary and Quiz

In this lesson, we covered:
- Performing similarity searches with query embeddings
- Using query texts for text-based similarity search
- Combining filters with similarity search
- Understanding and using different distance metrics (L2, cosine, dot product)
- Adjusting n_results for different use cases

Quiz:
1. What's the difference between using query_embeddings and query_texts in a similarity search?
2. How can you combine metadata filtering with similarity search?
3. What are the three distance metrics discussed in this lesson, and when might you use each?
4. How does changing the n_results parameter affect your query results?
5. Why might you choose cosine similarity over L2 distance in some scenarios?

Answers:
1. query_embeddings uses pre-computed embeddings, while query_texts automatically converts the text to embeddings.
2. By using the where parameter along with query_embeddings or query_texts in the query method.
3. L2 (Euclidean), cosine, and dot product. L2 is good for general purpose, cosine when vector magnitude isn't important, and dot product for certain specialized scenarios.
4. It determines how many similar items are returned. Increasing it gives more results but may include less relevant items.
5. Cosine similarity focuses on the direction of vectors, not their magnitude, which can be useful when dealing with documents of varying lengths.

This lesson provides an in-depth look at advanced querying and similarity search in ChromaDB. Practice these concepts with your own datasets to gain a deeper understanding of how they can be applied in real-world scenarios.

