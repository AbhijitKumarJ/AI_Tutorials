# Lesson 8: API Layer in Chroma DB

## 1. Introduction

In this lesson, we'll explore the API layer of Chroma DB. Understanding the API structure is crucial for interacting with Chroma DB effectively, whether you're using it as a client or extending its functionality. We'll cover the API structure, the FastAPI implementation, RESTful endpoints, authentication and authorization, API versioning, error handling, and how to extend the API.

## 2. API Structure Overview

Chroma DB's API is structured into two main components:

1. ClientAPI: For client-side interactions
2. ServerAPI: For server-side operations

Let's examine the basic structure in `chromadb/api/__init__.py`:

```python
from abc import ABC, abstractmethod

class API(ABC):
    @abstractmethod
    def heartbeat(self) -> int:
        pass

class ClientAPI(API):
    @abstractmethod
    def create_collection(self, name: str, metadata: Optional[Dict] = None) -> Collection:
        pass

class ServerAPI(ClientAPI):
    @abstractmethod
    def create_database(self, name: str) -> None:
        pass
```

## 3. FastAPI Implementation

Chroma DB uses FastAPI for its server implementation. Let's look at how this is set up in `chromadb/server/fastapi/__init__.py`:

```python
from fastapi import FastAPI, HTTPException
from chromadb.config import Settings
from chromadb.api import ServerAPI

class ChromaAPIServer:
    def __init__(self, settings: Settings):
        self.app = FastAPI()
        self.api = ServerAPI(settings)
        self.setup_routes()

    def setup_routes(self):
        @self.app.get("/api/v1/heartbeat")
        async def heartbeat():
            return {"heartbeat": self.api.heartbeat()}

        @self.app.post("/api/v1/collections")
        async def create_collection(name: str, metadata: Optional[Dict] = None):
            try:
                collection = self.api.create_collection(name, metadata)
                return {"id": collection.id, "name": collection.name}
            except Exception as e:
                raise HTTPException(status_code=400, detail=str(e))

        # ... other route definitions ...
```

## 4. RESTful Endpoints and Their Functionality

Let's explore some key RESTful endpoints in Chroma DB:

### 4.1 Collections

- GET /api/v1/collections: List all collections
- POST /api/v1/collections: Create a new collection
- GET /api/v1/collections/{collection_id}: Get collection details
- DELETE /api/v1/collections/{collection_id}: Delete a collection

### 4.2 Embeddings

- POST /api/v1/collections/{collection_id}/embeddings: Add embeddings to a collection
- GET /api/v1/collections/{collection_id}/embeddings: Get embeddings from a collection
- DELETE /api/v1/collections/{collection_id}/embeddings: Delete embeddings from a collection

### 4.3 Query

- POST /api/v1/collections/{collection_id}/query: Query embeddings in a collection

Example implementation for querying embeddings:

```python
@self.app.post("/api/v1/collections/{collection_id}/query")
async def query_embeddings(
    collection_id: str,
    query_embeddings: List[List[float]],
    n_results: int = 10,
    where: Optional[Dict] = None
):
    try:
        results = self.api.query(
            collection_id=collection_id,
            query_embeddings=query_embeddings,
            n_results=n_results,
            where=where
        )
        return {"results": results}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
```

## 5. Authentication and Authorization in Chroma DB

Chroma DB supports various authentication and authorization methods. Let's implement a simple JWT-based authentication:

```python
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext

SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_token(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    return username

@self.app.post("/api/v1/collections", dependencies=[Depends(verify_token)])
async def create_collection(name: str, metadata: Optional[Dict] = None):
    # ... implementation ...
```

## 6. API Versioning and Backward Compatibility

API versioning is crucial for maintaining backward compatibility. Chroma DB uses URL versioning:

```python
@self.app.get("/api/v1/collections")
async def get_collections_v1():
    # v1 implementation

@self.app.get("/api/v2/collections")
async def get_collections_v2():
    # v2 implementation with new features
```

To ensure backward compatibility:
1. Never remove or change the behavior of existing endpoints
2. Add new endpoints or parameters for new functionality
3. Use API versioning for breaking changes

## 7. Handling API Errors and Exceptions

Proper error handling is essential for a robust API. Chroma DB uses custom exception classes and FastAPI's error handling:

```python
from fastapi import HTTPException
from chromadb.errors import CollectionAlreadyExistsError, InvalidDimensionError

@self.app.exception_handler(CollectionAlreadyExistsError)
async def collection_exists_exception_handler(request, exc):
    return JSONResponse(
        status_code=409,
        content={"message": str(exc)},
    )

@self.app.exception_handler(InvalidDimensionError)
async def invalid_dimension_exception_handler(request, exc):
    return JSONResponse(
        status_code=400,
        content={"message": str(exc)},
    )

# In your route handlers:
@self.app.post("/api/v1/collections/{collection_id}/embeddings")
async def add_embeddings(collection_id: str, embeddings: List[List[float]]):
    try:
        self.api.add_embeddings(collection_id, embeddings)
    except InvalidDimensionError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal server error")
```

## 8. Extending the API with Custom Endpoints

To extend Chroma DB's API with custom functionality, you can add new endpoints to the FastAPI app:

```python
class CustomChromaAPIServer(ChromaAPIServer):
    def setup_routes(self):
        super().setup_routes()  # Call the parent class's setup_routes

        @self.app.get("/api/v1/custom/stats")
        async def get_custom_stats():
            # Implement your custom stats logic here
            return {"total_embeddings": self.api.get_total_embeddings_count()}

        @self.app.post("/api/v1/custom/process")
        async def custom_process(data: Dict):
            # Implement your custom processing logic here
            result = self.api.custom_process(data)
            return {"result": result}
```

## 9. API Documentation

Chroma DB uses FastAPI's built-in Swagger UI for API documentation. To enable it:

```python
from fastapi import FastAPI
from fastapi.openapi.docs import get_swagger_ui_html

class ChromaAPIServer:
    def __init__(self, settings: Settings):
        self.app = FastAPI(
            title="Chroma DB API",
            description="API for interacting with Chroma DB",
            version="1.0.0",
            docs_url=None,
            redoc_url=None,
        )
        
        @self.app.get("/docs", include_in_schema=False)
        async def custom_swagger_ui_html():
            return get_swagger_ui_html(
                openapi_url="/openapi.json",
                title="Chroma DB API Documentation",
            )
```

## 10. Testing the API

It's crucial to thoroughly test the API. Here's an example using pytest and FastAPI's TestClient:

```python
from fastapi.testclient import TestClient
import pytest

@pytest.fixture
def client():
    server = ChromaAPIServer(Settings())
    return TestClient(server.app)

def test_heartbeat(client):
    response = client.get("/api/v1/heartbeat")
    assert response.status_code == 200
    assert "heartbeat" in response.json()

def test_create_collection(client):
    response = client.post("/api/v1/collections", json={"name": "test_collection"})
    assert response.status_code == 200
    assert "id" in response.json()
    assert "name" in response.json()
    assert response.json()["name"] == "test_collection"
```

## 11. Practical Exercises

1. Implement a new API endpoint for bulk operations (e.g., bulk delete embeddings).
2. Add rate limiting to the API to prevent abuse.
3. Implement a custom authentication method (e.g., API key-based authentication).
4. Create a new API version (v2) with a breaking change and ensure backward compatibility.
5. Write comprehensive tests for all API endpoints, including error cases.

## 12. Conclusion

Understanding and effectively working with Chroma DB's API layer is crucial for building applications that leverage its vector database capabilities. The FastAPI implementation provides a solid foundation for creating a scalable and efficient API. In the next lesson, we'll explore segment management in Chroma DB, which is crucial for understanding how data is organized and accessed at a lower level.

