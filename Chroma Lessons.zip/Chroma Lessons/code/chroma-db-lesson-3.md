# Lesson 3: Project Structure

## 1. Overview of the Project Directory

Let's start by examining the high-level structure of the Chroma DB project:

```
chroma/
├── chromadb/
│   ├── api/
│   ├── auth/
│   ├── cli/
│   ├── config/
│   ├── db/
│   ├── ingest/
│   ├── migrations/
│   ├── segment/
│   ├── server/
│   ├── telemetry/
│   ├── test/
│   └── utils/
├── docs/
├── examples/
├── docker/
├── tests/
├── .github/
├── .gitignore
├── LICENSE
├── README.md
└── setup.py
```

This structure follows a typical Python project layout, with the main package `chromadb` containing various subpackages and modules.

## 2. Understanding the Main Components

Let's dive into the main components of the Chroma DB project:

### 2.1 api/

The `api/` directory contains the core API interfaces and implementations for Chroma DB. Key files include:

- `types.py`: Defines the main data types used throughout the project.
- `client.py`: Implements the client-side API.
- `segment.py`: Defines the interface for segment operations.

Example from `api/types.py`:

```python
from typing import Dict, List, Optional, Union

Embedding = List[float]
Embeddings = List[Embedding]
Metadata = Dict[str, Union[str, int, float]]
Metadatas = List[Metadata]
```

### 2.2 config/

This directory handles configuration management for Chroma DB. The main file is `config.py`, which defines the `Settings` class:

```python
from pydantic import BaseSettings

class Settings(BaseSettings):
    chroma_api_impl: str = "chromadb.api.segment.SegmentAPI"
    chroma_db_impl: str = "chromadb.db.duckdb.DuckDB"
    persist_directory: str = "./chroma"
    # ... other settings
```

### 2.3 db/

The `db/` directory contains database-related implementations. It includes:

- `base.py`: Defines the base database interface.
- `duckdb.py`: Implements DuckDB-based storage.
- `sqlite.py`: Implements SQLite-based storage.

### 2.4 segment/

This directory handles the core functionality of Chroma DB's segmentation system. Key files include:

- `impl/`: Contains various segment implementations (e.g., in-memory, persistent).
- `manager.py`: Manages segment operations and lifecycle.

### 2.5 server/

The `server/` directory contains server-side implementations, including:

- `fastapi/`: FastAPI-based server implementation.

### 2.6 utils/

The `utils/` directory contains various utility functions and classes used throughout the project. Notable subpackages include:

- `embedding_functions/`: Implementations of different embedding functions.

Example from `utils/embedding_functions/openai_embedding_function.py`:

```python
from chromadb.api.types import Documents, EmbeddingFunction

class OpenAIEmbeddingFunction(EmbeddingFunction):
    def __init__(self, api_key: str, model_name: str = "text-embedding-ada-002"):
        import openai
        openai.api_key = api_key
        self.model_name = model_name

    def __call__(self, texts: Documents) -> Embeddings:
        # Implementation details...
```

## 3. Exploring the utils Package

The `utils/` package contains various helper functions and classes used throughout Chroma DB. Some key modules include:

- `batch_utils.py`: Functions for handling batched operations.
- `distance_functions.py`: Implementations of distance metrics for embeddings.
- `read_write_lock.py`: A custom read-write lock implementation.

Example from `utils/distance_functions.py`:

```python
import numpy as np

def l2(x: np.ndarray, y: np.ndarray) -> float:
    return np.linalg.norm(x - y)

def cosine(x: np.ndarray, y: np.ndarray) -> float:
    return 1 - np.dot(x, y) / (np.linalg.norm(x) * np.linalg.norm(y))

def ip(x: np.ndarray, y: np.ndarray) -> float:
    return -np.dot(x, y)
```

## 4. Introduction to the Embedding Functions

Embedding functions are a crucial part of Chroma DB, responsible for converting raw data (like text or images) into vector embeddings. These functions are located in `utils/embedding_functions/`.

Some available embedding functions include:

- `openai_embedding_function.py`
- `huggingface_embedding_function.py`
- `sentence_transformer_embedding_function.py`

Users can also create custom embedding functions by implementing the `EmbeddingFunction` interface:

```python
from chromadb.api.types import Documents, Embeddings

class CustomEmbeddingFunction:
    def __call__(self, texts: Documents) -> Embeddings:
        # Custom embedding logic here
        pass
```

## 5. The Role of __init__.py Files in the Project

The `__init__.py` files play a crucial role in defining the package structure and controlling what is exposed to users of the library. Let's look at the main `chromadb/__init__.py` file:

```python
from chromadb.api import Client
from chromadb.config import Settings
from chromadb.api.types import (
    Documents,
    EmbeddingFunction,
    Embeddings,
)

__all__ = [
    "Client",
    "Settings",
    "Documents",
    "EmbeddingFunction",
    "Embeddings",
]
```

This file defines what is available when users import `chromadb`. It allows for a clean and intuitive API, hiding implementation details.

## 6. Understanding the Separation of Concerns in the Codebase

Chroma DB follows a clear separation of concerns in its codebase:

1. **API Layer** (`api/`): Defines the public interface for interacting with Chroma DB.
2. **Storage Layer** (`db/`): Handles data persistence and retrieval.
3. **Segment Management** (`segment/`): Manages the organization and operations on data segments.
4. **Configuration** (`config/`): Handles system-wide settings and configuration.
5. **Utilities** (`utils/`): Provides helper functions and classes used across the project.
6. **Server** (`server/`): Implements the server-side logic for distributed setups.

This separation allows for:
- Easier maintenance and updates
- Flexibility in swapping out implementations (e.g., changing the database backend)
- Clear boundaries between different parts of the system

## 7. How to Navigate the Codebase Effectively

To navigate the Chroma DB codebase effectively:

1. Start with the `api/` directory to understand the public interface.
2. Explore the `types.py` file to familiarize yourself with the core data structures.
3. Look into the `segment/` directory to understand how data is organized and managed.
4. Examine the `db/` directory to see how data is persisted.
5. Check the `utils/` directory for various helper functions and embedding implementations.
6. Refer to the `config/` directory to understand configuration options.

When trying to understand a specific feature or behavior:
1. Start from the API method in `api/client.py` or `api/segment.py`.
2. Follow the method calls to see how they interact with segments and the database.
3. Refer to utility functions and embedding functions as needed.

## Conclusion

In this lesson, we've explored the project structure of Chroma DB, understanding its main components, the role of different directories, and how they interact. We've looked at the separation of concerns in the codebase and discussed strategies for effective navigation.

This understanding of the project structure will be crucial as we dive deeper into specific components and implementations in future lessons. In the next lesson, we'll explore the core data types and models used throughout Chroma DB, which form the foundation of its functionality.

