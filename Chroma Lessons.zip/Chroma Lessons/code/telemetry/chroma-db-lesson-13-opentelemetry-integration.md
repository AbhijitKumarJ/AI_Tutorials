# Lesson 13: OpenTelemetry Integration

## Table of Contents
1. Introduction to OpenTelemetry in Chroma DB
2. File Structure and Organization
3. OpenTelemetryClient Implementation
4. Tracing Methods and Granularity
5. FastAPI Instrumentation
6. gRPC Instrumentation
7. Configuring OpenTelemetry in Chroma DB
8. Custom Span Attributes and Events
9. Exporting OpenTelemetry Data
10. Best Practices for Using OpenTelemetry in Chroma DB
11. Practical Exercises
12. Conclusion and Next Steps

## 1. Introduction to OpenTelemetry in Chroma DB

OpenTelemetry is an observability framework that provides a collection of tools, APIs, and SDKs for generating, collecting, and exporting telemetry data. Chroma DB integrates OpenTelemetry to provide detailed insights into its performance and behavior, complementing its product telemetry system.

Key concepts:
- Distributed tracing
- Metrics collection
- Context propagation
- Instrumentation of FastAPI and gRPC components

## 2. File Structure and Organization

The OpenTelemetry integration in Chroma DB is organized as follows:

```
chromadb/
├── telemetry/
│   ├── opentelemetry/
│   │   ├── __init__.py
│   │   ├── client.py
│   │   ├── fastapi.py
│   │   └── grpc.py
│   └── __init__.py
```

This structure separates the OpenTelemetry client implementation (`client.py`) from specific instrumentations for FastAPI (`fastapi.py`) and gRPC (`grpc.py`).

## 3. OpenTelemetryClient Implementation

The `OpenTelemetryClient` class is the core of Chroma DB's OpenTelemetry integration. Let's examine its implementation:

```python
# chromadb/telemetry/opentelemetry/__init__.py

from enum import Enum
from functools import wraps
from typing import Any, Callable, Dict, Optional, Sequence, Union, TypeVar

from opentelemetry import trace
from opentelemetry.sdk.resources import SERVICE_NAME, Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

from chromadb.config import Component
from chromadb.config import System

class OpenTelemetryGranularity(Enum):
    NONE = "none"
    OPERATION = "operation"
    OPERATION_AND_SEGMENT = "operation_and_segment"
    ALL = "all"

    def __lt__(self, other: Any) -> bool:
        order = [
            OpenTelemetryGranularity.ALL,
            OpenTelemetryGranularity.OPERATION_AND_SEGMENT,
            OpenTelemetryGranularity.OPERATION,
            OpenTelemetryGranularity.NONE,
        ]
        return order.index(self) < order.index(other)

class OpenTelemetryClient(Component):
    def __init__(self, system: System):
        super().__init__(system)
        self._settings = system.settings
        self._tracer_provider = None
        self._tracer = None

    def start(self):
        if not self._settings.chroma_otel_collection_endpoint:
            return

        resource = Resource(attributes={
            SERVICE_NAME: self._settings.chroma_otel_service_name
        })

        self._tracer_provider = TracerProvider(resource=resource)
        span_exporter = OTLPSpanExporter(
            endpoint=self._settings.chroma_otel_collection_endpoint,
            headers=self._settings.chroma_otel_collection_headers,
        )
        span_processor = BatchSpanProcessor(span_exporter)
        self._tracer_provider.add_span_processor(span_processor)
        trace.set_tracer_provider(self._tracer_provider)

        self._tracer = trace.get_tracer(__name__)

    def trace_method(self, name: str, granularity: OpenTelemetryGranularity):
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                if self._tracer is None or granularity < self._settings.chroma_otel_granularity:
                    return func(*args, **kwargs)

                with self._tracer.start_as_current_span(name):
                    return func(*args, **kwargs)
            return wrapper
        return decorator

def add_attributes_to_current_span(
    attributes: Dict[
        str,
        Union[
            str,
            bool,
            float,
            int,
            Sequence[str],
            Sequence[bool],
            Sequence[float],
            Sequence[int],
            None,
        ],
    ]
) -> None:
    if trace.get_tracer_provider() is None:
        return
    span = trace.get_current_span()
    span.set_attributes({k: v for k, v in attributes.items() if v is not None})

```

This implementation provides:
- Initialization of the OpenTelemetry tracer and exporter
- A decorator for tracing methods with configurable granularity
- A function for adding attributes to the current span

## 4. Tracing Methods and Granularity

Chroma DB uses a granularity system to control the level of tracing. The `OpenTelemetryGranularity` enum defines four levels:

1. `NONE`: No tracing
2. `OPERATION`: Trace only high-level operations
3. `OPERATION_AND_SEGMENT`: Trace operations and segment-level activities
4. `ALL`: Trace almost every method call

The `trace_method` decorator uses this granularity to determine whether a method should be traced:

```python
@opentelemetry_client.trace_method("my_method", OpenTelemetryGranularity.OPERATION)
def my_method():
    # Method implementation
    pass
```

## 5. FastAPI Instrumentation

Chroma DB provides instrumentation for FastAPI to automatically generate spans for HTTP requests:

```python
# chromadb/telemetry/opentelemetry/fastapi.py

from typing import List, Optional
from fastapi import FastAPI
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

def instrument_fastapi(app: FastAPI, excluded_urls: Optional[List[str]] = None) -> None:
    FastAPIInstrumentor.instrument_app(
        app, excluded_urls=",".join(excluded_urls) if excluded_urls else None
    )
```

This function can be used to instrument a FastAPI application, optionally excluding specific URLs from tracing.

## 6. gRPC Instrumentation

Chroma DB also provides custom instrumentation for gRPC:

```python
# chromadb/telemetry/opentelemetry/grpc.py

import binascii
import collections
import grpc
from opentelemetry.trace import StatusCode, SpanKind

class OtelInterceptor(
    grpc.UnaryUnaryClientInterceptor,
    grpc.UnaryStreamClientInterceptor,
    grpc.StreamUnaryClientInterceptor,
    grpc.StreamStreamClientInterceptor,
):
    def _intercept_call(self, continuation, client_call_details, request_or_iterator):
        from chromadb.telemetry.opentelemetry import tracer

        if tracer is None:
            return continuation(client_call_details, request_or_iterator)
        with tracer.start_as_current_span(
            f"RPC {client_call_details.method}", kind=SpanKind.CLIENT
        ) as span:
            # Prepare metadata for propagation
            metadata = (
                client_call_details.metadata[:] if client_call_details.metadata else []
            )
            metadata.extend([
                ("chroma-traceid", _encode_trace_id(span.get_span_context().trace_id)),
                ("chroma-spanid", _encode_span_id(span.get_span_context().span_id)),
            ])
            # Update client call details with new metadata
            new_client_details = _ClientCallDetails(
                client_call_details.method,
                client_call_details.timeout,
                tuple(metadata),
                client_call_details.credentials,
            )
            try:
                result = continuation(new_client_details, request_or_iterator)
                if hasattr(result, "details") and result.details():
                    span.set_attribute("rpc.detail", result.details())
                span.set_attribute("rpc.status_code", result.code().name.lower())
                if result.code() != grpc.StatusCode.OK:
                    span.set_status(StatusCode.ERROR, description=str(result.code()))
                return result
            except Exception as e:
                span.set_attribute("rpc.error", str(e))
                span.set_status(StatusCode.ERROR, description=str(e))
                raise

    # Implement interception methods for different RPC types
    # ...
```

This interceptor adds OpenTelemetry tracing to gRPC calls, including propagation of trace context and error handling.

## 7. Configuring OpenTelemetry in Chroma DB

OpenTelemetry in Chroma DB can be configured through environment variables or system settings:

- `CHROMA_OTEL_SERVICE_NAME`: The name of the service for OpenTelemetry tagging
- `CHROMA_OTEL_COLLECTION_ENDPOINT`: The endpoint to send OpenTelemetry data to
- `CHROMA_OTEL_COLLECTION_HEADERS`: Headers to include with OpenTelemetry data
- `CHROMA_OTEL_GRANULARITY`: The tracing granularity level

Example configuration:

```python
import os
os.environ["CHROMA_OTEL_SERVICE_NAME"] = "chroma-db"
os.environ["CHROMA_OTEL_COLLECTION_ENDPOINT"] = "http://otel-collector:4317"
os.environ["CHROMA_OTEL_GRANULARITY"] = "OPERATION_AND_SEGMENT"
```

## 8. Custom Span Attributes and Events

You can add custom attributes and events to spans for more detailed tracing:

```python
from opentelemetry import trace

tracer = trace.get_tracer(__name__)

with tracer.start_as_current_span("custom_operation") as span:
    span.set_attribute("custom.attribute", "value")
    span.add_event("interesting_event", {"event_data": "some data"})
    # Perform the operation
```

## 9. Exporting OpenTelemetry Data

Chroma DB uses the OTLP (OpenTelemetry Protocol) exporter to send trace data. You can configure the exporter to send data to various backends, such as Jaeger, Zipkin, or cloud-based observability platforms.

To visualize the exported data, you can use tools like Jaeger UI or cloud-based observability platforms that support OpenTelemetry.

## 10. Best Practices for Using OpenTelemetry in Chroma DB

1. Use appropriate granularity levels to balance performance and observability.
2. Add custom attributes and events to provide context-specific information.
3. Ensure that sensitive information is not included in span attributes or events.
4. Use sampling strategies to reduce the volume of telemetry data in high-traffic environments.
5. Regularly review and analyze the collected telemetry data to identify performance bottlenecks and issues.

## 11. Practical Exercises

1. Implement a custom span processor that filters out specific types of spans before exporting.
2. Create a middleware for FastAPI that adds custom attributes to spans based on request headers.
3. Implement a custom exporter that sends OpenTelemetry data to a time-series database for long-term storage and analysis.
4. Develop a dashboard that visualizes the collected OpenTelemetry data, focusing on Chroma DB-specific metrics and traces.

## 12. Conclusion and Next Steps

In this lesson, we've explored the OpenTelemetry integration in Chroma DB, including its implementation, configuration, and best practices. Understanding and utilizing this observability framework is crucial for maintaining and optimizing Chroma DB in production environments.

As you continue your Chroma DB journey, consider exploring:
- Advanced OpenTelemetry concepts like baggage and context propagation
- Integration with other observability tools and platforms
- Implementing custom samplers for more granular control over trace data collection
- Using OpenTelemetry metrics in addition to traces for a more comprehensive view of system performance

In the next lesson, we'll dive into advanced topics in Chroma DB, such as distributed setups and scalability considerations.

