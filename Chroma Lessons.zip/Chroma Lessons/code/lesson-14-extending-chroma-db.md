# Lesson 14: Extending Chroma DB

## Introduction

In this lesson, we'll explore how to extend and contribute to the Chroma DB project. We'll cover creating custom components and plugins, extending the API functionality, implementing new embedding functions, best practices for maintaining backward compatibility, documenting extensions and contributions, and the process of submitting pull requests and engaging with the community.

## 1. Creating Custom Components and Plugins

Chroma DB's modular architecture allows for easy extension through custom components and plugins. Let's explore how to create these.

### 1.1 Custom Embedding Functions

One of the most common extensions is creating custom embedding functions. Here's an example of how to create a custom embedding function using the Sentence Transformers library:

```python
from chromadb.api.types import Documents, EmbeddingFunction, Embeddings
from sentence_transformers import SentenceTransformer

class CustomSentenceTransformerEmbeddingFunction(EmbeddingFunction[Documents]):
    def __init__(self, model_name: str):
        self.model = SentenceTransformer(model_name)

    def __call__(self, input: Documents) -> Embeddings:
        return self.model.encode(input).tolist()
```

You can then use this custom embedding function when creating a collection:

```python
from chromadb import Client

client = Client()
custom_ef = CustomSentenceTransformerEmbeddingFunction("all-MiniLM-L6-v2")
collection = client.create_collection("custom_embeddings", embedding_function=custom_ef)
```

### 1.2 Custom Segment Types

For more advanced use cases, you might want to create custom segment types. Here's a skeleton for a custom segment type:

```python
from chromadb.segment import VectorReader
from chromadb.types import Segment, VectorQuery, VectorQueryResult
from typing import Sequence, Optional

class CustomVectorSegment(VectorReader):
    def __init__(self, segment: Segment):
        self._segment = segment
        # Initialize your custom data structures here

    def get_vectors(self, ids: Optional[Sequence[str]] = None) -> Sequence[List[float]]:
        # Implement vector retrieval logic
        pass

    def query_vectors(self, query: VectorQuery) -> Sequence[Sequence[VectorQueryResult]]:
        # Implement vector querying logic
        pass
```

To use this custom segment type, you'd need to modify the `SegmentManager` to create instances of your custom segment type.

## 2. Extending the API Functionality

To extend Chroma DB's API functionality, you can subclass the existing API classes and add new methods or override existing ones.

### 2.1 Extending the Client API

Here's an example of how to extend the Client API with a new method:

```python
from chromadb import Client

class ExtendedClient(Client):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def bulk_delete(self, collection_name: str, ids: List[str]):
        collection = self.get_collection(collection_name)
        for id_batch in self._batch(ids, 1000):
            collection.delete(ids=id_batch)

    @staticmethod
    def _batch(iterable, n):
        l = len(iterable)
        for ndx in range(0, l, n):
            yield iterable[ndx:min(ndx + n, l)]
```

You can then use this extended client in your application:

```python
client = ExtendedClient()
client.bulk_delete("my_collection", ["id1", "id2", "id3", ...])
```

### 2.2 Adding New API Endpoints

If you're working with the server version of Chroma DB, you might want to add new API endpoints. Here's an example of how to add a new endpoint to the FastAPI implementation:

```python
from fastapi import APIRouter
from chromadb.server.fastapi import FastAPI

router = APIRouter()

@router.get("/api/v1/stats")
async def get_stats():
    # Implement stats gathering logic
    return {"total_collections": 10, "total_embeddings": 1000}

class ExtendedFastAPI(FastAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.app.include_router(router)
```

## 3. Implementing New Embedding Functions

We've already seen how to create a custom embedding function, but let's explore a more advanced example that uses a pre-trained BERT model from Hugging Face:

```python
from chromadb.api.types import Documents, EmbeddingFunction, Embeddings
from transformers import AutoTokenizer, AutoModel
import torch

class BERTEmbeddingFunction(EmbeddingFunction[Documents]):
    def __init__(self, model_name: str = "bert-base-uncased"):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name)

    def __call__(self, input: Documents) -> Embeddings:
        # Tokenize the input texts
        encoded_input = self.tokenizer(input, padding=True, truncation=True, return_tensors='pt')
        
        # Compute token embeddings
        with torch.no_grad():
            model_output = self.model(**encoded_input)
        
        # Mean Pooling - Take average of all tokens
        sentence_embeddings = self._mean_pooling(model_output, encoded_input['attention_mask'])
        
        return sentence_embeddings.tolist()

    def _mean_pooling(self, model_output, attention_mask):
        token_embeddings = model_output[0]
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)
```

This embedding function uses a pre-trained BERT model to generate embeddings, which can be more powerful for certain types of text data.

## 4. Best Practices for Maintaining Backward Compatibility

When extending Chroma DB, it's crucial to maintain backward compatibility to ensure existing users' code doesn't break. Here are some best practices:

1. **Add, don't change or remove:** When adding new functionality, create new methods or classes rather than modifying existing ones.

2. **Use default arguments:** If you're adding parameters to existing methods, make them optional with sensible default values.

3. **Deprecate gradually:** If you must change existing functionality, use deprecation warnings to inform users of upcoming changes:

```python
import warnings

def old_method():
    warnings.warn("old_method is deprecated and will be removed in version X.X. Use new_method instead.", DeprecationWarning, stacklevel=2)
    # ... rest of the method
```

4. **Version your API:** Use versioning in your API endpoints to allow for major changes without breaking existing integrations.

5. **Write migration scripts:** Provide scripts to help users migrate from old versions to new versions of your extensions.

## 5. Documenting Extensions and Contributions

Good documentation is crucial for the adoption and maintenance of your extensions. Here are some guidelines:

1. **README:** Provide a clear README file that explains what your extension does, how to install it, and basic usage examples.

2. **Inline Comments:** Use inline comments to explain complex logic or non-obvious decisions in your code.

3. **Docstrings:** Use docstrings to document classes and methods. Follow the Google style guide for consistency:

```python
class MyExtension:
    """A brief description of MyExtension.

    A more detailed description of MyExtension and its purpose.

    Attributes:
        attr1 (int): Description of attr1.
        attr2 (str): Description of attr2.
    """

    def my_method(self, arg1: int, arg2: str) -> bool:
        """A brief description of my_method.

        A more detailed description of my_method and what it does.

        Args:
            arg1 (int): Description of arg1.
            arg2 (str): Description of arg2.

        Returns:
            bool: Description of return value.

        Raises:
            ValueError: Description of when this error is raised.
        """
        # Method implementation
```

4. **API Documentation:** For significant extensions, consider generating API documentation using tools like Sphinx.

5. **Usage Examples:** Provide comprehensive examples of how to use your extension in real-world scenarios.

## 6. Submitting Pull Requests and Engaging with the Community

When you're ready to contribute your extensions back to the Chroma DB project, follow these steps:

1. **Fork the Repository:** Create your own fork of the Chroma DB repository on GitHub.

2. **Create a Branch:** Create a new branch for your feature or bug fix.

3. **Make Your Changes:** Implement your changes, following the project's coding standards and guidelines.

4. **Write Tests:** Add tests for your new functionality to ensure it works as expected and doesn't break existing features.

5. **Update Documentation:** Update relevant documentation, including the main README if necessary.

6. **Commit Your Changes:** Make clear, concise commit messages that explain your changes.

7. **Push to Your Fork:** Push your changes to your fork on GitHub.

8. **Create a Pull Request:** Open a pull request from your fork to the main Chroma DB repository. Provide a clear description of your changes and their purpose.

9. **Engage in Code Review:** Be responsive to feedback and make necessary changes based on the reviewers' comments.

10. **Participate in the Community:** Join discussions on GitHub issues, help other users, and continue to improve your contributions based on community feedback.

## Conclusion

Extending Chroma DB allows you to tailor its functionality to your specific needs and contribute back to the open-source community. By creating custom components, extending the API, implementing new embedding functions, and following best practices for compatibility and documentation, you can significantly enhance Chroma DB's capabilities.

## Exercises

1. Create a custom embedding function that uses a different machine learning model (e.g., Doc2Vec or FastText).

2. Extend the Chroma DB Client API with a method that allows for bulk updates of metadata.

3. Implement a new segment type that uses a different indexing strategy for vector search.

4. Write comprehensive documentation for one of the extensions you created in the previous exercises.

5. Fork the Chroma DB repository, implement a small feature or bug fix, and create a pull request.

Remember, the key to successful extension and contribution is understanding the existing codebase, following established patterns and best practices, and actively engaging with the community. Happy coding!

