# Lesson 2: Python Fundamentals for Chroma DB

## 1. Basic Python Syntax Review

Before diving into Chroma DB specifics, let's review some basic Python syntax that you'll encounter frequently in the codebase:

### Variables and Data Types

```python
# Integer
count = 10

# Float
price = 9.99

# String
name = "Chroma DB"

# Boolean
is_active = True

# List
colors = ["red", "green", "blue"]

# Dictionary
config = {"host": "localhost", "port": 8000}
```

### Control Flow

```python
# If-else statement
if count > 5:
    print("Count is greater than 5")
else:
    print("Count is 5 or less")

# For loop
for color in colors:
    print(color)

# While loop
while count > 0:
    print(count)
    count -= 1
```

### Functions

```python
def greet(name):
    return f"Hello, {name}!"

message = greet("Chroma DB User")
print(message)
```

## 2. Object-Oriented Programming Concepts

Chroma DB makes extensive use of object-oriented programming (OOP). Here are the key OOP concepts you'll need to understand:

### Classes and Objects

```python
class EmbeddingFunction:
    def __init__(self, model_name):
        self.model_name = model_name
    
    def embed(self, text):
        # Embedding logic here
        pass

# Creating an object
ef = EmbeddingFunction("miniLM")
```

### Inheritance

```python
class CustomEmbeddingFunction(EmbeddingFunction):
    def __init__(self, model_name, custom_param):
        super().__init__(model_name)
        self.custom_param = custom_param
    
    def embed(self, text):
        # Custom embedding logic
        pass
```

### Polymorphism

```python
def process_embedding(embedding_function: EmbeddingFunction, text):
    return embedding_function.embed(text)

# Can use different types of EmbeddingFunction
process_embedding(EmbeddingFunction("miniLM"), "Hello")
process_embedding(CustomEmbeddingFunction("custom", "param"), "World")
```

## 3. Type Hinting and Annotations in Python

Type hinting is extensively used in the Chroma DB codebase to improve code readability and catch type-related errors early. Here's how it works:

```python
from typing import List, Dict, Optional

def get_embeddings(texts: List[str]) -> List[List[float]]:
    # Function implementation
    pass

def process_metadata(metadata: Optional[Dict[str, str]] = None) -> None:
    # Function implementation
    pass

class Collection:
    def add(self, 
            ids: List[str],
            embeddings: List[List[float]],
            metadatas: Optional[List[Dict[str, str]]] = None) -> None:
        # Method implementation
        pass
```

In the Chroma DB codebase, you'll often see custom types defined in `chromadb/api/types.py`, such as:

```python
from chromadb.api.types import (
    Documents,
    Embeddings,
    EmbeddingFunction,
    Metadata,
)

def custom_embedding_function(documents: Documents) -> Embeddings:
    # Function implementation
    pass
```

## 4. Working with Modules and Packages

Chroma DB is organized into various modules and packages. Understanding how to work with them is crucial:

```python
# Importing a module
import chromadb

# Importing specific items from a module
from chromadb.config import Settings

# Importing with an alias
import chromadb.api as api

# Relative imports (within the chromadb package)
from .types import Documents, Embeddings
```

## 5. Understanding Asynchronous Programming with asyncio

Chroma DB uses asynchronous programming for improved performance. Here's a basic example:

```python
import asyncio

async def async_embed(text):
    # Simulating an async operation
    await asyncio.sleep(1)
    return [0.1, 0.2, 0.3]  # Mock embedding

async def process_texts(texts):
    tasks = [async_embed(text) for text in texts]
    return await asyncio.gather(*tasks)

# Running the async function
texts = ["Hello", "World", "Chroma DB"]
embeddings = asyncio.run(process_texts(texts))
print(embeddings)
```

In the Chroma DB codebase, you'll see async methods in classes like `AsyncAPI` and `AsyncClientAPI`.

## 6. Error Handling and Exceptions in Python

Proper error handling is crucial in Chroma DB. Here's how it's typically done:

```python
from chromadb.errors import ChromaError, InvalidDimensionError

def add_embedding(embedding):
    try:
        if len(embedding) != 384:  # Assuming 384 is the expected dimension
            raise InvalidDimensionError(f"Expected 384 dimensions, got {len(embedding)}")
        # Add embedding logic here
    except InvalidDimensionError as e:
        print(f"Invalid embedding dimension: {e}")
    except ChromaError as e:
        print(f"A Chroma-specific error occurred: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
```

## 7. Python's Import System and How Chroma DB Uses It

Chroma DB makes use of Python's import system to organize its codebase. Here's an example of how imports are structured in the `__init__.py` file of the main `chromadb` package:

```python
# chromadb/__init__.py

from chromadb.api import Client
from chromadb.api import ClientAPI
from chromadb.config import Settings
from chromadb.errors import ChromaError

__all__ = [
    "Client",
    "ClientAPI",
    "Settings",
    "ChromaError",
]
```

This structure allows users to import directly from `chromadb`:

```python
from chromadb import Client, Settings
```

## 8. Virtual Environments and Package Management

When working with Chroma DB, it's recommended to use virtual environments to manage dependencies. Here's how you can set up a virtual environment for a Chroma DB project:

```bash
# Create a virtual environment
python -m venv chroma_env

# Activate the virtual environment
# On Windows:
chroma_env\Scripts\activate
# On macOS and Linux:
source chroma_env/bin/activate

# Install Chroma DB and its dependencies
pip install chromadb

# When you're done, you can deactivate the virtual environment
deactivate
```

For package management, Chroma DB uses `setup.py` and `requirements.txt`. Here's a snippet from Chroma DB's `setup.py`:

```python
from setuptools import setup, find_packages

setup(
    name="chromadb",
    version="0.3.29",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "pandas",
        "pydantic",
        "hnswlib",
        "clickhouse-driver",
        # ... other dependencies
    ],
    extras_require={
        "dev": [
            "pytest",
            "pytest-cov",
            "mypy",
            # ... other dev dependencies
        ]
    },
    # ... other setup parameters
)
```

This setup allows users to install Chroma DB with all its dependencies using `pip install chromadb`, and developers can install development dependencies with `pip install -e ".[dev]"`.

## Conclusion

In this lesson, we've covered the essential Python fundamentals that you'll encounter when working with the Chroma DB codebase. We've reviewed basic syntax, object-oriented programming concepts, type hinting, module and package management, asynchronous programming, error handling, and Python's import system. We've also looked at how Chroma DB uses these concepts in its implementation.

In the next lesson, we'll dive deeper into the Chroma DB project structure, exploring the main components and how they interact with each other.

