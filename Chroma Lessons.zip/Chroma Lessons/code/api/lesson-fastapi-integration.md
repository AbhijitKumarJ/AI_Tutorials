# Lesson: FastAPI Integration in Chroma DB

## 1. Introduction

In this lesson, we'll explore how Chroma DB integrates FastAPI to create a robust and efficient REST API. Understanding this integration is crucial for developers who want to extend or customize Chroma DB's API, or build similar systems using FastAPI.

## 2. File Structure

Let's start by looking at the relevant file structure:

```
chromadb/
└── api/
    ├── fastapi.py
    ├── async_fastapi.py
    └── base_http_client.py
```

We'll primarily focus on `fastapi.py` and `async_fastapi.py`.

## 3. FastAPI Class Overview

The `FastAPI` class in `fastapi.py` is the main implementation of Chroma DB's REST API. Let's examine its structure:

```python
class FastAPI(BaseHTTPClient, ServerAPI):
    def __init__(self, system: System):
        super().__init__(system)
        system.settings.require("chroma_server_host")
        system.settings.require("chroma_server_http_port")

        self._opentelemetry_client = self.require(OpenTelemetryClient)
        self._product_telemetry_client = self.require(ProductTelemetryClient)
        self._settings = system.settings

        self._api_url = FastAPI.resolve_url(
            chroma_server_host=str(system.settings.chroma_server_host),
            chroma_server_http_port=system.settings.chroma_server_http_port,
            chroma_server_ssl_enabled=system.settings.chroma_server_ssl_enabled,
            default_api_path=system.settings.chroma_server_api_default_path,
        )

        self._session = httpx.Client(timeout=None)

        # ... additional initialization ...
```

Key points:
- Inherits from `BaseHTTPClient` and implements `ServerAPI`.
- Uses a `System` object for configuration and dependency injection.
- Sets up HTTP client session using `httpx`.

## 4. Request Handling

The `FastAPI` class implements methods to handle various API requests. Let's look at an example:

```python
@trace_method("FastAPI.create_collection", OpenTelemetryGranularity.OPERATION)
@override
def create_collection(
    self,
    name: str,
    configuration: Optional[CollectionConfigurationInternal] = None,
    metadata: Optional[CollectionMetadata] = None,
    get_or_create: bool = False,
    tenant: str = DEFAULT_TENANT,
    database: str = DEFAULT_DATABASE,
) -> CollectionModel:
    """Creates a collection"""
    resp_json = self._make_request(
        "post",
        "/collections",
        json={
            "name": name,
            "metadata": metadata,
            "configuration": configuration.to_json() if configuration else None,
            "get_or_create": get_or_create,
        },
        params={"tenant": tenant, "database": database},
    )

    model = CollectionModel.from_json(resp_json)
    return model
```

Key points:
- Uses decorators for tracing and method overriding.
- Implements the `create_collection` method defined in `ServerAPI`.
- Uses the `_make_request` method to send HTTP requests.

## 5. Request Making and Error Handling

The `_make_request` method is crucial for sending HTTP requests and handling responses:

```python
def _make_request(self, method: str, path: str, **kwargs: Dict[str, Any]) -> Any:
    if "json" in kwargs:
        data = orjson.dumps(kwargs.pop("json"))
        kwargs["content"] = data

    escaped_path = urllib.parse.quote(path, safe="/", encoding=None, errors=None)
    url = self._api_url + escaped_path

    response = self._session.request(method, url, **cast(Any, kwargs))
    BaseHTTPClient._raise_chroma_error(response)
    return orjson.loads(response.text)
```

Key points:
- Uses `orjson` for fast JSON serialization.
- Properly escapes URL paths.
- Raises Chroma-specific errors based on the response.

## 6. Asynchronous FastAPI Implementation

Chroma DB also provides an asynchronous implementation in `async_fastapi.py`. Let's examine some key differences:

```python
class AsyncFastAPI(BaseHTTPClient, AsyncServerAPI):
    _clients: Dict[int, httpx.AsyncClient] = {}

    async def __aenter__(self) -> "AsyncFastAPI":
        self._get_client()
        return self

    async def _cleanup(self) -> None:
        while len(self._clients) > 0:
            (_, client) = self._clients.popitem()
            await client.aclose()

    async def _make_request(
        self, method: str, path: str, **kwargs: Dict[str, Any]
    ) -> Any:
        # ... similar to synchronous version, but using async methods ...
        response = await self._get_client().request(method, url, **cast(Any, kwargs))
        BaseHTTPClient._raise_chroma_error(response)
        return orjson.loads(response.text)
```

Key points:
- Uses `httpx.AsyncClient` for asynchronous HTTP requests.
- Implements `__aenter__` and `_cleanup` for proper resource management.
- The `_make_request` method is now asynchronous.

## 7. OpenTelemetry Integration

Chroma DB integrates OpenTelemetry for tracing and monitoring. This is implemented using decorators:

```python
@trace_method("AsyncFastAPI.create_collection", OpenTelemetryGranularity.OPERATION)
@override
async def create_collection(
    self,
    name: str,
    configuration: Optional[CollectionConfigurationInternal] = None,
    metadata: Optional[CollectionMetadata] = None,
    get_or_create: bool = False,
    tenant: str = DEFAULT_TENANT,
    database: str = DEFAULT_DATABASE,
) -> CollectionModel:
    # ... method implementation ...
```

Key points:
- Uses the `trace_method` decorator for OpenTelemetry tracing.
- Allows for granular tracing of API operations.

## 8. Authentication and Authorization

While not explicitly implemented in the provided code, authentication and authorization can be added using FastAPI's dependency injection system:

```python
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

async def get_current_user(token: str = Depends(oauth2_scheme)):
    user = await verify_token(token)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid token")
    return user

@app.post("/collections/")
async def create_collection(
    name: str,
    current_user: User = Depends(get_current_user),
    configuration: Optional[CollectionConfiguration] = None,
    metadata: Optional[CollectionMetadata] = None,
):
    if not current_user.has_permission("create_collection"):
        raise HTTPException(status_code=403, detail="Not enough permissions")
    # ... rest of the implementation ...
```

## 9. API Versioning

Chroma DB can implement API versioning using FastAPI's path operations:

```python
@app.post("/api/v1/collections/")
async def create_collection_v1(...):
    # v1 implementation

@app.post("/api/v2/collections/")
async def create_collection_v2(...):
    # v2 implementation with new features
```

## 10. Error Handling

Chroma DB implements custom error handling to provide meaningful error responses:

```python
@app.exception_handler(ChromaError)
async def chroma_exception_handler(request: Request, exc: ChromaError):
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.__class__.__name__, "message": str(exc)},
    )
```

## 11. API Documentation

FastAPI automatically generates OpenAPI (Swagger) documentation. Chroma DB can customize this:

```python
app = FastAPI(
    title="Chroma DB API",
    description="API for interacting with Chroma vector database",
    version="1.0.0",
    openapi_tags=[{"name": "collections", "description": "Operations with collections"}]
)
```

## 12. Testing

Testing the FastAPI integration can be done using FastAPI's TestClient:

```python
from fastapi.testclient import TestClient

client = TestClient(app)

def test_create_collection():
    response = client.post("/api/v1/collections/", json={"name": "test_collection"})
    assert response.status_code == 200
    assert response.json()["name"] == "test_collection"
```

## 13. Practical Exercises

1. Implement a new endpoint for batch operations on embeddings.
2. Add rate limiting to the API using FastAPI middleware.
3. Implement a custom authentication scheme (e.g., API key-based).
4. Create a new API version (v2) with a breaking change and ensure backward compatibility.
5. Write comprehensive tests for all API endpoints, including error cases.

## 14. Conclusion

Understanding Chroma DB's FastAPI integration is crucial for effectively working with and extending the system. The combination of FastAPI's modern features with Chroma DB's vector database capabilities provides a powerful foundation for building scalable and efficient APIs. In the next lesson, we'll explore Chroma DB's embedding functions and their integration with the API.

