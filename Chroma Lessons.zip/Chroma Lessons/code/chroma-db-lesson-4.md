# Lesson 4: Core Data Types and Models

## 1. Introduction to chromadb/api/types.py

The `chromadb/api/types.py` file is a crucial component of the Chroma DB project, as it defines the core data types and models used throughout the system. Understanding these types is essential for working with Chroma DB effectively.

Let's explore the main types defined in this file:

## 2. Basic Types

### 2.1 Scalar Types

```python
from typing import Union

Scalar = Union[bool, int, float, str]
```

The `Scalar` type represents basic data types that can be used in metadata or as individual values.

### 2.2 Document and Embedding Types

```python
Document = str
Embedding = Union[List[float], numpy.ndarray]
```

- `Document` is simply a string, representing the raw text data.
- `Embedding` can be either a list of floats or a NumPy array, representing the vector embedding of a document.

## 3. Collection Types

```python
Documents = List[Document]
Embeddings = List[Embedding]
IDs = List[str]
```

These types represent collections of documents, embeddings, and IDs respectively.

## 4. Metadata Types

```python
Metadata = Dict[str, Union[str, int, float, bool]]
Metadatas = List[Metadata]
```

`Metadata` is a dictionary that can contain various types of data associated with a document or embedding. `Metadatas` is a list of such dictionaries.

## 5. Where and WhereDocument Types

The `Where` and `WhereDocument` types are used for querying and filtering data in Chroma DB.

```python
class WhereOperator(str, Enum):
    EQ = "$eq"
    NE = "$ne"
    GT = "$gt"
    GTE = "$gte"
    LT = "$lt"
    LTE = "$lte"
    # ... other operators

Where = Dict[
    str,
    Union[
        str,
        int,
        float,
        bool,
        List[str],
        List[int],
        List[float],
        Dict[WhereOperator, Union[str, int, float, bool]],
    ],
]

WhereDocument = Dict[str, Union[str, Dict[str, str]]]
```

These types allow for complex querying of metadata and document content.

Example usage:

```python
where_clause: Where = {
    "price": {"$lt": 100},
    "category": "electronics"
}

where_document: WhereDocument = {
    "$contains": "artificial intelligence"
}
```

## 6. Include Type

The `Include` type is used to specify which data to include in query results:

```python
class Include(str, Enum):
    Documents = "documents"
    Embeddings = "embeddings"
    Metadatas = "metadatas"
    Distances = "distances"

IncludeAll = Set[Include]
```

Example usage:

```python
include: Include = Include.Documents | Include.Metadatas
```

## 7. Operation Type

The `Operation` type represents different operations that can be performed on the database:

```python
class Operation(Enum):
    ADD = "add"
    UPDATE = "update"
    UPSERT = "upsert"
    DELETE = "delete"
```

## 8. EmbeddingFunction Type

The `EmbeddingFunction` type is a protocol that defines the interface for embedding functions:

```python
T = TypeVar('T')

class EmbeddingFunction(Protocol[T]):
    def __call__(self, input: List[T]) -> Embeddings:
        ...
```

This allows for custom embedding functions to be easily integrated into Chroma DB.

## 9. Collection Configuration Types

Chroma DB uses several types to represent collection configurations:

```python
class NamespacedCollection(BaseModel):
    name: str
    tenant: str = "default_tenant"
    database: str = "default_database"

class CollectionMetadata(BaseModel):
    name: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

class OptionalCollectionMetadata(BaseModel):
    name: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
```

These types are used to create and manage collections within Chroma DB.

## 10. Result Types

Chroma DB defines several result types for different operations:

```python
GetResult = TypedDict(
    "GetResult",
    {
        "ids": List[str],
        "embeddings": Optional[List[List[float]]],
        "documents": Optional[List[Optional[str]]],
        "metadatas": Optional[List[Optional[Dict[str, Union[str, int, float, bool]]]]],
    },
)

QueryResult = TypedDict(
    "QueryResult",
    {
        "ids": List[List[str]],
        "embeddings": Optional[List[List[List[float]]]],
        "documents": Optional[List[List[Optional[str]]]],
        "metadatas": Optional[
            List[List[Optional[Dict[str, Union[str, int, float, bool]]]]]
        ],
        "distances": Optional[List[List[float]]],
    },
)
```

These types define the structure of results returned by get and query operations.

## 11. Practical Example: Using Core Types

Let's look at a practical example of how these types are used in Chroma DB:

```python
from chromadb.api.types import Documents, Embeddings, Metadatas, IDs, Where, WhereDocument

class Collection:
    def add(
        self,
        ids: IDs,
        embeddings: Optional[Embeddings] = None,
        metadatas: Optional[Metadatas] = None,
        documents: Optional[Documents] = None,
    ) -> None:
        # Implementation details...

    def query(
        self,
        query_embeddings: Optional[Embeddings] = None,
        query_texts: Optional[Documents] = None,
        n_results: int = 10,
        where: Optional[Where] = None,
        where_document: Optional[WhereDocument] = None,
    ) -> QueryResult:
        # Implementation details...
```

In this example, we can see how the core types are used to define the interface for adding data to a collection and querying it.

## 12. How Types Enhance Code Quality and Developer Experience

The use of these types in Chroma DB provides several benefits:

1. **Type Safety**: By using static typing, many errors can be caught at compile-time rather than runtime.

2. **Code Clarity**: Types serve as documentation, making it clear what kind of data is expected and returned by functions.

3. **Autocomplete and IntelliSense**: IDEs can provide better autocomplete suggestions and type information when working with well-typed code.

4. **Consistency**: Types ensure that data is consistently structured throughout the codebase.

5. **API Design**: Types help in designing clear and intuitive APIs by explicitly defining the shape of data.

## 13. Practical Exercises

To reinforce your understanding of Chroma DB's core types, try these exercises:

1. Create a function that takes a `Document` and returns an `Embedding` (you can use a dummy embedding function).

2. Write a `Where` clause that filters for documents with a specific tag and a date range.

3. Define a custom `EmbeddingFunction` that converts documents to lowercase and uses the length of the document as the embedding.

4. Create a `QueryResult` object with sample data for a query that returns 3 results.

## Conclusion

In this lesson, we've explored the core data types and models used in Chroma DB. We've seen how these types are defined in `chromadb/api/types.py` and how they are used throughout the project. Understanding these types is crucial for working effectively with Chroma DB, whether you're using it as a library or contributing to its development.

In the next lesson, we'll dive into the configuration system of Chroma DB, exploring how settings are managed and how they affect the behavior of the database.

