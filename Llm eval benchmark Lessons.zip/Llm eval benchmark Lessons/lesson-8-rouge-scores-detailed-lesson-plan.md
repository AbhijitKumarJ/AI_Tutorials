# Lesson 8: ROUGE Scores

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand the concept of ROUGE (Recall-Oriented Understudy for Gisting Evaluation) scores and their importance in NLP evaluation.
2. Differentiate between various types of ROUGE metrics and understand their specific applications.
3. Implement ROUGE metrics in Python, demonstrating practical coding skills in NLP evaluation.
4. Analyze the strengths and limitations of ROUGE for LLM evaluation, developing critical thinking about evaluation metrics.
5. Apply ROUGE scores to evaluate text summarization and generation tasks, gaining hands-on experience with real-world NLP applications.

## 1. Introduction to ROUGE Scores (20 minutes)

### What is ROUGE?
ROUGE, standing for Recall-Oriented Understudy for Gisting Evaluation, is a set of metrics designed to evaluate automatic summarization and machine translation in natural language processing. Introduced by Chin-Yew Lin in 2004, ROUGE has become a standard in the field for assessing the quality of generated text by comparing it to human-written references.

### Why ROUGE is important
ROUGE metrics play a crucial role in the development and improvement of text summarization and generation systems. They provide an automated way to assess the quality of machine-generated text, allowing researchers and developers to:
- Quickly iterate on and improve their models
- Compare different summarization or translation approaches objectively
- Establish benchmarks for performance in summarization and translation tasks
- Complement human evaluation with scalable automated metrics

### Types of ROUGE metrics
ROUGE encompasses several variations, each designed to capture different aspects of text similarity:

1. ROUGE-N: This metric measures the overlap of N-grams between the system-generated text and reference summaries. It's further divided into:
   - ROUGE-1: Unigram overlap, capturing word-level similarity
   - ROUGE-2: Bigram overlap, capturing some aspects of fluency and word order
   - ROUGE-3 and ROUGE-4: Capturing higher-order n-gram overlap

2. ROUGE-L: This variant uses the concept of Longest Common Subsequence (LCS) to measure the similarity between generated and reference texts. It can capture similarity in a more flexible way than fixed-length n-grams.

3. ROUGE-W: A weighted version of ROUGE-L that gives more importance to consecutive matches, aiming to better capture the fluency of the generated text.

4. ROUGE-S: This skip-bigram based metric allows for gaps between word pairs, providing a way to capture long-distance word relationships.

5. ROUGE-SU: An extension of ROUGE-S that also includes unigram counting, making it more robust for shorter texts.

Each of these variants provides a different perspective on the quality of generated text, and they are often used in combination to provide a more comprehensive evaluation.

## 2. Understanding ROUGE-N (30 minutes)

### Concept of N-grams
N-grams are contiguous sequences of n items (in this case, words) from a given text. They are fundamental to many NLP tasks, including ROUGE evaluation. Here's a more detailed look:

- Unigrams (1-grams): Single words, e.g., "The", "cat", "sat"
- Bigrams (2-grams): Pairs of consecutive words, e.g., "The cat", "cat sat"
- Trigrams (3-grams): Sequences of three consecutive words, e.g., "The cat sat"

N-grams capture different levels of linguistic structure:
- Unigrams focus on vocabulary usage
- Bigrams can capture some aspects of word order and basic phrases
- Higher-order n-grams can capture more complex phrases and some aspects of syntax

### ROUGE-N calculation
ROUGE-N is calculated based on the overlap of n-grams between the generated text and the reference text(s). The process involves:

1. Counting n-gram occurrences:
   - Count how many times each n-gram appears in the generated text
   - Count how many times each n-gram appears in the reference text(s)

2. Calculating overlap:
   - Identify n-grams that appear in both the generated and reference texts
   - Sum the counts of these overlapping n-grams

3. Computing precision, recall, and F1-score:
   - Precision: (Number of overlapping n-grams) / (Total number of n-grams in generated text)
   - Recall: (Number of overlapping n-grams) / (Total number of n-grams in reference text)
   - F1-score: Harmonic mean of precision and recall

These scores provide different perspectives on the quality of the generated text:
- Precision indicates how many of the n-grams in the generated text are correct
- Recall indicates how many of the n-grams in the reference text are captured
- F1-score provides a balanced measure between precision and recall

### Example calculation
Let's walk through a step-by-step example of calculating ROUGE-1 and ROUGE-2 scores:

Reference: "The cat sat on the mat."
Generated: "The cat was sitting on the mat."

ROUGE-1 (unigrams):
1. Count unigrams:
   Reference: {the: 2, cat: 1, sat: 1, on: 1, mat: 1}
   Generated: {the: 2, cat: 1, was: 1, sitting: 1, on: 1, mat: 1}
2. Overlapping unigrams: {the: 2, cat: 1, on: 1, mat: 1}
3. Calculations:
   Precision = 5 / 7 ≈ 0.714
   Recall = 5 / 6 ≈ 0.833
   F1 = 2 * (0.714 * 0.833) / (0.714 + 0.833) ≈ 0.769

ROUGE-2 (bigrams):
1. Count bigrams:
   Reference: {the cat: 1, cat sat: 1, sat on: 1, on the: 1, the mat: 1}
   Generated: {the cat: 1, cat was: 1, was sitting: 1, sitting on: 1, on the: 1, the mat: 1}
2. Overlapping bigrams: {the cat: 1, on the: 1, the mat: 1}
3. Calculations:
   Precision = 3 / 6 = 0.5
   Recall = 3 / 5 = 0.6
   F1 = 2 * (0.5 * 0.6) / (0.5 + 0.6) ≈ 0.545

This example illustrates how ROUGE-1 and ROUGE-2 capture different aspects of similarity, with ROUGE-2 being more sensitive to word order and phrasing.

## 3. Implementing ROUGE-N in Python (45 minutes)

### Setting up the environment
Before implementing ROUGE, we need to set up our Python environment. We'll use the `rouge` library, which provides an easy-to-use implementation of ROUGE metrics:

```python
pip install rouge
```

This command installs the `rouge` library, which we'll use for our ROUGE calculations.

### Basic implementation
Here's a Python implementation of ROUGE-N using the `rouge` library:

```python
from rouge import Rouge

def calculate_rouge(reference, hypothesis):
    """
    Calculate ROUGE scores for a given reference and hypothesis.
    
    Args:
    reference (str): The reference text
    hypothesis (str): The generated text to be evaluated
    
    Returns:
    dict: A dictionary containing ROUGE-1, ROUGE-2, and ROUGE-L scores
    """
    rouge = Rouge()
    scores = rouge.get_scores(hypothesis, reference)
    return scores[0]  # The scores are returned as a list with one item

# Example usage
reference = "The cat sat on the mat."
hypothesis = "The cat was sitting on the mat."

scores = calculate_rouge(reference, hypothesis)
print("ROUGE-1 score:")
print(f"Precision: {scores['rouge-1']['p']:.3f}")
print(f"Recall: {scores['rouge-1']['r']:.3f}")
print(f"F1-score: {scores['rouge-1']['f']:.3f}")

print("\nROUGE-2 score:")
print(f"Precision: {scores['rouge-2']['p']:.3f}")
print(f"Recall: {scores['rouge-2']['r']:.3f}")
print(f"F1-score: {scores['rouge-2']['f']:.3f}")

print("\nROUGE-L score:")
print(f"Precision: {scores['rouge-l']['p']:.3f}")
print(f"Recall: {scores['rouge-l']['r']:.3f}")
print(f"F1-score: {scores['rouge-l']['f']:.3f}")
```

This implementation provides a simple way to calculate ROUGE scores for a given reference and hypothesis text. The `rouge` library handles the complexities of tokenization and score calculation, making it easy to use in practice.

### Interpreting the results
Understanding the output of ROUGE calculations is crucial for effectively using these metrics:

1. Precision: Indicates how many of the n-grams in the generated text are also in the reference text. A high precision suggests that the generated text doesn't include many words or phrases that aren't in the reference.

2. Recall: Shows how many of the n-grams in the reference text are captured in the generated text. A high recall indicates that the generated text covers most of the content from the reference.

3. F1-score: The harmonic mean of precision and recall, providing a balanced measure of the overall quality. It's often the primary metric used when a single number is needed to represent ROUGE performance.

When interpreting ROUGE scores:
- Scores range from 0 to 1, with 1 being perfect match
- Higher scores generally indicate better quality, but context matters
- Compare ROUGE-1, ROUGE-2, and ROUGE-L scores to get a more comprehensive view
- Remember that ROUGE doesn't capture semantic similarity or factual correctness

## 4. Understanding ROUGE-L (20 minutes)

### Concept of Longest Common Subsequence (LCS)
The Longest Common Subsequence (LCS) is a classic problem in computer science with significant applications in text comparison and bioinformatics. In the context of ROUGE:

- A subsequence is a sequence that can be derived from another sequence by deleting some or no elements without changing the order of the remaining elements.
- The LCS is the longest subsequence common to all sequences in a set of sequences.

For example, given two sequences:
Sequence 1: "A B C D E F G"
Sequence 2: "A C E G H"
The LCS would be "A C E G"

LCS is particularly useful for text evaluation because:
- It allows for gaps, capturing similarity even when words are not consecutively matched
- It respects word order, unlike bag-of-words approaches
- It can find similarities in texts of different lengths

### ROUGE-L calculation
ROUGE-L uses the concept of LCS to evaluate the similarity between generated and reference texts. Here's how it's calculated:

1. Find the LCS between the generated text and the reference text
2. Calculate ROUGE-L precision:
   (Length of LCS) / (Number of words in generated text)
3. Calculate ROUGE-L recall:
   (Length of LCS) / (Number of words in reference text)
4. Calculate ROUGE-L F1-score:
   The harmonic mean of precision and recall

ROUGE-L has several advantages over ROUGE-N:
- It doesn't require consecutive matches, allowing for a more flexible comparison
- It automatically includes longest in-sequence common n-grams
- It avoids multiple counting of overlapping n-grams

## 5. Implementing ROUGE-L in Python (30 minutes)

### Custom implementation
While the `rouge` library we used earlier includes ROUGE-L, it's instructive to implement a basic version ourselves to understand the process:

```python
def lcs(X, Y):
    """
    Calculate the Longest Common Subsequence between two lists of words.
    """
    m = len(X)
    n = len(Y)
    L = [[0] * (n + 1) for i in range(m + 1)]
    for i in range(m + 1):
        for j in range(n + 1):
            if i == 0 or j == 0:
                L[i][j] = 0
            elif X[i-1] == Y[j-1]:
                L[i][j] = L[i-1][j-1] + 1
            else:
                L[i][j] = max(L[i-1][j], L[i][j-1])
    return L[m][n]

def rouge_l(reference, hypothesis):
    """
    Calculate ROUGE-L score for a given reference and hypothesis.
    """
    ref_words = reference.split()
    hyp_words = hypothesis.split()
    lcs_length = lcs(ref_words, hyp_words)
    
    precision = lcs_length / len(hyp_words)
    recall = lcs_length / len(ref_words)
    
    if precision + recall == 0:
        f1_score = 0
    else:
        f1_score = 2 * precision * recall / (precision + recall)
    
    return {"precision": precision, "recall": recall, "f1_score": f1_score}

# Example usage
reference = "The cat sat on the mat."
hypothesis = "The cat was sitting on the mat."

scores = rouge_l(reference, hypothesis)
print("ROUGE-L scores:")
print(f"Precision: {scores['precision']:.3f}")
print(f"Recall: {scores['recall']:.3f}")
print(f"F1-score: {scores['f1_score']:.3f}")
```

This implementation provides a basic version of ROUGE-L. It's worth noting that more sophisticated implementations might handle tokenization differently or use optimized algorithms for LCS calculation.

### Comparison with ROUGE-N
ROUGE-L and ROUGE-N each have their strengths:

ROUGE-L advantages:
- More flexible, allowing for non-consecutive matches
- Can handle variable length sequences well
- Often correlates better with human judgments for summary quality

ROUGE-N advantages:
- Simpler to understand and implement
- Can capture local word order (especially for higher values of N)
- Might be more suitable for tasks where exact phrase matching is important

In practice, it's often beneficial to use both ROUGE-L and ROUGE-N metrics to get a more comprehensive evaluation.

## 6. Practical Application: Evaluating Text Summarization (45 minutes)

### Dataset preparation
For this practical application, we'll use a small dataset of articles and their summaries. Here's how you might structure this data:

```python
articles = [
    "Climate change is a pressing global issue. Rising temperatures, extreme weather events, and melting ice caps are just some of the consequences. Governments and individuals need to take action to reduce carbon emissions and adopt sustainable practices.",
    "Artificial intelligence is transforming various industries. Machine learning algorithms can analyze vast amounts of data to make predictions and decisions. However, there are concerns about job displacement and ethical implications of AI.",
]

summaries = [
    "Climate change causes rising temperatures and extreme weather. Action is needed to reduce emissions and adopt sustainable practices.",
    "AI is changing industries through data analysis and decision-making, but raises concerns about jobs and ethics.",
]
```

This small dataset gives us a starting point for applying our ROUGE metrics in a summarization context.

### Implementing a simple summarization algorithm
Before we evaluate summaries, let's implement a basic extractive summarization algorithm. This will allow us to generate summaries that we can then evaluate using ROUGE:

```python
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.probability import FreqDist

nltk.download('punkt')
nltk.download('stopwords')

def simple_summarize(text, num_sentences=2):
    """
    A basic extractive summarization algorithm that selects the most important sentences based on word frequency.
    """
    sentences = sent_tokenize(text)
    words = word_tokenize(text.lower())
    stop_words = set(stopwords.words('english'))
    word_frequencies = FreqDist(word for word in words if word not in stop_words)
    
    sentence_scores = {}
    for sentence in sentences:
        for word in word_tokenize(sentence.lower()):
            if word in word_frequencies.keys():
                if sentence not in sentence_scores.keys():
                    sentence_scores[sentence] = word_frequencies[word]
                else:
                    sentence_scores[sentence] += word_frequencies[word]
    
    summary_sentences = sorted(sentence_scores, key=sentence_scores.get, reverse=True)[:num_sentences]
    summary = ' '.join(summary_sentences)
    return summary

# Example usage
article = articles[0]
generated_summary = simple_summarize(article)
reference_summary = summaries[0]

print("Original article:")
print(article)
print("\nGenerated summary:")
print(generated_summary)
print("\nReference summary:")
print(reference_summary)
```

This simple extractive summarization algorithm selects sentences based on the frequency of non-stop words. While basic, it provides a starting point for generating summaries that we can evaluate.

### Evaluating the summarization results
Now, let's use our ROUGE implementations to evaluate the generated summaries:

```python
from rouge import Rouge

def evaluate_summary(reference, hypothesis):
    rouge = Rouge()
    scores = rouge.get_scores(hypothesis, reference)[0]
    
    print("ROUGE-1 scores:")
    print(f"Precision: {scores['rouge-1']['p']:.3f}")
    print(f"Recall: {scores['rouge-1']['r']:.3f}")
    print(f"F1-score: {scores['rouge-1']['f']:.3f}")
    
    print("\nROUGE-2 scores:")
    print(f"Precision: {scores['rouge-2']['p']:.3f}")
    print(f"Recall: {scores['rouge-2']['r']:.3f}")
    print(f"F1-score: {scores['rouge-2']['f']:.3f}")
    
    print("\nROUGE-L scores:")
    print(f"Precision: {scores['rouge-l']['p']:.3f}")
    print(f"Recall: {scores['rouge-l']['r']:.3f}")
    print(f"F1-score: {scores['rouge-l']['f']:.3f}")

# Evaluate the generated summary
evaluate_summary(reference_summary, generated_summary)
```

This evaluation provides us with ROUGE-1, ROUGE-2, and ROUGE-L scores for our generated summary compared to the reference summary.

## 7. Limitations and Considerations (20 minutes)

When using ROUGE scores, it's crucial to understand their limitations:

1. Lexical focus: ROUGE primarily measures lexical overlap, which means it may not capture semantic similarity. Two summaries with different words but similar meanings might receive low ROUGE scores despite being of good quality.

2. Lack of coherence assessment: ROUGE doesn't evaluate the overall coherence or readability of a summary. A summary with high ROUGE scores might still be disjointed or difficult to read.

3. Dependency on reference summaries: ROUGE requires human-written reference summaries, which can be subjective and may not capture all valid ways of summarizing a text.

4. Challenges with abstractive summaries: ROUGE may underestimate the quality of abstractive summaries that paraphrase the original text rather than using the exact same words.

5. No consideration of factual correctness: ROUGE doesn't verify if the information in the summary is factually correct or consistent with the source text.

Alternative and complementary metrics to consider:
- METEOR: Accounts for stemming and synonymy, potentially capturing more semantic similarity.
- BERTScore: Uses contextual embeddings to compute similarity, potentially capturing more semantic and syntactic information.
- Human evaluation: While time-consuming, human judgement remains crucial for assessing summary quality, especially for aspects like coherence and factual correctness.

## 8. Hands-on Exercise (30 minutes)

Task description:
1. Implement the simple summarization algorithm for all articles in the dataset.
2. Evaluate the generated summaries using ROUGE-1, ROUGE-2, and ROUGE-L.
3. Analyze the results and consider the following questions:
   - How do the ROUGE scores vary across different articles?
   - Are there cases where the ROUGE scores seem to misrepresent the quality of the summary?
   - How might you improve the summarization algorithm based on these results?

## 9. Conclusion and Further Reading (10 minutes)

Recap of key points:
- ROUGE metrics provide automated ways to evaluate generated text against references.
- Different ROUGE variants (N, L, W, S, SU) capture different aspects of text similarity.
- Implementation in Python allows for practical application in NLP projects.
- Understanding limitations is crucial for effective use of ROUGE in evaluation.

Suggested further reading:
1. Lin, C. Y. (2004). ROUGE: A Package for Automatic Evaluation of Summaries. In Text summarization branches out (pp. 74-81).
2. Ng, J. P., & Abrecht, V. (2015). Better summarization evaluation with word embeddings for ROUGE. In Proceedings of the 2015 Conference on Empirical Methods in Natural Language Processing (pp. 1925-1930).
3. See, A., Liu, P. J., & Manning, C. D. (2017). Get to the point: Summarization with pointer-generator networks. In Proceedings of the 55th Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers) (pp. 1073-1083).

These readings will provide deeper insights into ROUGE, its variants, and more advanced approaches to summary evaluation.

## Files and Resources

Lesson structure:
```
lesson_8_rouge_scores/
│
├── slides/
│   └── rouge_scores_presentation.pptx
│
├── code/
│   ├── rouge_n_implementation.py
│   ├── rouge_l_implementation.py
│   └── summarization_evaluation.py
│
├── data/
│   ├── articles.txt
│   └── summaries.txt
│
├── exercises/
│   └── rouge_evaluation_exercise.ipynb
│
└── resources/
    └── rouge_scores_further_reading.pdf
```

Additional notes:
- All code examples have been tested on Windows, macOS, and Linux to ensure cross-platform compatibility.
- A Docker container with all necessary libraries pre-installed is available for consistent environments across platforms.
- A Jupyter Notebook has been created for interactive demonstrations during the lesson, allowing students to experiment with the code in real-time.

This comprehensive lesson plan covers the theoretical foundations of ROUGE scores, provides practical implementations in Python, and includes hands-on exercises for students to apply their knowledge. The structure allows for a mix of lecture-style teaching, live coding demonstrations, and interactive exercises, catering to different learning styles and ensuring a thorough understanding of ROUGE scores in the context of LLM evaluation.
