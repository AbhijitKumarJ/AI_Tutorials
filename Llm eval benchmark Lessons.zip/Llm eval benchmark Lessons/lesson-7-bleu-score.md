# Lesson 7: BLEU Score

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand the concept and importance of the BLEU score in evaluating machine translation and text generation
2. Explain the components of the BLEU score calculation, including n-gram precision and brevity penalty
3. Implement BLEU score calculation in Python using both custom functions and popular NLP libraries
4. Interpret BLEU scores in the context of LLM performance evaluation
5. Critically assess the strengths and limitations of the BLEU metric
6. Apply BLEU score to evaluate LLM outputs in translation and text generation tasks

## Lesson Duration
Approximately 3 hours

## Prerequisites
- Python programming skills, including working with strings, lists, and dictionaries
- Understanding of LLMs and their applications (covered in Module 1)
- Familiarity with basic NLP concepts and previous evaluation metrics (covered in earlier lessons)
- Basic knowledge of machine translation concepts

## File Structure
```
lesson_7/
│
├── bleu_score.ipynb
├── data/
│   ├── translations.json
│   └── references.json
├── utils/
│   └── bleu_helpers.py
├── images/
│   ├── bleu_example.png
│   └── n_gram_visualization.png
└── README.md
```

## Lesson Content

### 1. Introduction (20 minutes)
- Recap of previous lessons on evaluation metrics:
  Briefly review the classification metrics (Precision, Recall, F1 Score) from the previous lesson. Explain why these metrics, while useful for classification tasks, are not suitable for evaluating the quality of generated text or translations.

- Introduction to machine translation evaluation:
  Discuss the challenges of evaluating machine translation and text generation. Explain why automated metrics are necessary and how they complement human evaluation.

- Overview of BLEU (Bilingual Evaluation Understudy):
  Introduce BLEU as a widely used metric for evaluating machine translation quality. Briefly explain its origins and why it was developed.

### 2. Understanding BLEU Score (40 minutes)
- Definition and purpose of BLEU:
  Explain that BLEU measures how similar the machine-generated text is to a set of reference translations. Emphasize that it's designed to correlate with human judgments of quality.

- Key components of BLEU:
  1. N-gram precision: Explain that BLEU considers the overlap of n-grams (contiguous sequences of n words) between the candidate translation and reference translations.
  2. Brevity penalty: Describe how BLEU penalizes translations that are too short to discourage systems from gaming the metric by producing very short outputs.

- BLEU formula overview:
  Present the high-level formula for BLEU: BLEU = BP * exp(sum(w_n * log(p_n)))
  Where:
  - BP is the brevity penalty
  - w_n are weights for different n-gram precisions (usually uniform)
  - p_n are the n-gram precisions

- N-gram precision calculation:
  Provide a detailed explanation of how n-gram precision is calculated, using a simple example to illustrate the process.

```python
def calculate_ngram_precision(candidate, references, n):
    candidate_ngrams = get_ngrams(candidate, n)
    reference_ngrams = [get_ngrams(ref, n) for ref in references]
    
    max_count = {}
    for ref_ngrams in reference_ngrams:
        for ngram, count in ref_ngrams.items():
            max_count[ngram] = max(max_count.get(ngram, 0), count)
    
    candidate_ngram_counts = {}
    for ngram in candidate_ngrams:
        if ngram in max_count:
            candidate_ngram_counts[ngram] = candidate_ngram_counts.get(ngram, 0) + 1
    
    clipped_counts = {ngram: min(count, max_count[ngram]) for ngram, count in candidate_ngram_counts.items()}
    
    numerator = sum(clipped_counts.values())
    denominator = sum(candidate_ngrams.values())
    
    return numerator / denominator if denominator > 0 else 0

def get_ngrams(sentence, n):
    words = sentence.split()
    return {' '.join(words[i:i+n]): 1 for i in range(len(words)-n+1)}

# Example usage
candidate = "The cat is on the mat"
references = ["There is a cat on the mat", "A cat is on the mat"]
print(f"1-gram precision: {calculate_ngram_precision(candidate, references, 1):.4f}")
print(f"2-gram precision: {calculate_ngram_precision(candidate, references, 2):.4f}")
```

- Brevity penalty calculation:
  Explain how the brevity penalty is calculated and why it's necessary. Provide an example calculation.

```python
def calculate_brevity_penalty(candidate, references):
    c = len(candidate.split())
    r = min(len(ref.split()) for ref in references)
    
    if c > r:
        return 1
    else:
        return math.exp(1 - r/c)

# Example usage
bp = calculate_brevity_penalty(candidate, references)
print(f"Brevity penalty: {bp:.4f}")
```

### 3. Implementing BLEU Score in Python (50 minutes)
- Step-by-step implementation of BLEU:
  Walk through the process of implementing the full BLEU score calculation, building on the n-gram precision and brevity penalty functions.

```python
import math
from collections import Counter

def calculate_bleu(candidate, references, max_n=4):
    bp = calculate_brevity_penalty(candidate, references)
    precisions = [calculate_ngram_precision(candidate, references, n) for n in range(1, max_n+1)]
    
    if min(precisions) > 0:
        p_log_sum = sum((1.0 / max_n) * math.log(p) for p in precisions)
        return bp * math.exp(p_log_sum)
    else:
        return 0

# Example usage
bleu_score = calculate_bleu(candidate, references)
print(f"BLEU Score: {bleu_score:.4f}")
```

- Using NLTK for BLEU calculation:
  Demonstrate how to use the NLTK library to calculate BLEU scores, comparing the results with our custom implementation.

```python
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction

# Tokenize the sentences
candidate_tokens = candidate.split()
reference_tokens = [ref.split() for ref in references]

# Calculate BLEU score using NLTK
smoothie = SmoothingFunction().method1
nltk_bleu = sentence_bleu(reference_tokens, candidate_tokens, smoothing_function=smoothie)
print(f"NLTK BLEU Score: {nltk_bleu:.4f}")
```

- Handling multiple references:
  Explain how BLEU handles multiple reference translations and why this is important for robust evaluation.

### 4. Interpreting BLEU Scores (30 minutes)
- Range and meaning of BLEU scores:
  Discuss what different BLEU scores typically indicate about translation quality. Provide guidelines for interpreting scores (e.g., 0-20: very low quality, 20-40: low quality, 40-60: moderate quality, 60-80: high quality, 80-100: very high quality).

- Factors affecting BLEU scores:
  Explain how factors like language pair, domain, and reference quality can impact BLEU scores.

- Visualizing BLEU scores:
  Demonstrate how to create visualizations that help interpret BLEU scores across different systems or language pairs.

```python
import matplotlib.pyplot as plt

def plot_bleu_scores(systems, scores):
    plt.figure(figsize=(10, 6))
    plt.bar(systems, scores)
    plt.title('BLEU Scores Comparison')
    plt.xlabel('Translation System')
    plt.ylabel('BLEU Score')
    plt.ylim(0, 1)
    plt.show()

# Example usage
systems = ['System A', 'System B', 'System C']
scores = [0.35, 0.42, 0.28]
plot_bleu_scores(systems, scores)
```

### 5. Strengths and Limitations of BLEU (30 minutes)
- Advantages of BLEU:
  1. Language-independent
  2. Fast and easy to compute
  3. Correlates reasonably well with human judgments
  4. Allows for multiple references

- Limitations and criticisms of BLEU:
  1. Doesn't account for meaning or grammaticality
  2. Can be gamed by systems that optimize for n-gram overlap
  3. May not capture nuances in languages with rich morphology
  4. Doesn't handle synonyms or paraphrases well

- Alternatives and extensions to BLEU:
  Briefly introduce other metrics like METEOR, chrF, and COMET, explaining how they address some of BLEU's limitations.

### 6. Applying BLEU to LLM Evaluation (40 minutes)
- BLEU for text generation tasks:
  Discuss how BLEU can be applied beyond machine translation to evaluate other text generation tasks like summarization, paraphrasing, or dialogue generation.

- Case study: Evaluating an LLM on a translation task:
  Walk through a complete example of evaluating an LLM's performance on a machine translation task using BLEU. Use real or realistic data to calculate and interpret BLEU scores.

```python
import json

# Load translation data
with open('data/translations.json', 'r') as f:
    translations = json.load(f)

with open('data/references.json', 'r') as f:
    references = json.load(f)

# Calculate BLEU scores for each translation
bleu_scores = []
for src_lang in translations:
    for tgt_lang in translations[src_lang]:
        candidates = translations[src_lang][tgt_lang]
        refs = references[src_lang][tgt_lang]
        scores = [calculate_bleu(cand, refs) for cand in candidates]
        bleu_scores.extend(scores)

# Plot distribution of BLEU scores
plt.figure(figsize=(10, 6))
plt.hist(bleu_scores, bins=20, edgecolor='black')
plt.title('Distribution of BLEU Scores')
plt.xlabel('BLEU Score')
plt.ylabel('Frequency')
plt.show()
```

- Considerations for LLM evaluation:
  Discuss the challenges of applying BLEU to LLM outputs, such as:
  - Handling creative or diverse outputs
  - Evaluating factual correctness
  - Assessing coherence over long texts

### 7. Hands-on Exercise (30 minutes)
Students will work on a practical exercise involving:
1. Loading a dataset of LLM-generated translations and reference translations
2. Calculating BLEU scores for each translation
3. Visualizing the results and comparing performance across different language pairs
4. Analyzing examples of high and low-scoring translations
5. Proposing improvements based on the evaluation results

Provide starter code and a dataset, guiding students through each step of the process. Encourage them to experiment with different n-gram weights and smoothing techniques.

### 8. Discussion and Q&A (20 minutes)
- Open discussion on BLEU score:
  Facilitate a conversation about the students' experiences with the hands-on exercise. Encourage them to share insights and challenges they encountered.

- Address any questions or clarifications needed:
  Take time to clear up any confusion about the concepts or implementations covered in the lesson.

- Preview the next lesson on ROUGE scores:
  Briefly introduce ROUGE as another set of metrics for evaluating text generation, particularly useful for summarization tasks. Explain how it relates to and differs from BLEU.

## Additional Resources
- Original BLEU paper: "BLEU: a Method for Automatic Evaluation of Machine Translation" by Papineni et al. (2002)
- NLTK documentation on BLEU score implementation
- Blog post: "Understanding and Implementing BLEU Score for Text Generation" (provide a link to a comprehensive tutorial)
- Interactive web tool for calculating BLEU scores (if available)
- Research paper discussing the limitations of BLEU and proposing improvements

## Assessment
1. Multiple-choice questions testing understanding of BLEU score concepts, including n-gram precision, brevity penalty, and interpretation of scores.
2. Short coding task to implement a simplified version of BLEU score calculation from scratch.
3. Analysis task: Given a set of LLM-generated translations and references, calculate BLEU scores, create visualizations, and write a brief report interpreting the results and suggesting potential improvements to the model or evaluation process.

## Homework
1. Implement a function to calculate BLEU score for a corpus of texts, handling multiple references and applying smoothing techniques.
2. Research and write a brief report on how BLEU is used in a specific LLM application of your choice (e.g., machine translation systems, multilingual chatbots). Include real-world examples and discuss any adaptations or alternatives to BLEU used in that context.
3. Explore and report on one alternative translation evaluation metric not covered in the lesson (e.g., METEOR, chrF). Implement it in Python and discuss its advantages and disadvantages compared to BLEU.

## Next Steps
In the next lesson, we'll explore the ROUGE (Recall-Oriented Understudy for Gisting Evaluation) scores, which are particularly useful for evaluating text summarization tasks. We'll see how ROUGE complements BLEU and why it's important for certain LLM tasks, especially those involving content reduction and information preservation.
