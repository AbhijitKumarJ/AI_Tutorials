# Lesson 25: Bias and Fairness in LLMs

## Table of Contents
1. Introduction
2. Learning Objectives
3. Theoretical Foundation
   3.1 Understanding Bias in LLMs
   3.2 Types of Bias in NLP
   3.3 Fairness Metrics and Definitions
4. Practical Implementation
   3.1 Setting Up the Environment
   3.2 Detecting Bias in LLMs
   3.3 Implementing Fairness Metrics
   3.4 Bias Mitigation Strategies
5. Cross-Platform Considerations
6. Exercises and Projects
7. Real-World Applications
8. Assessment
9. Additional Resources

## 1. Introduction

Welcome to Lesson 25 of our comprehensive course on LLM Evaluation and Benchmarking. In this lesson, we'll delve into the critical topics of bias and fairness in Large Language Models (LLMs). As LLMs become increasingly influential in various aspects of our lives, from content generation to decision-making systems, understanding and mitigating biases in these models is crucial for ensuring equitable and responsible AI deployment.

## 2. Learning Objectives

By the end of this lesson, you should be able to:
- Explain the concept of bias in the context of LLMs
- Identify different types of biases that can occur in NLP models
- Understand various fairness metrics and their implications
- Implement techniques for detecting bias in LLMs
- Apply fairness metrics to evaluate model outputs
- Develop strategies for mitigating bias in LLMs
- Critically analyze the ethical implications of bias and fairness in AI systems

## 3. Theoretical Foundation

### 3.1 Understanding Bias in LLMs

Bias in Large Language Models refers to systematic errors or unfair preferences in model outputs that disproportionately affect certain groups or perspectives. These biases can stem from various sources:

1. **Training Data Bias**: 
   - Description: Biases present in the data used to train the model.
   - Example: If the training data predominantly contains texts written by a specific demographic group, the model may learn to generate or favor content that reflects that group's perspectives and experiences.

2. **Algorithmic Bias**: 
   - Description: Biases introduced by the model architecture or training process itself.
   - Example: Certain model architectures might be better at capturing some types of patterns over others, leading to biased representations.

3. **Deployment Bias**: 
   - Description: Biases introduced when the model is applied in specific contexts or domains.
   - Example: A model trained on formal text might perform poorly when deployed in a system that primarily deals with colloquial language.

4. **Historical Bias**: 
   - Description: Biases that reflect historical inequalities or societal prejudices.
   - Example: A model trained on historical texts might perpetuate outdated gender stereotypes or racial biases.

5. **Representation Bias**: 
   - Description: Biases resulting from unequal representation of different groups in the model's outputs.
   - Example: A language model consistently generating male pronouns for certain professions and female pronouns for others.

Understanding these sources of bias is crucial for developing effective detection and mitigation strategies.

### 3.2 Types of Bias in NLP

In the context of Natural Language Processing and LLMs, several specific types of bias can manifest:

1. **Gender Bias**: 
   - Description: Unfair treatment or representation based on gender.
   - Example: A model consistently associating certain professions (e.g., "doctor") with male pronouns and others (e.g., "nurse") with female pronouns.

2. **Racial Bias**: 
   - Description: Unfair treatment or representation based on race or ethnicity.
   - Example: A model generating more positive sentiments for names typically associated with certain racial groups.

3. **Age Bias**: 
   - Description: Unfair treatment or representation based on age.
   - Example: A model consistently using outdated or stereotypical language when generating text about older adults.

4. **Socioeconomic Bias**: 
   - Description: Unfair treatment or representation based on socioeconomic status.
   - Example: A model generating more sophisticated language for topics associated with higher socioeconomic status.

5. **Cultural Bias**: 
   - Description: Unfair treatment or representation based on cultural background.
   - Example: A model struggling to accurately interpret or generate text in dialects or cultural contexts underrepresented in its training data.

6. **Political Bias**: 
   - Description: Unfair treatment or representation based on political views.
   - Example: A model consistently generating more positive sentiment for news articles aligned with a particular political ideology.

7. **Religious Bias**: 
   - Description: Unfair treatment or representation based on religious beliefs.
   - Example: A model associating certain personality traits or behaviors more strongly with some religious groups than others.

8. **Ability Bias**: 
   - Description: Unfair treatment or representation based on physical or mental abilities.
   - Example: A model using ableist language or perpetuating stereotypes about people with disabilities.

Recognizing these types of biases is the first step towards developing more fair and inclusive language models.

### 3.3 Fairness Metrics and Definitions

Fairness in machine learning is a complex concept with multiple, sometimes conflicting, definitions. Here are some common fairness metrics and definitions used in the context of LLMs:

1. **Demographic Parity**: 
   - Description: The model's predictions should be independent of protected attributes (e.g., race, gender).
   - Formula: P(Ŷ=1 | A=0) = P(Ŷ=1 | A=1), where Ŷ is the prediction and A is the protected attribute.
   - Use Case: Ensuring that the model generates positive sentiment equally often for different demographic groups.

2. **Equal Opportunity**: 
   - Description: The true positive rates should be equal across protected groups.
   - Formula: P(Ŷ=1 | Y=1, A=0) = P(Ŷ=1 | Y=1, A=1), where Y is the true label.
   - Use Case: In a text classification task, ensuring that the model correctly identifies positive instances at equal rates across groups.

3. **Equalized Odds**: 
   - Description: Both true positive and false positive rates should be equal across protected groups.
   - Formula: P(Ŷ=1 | Y=y, A=0) = P(Ŷ=1 | Y=y, A=1) for y in {0,1}
   - Use Case: In sentiment analysis, ensuring that the model's accuracy is consistent across different demographic groups.

4. **Counterfactual Fairness**: 
   - Description: A model's prediction should remain the same if we change the protected attribute, all else being equal.
   - Use Case: Ensuring that changing names or pronouns in a text doesn't affect the model's output, unless directly relevant to the task.

5. **Group Fairness**: 
   - Description: The overall distribution of predictions should be similar across protected groups.
   - Use Case: Ensuring that the distribution of topics or sentiments generated by an LLM is similar across different demographic groups.

6. **Individual Fairness**: 
   - Description: Similar individuals should receive similar predictions.
   - Use Case: Ensuring that small, irrelevant changes to input text don't result in significantly different model outputs.

7. **Representation Fairness**: 
   - Description: The model's internal representations should not allow for the prediction of protected attributes.
   - Use Case: Ensuring that the model's learned embeddings don't encode information about protected attributes like gender or race.

These metrics provide different perspectives on fairness, and the choice of which to use depends on the specific application and ethical considerations of the task at hand. It's important to note that these metrics can sometimes be in tension with each other or with overall model performance, necessitating careful consideration and potential trade-offs in real-world applications.

## 4. Practical Implementation

Now, let's dive into the practical aspects of detecting bias, implementing fairness metrics, and mitigating bias in LLMs using Python.

### 4.1 Setting Up the Environment

First, we'll set up our Python environment with the necessary libraries:

```python
# File: setup.py

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
import numpy as np
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

def setup_environment():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    model_name = "gpt2-medium"  # You can change this to other models
    model = AutoModelForCausalLM.from_pretrained(model_name).to(device)
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    return model, tokenizer, device

# Usage
model, tokenizer, device = setup_environment()
```

### 4.2 Detecting Bias in LLMs

Let's implement a function to detect gender bias in occupation associations:

```python
# File: bias_detection.py

def detect_gender_bias(model, tokenizer, device, occupations, genders):
    results = {}
    for occupation in occupations:
        gender_probs = {}
        for gender in genders:
            prompt = f"The {occupation} is a"
            inputs = tokenizer(prompt, return_tensors="pt").to(device)
            with torch.no_grad():
                outputs = model(**inputs)
            
            gender_token_id = tokenizer.encode(f" {gender}")[0]
            gender_prob = torch.softmax(outputs.logits[0, -1], dim=0)[gender_token_id].item()
            gender_probs[gender] = gender_prob
        
        results[occupation] = gender_probs
    
    return results

# Usage example
occupations = ["doctor", "nurse", "engineer", "teacher", "CEO"]
genders = ["man", "woman"]

bias_results = detect_gender_bias(model, tokenizer, device, occupations, genders)

# Visualize results
plt.figure(figsize=(12, 6))
for occupation, probs in bias_results.items():
    plt.bar(occupation + " (Man)", probs["man"], color="blue", alpha=0.5)
    plt.bar(occupation + " (Woman)", probs["woman"], color="red", alpha=0.5)

plt.title("Gender Bias in Occupation Associations")
plt.ylabel("Probability")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
```

### 4.3 Implementing Fairness Metrics

Now, let's implement some fairness metrics:

```python
# File: fairness_metrics.py

def demographic_parity(y_pred, protected_attribute):
    """
    Compute demographic parity difference.
    A value close to 0 indicates better parity.
    """
    group_0 = y_pred[protected_attribute == 0]
    group_1 = y_pred[protected_attribute == 1]
    return np.mean(group_1) - np.mean(group_0)

def equal_opportunity(y_true, y_pred, protected_attribute):
    """
    Compute equal opportunity difference.
    A value close to 0 indicates better equality of opportunity.
    """
    cm_0 = confusion_matrix(y_true[protected_attribute == 0], y_pred[protected_attribute == 0])
    cm_1 = confusion_matrix(y_true[protected_attribute == 1], y_pred[protected_attribute == 1])
    
    tpr_0 = cm_0[1, 1] / (cm_0[1, 1] + cm_0[1, 0])
    tpr_1 = cm_1[1, 1] / (cm_1[1, 1] + cm_1[1, 0])
    
    return tpr_1 - tpr_0

def equalized_odds(y_true, y_pred, protected_attribute):
    """
    Compute equalized odds difference.
    A value close to 0 indicates better equalized odds.
    """
    cm_0 = confusion_matrix(y_true[protected_attribute == 0], y_pred[protected_attribute == 0])
    cm_1 = confusion_matrix(y_true[protected_attribute == 1], y_pred[protected_attribute == 1])
    
    tpr_0 = cm_0[1, 1] / (cm_0[1, 1] + cm_0[1, 0])
    tpr_1 = cm_1[1, 1] / (cm_1[1, 1] + cm_1[1, 0])
    
    fpr_0 = cm_0[0, 1] / (cm_0[0, 1] + cm_0[0, 0])
    fpr_1 = cm_1[0, 1] / (cm_1[0, 1] + cm_1[0, 0])
    
    return max(abs(tpr_1 - tpr_0), abs(fpr_1 - fpr_0))

# Usage example
y_true = np.array([0, 1, 1, 0, 1, 1, 0, 0])
y_pred = np.array([0, 1, 1, 0, 0, 1, 1, 0])
protected_attribute = np.array([0, 0, 0, 0, 1, 1, 1, 1])

print(f"Demographic Parity Difference: {demographic_parity(y_pred, protected_attribute):.4f}")
print(f"Equal Opportunity Difference: {equal_opportunity(y_true, y_pred, protected_attribute):.4f}")
print(f"Equalized Odds Difference: {equalized_odds(y_true, y_pred, protected_attribute):.4f}")
```

### 4.4 Bias Mitigation Strategies

Implementing bias mitigation strategies is crucial for developing fair LLMs. Here are some common approaches:

1. **Data Augmentation**:
   - Description: Enhance the training data with additional examples to balance representation.
   - Implementation:

```python
# File: bias_mitigation.py

def augment_data(text, protected_attributes):
    """
    Augment text by replacing protected attributes with alternatives.
    """
    for attr, alternatives in protected_attributes.items():
        for alt in alternatives:
            yield text.replace(attr, alt)

# Usage example
original_text = "The doctor told him to take the medicine."
protected_attributes = {
    "doctor": ["nurse", "physician", "surgeon"],
    "him": ["her", "them"]
}

augmented_texts = list(augment_data(original_text, protected_attributes))
for text in augmented_texts:
    print(text)
```

2. **Counterfactual Data Augmentation**:
   - Description: Generate counterfactual examples by changing protected attributes while keeping other content the same.
   - Implementation:

```python
def generate_counterfactuals(model, tokenizer, device, text, attribute_pairs):
    """
    Generate counterfactual examples by swapping protected attributes.
    """
    counterfactuals = []
    for attr1, attr2 in attribute_pairs:
        cf_text = text.replace(attr1, attr2)
        inputs = tokenizer(cf_text, return_tensors="pt").to(device)
        with torch.no_grad():
            outputs = model.generate(**inputs, max_length=100)
        cf_output = tokenizer.decode(outputs[0], skip_special_tokens=True)
        counterfactuals.append((cf_text, cf_output))
    return counterfactuals

# Usage example
text = "The man is a doctor."
attribute_pairs = [("man", "woman"), ("doctor", "nurse")]
counterfactuals = generate_counterfactuals(model, tokenizer, device, text, attribute_pairs)
for cf_input, cf_output in counterfactuals:
    print(f"Input: {cf_input}")
    print(f"Output: {cf_output}\n")
```

3. **Fine-tuning with Fairness Objectives**:
   - Description: Incorporate fairness metrics into the model's training objective.
   - Implementation: This typically involves modifying the model's loss function, which is beyond the scope of this basic example. However, here's a conceptual representation:

```python
def fairness_aware_loss(outputs, targets, protected_attributes, lambda_fairness):
    """
    Combine task loss with a fairness penalty term.
    """
    task_loss = compute_task_loss(outputs, targets)
    fairness_loss = compute_fairness_loss(outputs, protected_attributes)
    return task_loss + lambda_fairness * fairness_loss
```

4. **Post-processing Techniques**:
   - Description: Adjust model outputs to ensure fairness across groups.
   - Implementation:

```python
def adjust_thresholds(y_pred_prob, protected_attribute, target_tpr):
    """
    Adjust classification thresholds to achieve equal true positive rates.
    """
    thresholds = {}
    for group in [0, 1]:
        group_probs = y_pred_prob[protected_attribute == group]
        thresholds[group] = np.percentile(group_probs, (1 - target_tpr) * 100)
    
    y_pred_fair = np.where(protected_attribute == 0, 
                           y_pred_prob > thresholds[0],
                           y_pred_prob > thresholds[1])
    return y_pred_fair

# Usage example
y_pred_prob = np.random.rand(100)
protected_attribute = np.random.randint(0, 2, 100)
target_tpr = 0.8

y_pred_fair = adjust_thresholds(y_pred_prob, protected_attribute, target_tpr)
```

## 5. Cross-Platform Considerations

The code provided above should work across Windows, macOS, and Linux, as long as Python and the required libraries are installed. However, there are a few points to consider:

1. **GPU Support**: If you're using a GPU for model inference, ensure you have the appropriate CUDA drivers installed for your operating system.

2. **Visualization**: The matplotlib library used for visualizations may render differently across platforms. Consider using a backend that's compatible with your system (e.g., 'TkAgg' for most systems, 'Qt5Agg' for systems with Qt installed).

3. **File Paths**: When working with data files or saving outputs, use os.path.join() to create file paths that work across different operating systems.

4. **Docker**: For consistent environments across platforms, consider using Docker. Here's a simple Dockerfile:

```dockerfile
# File: Dockerfile

FROM python:3.8

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

CMD ["python", "main.py"]
```

Ensure you have a `requirements.txt` file listing all necessary Python packages.

## 6. Exercises and Projects

To reinforce your learning, try these exercises:

1. Implement a bias detection method for a different type of bias (e.g., racial bias in sentiment analysis).

2. Develop a more comprehensive fairness evaluation pipeline that combines multiple metrics and visualizes the results.

3. Create a data augmentation technique that addresses a specific type of bias in a given dataset.

4. Implement and compare different bias mitigation strategies on a real-world NLP task (e.g., text classification or generation).

5. Design an experiment to evaluate the trade-offs between model performance and fairness across different bias mitigation techniques.

## 7. Real-World Applications

Bias and fairness considerations in LLMs have numerous real-world applications:

1. **Hiring and Recruitment**: 
   - Description: Ensuring that AI-powered resume screening or job recommendation systems do not perpetuate gender or racial biases.
   - Example: Developing fair language models for analyzing job applications and generating job descriptions.

2. **Legal and Criminal Justice**: 
   - Description: Mitigating biases in AI systems used for risk assessment or legal document analysis.
   - Example: Implementing fairness-aware models for analyzing case law or predicting recidivism rates.

3. **Healthcare**: 
   - Description: Ensuring equitable performance of medical language models across different demographic groups.
   - Example: Developing unbiased models for analyzing medical records or generating clinical notes.

4. **Education**: 
   - Description: Creating fair automated grading or feedback systems that work equally well for students from diverse backgrounds.
   - Example: Implementing bias-aware language models for essay scoring or generating personalized learning content.

5. **Content Moderation**: 
   - Description: Developing hate speech detection models that are equally effective across different demographic groups and languages.
   - Example: Creating fairness-aware models for social media content moderation.

6. **Financial Services**: 
   - Description: Ensuring that AI-powered credit scoring or loan approval systems do not discriminate based on protected attributes.
   - Example: Developing fair language models for analyzing loan applications or financial documents.

7. **News and Media**: 
   - Description: Mitigating political or ideological biases in news recommendation systems or automated content generation.
   - Example: Implementing bias-aware models for news summarization or headline generation.

8. **Customer Service**: 
   - Description: Ensuring that AI chatbots and virtual assistants provide equitable service to all users.
   - Example: Developing fairness-aware language models for customer support interactions.

## 8. Assessment

To assess your understanding of bias and fairness in LLMs, consider the following questions and tasks:

1. Explain the difference between algorithmic bias and data bias in the context of LLMs. How might each type of bias manifest in a language model's outputs?

2. Implement a method to detect and quantify gender bias in a pre-trained language model's word embeddings.

3. Compare and contrast demographic parity and equal opportunity as fairness metrics. In what scenarios might you choose one over the other?

4. Design an experiment to evaluate the effectiveness of a bias mitigation strategy (e.g., data augmentation) on a specific NLP task. What metrics would you use to measure both task performance and fairness?

5. Discuss the potential limitations and drawbacks of current fairness metrics and bias mitigation strategies. How might these approaches fall short in real-world applications?

6. Analyze the ethical implications of deploying a biased language model in a high-stakes application (e.g., healthcare, criminal justice). What are the potential consequences, and how might they be mitigated?

7. Propose a novel approach to bias mitigation in LLMs that addresses some of the limitations of current methods. How would you evaluate its effectiveness?

## 9. Additional Resources

To deepen your understanding of bias and fairness in LLMs, consider exploring these resources:

1. Paper: "On Measuring Social Biases in Sentence Encoders" (May et al., 2019)
   - Description: This paper introduces the Word Embedding Association Test (WEAT) and its extensions for measuring biases in sentence encoders.
   - Link: [https://arxiv.org/abs/1903.10561](https://arxiv.org/abs/1903.10561)

2. Survey: "A Survey on Bias and Fairness in Machine Learning" (Mehrabi et al., 2021)
   - Description: This comprehensive survey covers various types of biases, fairness definitions, and mitigation strategies across different domains of machine learning.
   - Link: [https://arxiv.org/abs/1908.09635](https://arxiv.org/abs/1908.09635)

3. Tool: AI Fairness 360
   - Description: An open-source toolkit developed by IBM that includes a comprehensive set of fairness metrics and bias mitigation algorithms.
   - Link: [https://github.com/Trusted-AI/AIF360](https://github.com/Trusted-AI/AIF360)

4. Course: "Fairness in Machine Learning" by Moritz Hardt (UC Berkeley)
   - Description: This course provides a rigorous introduction to the study of fairness in machine learning, covering both theoretical foundations and practical considerations.
   - Link: [https://fairmlclass.github.io/](https://fairmlclass.github.io/)

5. Book: "Fairness and Machine Learning: Limitations and Opportunities" by Solon Barocas, Moritz Hardt, and Arvind Narayanan
   - Description: This freely available online book provides a comprehensive treatment of fairness in machine learning, including chapters specifically devoted to fairness in language models.
   - Link: [https://fairmlbook.org/](https://fairmlbook.org/)

6. Workshop: ACL Workshop on Gender Bias in Natural Language Processing
   - Description: This annual workshop focuses on understanding and mitigating gender bias in various NLP applications. Proceedings contain cutting-edge research papers on the topic.
   - Link: Search for the latest proceedings on the ACL Anthology website.

Remember, the field of bias and fairness in LLMs is rapidly evolving. Stay updated with the latest research papers, ethical guidelines, and industry practices to ensure responsible development and deployment of language models.
