# Lesson 24: Robustness and Adversarial Testing

## Table of Contents
1. Introduction
2. Learning Objectives
3. Theoretical Foundation
   3.1 Understanding Robustness in LLMs
   3.2 Adversarial Examples in NLP
   3.3 Importance of Robustness Testing
4. Practical Implementation
   4.1 Setting Up the Environment
   4.2 Creating Adversarial Examples
   4.3 Evaluating Model Robustness
5. Cross-Platform Considerations
6. Exercises and Projects
7. Real-World Applications
8. Assessment
9. Additional Resources

## 1. Introduction

Welcome to Lesson 24 of our comprehensive course on LLM Evaluation and Benchmarking. In this lesson, we'll explore the critical concepts of robustness and adversarial testing in the context of Large Language Models (LLMs). As LLMs become increasingly integrated into various applications, ensuring their reliability and resilience against potential attacks or unexpected inputs becomes paramount. This lesson will equip you with the knowledge and skills to evaluate and improve the robustness of LLMs.

## 2. Learning Objectives

By the end of this lesson, you should be able to:
- Explain the concept of robustness in the context of LLMs
- Understand various types of adversarial examples in natural language processing
- Implement techniques for creating adversarial examples
- Evaluate model robustness using different metrics and methodologies
- Develop strategies to improve model robustness
- Apply robustness and adversarial testing techniques to real-world LLM applications

## 3. Theoretical Foundation

### 3.1 Understanding Robustness in LLMs

Robustness in the context of Large Language Models refers to the model's ability to maintain consistent and accurate performance across a wide range of inputs, including those that may be noisy, out-of-distribution, or intentionally crafted to deceive the model. A robust LLM should:

1. **Handle Noise**: Maintain performance in the presence of typos, grammatical errors, or other forms of input noise.
2. **Generalize**: Perform well on inputs that may differ from its training distribution.
3. **Resist Adversarial Attacks**: Maintain integrity when faced with inputs designed to manipulate its output.
4. **Maintain Consistency**: Provide consistent outputs for semantically equivalent inputs.
5. **Handle Edge Cases**: Perform reasonably on extreme or unusual inputs.

Understanding and improving robustness is crucial for deploying LLMs in real-world scenarios where input quality and intentions cannot always be guaranteed.

### 3.2 Adversarial Examples in NLP

Adversarial examples are inputs specifically designed to cause a model to make errors. In the context of NLP and LLMs, adversarial examples can take various forms:

1. **Character-level Perturbations**: 
   - Description: These involve making small changes to the characters in words, such as swapping, inserting, or deleting characters.
   - Example: Changing "hello" to "helo" or "he11o".
   - Impact: Can trick models that rely heavily on exact word matching.

2. **Word-level Substitutions**: 
   - Description: Replacing words with synonyms or semantically similar words.
   - Example: Changing "The movie was great" to "The film was excellent".
   - Impact: Can reveal weaknesses in the model's understanding of semantic relationships.

3. **Sentence-level Transformations**: 
   - Description: Restructuring sentences while preserving their meaning.
   - Example: Changing active voice to passive voice, or reordering clauses.
   - Impact: Tests the model's ability to understand sentence structure and meaning.

4. **Addition of Irrelevant Information**: 
   - Description: Inserting text that doesn't change the core meaning but might distract the model.
   - Example: Adding "As I was saying earlier," before a sentence.
   - Impact: Tests the model's ability to focus on relevant information.

5. **Logical Contradictions**: 
   - Description: Creating inputs that contain logical inconsistencies.
   - Example: "The ball is both red and not red."
   - Impact: Assesses the model's logical reasoning capabilities.

6. **Context Manipulation**: 
   - Description: Altering the context in which certain words or phrases appear.
   - Example: Using words with multiple meanings in ambiguous contexts.
   - Impact: Tests the model's understanding of context and disambiguation abilities.

### 3.3 Importance of Robustness Testing

Robustness testing is crucial for several reasons:

1. **Safety and Reliability**: 
   - Description: Robust models are less likely to fail unexpectedly in real-world applications.
   - Importance: Critical for applications in healthcare, finance, or autonomous systems where errors could have severe consequences.

2. **Fairness and Bias Mitigation**: 
   - Description: Robustness testing can reveal biases in model responses across different demographic groups or input styles.
   - Importance: Ensures that the model performs consistently and fairly for all users.

3. **Security**: 
   - Description: Identifies vulnerabilities that could be exploited by malicious actors.
   - Importance: Prevents potential misuse of the model in security-critical applications.

4. **Generalization**: 
   - Description: Robust models are more likely to perform well on new, unseen data.
   - Importance: Enhances the model's applicability across diverse use cases.

5. **Trust and Adoption**: 
   - Description: Demonstrating robustness increases user confidence in the model.
   - Importance: Facilitates wider adoption of LLM technologies in various industries.

6. **Continuous Improvement**: 
   - Description: Robustness testing provides insights into model weaknesses, guiding future improvements.
   - Importance: Drives the ongoing development and refinement of LLM technologies.

## 4. Practical Implementation

Now, let's dive into the practical aspects of implementing robustness and adversarial testing for LLMs using Python.

### 4.1 Setting Up the Environment

First, we'll set up our Python environment with the necessary libraries:

```python
# File: setup.py

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
import nltk
from nltk.corpus import wordnet
import random

# Download necessary NLTK data
nltk.download('wordnet')
nltk.download('averaged_perceptron_tagger')

def setup_environment():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    model_name = "gpt2-medium"  # You can change this to other models
    model = AutoModelForCausalLM.from_pretrained(model_name).to(device)
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    return model, tokenizer, device

# Usage
model, tokenizer, device = setup_environment()
```

### 4.2 Creating Adversarial Examples

Now, let's implement functions to create different types of adversarial examples:

```python
# File: adversarial_examples.py

import random
import string

def character_perturbation(text, prob=0.1):
    """
    Introduce character-level perturbations to the input text.
    
    Args:
    text (str): Input text
    prob (float): Probability of perturbing each character
    
    Returns:
    str: Perturbed text
    """
    perturbed_text = ""
    for char in text:
        if random.random() < prob:
            action = random.choice(["swap", "insert", "delete"])
            if action == "swap" and len(perturbed_text) > 0:
                perturbed_text = perturbed_text[:-1] + char + perturbed_text[-1]
            elif action == "insert":
                perturbed_text += random.choice(string.ascii_lowercase) + char
            # For "delete", we simply skip adding the character
        else:
            perturbed_text += char
    return perturbed_text

def word_substitution(text, prob=0.2):
    """
    Substitute words with their synonyms.
    
    Args:
    text (str): Input text
    prob (float): Probability of substituting each word
    
    Returns:
    str: Text with word substitutions
    """
    words = text.split()
    for i, word in enumerate(words):
        if random.random() < prob:
            synsets = wordnet.synsets(word)
            if synsets:
                synonym = random.choice(synsets).lemmas()[0].name()
                words[i] = synonym
    return " ".join(words)

def add_irrelevant_info(text):
    """
    Add irrelevant information to the input text.
    
    Args:
    text (str): Input text
    
    Returns:
    str: Text with added irrelevant information
    """
    irrelevant_phrases = [
        "As I was saying earlier, ",
        "In my humble opinion, ",
        "Not to change the subject, but ",
        "On an unrelated note, ",
        "By the way, "
    ]
    return random.choice(irrelevant_phrases) + text

# Usage example
original_text = "The movie was great and I enjoyed it thoroughly."
perturbed_text = character_perturbation(original_text)
substituted_text = word_substitution(original_text)
irrelevant_text = add_irrelevant_info(original_text)

print(f"Original: {original_text}")
print(f"Character Perturbation: {perturbed_text}")
print(f"Word Substitution: {substituted_text}")
print(f"Added Irrelevant Info: {irrelevant_text}")
```

### 4.3 Evaluating Model Robustness

Now, let's implement a function to evaluate model robustness:

```python
# File: robustness_evaluation.py

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

def evaluate_robustness(model, tokenizer, device, original_text, adversarial_texts):
    """
    Evaluate model robustness by comparing outputs for original and adversarial inputs.
    
    Args:
    model: The language model
    tokenizer: The tokenizer for the model
    device: The device to run the model on
    original_text (str): The original input text
    adversarial_texts (list): List of adversarial versions of the input text
    
    Returns:
    dict: Evaluation results
    """
    def get_model_output(text):
        inputs = tokenizer(text, return_tensors="pt").to(device)
        with torch.no_grad():
            outputs = model.generate(**inputs, max_length=50, num_return_sequences=1)
        return tokenizer.decode(outputs[0], skip_special_tokens=True)

    original_output = get_model_output(original_text)
    adversarial_outputs = [get_model_output(text) for text in adversarial_texts]

    # Calculate similarity between original and adversarial outputs
    similarities = [len(set(original_output.split()) & set(adv_output.split())) / len(set(original_output.split() + adv_output.split())) 
                    for adv_output in adversarial_outputs]

    return {
        "original_text": original_text,
        "original_output": original_output,
        "adversarial_texts": adversarial_texts,
        "adversarial_outputs": adversarial_outputs,
        "similarities": similarities,
        "average_similarity": sum(similarities) / len(similarities)
    }

# Usage example
model, tokenizer, device = setup_environment()

original_text = "The movie was great and I enjoyed it thoroughly."
adversarial_texts = [
    character_perturbation(original_text),
    word_substitution(original_text),
    add_irrelevant_info(original_text)
]

results = evaluate_robustness(model, tokenizer, device, original_text, adversarial_texts)

print(f"Original Text: {results['original_text']}")
print(f"Original Output: {results['original_output']}")
print("\nAdversarial Examples:")
for i, (adv_text, adv_output, similarity) in enumerate(zip(results['adversarial_texts'], results['adversarial_outputs'], results['similarities'])):
    print(f"\nExample {i+1}:")
    print(f"Adversarial Text: {adv_text}")
    print(f"Adversarial Output: {adv_output}")
    print(f"Similarity to Original Output: {similarity:.2f}")
print(f"\nAverage Similarity: {results['average_similarity']:.2f}")
```

## 5. Cross-Platform Considerations

The code provided above should work across Windows, macOS, and Linux, as long as Python and the required libraries are installed. However, there are a few points to consider:

1. **NLTK Data**: The NLTK data is downloaded to a default location that may vary across operating systems. You might need to specify a custom download directory on some systems.

2. **GPU Support**: If you're using a GPU, ensure you have the appropriate CUDA drivers installed for your operating system.

3. **Virtual Environments**: It's recommended to use virtual environments to manage dependencies. The process is slightly different across platforms:
   - Windows: `python -m venv myenv` then `myenv\Scripts\activate`
   - macOS/Linux: `python3 -m venv myenv` then `source myenv/bin/activate`

4. **Docker**: For consistent environments across platforms, consider using Docker. Here's a simple Dockerfile:

```dockerfile
# File: Dockerfile

FROM python:3.8

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

# Download NLTK data
RUN python -c "import nltk; nltk.download('wordnet'); nltk.download('averaged_perceptron_tagger')"

COPY . .

CMD ["python", "main.py"]
```

Ensure you have a `requirements.txt` file listing all necessary Python packages.

## 6. Exercises and Projects

To reinforce your learning, try these exercises:

1. Implement additional adversarial example generation techniques, such as sentence-level transformations or logical contradictions.

2. Evaluate the robustness of different pre-trained models (e.g., GPT-2, BERT, T5) using the same set of adversarial examples. Compare their performance.

3. Create a visualization tool that shows the differences between original and adversarial inputs, and their respective model outputs.

4. Implement a fine-tuning procedure that incorporates adversarial examples to improve model robustness.

5. Develop a command-line tool that allows users to input text and generate various types of adversarial examples.

## 7. Real-World Applications

Robustness and adversarial testing have numerous real-world applications:

1. **Cybersecurity**: 
   - Description: Identifying and mitigating vulnerabilities in NLP-based security systems.
   - Example: Testing robustness of spam filters or phishing detection systems.

2. **Healthcare**: 
   - Description: Ensuring reliability of LLMs used in medical diagnosis or treatment recommendation systems.
   - Example: Evaluating robustness of models that analyze medical records or assist in clinical decision-making.

3. **Finance**: 
   - Description: Enhancing the security of language models used in financial analysis or fraud detection.
   - Example: Testing robustness of models used for sentiment analysis of financial news or reports.

4. **Legal Tech**: 
   - Description: Improving the reliability of LLMs used in legal document analysis or contract review.
   - Example: Evaluating robustness of models that summarize legal documents or extract key clauses.

5. **Education**: 
   - Description: Ensuring fairness and consistency in automated grading or feedback systems.
   - Example: Testing robustness of models used to assess student essays or provide tutoring.

6. **Customer Service**: 
   - Description: Enhancing the reliability of chatbots and virtual assistants in handling diverse and potentially adversarial user inputs.
   - Example: Testing robustness of models used in customer support chatbots against intentionally confusing or misleading queries.

7. **Content Moderation**: 
   - Description: Improving the effectiveness of automated content moderation systems in detecting subtle violations or evasion attempts.
   - Example: Evaluating robustness of models used to flag inappropriate content on social media platforms.

8. **Automated Journalism**: 
   - Description: Ensuring the reliability and factual consistency of AI-generated news articles across various topics and writing styles.
   - Example: Testing robustness of models used to generate news summaries or reports from data inputs.

## 8. Assessment

To assess your understanding of robustness and adversarial testing in LLMs, consider the following questions and tasks:

1. Explain the concept of robustness in the context of LLMs. How does it differ from traditional accuracy metrics?

2. Describe three different types of adversarial examples in NLP and explain how each might affect an LLM's performance.

3. Implement a new type of adversarial example generation not covered in the lesson (e.g., sentence-level transformations). Explain your approach and demonstrate its effect on a pre-trained model.

4. Analyze the trade-offs between model performance on clean data versus robustness to adversarial examples. How might you balance these concerns in a real-world application?

5. Design an experiment to evaluate the robustness of an LLM across different domains (e.g., news articles, social media posts, technical documentation). What metrics would you use, and how would you interpret the results?

6. Discuss the ethical implications of adversarial testing in LLMs. Are there potential negative consequences of making models more robust to certain types of inputs?

7. Propose a method to improve an LLM's robustness without access to its training data or architecture. How would you validate the effectiveness of your approach?

## 9. Additional Resources

To deepen your understanding of robustness and adversarial testing in LLMs, consider exploring these resources:

1. Paper: "Adversarial Examples Are Not Bugs, They Are Features" (Ilyas et al., 2019)
   - Description: This paper provides a thought-provoking perspective on adversarial examples, arguing that they are a consequence of models learning robust features that generalize across datasets.
   - Link: [https://arxiv.org/abs/1905.02175](https://arxiv.org/abs/1905.02175)

2. Survey: "Adversarial Attacks and Defenses in Images, Graphs and Text: A Review" (Xu et al., 2020)
   - Description: This comprehensive survey covers adversarial attacks and defenses across various domains, including text. It provides a broad overview of the field and is an excellent starting point for in-depth study.
   - Link: [https://arxiv.org/abs/1909.08072](https://arxiv.org/abs/1909.08072)

3. Tool: TextAttack
   - Description: TextAttack is a Python framework for adversarial attacks, adversarial training, and data augmentation in NLP. It provides implementations of various attack methods and can be used to evaluate model robustness.
   - Link: [https://github.com/QData/TextAttack](https://github.com/QData/TextAttack)

4. Blog Post: "Adversarial Examples in NLP" by Hugging Face
   - Description: This blog post provides an accessible introduction to adversarial examples in NLP, with practical examples using the Transformers library.
   - Link: [https://huggingface.co/blog/adversarial-examples-in-nlp](https://huggingface.co/blog/adversarial-examples-in-nlp)

5. Course: "Adversarial Machine Learning" by Nicolas Papernot (University of Toronto)
   - Description: While not specific to NLP, this course provides a comprehensive introduction to adversarial machine learning, covering many concepts applicable to LLMs.
   - Link: [https://www.cleverhans.io/](https://www.cleverhans.io/)

6. Book Chapter: "Adversarial Examples in Deep Learning" in "Deep Learning for NLP and Speech Recognition" (2019)
   - Description: This book chapter provides a detailed overview of adversarial examples in deep learning, with sections specifically devoted to NLP applications.
   - Link: Available in the book "Deep Learning for NLP and Speech Recognition" by Uday Kamath et al.

Remember, the field of robustness and adversarial testing in LLMs is rapidly evolving. Stay updated with the latest research papers and industry practices to keep your skills sharp and relevant.
