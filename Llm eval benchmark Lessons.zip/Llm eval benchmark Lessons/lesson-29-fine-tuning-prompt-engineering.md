# Lesson 29: Fine-tuning Efficiency and Prompt Engineering

## Learning Objectives

By the end of this lesson, students will be able to:
1. Understand the concept of fine-tuning in the context of Large Language Models (LLMs)
2. Implement efficient fine-tuning techniques for LLMs
3. Comprehend the principles of prompt engineering
4. Design effective prompts for various NLP tasks
5. Evaluate the impact of fine-tuning and prompt engineering on LLM performance

## 1. Introduction to Fine-tuning

Fine-tuning is a crucial technique in adapting pre-trained LLMs to specific tasks or domains. It involves further training a pre-trained model on a smaller, task-specific dataset to optimize its performance for particular applications.

### 1.1 Why Fine-tune?

Fine-tuning allows us to leverage the knowledge captured in large pre-trained models while adapting them to specific use cases. This approach offers several advantages:

- Reduced training time compared to training from scratch
- Lower computational resources required
- Improved performance on domain-specific tasks
- Ability to adapt to new data distributions or linguistic patterns

### 1.2 Challenges in Fine-tuning

While fine-tuning is powerful, it comes with its own set of challenges:

- Overfitting: The model may adapt too closely to the fine-tuning data, losing its generalization ability.
- Catastrophic forgetting: The model might forget previously learned knowledge during fine-tuning.
- Computational cost: Even though it's more efficient than training from scratch, fine-tuning can still be resource-intensive for large models.

## 2. Efficient Fine-tuning Techniques

To address the challenges mentioned above and optimize the fine-tuning process, we'll explore several efficient fine-tuning techniques.

### 2.1 Gradual Unfreezing

Gradual unfreezing involves progressively unfreezing layers of the model during fine-tuning, starting from the output layer and moving towards the input layer.

```python
import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer, Trainer, TrainingArguments

def gradual_unfreeze(model, num_layers_to_unfreeze):
    for param in model.parameters():
        param.requires_grad = False
    
    for i, layer in enumerate(reversed(list(model.bert.encoder.layer))):
        if i < num_layers_to_unfreeze:
            for param in layer.parameters():
                param.requires_grad = True
        else:
            break

# Load pre-trained model and tokenizer
model_name = "bert-base-uncased"
model = AutoModelForSequenceClassification.from_pretrained(model_name)
tokenizer = AutoTokenizer.from_pretrained(model_name)

# Gradually unfreeze layers
num_layers_to_unfreeze = 3
gradual_unfreeze(model, num_layers_to_unfreeze)

# Set up training arguments and trainer
training_args = TrainingArguments(
    output_dir="./results",
    num_train_epochs=3,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=64,
    warmup_steps=500,
    weight_decay=0.01,
    logging_dir="./logs",
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
)

# Start fine-tuning
trainer.train()
```

This technique helps prevent catastrophic forgetting and allows the model to adapt gradually to the new task.

### 2.2 Layer-wise Learning Rate Decay

Layer-wise learning rate decay involves using different learning rates for different layers of the model, typically with lower learning rates for earlier layers and higher rates for later layers.

```python
from torch.optim import AdamW
from transformers import get_linear_schedule_with_warmup

def get_optimizer_grouped_parameters(model, learning_rate, weight_decay):
    no_decay = ["bias", "LayerNorm.weight"]
    optimizer_grouped_parameters = []
    
    for i, layer in enumerate(model.bert.encoder.layer):
        layer_params = list(layer.named_parameters())
        layer_lr = learning_rate * (0.9 ** (len(model.bert.encoder.layer) - i - 1))
        
        optimizer_grouped_parameters.extend([
            {
                "params": [p for n, p in layer_params if not any(nd in n for nd in no_decay)],
                "weight_decay": weight_decay,
                "lr": layer_lr,
            },
            {
                "params": [p for n, p in layer_params if any(nd in n for nd in no_decay)],
                "weight_decay": 0.0,
                "lr": layer_lr,
            },
        ])
    
    return optimizer_grouped_parameters

# Set up optimizer with layer-wise learning rate decay
learning_rate = 2e-5
weight_decay = 0.01
optimizer_grouped_parameters = get_optimizer_grouped_parameters(model, learning_rate, weight_decay)
optimizer = AdamW(optimizer_grouped_parameters)

# Set up learning rate scheduler
num_training_steps = len(train_dataloader) * num_epochs
scheduler = get_linear_schedule_with_warmup(
    optimizer,
    num_warmup_steps=0,
    num_training_steps=num_training_steps
)
```

This approach allows for more flexible adaptation of different parts of the model, potentially leading to better performance and stability during fine-tuning.

### 2.3 Parameter-Efficient Fine-tuning (PEFT)

PEFT techniques aim to reduce the number of trainable parameters during fine-tuning, making the process more efficient and less prone to overfitting. We'll explore two popular PEFT methods:

#### 2.3.1 Adapter Layers

Adapter layers are small neural networks inserted between the layers of a pre-trained model. During fine-tuning, only the adapter layers are trained, keeping the original model parameters frozen.

```python
from transformers import AutoModelForSequenceClassification
from transformers.adapters import AdapterConfig, AutoAdapterModel

# Load pre-trained model
model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased")

# Convert to adapter model
model = AutoAdapterModel.from_pretrained(model)

# Add and activate adapter
adapter_config = AdapterConfig(hidden_size=768, adapter_size=64)
model.add_adapter("task_adapter", config=adapter_config)
model.train_adapter("task_adapter")

# Fine-tune the model (only adapter parameters will be updated)
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
)
trainer.train()
```

Adapter layers significantly reduce the number of trainable parameters while still allowing the model to adapt to new tasks.

#### 2.3.2 LoRA (Low-Rank Adaptation)

LoRA is another PEFT technique that adds low-rank decomposition matrices to the weights of the pre-trained model. These matrices are trained during fine-tuning, allowing for efficient adaptation.

```python
from peft import get_peft_model, LoraConfig, TaskType

# Define LoRA configuration
peft_config = LoraConfig(
    task_type=TaskType.SEQ_CLS,
    inference_mode=False,
    r=8,
    lora_alpha=32,
    lora_dropout=0.1,
)

# Load pre-trained model and apply LoRA
model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased")
model = get_peft_model(model, peft_config)

# Fine-tune the model (only LoRA parameters will be updated)
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
)
trainer.train()
```

LoRA allows for efficient fine-tuning with a minimal increase in parameter count, making it suitable for resource-constrained environments.

## 3. Prompt Engineering

Prompt engineering is the practice of designing and optimizing input prompts to elicit desired outputs from LLMs. It's a crucial skill for effectively utilizing LLMs across various tasks.

### 3.1 Principles of Effective Prompt Design

When designing prompts, consider the following principles:

1. Clarity: Ensure the prompt is clear and unambiguous.
2. Specificity: Provide enough context and details for the desired task.
3. Consistency: Use a consistent format and style across similar prompts.
4. Task-orientation: Clearly state the expected output or task.
5. Examples: Include examples or demonstrations when appropriate.

### 3.2 Prompt Templates

Prompt templates provide a structured way to generate prompts for specific tasks. Here's an example of a prompt template for sentiment analysis:

```python
def sentiment_analysis_prompt(text):
    return f"""Analyze the sentiment of the following text. Classify it as positive, negative, or neutral.

Text: "{text}"

Sentiment:"""

# Example usage
review = "The movie was absolutely fantastic! I loved every minute of it."
prompt = sentiment_analysis_prompt(review)
print(prompt)
```

This template ensures consistency across different inputs and clearly communicates the task to the model.

### 3.3 Few-shot Prompting

Few-shot prompting involves providing the model with a few examples of the task before asking it to perform the task on a new input. This technique can significantly improve performance, especially for complex or ambiguous tasks.

```python
def few_shot_classification_prompt(text, label_options):
    examples = [
        ("The food was delicious and the service was excellent.", "Positive"),
        ("I waited for an hour and the meal was cold.", "Negative"),
        ("The restaurant was okay, nothing special.", "Neutral")
    ]
    
    prompt = "Classify the sentiment of the following reviews:\n\n"
    
    for example, label in examples:
        prompt += f"Review: {example}\nSentiment: {label}\n\n"
    
    prompt += f"Review: {text}\nSentiment:"
    
    return prompt

# Example usage
new_review = "The atmosphere was great, but the food was mediocre."
prompt = few_shot_classification_prompt(new_review, ["Positive", "Negative", "Neutral"])
print(prompt)
```

Few-shot prompting helps the model understand the task better by providing context and examples.

### 3.4 Chain-of-Thought Prompting

Chain-of-thought prompting encourages the model to break down complex problems into smaller steps, improving its reasoning capabilities.

```python
def chain_of_thought_prompt(question):
    return f"""Solve the following problem step by step:

Problem: {question}

Let's approach this step-by-step:
1)
2)
3)
...

Therefore, the final answer is:"""

# Example usage
math_problem = "If a train travels 120 km in 2 hours, what is its average speed in km/h?"
prompt = chain_of_thought_prompt(math_problem)
print(prompt)
```

This technique is particularly useful for mathematical problems, logical reasoning tasks, and other complex queries that benefit from a structured approach.

## 4. Evaluating Fine-tuning and Prompt Engineering

To assess the effectiveness of fine-tuning and prompt engineering techniques, we need to implement robust evaluation methods.

### 4.1 Metrics for Fine-tuning Evaluation

When evaluating fine-tuned models, consider the following metrics:

1. Task-specific metrics (e.g., accuracy, F1 score, BLEU score)
2. Inference time and model size
3. Generalization to out-of-domain data
4. Retention of original capabilities

```python
from sklearn.metrics import accuracy_score, f1_score
import time

def evaluate_fine_tuned_model(model, eval_dataloader, tokenizer):
    model.eval()
    predictions = []
    true_labels = []
    inference_times = []
    
    with torch.no_grad():
        for batch in eval_dataloader:
            inputs = tokenizer(batch['text'], padding=True, truncation=True, return_tensors="pt")
            start_time = time.time()
            outputs = model(**inputs)
            end_time = time.time()
            
            predictions.extend(outputs.logits.argmax(dim=-1).tolist())
            true_labels.extend(batch['label'])
            inference_times.append(end_time - start_time)
    
    accuracy = accuracy_score(true_labels, predictions)
    f1 = f1_score(true_labels, predictions, average='weighted')
    avg_inference_time = sum(inference_times) / len(inference_times)
    
    return {
        'accuracy': accuracy,
        'f1_score': f1,
        'avg_inference_time': avg_inference_time,
        'model_size': sum(p.numel() for p in model.parameters())
    }

# Example usage
results = evaluate_fine_tuned_model(fine_tuned_model, eval_dataloader, tokenizer)
print(results)
```

### 4.2 Prompt Engineering Evaluation

For prompt engineering, consider these evaluation criteria:

1. Task completion rate
2. Output quality and relevance
3. Consistency across different inputs
4. Robustness to slight variations in prompts

```python
import random

def evaluate_prompt_template(model, prompt_template, eval_data, num_samples=100):
    successful_completions = 0
    total_relevance_score = 0
    
    for _ in range(num_samples):
        sample = random.choice(eval_data)
        prompt = prompt_template(sample['input'])
        output = model.generate(prompt)
        
        # Evaluate task completion and relevance (this would typically involve human evaluation or a separate classifier)
        task_completed = evaluate_task_completion(output, sample['expected_output'])
        relevance_score = evaluate_relevance(output, sample['input'])
        
        if task_completed:
            successful_completions += 1
        total_relevance_score += relevance_score
    
    completion_rate = successful_completions / num_samples
    avg_relevance_score = total_relevance_score / num_samples
    
    return {
        'completion_rate': completion_rate,
        'avg_relevance_score': avg_relevance_score
    }

# Example usage
results = evaluate_prompt_template(llm_model, sentiment_analysis_prompt, eval_dataset)
print(results)
```

## 5. Practical Exercise

To reinforce the concepts learned in this lesson, students will complete the following exercise:

1. Choose a pre-trained language model (e.g., BERT, RoBERTa, GPT-2) and a specific NLP task (e.g., sentiment analysis, named entity recognition).
2. Implement at least two efficient fine-tuning techniques discussed in the lesson.
3. Design a prompt template and implement few-shot prompting for the chosen task.
4. Evaluate the performance of both the fine-tuned models and the prompt engineering approach using appropriate metrics.
5. Compare the results and discuss the trade-offs between fine-tuning and prompt engineering for your specific task.

## 6. Additional Resources

To deepen your understanding of fine-tuning efficiency and prompt engineering, explore these resources:

1. "Parameter-Efficient Transfer Learning for NLP" by Houlsby et al. (2019)
2. "LoRA: Low-Rank Adaptation of Large Language Models" by Hu et al. (2021)
3. "Prompt Engineering Guide" by Dair.ai
4. "The Power of Scale for Parameter-Efficient Prompt Tuning" by Lester et al. (2021)
5. "Scaling Instruction-Finetuned Language