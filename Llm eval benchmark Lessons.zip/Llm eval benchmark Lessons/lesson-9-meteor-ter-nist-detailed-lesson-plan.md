# Lesson 9: METEOR, TER, and NIST

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand the concepts behind METEOR, TER, and NIST metrics and their role in NLP evaluation.
2. Implement these metrics in Python, demonstrating practical coding skills in advanced NLP evaluation techniques.
3. Compare and contrast METEOR, TER, and NIST with previously learned metrics like BLEU and ROUGE, developing a nuanced understanding of evaluation strategies.
4. Apply these metrics to evaluate machine translation and text generation tasks, gaining hands-on experience with real-world NLP applications.
5. Analyze the strengths and limitations of each metric, fostering critical thinking about evaluation methodologies in NLP.

## 1. Introduction (15 minutes)

### Overview of advanced evaluation metrics
In previous lessons, we explored BLEU and ROUGE as fundamental metrics for evaluating text generation and machine translation. While these metrics are widely used, they have limitations. METEOR, TER, and NIST are additional metrics that address some of these limitations and provide alternative perspectives on text quality.

- METEOR (Metric for Evaluation of Translation with Explicit ORdering) incorporates semantic similarity and word order, going beyond simple n-gram matching.
- TER (Translation Edit Rate) focuses on the number of edits required to transform the generated text into the reference, providing an intuitive measure of translation effort.
- NIST (named after the National Institute of Standards and Technology) is an enhanced version of BLEU that gives more weight to rarer n-grams.

### Importance of multiple metrics
Using multiple metrics is crucial for a comprehensive evaluation of language models for several reasons:

1. Complementary perspectives: Each metric captures different aspects of text quality. Using multiple metrics provides a more rounded view of performance.
2. Robustness: Different metrics may be sensitive to different types of errors or improvements. Using multiple metrics increases the chances of detecting meaningful changes in model performance.
3. Task-specific relevance: Some metrics may be more appropriate for certain tasks or languages. Having a range of metrics allows for more flexible and appropriate evaluation across different scenarios.
4. Addressing limitations: Each metric has its own limitations. By using multiple metrics, we can often compensate for the weaknesses of individual metrics.
5. Correlation with human judgment: Different metrics may correlate with human judgments to varying degrees for different tasks. Using multiple metrics increases the likelihood of capturing aspects of quality that align with human perceptions.

## 2. METEOR (Metric for Evaluation of Translation with Explicit ORdering) (45 minutes)

### Concept and motivation
METEOR was developed to address several limitations of earlier metrics like BLEU:

1. Lack of recall: BLEU only considers precision, while METEOR balances precision and recall.
2. Exact match requirement: BLEU requires exact word matches, while METEOR incorporates synonymy and paraphrasing.
3. Lack of explicit word order consideration: METEOR includes a penalty for out-of-order matches.

The key idea behind METEOR is to create a flexible alignment between the hypothesis and reference translations, allowing for synonyms and paraphrases.

### METEOR calculation
The METEOR score is calculated through the following steps:

1. Alignment: Create a mapping between words in the hypothesis and reference translations. This alignment process considers exact matches, stemmed matches, synonym matches, and paraphrase matches.

2. Precision and Recall: Calculate precision (P) and recall (R) based on the number of matched unigrams:
   P = (number of matched unigrams in hypothesis) / (total unigrams in hypothesis)
   R = (number of matched unigrams in reference) / (total unigrams in reference)

3. Harmonic Mean: Compute the harmonic mean of precision and recall:
   F-mean = (10 * P * R) / (R + 9P)

4. Penalty: Calculate a penalty for fragmented matches:
   Penalty = 0.5 * (number of chunks / number of matched unigrams)^3

5. Final Score: Compute the final METEOR score:
   METEOR = F-mean * (1 - Penalty)

This process allows METEOR to capture semantic similarity and word order, providing a more nuanced evaluation than simple n-gram matching.

### Implementing METEOR in Python
Here's a basic implementation of METEOR using the `nltk` library:

```python
import nltk
from nltk.translate import meteor_score
from nltk.tokenize import word_tokenize

nltk.download('wordnet')
nltk.download('omw-1.4')

def calculate_meteor(reference, hypothesis):
    """
    Calculate METEOR score for a given reference and hypothesis.
    
    Args:
    reference (str): The reference translation
    hypothesis (str): The hypothesis translation to be evaluated
    
    Returns:
    float: The METEOR score
    """
    return meteor_score.meteor_score([word_tokenize(reference)], word_tokenize(hypothesis))

# Example usage
reference = "The cat is on the mat."
hypothesis = "There is a cat on the mat."

score = calculate_meteor(reference, hypothesis)
print(f"METEOR score: {score:.4f}")
```

This implementation uses NLTK's built-in METEOR implementation, which handles the complexities of synonym matching and alignment.

### Interpreting METEOR scores
METEOR scores range from 0 to 1, with 1 indicating a perfect match. When interpreting METEOR scores:

- Higher scores generally indicate better quality translations or summaries.
- METEOR tends to correlate better with human judgments compared to BLEU, especially for segment-level evaluation.
- METEOR is particularly useful for evaluating translations into English due to its use of WordNet for synonym matching.
- Scores should be compared within the same language pair and task, as absolute values can vary across different settings.

### Advantages and limitations of METEOR
Advantages:
1. Incorporates semantic similarity through synonym matching
2. Considers both precision and recall
3. Accounts for word order through its penalty mechanism
4. Generally correlates well with human judgments

Limitations:
1. Computationally more expensive than simpler metrics like BLEU
2. Requires language-specific resources (like WordNet) for optimal performance
3. May not capture some aspects of fluency or grammaticality
4. Can be overly lenient in some cases due to its flexible matching

## 3. TER (Translation Edit Rate) (45 minutes)

### Concept and motivation
Translation Edit Rate (TER) was developed to provide a more intuitive measure of translation quality. The core idea is to measure the amount of editing that a human would have to perform to change a machine translation output into an exact match with a reference translation.

TER is motivated by the desire to:
1. Provide a metric that aligns closely with the effort required to post-edit translations
2. Capture word order and structural differences more explicitly than n-gram based metrics
3. Offer an intuitive interpretation of translation quality

### TER calculation
TER is calculated as the minimum number of edits required to change the hypothesis into the reference, normalized by the length of the reference. The types of edits considered are:

1. Insertion: Adding a word
2. Deletion: Removing a word
3. Substitution: Replacing one word with another
4. Shift: Moving a word or phrase to a different position

The TER score is computed as follows:

TER = (Number of edits) / (Number of words in reference)

A lower TER score indicates a better translation, as it requires fewer edits to match the reference.

### Implementing TER in Python
Here's a basic implementation of TER using the `pyter` library:

```python
from pyter import ter

def calculate_ter(reference, hypothesis):
    """
    Calculate TER score for a given reference and hypothesis.
    
    Args:
    reference (str): The reference translation
    hypothesis (str): The hypothesis translation to be evaluated
    
    Returns:
    float: The TER score
    """
    return ter(hypothesis.split(), reference.split())

# Example usage
reference = "The cat is on the mat."
hypothesis = "There is a cat on the mat."

score = calculate_ter(reference, hypothesis)
print(f"TER score: {score:.4f}")
```

This implementation uses the `pyter` library, which provides an efficient implementation of TER.

### Interpreting TER scores
TER scores are interpreted as follows:

- The score represents the edit distance as a fraction of the reference length.
- Lower scores indicate better translations (fewer edits required).
- A score of 0 means the hypothesis exactly matches the reference.
- Scores can exceed 1 if more edits are required than there are words in the reference.

When using TER:
- Compare scores within the same language pair and task.
- Consider that TER may penalize valid paraphrases or alternative translations.


### Advantages and limitations of TER
Advantages of TER:
1. Intuitive interpretation: TER scores directly relate to the amount of post-editing required, making them easily understandable for non-experts.
2. Sensitivity to word order: Unlike n-gram based metrics, TER explicitly accounts for word order through its shift operation.
3. Language-independent: TER can be applied to any language pair without requiring language-specific resources.
4. Correlates with human effort: TER often aligns well with the actual effort required for post-editing, making it valuable for estimating translation costs.

Limitations of TER:
1. Binary match criterion: TER considers only exact matches, potentially penalizing semantically correct but lexically different translations.
2. Lack of semantic consideration: Unlike METEOR, TER doesn't account for synonyms or paraphrases.
3. Sensitivity to reference choice: TER scores can vary significantly based on the chosen reference translation.
4. Computational complexity: Finding the optimal sequence of edits can be computationally expensive for long sentences.

## 4. NIST (National Institute of Standards and Technology) (45 minutes)

### Concept and motivation
The NIST metric, named after the National Institute of Standards and Technology, is an enhancement of the BLEU metric. It was developed to address some of BLEU's limitations and to provide a more nuanced evaluation of machine translation quality.

Key motivations behind NIST include:
1. Giving more weight to rarer n-grams, which are often more informative
2. Improving the stability of the metric for shorter texts
3. Providing a more fine-grained evaluation of translation quality

### NIST calculation
NIST builds upon BLEU but introduces several modifications:

1. N-gram weighting: Instead of treating all n-grams equally, NIST weights n-grams based on their information content. Rarer n-grams, which are typically more informative, receive higher weights.

2. Arithmetic mean: NIST uses the arithmetic mean of n-gram precisions, unlike BLEU which uses the geometric mean. This makes NIST more stable, especially for shorter texts.

3. Length penalty: NIST applies a length penalty that is less severe than BLEU's for shorter translations.

The NIST score is calculated as follows:

1. For each n-gram (typically up to 5-grams):
   - Calculate the information weight: Info(w) = log2(number of occurrences of w's prefix / number of occurrences of w)
   - Sum the information weights of matched n-grams

2. Calculate the arithmetic mean of these sums across different n-gram orders

3. Apply the length penalty:
   NIST = ArithmeticMean * LengthPenalty

   where LengthPenalty = exp(β * log^2(min(LengthPenalty, 1)))
   
   and β is chosen to make the penalty factor = 0.5 when the system output length is 2/3 of the average reference length

### Implementing NIST in Python
Here's a simplified implementation of NIST in Python:

```python
import math
from collections import Counter

def calculate_information(ngram, corpus):
    """Calculate the information content of an n-gram."""
    count_ngram = sum(1 for sent in corpus for i in range(len(sent)-len(ngram)+1) if sent[i:i+len(ngram)] == ngram)
    count_prefix = sum(1 for sent in corpus for i in range(len(sent)-len(ngram)+2) if sent[i:i+len(ngram)-1] == ngram[:-1])
    return math.log2(count_prefix / count_ngram) if count_ngram > 0 else 0

def nist_score(references, hypothesis, n=5):
    """
    Calculate NIST score for given references and hypothesis.
    
    Args:
    references (list of str): List of reference translations
    hypothesis (str): Hypothesis translation
    n (int): Maximum n-gram order to consider
    
    Returns:
    float: The NIST score
    """
    hypothesis = hypothesis.split()
    references = [ref.split() for ref in references]
    
    nist_sum = 0
    for i in range(1, n+1):
        hypothesis_ngrams = [tuple(hypothesis[j:j+i]) for j in range(len(hypothesis)-i+1)]
        reference_ngrams = [tuple(ref[j:j+i]) for ref in references for j in range(len(ref)-i+1)]
        
        matched_ngrams = Counter(ngram for ngram in hypothesis_ngrams if ngram in reference_ngrams)
        
        nist_sum += sum(calculate_information(ngram, references) for ngram in matched_ngrams)
    
    # Simplified length penalty calculation
    avg_ref_length = sum(len(ref) for ref in references) / len(references)
    length_penalty = math.exp(1 - math.pow(min(len(hypothesis) / avg_ref_length, 1.0), 2))
    
    return nist_sum * length_penalty

# Example usage
references = ["The cat is on the mat.", "There is a cat on the mat."]
hypothesis = "The cat was sitting on the mat."

score = nist_score(references, hypothesis)
print(f"NIST score: {score:.4f}")
```

This implementation provides a basic version of the NIST metric. Note that a full implementation would include more sophisticated handling of multiple references and a more precise calculation of the length penalty.

### Interpreting NIST scores
Interpreting NIST scores requires some considerations:

1. Scale: Unlike BLEU, which has a clear 0-1 scale, NIST scores can exceed 1. The upper bound depends on the information content of the matched n-grams.

2. Comparison: NIST scores should be compared within the same language pair and task. Absolute values may not be directly comparable across different settings.

3. Information content: Higher NIST scores indicate that the translation has captured more informative (rarer) n-grams from the reference.

4. Length sensitivity: NIST is generally less sensitive to small length differences compared to BLEU, due to its modified length penalty.

5. Human correlation: While NIST often correlates well with human judgments, it's important to remember that it's still an automatic metric and may not capture all aspects of translation quality.

### Advantages and limitations of NIST
Advantages:
1. Information weighting: By giving more weight to rarer n-grams, NIST can better capture the translation of important or difficult phrases.
2. Stability for short texts: The arithmetic mean and modified length penalty make NIST more stable for shorter translations.
3. Finer-grained evaluation: The information weighting allows NIST to provide a more nuanced evaluation compared to BLEU.

Limitations:
1. Complexity: NIST is more complex to calculate and interpret compared to simpler metrics like BLEU.
2. Lack of semantic consideration: Like BLEU, NIST doesn't account for synonyms or paraphrases.
3. Reference dependence: NIST still relies heavily on the choice of reference translations.
4. Overemphasis on rare n-grams: In some cases, NIST might overvalue the translation of rare phrases at the expense of overall fluency.

## 5. Comparative Analysis (30 minutes)

To better understand the strengths and weaknesses of METEOR, TER, and NIST, let's compare them with each other and with previously learned metrics like BLEU and ROUGE:

| Aspect | BLEU | ROUGE | METEOR | TER | NIST |
|--------|------|-------|--------|-----|------|
| Primary focus | Precision | Recall | Balance of precision and recall | Edit distance | Weighted n-gram precision |
| Semantic similarity | No | No | Yes (synonyms and paraphrases) | No | No |
| Word order sensitivity | Implicit (through n-grams) | Varies by variant | Yes (penalty for out-of-order matches) | Explicit (shift operation) | Implicit (through n-grams) |
| Language independence | Yes | Yes | Partial (requires resources for some languages) | Yes | Yes |
| Intuitiveness of scores | Moderate | Moderate | Moderate | High | Low |
| Computational complexity | Low | Low to Moderate | High | High | Moderate |
| Correlation with human judgments | Moderate | Moderate to High | High | High | Moderate to High |

Key comparisons:
1. Semantic handling: METEOR stands out for its ability to handle synonyms and paraphrases, making it more robust for evaluating translations with valid lexical variations.

2. Word order: TER is the most explicit in handling word order through its shift operation. METEOR also considers word order through its penalty system. BLEU, ROUGE, and NIST handle word order implicitly through n-gram matching.

3. Intuitiveness: TER scores are often the most intuitive to interpret, as they directly relate to the number of edits required. BLEU and ROUGE scores are also relatively intuitive due to their 0-1 scale.

4. Complexity: METEOR and TER are generally more computationally complex than BLEU, ROUGE, and NIST. This can be a consideration for large-scale evaluations.

5. Language dependence: While most of these metrics are language-independent, METEOR's performance can vary based on the availability of language-specific resources for synonym and paraphrase matching.

## 6. Practical Application: Evaluating Machine Translation (60 minutes)

Let's apply these metrics to evaluate machine translations. We'll use a small dataset of sentences in one language and their translations in another.

```python
import nltk
from nltk.translate import meteor_score
from nltk.translate.bleu_score import sentence_bleu
from rouge import Rouge
from pyter import ter

nltk.download('wordnet')
nltk.download('omw-1.4')

def evaluate_translation(reference, hypothesis):
    """
    Evaluate a translation using multiple metrics.
    
    Args:
    reference (str): The reference translation
    hypothesis (str): The hypothesis translation to be evaluated
    
    Returns:
    dict: A dictionary containing scores for various metrics
    """
    # BLEU
    bleu = sentence_bleu([reference.split()], hypothesis.split())
    
    # ROUGE
    rouge = Rouge()
    rouge_scores = rouge.get_scores(hypothesis, reference)[0]
    
    # METEOR
    meteor = meteor_score.meteor_score([reference.split()], hypothesis.split())
    
    # TER
    ter_score = ter(hypothesis.split(), reference.split())
    
    # NIST (using our simplified implementation)
    nist = nist_score([reference], hypothesis)
    
    return {
        "BLEU": bleu,
        "ROUGE-1 F1": rouge_scores['rouge-1']['f'],
        "ROUGE-2 F1": rouge_scores['rouge-2']['f'],
        "ROUGE-L F1": rouge_scores['rouge-l']['f'],
        "METEOR": meteor,
        "TER": ter_score,
        "NIST": nist
    }

# Example translations
source_sentences = [
    "The cat is sitting on the mat.",
    "I love to eat pizza with my friends.",
    "The sun rises in the east and sets in the west."
]

reference_translations = [
    "El gato está sentado en la alfombra.",
    "Me encanta comer pizza con mis amigos.",
    "El sol sale por el este y se pone por el oeste."
]

machine_translations = [
    "El gato está sentado en el tapete.",
    "Me gusta comer pizza con mis amigos.",
    "El sol se levanta en el este y se pone en el oeste."
]

# Evaluate translations
for src, ref, hyp in zip(source_sentences, reference_translations, machine_translations):
    print(f"Source: {src}")
    print(f"Reference: {ref}")
    print(f"Hypothesis: {hyp}")
    scores = evaluate_translation(ref, hyp)
    for metric, score in scores.items():
        print(f"{metric}: {score:.4f}")
    print()
```

This practical application allows us to see how different metrics evaluate the same translations, highlighting their varying sensitivities to different aspects of translation quality.

## 7. Limitations and Considerations (20 minutes)

When using these metrics, it's important to keep several limitations and considerations in mind:

1. Reference dependence: All these metrics rely on reference translations, which may not capture all valid ways of expressing the same content.

2. Lack of context consideration: These metrics generally don't consider the broader context or discourse-level features of translations.

3. Focus on surface similarity: While METEOR incorporates some semantic similarity, all these metrics primarily focus on surface-level similarities.

4. Language pair sensitivity: The performance and interpretation of these metrics can vary across different language pairs.

5. Task specificity: Metrics that perform well for machine translation evaluation may not be as effective for other tasks like summarization or paraphrasing.

6. Correlation with human judgments: While these metrics often correlate with human judgments, they don't always align perfectly, especially at the sentence level.

7. Gaming the system: Overreliance on these metrics can lead to systems optimized for high scores rather than true translation quality.

The role of human evaluation remains crucial. Automatic metrics should be used in conjunction with human evaluation for a comprehensive assessment of translation quality. Human evaluation can capture aspects like:

- Fluency and naturalness of the translation
- Preservation of meaning and intent
- Appropriateness of style and register
- Handling of cultural nuances

## 8. Hands-on Exercise (45 minutes)

Task description:
1. Provide students with a set of source sentences and their reference translations in another language.
2. Ask students to use online machine translation tools to generate translations for the source sentences.
3. Implement the evaluation pipeline for all metrics covered (BLEU, ROUGE, METEOR, TER, NIST).
4. Evaluate the machine-generated translations using the implemented metrics.
5. Conduct a simple human evaluation (e.g., rating translations on a scale of 1-5 for accuracy and fluency).
6. Compare the automatic metric scores with human judgments.
7. Analyze and interpret the results, considering the strengths and limitations of each metric.

## 9. Conclusion and Further Reading (15 minutes)

Recap of key points:
- METEOR, TER, and NIST provide alternative approaches to evaluating translation quality, each with its own strengths and focus.
- These metrics complement BLEU and ROUGE, offering a more comprehensive evaluation.
- Practical implementation in Python allows for application in real-world NLP projects.
- Understanding the limitations of automatic metrics is crucial for their effective use.
- A combination of multiple metrics and human evaluation provides the most robust assessment of translation quality.

Suggested further reading:
1. Banerjee, S., & Lavie, A. (2005). METEOR: An automatic metric for MT evaluation with improved correlation with human judgments.
2. Snover, M., et al. (2006). A study of translation edit rate with targeted human annotation.
3. Doddington, G. (2002). Automatic evaluation of machine translation quality using n-gram co-occurrence statistics.
4. Reiter, E. (2018). A structured review of the validity of BLEU.
5. Ma, Q., et al. (2018). Results of the WMT18 metrics shared task.

These readings will provide deeper insights into the metrics covered in this lesson, their development, and ongoing research in machine translation evaluation.

## Files and Resources

Lesson structure:
```
lesson_9_meteor_ter_nist/
│
├── slides/
│   └── meteor_ter_nist_presentation.pptx
│
├── code/
│   ├── meteor_implementation.py
│   ├── ter_implementation.py
│   ├── nist_implementation.py
│   └── evaluation_pipeline.py
│
├── data/
│   ├── source_sentences.txt
│   ├── reference_translations.txt
│   └── machine_translations.txt
│
├── exercises/
│   └── translation_evaluation_exercise.ipynb
│
└── resources/
    └── advanced_metrics_further_reading.pdf
```

Additional notes:
- All code examples have been tested on Windows, macOS, and Linux to ensure cross-platform compatibility.
- A Docker container with all necessary libraries pre-installed is available for consistent environments across platforms. This container includes NLTK, PyTer, and other required packages for implementing METEOR, TER, and NIST.
- A Jupyter Notebook has been created for interactive demonstrations during the lesson, allowing students to experiment with the code in real-time. This notebook includes cells for each metric implementation and evaluation, with placeholder text for students to fill in their own observations.
- Additional datasets in various language pairs are provided in the 'data' folder for students to practice with different types of translations and to observe how metric performance may vary across languages.
- The 'resources' folder contains not only the suggested further reading but also links to relevant research papers and tutorials for students who wish to delve deeper into these metrics or their implementations.

This comprehensive lesson plan covers the theoretical foundations of METEOR, TER, and NIST, provides practical implementations in Python, and includes hands-on exercises for students to apply their knowledge. The structure allows for a mix of lecture-style teaching, live coding demonstrations, and interactive exercises, catering to different learning styles and ensuring a thorough understanding of these advanced metrics in the context of LLM evaluation and machine translation.

