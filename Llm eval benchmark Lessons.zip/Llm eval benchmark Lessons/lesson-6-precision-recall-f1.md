# Lesson 6: Precision, Recall, and F1 Score

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand the concepts of Precision, Recall, and F1 Score in the context of LLM evaluation
2. Calculate and interpret these metrics for various LLM tasks
3. Implement these metrics in Python using both custom functions and popular libraries
4. Apply these metrics to evaluate LLM performance in classification tasks
5. Critically assess the strengths and limitations of each metric
6. Choose appropriate metrics for different LLM evaluation scenarios

## Lesson Duration
Approximately 3 hours

## Prerequisites
- Basic Python programming skills, including functions, loops, and data structures
- Understanding of LLMs and their applications (covered in Module 1)
- Familiarity with basic NLP concepts and previous evaluation metrics (covered in earlier lessons)
- Basic knowledge of classification problems in machine learning

## File Structure
```
lesson_6/
│
├── precision_recall_f1.ipynb
├── data/
│   ├── classification_results.csv
│   └── llm_outputs.json
├── utils/
│   └── evaluation_helpers.py
├── images/
│   ├── precision_recall_tradeoff.png
│   └── confusion_matrix.png
└── README.md
```

## Lesson Content

### 1. Introduction (20 minutes)
- Recap of previous lessons on evaluation metrics:
  Briefly review the token-level accuracy and perplexity concepts from the previous lesson. Explain how these metrics provide insights into model performance but may not capture all aspects of LLM output quality.

- Importance of classification metrics in LLM evaluation:
  Discuss how many LLM tasks can be framed as classification problems (e.g., sentiment analysis, topic classification, intent recognition). Explain why we need specialized metrics for these tasks.

- Overview of Precision, Recall, and F1 Score:
  Introduce these metrics as fundamental tools for evaluating classification performance. Explain their origins in information retrieval and their widespread use in machine learning and NLP.

### 2. Understanding the Confusion Matrix (30 minutes)
- Definition and components of a confusion matrix:
  Explain that a confusion matrix is a table showing the performance of a classification model. Describe its four components: True Positives (TP), True Negatives (TN), False Positives (FP), and False Negatives (FN).

- Visualizing a confusion matrix:
  Provide an example of a confusion matrix and explain how to read it. Use a simple binary classification scenario to illustrate the concept.

- Implementing a confusion matrix in Python:
```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix

def plot_confusion_matrix(y_true, y_pred, classes):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(10, 7))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=classes, yticklabels=classes)
    plt.title('Confusion Matrix')
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.show()

# Example usage
y_true = [0, 1, 0, 1, 0, 1, 0, 1, 1, 0]
y_pred = [0, 1, 0, 1, 0, 0, 1, 1, 1, 0]
classes = ['Negative', 'Positive']

plot_confusion_matrix(y_true, y_pred, classes)
```

### 3. Precision (40 minutes)
- Definition of Precision:
  Explain that Precision is the ratio of correctly predicted positive instances to the total predicted positive instances. Mathematically, it's TP / (TP + FP).

- Interpretation and use cases:
  Discuss scenarios where Precision is particularly important, such as in medical diagnosis or spam detection, where false positives can be costly.

- Calculating Precision in Python:
```python
def calculate_precision(y_true, y_pred):
    TP = sum((y_true == 1) & (y_pred == 1))
    FP = sum((y_true == 0) & (y_pred == 1))
    return TP / (TP + FP) if (TP + FP) > 0 else 0

# Example usage
precision = calculate_precision(y_true, y_pred)
print(f"Precision: {precision:.2f}")

# Using scikit-learn for verification
from sklearn.metrics import precision_score
sk_precision = precision_score(y_true, y_pred)
print(f"Scikit-learn Precision: {sk_precision:.2f}")
```

- Limitations of Precision:
  Explain that Precision alone doesn't provide a complete picture of model performance. It doesn't account for false negatives, which can be crucial in some applications.

### 4. Recall (40 minutes)
- Definition of Recall:
  Explain that Recall is the ratio of correctly predicted positive instances to the total actual positive instances. Mathematically, it's TP / (TP + FN).

- Interpretation and use cases:
  Discuss scenarios where Recall is particularly important, such as in rare disease detection or fraud detection, where missing positive cases can be very costly.

- Calculating Recall in Python:
```python
def calculate_recall(y_true, y_pred):
    TP = sum((y_true == 1) & (y_pred == 1))
    FN = sum((y_true == 1) & (y_pred == 0))
    return TP / (TP + FN) if (TP + FN) > 0 else 0

# Example usage
recall = calculate_recall(y_true, y_pred)
print(f"Recall: {recall:.2f}")

# Using scikit-learn for verification
from sklearn.metrics import recall_score
sk_recall = recall_score(y_true, y_pred)
print(f"Scikit-learn Recall: {sk_recall:.2f}")
```

- Limitations of Recall:
  Explain that Recall alone doesn't provide a complete picture of model performance. A model that always predicts the positive class will have perfect Recall but may not be useful in practice.

### 5. F1 Score (40 minutes)
- Definition of F1 Score:
  Explain that the F1 Score is the harmonic mean of Precision and Recall. Mathematically, it's 2 * (Precision * Recall) / (Precision + Recall).

- Interpretation and use cases:
  Discuss how F1 Score provides a balanced measure between Precision and Recall. Explain scenarios where this balance is crucial, such as in text classification or named entity recognition.

- Calculating F1 Score in Python:
```python
def calculate_f1(precision, recall):
    return 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0

# Example usage
f1 = calculate_f1(precision, recall)
print(f"F1 Score: {f1:.2f}")

# Using scikit-learn for verification
from sklearn.metrics import f1_score
sk_f1 = f1_score(y_true, y_pred)
print(f"Scikit-learn F1 Score: {sk_f1:.2f}")
```

- Limitations of F1 Score:
  Explain that F1 Score assumes equal importance of Precision and Recall, which may not always be appropriate. Discuss scenarios where one might be more important than the other.

### 6. Precision-Recall Trade-off (30 minutes)
- Understanding the trade-off:
  Explain how increasing Precision often comes at the cost of Recall, and vice versa. Use examples to illustrate this concept.

- Visualizing the Precision-Recall curve:
```python
from sklearn.metrics import precision_recall_curve
import numpy as np

def plot_precision_recall_curve(y_true, y_scores):
    precision, recall, thresholds = precision_recall_curve(y_true, y_scores)
    plt.figure(figsize=(10, 7))
    plt.plot(recall, precision, marker='.')
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall Curve')
    plt.show()

# Example usage with probabilistic predictions
y_scores = np.random.random(len(y_true))
plot_precision_recall_curve(y_true, y_scores)
```

- Choosing an appropriate threshold:
  Discuss strategies for selecting a classification threshold based on the specific requirements of the task and the shape of the Precision-Recall curve.

### 7. Applying Metrics to LLM Evaluation (30 minutes)
- LLM tasks suitable for these metrics:
  Discuss various LLM tasks where Precision, Recall, and F1 Score are applicable, such as:
  - Sentiment analysis
  - Named Entity Recognition
  - Intent classification in conversational AI
  - Topic categorization

- Case study: Evaluating an LLM on a text classification task:
  Walk through a complete example of evaluating an LLM's performance on a multi-class text classification problem. Use real or realistic data to calculate and interpret all the metrics covered in the lesson.

- Limitations and considerations:
  Discuss the challenges of applying these metrics to LLM outputs, such as:
  - Handling multi-label classification
  - Dealing with class imbalance
  - Evaluating probabilistic outputs

### 8. Hands-on Exercise (30 minutes)
Students will work on a practical exercise involving:
1. Loading a dataset of LLM-generated classifications and ground truth labels
2. Calculating Precision, Recall, and F1 Score for each class
3. Visualizing the results using confusion matrices and Precision-Recall curves
4. Interpreting the metrics in the context of LLM performance
5. Proposing improvements based on the evaluation results

Provide starter code and a dataset, guiding students through each step of the process. Encourage them to experiment with different classification thresholds and observe the impact on the metrics.

### 9. Discussion and Q&A (20 minutes)
- Open discussion on Precision, Recall, and F1 Score:
  Facilitate a conversation about the students' experiences with the hands-on exercise. Encourage them to share insights and challenges they encountered.

- Address any questions or clarifications needed:
  Take time to clear up any confusion about the concepts or implementations covered in the lesson.

- Preview the next lesson on BLEU Score:
  Briefly introduce the BLEU score as a metric specifically designed for evaluating machine translation quality. Explain how it differs from the classification metrics covered in this lesson and why it's important for certain LLM tasks.

## Additional Resources
- Scikit-learn documentation on classification metrics: Provide links to relevant sections for further exploration.
- Research paper: "Beyond Accuracy: Precision and Recall" by Jason Brownlee. Summarize key insights and practical tips from the paper.
- Interactive web tool for visualizing Precision, Recall, and F1 Score: Provide a link to a tool where students can experiment with different scenarios.
- Video tutorial on interpreting confusion matrices and Precision-Recall curves in the context of NLP tasks.

## Assessment
1. Multiple-choice questions testing understanding of Precision, Recall, and F1 Score concepts, including their relationships and trade-offs.
2. Short coding task to implement these metrics from scratch for a multi-class classification problem.
3. Analysis task: Given a set of LLM outputs for a text classification task, calculate the metrics, create visualizations, and write a brief report interpreting the results and suggesting potential improvements to the model.

## Homework
1. Implement a function to calculate the Average Precision (AP) and Mean Average Precision (mAP) for multi-class classification problems. Apply these metrics to the dataset used in the hands-on exercise.
2. Research and write a brief report on how Precision, Recall, and F1 Score are used in a specific LLM application of your choice (e.g., sentiment analysis in social media monitoring, intent classification in chatbots). Include real-world examples and discuss any limitations or adaptations of these metrics in that context.
3. Explore and report on one alternative classification metric not covered in the lesson (e.g., Matthews Correlation Coefficient, Cohen's Kappa). Implement it in Python and discuss its advantages and disadvantages compared to the metrics covered in class.

## Next Steps
In the next lesson, we'll dive into the BLEU (Bilingual Evaluation Understudy) score, a metric specifically designed for evaluating machine translation quality. We'll see how it differs from the classification metrics covered in this lesson and why it's important for certain LLM tasks, particularly those involving text generation and translation.
