# Lesson 13: BLEURT and MoverScore - Advanced Learned Metrics

## Overview
This lesson focuses on two advanced learned metrics for text evaluation: BLEURT (Bilingual Evaluation Understudy with Representations from Transformers) and MoverScore. These metrics represent the cutting edge in NLP evaluation, leveraging machine learning techniques to provide more nuanced and accurate assessments of text quality. We'll explore their theoretical foundations, implementation in Python, and applications in evaluating Large Language Model (LLM) outputs.

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand the concepts and motivations behind BLEURT and MoverScore
2. Explain how these metrics improve upon earlier learned metrics like BERTScore
3. Implement BLEURT and MoverScore using pre-trained models and libraries
4. Analyze the strengths and limitations of BLEURT and MoverScore compared to other metrics
5. Apply BLEURT and MoverScore to evaluate LLM outputs in various text generation tasks

## File Structure
```
lesson_12/
│
├── notebooks/
│   ├── bleurt_implementation.ipynb
│   └── moverscore_implementation.ipynb
│
├── scripts/
│   ├── bleurt_metric.py
│   └── moverscore_metric.py
│
├── data/
│   ├── sample_references.txt
│   └── sample_candidates.txt
│
└── requirements.txt
```

## Lesson Content

### 1. Introduction to BLEURT and MoverScore (45 minutes)

#### 1.1 Background and Motivation
Both BLEURT and MoverScore were developed to address limitations in existing text evaluation metrics, including learned metrics like BERTScore. While BERTScore was a significant improvement over traditional n-gram based metrics, it still had some limitations:

1. Lack of Task-Specific Training: 
   BERTScore relies on pre-trained language models without any task-specific fine-tuning, which can limit its ability to capture task-specific nuances.

2. Limited Consideration of Word Importance: 
   While BERTScore uses IDF weighting, it doesn't learn task-specific word importance.

3. Token-Level Matching: 
   BERTScore performs token-level matching, which may not always capture sentence-level semantic similarities effectively.

BLEURT and MoverScore aim to address these limitations through different approaches.

#### 1.2 BLEURT: Bilingual Evaluation Understudy with Representations from Transformers

BLEURT is a learned evaluation metric that builds upon the success of BERT-based models while incorporating task-specific training. Key aspects of BLEURT include:

1. Pre-training Phase: 
   BLEURT starts with a pre-trained BERT model and further pre-trains it on a large synthetic dataset of sentence pairs. This synthetic data is created using techniques like backtranslation, word dropping, and phrase replacement, allowing the model to learn general notions of sentence similarity.

2. Fine-tuning Phase: 
   After pre-training, BLEURT is fine-tuned on human judgments of sentence similarity. This allows the model to align its predictions with human assessments of text quality.

3. Regression Output: 
   Unlike BERTScore, which outputs separate precision, recall, and F1 scores, BLEURT produces a single regression score indicating the quality of the candidate text relative to the reference.

4. Adaptability: 
   BLEURT can be adapted to different evaluation tasks by fine-tuning on task-specific human judgments.

#### 1.3 MoverScore: Earth Mover's Distance for Text Generation Evaluation

MoverScore takes a different approach, inspired by optimal transport theory. Key aspects of MoverScore include:

1. Word Mover's Distance: 
   MoverScore is based on the concept of Word Mover's Distance (WMD), which measures the minimum "travel cost" of transforming one text into another in the semantic space.

2. Contextual Embeddings: 
   Like BERTScore, MoverScore uses contextual embeddings from pre-trained language models to represent words and subwords.

3. n-gram Matching: 
   MoverScore extends the WMD concept to n-grams, allowing it to capture phrase-level similarities.

4. Soft Alignments: 
   Instead of hard token-to-token alignments, MoverScore computes soft alignments between all tokens in the candidate and reference texts.

5. Incorporation of IDF: 
   MoverScore incorporates inverse document frequency (IDF) to give more weight to informative words.

### 2. Implementing BLEURT in Python (60 minutes)

#### 2.1 Setting Up the Environment
We'll start by setting up our Python environment with the necessary libraries. BLEURT is available as a separate Python package.

```python
!pip install bleurt
!pip install tensorflow  # BLEURT requires TensorFlow

from bleurt import score
import tensorflow as tf
```

#### 2.2 Loading a Pre-trained BLEURT Model
BLEURT provides pre-trained checkpoints that we can use. We'll load a checkpoint and create a scorer:

```python
def load_bleurt_model(checkpoint="bleurt-base-128"):
    scorer = score.BleurtScorer(checkpoint)
    return scorer

bleurt_scorer = load_bleurt_model()
```

The `checkpoint` parameter allows us to choose different BLEURT models. "bleurt-base-128" is a good balance of performance and efficiency, but larger models are available for higher accuracy at the cost of increased computation time.

#### 2.3 Computing BLEURT Scores
Now we'll implement a function to compute BLEURT scores for candidate texts given reference texts:

```python
def compute_bleurt_scores(candidates, references, scorer):
    scores = scorer.score(references=references, candidates=candidates)
    return scores

# Example usage
candidates = ["The cat sat on the mat", "A feline rested on the floor covering"]
references = ["A cat was sitting on a mat", "The feline was lounging on a rug"]

bleurt_scores = compute_bleurt_scores(candidates, references, bleurt_scorer)
```

This function handles the following steps:
1. Input Processing: The scorer takes care of tokenization and embedding computation internally.
2. Score Computation: The scorer computes BLEURT scores for each candidate-reference pair.
3. Output: A list of scores is returned, one for each candidate-reference pair.

#### 2.4 Interpreting BLEURT Scores
BLEURT scores typically range from 0 to 1, with higher scores indicating greater similarity between the candidate and reference texts. However, it's important to note:

1. Score Range: 
   While scores typically fall between 0 and 1, they are not strictly bounded and can sometimes go outside this range.

2. Relative Interpretation: 
   BLEURT scores are best interpreted relatively rather than absolutely. Comparing scores across different systems or versions is more informative than focusing on absolute values.

3. Task Specificity: 
   The interpretation of BLEURT scores can vary depending on the task and the specific checkpoint used. Scores from different checkpoints are not directly comparable.

#### 2.5 Handling Edge Cases
When using BLEURT in real-world scenarios, consider the following edge cases:

1. Empty Texts: 
   BLEURT can handle empty strings, but you should decide how to interpret scores for empty candidates or references in your application.

2. Very Long Texts: 
   BLEURT models have a maximum sequence length (often 512 tokens). For longer texts, you might need to implement a chunking strategy.

3. Batching: 
   For efficiency when scoring many texts, use batching:

```python
def batch_bleurt_scores(candidates, references, scorer, batch_size=32):
    scores = []
    for i in range(0, len(candidates), batch_size):
        batch_candidates = candidates[i:i+batch_size]
        batch_references = references[i:i+batch_size]
        batch_scores = scorer.score(references=batch_references, candidates=batch_candidates)
        scores.extend(batch_scores)
    return scores
```

### 3. Implementing MoverScore in Python (60 minutes)

#### 3.1 Setting Up the Environment
MoverScore is available as a separate Python package. We'll install and import the necessary libraries:

```python
!pip install moverscore
!pip install pytorch-pretrained-bert  # MoverScore depends on this

from moverscore import word_mover_score
from pytorch_pretrained_bert import BertTokenizer, BertModel
```

#### 3.2 Loading Pre-trained Models for MoverScore
MoverScore uses BERT models for word embeddings. We'll load a pre-trained BERT model and tokenizer:

```python
def load_moverscore_models():
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    model = BertModel.from_pretrained('bert-base-uncased')
    return tokenizer, model

moverscore_tokenizer, moverscore_model = load_moverscore_models()
```

#### 3.3 Computing MoverScore
Now we'll implement a function to compute MoverScores for candidate texts given reference texts:

```python
def compute_moverscores(candidates, references, tokenizer, model):
    scores = word_mover_score(references, candidates, tokenizer, model, idf=True, stop_words=[], n_gram=1, batch_size=16)
    return scores

# Example usage
candidates = ["The cat sat on the mat", "A feline rested on the floor covering"]
references = ["A cat was sitting on a mat", "The feline was lounging on a rug"]

moverscores = compute_moverscores(candidates, references, moverscore_tokenizer, moverscore_model)
```

This function handles the following steps:
1. Tokenization: The tokenizer converts input texts into tokens that the BERT model can process.
2. Embedding Computation: The BERT model computes contextual embeddings for each token.
3. MoverScore Calculation: The word_mover_score function computes the MoverScore using these embeddings.

#### 3.4 Interpreting MoverScores
MoverScore interpretation requires some nuance:

1. Score Range: 
   MoverScores typically range from 0 to 1, with higher scores indicating greater similarity. However, the exact range can vary depending on the specific texts and model used.

2. n-gram Consideration: 
   MoverScore can consider n-grams beyond individual words. Higher n-gram values can capture phrase-level similarities but may also increase computation time.

3. IDF Weighting: 
   The use of IDF weighting (enabled by default) gives more importance to rare words, which can be beneficial for capturing key content words.

#### 3.5 Handling Edge Cases and Optimizations
When using MoverScore in practice, consider the following:

1. Stop Words: 
   MoverScore allows specification of stop words to ignore. This can be useful for focusing on content words:

```python
from nltk.corpus import stopwords
stop_words = set(stopwords.words('english'))

scores = word_mover_score(references, candidates, tokenizer, model, stop_words=stop_words)
```

2. Batching: 
   MoverScore supports batching for efficient processing of many texts. The batch_size parameter in the word_mover_score function controls this.

3. n-gram Selection: 
   Experiment with different n-gram values to balance between capturing phrase similarities and computation time:

```python
unigram_scores = word_mover_score(references, candidates, tokenizer, model, n_gram=1)
bigram_scores = word_mover_score(references, candidates, tokenizer, model, n_gram=2)
```

### 4. Comparing BLEURT and MoverScore (30 minutes)

#### 4.1 Strengths of BLEURT
1. Task-Specific Training: 
   BLEURT's fine-tuning on human judgments allows it to align closely with human evaluations for specific tasks.

2. Robustness: 
   The pre-training on synthetic data makes BLEURT robust to various text perturbations.

3. Single Score Output: 
   BLEURT provides a single, easy-to-interpret score, which can be beneficial for straightforward comparisons.

#### 4.2 Strengths of MoverScore
1. Flexible Similarity Measurement: 
   MoverScore's use of optimal transport theory allows for a more flexible matching between words and phrases.

2. n-gram Consideration: 
   The ability to consider n-grams allows MoverScore to capture phrase-level similarities effectively.

3. No Task-Specific Training Required: 
   MoverScore can be applied to new tasks without requiring task-specific training data.

#### 4.3 Limitations and Considerations
1. Computational Cost: 
   Both BLEURT and MoverScore are more computationally intensive than simpler metrics like BLEU or even BERTScore.

2. Interpretability: 
   As learned metrics, both BLEURT and MoverScore can be less interpretable than traditional metrics. It's not always clear why a particular score was assigned.

3. Dependency on Pre-trained Models: 
   Both metrics rely on the quality and biases of the underlying pre-trained language models.

### 5. Applying BLEURT and MoverScore to LLM Evaluation (45 minutes)

#### 5.1 Use Cases in LLM Evaluation
BLEURT and MoverScore can be particularly useful in several LLM evaluation scenarios:

1. Open-ended Text Generation: 
   For tasks like story continuation or creative writing, these metrics can capture semantic similarity even when the generated text differs significantly from references.

2. Abstractive Summarization: 
   Both metrics can effectively evaluate summaries that paraphrase the original text, capturing meaning preservation better than n-gram based metrics.

3. Dialogue Systems: 
   For evaluating chatbot responses, these metrics can assess the semantic appropriateness of responses even when they differ lexically from reference responses.

4. Machine Translation: 
   Both metrics have shown strong performance in evaluating translation quality, capturing meaning preservation across languages.

#### 5.2 Implementing a Comparative Evaluation Framework
We'll implement a function to evaluate LLM outputs using both BLEURT and MoverScore, allowing for easy comparison:

```python
def evaluate_llm_outputs(candidates, references, bleurt_scorer, moverscore_tokenizer, moverscore_model):
    bleurt_scores = compute_bleurt_scores(candidates, references, bleurt_scorer)
    moverscores = compute_moverscores(candidates, references, moverscore_tokenizer, moverscore_model)
    
    results = []
    for cand, ref, bleurt, mover in zip(candidates, references, bleurt_scores, moverscores):
        results.append({
            'candidate': cand,
            'reference': ref,
            'BLEURT': bleurt,
            'MoverScore': mover
        })
    return results

# Example usage
llm_outputs = ["The cat sat on the mat", "A feline rested on the floor covering"]
reference_texts = ["A cat was sitting on a mat", "The feline was lounging on a rug"]

evaluation_results = evaluate_llm_outputs(llm_outputs, reference_texts, bleurt_scorer, moverscore_tokenizer, moverscore_model)
```

#### 5.3 Analyzing and Interpreting Results
When analyzing the results of BLEURT and MoverScore in LLM evaluation:

1. Comparative Analysis: 
   Look for cases where BLEURT and MoverScore disagree. These can often highlight interesting aspects of the generated text.

2. Task-Specific Thresholds: 
   Develop task-specific thresholds for "good" scores based on human evaluations of a subset of outputs.

3. Correlation with Human Judgments: 
   Periodically check the correlation of these metric scores with human judgments to ensure they align with human perceptions of quality.

4. Complementary Use: 
   Consider using BLEURT and MoverScore alongside other metrics for a more comprehensive evaluation. For example, combine them with task-specific metrics or human evaluations.

### 6. Practical Exercise and Discussion (60 minutes)

To solidify understanding and provide hands-on experience with BLEURT and MoverScore, we'll conduct a practical exercise followed by a group discussion.

#### 6.1 Exercise Setup

We'll use a pre-trained LLM to generate outputs for a specific task, then evaluate these outputs using BLEURT and MoverScore. For this exercise, we'll focus on abstractive summarization.

1. Task Description:
   Students will use a pre-trained summarization model (e.g., BART or T5) to generate summaries for a set of news articles. They will then evaluate these summaries using BLEURT and MoverScore, comparing the results to human-written reference summaries.

2. Dataset:
   We'll use a subset of the CNN/Daily Mail dataset, which provides news articles along with human-written summaries.

3. Implementation Steps:
   a. Load the pre-trained summarization model
   b. Generate summaries for the news articles
   c. Evaluate the generated summaries using BLEURT and MoverScore
   d. Compare the metric scores to human judgments (if available)

#### 6.2 Code Implementation

Here's a skeleton of the code students will use for this exercise:

```python
from transformers import pipeline
from datasets import load_dataset
from bleurt import score
from moverscore import word_mover_score
from pytorch_pretrained_bert import BertTokenizer, BertModel

# Load models
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
bleurt_scorer = score.BleurtScorer("bleurt-base-128")
moverscore_tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
moverscore_model = BertModel.from_pretrained('bert-base-uncased')

# Load dataset
dataset = load_dataset("cnn_dailymail", "3.0.0", split="test[:100]")  # Using 100 examples for brevity

def generate_and_evaluate_summaries(articles, reference_summaries):
    # Generate summaries
    generated_summaries = [summarizer(article, max_length=130, min_length=30, do_sample=False)[0]['summary_text'] for article in articles]
    
    # Compute BLEURT scores
    bleurt_scores = bleurt_scorer.score(references=reference_summaries, candidates=generated_summaries)
    
    # Compute MoverScores
    moverscores = word_mover_score(reference_summaries, generated_summaries, moverscore_tokenizer, moverscore_model, idf=True, stop_words=[], n_gram=1, batch_size=16)
    
    return generated_summaries, bleurt_scores, moverscores

# Run evaluation
generated_summaries, bleurt_scores, moverscores = generate_and_evaluate_summaries(dataset['article'], dataset['highlights'])

# Display results
for i in range(len(generated_summaries)):
    print(f"Article {i+1}:")
    print(f"Generated Summary: {generated_summaries[i]}")
    print(f"Reference Summary: {dataset['highlights'][i]}")
    print(f"BLEURT Score: {bleurt_scores[i]}")
    print(f"MoverScore: {moverscores[i]}")
    print("\n")
```

#### 6.3 Analysis Tasks

After running the code, students will perform the following analysis tasks:

1. Score Distribution:
   Plot histograms of BLEURT and MoverScore distributions. Analyze the range and central tendencies of the scores.

2. Correlation Analysis:
   Compute the correlation between BLEURT and MoverScore. Discuss cases where the metrics agree or disagree significantly.

3. Qualitative Assessment:
   Select a few examples with high, medium, and low scores. Perform a qualitative analysis of these summaries, considering factors like content coverage, fluency, and factual accuracy.

4. Comparison with ROUGE:
   If time allows, compute ROUGE scores for the same summaries and compare them with BLEURT and MoverScore results. Discuss the differences in what these metrics capture.

#### 6.4 Group Discussion

After completing the exercise and analysis, the class will engage in a group discussion. Key points to cover include:

1. Metric Behavior:
   - How do BLEURT and MoverScore behave differently from traditional metrics like ROUGE?
   - In what ways do these learned metrics seem to align better (or worse) with human judgments of summary quality?

2. Strengths and Weaknesses:
   - What strengths of BLEURT and MoverScore were evident in this exercise?
   - What limitations or potential weaknesses did you observe?

3. Use Cases:
   - Based on this exercise, in what scenarios would you recommend using BLEURT or MoverScore over traditional metrics?
   - Are there cases where you'd still prefer simpler metrics like ROUGE?

4. Challenges in Implementation:
   - What challenges did you face in implementing and using these metrics?
   - How might these challenges affect their adoption in real-world evaluation pipelines?

5. Future Directions:
   - How might these metrics be further improved?
   - What other aspects of text quality do you think are still not captured well by current metrics?

#### 6.5 Reflection and Takeaways

To conclude the exercise, ask students to write a brief reflection (about 200 words) on their key takeaways from using BLEURT and MoverScore. Encourage them to consider:

- How their understanding of text evaluation has evolved
- Potential applications of these metrics in their own work or research
- Questions or areas they'd like to explore further

### 7. Conclusion and Further Resources (15 minutes)

#### 7.1 Recap of Key Points
- BLEURT and MoverScore represent advanced approaches to learned text evaluation metrics.
- BLEURT leverages task-specific training to align closely with human judgments.
- MoverScore uses optimal transport theory to flexibly match words and phrases.
- Both metrics show promise in evaluating complex text generation tasks, particularly where semantic similarity is important.
- Implementation and interpretation of these metrics require careful consideration of their strengths and limitations.

#### 7.2 Further Reading and Resources
- BLEURT paper: "BLEURT: Learning Robust Metrics for Text Generation" by Sellam et al.
- MoverScore paper: "MoverScore: Text Generation Evaluating with Contextualized Embeddings and Earth Mover Distance" by Zhao et al.
- BLEURT GitHub repository: [https://github.com/google-research/bleurt](https://github.com/google-research/bleurt)
- MoverScore GitHub repository: [https://github.com/AIPHES/emnlp19-moverscore](https://github.com/AIPHES/emnlp19-moverscore)
- Survey paper: "Evaluation of Text Generation: A Survey" by Celikyilmaz et al., for a broader context of text generation evaluation

#### 7.3 Next Steps
Encourage students to:
- Experiment with these metrics on different text generation tasks
- Explore other recent learned metrics and compare them with BLEURT and MoverScore
- Consider how these metrics might be integrated into their own NLP projects or research

By the end of this comprehensive lesson, students will have gained both theoretical understanding and practical experience with BLEURT and MoverScore, preparing them to apply these advanced metrics in their own work with Large Language Models and text generation tasks.

