# Lesson 16: SQuAD and Question-Answering Benchmarks

## Learning Objectives

By the end of this lesson, students will be able to:
1. Understand the importance of question-answering tasks in Natural Language Processing (NLP) and their role in evaluating Large Language Models (LLMs).
2. Comprehend the structure and purpose of the Stanford Question Answering Dataset (SQuAD).
3. Implement SQuAD evaluation metrics using Python.
4. Analyze and interpret SQuAD evaluation results for LLMs.
5. Recognize the limitations of SQuAD and explore other question-answering benchmarks.

## 1. Introduction to Question-Answering Tasks

Question-answering (QA) is a fundamental task in Natural Language Processing that assesses a model's ability to understand and extract relevant information from a given context to answer questions. This capability is crucial for LLMs as it demonstrates their comprehension and reasoning abilities.

QA tasks typically involve three main components:
- Context: A passage or document containing relevant information.
- Question: A query about the information in the context.
- Answer: The correct response to the question based on the context.

LLMs are evaluated on their ability to generate accurate answers given a context and question pair. This evaluation helps researchers and practitioners understand how well the models can comprehend and reason about textual information.

## 2. Stanford Question Answering Dataset (SQuAD)

### 2.1 Overview of SQuAD

The Stanford Question Answering Dataset (SQuAD) is one of the most widely used benchmarks for evaluating question-answering systems. Developed by researchers at Stanford University, SQuAD has become a standard for measuring the performance of LLMs in reading comprehension tasks.

There are two main versions of SQuAD:
1. SQuAD 1.1: The original version, released in 2016.
2. SQuAD 2.0: An enhanced version, released in 2018, which includes unanswerable questions.

### 2.2 Structure of SQuAD

SQuAD consists of crowdsourced question-answer pairs based on Wikipedia articles. Each example in the dataset includes:
- A paragraph from a Wikipedia article (context)
- A question about the paragraph
- The answer to the question, which is a span of text from the paragraph

For SQuAD 2.0, some questions are designed to be unanswerable based on the given context, adding an extra layer of difficulty to the task.

### 2.3 Importance of SQuAD in LLM Evaluation

SQuAD plays a crucial role in LLM evaluation for several reasons:
1. Reading Comprehension: It tests an LLM's ability to understand and extract relevant information from a given context.
2. Natural Language Understanding: The questions in SQuAD are posed in natural language, requiring models to interpret and understand human-like queries.
3. Reasoning: Many questions require simple reasoning or inference, going beyond mere information retrieval.
4. Benchmark Standardization: As a widely adopted benchmark, SQuAD allows for fair comparisons between different models and approaches.
5. Real-world Applicability: The task closely mimics real-world scenarios where users might ask questions about a given text, making it relevant for practical applications.

## 3. Implementing SQuAD Evaluation

To evaluate an LLM's performance on SQuAD, we need to implement the official evaluation metrics. The primary metrics used for SQuAD are Exact Match (EM) and F1 score. Let's implement these metrics in Python.

### 3.1 File Structure

First, let's set up our project structure:

```
squad_evaluation/
│
├── data/
│   ├── squad_dev.json
│   └── model_predictions.json
│
├── src/
│   ├── __init__.py
│   ├── preprocessing.py
│   ├── metrics.py
│   └── evaluation.py
│
├── notebooks/
│   └── squad_evaluation_demo.ipynb
│
├── requirements.txt
└── README.md
```

### 3.2 Implementation

Let's break down the implementation into several Python files:

#### preprocessing.py

This file will handle data loading and preprocessing.

```python
import json
from typing import Dict, List, Tuple

def load_squad_data(file_path: str) -> Dict:
    """Load SQuAD dataset from a JSON file."""
    with open(file_path, 'r') as f:
        return json.load(f)

def preprocess_squad_data(squad_data: Dict) -> List[Tuple[str, str, str]]:
    """
    Preprocess SQuAD data into a list of (context, question, answer) tuples.
    """
    processed_data = []
    for article in squad_data['data']:
        for paragraph in article['paragraphs']:
            context = paragraph['context']
            for qa in paragraph['qas']:
                question = qa['question']
                if not qa['is_impossible']:
                    answer = qa['answers'][0]['text']  # We'll use the first answer
                else:
                    answer = ""  # For unanswerable questions in SQuAD 2.0
                processed_data.append((context, question, answer))
    return processed_data
```

#### metrics.py

This file will contain the implementation of the Exact Match and F1 score metrics.

```python
import re
from collections import Counter

def normalize_answer(s: str) -> str:
    """Lower text and remove punctuation, articles and extra whitespace."""
    def remove_articles(text):
        return re.sub(r'\b(a|an|the)\b', ' ', text)

    def white_space_fix(text):
        return ' '.join(text.split())

    def remove_punc(text):
        exclude = set(string.punctuation)
        return ''.join(ch for ch in text if ch not in exclude)

    def lower(text):
        return text.lower()

    return white_space_fix(remove_articles(remove_punc(lower(s))))

def exact_match_score(prediction: str, ground_truth: str) -> int:
    """Compute exact match score."""
    return int(normalize_answer(prediction) == normalize_answer(ground_truth))

def f1_score(prediction: str, ground_truth: str) -> float:
    """Compute F1 score."""
    prediction_tokens = normalize_answer(prediction).split()
    ground_truth_tokens = normalize_answer(ground_truth).split()
    
    common = Counter(prediction_tokens) & Counter(ground_truth_tokens)
    num_same = sum(common.values())
    
    if num_same == 0:
        return 0
    
    precision = 1.0 * num_same / len(prediction_tokens)
    recall = 1.0 * num_same / len(ground_truth_tokens)
    f1 = (2 * precision * recall) / (precision + recall)
    return f1
```

#### evaluation.py

This file will contain the main evaluation logic, using the metrics we defined.

```python
from typing import List, Tuple
from .metrics import exact_match_score, f1_score

def evaluate_predictions(predictions: List[str], ground_truths: List[str]) -> Tuple[float, float]:
    """
    Evaluate predictions against ground truths using Exact Match and F1 score.
    """
    em_scores = []
    f1_scores = []
    
    for pred, truth in zip(predictions, ground_truths):
        em_scores.append(exact_match_score(pred, truth))
        f1_scores.append(f1_score(pred, truth))
    
    em_score = sum(em_scores) / len(em_scores)
    f1_score = sum(f1_scores) / len(f1_scores)
    
    return em_score, f1_score

def evaluate_squad(predictions: List[str], processed_data: List[Tuple[str, str, str]]) -> Dict[str, float]:
    """
    Evaluate SQuAD predictions and return a dictionary of metrics.
    """
    ground_truths = [answer for _, _, answer in processed_data]
    em_score, f1_score = evaluate_predictions(predictions, ground_truths)
    
    return {
        "exact_match": em_score * 100,  # Convert to percentage
        "f1_score": f1_score * 100      # Convert to percentage
    }
```

### 3.3 Usage Example

Now, let's create a Jupyter notebook to demonstrate how to use our SQuAD evaluation implementation.

```python
# squad_evaluation_demo.ipynb

import json
from src.preprocessing import load_squad_data, preprocess_squad_data
from src.evaluation import evaluate_squad

# Load SQuAD data
squad_data = load_squad_data('data/squad_dev.json')
processed_data = preprocess_squad_data(squad_data)

# Load model predictions (assuming we have these from an LLM)
with open('data/model_predictions.json', 'r') as f:
    predictions = json.load(f)

# Evaluate predictions
results = evaluate_squad(predictions, processed_data)

print(f"Exact Match: {results['exact_match']:.2f}%")
print(f"F1 Score: {results['f1_score']:.2f}%")
```

## 4. Analyzing and Interpreting SQuAD Results

When analyzing SQuAD results for an LLM, consider the following aspects:

1. Exact Match (EM) Score: This metric measures the percentage of predictions that exactly match the ground truth answers. A higher EM score indicates better performance, but it can be quite strict as it doesn't account for synonyms or paraphrases.

2. F1 Score: This metric provides a more flexible evaluation by considering partial matches. It's particularly useful for longer answers where slight variations might still be correct.

3. Performance on Answerable vs. Unanswerable Questions: For SQuAD 2.0, analyze how well the model distinguishes between answerable and unanswerable questions. This tests the model's ability to recognize when information is not present in the context.

4. Error Analysis: Examine the types of questions or contexts where the model struggles. This can reveal weaknesses in the model's understanding or reasoning capabilities.

5. Comparison to Human Performance: SQuAD provides human performance benchmarks. Comparing the LLM's performance to human levels can give insight into the model's capabilities relative to human understanding.

6. Comparison to State-of-the-Art: Compare the results to the latest published results on the SQuAD leaderboard to understand how the LLM stands in relation to other advanced models.

## 5. Limitations of SQuAD and Other QA Benchmarks

While SQuAD is a valuable benchmark, it's important to recognize its limitations:

1. Limited Domain: SQuAD is based on Wikipedia articles, which may not represent the full range of real-world question-answering scenarios.

2. Answer Span Limitation: In SQuAD, answers are always contiguous spans from the context. This doesn't account for questions that might require synthesizing information from multiple parts of the text.

3. Lack of External Knowledge: SQuAD doesn't test a model's ability to incorporate external knowledge beyond the given context.

4. Potential Dataset Biases: Like any dataset, SQuAD may contain biases in its question types or content that could influence model performance.

Other Question-Answering Benchmarks:

1. Natural Questions (NQ): This dataset contains real user queries and long-form answers, providing a more realistic QA scenario.

2. TriviaQA: This dataset includes questions from trivia competitions, testing a wider range of knowledge.

3. HotpotQA: This benchmark requires multi-hop reasoning across multiple paragraphs, testing more complex reasoning abilities.

4. RACE: Reading Comprehension from Examinations, which includes passages and questions from English exams for Chinese students.

5. MS MARCO: A large-scale dataset based on real web searches and human-generated answers.

## Conclusion

SQuAD and question-answering benchmarks play a crucial role in evaluating the comprehension and reasoning capabilities of Large Language Models. By implementing and understanding these evaluations, we can gain valuable insights into an LLM's performance on practical NLP tasks. However, it's important to consider multiple benchmarks and real-world applications to get a comprehensive view of an LLM's capabilities and limitations.

In the next lesson, we'll explore multi-task benchmarks like MMLU, which provide an even broader evaluation of LLM performance across various domains and task types.

## Additional Resources

1. SQuAD: The Stanford Question Answering Dataset - [Official Website](https://rajpurkar.github.io/SQuAD-explorer/)
2. "Know What You Don't Know: Unanswerable Questions for SQuAD" by Rajpurkar et al. - [Paper](https://arxiv.org/abs/1806.03822)
3. "BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding" by Devlin et al. - [Paper](https://arxiv.org/abs/1810.04805)
4. "Retrospective Reader for Machine Reading Comprehension" by Zhang et al. - [Paper](https://arxiv.org/abs/2001.09694)
5. "Exploring the Limits of Transfer Learning with a Unified Text-to-Text Transformer" by Raffel et al. - [Paper](https://arxiv.org/abs/1910.10683)

These resources provide deeper insights into SQuAD, question-answering tasks, and state-of-the-art approaches in this field.
