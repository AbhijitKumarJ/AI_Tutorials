# Lesson 3: Setting up your development environment

## File Structure
```
course_repository/
│
├── module_1/
│   ├── lesson_1_intro_to_python.md
│   ├── lesson_2_understanding_llms.md
│   ├── lesson_3_dev_environment_setup.md
│   └── lesson_3_environment_test.ipynb
│
└── resources/
    ├── requirements.txt
    └── gpu_setup_guide.md
```

## Learning Objectives
By the end of this lesson, students will be able to:
1. Set up a Python environment suitable for LLM development
2. Install and manage necessary libraries and dependencies
3. Configure GPU support for faster model training and inference
4. Use Jupyter Notebooks for interactive LLM experimentation
5. Understand best practices for managing LLM projects

## 1. Setting up a Python Environment

### 1.1 Installing Python
If you haven't already installed Python, download and install the latest version from the official Python website (https://www.python.org).

Verify the installation by opening a terminal and running:
```bash
python --version
```

### 1.2 Creating a Virtual Environment
Virtual environments help manage dependencies for different projects.

```bash
# Create a new virtual environment
python -m venv llm_env

# Activate the virtual environment
# On Windows:
llm_env\Scripts\activate
# On macOS and Linux:
source llm_env/bin/activate
```

### 1.3 Managing Dependencies with pip
pip is the package installer for Python. We'll use it to install the necessary libraries.

Create a `requirements.txt` file in your project directory with the following content:

```
numpy
pandas
scikit-learn
torch
transformers
datasets
matplotlib
jupyter
```

Install the dependencies:

```bash
pip install -r requirements.txt
```

## 2. Installing and Configuring LLM Libraries

### 2.1 PyTorch
PyTorch is a popular deep learning framework used by many LLM libraries.

Verify PyTorch installation:
```python
import torch
print(torch.__version__)
print("CUDA available:", torch.cuda.is_available())
```

### 2.2 Hugging Face Transformers
The Transformers library provides easy-to-use implementations of popular LLM architectures.

```python
from transformers import AutoTokenizer, AutoModel

# Load a pre-trained model
model_name = "bert-base-uncased"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModel.from_pretrained(model_name)

# Test the model
text = "Hello, how are you?"
inputs = tokenizer(text, return_tensors="pt")
outputs = model(**inputs)
print(outputs.last_hidden_state.shape)
```

### 2.3 Datasets Library
The Datasets library provides easy access to many NLP datasets.

```python
from datasets import load_dataset

# Load a sample dataset
dataset = load_dataset("glue", "mrpc")
print(dataset)
```

## 3. Configuring GPU Support

### 3.1 CUDA Setup (for NVIDIA GPUs)
1. Install the NVIDIA GPU driver for your system.
2. Install CUDA Toolkit (https://developer.nvidia.com/cuda-downloads).
3. Install cuDNN (https://developer.nvidia.com/cudnn).

Verify CUDA installation:
```python
import torch
print("CUDA version:", torch.version.cuda)
print("cuDNN version:", torch.backends.cudnn.version())
print("Available GPUs:", torch.cuda.device_count())
```

### 3.2 Using GPU in PyTorch
```python
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)

# Move a tensor to GPU
x = torch.rand(5, 3)
x = x.to(device)
```

### 3.3 GPU Memory Management
Be mindful of GPU memory usage, especially when working with large models.

```python
# Clear GPU memory
torch.cuda.empty_cache()

# Check GPU memory usage
print(torch.cuda.memory_summary(device=device))
```

## 4. Using Jupyter Notebooks

### 4.1 Starting Jupyter Notebook
```bash
jupyter notebook
```

This will open a new browser window where you can create and run Jupyter Notebooks.

### 4.2 Creating a New Notebook
1. Click on "New" > "Python 3" to create a new notebook.
2. Rename the notebook by clicking on "Untitled" at the top of the page.

### 4.3 Jupyter Notebook Basics
- Code cells: Write and execute Python code
- Markdown cells: Write formatted text, equations, and explanations
- Execute a cell: Shift + Enter
- Change cell type: Esc + M (for Markdown), Esc + Y (for Code)

### 4.4 Jupyter Extensions (optional)
Install useful Jupyter extensions:

```bash
pip install jupyter_contrib_nbextensions
jupyter contrib nbextension install --user
```

Enable extensions like "Table of Contents" and "Collapsible Headings" from the Nbextensions tab in Jupyter.

## 5. Best Practices for Managing LLM Projects

### 5.1 Project Structure
Organize your project files:

```
llm_project/
│
├── data/
│   ├── raw/
│   └── processed/
│
├── models/
│   └── saved_models/
│
├── notebooks/
│   └── experiments/
│
├── src/
│   ├── data_processing/
│   ├── model/
│   └── utils/
│
├── tests/
│
├── requirements.txt
└── README.md
```

### 5.2 Version Control
Use Git for version control:

```bash
git init
```

Create a `.gitignore` file to exclude large files and sensitive information:

```
# .gitignore
data/
models/saved_models/
*.pyc
.ipynb_checkpoints/
```

### 5.3 Documentation
- Use docstrings for functions and classes
- Maintain a README.md file with project overview and setup instructions
- Comment your code, especially complex parts

### 5.4 Experiment Tracking
Consider using tools like MLflow or Weights & Biases for tracking experiments:

```bash
pip install mlflow
```

```python
import mlflow

mlflow.start_run()
mlflow.log_param("learning_rate", 0.01)
mlflow.log_metric("accuracy", 0.85)
mlflow.end_run()
```

## Exercises

1. Set up a new virtual environment and install the required libraries for LLM development.

2. Create a Jupyter Notebook that demonstrates GPU usage with PyTorch, including tensor operations and a simple neural network.

3. Implement a project structure for a hypothetical LLM fine-tuning task, including data preprocessing, model training, and evaluation scripts.

4. Use the Hugging Face Datasets library to load a text classification dataset and perform basic exploratory data analysis in a Jupyter Notebook.

## Additional Resources

- [PyTorch Documentation](https://pytorch.org/docs/stable/index.html)
- [Hugging Face Transformers Documentation](https://huggingface.co/transformers/)
- [CUDA Toolkit Documentation](https://docs.nvidia.com/cuda/)
- [Jupyter Notebook Documentation](https://jupyter-notebook.readthedocs.io/en/stable/)
- [Git Documentation](https://git-scm.com/doc)
- [MLflow Documentation](https://www.mlflow.org/docs/latest/index.html)

## Next Steps
In the next lesson, we'll dive into basic metrics and evaluation concepts for LLMs, starting with an introduction to NLP evaluation metrics and their importance in assessing model performance.
