# Lesson 10: CIDEr and SPICE Metrics

## Overview
This lesson delves into two advanced metrics originally developed for image captioning tasks but adaptable for text-only evaluation: CIDEr (Consensus-based Image Description Evaluation) and SPICE (Semantic Propositional Image Caption Evaluation). We'll explore their theoretical foundations, implement them in Python, and discuss how to adapt them for text-only tasks, providing students with a deep understanding of these sophisticated evaluation techniques.

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand the concepts behind CIDEr and SPICE metrics, including their origins in image captioning and their relevance to text-only tasks.
2. Implement CIDEr and SPICE in Python, demonstrating proficiency in advanced NLP programming.
3. Analyze the strengths and weaknesses of these metrics, developing critical thinking skills in evaluation methodology.
4. Apply these metrics to text-only tasks beyond image captioning, showcasing adaptability in NLP evaluation techniques.

## File Structure
```
lesson_10/
│
├── notebooks/
│   ├── cider_implementation.ipynb
│   └── spice_implementation.ipynb
│
├── scripts/
│   ├── cider_metric.py
│   └── spice_metric.py
│
├── data/
│   ├── sample_references.txt
│   └── sample_candidates.txt
│
└── requirements.txt
```

## Lesson Content

### 1. Introduction to CIDEr and SPICE (30 minutes)

#### 1.1 Background on Image Captioning Metrics
Image captioning metrics were developed to evaluate the quality of automatically generated image descriptions. These metrics aim to capture how well a generated caption matches human-written reference captions. Understanding the context of these metrics is crucial as we adapt them for text-only tasks in LLM evaluation.

The challenge in image captioning evaluation lies in capturing both the accuracy of the content and the fluency of the language. Traditional n-gram based metrics often fall short in capturing semantic similarities, which led to the development of more sophisticated metrics like CIDEr and SPICE.

#### 1.2 CIDEr (Consensus-based Image Description Evaluation)
CIDEr is a metric that measures the similarity of a generated sentence to a set of reference sentences. It uses Term Frequency-Inverse Document Frequency (TF-IDF) weighting to capture the importance of words. 

Key features of CIDEr:
- TF-IDF Weighting: CIDEr emphasizes informative words by using TF-IDF weighting. This approach gives higher weight to words that are important in the given sentence but rare in the overall corpus. For example, in a caption about a "giraffe in a zoo", the word "giraffe" would likely have a higher TF-IDF weight than "in" or "a".

- Consensus Measurement: CIDEr is designed to capture consensus among human references. It does this by comparing the candidate sentence not just to one, but to a set of reference sentences. This approach helps to account for the variety of ways humans might describe the same content.

- Human Judgment Correlation: CIDEr was designed to correlate well with human judgments. In studies, it has shown a higher correlation with human ratings compared to earlier metrics like BLEU or METEOR, especially in the context of image captioning.

#### 1.3 SPICE (Semantic Propositional Image Caption Evaluation)
SPICE is a metric that measures how well the semantic content of a generated caption matches that of reference captions. It uses scene graphs to represent the meaning of sentences, focusing on the underlying semantics rather than surface-level text similarity.

Key features of SPICE:
- Semantic Focus: Unlike n-gram based metrics, SPICE focuses on semantic similarity rather than word overlap. This allows it to capture meaning-level similarities even when the exact wording differs.

- Scene Graph Representation: SPICE uses scene graphs to capture objects, attributes, and relationships in a sentence. For example, "A red car parked near a tree" might be represented as objects (car, tree), attributes (car-red), and relationships (car-near-tree).

- Paraphrase Robustness: By focusing on semantics, SPICE is generally more robust to paraphrasing than n-gram based metrics. This means it can recognize when two differently worded sentences convey the same meaning.

### 2. Implementing CIDEr in Python (60 minutes)

#### 2.1 TF-IDF Calculation
We'll start by implementing the TF-IDF weighting scheme, which is crucial for CIDEr. This involves several steps:

1. Term Frequency (TF) Calculation: 
   We'll compute how often each n-gram appears in a given sentence. This captures the importance of a term within a single sentence.

2. Inverse Document Frequency (IDF) Computation: 
   We'll calculate how common or rare an n-gram is across all reference sentences. This helps to down-weight common words and emphasize distinctive ones.

3. TF-IDF Combination: 
   We'll combine TF and IDF to get the final weights, which represent both the importance of a term in a sentence and its distinctiveness across all sentences.

Here's a sketch of how we might implement this:

```python
import numpy as np
from collections import Counter

def calculate_tf_idf(candidates, references):
    # Combine all sentences for IDF calculation
    all_sentences = candidates + [ref for refs in references for ref in refs]
    
    # Calculate IDF
    idf = compute_idf(all_sentences)
    
    # Calculate TF-IDF for candidates and references
    candidate_tfidf = [compute_tfidf(cand, idf) for cand in candidates]
    reference_tfidf = [[compute_tfidf(ref, idf) for ref in refs] for refs in references]
    
    return candidate_tfidf, reference_tfidf

def compute_idf(sentences):
    # Implementation details...
    pass

def compute_tfidf(sentence, idf):
    # Implementation details...
    pass
```

#### 2.2 CIDEr Score Computation
Next, we'll implement the CIDEr score calculation. This involves several steps:

1. Cosine Similarity Calculation: 
   We'll compute the cosine similarity between the TF-IDF vectors of the candidate and each reference sentence. This measures how similar the content is, taking into account the importance of each word.

2. N-gram Averaging: 
   CIDEr typically uses n-grams of length 1 to 4. We'll calculate the score for each n-gram length and then take the average. This helps to capture both individual word matches and longer phrase matches.

3. Clipping and Normalization: 
   To prevent gaming the metric with repetition, CIDEr includes a clipping mechanism. We'll also normalize the scores to ensure they're comparable across different reference set sizes.

Here's a sketch of the implementation:

```python
def compute_cider(candidates, references):
    candidate_tfidf, reference_tfidf = calculate_tf_idf(candidates, references)
    
    scores = []
    for cand, refs in zip(candidate_tfidf, reference_tfidf):
        score = 0
        for n in range(1, 5):  # n-grams from 1 to 4
            cand_n = to_n_grams(cand, n)
            refs_n = [to_n_grams(ref, n) for ref in refs]
            score += compute_cider_n(cand_n, refs_n)
        scores.append(score / 4.0)  # Average over n-gram lengths
    
    return np.mean(scores)  # Average over all candidates

def compute_cider_n(candidate, references):
    # Implementation details...
    pass

def to_n_grams(sentence, n):
    # Implementation details...
    pass
```

#### 2.3 Handling Edge Cases
In real-world applications, we often encounter edge cases that require special handling. For CIDEr, some important edge cases include:

1. Empty Candidates or References: 
   We need to decide how to score cases where either the candidate or all references are empty. Typically, an empty candidate with non-empty references would receive a score of 0, while the case of empty references might be considered invalid.

2. Single-Word Sentences: 
   For very short sentences, higher-order n-grams (e.g., 4-grams) might not be applicable. Our implementation should gracefully handle these cases, perhaps by only considering lower-order n-grams.

3. Sentences with Only Stop Words: 
   If a sentence consists entirely of very common words (e.g., "the", "a", "is"), it might end up with zero or near-zero TF-IDF weights. We might need to implement a minimum weight or special handling for these cases.

We'll implement and discuss solutions for these edge cases, ensuring our CIDEr implementation is robust and applicable to a wide range of real-world scenarios.

### 3. Implementing SPICE in Python (90 minutes)

#### 3.1 Scene Graph Generation
SPICE requires converting sentences into scene graphs, which represent the semantic content of the sentence. While full scene graph generation is a complex task, we'll implement a simplified version using spaCy, a popular NLP library. Our approach will involve:

1. Dependency Parsing: 
   We'll use spaCy to perform dependency parsing on the input sentences. This will give us a structured representation of the grammatical relationships between words.

2. Entity and Relation Extraction: 
   From the dependency parse, we'll extract entities (nouns), attributes (adjectives), and relations (verbs and prepositions connecting entities).

3. Graph Construction: 
   We'll construct a graph where nodes represent entities and attributes, and edges represent relations between entities.

Here's a sketch of how we might implement this:

```python
import spacy

nlp = spacy.load("en_core_web_sm")

def generate_scene_graph(sentence):
    doc = nlp(sentence)
    
    entities = [token for token in doc if token.pos_ in ["NOUN", "PROPN"]]
    attributes = [token for token in doc if token.pos_ == "ADJ"]
    relations = [token for token in doc if token.pos_ in ["VERB", "ADP"]]
    
    graph = {
        "entities": [(ent.text, ent.lemma_) for ent in entities],
        "attributes": [(attr.text, attr.head.text) for attr in attributes],
        "relations": [(rel.text, rel.head.text, [child.text for child in rel.children]) for rel in relations]
    }
    
    return graph
```

This simplified approach captures the essence of scene graphs without requiring complex semantic parsing or world knowledge integration.

#### 3.2 Semantic Proposition Matching
The core of the SPICE algorithm involves matching semantic propositions between the candidate and reference scene graphs. This process includes:

1. Proposition Extraction: 
   We'll extract propositions (tuples of objects, attributes, and relationships) from both the candidate and reference scene graphs.

2. Matching Algorithm: 
   We'll implement a matching algorithm that compares propositions from the candidate graph to those in the reference graphs. This matching considers synonyms and allows for partial matches.

3. Score Calculation: 
   Based on the matched propositions, we'll calculate precision (proportion of candidate propositions that match references), recall (proportion of reference propositions matched by the candidate), and F1-score (harmonic mean of precision and recall).

Here's a sketch of this implementation:

```python
def match_propositions(candidate_graph, reference_graph):
    candidate_props = extract_propositions(candidate_graph)
    reference_props = extract_propositions(reference_graph)
    
    matches = 0
    for c_prop in candidate_props:
        if any(prop_match(c_prop, r_prop) for r_prop in reference_props):
            matches += 1
    
    precision = matches / len(candidate_props) if candidate_props else 0
    recall = matches / len(reference_props) if reference_props else 0
    f1 = 2 * (precision * recall) / (precision + recall) if precision + recall > 0 else 0
    
    return f1

def extract_propositions(graph):
    # Implementation details...
    pass

def prop_match(prop1, prop2):
    # Implementation details, including synonym handling...
    pass

def calculate_spice(candidate, references):
    cand_graph = generate_scene_graph(candidate)
    ref_graphs = [generate_scene_graph(ref) for ref in references]
    
    scores = [match_propositions(cand_graph, ref_graph) for ref_graph in ref_graphs]
    return np.mean(scores)
```

#### 3.3 Handling Complex Semantic Structures
Real-world sentences often contain complex semantic structures that can be challenging for our simplified scene graph approach. We'll discuss strategies for handling these, including:

1. Coreference Resolution: 
   Identifying when different mentions refer to the same entity (e.g., "The cat... It...").

2. Implicit Relations: 
   Capturing relationships that are implied but not explicitly stated.

3. Figurative Language: 
   Dealing with metaphors, idioms, and other non-literal language use.

While fully solving these challenges is beyond the scope of this lesson, we'll implement basic heuristics and discuss more advanced techniques that could be applied in a production system.

### 4. Adapting CIDEr and SPICE for Text-Only Tasks (30 minutes)

While CIDEr and SPICE were originally designed for image captioning, they can be valuable for evaluating text generation in LLMs. We'll discuss:

1. Task Adaptation: 
   How to frame different text generation tasks (e.g., summarization, paraphrasing) in terms suitable for CIDEr and SPICE evaluation.

2. Reference Selection: 
   Strategies for selecting or generating appropriate reference texts for different tasks.

3. Interpretation of Scores: 
   How to interpret CIDEr and SPICE scores in the context of text-only tasks, and what they reveal about different aspects of generation quality.

4. Complementary Use: 
   How to use CIDEr and SPICE in conjunction with other metrics for a more comprehensive evaluation of LLM outputs.

### 5. Practical Exercise and Discussion (30 minutes)

To conclude the lesson, students will apply the implemented CIDEr and SPICE metrics to evaluate outputs from a pre-trained LLM on a text summarization task. This exercise will involve:

1. Generating summaries using a pre-trained model
2. Evaluating the summaries using our CIDEr and SPICE implementations
3. Analyzing the results and discussing the strengths and limitations of these metrics
4. Comparing the insights gained from CIDEr and SPICE to those from more traditional metrics like ROUGE

This hands-on experience will solidify students' understanding of these advanced metrics and their application in real-world LLM evaluation scenarios.

## Additional Resources
- Original CIDEr paper: "CIDEr: Consensus-based Image Description Evaluation" by Vedantam et al.
- Original SPICE paper: "SPICE: Semantic Propositional Image Caption Evaluation" by Anderson et al.
- spaCy documentation for dependency parsing and named entity recognition
- Research papers on adapting image captioning metrics for text-only tasks

By the end of this comprehensive lesson, students will have gained both theoretical understanding and practical skills in implementing and applying CIDEr and SPICE metrics, preparing them for advanced LLM evaluation tasks.
