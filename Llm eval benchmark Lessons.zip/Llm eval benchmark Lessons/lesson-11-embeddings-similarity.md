# Lesson 11: Introduction to Embeddings and Semantic Similarity

## Overview
This lesson introduces the crucial concepts of word embeddings and semantic similarity, which form the foundation for many advanced natural language processing (NLP) techniques, including modern evaluation metrics for Large Language Models (LLMs). We'll explore different types of embeddings, methods to create them, and how they enable the computation of semantic similarity between words and texts.

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand the concept of word embeddings and their importance in NLP
2. Differentiate between static word embeddings and contextual embeddings
3. Implement and use popular embedding models like Word2Vec and BERT
4. Compute semantic similarity using various embedding-based methods
5. Apply embedding-based similarity measures to basic NLP tasks

## File Structure
```
lesson_11/
│
├── notebooks/
│   ├── static_embeddings.ipynb
│   └── contextual_embeddings.ipynb
│
├── scripts/
│   ├── word2vec_example.py
│   └── bert_embeddings.py
│
├── data/
│   └── sample_corpus.txt
│
└── requirements.txt
```

## Lesson Content

### 1. Introduction to Word Embeddings (30 minutes)

#### 1.1 What are Word Embeddings?
Word embeddings are dense vector representations of words in a continuous vector space. Unlike traditional one-hot encodings, embeddings capture semantic relationships between words, allowing similar words to have similar vector representations.

Key characteristics of word embeddings:
- Dense vectors: Typically 100-300 dimensions, much smaller than vocabulary size
- Learned from data: Capture co-occurrence statistics and semantic relationships
- Enable similarity computations: Similar words have similar vectors

#### 1.2 Why are Embeddings Important?
Embeddings have revolutionized NLP for several reasons:

1. Dimensionality Reduction: 
   They provide a compact representation of words, reducing the dimensionality from the size of the vocabulary (often 100,000+) to a few hundred dimensions.

2. Semantic Meaning: 
   Embeddings capture semantic relationships, allowing models to understand similarities and analogies between words.

3. Transfer Learning: 
   Pre-trained embeddings can be used as starting points for various NLP tasks, improving performance and reducing training time.

4. Enabling Neural Networks: 
   Dense embeddings work well with neural network architectures, enabling advanced NLP models.

#### 1.3 Types of Embeddings
We'll focus on two main categories of embeddings:

1. Static Word Embeddings:
   - Examples: Word2Vec, GloVe, FastText
   - Characteristics: 
     - Each word has a fixed vector regardless of context
     - Good for capturing general word semantics
     - Struggle with polysemy (words with multiple meanings)

2. Contextual Embeddings:
   - Examples: BERT, ELMo, GPT
   - Characteristics:
     - Word representations change based on surrounding context
     - Better at capturing context-dependent meanings
     - More computationally intensive

### 2. Static Word Embeddings: Word2Vec (45 minutes)

#### 2.1 Introduction to Word2Vec
Word2Vec, introduced by Mikolov et al. in 2013, is one of the most popular static embedding models. It comes in two flavors:

1. Continuous Bag of Words (CBOW): 
   Predicts a target word from its context words.

2. Skip-gram: 
   Predicts context words given a target word.

Both approaches learn embeddings by training a shallow neural network on a large corpus of text.

#### 2.2 How Word2Vec Works
Key concepts of Word2Vec:

1. Training Objective: 
   Maximize the probability of observing the actual context words given the target word (Skip-gram) or vice versa (CBOW).

2. Negative Sampling: 
   To make training efficient, Word2Vec uses negative sampling, which contrasts the true context with randomly sampled negative examples.

3. Vector Operations: 
   The resulting embeddings support meaningful vector operations, e.g., vector("king") - vector("man") + vector("woman") ≈ vector("queen").

#### 2.3 Implementing Word2Vec
We'll use the Gensim library to train a Word2Vec model:

```python
from gensim.models import Word2Vec
from gensim.utils import simple_preprocess

# Load and preprocess the corpus
with open('data/sample_corpus.txt', 'r') as f:
    corpus = [simple_preprocess(line) for line in f]

# Train the Word2Vec model
model = Word2Vec(sentences=corpus, vector_size=100, window=5, min_count=1, workers=4)

# Find similar words
similar_words = model.wv.most_similar('computer', topn=5)
print(similar_words)

# Vector operations
result = model.wv['king'] - model.wv['man'] + model.wv['woman']
most_similar = model.wv.similar_by_vector(result, topn=1)
print(f"king - man + woman ≈ {most_similar[0][0]}")
```

### 3. Contextual Embeddings: BERT (45 minutes)

#### 3.1 Introduction to BERT
BERT (Bidirectional Encoder Representations from Transformers), introduced by Devlin et al. in 2018, revolutionized NLP by providing powerful contextual embeddings.

Key features of BERT:
- Bidirectional context: Considers both left and right context for each word
- Pre-training tasks: Masked Language Model (MLM) and Next Sentence Prediction (NSP)
- Transfer learning: Can be fine-tuned for various downstream tasks

#### 3.2 How BERT Embeddings Work
Unlike static embeddings, BERT produces different vectors for the same word in different contexts:

1. Tokenization: 
   BERT uses WordPiece tokenization, breaking words into subwords.

2. Positional Encoding: 
   Adds position information to each token embedding.

3. Self-Attention: 
   Uses transformer layers to compute contextual representations.

4. Layer Selection: 
   Different layers capture different levels of linguistic information. Often, a combination of layers is used.

#### 3.3 Implementing BERT Embeddings
We'll use the transformers library to generate BERT embeddings:

```python
from transformers import BertTokenizer, BertModel
import torch

# Load pre-trained model and tokenizer
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertModel.from_pretrained('bert-base-uncased')

# Prepare input
text = "The quick brown fox jumps over the lazy dog."
inputs = tokenizer(text, return_tensors="pt")

# Generate embeddings
with torch.no_grad():
    outputs = model(**inputs)

# Extract embeddings (last hidden state)
embeddings = outputs.last_hidden_state

print(f"Shape of embeddings: {embeddings.shape}")
```

### 4. Computing Semantic Similarity (45 minutes)

#### 4.1 Cosine Similarity
Cosine similarity is the most common method for computing similarity between embedding vectors:

1. Definition: 
   Cosine similarity measures the cosine of the angle between two vectors.

2. Formula: 
   cos(θ) = (A · B) / (||A|| ||B||), where A and B are vectors.

3. Properties:
   - Ranges from -1 (opposite) to 1 (identical), with 0 indicating orthogonality
   - Insensitive to vector magnitude, focusing on direction

#### 4.2 Implementing Cosine Similarity
We'll implement cosine similarity for both static and contextual embeddings:

```python
import numpy as np

def cosine_similarity(vec1, vec2):
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

# For Word2Vec
similarity = cosine_similarity(model.wv['computer'], model.wv['laptop'])
print(f"Similarity between 'computer' and 'laptop': {similarity}")

# For BERT
def get_bert_embedding(text):
    inputs = tokenizer(text, return_tensors="pt")
    with torch.no_grad():
        outputs = model(**inputs)
    return outputs.last_hidden_state.mean(dim=1).squeeze().numpy()

text1 = "The cat sits on the mat."
text2 = "A feline rests on a rug."

emb1 = get_bert_embedding(text1)
emb2 = get_bert_embedding(text2)

similarity = cosine_similarity(emb1, emb2)
print(f"Similarity between '{text1}' and '{text2}': {similarity}")
```

#### 4.3 Other Similarity Measures
While cosine similarity is most common, other measures can be useful:

1. Euclidean Distance: 
   Measures the straight-line distance between two points in the embedding space.

2. Dot Product: 
   Simple multiplication of vectors, sensitive to magnitude.

3. Jaccard Similarity: 
   Useful for comparing sets of words, based on overlap.

### 5. Applications of Embeddings and Similarity (30 minutes)

#### 5.1 Text Classification
Embeddings can improve text classification by providing rich, low-dimensional representations:

```python
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline

# Traditional approach
tfidf_clf = make_pipeline(TfidfVectorizer(), MultinomialNB())

# Embedding-based approach (pseudo-code)
def document_embedding(doc):
    # Average word embeddings for the document
    return np.mean([model.wv[word] for word in doc if word in model.wv], axis=0)

# Use document_embedding in your ML pipeline
```

#### 5.2 Information Retrieval
Embeddings enable semantic search, going beyond keyword matching:

```python
def semantic_search(query, documents, top_k=5):
    query_emb = get_bert_embedding(query)
    doc_embs = [get_bert_embedding(doc) for doc in documents]
    
    similarities = [cosine_similarity(query_emb, doc_emb) for doc_emb in doc_embs]
    top_indices = np.argsort(similarities)[-top_k:][::-1]
    
    return [(documents[i], similarities[i]) for i in top_indices]

# Example usage
query = "What is the capital of France?"
documents = ["Paris is the capital of France.", "London is in England.", "Berlin is a city in Germany."]

results = semantic_search(query, documents)
for doc, score in results:
    print(f"Score: {score:.4f} - {doc}")
```

#### 5.3 Text Similarity for Evaluation
Embedding-based similarity forms the basis for advanced evaluation metrics like BERTScore:

```python
def simple_bertscore(candidate, reference):
    cand_emb = get_bert_embedding(candidate)
    ref_emb = get_bert_embedding(reference)
    return cosine_similarity(cand_emb, ref_emb)

candidate = "The feline lounges on the carpet."
reference = "A cat is sitting on a mat."

score = simple_bertscore(candidate, reference)
print(f"Simple BERTScore: {score:.4f}")
```

### 6. Practical Exercise and Discussion (45 minutes)

#### 6.1 Exercise: Semantic Textual Similarity
Students will implement a simple semantic textual similarity system using both Word2Vec and BERT embeddings. They will evaluate the system on a small dataset of sentence pairs with human-annotated similarity scores.

```python
# Provided: dataset of sentence pairs with similarity scores
sentence_pairs = [
    ("The cat sits on the mat.", "A feline rests on a rug.", 0.8),
    ("The dog barks loudly.", "A canine makes noise.", 0.6),
    ("The sun is shining.", "It's raining outside.", 0.1),
    # ... more examples ...
]

# Task 1: Implement similarity computation using Word2Vec
def word2vec_similarity(sent1, sent2, model):
    # Your implementation here
    pass

# Task 2: Implement similarity computation using BERT
def bert_similarity(sent1, sent2, model, tokenizer):
    # Your implementation here
    pass

# Task 3: Evaluate both methods
def evaluate_similarity(sentence_pairs, similarity_func):
    predicted = [similarity_func(pair[0], pair[1]) for pair in sentence_pairs]
    actual = [pair[2] for pair in sentence_pairs]
    correlation = np.corrcoef(predicted, actual)[0, 1]
    return correlation

# Run evaluation and compare results
```

#### 6.2 Discussion Points
After completing the exercise, discuss:
1. How do Word2Vec and BERT similarities differ? When might each be preferable?
2. What are the limitations of these embedding-based similarity measures?
3. How might these techniques be applied in real-world NLP tasks or LLM evaluation?
4. What ethical considerations should we keep in mind when using word embeddings?

### 7. Conclusion and Further Resources (15 minutes)

#### 7.1 Recap of Key Points
- Embeddings provide dense vector representations of words and texts
- Static embeddings (e.g., Word2Vec) offer fixed representations, while contextual embeddings (e.g., BERT) are context-dependent
- Semantic similarity can be computed using these embeddings, with cosine similarity being a common measure
- Embedding-based techniques have wide applications in NLP, including classification, retrieval, and evaluation

#### 7.2 Further Reading and Resources
- Original Word2Vec paper: "Efficient Estimation of Word Representations in Vector Space" by Mikolov et al.
- BERT paper: "BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding" by Devlin et al.
- Book: "Natural Language Processing with Transformers" by Lewis et al.
- Tutorial: "Word Embeddings: Encoding Lexical Semantics" in the Stanford CS224N course materials

#### 7.3 Next Steps
Encourage students to:
- Experiment with different pre-trained embedding models
- Explore more advanced similarity measures and their applications
- Consider how embeddings and similarity measures can be integrated into their own NLP projects or research

By the end of this comprehensive lesson, students will have gained both theoretical understanding and practical experience with word embeddings and semantic similarity, preparing them for more advanced topics in NLP and LLM evaluation.

