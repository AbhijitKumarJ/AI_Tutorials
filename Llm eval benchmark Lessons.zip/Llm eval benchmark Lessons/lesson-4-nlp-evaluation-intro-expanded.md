# Lesson 4: Introduction to NLP evaluation metrics (Expanded)

## File Structure
```
course_repository/
│
├── module_2/
│   ├── lesson_4_nlp_evaluation_intro.md
│   └── lesson_4_evaluation_examples.ipynb
│
└── resources/
    └── evaluation_metrics_cheatsheet.pdf
```

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand the importance of evaluation metrics in NLP and LLM development
2. Differentiate between various types of NLP tasks and their corresponding evaluation metrics
3. Describe common evaluation metrics for different NLP tasks
4. Implement basic evaluation metrics using Python and popular NLP libraries
5. Interpret evaluation results and understand their implications for model performance

## 1. Importance of Evaluation Metrics in NLP and LLM Development

Evaluation metrics play a crucial role in the development and deployment of NLP models, including Large Language Models (LLMs). Let's explore their importance in detail:

1. Objective Assessment of Model Performance: 
   Evaluation metrics provide a quantitative measure of how well a model performs on a given task. This objectivity is crucial for scientific rigor and allows researchers and practitioners to make informed decisions about model selection and improvement.

2. Comparative Analysis:
   Metrics enable us to compare different models or approaches systematically. This is particularly important in a rapidly evolving field like NLP, where new architectures and techniques are constantly being developed. Standardized metrics allow for fair comparisons across different research efforts.

3. Progress Tracking:
   During the development process, metrics help track improvements over time. This is essential for iterative development, where small changes to model architecture, training data, or hyperparameters can significantly impact performance.

4. Identifying Areas for Improvement:
   By analyzing performance across different metrics, we can identify specific weaknesses in a model. For example, a machine translation model might have high BLEU scores but low human evaluation scores, indicating a need to focus on fluency and naturalness.

5. Production Readiness:
   Metrics help determine when a model is ready for production deployment. By setting performance thresholds across various metrics, teams can ensure that models meet the necessary quality standards before being used in real-world applications.

6. Cross-Task and Cross-Dataset Understanding:
   Evaluating models on multiple tasks and datasets using various metrics provides a more comprehensive understanding of a model's capabilities and limitations. This is particularly important for large language models that are designed to be general-purpose.

7. Alignment with Human Judgment:
   While not perfect, many NLP metrics are designed to correlate with human judgments of quality. This alignment helps bridge the gap between computational evaluation and real-world utility of NLP systems.

8. Facilitating Research Communication:
   Standardized metrics provide a common language for researchers to communicate their findings. This standardization is crucial for reproducibility and for building upon previous work in the field.

## 2. Types of NLP Tasks and Corresponding Evaluation Metrics

NLP encompasses a wide range of tasks, each requiring specific evaluation approaches. Let's examine some key task types and their associated metrics:

### 2.1 Text Classification
Text classification involves assigning predefined categories to text documents. Examples include:
- Sentiment Analysis: Determining the emotional tone of a piece of text (e.g., positive, negative, neutral).
- Spam Detection: Identifying unwanted or malicious messages.
- Topic Classification: Categorizing documents into predefined topics or themes.

Common metrics for text classification tasks:
- Accuracy: The proportion of correct predictions among the total number of cases examined.
- Precision: The ratio of true positive predictions to the total positive predictions. It answers the question, "Of all the instances the model labeled as positive, how many actually were positive?"
- Recall: The ratio of true positive predictions to the total actual positive instances. It answers, "Of all the actual positive instances, how many did the model correctly identify?"
- F1-score: The harmonic mean of precision and recall, providing a single score that balances both metrics.
- ROC-AUC: The Area Under the Receiver Operating Characteristic curve, which represents the model's ability to distinguish between classes.

### 2.2 Sequence Labeling
Sequence labeling tasks involve assigning a label to each element in a sequence. Key examples include:
- Named Entity Recognition (NER): Identifying and categorizing named entities (e.g., person names, organizations, locations) in text.
- Part-of-Speech (POS) Tagging: Assigning grammatical categories (e.g., noun, verb, adjective) to each word in a sentence.

Common metrics for sequence labeling tasks:
- Token-level Accuracy: The proportion of correctly labeled tokens.
- Precision, Recall, and F1-score: These are calculated at the entity level, considering both the type and span of predicted entities.
- Confusion Matrix: A table showing the distribution of predicted vs. actual labels, helpful for identifying specific types of errors.

### 2.3 Text Generation
Text generation tasks involve producing human-readable text based on some input or prompt. Examples include:
- Machine Translation: Translating text from one language to another.
- Text Summarization: Generating concise summaries of longer documents.
- Dialogue Generation: Producing appropriate responses in conversational systems.

Common metrics for text generation tasks:
- BLEU (Bilingual Evaluation Understudy): Measures the overlap of n-grams between the generated text and reference text(s).
- ROUGE (Recall-Oriented Understudy for Gisting Evaluation): A set of metrics that compare generated text with reference summaries, particularly useful for summarization tasks.
- METEOR (Metric for Evaluation of Translation with Explicit ORdering): Designed to address some limitations of BLEU, it considers synonyms and paraphrases.
- Perplexity: A measure of how well a probability model predicts a sample, often used in language modeling tasks.

### 2.4 Text Similarity
Text similarity tasks involve determining how similar two pieces of text are to each other. Examples include:
- Semantic Textual Similarity: Assessing the degree to which two sentences are semantically equivalent.
- Paraphrase Detection: Identifying whether two sentences or phrases have the same meaning.

Common metrics for text similarity tasks:
- Cosine Similarity: Measures the cosine of the angle between two vectors in a multi-dimensional space, often used with text embeddings.
- Pearson Correlation: Measures the linear correlation between predicted similarity scores and human-annotated scores.
- Spearman Correlation: Assesses the monotonic relationship between predicted and human-annotated similarity scores.

### 2.5 Question Answering
Question answering tasks involve systems that can automatically answer questions posed in natural language. Examples include:
- Open-domain QA: Answering questions on a wide range of topics without a predefined knowledge base.
- Reading Comprehension: Answering questions based on a given passage of text.

Common metrics for question answering tasks:
- Exact Match (EM): The percentage of predictions that exactly match the ground truth answer.
- F1-score: In the context of QA, this measures the overlap between predicted and ground truth answers at the token level.
- Mean Reciprocal Rank (MRR): Used when multiple answers are returned, measuring the rank of the first correct answer.

### 2.6 Language Modeling
Language modeling involves predicting the probability of sequences of words. While often a component of other tasks, it can be evaluated independently. Examples include:
- Next Word Prediction: Predicting the most likely next word given a sequence of previous words.
- Fill-in-the-Blank Tasks: Predicting missing words in a sentence or paragraph.

Common metrics for language modeling tasks:
- Perplexity: A measurement of how well a probability model predicts a sample. Lower perplexity indicates better performance.
- Bits Per Character (BPC): Similar to perplexity but measured at the character level, useful for character-level language models.

## 3. Common Evaluation Metrics for NLP Tasks

Let's dive deeper into some of the most commonly used evaluation metrics across various NLP tasks:

### 3.1 Accuracy
Accuracy is the ratio of correct predictions to the total number of predictions. While simple to understand and implement, it can be misleading for imbalanced datasets.

```python
from sklearn.metrics import accuracy_score

y_true = [0, 1, 1, 0, 1]
y_pred = [0, 1, 0, 0, 1]

accuracy = accuracy_score(y_true, y_pred)
print(f"Accuracy: {accuracy}")
```

### 3.2 Precision, Recall, and F1-score
These metrics provide a more nuanced view of model performance, especially for imbalanced datasets:

- Precision: The ratio of true positive predictions to the total positive predictions. It measures the model's ability to avoid labeling negative instances as positive.
- Recall: The ratio of true positive predictions to the total actual positive instances. It measures the model's ability to find all positive instances.
- F1-score: The harmonic mean of precision and recall, providing a single score that balances both metrics.

```python
from sklearn.metrics import precision_recall_fscore_support

precision, recall, f1, _ = precision_recall_fscore_support(y_true, y_pred, average='binary')
print(f"Precision: {precision:.2f}")
print(f"Recall: {recall:.2f}")
print(f"F1-score: {f1:.2f}")
```

### 3.3 BLEU (Bilingual Evaluation Understudy)
BLEU is commonly used for evaluating machine translation and text generation tasks. It measures the overlap of n-grams between the generated text and reference text(s). BLEU scores range from 0 to 1, with 1 indicating a perfect match.

```python
from nltk.translate.bleu_score import sentence_bleu

reference = [['the', 'cat', 'is', 'on', 'the', 'mat']]
candidate = ['the', 'cat', 'sat', 'on', 'the', 'mat']

bleu_score = sentence_bleu(reference, candidate)
print(f"BLEU score: {bleu_score:.4f}")
```

### 3.4 ROUGE (Recall-Oriented Understudy for Gisting Evaluation)
ROUGE is often used for evaluating text summarization and generation tasks. It compares the generated text with one or more reference texts. There are several ROUGE variants, including ROUGE-N (n-gram overlap), ROUGE-L (longest common subsequence), and ROUGE-S (skip-gram concurrence).

```python
from rouge import Rouge

rouge = Rouge()
reference = "The cat is on the mat."
hypothesis = "There is a cat on the mat."

scores = rouge.get_scores(hypothesis, reference)
print(f"ROUGE-1 F1-score: {scores[0]['rouge-1']['f']:.4f}")
```

### 3.5 Perplexity
Perplexity is a measure of how well a probability model predicts a sample. It's commonly used in language modeling tasks. Lower perplexity indicates better performance, as it suggests the model is less "surprised" by the test data.

```python
import numpy as np

def perplexity(probabilities):
    return np.exp(-np.mean(np.log(probabilities)))

# Example: probabilities of words in a sequence
word_probabilities = [0.1, 0.2, 0.05, 0.1, 0.15]
ppl = perplexity(word_probabilities)
print(f"Perplexity: {ppl:.2f}")
```

## 4. Implementing Evaluation Metrics

Let's implement a more comprehensive example that evaluates a text classification model:

```python
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

# Sample data
texts = [
    "I love this movie", "Great film, highly recommended",
    "Terrible movie, waste of time", "I hated every minute of it",
    "Amazing plot and acting", "Boring and predictable"
]
labels = [1, 1, 0, 0, 1, 0]  # 1 for positive, 0 for negative

# Split data
X_train, X_test, y_train, y_test = train_test_split(texts, labels, test_size=0.3, random_state=42)

# Vectorize text
vectorizer = CountVectorizer()
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# Train model
model = MultinomialNB()
model.fit(X_train_vec, y_train)

# Make predictions
y_pred = model.predict(X_test_vec)

# Evaluate model
print(classification_report(y_test, y_pred, target_names=['Negative', 'Positive']))
```

## 5. Interpreting Evaluation Results

When interpreting evaluation results, consider the following aspects:

1. Context: 
   Understand what is considered a good score for each metric in your specific task and domain. For example, a BLEU score of 0.3 might be considered good for a complex language pair in machine translation, while it would be poor for a simpler task.

2. Balance: 
   Look at multiple metrics to get a comprehensive view of model performance. For instance, in a classification task, high precision but low recall might indicate a conservative model that misses many positive instances.

3. Error Analysis: 
   Examine individual errors to understand model weaknesses. This qualitative analysis can reveal patterns in misclassifications or generation errors that aren't apparent from aggregate metrics.

4. Baseline Comparison: 
   Compare your model's performance to simple baselines (e.g., majority class predictor, rule-based systems) and state-of-the-art models. This helps contextualize your model's performance within the current landscape of solutions.

5. Statistical Significance: 
   For small datasets, consider whether performance differences are statistically significant. Techniques like bootstrap resampling can help assess the reliability of observed differences.

6. Real-world Impact: 
   Translate metric improvements into tangible benefits for your application. For example, how does a 2% increase in F1-score translate to user experience or business metrics?

7. Limitations of Metrics: 
   Be aware of the limitations of each metric. For instance, BLEU has been criticized for not always correlating well with human judgments of translation quality, especially for non-European languages.

8. Task-Specific Considerations: 
   Some tasks may require additional or specialized evaluation approaches. For example, dialogue systems might be evaluated on metrics like coherence or engagement, which are not captured by standard NLP metrics.

9. Human Evaluation: 
   For many NLP tasks, especially those involving generation, human evaluation remains a crucial complement to automatic metrics. Consider incorporating human judgments in your evaluation pipeline.

10. Robustness and Generalization: 
    Evaluate your model's performance across different subsets of data or out-of-distribution samples to assess its robustness and ability to generalize.

## Exercises

1. Implement a function to calculate the token-level accuracy for a named entity recognition task. Use the CoNLL-2003 dataset and evaluate a pre-trained model's performance.

2. Use the `transformers` library to fine-tune a pre-trained BERT model on the IMDB movie review dataset for sentiment analysis. Evaluate its performance using accuracy, precision, recall, and F1-score. Compare these results with a baseline model (e.g., logistic regression on TF-IDF features).

3. Implement the METEOR score for machine translation evaluation. Apply it to assess the quality of translations between English and another language of your choice using a pre-trained machine translation model.

4. Create a Jupyter notebook that demonstrates the calculation and interpretation of different evaluation metrics for a multi-class text classification problem. Use the AG News dataset and compare the performance of at least two different models.

5. Research and write a short report (1000-1500 words) on the limitations of current NLP evaluation metrics and proposed alternatives or improvements in recent literature. Include discussions on metrics like BERTScore, MoverScore, or learnable metrics.

## Additional Resources

To deepen your understanding of NLP evaluation metrics and stay current with the latest developments in the field, explore the following resources:

1. [sklearn.metrics documentation](https://scikit-learn.org/stable/modules/classes.html#module-sklearn.metrics): 
   This comprehensive guide provides detailed explanations and implementations of various evaluation metrics in scikit-learn. It's an excellent reference for understanding the mathematical foundations and practical applications of common metrics.

2. [NLTK BLEU score implementation](https://www.nltk.org/_modules/nltk/translate/bleu_score.html): 
   Dive into the source code of NLTK's BLEU score implementation to understand the intricacies of this widely used metric for machine translation evaluation.

3. [Evaluating Text Output in NLP: BLEU at Your Own Risk](https://towardsdatascience.com/evaluating-text-output-in-nlp-bleu-at-your-own-risk-e8609665a213): 
   This blog post offers a critical perspective on the limitations of BLEU and discusses alternative evaluation approaches for text generation tasks.

4. [SacreBLEU: A Standardized BLEU Implementation](https://github.com/mjpost/sacrebleu): 
   Explore this project, which aims to standardize BLEU score computation across different implementations, addressing issues of reproducibility in machine translation research.

5. [Beyond Accuracy: Behavioral Testing of NLP Models with CheckList](https://arxiv.org/abs/2005.04118): 
   This paper introduces a novel evaluation methodology that goes beyond traditional metrics, focusing on comprehensive behavioral testing of NLP models.

6. [The Unstoppable Rise of Computational Linguistics in Deep Learning](https://arxiv.org/abs/1707.01780): 
   This survey paper provides an overview of evaluation methodologies in computational linguistics, offering insights into both traditional and emerging evaluation approaches.

7. [Meta-Evaluation of Conversational Search Evaluation Metrics](https://arxiv.org/abs/2104.13453): 
   This paper discusses the challenges of evaluating conversational AI systems and proposes a framework for meta-evaluation of metrics in this domain.

8. [GLUE Benchmark](https://gluebenchmark.com/): 
   Familiarize yourself with this multi-task benchmark for evaluating natural language understanding systems. Understanding GLUE can provide insights into comprehensive model evaluation strategies.

9. [Hugging Face Evaluate Library](https://huggingface.co/docs/evaluate/index): 
   This library provides a simple and unified way to evaluate machine learning models across various tasks and metrics. It's particularly useful for evaluating transformer-based models.

10. [Better Evaluation for Machine Translation: Putting Human Judgments First](https://aclanthology.org/2023.eamt-1.13/): 
    This paper discusses the importance of human evaluation in machine translation and proposes methods to improve the correlation between automatic metrics and human judgments.

## Next Steps

Now that you have a solid foundation in NLP evaluation metrics, you're ready to dive deeper into more advanced topics and practical applications. Here's what you can look forward to in the upcoming lessons:

1. Token-level Accuracy and Perplexity (Next Lesson): 
   We'll explore these fundamental metrics in depth, including their mathematical foundations, implementation details, and use cases in language modeling tasks.

2. Advanced Metrics for Text Generation: 
   You'll learn about sophisticated metrics like METEOR, TER, NIST, CIDEr, and SPICE, understanding their strengths and limitations in evaluating generated text.

3. Neural Network-Based Metrics: 
   We'll dive into modern evaluation approaches that leverage neural networks, such as BERTScore, BLEURT, and MoverScore, discussing how they address limitations of traditional metrics.

4. Task-Specific Benchmarks: 
   You'll explore comprehensive evaluation frameworks like GLUE, SuperGLUE, and SQuAD, understanding how to use these benchmarks to assess model performance across various NLP tasks.

5. Specialized Evaluation Concepts: 
   We'll cover topics like few-shot and zero-shot learning evaluation, robustness testing, and bias detection in LLMs.

6. Practical LLM Deployment and Efficiency: 
   You'll learn about evaluating model size, inference speed, and latency, crucial considerations for real-world LLM applications.

7. Ethical Considerations in Evaluation: 
   We'll discuss the importance of fairness, transparency, and responsible AI practices in LLM evaluation.

8. Capstone Project: 
   You'll apply your knowledge to design and implement a comprehensive LLM evaluation pipeline, synthesizing various metrics and approaches learned throughout the course.

Remember, evaluation is an ongoing process in NLP research and development. As you progress through the course, continually reflect on how these metrics relate to real-world model performance and user satisfaction. Stay curious about new evaluation methodologies and always consider the broader implications of LLM capabilities and limitations.

Get ready to deepen your understanding and sharpen your practical skills in LLM evaluation. The journey ahead is exciting and full of opportunities to contribute to this rapidly evolving field!

