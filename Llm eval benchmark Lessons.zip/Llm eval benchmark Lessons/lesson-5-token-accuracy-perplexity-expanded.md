# Lesson 5: Token-level accuracy and perplexity

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand the concept of tokens in NLP and their importance in language processing
2. Calculate and interpret token-level accuracy, recognizing its strengths and limitations in LLM evaluation
3. Comprehend the concept of perplexity, its mathematical foundations, and its role in assessing language models
4. Implement token-level accuracy and perplexity calculations in Python using both custom functions and popular NLP libraries
5. Apply these metrics to evaluate LLM performance and interpret the results in the context of model improvement

## Lesson Duration
Approximately 3 hours

## Prerequisites
- Basic Python programming skills, including familiarity with functions, loops, and data structures
- Understanding of LLMs and their applications (covered in Module 1), including basic knowledge of how LLMs generate text
- Familiarity with basic NLP concepts (covered in Module 1), such as the difference between words and characters in text processing

## File Structure
```
lesson_5/
│
├── token_accuracy_perplexity.ipynb
├── data/
│   ├── sample_texts.txt
│   └── llm_predictions.txt
├── utils/
│   └── nlp_helpers.py
├── images/
│   ├── tokenization_example.png
│   └── perplexity_intuition.png
└── README.md
```

## Lesson Content

### 1. Introduction (20 minutes)
- Recap of previous lessons on LLMs and evaluation:
  Briefly revisit the core concepts of Large Language Models, their applications, and the importance of robust evaluation metrics. Emphasize how the performance of LLMs in various tasks necessitates specialized evaluation techniques.

- Importance of token-level metrics in LLM evaluation:
  Discuss why we need to evaluate LLMs at the token level. Explain how token-level analysis provides insights into the model's understanding of language structure and its ability to predict individual elements of text. Highlight how this granular approach complements broader evaluation methods.

- Overview of today's topics: tokens, accuracy, and perplexity:
  Provide a roadmap for the lesson, explaining how understanding tokens leads into measuring accuracy at the token level, and how perplexity offers a more nuanced view of model performance. Emphasize the interconnectedness of these concepts in LLM evaluation.

### 2. Understanding Tokens in NLP (40 minutes)
#### 2.1 What are tokens?
- Definition and examples of tokens:
  Explain that tokens are the basic units of text in NLP. They can be words, parts of words, or even characters, depending on the tokenization strategy. Provide examples of how a sentence might be tokenized differently based on the chosen approach.

- Importance of tokenization in NLP tasks:
  Discuss how tokenization serves as the foundation for many NLP tasks. Explain how it affects model input, influences the model's understanding of text structure, and impacts downstream tasks like sentiment analysis or machine translation.

- Different tokenization strategies (word-level, subword, character-level):
  Elaborate on each strategy:
  - Word-level: Splits text into words, usually at whitespace and punctuation. Simple but can struggle with out-of-vocabulary words.
  - Subword: Breaks words into meaningful subunits, balancing vocabulary size and ability to handle unknown words. Common in modern LLMs.
  - Character-level: Treats each character as a token. Results in a small vocabulary but very long sequences.

#### 2.2 Implementing tokenization in Python
```python
import nltk
from transformers import AutoTokenizer

# Word-level tokenization
text = "The quick brown fox jumps over the lazy dog."
word_tokens = nltk.word_tokenize(text)
print("Word tokens:", word_tokens)

# Subword tokenization (using BERT tokenizer)
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
subword_tokens = tokenizer.tokenize(text)
print("Subword tokens:", subword_tokens)

# Character-level tokenization
char_tokens = list(text)
print("Character tokens:", char_tokens)

# Visualize the differences
import matplotlib.pyplot as plt

fig, ax = plt.subplots(3, 1, figsize=(12, 8))
ax[0].text(0.5, 0.5, ' '.join(word_tokens), ha='center', va='center', wrap=True)
ax[0].set_title('Word-level Tokenization')
ax[1].text(0.5, 0.5, ' '.join(subword_tokens), ha='center', va='center', wrap=True)
ax[1].set_title('Subword Tokenization')
ax[2].text(0.5, 0.5, ' '.join(char_tokens), ha='center', va='center', wrap=True)
ax[2].set_title('Character-level Tokenization')
plt.tight_layout()
plt.show()
```

### 3. Token-level Accuracy (50 minutes)
#### 3.1 Understanding token-level accuracy
- Definition: proportion of correctly predicted tokens
  Explain that token-level accuracy is the ratio of correctly predicted tokens to the total number of tokens in a sequence. Emphasize that this metric treats each token prediction as an independent event.

- Use cases in LLM evaluation:
  Discuss scenarios where token-level accuracy is particularly useful, such as in assessing the model's grasp of vocabulary, its ability to maintain contextual consistency, or in tasks where each token prediction is crucial (e.g., code generation).

- Limitations of token-level accuracy:
  Highlight that while useful, token-level accuracy doesn't capture the overall coherence or semantic correctness of the generated text. Explain how it might overstate performance in cases where small errors lead to drastically different meanings.

#### 3.2 Implementing token-level accuracy in Python
```python
def calculate_token_accuracy(true_tokens, pred_tokens):
    correct = sum(t == p for t, p in zip(true_tokens, pred_tokens))
    total = len(true_tokens)
    return correct / total if total > 0 else 0

# Example usage
true_text = "The quick brown fox jumps over the lazy dog."
pred_text = "The quick brown fox jumps over the lazy cat."

true_tokens = nltk.word_tokenize(true_text)
pred_tokens = nltk.word_tokenize(pred_text)

accuracy = calculate_token_accuracy(true_tokens, pred_tokens)
print(f"Token-level accuracy: {accuracy:.2f}")

# Detailed analysis
for t, p in zip(true_tokens, pred_tokens):
    print(f"True: {t:<10} Pred: {p:<10} Correct: {t == p}")
```

#### 3.3 Visualizing token-level accuracy
```python
import matplotlib.pyplot as plt

def visualize_token_accuracy(true_tokens, pred_tokens):
    accuracies = [1 if t == p else 0 for t, p in zip(true_tokens, pred_tokens)]
    plt.figure(figsize=(12, 4))
    plt.bar(range(len(accuracies)), accuracies, color=['g' if a == 1 else 'r' for a in accuracies])
    plt.xticks(range(len(accuracies)), true_tokens, rotation=45)
    plt.title("Token-level Accuracy")
    plt.xlabel("Tokens")
    plt.ylabel("Accuracy (0 or 1)")
    for i, v in enumerate(accuracies):
        plt.text(i, v, true_tokens[i] if v == 1 else pred_tokens[i], ha='center', va='bottom')
    plt.tight_layout()
    plt.show()

visualize_token_accuracy(true_tokens, pred_tokens)
```

### 4. Perplexity (70 minutes)
#### 4.1 Understanding perplexity
- Definition: measurement of how well a probability model predicts a sample
  Explain that perplexity is a way to quantify how "surprised" a model is by new text. Lower perplexity indicates that the model considers the observed text more probable.

- Interpretation: lower perplexity indicates better prediction
  Discuss how perplexity relates to the model's confidence in its predictions. Provide examples of what low and high perplexity might mean in practical terms.

- Relationship to cross-entropy:
  Explain that perplexity is the exponential of the cross-entropy. This connection helps in understanding perplexity from an information theory perspective.

- Use cases in language modeling and LLM evaluation:
  Describe how perplexity is used to compare language models, evaluate the quality of generated text, and assess a model's understanding of different types of text or domains.

#### 4.2 Calculating perplexity
- Mathematical formula: PP(W) = 2^(-1/N * sum(log2(P(wi|w1,...,wi-1))))
  Break down each component of the formula:
  - W: the sequence of words
  - N: the number of words
  - P(wi|w1,...,wi-1): the conditional probability of word wi given the preceding words

- Explanation of each component in the formula:
  Discuss how this formula captures the model's ability to predict each word given the context. Explain why we use the geometric mean (via log and exp operations) rather than a simple average.

#### 4.3 Implementing perplexity calculation in Python
```python
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

def calculate_perplexity(model, tokenizer, text):
    encodings = tokenizer(text, return_tensors="pt")
    max_length = model.config.max_position_embeddings
    stride = 512
    seq_len = encodings.input_ids.size(1)
    
    nlls = []
    for i in range(0, seq_len, stride):
        begin_loc = max(i + stride - max_length, 0)
        end_loc = min(i + stride, seq_len)
        trg_len = end_loc - i
        input_ids = encodings.input_ids[:, begin_loc:end_loc].to(model.device)
        target_ids = input_ids.clone()
        target_ids[:, :-trg_len] = -100
        
        with torch.no_grad():
            outputs = model(input_ids, labels=target_ids)
            neg_log_likelihood = outputs.loss * trg_len
        
        nlls.append(neg_log_likelihood)
    
    ppl = torch.exp(torch.stack(nlls).sum() / end_loc)
    return ppl.item()

# Example usage
model = AutoModelForCausalLM.from_pretrained("gpt2")
tokenizer = AutoTokenizer.from_pretrained("gpt2")

text = "The quick brown fox jumps over the lazy dog."
perplexity = calculate_perplexity(model, tokenizer, text)
print(f"Perplexity: {perplexity:.2f}")

# Visualizing perplexity across different texts
texts = [
    "The quick brown fox jumps over the lazy dog.",
    "I love natural language processing and machine learning.",
    "Xylophone zebra quantum fluctuations in antimatter condensates."
]

perplexities = [calculate_perplexity(model, tokenizer, t) for t in texts]

plt.figure(figsize=(10, 6))
plt.bar(range(len(perplexities)), perplexities)
plt.xticks(range(len(perplexities)), [f"Text {i+1}" for i in range(len(perplexities))], rotation=45)
plt.title("Perplexity Across Different Texts")
plt.ylabel("Perplexity")
plt.tight_layout()
plt.show()
```

#### 4.4 Interpreting perplexity scores
- Guidelines for interpreting perplexity values:
  Provide a general scale for perplexity values (e.g., what ranges are considered good or poor). Emphasize that interpretation often depends on the specific task and dataset.

- Comparing perplexity across different models and datasets:
  Discuss the challenges in comparing perplexity between different tokenization schemes or across vastly different types of text. Explain why perplexity is most useful for comparing models on the same dataset.

- Limitations of perplexity as an evaluation metric:
  Highlight that while perplexity is a powerful tool, it doesn't capture aspects like factual correctness, coherence over long passages, or appropriateness of generated text. Discuss how it might be complemented by other metrics or human evaluation.

### 5. Applying Metrics to LLM Evaluation (30 minutes)
- Discussion on when to use token-level accuracy vs perplexity:
  Compare and contrast these metrics. Explain scenarios where one might be preferable over the other, and cases where using both provides a more comprehensive evaluation.

- Real-world examples of using these metrics in LLM research and development:
  Present case studies from recent research papers or industry reports where these metrics were crucial in advancing LLM capabilities.

- Limitations and potential pitfalls in using these metrics:
  Discuss how over-reliance on these metrics might lead to models that perform well numerically but fall short in practical applications. Emphasize the importance of a holistic evaluation approach.

### 6. Hands-on Exercise (30 minutes)
Students will work on a practical exercise involving:
1. Loading a dataset of LLM-generated text and ground truth
2. Calculating token-level accuracy and perplexity
3. Visualizing the results
4. Interpreting the metrics in the context of LLM performance

Provide a starter code and dataset, guiding students through each step of the process. Encourage them to experiment with different texts and model outputs to gain intuition about the metrics.

### 7. Discussion and Q&A (20 minutes)
- Open discussion on token-level accuracy and perplexity:
  Facilitate a conversation about the students' experiences with the hands-on exercise. Encourage them to share insights and challenges they encountered.

- Address any questions or clarifications needed:
  Take time to clear up any confusion about the concepts or implementations covered in the lesson.

- Preview the next lesson on Precision, Recall, and F1 Score:
  Briefly introduce these metrics and explain how they build upon the concepts learned in this lesson. Highlight the importance of these metrics in classification tasks, which are common in many LLM applications.

## Additional Resources
- NLTK documentation on tokenization: Provide links to specific sections that cover advanced tokenization techniques.
- Hugging Face Transformers documentation: Link to guides on using pre-trained models for perplexity calculation.
- Research paper: "A Survey of Evaluation Metrics Used for NLG Systems" by Ananya B. Sai et al. Summarize key findings relevant to token-level metrics and perplexity.
- Blog post or video explaining the intuition behind perplexity in simple terms.

## Assessment
1. Multiple-choice questions on the concepts of tokens, token-level accuracy, and perplexity. Include questions that test understanding of edge cases and limitations.
2. Short coding task to implement token-level accuracy from scratch, including handling edge cases like empty sequences or mismatched lengths.
3. Analysis task: Given a set of LLM outputs and references, calculate and interpret token-level accuracy and perplexity. Ask students to write a brief report on their findings, including visualizations and recommendations for model improvement.

## Homework
1. Implement a function to calculate perplexity without using pre-built libraries. Compare the results with the Hugging Face implementation and explain any differences.
2. Research and write a brief report on how token-level accuracy and perplexity are used in a specific LLM application (e.g., language modeling, machine translation). Include real-world examples and discuss any limitations or criticisms of these metrics in that context.
3. Explore and report on one alternative token-level metric not covered in the lesson 




## 8. Practical Applications in LLM Evaluation (30 minutes)

### 8.1 Token-level Accuracy in LLM Tasks
- Discuss how token-level accuracy is used in various LLM tasks:
  1. Language modeling: Evaluating the model's ability to predict the next token in a sequence.
  2. Machine translation: Assessing the accuracy of translated tokens.
  3. Text completion: Measuring the correctness of generated tokens in fill-in-the-blank tasks.

- Example: Evaluating a simple language model
```python
import numpy as np

def evaluate_language_model(model, test_data):
    total_tokens = 0
    correct_predictions = 0
    
    for sentence in test_data:
        tokens = sentence.split()
        for i in range(len(tokens) - 1):
            context = ' '.join(tokens[:i+1])
            predicted_token = model.predict_next_token(context)
            if predicted_token == tokens[i+1]:
                correct_predictions += 1
            total_tokens += 1
    
    accuracy = correct_predictions / total_tokens
    return accuracy

# Placeholder for a simple language model class
class SimpleLM:
    def predict_next_token(self, context):
        # Simplified prediction (random choice for demonstration)
        return np.random.choice(['the', 'a', 'an', 'is', 'are'])

# Example usage
model = SimpleLM()
test_data = [
    "the cat is on the mat",
    "a dog is in the yard",
    "an elephant is very large"
]

accuracy = evaluate_language_model(model, test_data)
print(f"Token-level accuracy: {accuracy:.4f}")
```

### 8.2 Perplexity in LLM Evaluation
- Explain how perplexity is used to evaluate LLMs in different scenarios:
  1. Comparing different language models: Lower perplexity indicates better performance.
  2. Domain adaptation: Measuring how well a model generalizes to new domains.
  3. Fine-tuning assessment: Evaluating the impact of fine-tuning on model performance.

- Example: Comparing perplexity across domains
```python
import math

def calculate_perplexity(model, text):
    tokens = text.split()
    n = len(tokens)
    log_likelihood = 0
    
    for i in range(1, n):
        context = ' '.join(tokens[:i])
        next_token = tokens[i]
        probability = model.predict_probability(context, next_token)
        log_likelihood += math.log2(probability)
    
    perplexity = 2 ** (-log_likelihood / n)
    return perplexity

# Placeholder for a more advanced language model class
class AdvancedLM:
    def predict_probability(self, context, token):
        # Simplified probability prediction (random for demonstration)
        return np.random.uniform(0.1, 0.5)

# Example usage
model = AdvancedLM()
general_text = "The quick brown fox jumps over the lazy dog."
technical_text = "The quaternion represents rotation in three-dimensional space."

general_perplexity = calculate_perplexity(model, general_text)
technical_perplexity = calculate_perplexity(model, technical_text)

print(f"General domain perplexity: {general_perplexity:.2f}")
print(f"Technical domain perplexity: {technical_perplexity:.2f}")
```

## 9. Advanced Topics (20 minutes)

### 9.1 Smoothing Techniques for Perplexity
- Introduce common smoothing methods to handle out-of-vocabulary words:
  1. Add-k smoothing
  2. Backoff models
  3. Interpolation

- Briefly explain how these techniques help in obtaining more reliable perplexity scores.

### 9.2 Token-level Accuracy vs. Sequence-level Accuracy
- Discuss the differences between token-level and sequence-level accuracy.
- Explain scenarios where one might be preferred over the other.

### 9.3 Perplexity in Subword-based Models
- Explain how perplexity calculation changes when dealing with subword tokenization (e.g., BPE, WordPiece).
- Discuss the challenges and considerations in interpreting perplexity for these models.

## 10. Hands-on Exercise (40 minutes)

### Exercise: Evaluating an LLM on a Text Completion Task

In this exercise, students will:
1. Load a pre-trained language model (e.g., GPT-2 small)
2. Prepare a dataset of incomplete sentences
3. Use the model to complete the sentences
4. Calculate token-level accuracy and perplexity for the completions
5. Analyze the results and draw conclusions about the model's performance

```python
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import torch

# Load pre-trained model and tokenizer
model_name = "gpt2"
model = GPT2LMHeadModel.from_pretrained(model_name)
tokenizer = GPT2Tokenizer.from_pretrained(model_name)

def complete_sentence(model, tokenizer, incomplete_sentence, max_length=50):
    input_ids = tokenizer.encode(incomplete_sentence, return_tensors="pt")
    output = model.generate(input_ids, max_length=max_length, num_return_sequences=1, pad_token_id=tokenizer.eos_token_id)
    completed_sentence = tokenizer.decode(output[0], skip_special_tokens=True)
    return completed_sentence

def calculate_accuracy_and_perplexity(model, tokenizer, incomplete_sentence, true_completion):
    with torch.no_grad():
        input_ids = tokenizer.encode(incomplete_sentence, return_tensors="pt")
        true_ids = tokenizer.encode(true_completion, return_tensors="pt")
        
        outputs = model(input_ids, labels=true_ids)
        loss = outputs.loss
        perplexity = torch.exp(loss)
        
        logits = outputs.logits
        predictions = torch.argmax(logits, dim=-1)
        
        correct_predictions = (predictions == true_ids).sum().item()
        total_tokens = true_ids.numel()
        accuracy = correct_predictions / total_tokens
        
    return accuracy, perplexity.item()

# Example usage
incomplete_sentences = [
    "The capital of France is",
    "Machine learning is a subset of",
    "The Eiffel Tower is located in"
]

true_completions = [
    "The capital of France is Paris.",
    "Machine learning is a subset of artificial intelligence.",
    "The Eiffel Tower is located in Paris, France."
]

for incomplete, true in zip(incomplete_sentences, true_completions):
    completed = complete_sentence(model, tokenizer, incomplete)
    accuracy, perplexity = calculate_accuracy_and_perplexity(model, tokenizer, incomplete, true)
    
    print(f"Incomplete: {incomplete}")
    print(f"Completed: {completed}")
    print(f"True: {true}")
    print(f"Token-level accuracy: {accuracy:.4f}")
    print(f"Perplexity: {perplexity:.2f}")
    print()
```

## 11. Discussion and Q&A (20 minutes)
- Encourage students to share their observations from the hands-on exercise.
- Discuss any challenges encountered in implementing or interpreting the metrics.
- Address any remaining questions about token-level accuracy and perplexity.

## 12. Conclusion and Next Steps (10 minutes)
- Recap the key points of the lesson:
  1. The importance of token-level accuracy and perplexity in LLM evaluation
  2. How to calculate and interpret these metrics
  3. Practical applications in various LLM tasks

- Preview the next lesson on Precision, Recall, and F1 Score:
  Explain how these metrics complement token-level accuracy and perplexity, particularly for classification tasks in NLP.

- Encourage students to explore further:
  1. Experiment with different pre-trained models and compare their performance using these metrics.
  2. Investigate how fine-tuning affects token-level accuracy and perplexity.
  3. Research other evaluation metrics used in specific NLP tasks (e.g., BLEU for machine translation).

## Additional Resources
- Research paper: "A Survey of Evaluation Metrics Used for NLG Systems" by Ananya B. Sai, et al.
- Blog post: "Understanding Perplexity in Language Models" (provide a link to a comprehensive explanation)
- Documentation for popular NLP libraries (e.g., HuggingFace Transformers, TensorFlow, PyTorch) on implementing these metrics
- Online courses or tutorials on advanced topics in language model evaluation

Remember to complete the homework assignments from the previous part of the lesson and prepare any questions for the next class.
