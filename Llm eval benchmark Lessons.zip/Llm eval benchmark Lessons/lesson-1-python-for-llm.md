# Lesson 1: Introduction to Python for LLM work

## File Structure
```
course_repository/
│
├── module_1/
│   ├── lesson_1_intro_to_python.md
│   ├── lesson_1_exercises.ipynb
│   └── lesson_1_solutions.ipynb
│
└── resources/
    └── python_setup_guide.md
```

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand basic Python syntax and data structures relevant to LLM work
2. Manipulate strings and text effectively in Python
3. Use popular Python libraries for Natural Language Processing (NLP)
4. Set up a Python development environment for LLM tasks

## 1. Basic Python Syntax and Data Structures

### 1.1 Variables and Data Types
Python is a dynamically-typed language, which means you don't need to declare variable types explicitly.

```python
# Strings
text = "Hello, LLM world!"

# Integers
token_count = 100

# Floats
probability = 0.85

# Booleans
is_trained = True

# Lists
words = ["natural", "language", "processing"]

# Dictionaries
word_freq = {"the": 1463, "and": 927, "of": 834}
```

### 1.2 Control Structures
Python uses indentation to define code blocks.

```python
# If-else statement
if token_count > 512:
    print("Sequence too long")
else:
    print("Sequence length OK")

# For loop
for word in words:
    print(word.upper())

# While loop
i = 0
while i < 5:
    print(f"Iteration {i}")
    i += 1
```

### 1.3 Functions
Functions in Python are defined using the `def` keyword.

```python
def tokenize(text):
    return text.split()

def calculate_perplexity(log_likelihood, num_tokens):
    return 2 ** (-log_likelihood / num_tokens)
```

## 2. Working with Strings and Text

### 2.1 String Operations
```python
# Concatenation
full_name = "Claude" + " " + "AI"

# String formatting
print(f"The model has {token_count} tokens")

# String methods
lowercase_text = text.lower()
word_count = text.count("the")
```

### 2.2 Regular Expressions
The `re` module provides support for regular expressions in Python.

```python
import re

# Finding all occurrences of a pattern
pattern = r'\b\w+ing\b'
matches = re.findall(pattern, text)

# Replacing patterns
cleaned_text = re.sub(r'[^\w\s]', '', text)
```

## 3. Introduction to Popular Python Libraries for NLP

### 3.1 Natural Language Toolkit (NLTK)
NLTK is a leading platform for building Python programs to work with human language data.

```python
import nltk
nltk.download('punkt')
from nltk.tokenize import word_tokenize

text = "NLTK is a powerful library for natural language processing."
tokens = word_tokenize(text)
print(tokens)
```

### 3.2 spaCy
spaCy is a library for advanced natural language processing in Python.

```python
import spacy

nlp = spacy.load("en_core_web_sm")
doc = nlp("spaCy is an advanced NLP library with pre-trained models.")

for token in doc:
    print(token.text, token.pos_, token.dep_)
```

## 4. Setting Up Your Development Environment

### 4.1 Installing Python
Visit the official Python website (https://www.python.org) and download the latest version for your operating system. Follow the installation instructions provided.

### 4.2 Setting Up a Virtual Environment
Virtual environments help manage dependencies for different projects.

```bash
# Create a new virtual environment
python -m venv llm_env

# Activate the virtual environment
# On Windows:
llm_env\Scripts\activate
# On macOS and Linux:
source llm_env/bin/activate
```

### 4.3 Installing Required Libraries
Use pip to install the necessary libraries:

```bash
pip install nltk spacy jupyter
python -m spacy download en_core_web_sm
```

### 4.4 Introduction to Jupyter Notebooks
Jupyter Notebooks provide an interactive environment for Python development.

To start a Jupyter Notebook:

```bash
jupyter notebook
```

This will open a new browser window where you can create and run Jupyter Notebooks.

## Exercises

1. Create a function that takes a string as input and returns the number of words, the number of characters, and the number of sentences.

2. Using NLTK, tokenize a given text and perform part-of-speech tagging.

3. Use spaCy to extract named entities from a news article.

4. Create a Jupyter Notebook that demonstrates the use of string operations, NLTK, and spaCy on a sample text related to LLMs.

## Additional Resources

- [Python Official Documentation](https://docs.python.org/3/)
- [NLTK Book](http://www.nltk.org/book/)
- [spaCy Course](https://course.spacy.io/)
- [Jupyter Notebook Documentation](https://jupyter-notebook.readthedocs.io/en/stable/)

## Next Steps
In the next lesson, we'll dive deeper into the world of Large Language Models, exploring their history, evolution, and common architectures.
