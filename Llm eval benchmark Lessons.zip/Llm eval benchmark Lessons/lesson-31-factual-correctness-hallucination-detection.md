# Lesson 31: Factual Correctness and Hallucination Detection

## Learning Objectives

By the end of this lesson, students will be able to:
1. Understand the concepts of factual correctness and hallucination in the context of Large Language Models (LLMs)
2. Implement techniques for evaluating factual correctness in LLM outputs
3. Develop methods for detecting and mitigating hallucinations in LLM-generated content
4. Apply best practices for improving the reliability and trustworthiness of LLM outputs
5. Critically analyze the challenges and limitations of current approaches to factual correctness and hallucination detection

## 1. Introduction to Factual Correctness and Hallucination in LLMs

Large Language Models have demonstrated remarkable capabilities in generating human-like text across various domains. However, they also pose significant challenges when it comes to ensuring the factual correctness of their outputs and preventing hallucinations, which are instances where the model generates false or nonsensical information that appears plausible.

### 1.1 The Importance of Factual Correctness

Factual correctness is crucial for many applications of LLMs, particularly in fields such as:

- Information retrieval and question-answering systems
- Automated content generation for educational materials
- Decision support systems in healthcare, finance, and legal domains
- News summarization and report generation

Ensuring factual correctness is essential for maintaining user trust, preventing the spread of misinformation, and enabling the safe deployment of LLMs in critical applications.

### 1.2 Understanding Hallucinations in LLMs

Hallucinations occur when an LLM generates information that is not grounded in its training data or the provided context. These can manifest in various ways:

- Fabrication of non-existent entities, events, or relationships
- Misattribution of facts to incorrect sources or time periods
- Generation of plausible but false information
- Combining unrelated pieces of information in nonsensical ways

Hallucinations are particularly challenging because they often produce outputs that seem coherent and believable, making them difficult to detect without external verification.

## 2. Techniques for Evaluating Factual Correctness

Evaluating the factual correctness of LLM outputs involves comparing the generated content against reliable sources of truth. Here are several approaches to assess factual correctness:

### 2.1 Knowledge Base Verification

This method involves checking LLM outputs against a curated knowledge base or database of facts. Here's an example implementation using a simple knowledge base:

```python
import spacy

class KnowledgeBase:
    def __init__(self):
        self.facts = {
            "Paris": {"is_capital_of": "France", "population": 2161000},
            "Mount Everest": {"height": 8848, "location": "Himalayas"},
            # Add more facts...
        }
        self.nlp = spacy.load("en_core_web_sm")

    def verify_statement(self, statement):
        doc = self.nlp(statement)
        for ent in doc.ents:
            if ent.text in self.facts:
                # Check if any of the facts about the entity are mentioned in the statement
                for attribute, value in self.facts[ent.text].items():
                    if str(value).lower() in statement.lower():
                        return True, f"Verified: {ent.text} {attribute} {value}"
        return False, "No verifiable facts found in the statement"

# Usage
kb = KnowledgeBase()
statement1 = "Paris is the capital of France."
statement2 = "Mount Everest is located in the Andes."

print(kb.verify_statement(statement1))
print(kb.verify_statement(statement2))
```

This simple example demonstrates how to verify statements against a knowledge base. In practice, you would use a much larger and more comprehensive knowledge base, possibly integrating with existing databases like Wikidata or domain-specific knowledge graphs.

### 2.2 Information Retrieval-based Verification

This approach involves using information retrieval techniques to find supporting evidence for LLM-generated statements in a large corpus of trusted documents. Here's a basic implementation using TF-IDF and cosine similarity:

```python
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

class IRVerifier:
    def __init__(self, trusted_documents):
        self.documents = trusted_documents
        self.vectorizer = TfidfVectorizer()
        self.document_vectors = self.vectorizer.fit_transform(self.documents)

    def verify_statement(self, statement, threshold=0.3):
        statement_vector = self.vectorizer.transform([statement])
        similarities = cosine_similarity(statement_vector, self.document_vectors)
        max_similarity = np.max(similarities)
        if max_similarity > threshold:
            most_similar_doc = self.documents[np.argmax(similarities)]
            return True, f"Statement supported by document with similarity {max_similarity:.2f}: {most_similar_doc[:100]}..."
        else:
            return False, f"No supporting document found (max similarity: {max_similarity:.2f})"

# Usage
trusted_docs = [
    "Paris is the capital and most populous city of France.",
    "Mount Everest is Earth's highest mountain above sea level, located in the Himalayas.",
    # Add more trusted documents...
]

verifier = IRVerifier(trusted_docs)
statement1 = "Paris is the capital of France."
statement2 = "Mount Everest is located in the Andes."

print(verifier.verify_statement(statement1))
print(verifier.verify_statement(statement2))
```

This example uses TF-IDF and cosine similarity to find supporting evidence for statements. In a real-world scenario, you would use a much larger corpus of trusted documents and more sophisticated information retrieval techniques.

### 2.3 Question-Answering-based Verification

This method involves reformulating the LLM-generated statements as questions and using a separate question-answering system to verify the information. Here's a basic implementation using a pre-trained question-answering model:

```python
from transformers import pipeline

class QAVerifier:
    def __init__(self):
        self.qa_pipeline = pipeline("question-answering", model="distilbert-base-cased-distilled-squad")

    def verify_statement(self, statement, context):
        # Convert statement to a question
        question = self.statement_to_question(statement)
        
        result = self.qa_pipeline(question=question, context=context)
        
        # Check if the answer supports the original statement
        if result['score'] > 0.7 and result['answer'].lower() in statement.lower():
            return True, f"Statement supported by QA system (confidence: {result['score']:.2f})"
        else:
            return False, f"Statement not supported by QA system (confidence: {result['score']:.2f})"

    def statement_to_question(self, statement):
        # Simple rule-based conversion (in practice, use more sophisticated NLP techniques)
        return statement.replace("is", "What is") + "?"

# Usage
verifier = QAVerifier()
context = """
Paris is the capital and most populous city of France. Mount Everest, Earth's highest mountain above sea level, 
is located in the Himalayas on the border between Nepal and Tibet.
"""

statement1 = "Paris is the capital of France."
statement2 = "Mount Everest is located in the Andes."

print(verifier.verify_statement(statement1, context))
print(verifier.verify_statement(statement2, context))
```

This example uses a pre-trained question-answering model to verify statements. In practice, you would use a more robust QA system and carefully curated contexts for verification.

## 3. Hallucination Detection Methods

Detecting hallucinations in LLM outputs is challenging because the generated content often appears plausible. Here are some approaches to identify potential hallucinations:

### 3.1 Consistency Checking

This method involves generating multiple outputs for the same input and checking for consistency across the generated content. Inconsistencies may indicate potential hallucinations. Here's a simple implementation:

```python
from transformers import pipeline
import numpy as np

class ConsistencyChecker:
    def __init__(self, model_name="gpt2"):
        self.generator = pipeline("text-generation", model=model_name)

    def generate_multiple(self, prompt, num_generations=5, max_length=50):
        return [self.generator(prompt, max_length=max_length)[0]['generated_text'] for _ in range(num_generations)]

    def check_consistency(self, prompt, num_generations=5, max_length=50):
        generations = self.generate_multiple(prompt, num_generations, max_length)
        
        # Simple consistency check based on word overlap
        word_sets = [set(gen.split()) for gen in generations]
        overlap_ratios = []
        
        for i in range(len(word_sets)):
            for j in range(i+1, len(word_sets)):
                overlap = len(word_sets[i] & word_sets[j]) / len(word_sets[i] | word_sets[j])
                overlap_ratios.append(overlap)
        
        avg_overlap = np.mean(overlap_ratios)
        
        if avg_overlap > 0.7:
            return True, f"Consistent generations (average overlap: {avg_overlap:.2f})"
        else:
            return False, f"Potential hallucinations detected (average overlap: {avg_overlap:.2f})"

# Usage
checker = ConsistencyChecker()
prompt1 = "The capital of France is"
prompt2 = "The largest planet in our solar system is"

print(checker.check_consistency(prompt1))
print(checker.check_consistency(prompt2))
```

This example generates multiple outputs for the same prompt and checks for consistency based on word overlap. In practice, you would use more sophisticated methods to compare the semantic content of the generated texts.

### 3.2 Uncertainty Estimation

This approach involves estimating the model's uncertainty in its generations. Higher uncertainty may indicate potential hallucinations. Here's an example using the entropy of the model's output distribution:

```python
import torch
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import numpy as np

class UncertaintyEstimator:
    def __init__(self, model_name="gpt2"):
        self.model = GPT2LMHeadModel.from_pretrained(model_name)
        self.tokenizer = GPT2Tokenizer.from_pretrained(model_name)
        self.model.eval()

    def estimate_uncertainty(self, text, window_size=5):
        inputs = self.tokenizer.encode(text, return_tensors="pt")
        with torch.no_grad():
            outputs = self.model(inputs)
            logits = outputs.logits
        
        entropies = []
        for i in range(logits.shape[1] - window_size):
            window_logits = logits[0, i:i+window_size, :]
            probs = torch.softmax(window_logits, dim=-1)
            entropy = -torch.sum(probs * torch.log(probs), dim=-1).mean().item()
            entropies.append(entropy)
        
        avg_entropy = np.mean(entropies)
        if avg_entropy > 2.0:  # Threshold can be adjusted based on empirical observations
            return True, f"High uncertainty detected (average entropy: {avg_entropy:.2f})"
        else:
            return False, f"Low uncertainty (average entropy: {avg_entropy:.2f})"

# Usage
estimator = UncertaintyEstimator()
text1 = "The capital of France is Paris."
text2 = "The capital of Narnia is Cair Paravel."

print(estimator.estimate_uncertainty(text1))
print(estimator.estimate_uncertainty(text2))
```

This example estimates uncertainty using the entropy of the model's output distribution. Higher entropy indicates higher uncertainty, which may suggest potential hallucinations.

### 3.3 Fact-checking with External Knowledge Sources

This method involves cross-referencing LLM outputs with external knowledge sources to identify potential hallucinations. Here's a simple example using Wikipedia as an external knowledge source:

```python
import wikipedia
import spacy

class ExternalFactChecker:
    def __init__(self):
        self.nlp = spacy.load("en_core_web_sm")

    def check_facts(self, text):
        doc = self.nlp(text)
        potential_hallucinations = []

        for ent in doc.ents:
            try:
                # Try to find a Wikipedia page for the entity
                page = wikipedia.page(ent.text)
                # Check if the entity's context in the text matches the Wikipedia summary
                if ent.text.lower() not in page.summary.lower():
                    potential_hallucinations.append(ent.text)
            except wikipedia.exceptions.DisambiguationError:
                # Multiple pages found, consider it verified
                pass
            except wikipedia.exceptions.PageError:
                # No Wikipedia page found, potential hallucination
                potential_hallucinations.append(ent.text)

        if potential_hallucinations:
            return False, f"Potential hallucinations detected: {', '.join(potential_hallucinations)}"
        else:
            return True, "No obvious hallucinations detected"

# Usage
checker = ExternalFactChecker()
text1 = "Paris is the capital of France and is known for the Eiffel Tower."
text2 = "Atlantis is the capital of the underwater kingdom of Merpeople."

print(checker.check_facts(text1))
print(checker.check_facts(text2))
```

This example uses Wikipedia as an external knowledge source to verify entities mentioned in the text. In practice, you would use multiple reliable knowledge sources and more sophisticated entity linking and fact verification techniques.

## 4. Best Practices for Improving Reliability and Trustworthiness

To enhance the factual correctness and reduce hallucinations in LLM outputs, consider the following best practices:

1. Use retrieval-augmented generation: Incorporate relevant information from trusted knowledge bases or documents into the LLM's context during generation.

2. Implement fact-checking pipelines: Develop automated fact-checking systems that verify LLM outputs against trusted sources before presenting them to users.

3. Fine-tune models on high-quality, factual data: Train or fine-tune LLMs on carefully curated datasets that prioritize factual accuracy.

4. Employ ensemble methods: Combine outputs from multiple models or generation attempts to increase reliability.

5. Implement uncertainty-aware decoding: Use decoding strategies that take into account the model's uncertainty, such as nucleus sampling with a conservative threshold.

6. Provide source attribution: When possible, include references or sources for generated information to enable verification.

7. Use human-in-the-loop systems: For critical applications, incorporate human expert review into the generation and verification process.

8. Regularly update model knowledge: Fine-tune or retrain models periodically to incorporate new information and correct outdated facts.

9. Implement content warnings: For topics or domains where the model's knowledge might be uncertain or outdated, provide appropriate disclaimers to users.

10. Encourage user feedback: Develop mechanisms for users to report potential inaccuracies or hallucinations, and use this feedback to improve the system.

## 5. Challenges and Limitations

While the techniques discussed in this lesson can significantly improve the factual correctness and reduce hallucinations in LLM outputs, several challenges and limitations remain:

1. Scalability: Verifying every generated statement against external knowledge sources can be computationally expensive and time-consuming.

2. Knowledge cutoff: LLMs have a knowledge cutoff date, after which they may not have accurate information about recent events or discoveries.

3. Domain specificity: General-purpose LLMs may struggle with factual accuracy in specialized domains that require expert knowledge.

4. Evolving facts: Some information changes over time, making it challenging