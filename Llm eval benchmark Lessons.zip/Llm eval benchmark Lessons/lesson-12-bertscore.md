# Lesson 12: BERTScore - Neural Network-Based Metric

## Overview
This lesson focuses on BERTScore, a neural network-based evaluation metric for text generation tasks. BERTScore leverages pre-trained language models to compute similarity scores between candidate and reference texts. We'll explore its theoretical foundations, implementation in Python, and applications in evaluating Large Language Model (LLM) outputs.

## Learning Objectives
By the end of this lesson, students will be able to:
1. Understand the concept and motivation behind BERTScore
2. Explain how BERTScore utilizes contextual embeddings for text similarity
3. Implement BERTScore using pre-trained BERT models
4. Analyze the strengths and limitations of BERTScore compared to traditional metrics
5. Apply BERTScore to evaluate LLM outputs in various text generation tasks

## File Structure
```
lesson_11/
│
├── notebooks/
│   └── bertscore_implementation.ipynb
│
├── scripts/
│   └── bertscore_metric.py
│
├── data/
│   ├── sample_references.txt
│   └── sample_candidates.txt
│
└── requirements.txt
```

## Lesson Content

### 1. Introduction to BERTScore (30 minutes)

#### 1.1 Background and Motivation
BERTScore was introduced to address limitations of traditional n-gram based metrics like BLEU and ROUGE. These traditional metrics often fail to capture semantic similarities beyond exact word matches. For instance, they might unfairly penalize a high-quality paraphrase that uses different words to convey the same meaning.

BERTScore aims to leverage the power of contextual embeddings to provide a more nuanced evaluation of text similarity. By using pre-trained language models, BERTScore can capture semantic and contextual information that goes beyond surface-level word matching.

#### 1.2 Core Concepts of BERTScore
BERTScore is based on several key concepts:

1. Contextual Embeddings: 
   BERTScore uses BERT (Bidirectional Encoder Representations from Transformers) or similar models to generate contextual embeddings for each token in the candidate and reference texts. These embeddings capture not just the meaning of individual words, but how that meaning changes based on the surrounding context.

2. Token-level Matching: 
   Instead of looking for exact n-gram matches, BERTScore computes the similarity between each token in the candidate text and each token in the reference text. This allows it to identify semantic matches even when different words are used.

3. Soft Alignment: 
   BERTScore uses a soft alignment approach, where each token can partially match with multiple tokens in the other text. This is particularly useful for handling paraphrases and synonyms.

4. Importance Weighting: 
   Not all words contribute equally to the meaning of a sentence. BERTScore incorporates an optional importance weighting scheme based on inverse document frequency (IDF), giving more weight to content words and less to common function words.

#### 1.3 BERTScore Computation
The BERTScore computation involves several steps:

1. Tokenization and Embedding: 
   Both the candidate and reference texts are tokenized and passed through a pre-trained BERT model to obtain contextual embeddings for each token.

2. Similarity Computation: 
   The cosine similarity is computed between each candidate token embedding and each reference token embedding, resulting in a similarity matrix.

3. Greedy Matching: 
   For each token in the candidate text, the maximum similarity score with any token in the reference text is selected. The same is done in the reverse direction.

4. Aggregation: 
   The selected similarity scores are aggregated (typically by taking the mean) to compute precision, recall, and F1 scores.

Here's a high-level overview of the computation:

```python
def compute_bertscore(candidate, reference, model, tokenizer):
    # Tokenize and get embeddings
    cand_embeddings = get_bert_embeddings(candidate, model, tokenizer)
    ref_embeddings = get_bert_embeddings(reference, model, tokenizer)
    
    # Compute similarity matrix
    similarity_matrix = cosine_similarity(cand_embeddings, ref_embeddings)
    
    # Compute precision and recall
    precision = similarity_matrix.max(axis=1).mean()
    recall = similarity_matrix.max(axis=0).mean()
    
    # Compute F1
    f1 = 2 * (precision * recall) / (precision + recall)
    
    return precision, recall, f1
```

### 2. Implementing BERTScore in Python (60 minutes)

#### 2.1 Setting Up the Environment
We'll start by setting up our Python environment with the necessary libraries. We'll primarily use the transformers library from Hugging Face, which provides easy access to pre-trained BERT models.

```python
!pip install transformers torch numpy scipy

import torch
from transformers import AutoTokenizer, AutoModel
import numpy as np
from scipy.spatial.distance import cosine
```

#### 2.2 Loading Pre-trained BERT Model
We'll load a pre-trained BERT model and its associated tokenizer. For this implementation, we'll use the 'bert-base-uncased' model, but you could experiment with other BERT variants or even other language models like RoBERTa or ALBERT.

```python
def load_bert_model():
    tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')
    model = AutoModel.from_pretrained('bert-base-uncased')
    return model, tokenizer

model, tokenizer = load_bert_model()
```

#### 2.3 Computing BERT Embeddings
Next, we'll implement a function to compute BERT embeddings for a given text. This function will tokenize the input, pass it through the BERT model, and return the contextual embeddings for each token.

```python
def get_bert_embeddings(text, model, tokenizer):
    inputs = tokenizer(text, return_tensors='pt', padding=True, truncation=True)
    with torch.no_grad():
        outputs = model(**inputs)
    
    # Use the last hidden state as token embeddings
    embeddings = outputs.last_hidden_state.squeeze(0)
    
    return embeddings.numpy()
```

This function handles the following steps:
1. Tokenization: Convert the input text into tokens that BERT understands.
2. Model Forward Pass: Pass the tokenized input through the BERT model.
3. Embedding Extraction: Extract the contextual embeddings from the model's output.

#### 2.4 Implementing BERTScore Computation
Now we'll implement the core BERTScore computation. This involves computing the cosine similarity between token embeddings and performing greedy matching to calculate precision, recall, and F1 score.

```python
def compute_bertscore(candidate, reference, model, tokenizer):
    # Get embeddings
    cand_embeddings = get_bert_embeddings(candidate, model, tokenizer)
    ref_embeddings = get_bert_embeddings(reference, model, tokenizer)
    
    # Compute cosine similarity
    similarity_matrix = np.inner(cand_embeddings, ref_embeddings)
    
    # Greedy matching
    precision = similarity_matrix.max(axis=1).mean()
    recall = similarity_matrix.max(axis=0).mean()
    
    # Compute F1
    f1 = 2 * (precision * recall) / (precision + recall)
    
    return precision, recall, f1
```

This function performs the following steps:
1. Embedding Computation: Get BERT embeddings for both candidate and reference texts.
2. Similarity Matrix: Compute the cosine similarity between all pairs of candidate and reference tokens.
3. Greedy Matching: For each token, find its best match in the other text.
4. Score Aggregation: Compute precision, recall, and F1 score based on the greedy matches.

#### 2.5 Handling Edge Cases
In real-world applications, we need to handle various edge cases. Some important considerations include:

1. Empty Texts: 
   We need to decide how to score cases where either the candidate or reference is empty. Typically, an empty candidate with a non-empty reference would receive a score of 0, while the case of an empty reference might be considered invalid.

2. Very Long Texts: 
   BERT models typically have a maximum sequence length (often 512 tokens). For longer texts, we might need to implement a sliding window approach or truncation strategy.

3. Multilingual Texts: 
   If we expect to evaluate texts in multiple languages, we should consider using a multilingual BERT model.

Here's an example of how we might handle some of these cases:

```python
def safe_bertscore(candidate, reference, model, tokenizer, max_length=512):
    if not candidate or not reference:
        return 0, 0, 0
    
    # Truncate long texts
    candidate = ' '.join(candidate.split()[:max_length])
    reference = ' '.join(reference.split()[:max_length])
    
    return compute_bertscore(candidate, reference, model, tokenizer)
```

### 3. Analyzing BERTScore (30 minutes)

#### 3.1 Strengths of BERTScore
BERTScore offers several advantages over traditional metrics:

1. Semantic Understanding: 
   By leveraging contextual embeddings, BERTScore can capture semantic similarities even when different words are used. This makes it particularly useful for evaluating paraphrases or abstractive summaries.

2. Contextual Awareness: 
   BERTScore considers the context in which words appear, allowing it to handle polysemy (words with multiple meanings) more effectively than n-gram based metrics.

3. Soft Matching: 
   The use of cosine similarity allows for partial matches between words, providing a more nuanced evaluation than binary match/no-match approaches.

4. Language Agnostic: 
   When used with multilingual BERT models, BERTScore can be applied to texts in multiple languages without requiring language-specific adaptations.

#### 3.2 Limitations of BERTScore
Despite its advantages, BERTScore also has some limitations:

1. Computational Cost: 
   Computing BERTScore is more computationally intensive than traditional n-gram based metrics, which can be a concern for large-scale evaluations.

2. Model Dependence: 
   The performance of BERTScore is dependent on the pre-trained language model used. Different models might yield different scores for the same texts.

3. Lack of Interpretability: 
   Unlike n-gram based metrics, where it's clear which specific n-grams contributed to the score, BERTScore's neural network approach makes it less interpretable.

4. Potential Biases: 
   BERTScore inherits any biases present in the pre-trained language model it uses, which could affect its scoring in subtle ways.

#### 3.3 Comparing BERTScore to Other Metrics
We'll discuss how BERTScore compares to other metrics we've covered in this course:

1. vs. BLEU/ROUGE: 
   BERTScore generally shows higher correlation with human judgments, especially for tasks involving paraphrasing or abstraction. However, BLEU and ROUGE remain useful for their simplicity and established benchmarks.

2. vs. METEOR: 
   Both BERTScore and METEOR aim to capture semantic similarity, but BERTScore's use of contextual embeddings often provides a more nuanced understanding of meaning.

3. vs. CIDEr: 
   While both use weighting schemes to emphasize important words, BERTScore's use of contextual embeddings allows it to capture more complex semantic relationships.

### 4. Applying BERTScore to LLM Evaluation (45 minutes)

#### 4.1 Use Cases for BERTScore in LLM Evaluation
BERTScore can be particularly useful in several LLM evaluation scenarios:

1. Abstractive Summarization: 
   BERTScore's ability to capture semantic similarity makes it well-suited for evaluating summaries that paraphrase the original text.

2. Paraphrase Generation: 
   When evaluating paraphrases, BERTScore can identify semantic equivalence even when different words are used.

3. Open-ended Generation: 
   For tasks like story continuation or dialogue generation, BERTScore can assess semantic coherence with given prompts or contexts.

4. Cross-lingual Generation: 
   When used with multilingual models, BERTScore can evaluate translations or cross-lingual summarization without requiring exact word matches.

#### 4.2 Implementing BERTScore for LLM Output Evaluation
We'll implement a function to evaluate a set of LLM outputs against reference texts using BERTScore:

```python
def evaluate_llm_outputs(candidates, references, model, tokenizer):
    scores = []
    for cand, ref in zip(candidates, references):
        precision, recall, f1 = safe_bertscore(cand, ref, model, tokenizer)
        scores.append({
            'precision': precision,
            'recall': recall,
            'f1': f1
        })
    return scores

# Example usage
llm_outputs = ["The cat sat on the mat", "A feline rested on the floor covering"]
reference_texts = ["A cat was sitting on a mat", "The feline was lounging on a rug"]

scores = evaluate_llm_outputs(llm_outputs, reference_texts, model, tokenizer)
```

#### 4.3 Interpreting BERTScore Results
When interpreting BERTScore results for LLM evaluation, consider the following:

1. Score Range: 
   BERTScore values typically range from 0 to 1, with higher scores indicating greater similarity. However, the exact thresholds for "good" scores can vary depending on the task and domain.

2. Precision vs. Recall: 
   In the context of LLM evaluation, precision often relates to the accuracy of the generated content, while recall relates to coverage of the reference content. The F1 score provides a balanced measure of both.

3. Comparative Analysis: 
   Rather than focusing on absolute scores, it's often more informative to compare BERTScores across different model outputs or against a baseline.

4. Task-Specific Considerations: 
   The interpretation of BERTScore can vary depending on the task. For summarization, high recall might be prioritized, while for paraphrasing, a balance of precision and recall is typically desired.

### 5. Practical Exercise and Discussion (30 minutes)

To conclude the lesson, students will apply BERTScore to evaluate outputs from a pre-trained LLM on a text generation task, such as abstractive summarization or paraphrasing. This exercise will involve:

1. Generating outputs using a pre-trained LLM
2. Evaluating the outputs using our BERTScore implementation
3. Comparing BERTScore results with other metrics like BLEU or ROUGE
4. Analyzing the results and discussing the insights provided by BERTScore

This hands-on experience will help students understand the practical applications and interpretations of BERTScore in real-world LLM evaluation scenarios.

## Additional Resources
- Original BERTScore paper: "BERTScore: Evaluating Text Generation with BERT" by Zhang et al.
- Hugging Face Transformers documentation for working with BERT models
- Research papers comparing BERTScore with other metrics in various NLP tasks
- GitHub repository of the official BERTScore implementation

By the end of this comprehensive lesson, students will have gained both theoretical understanding and practical skills in implementing and applying BERTScore, preparing them for advanced LLM evaluation tasks using neural network-based metrics.

