# LanceDB: A Practical User Guide

## Table of Contents
1. [Getting Started](#getting-started)
2. [Basic Operations](#basic-operations)
3. [Working with Different Data Types](#working-with-different-data-types)
4. [Practical Search Examples](#practical-search-examples)
5. [Common Use Cases](#common-use-cases)
6. [Troubleshooting](#troubleshooting)
7. [Performance Tips](#performance-tips)

## Getting Started

### Installation
```bash
# Basic installation
pip install lancedb

# With all optional dependencies
pip install lancedb[all]

# For specific features
pip install lancedb[server]  # For server functionality
pip install lancedb[aws]     # For AWS S3 support
```

### Initial Setup
```python
import lancedb

# Local database
db = lancedb.connect("my_database")

# Remote database (if using server)
db = lancedb.connect("http://localhost:8000")

# S3 database
db = lancedb.connect("s3://my-bucket/my-database")
```

### Environment Setup
```python
# Required imports for common tasks
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer
import lancedb
```

## Basic Operations

### Creating Your First Table
```python
# Simple example with small vectors
vectors = np.random.rand(100, 128)  # 100 vectors of dimension 128
metadata = [{"id": i, "label": f"item_{i}"} for i in range(100)]

# Create table
table = db.create_table(
    "my_first_table",
    data={
        "vector": vectors,
        "id": [m["id"] for m in metadata],
        "label": [m["label"] for m in metadata]
    }
)

# Alternative: Create from pandas DataFrame
df = pd.DataFrame({
    "vector": list(vectors),
    "id": range(100),
    "label": [f"item_{i}" for i in range(100)]
})
table = db.create_table("my_table", data=df)
```

### Common Operations
```python
# List all tables
print(db.table_names())

# Open existing table
table = db.open_table("my_table")

# Add new data
new_vectors = np.random.rand(10, 128)
new_metadata = [{"id": i+100, "label": f"item_{i+100}"} for i in range(10)]
table.add(data={
    "vector": new_vectors,
    "id": [m["id"] for m in new_metadata],
    "label": [m["label"] for m in new_metadata]
})

# Simple search
query_vector = np.random.rand(128)
results = table.search(query_vector).limit(5).to_pandas()
```

## Working with Different Data Types

### Text Data
```python
# Initialize text embedding model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Create text embeddings
texts = [
    "The quick brown fox",
    "Jumps over the lazy dog",
    "A lazy fox sleeps"
]
text_vectors = model.encode(texts)

# Create table with text and embeddings
table = db.create_table(
    "text_search",
    data={
        "vector": text_vectors,
        "text": texts
    }
)

# Search similar texts
query = "A fox is running"
query_vector = model.encode([query])[0]
results = table.search(query_vector).limit(2).to_pandas()
```

### Image Data
```python
from PIL import Image
import torch
from torchvision import transforms
from torchvision.models import resnet50, ResNet50_Weights

def process_images(image_paths):
    # Load pretrained model
    model = resnet50(weights=ResNet50_Weights.IMAGENET1K_V2)
    model.eval()
    
    # Preprocessing
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )
    ])
    
    vectors = []
    for path in image_paths:
        # Load and preprocess image
        img = Image.open(path)
        img_tensor = preprocess(img)
        img_tensor = img_tensor.unsqueeze(0)
        
        # Generate embedding
        with torch.no_grad():
            vector = model(img_tensor).squeeze().numpy()
        vectors.append(vector)
    
    return np.array(vectors)

# Create image search table
image_paths = ["image1.jpg", "image2.jpg", "image3.jpg"]
image_vectors = process_images(image_paths)

table = db.create_table(
    "image_search",
    data={
        "vector": image_vectors,
        "path": image_paths
    }
)
```

## Practical Search Examples

### Basic Vector Search
```python
# Simple nearest neighbor search
results = table.search(query_vector).limit(5).to_pandas()

# With distance scores
results = table.search(query_vector)\
              .select(["*", "distance"])\
              .limit(5)\
              .to_pandas()
```

### Filtered Search
```python
# Search with metadata filter
results = table.search(query_vector)\
              .where("category = 'electronics'")\
              .limit(5)\
              .to_pandas()

# Multiple filters
results = table.search(query_vector)\
              .where("category = 'electronics' AND price < 100")\
              .limit(5)\
              .to_pandas()
```

### Hybrid Search
```python
# Combine vector similarity with text search
results = table.search(query_vector)\
              .where("description LIKE '%wireless%'")\
              .limit(5)\
              .to_pandas()

# With date ranges
results = table.search(query_vector)\
              .where("date BETWEEN '2024-01-01' AND '2024-12-31'")\
              .limit(5)\
              .to_pandas()
```

## Common Use Cases

### Semantic Search System
```python
class SemanticSearch:
    def __init__(self, db_path: str):
        self.db = lancedb.connect(db_path)
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        
    def add_documents(self, documents: list):
        # Create embeddings
        vectors = self.model.encode([doc["content"] for doc in documents])
        
        # Create or update table
        table = self.db.create_table(
            "documents",
            data={
                "vector": vectors,
                "content": [doc["content"] for doc in documents],
                "title": [doc.get("title", "") for doc in documents],
                "category": [doc.get("category", "") for doc in documents]
            },
            mode="overwrite"  # or "append" to add to existing
        )
        
    def search(self, query: str, limit: int = 5, category: str = None):
        table = self.db.open_table("documents")
        query_vector = self.model.encode(query)
        
        # Build search query
        search_query = table.search(query_vector)
        
        if category:
            search_query = search_query.where(f"category = '{category}'")
            
        return search_query.limit(limit).to_pandas()
```

### Simple Recommendation System
```python
class SimpleRecommender:
    def __init__(self, db_path: str):
        self.db = lancedb.connect(db_path)
        
    def add_items(self, items: list, item_vectors: np.ndarray):
        table = self.db.create_table(
            "items",
            data={
                "vector": item_vectors,
                "item_id": [item["id"] for item in items],
                "name": [item["name"] for item in items],
                "category": [item["category"] for item in items]
            },
            mode="overwrite"
        )
        
    def get_recommendations(self, 
                          user_vector: np.ndarray, 
                          limit: int = 5,
                          exclude_categories: list = None):
        table = self.db.open_table("items")
        
        # Build query
        query = table.search(user_vector)
        
        if exclude_categories:
            exclusion = " AND ".join(
                [f"category != '{cat}'" for cat in exclude_categories]
            )
            query = query.where(exclusion)
            
        return query.limit(limit).to_pandas()
```

## Troubleshooting

### Common Issues and Solutions

1. **Table Creation Errors**
```python
# Problem: Inconsistent vector dimensions
# Solution: Ensure all vectors have same dimension
vectors = np.random.rand(100, 128)
assert all(len(v) == 128 for v in vectors), "Inconsistent dimensions"

# Problem: Missing values
# Solution: Fill or remove null values
df = df.dropna()  # or df.fillna(value)
```

2. **Search Performance Issues**
```python
# Problem: Slow search
# Solution 1: Create index
table.create_index()

# Solution 2: Batch processing
batch_size = 1000
for i in range(0, len(vectors), batch_size):
    batch = vectors[i:i+batch_size]
    table.add(data={"vector": batch})
```

3. **Memory Issues**
```python
# Problem: Out of memory
# Solution: Stream data in chunks
def process_in_chunks(data, chunk_size=1000):
    for i in range(0, len(data), chunk_size):
        chunk = data[i:i+chunk_size]
        yield chunk

# Usage
for chunk in process_in_chunks(large_dataset):
    table.add(data=chunk)
```

## Performance Tips

### Optimization Strategies

1. **Batch Operations**
```python
# Better: Batch insertions
table.add(data={
    "vector": vectors,
    "metadata": metadata
})

# Worse: Individual insertions
for vec, meta in zip(vectors, metadata):
    table.add(data={
        "vector": vec,
        "metadata": meta
    })
```

2. **Index Configuration**
```python
# Create optimized index
table.create_index(
    num_partitions=256,        # Adjust based on data size
    num_sub_vectors=96,        # Trade-off between speed and accuracy
    replace=True              # Replace existing index
)
```

3. **Query Optimization**
```python
# Better: Combined filter
results = table.search(query_vector)\
              .where("category = 'electronics' AND price < 100")\
              .limit(5)

# Worse: Multiple separate filters
results = table.search(query_vector)\
              .where("category = 'electronics'")\
              .where("price < 100")\
              .limit(5)
```

4. **Memory Management**
```python
# Better: Use iterators for large datasets
def data_generator(data_path):
    with open(data_path) as f:
        for line in f:
            yield process_line(line)

# Process large datasets
for batch in data_generator("large_file.txt"):
    table.add(data=batch)
```

These practical usage details should help users effectively work with LanceDB in real-world scenarios. The examples cover common use cases and provide solutions to typical challenges users might face.

Would you like me to:
1. Provide more specific examples for any use case?
2. Add more troubleshooting scenarios?
3. Explain any particular optimization strategy in more detail?

