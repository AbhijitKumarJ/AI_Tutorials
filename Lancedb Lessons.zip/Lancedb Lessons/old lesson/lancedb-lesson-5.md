# Lesson 5: Developer Experience & Best Practices with LanceDB

## Table of Contents
1. [Project Setup and Organization](#project-setup-and-organization)
2. [Python API Best Practices](#python-api-best-practices)
3. [Pandas Integration Patterns](#pandas-integration-patterns)
4. [Performance Optimization](#performance-optimization)
5. [Testing and Maintenance](#testing-and-maintenance)
6. [Error Handling and Logging](#error-handling-and-logging)

## Project Setup and Organization

### Recommended Project Structure
```
lancedb-project/
├── src/
│   ├── config/
│   │   ├── __init__.py
│   │   ├── settings.py           # Configuration settings
│   │   └── db_config.py         # Database configuration
│   ├── models/
│   │   ├── __init__.py
│   │   ├── base.py              # Base model definitions
│   │   └── schemas.py           # Table schemas
│   ├── operations/
│   │   ├── __init__.py
│   │   ├── crud.py              # CRUD operations
│   │   ├── search.py            # Search operations
│   │   └── maintenance.py       # Maintenance operations
│   └── utils/
│       ├── __init__.py
│       ├── vector_utils.py      # Vector manipulation utilities
│       └── pandas_utils.py      # Pandas helper functions
├── tests/
│   ├── __init__.py
│   ├── conftest.py              # Test configurations
│   ├── test_crud.py
│   └── test_search.py
├── notebooks/
│   └── examples.ipynb           # Usage examples
├── requirements.txt
├── setup.py
└── README.md
```

### Configuration Management
```python
# config/settings.py
from dataclasses import dataclass
from typing import Optional

@dataclass
class LanceDBConfig:
    db_path: str
    index_metric: str = "cosine"
    num_partitions: int = 256
    num_sub_vectors: Optional[int] = None
    cache_size_mb: int = 1024

    @property
    def index_params(self):
        return {
            "metric": self.index_metric,
            "num_partitions": self.num_partitions,
            "num_sub_vectors": self.num_sub_vectors
        }

# config/db_config.py
import lancedb
from .settings import LanceDBConfig

class DatabaseManager:
    def __init__(self, config: LanceDBConfig):
        self.config = config
        self._db = None

    @property
    def db(self):
        if self._db is None:
            self._db = lancedb.connect(
                self.config.db_path,
                cache_size_mb=self.config.cache_size_mb
            )
        return self._db

    def get_or_create_table(self, table_name: str, schema: dict):
        if table_name in self.db.table_names():
            return self.db.open_table(table_name)
        return self.db.create_table(table_name, schema=schema)
```

## Python API Best Practices

### Table Management Class
```python
# models/base.py
from typing import Dict, List, Optional, Union
import numpy as np
import pandas as pd

class LanceDBTable:
    def __init__(self, table, config: LanceDBConfig):
        self.table = table
        self.config = config
        self._ensure_index()

    def _ensure_index(self):
        """Ensure vector index exists"""
        if not self.table.has_index():
            self.table.create_index(**self.config.index_params)

    def upsert(self, 
               vectors: np.ndarray, 
               metadata: List[Dict],
               batch_size: int = 1000):
        """Batch upsert with progress tracking"""
        total_batches = len(vectors) // batch_size + 1
        
        for i in range(0, len(vectors), batch_size):
            batch_end = min(i + batch_size, len(vectors))
            batch_data = {
                "vector": vectors[i:batch_end],
                **{k: [d[k] for d in metadata[i:batch_end]] 
                   for k in metadata[0].keys()}
            }
            self.table.add(batch_data)
            print(f"Processed batch {i//batch_size + 1}/{total_batches}")

    def search(self,
              query_vector: np.ndarray,
              filters: Optional[str] = None,
              limit: int = 10) -> pd.DataFrame:
        """Perform vector search with optional filters"""
        search_query = self.table.search(query_vector)
        
        if filters:
            search_query = search_query.where(filters)
            
        return search_query.limit(limit).to_pandas()
```

## Pandas Integration Patterns

### Efficient Data Loading
```python
# utils/pandas_utils.py
import pandas as pd
import numpy as np
from typing import List, Tuple

class DataFrameHandler:
    @staticmethod
    def prepare_for_lancedb(
        df: pd.DataFrame,
        vector_col: str,
        metadata_cols: List[str]
    ) -> Tuple[np.ndarray, List[dict]]:
        """
        Convert DataFrame to LanceDB-compatible format
        """
        vectors = np.stack(df[vector_col].values)
        metadata = df[metadata_cols].to_dict('records')
        return vectors, metadata

    @staticmethod
    def chunk_dataframe(
        df: pd.DataFrame,
        chunk_size: int
    ) -> List[pd.DataFrame]:
        """
        Split DataFrame into manageable chunks
        """
        return np.array_split(df, len(df) // chunk_size + 1)

    @staticmethod
    def optimize_dtypes(df: pd.DataFrame) -> pd.DataFrame:
        """
        Optimize DataFrame memory usage
        """
        for col in df.columns:
            if df[col].dtype == 'object':
                if pd.api.types.is_datetime64_any_dtype(df[col]):
                    df[col] = pd.to_datetime(df[col])
                elif pd.api.types.is_numeric_dtype(df[col]):
                    df[col] = pd.to_numeric(df[col], downcast='integer')
        return df
```

## Performance Optimization

### Performance Monitoring Class
```python
# utils/performance_utils.py
import time
from functools import wraps
from typing import Optional, Callable
import logging

class PerformanceMonitor:
    def __init__(self):
        self.metrics = {}

    def measure_time(self, operation_name: str) -> Callable:
        """Decorator to measure operation time"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                start_time = time.time()
                result = func(*args, **kwargs)
                execution_time = time.time() - start_time
                
                if operation_name not in self.metrics:
                    self.metrics[operation_name] = []
                self.metrics[operation_name].append(execution_time)
                
                logging.info(
                    f"{operation_name} completed in {execution_time:.2f} seconds"
                )
                return result
            return wrapper
        return decorator

    def get_average_time(self, operation_name: str) -> Optional[float]:
        """Get average execution time for an operation"""
        times = self.metrics.get(operation_name, [])
        return sum(times) / len(times) if times else None

    def print_summary(self):
        """Print performance summary"""
        print("\nPerformance Summary:")
        print("-" * 50)
        for op, times in self.metrics.items():
            avg_time = sum(times) / len(times)
            print(f"{op:30s}: {avg_time:.4f}s (avg of {len(times)} calls)")
```

## Testing and Maintenance

### Test Configuration
```python
# tests/conftest.py
import pytest
import numpy as np
from src.config.settings import LanceDBConfig

@pytest.fixture
def test_config():
    return LanceDBConfig(
        db_path="test_db",
        index_metric="cosine",
        num_partitions=64,
        cache_size_mb=512
    )

@pytest.fixture
def sample_vectors():
    return np.random.rand(100, 128)

@pytest.fixture
def sample_metadata():
    return [
        {
            "id": i,
            "category": f"cat_{i%5}",
            "timestamp": f"2024-{i%12+1:02d}-01"
        }
        for i in range(100)
    ]
```

### Test Cases
```python
# tests/test_crud.py
import pytest
import numpy as np
from src.models.base import LanceDBTable

def test_table_creation(test_config, sample_vectors, sample_metadata):
    # Setup
    db = DatabaseManager(test_config)
    table = db.get_or_create_table(
        "test_table",
        schema={
            "vector": "float32[128]",
            "id": "int64",
            "category": "string",
            "timestamp": "string"
        }
    )
    
    # Test
    lance_table = LanceDBTable(table, test_config)
    lance_table.upsert(sample_vectors, sample_metadata)
    
    # Verify
    assert table.count() == len(sample_vectors)
    
    # Search test
    query_vector = np.random.rand(128)
    results = lance_table.search(query_vector, limit=5)
    assert len(results) == 5

## Error Handling and Logging

### Custom Exception Handling
```python
# utils/exceptions.py
class LanceDBError(Exception):
    """Base exception for LanceDB operations"""
    pass

class TableError(LanceDBError):
    """Raised for table-related errors"""
    pass

class VectorError(LanceDBError):
    """Raised for vector-related errors"""
    pass

class ConfigError(LanceDBError):
    """Raised for configuration errors"""
    pass
```

### Logging Configuration
```python
# utils/logging_config.py
import logging
import sys
from pathlib import Path

def setup_logging(
    log_file: Path,
    level: int = logging.INFO,
    format_string: str = None
):
    """Configure logging for the application"""
    if format_string is None:
        format_string = (
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )

    # Create formatter
    formatter = logging.Formatter(format_string)

    # Setup file handler
    file_handler = logging.FileHandler(log_file)
    file_handler.setFormatter(formatter)

    # Setup console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)

    # Setup root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    return root_logger
```

## Usage Examples

### Complete Usage Example
```python
from src.config.settings import LanceDBConfig
from src.models.base import LanceDBTable
from src.utils.performance_utils import PerformanceMonitor
from src.utils.pandas_utils import DataFrameHandler
import logging

# Initialize configuration
config = LanceDBConfig(
    db_path="production_db",
    index_metric="cosine",
    num_partitions=256,
    cache_size_mb=2048
)

# Setup logging
setup_logging(Path("logs/lancedb.log"))
logger = logging.getLogger(__name__)

# Initialize performance monitoring
perf_monitor = PerformanceMonitor()

# Initialize database
db_manager = DatabaseManager(config)

# Create or open table
table = db_manager.get_or_create_table(
    "embeddings",
    schema={
        "vector": "float32[128]",
        "id": "int64",
        "category": "string",
        "timestamp": "string"
    }
)

# Create table wrapper
lance_table = LanceDBTable(table, config)

# Load and prepare data
df = pd.read_csv("data/embeddings.csv")
df = DataFrameHandler.optimize_dtypes(df)

# Process in chunks
for chunk in DataFrameHandler.chunk_dataframe(df, chunk_size=1000):
    vectors, metadata = DataFrameHandler.prepare_for_lancedb(
        chunk,
        vector_col="embedding",
        metadata_cols=["id", "category", "timestamp"]
    )
    
    try:
        with perf_monitor.measure_time("batch_upsert"):
            lance_table.upsert(vectors, metadata)
    except Exception as e:
        logger.error(f"Error during batch upsert: {str(e)}")
        raise

# Print performance summary
perf_monitor.print_summary()
```

This lesson provides a comprehensive foundation for building production-ready applications with LanceDB, following best practices for configuration management, error handling, performance monitoring, and maintainable code organization. The included examples demonstrate how to structure a project, implement efficient data processing patterns, and maintain high-quality code standards.
