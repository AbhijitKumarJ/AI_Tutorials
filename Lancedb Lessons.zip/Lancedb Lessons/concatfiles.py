import os

def consolidate_folders(root_dir="."):
   """Create separate consolidated files for each subfolder"""
   subfolders = [d for d in os.listdir(root_dir) if os.path.isdir(os.path.join(root_dir, d))]
   if not subfolders:
       print("No subfolders found.")
       return
       
   for folder in sorted(subfolders):
       response = input(f"\nInclude '{folder}'? (Y/n): ").lower()
       if response in ['', 'y']:
           output_file = f"{folder}_consolidated.md"
           folder_path = os.path.join(root_dir, folder)
           
           with open(output_file, 'w', encoding="utf8") as outfile:
               for root, _, files in os.walk(folder_path):
                   for fname in sorted(files):
                       if fname.endswith('.md'):
                           full_path = os.path.join(root, fname)
                           outfile.write("="*80 + "\n")
                           outfile.write(f"FILE PATH: {full_path}\n")
                           outfile.write("="*80 + "\n\n")
                           
                           with open(full_path, 'r', encoding="utf8") as infile:
                               outfile.write(infile.read())
                           outfile.write("\n" + "="*80 + "\n\n")
           print(f"Created: {output_file}")

if __name__ == "__main__":
   consolidate_folders()