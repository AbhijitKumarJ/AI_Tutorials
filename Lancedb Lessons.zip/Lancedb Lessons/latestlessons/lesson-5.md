# Lesson 5: Data Ingestion & Management

## 1. Data Ingestion Methods

LanceDB supports multiple data ingestion methods designed to handle different data sources and volumes efficiently.

```plaintext
Data Ingestion Methods
├── Direct Data Loading
│   ├── Lists/Dictionaries
│   ├── Pandas DataFrames
│   └── PyArrow Tables
├── Streaming Ingestion
│   ├── Iterators
│   └── Batch Processing
└── External Sources
    ├── CSV Files
    ├── Parquet Files
    └── Custom Sources
```

## 2. Basic Data Loading

### From Python Data Structures
```python
import lancedb

# Connect to database
db = lancedb.connect("~/.lancedb")

# Load from list of dictionaries
data = [
    {"vector": [1.1, 1.2], "text": "sample 1"},
    {"vector": [2.1, 2.2], "text": "sample 2"}
]
table = db.create_table("basic_table", data)
```

### From Pandas DataFrame
```python
import pandas as pd

# Create DataFrame
df = pd.DataFrame({
    "vector": [[1.1, 1.2], [2.1, 2.2]],
    "text": ["sample 1", "sample 2"]
})

# Create table from DataFrame
table = db.create_table("pandas_table", data=df)
```

## 3. Batch Processing and Iterators

### Using Iterators for Large Datasets
```python
def make_batches():
    for i in range(5):
        yield [
            {"vector": [3.1, 4.1], "text": "batch item 1"},
            {"vector": [5.9, 26.5], "text": "batch item 2"}
        ]

# Create table with iterator
schema = pa.schema([
    pa.field("vector", pa.list_(pa.float32(), 2)),
    pa.field("text", pa.string())
])
table = db.create_table("batch_table", make_batches(), schema=schema)
```

### Batch Size Optimization
```python
from lancedb.embeddings import with_embeddings

# Configure batch processing
data_with_embeddings = with_embeddings(
    embed_func,
    data,
    batch_size=1000  # Optimize based on memory constraints
)
```

## 4. Data Management Operations

### Adding Data
```python
# Add new data to existing table
table.add(new_data)

# Add with specific mode
table.add(new_data, mode="append")  # or "overwrite"
```

### Updating Data
```python
# Update specific rows
table.update(
    where="category = 'old'",
    values={"category": "new"}
)

# Update using SQL expression
table.update(
    where="price < 100",
    values_sql={"price": "price * 1.1"}
)
```

### Deleting Data
```python
# Delete with condition
table.delete("timestamp < '2023-01-01'")

# Delete specific rows
table.delete("id IN (1, 2, 3)")
```

## 5. Data Validation and Cleaning

### Using Pydantic Validators
```python
from pydantic import validator
from lancedb.pydantic import LanceModel, Vector

class ValidatedDocument(LanceModel):
    text: str
    vector: Vector(128)
    category: str

    @validator('text')
    def clean_text(cls, v):
        return v.strip().lower()

    @validator('category')
    def validate_category(cls, v):
        valid_categories = ['A', 'B', 'C']
        if v not in valid_categories:
            raise ValueError(f"Category must be one of {valid_categories}")
        return v
```

## 6. Error Handling and Recovery

```python
def safe_ingest(table, data_batch):
    try:
        table.add(data_batch)
    except Exception as e:
        print(f"Error ingesting batch: {e}")
        # Implement recovery logic
        if "schema mismatch" in str(e):
            # Handle schema evolution
            pass
        elif "duplicate key" in str(e):
            # Handle duplicates
            pass
        raise
```

## 7. Performance Optimization

### Bulk Loading
```python
def optimize_bulk_load(data, batch_size=1000):
    """Optimize bulk loading with batching"""
    batches = []
    for i in range(0, len(data), batch_size):
        batch = data[i:i + batch_size]
        batches.append(batch)
    return batches
```

### Compaction and Maintenance
```python
# Regular maintenance operations
def maintain_table(table):
    # Compact table
    table.compact()
    
    # Rebuild indices if needed
    table.create_index(replace=True)
```

## 8. Practice Exercise

Create a robust data ingestion pipeline:

```python
import lancedb
import pandas as pd
from typing import Iterator, List, Dict, Any

class DataIngestionPipeline:
    def __init__(self, db_uri: str, table_name: str):
        self.db = lancedb.connect(db_uri)
        self.table_name = table_name
        self.batch_size = 1000

    def preprocess_batch(self, batch: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Implement data preprocessing logic"""
        # Your preprocessing code here
        pass

    def validate_batch(self, batch: List[Dict[str, Any]]) -> bool:
        """Implement validation logic"""
        # Your validation code here
        pass

    def ingest_batch(self, batch: List[Dict[str, Any]]) -> None:
        """Ingest a single batch of data"""
        if self.validate_batch(batch):
            processed_batch = self.preprocess_batch(batch)
            self.table.add(processed_batch)

    def process_stream(self, data_stream: Iterator[Dict[str, Any]]) -> None:
        """Process streaming data"""
        current_batch = []
        for item in data_stream:
            current_batch.append(item)
            if len(current_batch) >= self.batch_size:
                self.ingest_batch(current_batch)
                current_batch = []
        
        # Process remaining items
        if current_batch:
            self.ingest_batch(current_batch)

# Test the pipeline
pipeline = DataIngestionPipeline("~/.lancedb", "test_table")
# Implement test data stream and run pipeline
```

## 9. Best Practices

1. Data Ingestion
   - Use appropriate batch sizes
   - Implement proper error handling
   - Validate data before ingestion
   - Monitor ingestion performance

2. Data Management
   - Regular maintenance
   - Efficient update strategies
   - Proper deletion policies
   - Schema evolution handling

3. Performance
   - Optimize batch sizes
   - Use appropriate indices
   - Regular compaction
   - Monitor system resources

## 10. Key Takeaways

- Multiple ingestion methods support different use cases
- Batch processing optimizes resource usage
- Proper error handling is crucial
- Regular maintenance ensures optimal performance
- Data validation prevents corruption

## Next Lesson Preview

In the next lesson, we'll explore vector search fundamentals, including similarity metrics, query optimization, and advanced search techniques.
