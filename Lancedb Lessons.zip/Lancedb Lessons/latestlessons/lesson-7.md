# Lesson 7: Full-Text and Hybrid Search Capabilities

## 1. Full-Text Search Architecture

LanceDB combines vector search with powerful full-text search (FTS) capabilities. The FTS system is built on a robust indexing mechanism that enables efficient text-based queries.

```plaintext
Full-Text Search Components
├── Text Indexing
│   ├── Tokenization
│   ├── Term Frequency
│   └── Inverse Document Frequency
├── Query Processing
│   ├── Query Analysis
│   └── Term Matching
└── Scoring System
    ├── BM25 Scoring
    └── Relevance Ranking
```

## 2. Setting Up Full-Text Search

### Creating FTS Index
```python
import lancedb
from lancedb.embeddings import get_registry
from lancedb.pydantic import LanceModel, Vector

# Create table with text column
db = lancedb.connect("~/.lancedb")
table = db.create_table("documents", data=[
    {"text": "machine learning basics", "category": "AI"},
    {"text": "deep neural networks", "category": "AI"}
])

# Create FTS index
table.create_fts_index("text", replace=True)
```

## 3. Full-Text Search Operations

### Basic Text Search
```python
# Simple text search
results = table.search(
    "machine learning",
    query_type="fts"
).limit(5).to_pandas()

# With filtering
results = table.search(
    "neural networks",
    query_type="fts"
).where(
    "category = 'AI'"
).limit(5).to_pandas()
```

## 4. Hybrid Search Implementation

### Basic Hybrid Search
```python
# Configure embedding
embedder = get_registry().get("openai").create()

class Document(LanceModel):
    text: str = embedder.SourceField()
    vector: Vector(embedder.ndims()) = embedder.VectorField()
    category: str

# Create table with schema
table = db.create_table("hybrid_search", schema=Document)

# Create FTS index
table.create_fts_index("text")

# Perform hybrid search
results = table.search(
    "deep learning tutorials",
    query_type="hybrid"
).limit(5).to_pandas()
```

## 5. Reranking Strategies

### Using Different Rerankers
```python
from lancedb.rerankers import (
    RRFReranker,
    CohereReranker,
    CrossEncoderReranker
)

# RRF Reranker
results = table.search(
    "machine learning",
    query_type="hybrid"
).rerank(
    reranker=RRFReranker()
).to_pandas()

# Cohere Reranker
results = table.search(
    "machine learning",
    query_type="hybrid"
).rerank(
    reranker=CohereReranker(api_key="your_key")
).to_pandas()

# Cross Encoder Reranker
results = table.search(
    "machine learning",
    query_type="hybrid"
).rerank(
    reranker=CrossEncoderReranker()
).to_pandas()
```

## 6. Advanced Query Techniques

### Complex Query Conditions
```python
# Combining search with complex filters
results = table.search(
    "deep learning",
    query_type="hybrid"
).where(
    "(category = 'AI' OR category = 'ML') AND date > '2024-01-01'"
).limit(10).to_pandas()
```

### Custom Reranking
```python
from lancedb.rerankers import Reranker

class CustomReranker(Reranker):
    def rerank_hybrid(self, query, vector_results, fts_results):
        # Custom reranking logic
        return combined_results

    def rerank_vector(self, query, vector_results):
        # Vector-specific reranking
        return vector_results

    def rerank_fts(self, query, fts_results):
        # FTS-specific reranking
        return fts_results
```

## 7. Performance Optimization

### Query Optimization
```python
# Optimize hybrid search
results = table.search(
    "deep learning",
    query_type="hybrid"
).where(
    "category = 'AI'",
    prefilter=True  # Apply filter before search
).limit(10).to_pandas()
```

### Index Management
```python
# Rebuild indices for optimal performance
def optimize_indices(table):
    # Rebuild FTS index
    table.create_fts_index("text", replace=True)
    
    # Rebuild vector index
    table.create_index(
        metric="cosine",
        num_partitions=256,
        num_sub_vectors=96,
        replace=True
    )
```

## 8. Practice Exercise

Build a hybrid search system with custom ranking:

```python
import lancedb
from lancedb.embeddings import get_registry
from lancedb.pydantic import LanceModel, Vector
from lancedb.rerankers import Reranker
from typing import Optional, List, Dict

class SearchEngine:
    def __init__(self, db_path: str):
        self.db = lancedb.connect(db_path)
        self.embedder = get_registry().get("sentence-transformers").create()
        
        class Document(LanceModel):
            text: str = self.embedder.SourceField()
            vector: Vector(self.embedder.ndims()) = self.embedder.VectorField()
            category: str
            importance: float
        
        self.schema = Document
        
    def create_indices(self, table):
        """Create necessary indices"""
        table.create_fts_index("text")
        table.create_index(metric="cosine")
        
    def search(
        self,
        query: str,
        category: Optional[str] = None,
        min_importance: float = 0.0,
        k: int = 5
    ) -> pd.DataFrame:
        """
        Perform hybrid search with filtering
        """
        base_query = self.table.search(
            query,
            query_type="hybrid"
        )
        
        # Apply filters
        filters = []
        if category:
            filters.append(f"category = '{category}'")
        if min_importance > 0:
            filters.append(f"importance >= {min_importance}")
            
        if filters:
            base_query = base_query.where(" AND ".join(filters))
            
        return base_query.limit(k).to_pandas()

# Test implementation
engine = SearchEngine("~/.lancedb")
# Add test data and run searches
```

## 9. Best Practices

1. Index Management
   - Regular index maintenance
   - Optimize index parameters
   - Monitor index performance

2. Query Optimization
   - Use prefilters
   - Batch similar queries
   - Choose appropriate rerankers

3. Result Quality
   - Validate search results
   - Tune reranking parameters
   - Monitor search quality

## 10. Key Takeaways

- Hybrid search combines vector and text search capabilities
- Reranking improves result quality
- Index optimization is crucial for performance
- Custom rerankers enable specialized ranking logic
- Regular maintenance ensures optimal performance

## Next Lesson Preview

In the next lesson, we'll explore integration with ML frameworks, including using custom embedding models, integrating with popular ML libraries, and building end-to-end ML pipelines.
