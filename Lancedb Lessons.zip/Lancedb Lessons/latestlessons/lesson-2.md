# Lesson 2: LanceDB Architecture & Core Components

## 1. Core Architecture Overview

LanceDB is built on a modular architecture designed for efficient vector storage and retrieval. The system separates storage from compute, enabling serverless deployments and scalable operations. Let's explore the key components:

```plaintext
LanceDB Architecture
├── Storage Layer
│   ├── Lance Format (Columnar Storage)
│   ├── Fragment Management
│   └── Version Control
├── Compute Layer
│   ├── Query Engine
│   ├── Index Management
│   └── Embedding Functions
└── API Layer
    ├── Python API
    ├── JavaScript API
    └── REST API
```

## 2. Lance Data Format

The foundation of LanceDB is the Lance data format, which provides several key features:

1. Columnar Storage
   - Data organized by columns rather than rows
   - Efficient compression and query performance
   - Interoperable with other columnar formats via Apache Arrow

2. Data Fragmentation
   - Data divided into manageable fragments
   - Each fragment represents a subset of data
   - Optimized for parallel processing

3. Version Control
   - Each insert creates a new version
   - Metadata tracks versions via manifest
   - Efficient storage with only changed data per version

## 3. Index Types and Management

LanceDB supports multiple index types for different query patterns:

### Vector Indices
```python
# IVF-PQ Index Configuration
table.create_index(
    metric="L2",
    num_partitions=256,
    num_sub_vectors=96
)
```

### Scalar Indices
```python
# Different types of scalar indices
table.create_scalar_index("column_name", index_type="BTREE")  # For high cardinality
table.create_scalar_index("category", index_type="BITMAP")    # For low cardinality
table.create_scalar_index("tags", index_type="LABEL_LIST")    # For list columns
```

## 4. Query Processing Pipeline

Understanding how LanceDB processes queries is crucial:

```plaintext
Query Flow
1. Query Input
   ↓
2. Query Planning
   ├── Index Selection
   ├── Filter Push-down
   └── Optimization
   ↓
3. Execution
   ├── Parallel Processing
   ├── Fragment Scanning
   └── Result Aggregation
   ↓
4. Result Return
```

## 5. Embedding Functions Integration

LanceDB provides a powerful embedding function API:

```python
from lancedb.embeddings import get_registry
from lancedb.pydantic import LanceModel, Vector

# Define embedding model
embedder = get_registry().get("openai").create()

# Define schema with embedding
class Documents(LanceModel):
    text: str = embedder.SourceField()
    vector: Vector(embedder.ndims()) = embedder.VectorField()

# Create table with automatic embedding
table = db.create_table("documents", schema=Documents)
table.add([{"text": "sample document"}])
```

## 6. Data Management Features

### Compaction
```python
# Compaction improves query performance
table.compact()
```

### Deletion
```python
# Delete with conditions
table.delete("category = 'obsolete'")
```

### Reindexing
```python
# Rebuild index after significant changes
table.create_index(replace=True)
```

## 7. Advanced Query Features

### Hybrid Search
```python
# Create FTS index
table.create_fts_index("text")

# Hybrid search with reranking
result = table.search(
    "query text",
    query_type="hybrid"
).rerank(reranker=reranker).to_pandas()
```

### Query Filters
```python
# Combining vector search with filters
results = table.search(query_vector)
                .where("category = 'active'")
                .limit(10)
                .to_pandas()
```

## 8. Performance Monitoring

Key metrics to monitor:

1. Query Latency
2. Fragment Size
3. Index Performance
4. Memory Usage
5. Storage Efficiency

## 9. Practice Exercise

Create a table with multiple indices and explore query performance:

```python
import lancedb
import numpy as np

# Initialize database
db = lancedb.connect("~/.lancedb")

# Create sample data
data = [
    {
        "vector": np.random.rand(128),
        "text": "Document A",
        "category": "tech",
        "tags": ["ai", "ml"]
    }
    # Add more samples...
]

# Tasks:
# 1. Create table with appropriate schema
# 2. Add vector and scalar indices
# 3. Perform hybrid search with filters
# 4. Compare performance with/without indices
```

## 10. Best Practices

1. Data Organization
   - Use appropriate fragment sizes (aim for <100 fragments)
   - Regular compaction for optimal performance
   - Proper schema design

2. Index Management
   - Choose appropriate index types
   - Regular reindexing for dynamic data
   - Monitor index performance

3. Query Optimization
   - Use filters effectively
   - Batch operations when possible
   - Implement proper error handling

## 11. Key Takeaways

- LanceDB's architecture combines efficient storage with powerful query capabilities
- Multiple index types support different query patterns
- Embedding functions provide seamless vector generation
- Performance optimization requires understanding of system components
- Regular maintenance tasks ensure optimal performance

## Next Lesson Preview

In the next lesson, we'll explore storage options and configurations in detail, including cloud storage integration and optimization strategies for different deployment scenarios.
