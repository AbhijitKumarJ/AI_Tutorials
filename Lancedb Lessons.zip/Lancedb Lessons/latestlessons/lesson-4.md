# Lesson 4: Data Modeling & Schema Design

## 1. Schema Design Fundamentals

LanceDB provides flexible schema design options through PyArrow schemas and Pydantic models. The schema system supports both simple and complex data types, enabling efficient storage and retrieval of vector embeddings alongside metadata.

```plaintext
Schema Components
├── Vector Fields
│   ├── Fixed-size Lists
│   └── Embedding Dimensions
├── Metadata Fields
│   ├── Primitive Types
│   ├── Complex Types
│   └── Nested Structures
└── Index Configurations
    ├── Vector Indices
    └── Scalar Indices
```

## 2. Defining Schemas Using Pydantic

### Basic Schema Definition
```python
from lancedb.pydantic import LanceModel, Vector
from lancedb.embeddings import get_registry

# Get embedding model
embedder = get_registry().get("openai").create()

class Document(LanceModel):
    # Vector field with automatic embedding
    vector: Vector(embedder.ndims()) = embedder.VectorField()
    
    # Source field for embedding
    text: str = embedder.SourceField()
    
    # Metadata fields
    title: str
    category: str
    timestamp: datetime
    tags: List[str]
```

### Nested Schema Structures
```python
class Metadata(BaseModel):
    source: str
    author: str
    created_at: datetime

class ComplexDocument(LanceModel):
    vector: Vector(384)
    content: str
    metadata: Metadata
```

## 3. PyArrow Schema Definition

```python
import pyarrow as pa

# Define schema manually
schema = pa.schema([
    pa.field("vector", pa.list_(pa.float32(), 384)),
    pa.field("text", pa.string()),
    pa.field("metadata", pa.struct([
        pa.field("source", pa.string()),
        pa.field("author", pa.string()),
        pa.field("created_at", pa.timestamp('s'))
    ]))
])

# Create table with schema
table = db.create_table("documents", schema=schema)
```

## 4. Data Types and Conversions

### Supported Type Mappings
```python
# Pydantic to PyArrow Type Conversion
TYPE_MAPPING = {
    int: pa.int64(),
    float: pa.float64(),
    bool: pa.bool_(),
    str: pa.utf8(),
    list: pa.list_(),
    BaseModel: pa.struct(),
    Vector: lambda dim: pa.list_(pa.float32(), dim)
}
```

### Custom Type Handling
```python
from pydantic import Field, validator
from typing import List

class CustomDocument(LanceModel):
    tags: List[str] = Field(default_factory=list)
    
    @validator('tags')
    def validate_tags(cls, v):
        return [tag.lower() for tag in v]
```

## 5. Schema Evolution

LanceDB supports schema evolution, allowing you to modify your schema over time:

```python
# Adding new columns
table.add(new_data_with_extra_columns)

# Handling missing columns
table.add(new_data_missing_columns, mode="append")
```

## 6. Embedding Integration

### Automatic Embedding
```python
from lancedb.embeddings import get_registry

# Configure embedding function
embedder = get_registry().get("sentence-transformers").create(
    name="all-MiniLM-L6-v2"
)

class AutoEmbedDocument(LanceModel):
    text: str = embedder.SourceField()
    vector: Vector(embedder.ndims()) = embedder.VectorField()

# Data is automatically embedded during insertion
table = db.create_table("auto_embed", schema=AutoEmbedDocument)
table.add([{"text": "Sample document"}])
```

### Manual Embedding
```python
from lancedb.embeddings import with_embeddings

def embed_func(texts):
    # Custom embedding logic
    return [model.encode(text) for text in texts]

data_with_embeddings = with_embeddings(embed_func, data)
table.add(data_with_embeddings)
```

## 7. Index Design

### Vector Index Configuration
```python
# IVF-PQ Index
table.create_index(
    metric="L2",
    num_partitions=256,
    num_sub_vectors=96
)

# Full-text Search Index
table.create_fts_index("text")
```

### Scalar Index Selection
```python
# B-tree for high cardinality
table.create_scalar_index("timestamp")

# Bitmap for low cardinality
table.create_scalar_index("category", index_type="BITMAP")

# Label list for arrays
table.create_scalar_index("tags", index_type="LABEL_LIST")
```

## 8. Practice Exercise

Design a schema for a document management system:

```python
from datetime import datetime
from typing import List, Optional
from lancedb.pydantic import LanceModel, Vector
from lancedb.embeddings import get_registry

# Task 1: Define the schema
class Author(BaseModel):
    name: str
    email: str
    department: str

class Document(LanceModel):
    # Define fields here...
    pass

# Task 2: Create table and add data
db = lancedb.connect("~/.lancedb")
table = db.create_table("documents", schema=Document)

# Task 3: Add appropriate indices
# Task 4: Test queries and performance
```

## 9. Best Practices

### Schema Design
1. Keep vector dimensions consistent
2. Use appropriate data types
3. Consider query patterns
4. Plan for schema evolution

### Performance Optimization
1. Choose appropriate index types
2. Optimize embedding process
3. Monitor schema complexity
4. Regular maintenance

## 10. Key Takeaways

- Proper schema design is crucial for performance
- Pydantic integration provides type safety
- Automatic embedding simplifies workflow
- Schema evolution supports changing requirements
- Index selection impacts query performance

## Next Lesson Preview

In the next lesson, we'll explore data ingestion and management techniques, including batch operations, updates, and deletion strategies in LanceDB.
