# Lesson 8: Integration with ML Frameworks

## 1. ML Framework Integration Overview

```plaintext
ML Integration Components
├── Embedding Models
│   ├── LangChain
│   ├── LlamaIndex
│   └── Custom Models
├── Vector Generation
│   ├── Sentence Transformers
│   ├── OpenAI Embeddings
│   └── Custom Embeddings
└── Pipeline Integration
    ├── Training Data Management
    ├── Inference Pipeline
    └── Model Versioning
```

## 2. LangChain Integration

```python
from langchain.vectorstores import LanceDB
from langchain.embeddings import OpenAIEmbeddings
from langchain.document_loaders import TextLoader
from langchain.text_splitter import CharacterTextSplitter

# Initialize LangChain components
embeddings = OpenAIEmbeddings()
loader = TextLoader('data.txt')
documents = loader.load()

# Split documents
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
docs = text_splitter.split_documents(documents)

# Create LanceDB vectorstore
db = lancedb.connect('~/.lancedb')
vectorstore = LanceDB.from_documents(
    documents=docs,
    embedding=embeddings,
    connection=db
)

# Perform similarity search
query = "what is machine learning?"
docs = vectorstore.similarity_search(query)
```

## 3. LlamaIndex Integration

```python
from llama_index import VectorStoreIndex, SimpleDirectoryReader
from llama_index.vector_stores import LanceDBVectorStore

# Load documents
documents = SimpleDirectoryReader('data_dir').load_data()

# Create vector store
vector_store = LanceDBVectorStore(
    uri="~/.lancedb",
    table_name="llama_index_table"
)

# Create index
index = VectorStoreIndex.from_documents(
    documents,
    vector_store=vector_store
)

# Query the index
query_engine = index.as_query_engine()
response = query_engine.query("what is deep learning?")
```

## 4. Custom Embedding Models

### Creating Custom Embedding Function
```python
from lancedb.embeddings import EmbeddingFunction, register

@register("custom-embedder")
class CustomEmbeddings(EmbeddingFunction):
    def __init__(self, model_name, **kwargs):
        self.model = load_model(model_name)
        self._ndims = None

    def generate_embeddings(self, texts):
        return [self.model.embed(text) for text in texts]

    def ndims(self):
        if self._ndims is None:
            self._ndims = len(self.generate_embeddings(["test"])[0])
        return self._ndims
```

### Using Custom Embeddings
```python
from lancedb.pydantic import LanceModel, Vector

custom_embedder = get_registry().get("custom-embedder").create()

class Document(LanceModel):
    text: str = custom_embedder.SourceField()
    vector: Vector(custom_embedder.ndims()) = custom_embedder.VectorField()

table = db.create_table("custom_embeddings", schema=Document)
```

## 5. Building ML Pipelines

### Training Pipeline
```python
import pytorch_lightning as pl
from torch.utils.data import DataLoader

class EmbeddingTrainer(pl.LightningModule):
    def __init__(self, table_name):
        super().__init__()
        self.db = lancedb.connect("~/.lancedb")
        self.table = self.db.open_table(table_name)
        
    def train_dataloader(self):
        data = self.table.to_lance()
        return DataLoader(data, batch_size=32)
    
    def training_step(self, batch, batch_idx):
        # Training logic
        pass

# Train model
trainer = pl.Trainer(max_epochs=10)
model = EmbeddingTrainer("training_data")
trainer.fit(model)
```

### Inference Pipeline
```python
class InferencePipeline:
    def __init__(self, model_path, db_path):
        self.model = load_model(model_path)
        self.db = lancedb.connect(db_path)
        
    def preprocess(self, text):
        # Preprocessing logic
        return processed_text
        
    def generate_embedding(self, text):
        processed = self.preprocess(text)
        return self.model.encode(processed)
        
    def search(self, query, table_name, k=5):
        embedding = self.generate_embedding(query)
        table = self.db.open_table(table_name)
        return table.search(embedding).limit(k).to_pandas()
```

## 6. MLflow Integration

```python
import mlflow

class MLflowEmbeddingTracker:
    def __init__(self, experiment_name):
        mlflow.set_experiment(experiment_name)
        
    def log_model(self, model, metrics):
        with mlflow.start_run():
            # Log model
            mlflow.pytorch.log_model(model, "embedding_model")
            
            # Log metrics
            mlflow.log_metrics(metrics)
            
    def load_model(self, run_id):
        return mlflow.pytorch.load_model(f"runs:/{run_id}/embedding_model")
```

## 7. Practice Exercise

Build an end-to-end ML pipeline:

```python
class SemanticSearchPipeline:
    def __init__(self, db_path: str):
        self.db = lancedb.connect(db_path)
        self.embedder = get_registry().get("sentence-transformers").create()
        
    def prepare_data(self, texts: List[str]) -> pd.DataFrame:
        """Prepare training data"""
        pass
        
    def train_model(self, data: pd.DataFrame) -> None:
        """Train custom embedding model"""
        pass
        
    def create_index(self, table_name: str) -> None:
        """Create search index"""
        pass
        
    def search(self, query: str, k: int = 5) -> pd.DataFrame:
        """Perform semantic search"""
        pass

# Implement the pipeline
pipeline = SemanticSearchPipeline("~/.lancedb")
# Test with sample data
```

## 8. Performance Optimization

### Batch Processing
```python
def batch_process_embeddings(texts, batch_size=32):
    """Process embeddings in batches"""
    embeddings = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        batch_embeddings = model.encode(batch)
        embeddings.extend(batch_embeddings)
    return embeddings
```

### Caching
```python
from functools import lru_cache

class CachedEmbedder:
    def __init__(self, model_name):
        self.model = load_model(model_name)
    
    @lru_cache(maxsize=1000)
    def embed(self, text):
        return self.model.encode(text)
```

## 9. Best Practices

1. Model Integration
   - Validate embedding dimensions
   - Handle errors gracefully
   - Implement proper batching

2. Pipeline Design
   - Modular components
   - Error handling
   - Performance monitoring

3. Production Deployment
   - Version control
   - Model monitoring
   - Resource optimization

## 10. Key Takeaways

- Multiple ML framework integration options
- Custom embedding model support
- End-to-end pipeline creation
- Performance optimization techniques
- Production deployment considerations

## Next Lesson Preview

Next lesson covers RAG applications and use cases, including chatbots, document search, and recommendation systems.
