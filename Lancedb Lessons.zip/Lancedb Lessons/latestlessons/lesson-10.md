# Lesson 10: Production Deployment and Scaling

## 1. Deployment Architecture

```plaintext
Production Components
├── Database Layer
│   ├── Cloud Storage (S3/GCS/Azure)
│   └── DynamoDB for Locks
├── Compute Layer
│   ├── Serverless Functions
│   └── Container Deployments
└── Application Layer
    ├── API Service
    ├── Background Jobs
    └── Monitoring System
```

## 2. Cloud Deployment Configuration

### AWS Configuration
```python
import lancedb
import os

def configure_aws_deployment():
    # Configure S3 storage with DynamoDB locking
    db = lancedb.connect(
        "s3+ddb://bucket/database?ddbTableName=lance_locks",
        storage_options={
            "aws_access_key_id": os.getenv("AWS_ACCESS_KEY_ID"),
            "aws_secret_access_key": os.getenv("AWS_SECRET_ACCESS_KEY"),
            "region": "us-east-1",
            "endpoint": "http://s3.amazonaws.com",
            "connect_timeout": "5s",
            "timeout": "60s"
        }
    )
    return db

def create_dynamodb_table():
    import boto3
    
    dynamodb = boto3.client('dynamodb')
    table = dynamodb.create_table(
        TableName='lance_locks',
        KeySchema=[
            {"AttributeName": "base_uri", "KeyType": "HASH"},
            {"AttributeName": "version", "KeyType": "RANGE"}
        ],
        AttributeDefinitions=[
            {"AttributeName": "base_uri", "AttributeType": "S"},
            {"AttributeName": "version", "AttributeType": "N"}
        ],
        ProvisionedThroughput={
            "ReadCapacityUnits": 5,
            "WriteCapacityUnits": 5
        }
    )
    return table
```

## 3. Containerized Deployment

### Docker Configuration
```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

ENV LANCEDB_URI="s3://bucket/database"
ENV AWS_ACCESS_KEY_ID=""
ENV AWS_SECRET_ACCESS_KEY=""

CMD ["python", "app.py"]
```

### Docker Compose Setup
```yaml
version: '3'
services:
  lancedb_api:
    build: .
    environment:
      - LANCEDB_URI=s3://bucket/database
      - AWS_ACCESS_KEY_ID
      - AWS_SECRET_ACCESS_KEY
    ports:
      - "8000:8000"
    volumes:
      - ./data:/app/data

  background_worker:
    build: .
    command: python worker.py
    environment:
      - LANCEDB_URI=s3://bucket/database
      - AWS_ACCESS_KEY_ID
      - AWS_SECRET_ACCESS_KEY
    volumes:
      - ./data:/app/data
```

## 4. Performance Optimization

### Connection Pool Management
```python
class LanceDBPool:
    def __init__(self, max_connections=10):
        self.max_connections = max_connections
        self.connections = []
        self.semaphore = asyncio.Semaphore(max_connections)
        
    async def get_connection(self):
        async with self.semaphore:
            if not self.connections:
                conn = await lancedb.connect_async("s3://bucket/database")
                self.connections.append(conn)
            return self.connections.pop()
            
    async def release_connection(self, conn):
        self.connections.append(conn)
```

### Batch Processing
```python
class BatchProcessor:
    def __init__(self, table_name, batch_size=1000):
        self.table = db.open_table(table_name)
        self.batch_size = batch_size
        self.current_batch = []
        
    async def process_item(self, item):
        self.current_batch.append(item)
        if len(self.current_batch) >= self.batch_size:
            await self.flush()
            
    async def flush(self):
        if self.current_batch:
            await self.table.add(self.current_batch)
            self.current_batch = []
```

## 5. Monitoring and Observability

### Prometheus Metrics
```python
from prometheus_client import Counter, Histogram
import time

# Define metrics
query_counter = Counter('lancedb_queries_total', 'Total number of queries')
query_latency = Histogram('lancedb_query_duration_seconds', 'Query duration')

class MonitoredTable:
    def __init__(self, table):
        self.table = table
        
    async def search(self, query, **kwargs):
        query_counter.inc()
        start_time = time.time()
        try:
            result = await self.table.search(query, **kwargs)
            return result
        finally:
            query_latency.observe(time.time() - start_time)
```

### Logging Configuration
```python
import logging
import json

class JSONFormatter(logging.Formatter):
    def format(self, record):
        log_record = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "message": record.getMessage(),
            "location": f"{record.filename}:{record.lineno}"
        }
        if hasattr(record, 'query'):
            log_record["query"] = record.query
        if hasattr(record, 'latency'):
            log_record["latency"] = record.latency
        return json.dumps(log_record)

def setup_logging():
    logger = logging.getLogger("lancedb")
    handler = logging.StreamHandler()
    handler.setFormatter(JSONFormatter())
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
```

## 6. Scaling Strategies

### Horizontal Scaling
```python
class ShardedLanceDB:
    def __init__(self, shard_count):
        self.shard_count = shard_count
        self.shards = [
            lancedb.connect(f"s3://bucket/shard_{i}")
            for i in range(shard_count)
        ]
        
    def get_shard(self, key):
        shard_id = hash(key) % self.shard_count
        return self.shards[shard_id]
        
    async def distributed_search(self, query):
        tasks = [
            shard.open_table("data").search(query)
            for shard in self.shards
        ]
        results = await asyncio.gather(*tasks)
        return self.merge_results(results)
```

## 7. Error Handling and Recovery

```python
class ResilientLanceDB:
    def __init__(self, uri, max_retries=3):
        self.uri = uri
        self.max_retries = max_retries
        
    async def execute_with_retry(self, operation):
        retries = 0
        while retries < self.max_retries:
            try:
                return await operation()
            except Exception as e:
                retries += 1
                if retries == self.max_retries:
                    raise
                await asyncio.sleep(2 ** retries)
                
    async def reconnect(self):
        self.db = await lancedb.connect_async(self.uri)
        
    async def search_safely(self, table_name, query):
        return await self.execute_with_retry(
            lambda: self.db.open_table(table_name).search(query)
        )
```

## 8. Security Configuration

```python
def configure_security():
    return {
        "encryption": {
            "at_rest": True,
            "in_transit": True,
            "kms_key_id": "arn:aws:kms:region:account:key/id"
        },
        "authentication": {
            "iam_role": "arn:aws:iam::account:role/LanceDB",
            "temporary_credentials": True
        },
        "network": {
            "vpc_config": {
                "subnet_ids": ["subnet-xxx"],
                "security_group_ids": ["sg-xxx"]
            }
        }
    }
```

## 9. Backup and Recovery

```python
class BackupManager:
    def __init__(self, source_uri, backup_uri):
        self.source = lancedb.connect(source_uri)
        self.backup = lancedb.connect(backup_uri)
        
    async def create_backup(self, table_name):
        source_table = self.source.open_table(table_name)
        data = await source_table.to_arrow()
        backup_table = self.backup.create_table(
            f"{table_name}_backup_{int(time.time())}",
            data
        )
        
    async def restore_from_backup(self, backup_name, target_name):
        backup_table = self.backup.open_table(backup_name)
        data = await backup_table.to_arrow()
        self.source.create_table(target_name, data)
```

## 10. Practice Exercise

Implement a production-ready LanceDB service:

```python
import lancedb
import asyncio
from typing import Optional, Dict, Any

class ProductionLanceDB:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.pool = LanceDBPool(max_connections=config["max_connections"])
        self.monitor = MonitoredTable
        self.backup = BackupManager(
            config["primary_uri"],
            config["backup_uri"]
        )
        
    async def initialize(self):
        """Initialize database and create necessary resources"""
        pass
        
    async def search(
        self,
        query: str,
        table: str,
        filters: Optional[Dict] = None
    ) -> pd.DataFrame:
        """Perform search with monitoring and error handling"""
        pass
        
    async def backup(self, table: str):
        """Create backup of specified table"""
        pass
        
    async def health_check(self) -> Dict[str, Any]:
        """Check system health"""
        pass

# Implementation testing
config = {
    "primary_uri": "s3://bucket/primary",
    "backup_uri": "s3://bucket/backup",
    "max_connections": 10
}

service = ProductionLanceDB(config)
# Test various operations
```

## 11. Key Takeaways

- Cloud deployment requires careful configuration
- Performance optimization through connection pooling and batching
- Comprehensive monitoring essential for production
- Error handling and recovery mechanisms crucial
- Regular backups and security measures required

