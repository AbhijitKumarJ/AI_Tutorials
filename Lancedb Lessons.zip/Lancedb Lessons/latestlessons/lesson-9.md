# Lesson 9: RAG Applications and Use Cases

## 1. Understanding RAG Architecture

Retrieval-Augmented Generation (RAG) combines the power of retrieval systems with language models to produce more accurate and contextual responses.

```plaintext
RAG Components
├── Knowledge Base
│   ├── Document Storage
│   └── Vector Embeddings
├── Retrieval System
│   ├── Vector Search
│   ├── Contextual Retrieval
│   └── Relevance Ranking
└── Generation System
    ├── Context Integration
    ├── Response Generation
    └── Output Verification
```

## 2. Building a Basic RAG System

```python
import lancedb
from lancedb.embeddings import get_registry
from lancedb.pydantic import LanceModel, Vector
from langchain.llms import OpenAI

class RAGSystem:
    def __init__(self, db_path: str):
        self.db = lancedb.connect(db_path)
        self.embedder = get_registry().get("openai").create()
        self.llm = OpenAI()
        
    def create_knowledge_base(self, documents: List[Dict]):
        class Document(LanceModel):
            text: str = self.embedder.SourceField()
            vector: Vector(self.embedder.ndims()) = self.embedder.VectorField()
            source: str
            
        self.table = self.db.create_table("knowledge_base", schema=Document)
        self.table.add(documents)
        
    def retrieve(self, query: str, k: int = 3) -> List[str]:
        results = self.table.search(query).limit(k).to_pandas()
        return results['text'].tolist()
        
    def generate_response(self, query: str, context: List[str]) -> str:
        prompt = f"""
        Context: {' '.join(context)}
        
        Question: {query}
        
        Please provide a detailed answer based on the context provided above.
        """
        return self.llm.generate(prompt)
```

## 3. Advanced RAG Implementations

### Self-RAG Implementation
```python
from lancedb.rerankers import CrossEncoderReranker

class SelfRAGSystem:
    def __init__(self):
        self.reranker = CrossEncoderReranker()
        
    def retrieve_with_reflection(self, query: str, initial_results: pd.DataFrame) -> pd.DataFrame:
        # Rerank with self-reflection
        return self.reranker.rerank(
            query=query,
            results=initial_results,
            self_reflect=True
        )
```

### Multi-Head RAG
```python
class MultiHeadRAG:
    def __init__(self, num_heads: int):
        self.embedders = [
            get_registry().get("openai").create(),
            get_registry().get("sentence-transformers").create(),
            get_registry().get("cohere").create()
        ][:num_heads]
        
    def retrieve_multi(self, query: str) -> List[pd.DataFrame]:
        results = []
        for embedder in self.embedders:
            results.append(
                self.table.search(query, embedder=embedder)
                    .limit(3)
                    .to_pandas()
            )
        return self.merge_results(results)
```

## 4. Real-World Applications

### Document Q&A System
```python
class DocumentQA:
    def __init__(self, db_path: str):
        self.rag = RAGSystem(db_path)
        
    def ingest_documents(self, documents: List[str]):
        processed_docs = [
            {"text": doc, "source": f"doc_{i}"}
            for i, doc in enumerate(documents)
        ]
        self.rag.create_knowledge_base(processed_docs)
        
    def ask(self, question: str) -> str:
        context = self.rag.retrieve(question)
        return self.rag.generate_response(question, context)
```

### Chatbot Implementation
```python
class RAGChatbot:
    def __init__(self):
        self.rag = RAGSystem("~/.lancedb")
        self.history = []
        
    def chat(self, message: str) -> str:
        self.history.append({"role": "user", "content": message})
        
        # Get relevant context
        context = self.rag.retrieve(message)
        
        # Generate response with context and history
        response = self.rag.generate_response(
            message,
            context=context,
            history=self.history
        )
        
        self.history.append({"role": "assistant", "content": response})
        return response
```

## 5. Optimization Techniques

### Context Window Management
```python
def optimize_context(documents: List[str], max_tokens: int = 2000) -> List[str]:
    """Optimize context for token limits"""
    total_tokens = 0
    optimized_docs = []
    
    for doc in documents:
        token_count = count_tokens(doc)
        if total_tokens + token_count <= max_tokens:
            optimized_docs.append(doc)
            total_tokens += token_count
    
    return optimized_docs
```

### Result Reranking
```python
def rerank_results(query: str, results: pd.DataFrame, k: int = 3) -> pd.DataFrame:
    """Rerank results based on relevance"""
    reranker = CrossEncoderReranker()
    return reranker.rerank_fts(query, results).head(k)
```

## 6. Practice Exercise

Build a document-based chatbot:

```python
import lancedb
from typing import List, Dict, Optional

class DocumentChatbot:
    def __init__(self, db_path: str):
        self.db = lancedb.connect(db_path)
        self.embedder = get_registry().get("openai").create()
        
        class Document(LanceModel):
            text: str = self.embedder.SourceField()
            vector: Vector(self.embedder.ndims()) = self.embedder.VectorField()
            source: str
            
        self.schema = Document
        
    def ingest_documents(self, documents: List[Dict[str, str]]):
        """
        Ingest documents into knowledge base
        """
        self.table = self.db.create_table("chatbot_kb", schema=self.schema)
        self.table.add(documents)
        
    def get_context(self, query: str, k: int = 3) -> List[str]:
        """
        Retrieve relevant context for query
        """
        results = self.table.search(query).limit(k).to_pandas()
        return results['text'].tolist()
        
    def generate_response(
        self,
        query: str,
        context: List[str],
        chat_history: Optional[List[Dict]] = None
    ) -> str:
        """
        Generate response using context and history
        """
        # Implement response generation
        pass
        
    def chat(self, message: str) -> str:
        """
        Main chat interface
        """
        # Implement chat logic
        pass

# Test implementation
chatbot = DocumentChatbot("~/.lancedb")
# Add test documents and try conversations
```

## 7. Best Practices

1. System Design
   - Modular architecture
   - Clear component separation
   - Error handling
   - Performance monitoring

2. Context Management
   - Optimal context size
   - Relevance filtering
   - History management

3. Response Generation
   - Output validation
   - Factual accuracy
   - Response formatting

## 8. Key Takeaways

- RAG enhances LLM responses with relevant context
- Multiple RAG architectures for different use cases
- Context optimization crucial for performance
- Reranking improves result quality
- Error handling and validation important

## Next Lesson Preview

The next lesson covers production deployment and scaling, including cloud deployment, monitoring, and performance optimization.
