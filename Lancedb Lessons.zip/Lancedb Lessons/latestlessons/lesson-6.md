# Lesson 6: Vector Search Fundamentals

## 1. Understanding Vector Search

Vector search is the core functionality of LanceDB, enabling similarity-based searches using vector representations of data. The process involves converting queries into vectors and finding the most similar vectors in the database using distance metrics.

```plaintext
Vector Search Pipeline
├── Query Processing
│   ├── Query Vectorization
│   └── Distance Metric Selection
├── Index Traversal
│   ├── ANN Algorithm
│   └── Distance Calculation
└── Result Ranking
    ├── Score Calculation
    └── Result Filtering
```

## 2. Distance Metrics

LanceDB supports multiple distance metrics for similarity calculation:

```python
# L2 (Euclidean) Distance
table.search(query_vector, metric="L2")

# Cosine Similarity
table.search(query_vector, metric="cosine")

# Dot Product
table.search(query_vector, metric="dot")
```

### Metric Selection Guide
- L2: Best for absolute distances, normalized vectors
- Cosine: Best for directional similarity, varying magnitudes
- Dot Product: Best for learned embeddings optimized for dot product

## 3. Building and Using Indices

### IVF-PQ Index
```python
# Create IVF-PQ index
table.create_index(
    metric="L2",
    num_partitions=256,  # Number of clusters
    num_sub_vectors=96,  # Number of sub-vectors for quantization
)

# Search with index parameters
results = table.search(query_vector)
                .nprobes(20)        # Number of clusters to search
                .refine_factor(10)  # Number of candidates for reranking
                .limit(5)
                .to_pandas()
```

## 4. Query Types and Combinations

### Vector Search
```python
# Basic vector search
results = table.search([1.0, 2.0]).limit(5).to_pandas()

# With filtering
results = table.search([1.0, 2.0])
                .where("category = 'tech'")
                .limit(5)
                .to_pandas()
```

### Hybrid Search
```python
# Create FTS index first
table.create_fts_index("text")

# Hybrid search with reranking
from lancedb.rerankers import RRFReranker

results = table.search(
    "machine learning",
    query_type="hybrid"
).rerank(
    reranker=RRFReranker()
).to_pandas()
```

## 5. Performance Optimization

### Query Optimization
```python
# Pre-filter optimization
results = table.search(query_vector)
                .where("timestamp > '2024-01-01'", prefilter=True)
                .limit(10)
                .to_pandas()

# Batch search for multiple queries
queries = [[1.0, 2.0], [3.0, 4.0]]
results = [table.search(q).limit(5).to_pandas() for q in queries]
```

### Index Tuning
```python
# Fine-tune index parameters
table.create_index(
    metric="L2",
    num_partitions=optimal_partitions(table_size),
    num_sub_vectors=optimal_subvectors(vector_dim)
)

def optimal_partitions(size):
    """Calculate optimal number of partitions"""
    return min(int(size ** 0.5), 1024)

def optimal_subvectors(dim):
    """Calculate optimal number of sub-vectors"""
    return min(dim // 4, 96)
```

## 6. Embedding Integration

### Automatic Embedding
```python
from lancedb.embeddings import get_registry

# Configure embedding function
embedder = get_registry().get("openai").create()

class Document(LanceModel):
    text: str = embedder.SourceField()
    vector: Vector(embedder.ndims()) = embedder.VectorField()

# Search automatically converts query to vector
table.search("what is machine learning?").limit(5).to_pandas()
```

### Custom Embedding
```python
def custom_embed(texts):
    """Custom embedding function"""
    # Implementation
    return vectors

results = table.search(
    custom_embed(["query text"])[0]
).limit(5).to_pandas()
```

## 7. Advanced Search Features

### Multi-Vector Search
```python
# Search across multiple vector columns
results = table.search(query)
                .vector(query_vector_1, column="vector1")
                .vector(query_vector_2, column="vector2")
                .limit(5)
                .to_pandas()
```

### Context-Aware Search
```python
from lancedb.context import contextualize

# Add context to search
contextualized_results = contextualize(
    table.search(query).to_pandas(),
    window_size=2
)
```

## 8. Practice Exercise

Implement a semantic search system:

```python
import lancedb
from lancedb.embeddings import get_registry
from lancedb.pydantic import LanceModel, Vector

class SearchSystem:
    def __init__(self, db_path: str):
        self.db = lancedb.connect(db_path)
        self.embedder = get_registry().get("sentence-transformers").create()
        
        class Document(LanceModel):
            text: str = self.embedder.SourceField()
            vector: Vector(self.embedder.ndims()) = self.embedder.VectorField()
            category: str
        
        self.schema = Document
        
    def create_table(self, name: str, data: List[Dict]):
        return self.db.create_table(name, schema=self.schema, data=data)
    
    def search(self, query: str, category: Optional[str] = None, k: int = 5):
        search_query = self.table.search(query)
        if category:
            search_query = search_query.where(f"category = '{category}'")
        return search_query.limit(k).to_pandas()

# Implementation and testing
search_system = SearchSystem("~/.lancedb")
# Add test data and run searches
```

## 9. Best Practices

1. Index Configuration
   - Choose appropriate number of partitions
   - Optimize sub-vector count
   - Regular reindexing for dynamic data

2. Query Optimization
   - Use prefilters effectively
   - Batch similar queries
   - Monitor query latency

3. Result Quality
   - Choose appropriate distance metrics
   - Implement proper reranking
   - Validate search results

## 10. Key Takeaways

- Vector search enables similarity-based retrieval
- Distance metrics affect search quality
- Index configuration impacts performance
- Hybrid search combines multiple approaches
- Regular optimization maintains performance

## Next Lesson Preview

In the next lesson, we'll explore full-text search and hybrid search capabilities, including index creation, query optimization, and advanced search techniques.
