# Lesson 1: Database Fundamentals & Vector Databases

## 1. Introduction to Vector Databases

In today's data-driven world, traditional databases face challenges when dealing with unstructured data and semantic search requirements. Vector databases have emerged as a solution to handle complex data types by representing information as mathematical vectors in high-dimensional spaces.

## 2. Understanding Vector Embeddings

Vector embeddings are the foundation of vector databases. They are numerical representations that capture semantic meaning of data in a high-dimensional space. The basic concept is:

Raw Data → Embedding Model → Vector Representation

For example, the sentence "The quick brown fox" might be converted into a vector like [0.2, 0.5, -0.1, ...] with hundreds of dimensions. Similar items will have vectors that are close together in this space.

### Key Properties of Embeddings:
1. Fixed Dimensionality: Each vector has same number of dimensions
2. Semantic Proximity: Similar items have similar vectors
3. Mathematical Operations: Can perform distance calculations

## 3. LanceDB Architecture

LanceDB is built on a unique architecture that combines the strengths of vector databases with efficient disk-based storage. The key components are:

```plaintext
LanceDB/
├── Database Connection
│   ├── Local Storage
│   └── Cloud Storage (S3, GCS, Azure)
├── Tables
│   ├── Vector Data
│   ├── Metadata
│   └── Indices
└── Query Engine
    ├── Vector Search
    ├── Full-Text Search
    └── Hybrid Search
```

### Storage Architecture
LanceDB uses a columnar storage format based on Apache Arrow, providing several advantages:

1. Efficient Disk Usage: Data is stored in a compressed, column-oriented format
2. Zero-Copy Reading: Minimizes memory overhead during queries
3. Versioning Support: Each version contains only changed data

## 4. Basic Operations

Let's look at the fundamental operations in LanceDB:

```python
import lancedb

# Connect to database
db = lancedb.connect("~/.lancedb")

# Create table
data = [
    {"vector": [1.1, 1.2], "text": "hello world", "metadata": "doc1"},
    {"vector": [0.2, 1.8], "text": "goodbye world", "metadata": "doc2"}
]
table = db.create_table("my_first_table", data)

# Basic vector search
results = table.search([1.0, 1.0]).limit(2).to_pandas()
```

## 5. Storage Options

LanceDB supports multiple storage backends with different performance characteristics:

1. Local Storage
   - Fastest performance
   - Limited by disk space
   - Best for development

2. Cloud Storage (S3, GCS, Azure)
   - Scalable
   - Cost-effective
   - Higher latency

Example cloud configuration:
```python
# AWS S3
db = lancedb.connect(
    "s3://bucket/path",
    storage_options={
        "aws_access_key_id": "your_key",
        "aws_secret_access_key": "your_secret"
    }
)
```

## 6. Query Types

LanceDB supports three main types of queries:

1. Vector Search
```python
results = table.search([1.0, 1.0])
                     .limit(5)
                     .to_pandas()
```

2. Full-Text Search
```python
# Create FTS index first
table.create_fts_index("text")
results = table.search("hello", query_type="fts")
                     .limit(5)
                     .to_pandas()
```

3. Hybrid Search
```python
results = table.search("hello", query_type="hybrid")
                     .limit(5)
                     .to_pandas()
```

## 7. File Organization and Data Management

A typical LanceDB deployment might look like:
```plaintext
project/
├── data/
│   └── .lancedb/
│       ├── _latest/
│       ├── _transactions/
│       └── tables/
├── scripts/
│   ├── ingest.py
│   └── query.py
└── config/
    └── storage_config.json
```

## 8. Practice Exercise

Try this basic exercise to get started with LanceDB:

1. Create a database connection
2. Create a table with some sample text data and vectors
3. Perform a basic vector search
4. Add a full-text search index
5. Try a hybrid search query

```python
import lancedb
import numpy as np

# Your solution here
db = lancedb.connect("~/.lancedb")

# Create sample data
data = [
    {"vector": np.random.rand(128), "text": "Machine learning basics"},
    {"vector": np.random.rand(128), "text": "Deep learning tutorial"},
    {"vector": np.random.rand(128), "text": "Neural networks guide"}
]

# Create table and try operations
# ... (implement the remaining steps)
```

## 9. Key Takeaways

- Vector databases excel at semantic search and similarity matching
- LanceDB combines vector search with efficient disk-based storage
- Multiple storage options support different use cases
- Built-in support for vector, full-text, and hybrid search
- Apache Arrow foundation provides efficient data handling

## Next Lesson Preview
In the next lesson, we'll dive deeper into LanceDB's architecture and core components, exploring how the system manages data at scale and handles different types of queries efficiently.
