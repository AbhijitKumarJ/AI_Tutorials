# Lesson 5: Advanced Graph Structures in LangGraph

## Introduction

Welcome to Lesson 5 of our LangGraph series! In this lesson, we'll dive deep into advanced graph structures that will allow you to create more complex and powerful AI applications. We'll cover conditional edges, the use of START and END nodes, creating complex workflows with multiple paths, implementing loops and recursive structures, and best practices for designing graph structures.

By the end of this lesson, you'll have a solid understanding of how to create sophisticated graph-based workflows that can handle a wide variety of AI tasks and scenarios.

## Table of Contents

1. Conditional Edges
2. Using START and END Nodes
3. Creating Complex Workflows with Multiple Paths
4. Implementing Loops and Recursive Structures
5. Best Practices for Designing Graph Structures
6. Practical Exercise
7. Conclusion and Next Steps

Let's begin by exploring conditional edges, a powerful feature that allows your graphs to make decisions based on the state of your application.

## 1. Conditional Edges

Conditional edges are a crucial feature in LangGraph that allow you to create dynamic, adaptive workflows. Unlike simple edges that always connect two nodes, conditional edges use a function to determine which node(s) to execute next based on the current state of the graph.

### How Conditional Edges Work

When you add a conditional edge to your graph, you provide a routing function that takes the current state as input and returns the name of the next node(s) to execute. This allows your graph to make decisions at runtime, creating more flexible and powerful workflows.

Here's an example of how to implement a conditional edge:

```python
from langgraph.graph import StateGraph, END

def route_based_on_sentiment(state):
    sentiment = state['sentiment']
    if sentiment > 0.5:
        return "positive_response"
    elif sentiment < -0.5:
        return "negative_response"
    else:
        return "neutral_response"

graph = StateGraph()

# Add nodes (assuming these functions are defined elsewhere)
graph.add_node("analyze_sentiment", analyze_sentiment)
graph.add_node("positive_response", handle_positive)
graph.add_node("negative_response", handle_negative)
graph.add_node("neutral_response", handle_neutral)

# Add conditional edge
graph.add_conditional_edges(
    "analyze_sentiment",
    route_based_on_sentiment,
    {
        "positive_response": "positive_response",
        "negative_response": "negative_response",
        "neutral_response": "neutral_response"
    }
)

# Add edges from response nodes to END
graph.add_edge("positive_response", END)
graph.add_edge("negative_response", END)
graph.add_edge("neutral_response", END)
```

In this example, the `route_based_on_sentiment` function analyzes the sentiment in the current state and decides which response node to execute next. This allows the graph to adapt its behavior based on the sentiment of the input.

### Advanced Conditional Routing

You can create even more complex routing logic by returning multiple node names or using nested conditions. Here's an example of a more advanced routing function:

```python
def complex_routing(state):
    user_type = state['user_type']
    query_complexity = state['query_complexity']
    
    if user_type == 'premium':
        if query_complexity > 0.8:
            return ["advanced_processing", "premium_response"]
        else:
            return "premium_response"
    elif query_complexity > 0.6:
        return "advanced_processing"
    else:
        return "standard_processing"
```

This routing function takes into account both the user type and the complexity of the query, allowing for more nuanced decision-making in your graph.

## 2. Using START and END Nodes

START and END nodes are special nodes in LangGraph that help define the entry and exit points of your graph. Understanding how to use these effectively is crucial for creating well-structured graphs.

### The START Node

The START node represents the beginning of your graph's execution. It's not a node you define explicitly, but rather a constant provided by LangGraph. You use it to specify which node(s) should be executed first when your graph runs.

Here's how you typically use the START node:

```python
from langgraph.graph import StateGraph, START

graph = StateGraph()

# Add your initial node
graph.add_node("initial_processing", initial_processing_function)

# Set the entry point of your graph
graph.add_edge(START, "initial_processing")
```

You can also use conditional logic with the START node:

```python
def initial_routing(state):
    if state['is_returning_user']:
        return "welcome_back"
    else:
        return "new_user_onboarding"

graph.add_conditional_edges(
    START,
    initial_routing,
    {
        "welcome_back": "welcome_back",
        "new_user_onboarding": "new_user_onboarding"
    }
)
```

This allows you to have different starting points based on the initial state of your application.

### The END Node

The END node represents the termination of your graph's execution. Like START, it's a constant provided by LangGraph. You use it to specify when your graph should stop executing.

Here's a simple example of using the END node:

```python
from langgraph.graph import StateGraph, END

graph = StateGraph()

# Add your final node
graph.add_node("final_processing", final_processing_function)

# Set the exit point of your graph
graph.add_edge("final_processing", END)
```

You can also use conditional logic to determine when to end the graph:

```python
def check_completion(state):
    if state['task_completed']:
        return END
    else:
        return "continue_processing"

graph.add_conditional_edges(
    "check_status",
    check_completion,
    {
        END: END,
        "continue_processing": "continue_processing"
    }
)
```

This allows your graph to decide dynamically when to terminate based on the current state.

## 3. Creating Complex Workflows with Multiple Paths

Now that we understand conditional edges and START/END nodes, we can create more complex workflows with multiple paths. These workflows can represent sophisticated decision-making processes or multi-step tasks with various possible routes.

Let's create an example of a customer support workflow:

```python
from langgraph.graph import StateGraph, START, END

def route_query(state):
    query_type = state['query_type']
    if query_type == 'billing':
        return "billing_department"
    elif query_type == 'technical':
        return "technical_support"
    else:
        return "general_inquiry"

def check_resolution(state):
    if state['issue_resolved']:
        return "satisfaction_survey"
    else:
        return "escalate_to_human"

graph = StateGraph()

# Add nodes
graph.add_node("classify_query", classify_query_function)
graph.add_node("billing_department", handle_billing_query)
graph.add_node("technical_support", handle_technical_query)
graph.add_node("general_inquiry", handle_general_inquiry)
graph.add_node("check_resolution", check_resolution_function)
graph.add_node("satisfaction_survey", conduct_survey)
graph.add_node("escalate_to_human", escalate_to_human_agent)

# Add edges
graph.add_edge(START, "classify_query")

graph.add_conditional_edges(
    "classify_query",
    route_query,
    {
        "billing_department": "billing_department",
        "technical_support": "technical_support",
        "general_inquiry": "general_inquiry"
    }
)

graph.add_edge("billing_department", "check_resolution")
graph.add_edge("technical_support", "check_resolution")
graph.add_edge("general_inquiry", "check_resolution")

graph.add_conditional_edges(
    "check_resolution",
    check_resolution,
    {
        "satisfaction_survey": "satisfaction_survey",
        "escalate_to_human": "escalate_to_human"
    }
)

graph.add_edge("satisfaction_survey", END)
graph.add_edge("escalate_to_human", END)
```

This workflow demonstrates how you can create a complex customer support system with multiple paths based on the type of query and whether the issue was resolved. It shows how conditional edges can be used to route the workflow based on the state at various points in the process.

## 4. Implementing Loops and Recursive Structures

Loops and recursive structures are powerful tools in graph-based workflows, allowing you to repeat certain processes until a condition is met. In LangGraph, you can implement these using conditional edges that point back to earlier nodes in the graph.

### Implementing a Loop

Let's implement a loop that processes a list of items:

```python
from langgraph.graph import StateGraph, START, END

def process_item(state):
    items = state['items']
    if items:
        current_item = items.pop(0)
        # Process the item...
        state['processed_items'].append(current_item)
    return state

def check_more_items(state):
    if state['items']:
        return "process_item"
    else:
        return END

graph = StateGraph()

graph.add_node("process_item", process_item)

graph.add_edge(START, "process_item")

graph.add_conditional_edges(
    "process_item",
    check_more_items,
    {
        "process_item": "process_item",
        END: END
    }
)
```

In this example, the graph processes items from a list one by one. After each item is processed, it checks if there are more items. If there are, it loops back to process the next item. If not, it ends the graph.

### Implementing a Recursive Structure

Recursive structures can be implemented similarly, but they often involve more complex state management. Here's an example of a graph that recursively processes a tree structure:

```python
from langgraph.graph import StateGraph, START, END

def process_node(state):
    current_node = state['current_node']
    # Process the current node...
    state['processed_nodes'].append(current_node)
    if current_node.children:
        state['node_stack'].extend(current_node.children)
    return state

def check_more_nodes(state):
    if state['node_stack']:
        state['current_node'] = state['node_stack'].pop()
        return "process_node"
    else:
        return END

graph = StateGraph()

graph.add_node("process_node", process_node)

graph.add_edge(START, "process_node")

graph.add_conditional_edges(
    "process_node",
    check_more_nodes,
    {
        "process_node": "process_node",
        END: END
    }
)
```

This graph recursively processes a tree structure by maintaining a stack of nodes to process. It continues processing nodes until the stack is empty.

## 5. Best Practices for Designing Graph Structures

When designing complex graph structures, it's important to follow best practices to ensure your graphs are efficient, maintainable, and easy to understand. Here are some key guidelines:

1. **Modularity**: Break your graph into logical, reusable components. This makes it easier to understand, test, and maintain your code.

2. **Clear Node Naming**: Use descriptive names for your nodes that clearly indicate their purpose. This makes your graph easier to read and debug.

3. **State Management**: Be careful with how you manage state in your graph. Ensure that each node only modifies the parts of the state it needs to, and consider using immutable data structures to prevent unexpected side effects.

4. **Error Handling**: Implement proper error handling in your nodes and routing functions. Consider adding specific nodes for error handling and recovery.

5. **Documentation**: Document your graph structure, including the purpose of each node and the expected input/output state. This is especially important for complex graphs.

6. **Testing**: Create unit tests for individual nodes and integration tests for the entire graph. This helps ensure your graph behaves correctly under various conditions.

7. **Performance Considerations**: For large graphs, be mindful of performance. Avoid unnecessary computation in routing functions and consider optimizing frequently executed nodes.

8. **Versioning**: If your graph structure might change over time, consider implementing a versioning system to manage different versions of your graph.

Here's an example of how you might structure a more complex graph following these best practices:

```python
from langgraph.graph import StateGraph, START, END

# Define node functions (implementation details omitted for brevity)
def preprocess_input(state):
    # Preprocess the input...
    pass

def analyze_intent(state):
    # Analyze the user's intent...
    pass

def handle_greeting(state):
    # Handle a greeting intent...
    pass

def handle_question(state):
    # Handle a question intent...
    pass

def handle_command(state):
    # Handle a command intent...
    pass

def postprocess_output(state):
    # Postprocess the output...
    pass

def handle_error(state):
    # Handle any errors that occurred...
    pass

# Define routing functions
def route_by_intent(state):
    intent = state['intent']
    if intent == 'greeting':
        return "handle_greeting"
    elif intent == 'question':
        return "handle_question"
    elif intent == 'command':
        return "handle_command"
    else:
        return "handle_error"

def check_for_errors(state):
    if state['error']:
        return "handle_error"
    else:
        return "postprocess_output"

# Create the graph
graph = StateGraph()

# Add nodes
graph.add_node("preprocess_input", preprocess_input)
graph.add_node("analyze_intent", analyze_intent)
graph.add_node("handle_greeting", handle_greeting)
graph.add_node("handle_question", handle_question)
graph.add_node("handle_command", handle_command)
graph.add_node("postprocess_output", postprocess_output)
graph.add_node("handle_error", handle_error)

# Add edges
graph.add_edge(START, "preprocess_input")
graph.add_edge("preprocess_input", "analyze_intent")

graph.add_conditional_edges(
    "analyze_intent",
    route_by_intent,
    {
        "handle_greeting": "handle_greeting",
        "handle_question": "handle_question",
        "handle_command": "handle_command",
        "handle_error": "handle_error"
    }
)

graph.add_conditional_edges(
    "handle_greeting",
    check_for_errors,
    {
        "postprocess_output": "postprocess_output",
        "handle_error": "handle_error"
    }
)

graph.add_conditional_edges(
    "handle_question",
    check_for_errors,
    {
        "postprocess_output": "postprocess_output",
        "handle_error": "handle_error"
    }
)

graph.add_conditional_edges(
    "handle_command",
    check_for_errors,
    {
        "postprocess_output": "postprocess_output",
        "handle_error": "handle_error"
    }
)

graph.add_edge("postprocess_output", END)
graph.add_edge("handle_error", END)

# Compile the graph
compiled_graph = graph.compile()
```

This example demonstrates a more complex graph structure that follows the best practices we discussed. It includes clear node naming, modular design, error handling, and uses conditional edges to create a flexible workflow.

## 6. Practical Exercise

Now that we've covered the theory and examples of advanced graph structures, let's put it all together with a practical exercise. We'll create a graph that simulates a simple AI assistant that can handle multiple types of requests and has a conversation loop.

```python
from langgraph.graph import StateGraph, START, END
from typing import TypedDict, Annotated
from langgraph.graph.message import add_messages

# Define our state
class State(TypedDict):
    messages: Annotated[list, add_messages]
    conversation_stage: str
    
# Define node functions

def initialize_conversation(state: State):
    state['conversation_stage'] = 'greeting'
    return state

def generate_response(state: State):
    last_message = state['messages'][-1]
    stage = state['conversation_stage']
    
    if stage == 'greeting':
        response = "Hello! How can I assist you today?"
        state['conversation_stage'] = 'awaiting_request'
    elif stage == 'awaiting_request':
        response = "I understand you need help. Could you please provide more details about your request?"
        state['conversation_stage'] = 'processing_request'
    elif stage == 'processing_request':
        response = "I'm processing your request. Is there anything else you'd like to add?"
        state['conversation_stage'] = 'follow_up'
    else:
        response = "Thank you for using our AI assistant. Is there anything else I can help you with?"
        state['conversation_stage'] = 'awaiting_request'
    
    state['messages'].append(("ai", response))
    return state

def analyze_user_input(state: State):
    last_message = state['messages'][-1]
    if "goodbye" in last_message[1].lower() or "thank you" in last_message[1].lower():
        state['conversation_stage'] = 'ending'
    return state

def should_continue(state: State):
    if state['conversation_stage'] == 'ending':
        return END
    else:
        return "generate_response"

# Create the graph
graph = StateGraph(State)

# Add nodes
graph.add_node("initialize", initialize_conversation)
graph.add_node("generate_response", generate_response)
graph.add_node("analyze_input", analyze_user_input)

# Add edges
graph.add_edge(START, "initialize")
graph.add_edge("initialize", "generate_response")
graph.add_edge("generate_response", "analyze_input")

# Add conditional edge
graph.add_conditional_edges(
    "analyze_input",
    should_continue,
    {
        "generate_response": "generate_response",
        END: END
    }
)

# Compile the graph
compiled_graph = graph.compile()

# Example usage
initial_state = State(messages=[], conversation_stage='')
for output in compiled_graph.stream(initial_state):
    if 'messages' in output:
        last_message = output['messages'][-1]
        if last_message[0] == 'ai':
            print("AI:", last_message[1])
            user_input = input("Human: ")
            output['messages'].append(("human", user_input))

print("Conversation ended.")
```

This practical exercise demonstrates several advanced concepts we've discussed:

1. **Complex State Management**: We use a TypedDict to define our state, which includes both the conversation messages and a conversation stage.

2. **Conditional Routing**: The `should_continue` function acts as a conditional router, deciding whether to continue the conversation or end it based on the current state.

3. **Looping Structure**: The graph implements a conversation loop, continuously generating responses and analyzing user input until the conversation is ended.

4. **Modular Design**: Each node in the graph has a specific responsibility (initializing, generating responses, analyzing input), making the code more maintainable and easier to understand.

5. **Use of START and END Nodes**: We explicitly define the start of our graph with the initialize node, and use the END node to terminate the conversation when appropriate.

This exercise provides a practical example of how advanced graph structures can be used to create a flexible, stateful conversation flow in an AI assistant. It showcases how LangGraph can be used to manage complex interactions that go beyond simple query-response patterns.

In a real-world scenario, you would likely expand this graph to include more sophisticated natural language processing, integration with external knowledge bases or APIs, and more nuanced conversation management. However, this example serves as a solid foundation for understanding how to structure more complex applications using LangGraph.


 # Conclusion and Next Steps

Congratulations on completing Lesson 5: Advanced Graph Structures in LangGraph! Let's recap the key points we've covered and discuss some next steps for your learning journey.

## Key Takeaways

1. **Conditional Edges**: We learned that conditional edges are a powerful feature in LangGraph that allow for dynamic, adaptive workflows. They use routing functions to determine the next node(s) to execute based on the current state of the graph. This enables the creation of flexible and intelligent graph structures that can make decisions at runtime.

2. **START and END Nodes**: We explored the use of special START and END nodes in LangGraph. The START node defines the entry point of your graph, while the END node represents the termination point. These nodes are crucial for defining the overall flow of your graph and can be used with conditional logic to create dynamic starting and ending points.

3. **Complex Workflows**: We delved into creating complex workflows with multiple paths. This involved combining conditional edges, START/END nodes, and various processing nodes to create sophisticated decision-making processes. We saw how these complex structures can represent real-world scenarios like customer support systems.

4. **Loops and Recursive Structures**: We learned how to implement loops and recursive structures in LangGraph. These are essential for handling repetitive tasks or processing hierarchical data structures. We saw examples of how to use conditional edges to create loops and how to manage state for recursive processing.

5. **Best Practices**: We discussed several best practices for designing graph structures, including:
   - Modularity: Breaking graphs into logical, reusable components.
   - Clear naming conventions: Using descriptive names for nodes and functions.
   - Careful state management: Ensuring each node only modifies necessary state.
   - Error handling: Implementing proper error handling and recovery mechanisms.
   - Documentation: Clearly documenting the purpose and behavior of graph components.
   - Testing: Creating unit tests for nodes and integration tests for the entire graph.
   - Performance considerations: Optimizing for efficiency in large graphs.
   - Versioning: Implementing version control for evolving graph structures.

6. **Practical Application**: Through our practical exercise, we saw how these concepts come together to create a functional AI assistant. This demonstrated the power of LangGraph in managing complex, stateful interactions and showcased how advanced graph structures can be applied to real-world problems.

## Next Steps

Now that you have a solid understanding of advanced graph structures in LangGraph, here are some suggested next steps to further your learning:

1. **Practice, Practice, Practice**: The best way to solidify your understanding is through practice. Try modifying the practical exercise we worked on to add new features or handle different types of conversations.

2. **Explore Real-World Applications**: Look for opportunities to apply LangGraph in your own projects. Consider how you might use these advanced graph structures to solve complex problems in areas like natural language processing, task automation, or decision-making systems.

3. **Dive Deeper into State Management**: As graphs become more complex, effective state management becomes crucial. Explore different strategies for managing state in large graphs, including the use of custom channel types and reducers.

4. **Learn About Integration**: In the next lesson, we'll be exploring how to integrate language models into your LangGraph applications. Start thinking about how you might combine the advanced graph structures you've learned with powerful language models.

5. **Study Open-Source Projects**: Look for open-source projects that use LangGraph and study their graph structures. This can provide valuable insights into how experienced developers are using these concepts in production environments.

6. **Experiment with Visualization**: Try using graph visualization tools to represent your LangGraph structures visually. This can be incredibly helpful for understanding and debugging complex graphs.

7. **Join the Community**: Engage with the LangGraph and LangChain communities. Share your projects, ask questions, and learn from others who are working with these technologies.

Remember, mastering advanced graph structures takes time and practice. Don't be discouraged if some concepts feel challenging at first. Keep experimenting, asking questions, and building projects, and you'll continue to improve your skills with LangGraph.

In the next lesson, we'll be diving into the exciting world of integrating language models with LangGraph. This will open up even more possibilities for creating sophisticated AI applications. Get ready to take your LangGraph skills to the next level!

