# Lesson 6: Working with State and Channels in LangGraph

## Introduction

Welcome to Lesson 6 of our LangGraph series! In this lesson, we'll dive deep into state management and channels, two crucial concepts for building complex and efficient AI applications with LangGraph. Understanding these concepts will allow you to create more sophisticated graph structures and handle data flow more effectively within your applications.

By the end of this lesson, you'll have a solid grasp of how to manage state in LangGraph, work with different types of channels, implement custom reducers, and handle complex state transitions. This knowledge will be instrumental in creating robust and flexible AI applications.

## Table of Contents

1. Deep Dive into State Management
2. Understanding and Using Different Channel Types
3. Best Practices for State Handling
4. Implementing Custom Reducers for State Updates
5. Handling Complex State Transitions
6. Practical Exercise
7. Conclusion and Next Steps

Let's begin by exploring state management in LangGraph.

## 1. Deep Dive into State Management

State management is a fundamental concept in LangGraph that allows your graph to maintain and update information as it processes data. The state represents the current condition of your application and can include various types of data, from simple variables to complex data structures.

### The Concept of State in LangGraph

In LangGraph, the state is typically defined as a TypedDict, which is a way to specify the structure of your state with type hints. This helps ensure type safety and makes your code more readable and maintainable. Here's an example of how you might define a state for a chatbot application:

```python
from typing import TypedDict, List, Annotated
from langgraph.graph.message import add_messages

class ChatbotState(TypedDict):
    messages: Annotated[List[dict], add_messages]
    user_info: dict
    conversation_stage: str
    sentiment_score: float
```

In this example, our state includes:
- A list of messages (using the `add_messages` annotation for proper handling)
- User information
- The current stage of the conversation
- A sentiment score

### Accessing and Updating State

Each node in your LangGraph receives the current state as an input and can return an updated state. Here's an example of how a node might access and update the state:

```python
def analyze_sentiment(state: ChatbotState) -> ChatbotState:
    last_message = state['messages'][-1]
    # Assume we have a sentiment analysis function
    sentiment = analyze_sentiment_of_text(last_message['content'])
    
    # Update the state
    state['sentiment_score'] = sentiment
    
    return state
```

This function analyzes the sentiment of the last message and updates the sentiment score in the state.

### State Immutability and Side Effects

It's important to note that while the above example directly modifies the state, in many cases it's better to treat the state as immutable and return a new state object. This can help prevent unexpected side effects and make your code easier to reason about. Here's how you might rewrite the above function with immutability in mind:

```python
def analyze_sentiment(state: ChatbotState) -> ChatbotState:
    last_message = state['messages'][-1]
    sentiment = analyze_sentiment_of_text(last_message['content'])
    
    # Create a new state object
    return {
        **state,
        'sentiment_score': sentiment
    }
```

This approach creates a new state object with the updated sentiment score, leaving the original state unchanged.

## 2. Understanding and Using Different Channel Types

Channels in LangGraph are a way to manage how data flows through your graph and how state updates are handled. LangGraph provides several types of channels, each with its own behavior and use cases.

### Topic Channel

The Topic channel is the default channel type in LangGraph. It allows multiple subscribers to receive all updates to a particular key in the state.

```python
from langgraph.channels import Topic

class MyState(TypedDict):
    messages: Annotated[List[dict], Topic]
```

In this example, any node that updates the 'messages' key will broadcast that update to all other nodes that are subscribed to this channel.

### LastValue Channel

The LastValue channel only keeps the most recent value. This is useful when you only care about the current state and not the history of changes.

```python
from langgraph.channels import LastValue

class MyState(TypedDict):
    current_user: Annotated[str, LastValue]
```

Here, only the most recent value of 'current_user' is maintained in the state.

### EphemeralValue Channel

The EphemeralValue channel is similar to LastValue, but it resets to the default value after being read. This is useful for temporary data that should be cleared after use.

```python
from langgraph.channels import EphemeralValue

class MyState(TypedDict):
    error_message: Annotated[str, EphemeralValue]
```

In this case, 'error_message' will be cleared after it's read by a node.

### BinaryOperatorAggregate Channel

This channel type allows you to specify a binary operator to aggregate values. This is useful for performing operations like summing or finding the maximum value.

```python
from langgraph.channels import BinaryOperatorAggregate
from operator import add

class MyState(TypedDict):
    total_score: Annotated[int, BinaryOperatorAggregate(add)]
```

Here, 'total_score' will be updated by adding new values to the existing value.

### AnyValue Channel

The AnyValue channel allows any type of value to be stored and doesn't perform any specific aggregation.

```python
from langgraph.channels import AnyValue

class MyState(TypedDict):
    misc_data: Annotated[Any, AnyValue]
```

This channel is useful when you need flexibility in the type of data stored.

## 3. Best Practices for State Handling

When working with state in LangGraph, it's important to follow some best practices to ensure your application is efficient, maintainable, and scalable. Here are some key guidelines:

1. **Use Appropriate Channel Types**: Choose the right channel type for each piece of state based on how you need to access and update it. This can significantly improve the efficiency of your graph.

2. **Keep State Minimal**: Only include in your state what is necessary for your graph's operation. Excessive state can lead to performance issues and make your graph harder to reason about.

3. **Use Immutable Updates**: Whenever possible, create new state objects rather than modifying existing ones. This can help prevent bugs caused by unexpected state mutations.

4. **Type Your State**: Always use type hints for your state. This improves code readability and helps catch errors early.

5. **Handle Errors Gracefully**: Implement error handling in your state updates to ensure your graph can recover from unexpected issues.

6. **Document Your State**: Clearly document what each piece of state represents and how it should be used. This is especially important for complex state structures.

7. **Use Meaningful Names**: Choose clear and descriptive names for your state keys. This makes your code more self-documenting and easier to understand.

Here's an example that demonstrates some of these best practices:

```python
from typing import TypedDict, List, Annotated
from langgraph.channels import Topic, LastValue

class UserState(TypedDict):
    """
    Represents the current state of a user in the system.
    
    Attributes:
        name (str): The user's name. Only the last value is stored.
        messages (List[dict]): The user's message history. All messages are stored.
        is_active (bool): Whether the user is currently active. Only the last value is stored.
    """
    name: Annotated[str, LastValue]
    messages: Annotated[List[dict], Topic]
    is_active: Annotated[bool, LastValue]

def update_user_activity(state: UserState) -> UserState:
    """
    Updates the user's activity status based on their recent messages.
    
    Args:
        state (UserState): The current user state.
    
    Returns:
        UserState: A new state object with the updated activity status.
    """
    try:
        is_active = len(state['messages']) > 0 and (time.time() - state['messages'][-1]['timestamp'] < 300)
        return {**state, 'is_active': is_active}
    except KeyError as e:
        print(f"Error updating user activity: {e}")
        return state
```

This example demonstrates type hinting, appropriate channel usage, immutable updates, error handling, and clear documentation.

## 4. Implementing Custom Reducers for State Updates

While the built-in channel types cover many common use cases, you may sometimes need more complex behavior for state updates. In these cases, you can implement custom reducers.

A reducer is a function that takes the current state and an update, and returns the new state. Here's an example of a custom reducer that maintains a moving average:

```python
from typing import TypedDict, Annotated, List

def moving_average_reducer(current: List[float], update: float) -> List[float]:
    if len(current) < 5:
        return current + [update]
    else:
        return current[1:] + [update]

class AnalyticsState(TypedDict):
    response_times: Annotated[List[float], moving_average_reducer]

# Usage
def log_response_time(state: AnalyticsState, response_time: float) -> AnalyticsState:
    return {
        **state,
        'response_times': response_time  # The reducer will handle maintaining the moving average
    }
```

In this example, the `moving_average_reducer` maintains a list of the last 5 response times. When a new response time is added, it removes the oldest one if the list is already at capacity.

## 5. Handling Complex State Transitions

As your LangGraph applications become more complex, you may need to handle more sophisticated state transitions. These might involve multiple state changes based on complex conditions. Here's an example of how you might handle a complex state transition in a customer support chatbot:

```python
from typing import TypedDict, Annotated, List
from langgraph.channels import Topic, LastValue

class SupportState(TypedDict):
    messages: Annotated[List[dict], Topic]
    customer_sentiment: Annotated[float, LastValue]
    issue_resolved: Annotated[bool, LastValue]
    escalation_level: Annotated[int, LastValue]

def handle_customer_response(state: SupportState) -> SupportState:
    last_message = state['messages'][-1]
    sentiment = analyze_sentiment(last_message['content'])
    
    new_state = {
        **state,
        'customer_sentiment': sentiment,
    }
    
    if "issue resolved" in last_message['content'].lower():
        new_state['issue_resolved'] = True
    elif sentiment < -0.5 and new_state['escalation_level'] < 2:
        new_state['escalation_level'] = state['escalation_level'] + 1
    
    return new_state

def analyze_sentiment(text: str) -> float:
    # Implement sentiment analysis here
    pass
```

In this example, we're handling a complex state transition that involves updating the customer sentiment, checking for issue resolution, and potentially escalating the issue based on the sentiment. This demonstrates how you can combine multiple state updates and conditional logic to handle complex scenarios.

## 6. Practical Exercise

Now, let's put all of these concepts together in a practical exercise. We'll create a simple task management system using LangGraph, incorporating various channel types and complex state handling.

```python
from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, END
from langgraph.channels import Topic, LastValue, BinaryOperatorAggregate
from operator import add

class TaskState(TypedDict):
    tasks: Annotated[List[dict], Topic]
    current_task: Annotated[dict, LastValue]
    total_completed: Annotated[int, BinaryOperatorAggregate(add)]
    user_productivity: Annotated[float, LastValue]

def add_task(state: TaskState, task: dict) -> TaskState:
    return {
        **state,
        'tasks': task
    }

def start_task(state: TaskState) -> TaskState:
    if state['tasks']:
        return {
            **state,
            'current_task': state['tasks'][0],
            'tasks': state['tasks'][1:]
        }
    return state

def complete_task(state: TaskState) -> TaskState:
    if state['current_task']:
        return {
            **state,
            'current_task': {},
            'total_completed': 1,
            'user_productivity': calculate_productivity(state)
        }
    return state

def calculate_productivity(state: TaskState) -> float:
    # Simple productivity calculation
    return state['total_completed'] / (len(state['tasks']) + state['total_completed'] + 1)

def should_continue(state: TaskState):
    if state['tasks'] or state['current_task']:
        return 'start_task'
    return END

# Create the graph
graph = StateGraph(TaskState)

# Add nodes
graph.add_node('add_task', add_task)
graph.add_node('start_task', start_task)
graph.add_node('complete_task', complete_task)

# Add edges
graph.add_edge('add_task', 'start_task')
graph.add_edge('start_task', 'complete_task')

# Add conditional edge
graph.add_conditional_edges(
    'complete_task',
    should_continue,
    {
        'start_task': 'start_task',
        END: END
    }
)

# Compile the graph
compiled_graph = graph.compile()

# Example usage
initial_state = TaskState(tasks=[], current_task={}, total_completed=0, user_productivity=0.0)
tasks_to_add = [
    {'id': 1, 'description': 'Write report'},
    {'id': 2, 'description': 'Review code'},
    {'id': 3, 'description': 'Plan meeting'}
]

for task in tasks_to_add:
    initial_state = add_task(initial_state, task)

for output in compiled_graph.stream(initial_state):
    print(output)

print(f"Final productivity: {output['user_productivity']}")
```

This exercise demonstrates:
- Use of different channel types (Topic, LastValue, BinaryOperatorAggregate)
- Complex state handling with multiple updates
- A loop structure using conditional edges
- Calculation of derived state (productivity)

## Conclusion and Next Steps

In this lesson, we've explored the intricate world of state management and channels in LangGraph. We've covered:

1. The fundamental concept of state in LangGraph and how to define it using TypedDict.
2. Various channel types (Topic, LastValue, EphemeralValue, BinaryOperatorAggregate, AnyValue) and their use cases.
3. Best practices for state handling, including immutability, error handling, and documentation.
4. How to implement custom reducers for more complex state update behavior.
5. Techniques for handling complex state transitions involving multiple updates and conditions.
6. A practical exercise demonstrating these concepts in a task management system.

Understanding these concepts is crucial for building sophisticated AI applications with LangGraph. As you continue your journey, here are some next steps to consider:

1. **Experiment with Different Channel Types**: Try building applications that use various combinations of channel types to see how they affect your graph's behavior.

2. **Implement Complex State Transitions**: Practice creating graphs with more complex state transitions, perhaps involving multiple conditions and update paths.

3. **Explore Error Handling**: Dive deeper into error handling in state updates. How can you make your graph more resilient to unexpected state conditions?

4. **Optimize Performance**: As your graphs become more complex, consider how different state management strategies might affect performance. Experiment with different approaches and measure their impact.

5. **Integrate with External Systems**: Try building a LangGraph application that integrates with external systems, managing state that includes data from APIs or databases.

6. **Implement Undo/Redo Functionality**: As a challenge, try implementing undo/redo functionality in a




# Conclusion and Next Steps

Congratulations on completing Lesson 6: Working with State and Channels in LangGraph! Let's recap the key points we've covered and discuss some next steps for your learning journey.

## Key Takeaways

1. **State Management**: We learned that state in LangGraph represents the current condition of your application. It's typically defined using TypedDict and can include various types of data. Proper state management is crucial for creating complex and efficient AI applications.

2. **Channel Types**: We explored different channel types in LangGraph, including Topic, LastValue, EphemeralValue, BinaryOperatorAggregate, and AnyValue. Each of these channel types has its own behavior and use cases, allowing for flexible and efficient data flow management in your graphs.

3. **Best Practices for State Handling**: We discussed several best practices, including using appropriate channel types, keeping state minimal, using immutable updates, typing your state, handling errors gracefully, documenting your state, and using meaningful names. These practices help in creating maintainable and scalable LangGraph applications.

4. **Custom Reducers**: We learned how to implement custom reducers for more complex state update behavior. This allows for sophisticated state management tailored to specific application needs.

5. **Complex State Transitions**: We explored techniques for handling complex state transitions involving multiple updates and conditions. This is crucial for creating advanced AI applications with intricate workflows.

6. **Practical Application**: Through our practical exercise of creating a task management system, we saw how these concepts come together in a real-world scenario. This demonstrated the power of LangGraph in managing complex state and workflows.

## Next Steps

As you continue your journey with LangGraph, here are some suggested next steps to further your learning:

1. **Experiment with Different State Structures**: Try creating LangGraph applications with various state structures. Experiment with different combinations of channel types and see how they affect your application's behavior and performance.

2. **Implement Advanced State Management**: Challenge yourself to create graphs with more complex state management requirements. This could involve implementing undo/redo functionality, managing shared state across multiple sub-graphs, or creating a state caching mechanism.

3. **Optimize Performance**: As your graphs become more complex, look into ways to optimize state management for better performance. This might involve profiling your application, identifying bottlenecks, and refining your state structure and update mechanisms.

4. **Explore Error Handling**: Dive deeper into error handling in state updates. How can you make your graph more resilient to unexpected state conditions? Consider implementing advanced error recovery mechanisms.

5. **Integrate with External Systems**: Try building a LangGraph application that integrates with external systems, managing state that includes data from APIs or databases. This will give you practice in handling more complex and realistic scenarios.

6. **Implement Concurrency**: Explore how to handle concurrent state updates in LangGraph. This is an advanced topic but becomes important as applications scale.

7. **Create Visualization Tools**: As an extra challenge, try creating tools to visualize the state of your LangGraph applications over time. This can be incredibly helpful for debugging and understanding complex graphs.

8. **Contribute to the Community**: As you gain expertise, consider contributing to the LangGraph community. This could involve creating tutorials, sharing your projects, or even contributing to the LangGraph codebase.

Remember, mastering state and channel management in LangGraph takes practice. Don't be discouraged if some concepts feel challenging at first. Keep experimenting, asking questions, and building projects, and you'll continue to improve your skills.

In the next lesson, we'll be diving into the exciting world of integrating language models with LangGraph. This will open up even more possibilities for creating sophisticated AI applications. Get ready to take your LangGraph skills to the next level!

