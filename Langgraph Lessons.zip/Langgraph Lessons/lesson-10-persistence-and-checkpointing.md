# Lesson 10: Persistence and Checkpointing in LangGraph

## Introduction

In this lesson, we'll explore the critical concepts of persistence and checkpointing in LangGraph. These features are essential for creating robust, fault-tolerant applications that can handle long-running processes, recover from failures, and maintain state across multiple sessions. We'll dive deep into the implementation details, best practices, and advanced techniques for managing state in complex LangGraph applications.

## 1. Understanding the Need for Persistence

Persistence in the context of LangGraph refers to the ability to save and restore the state of a graph execution. This capability is crucial for several reasons:

1. Long-running processes: Many LangGraph applications, especially those involving complex workflows or large language models, can take a significant amount of time to complete. Persistence allows us to save intermediate states, enabling the application to resume from where it left off in case of interruptions.

2. Fault tolerance: In production environments, system failures, network issues, or other unexpected problems can occur. Persistence mechanisms allow applications to recover gracefully from these failures without losing progress.

3. Asynchronous workflows: Some applications may require human intervention or external processes that operate on different timescales. Persistence enables these workflows by allowing the graph execution to be paused and resumed as needed.

4. State analysis and debugging: Saving intermediate states can be invaluable for analyzing the behavior of your application, debugging issues, and optimizing performance.

5. Resource management: For resource-intensive applications, persistence allows for better management of computational resources by enabling the distribution of work across different time periods or machines.

## 2. Implementing Checkpointing in LangGraph

Checkpointing is the primary mechanism for implementing persistence in LangGraph. It involves saving the state of the graph at specific points during execution. LangGraph provides built-in support for checkpointing through its `Checkpointer` classes.

Let's explore how to implement checkpointing in a LangGraph application:

1. Choosing a Checkpointer:
LangGraph offers several checkpointer options:
   - `MemorySaver`: Stores checkpoints in memory (suitable for testing and small applications)
   - `SqliteSaver`: Stores checkpoints in a SQLite database
   - `PostgresSaver`: Stores checkpoints in a PostgreSQL database (suitable for production environments)

Here's an example of how to create and use a `SqliteSaver`:

```python
from langgraph.checkpoint.sqlite import SqliteSaver

checkpointer = SqliteSaver("my_app_checkpoints.db")
```

2. Integrating Checkpointing into Your Graph:
To enable checkpointing in your LangGraph application, you need to pass the checkpointer when compiling your graph:

```python
from langgraph.graph import StateGraph

# Define your graph
graph = StateGraph()
# ... (add nodes and edges)

# Compile the graph with checkpointing
compiled_graph = graph.compile(checkpointer=checkpointer)
```

3. Configuring Checkpoint Frequency:
You can control when checkpoints are created by specifying checkpoint conditions. For example, you might want to create a checkpoint after each major step in your workflow:

```python
def should_checkpoint(state):
    return state.get("major_step_completed", False)

compiled_graph = graph.compile(
    checkpointer=checkpointer,
    checkpoint_condition=should_checkpoint
)
```

4. Resuming from a Checkpoint:
To resume execution from a checkpoint, you need to provide the checkpoint ID when invoking the graph:

```python
checkpoint_id = "last_successful_checkpoint"
result = compiled_graph.invoke(input_data, config={"checkpoint_id": checkpoint_id})
```

## 3. Strategies for Efficient State Serialization

Efficient state serialization is crucial for performance, especially when dealing with large or complex states. Here are some strategies to optimize state serialization:

1. Use lightweight data structures: When designing your state, prefer simple data structures that are easy to serialize, such as dictionaries and lists.

2. Implement custom serialization methods: For complex objects, implement custom `__getstate__` and `__setstate__` methods to control exactly what gets serialized:

```python
class ComplexState:
    def __init__(self):
        self.important_data = {}
        self.cache = {}  # Large, regenerable cache

    def __getstate__(self):
        # Only serialize important_data
        return {"important_data": self.important_data}

    def __setstate__(self, state):
        self.__dict__.update(state)
        self.cache = {}  # Regenerate cache as needed
```

3. Use incremental updates: Instead of serializing the entire state each time, consider implementing a system for incremental updates:

```python
def update_state(old_state, new_data):
    # Only update changed fields
    for key, value in new_data.items():
        if old_state.get(key) != value:
            old_state[key] = value
    return old_state
```

4. Compress large data: For states with large text fields or binary data, consider using compression:

```python
import zlib

def compress_state(state):
    return {k: zlib.compress(v.encode()) if isinstance(v, str) else v for k, v in state.items()}

def decompress_state(compressed_state):
    return {k: zlib.decompress(v).decode() if isinstance(v, bytes) else v for k, v in compressed_state.items()}
```

5. Use efficient serialization formats: While JSON is human-readable, consider using more efficient formats like MessagePack or Protocol Buffers for large-scale applications.

## 4. Different Checkpointer Options

Let's dive deeper into the available checkpointer options in LangGraph:

1. MemorySaver:
   - Stores checkpoints in memory
   - Fastest option, but not persistent across application restarts
   - Suitable for testing and development
   - Usage:
     ```python
     from langgraph.checkpoint.memory import MemorySaver
     memory_saver = MemorySaver()
     ```

2. SqliteSaver:
   - Stores checkpoints in a SQLite database
   - Persistent storage, suitable for small to medium-sized applications
   - Easy to set up and use, no additional dependencies
   - Usage:
     ```python
     from langgraph.checkpoint.sqlite import SqliteSaver
     sqlite_saver = SqliteSaver("path/to/checkpoint.db")
     ```

3. PostgresSaver:
   - Stores checkpoints in a PostgreSQL database
   - Suitable for large-scale, production applications
   - Offers better concurrency and performance for high-load scenarios
   - Requires PostgreSQL to be installed and configured
   - Usage:
     ```python
     from langgraph.checkpoint.postgres import PostgresSaver
     postgres_saver = PostgresSaver(
         host="localhost",
         port=5432,
         user="user",
         password="password",
         database="checkpoints_db"
     )
     ```

When choosing a checkpointer, consider factors such as:
- Application scale and expected load
- Persistence requirements
- Deployment environment
- Performance needs
- Ease of maintenance and backup

## 5. Recovering from Failures Using Checkpoints

Implementing robust failure recovery is a critical aspect of using checkpoints effectively. Here's a strategy for recovering from failures:

1. Implement error handling in your graph nodes:

```python
def fallible_node(state):
    try:
        # Potentially failing operation
        result = perform_operation(state)
        return {"result": result, "status": "success"}
    except Exception as e:
        return {"error": str(e), "status": "failure"}

graph.add_node("fallible_operation", fallible_node)
```

2. Use conditional edges to handle failures:

```python
def handle_failure(state):
    if state["status"] == "failure":
        return "recovery_node"
    else:
        return "next_normal_node"

graph.add_conditional_edges("fallible_operation", handle_failure)
```

3. Implement a recovery node:

```python
def recovery_node(state):
    # Log the error
    log_error(state["error"])
    
    # Attempt to fix the issue or revert to a safe state
    fixed_state = attempt_fix(state)
    
    # Determine next step based on fix result
    if fixed_state["status"] == "fixed":
        return {"state": fixed_state, "next_node": "retry_operation"}
    else:
        return {"state": fixed_state, "next_node": "human_intervention"}

graph.add_node("recovery_node", recovery_node)
```

4. Use checkpoints to resume from the last safe state:

```python
def run_graph_with_recovery(input_data):
    while True:
        try:
            result = compiled_graph.invoke(input_data)
            return result
        except Exception as e:
            print(f"Encountered error: {e}")
            # Get the last successful checkpoint
            last_checkpoint = checkpointer.get_last_successful()
            if last_checkpoint:
                print(f"Resuming from checkpoint: {last_checkpoint.id}")
                input_data = last_checkpoint.state
            else:
                print("No valid checkpoint found. Starting from the beginning.")
                # Optionally, you might want to modify the input_data here
```

This approach allows your application to gracefully handle failures, attempt recovery, and resume execution from the last known good state.

## 6. Best Practices for Checkpointing

To make the most of checkpointing in your LangGraph applications, consider the following best practices:

1. Checkpoint frequency: Balance between performance and fault tolerance. Too frequent checkpoints can slow down your application, while too infrequent checkpoints risk losing significant progress in case of failure.

2. Checkpoint granularity: Consider creating checkpoints at logical boundaries in your workflow, such as after completing major steps or before starting resource-intensive operations.

3. Versioning: Implement a versioning system for your checkpoints to handle changes in your application's state structure over time.

```python
class VersionedState:
    def __init__(self, data, version):
        self.data = data
        self.version = version

    def upgrade(self):
        if self.version < CURRENT_VERSION:
            # Perform necessary upgrades
            pass
        return self

def create_checkpoint(state):
    return VersionedState(state, CURRENT_VERSION)

def load_checkpoint(versioned_state):
    return versioned_state.upgrade().data
```

4. Cleanup: Implement a cleanup strategy to prevent accumulation of old, unnecessary checkpoints:

```python
def cleanup_old_checkpoints(checkpointer, max_age=timedelta(days=7)):
    old_checkpoints = checkpointer.list_checkpoints(older_than=max_age)
    for checkpoint in old_checkpoints:
        checkpointer.delete_checkpoint(checkpoint.id)
```

5. Monitoring and logging: Implement comprehensive logging for checkpoint operations to aid in debugging and performance optimization:

```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def checkpoint_callback(checkpoint):
    logger.info(f"Created checkpoint: {checkpoint.id}")

compiled_graph = graph.compile(
    checkpointer=checkpointer,
    checkpoint_callback=checkpoint_callback
)
```

6. Testing: Thoroughly test your checkpointing and recovery mechanisms under various failure scenarios to ensure robustness.

## Conclusion

Persistence and checkpointing are crucial features in LangGraph that enable the development of robust, fault-tolerant applications. By implementing effective checkpointing strategies, you can create applications that gracefully handle failures, support long-running processes, and maintain state across sessions.

As you continue to work with LangGraph, consider exploring advanced topics such as:
- Implementing distributed checkpointing for large-scale applications
- Optimizing checkpoint storage and retrieval for high-performance scenarios
- Integrating checkpointing with monitoring and alerting systems for proactive failure detection and recovery

Remember that the key to effective persistence and checkpointing lies in finding the right balance between performance, fault tolerance, and application-specific requirements. As you gain more experience, you'll develop an intuition for designing checkpointing strategies that best suit your particular use cases.

## Exercises

1. Implement a LangGraph application that uses the `SqliteSaver` for checkpointing. Add intentional failures at different points in the graph and demonstrate how the application recovers using checkpoints.

2. Create a custom `Checkpointer` class that implements encryption for sensitive data in checkpoints. Consider using libraries like `cryptography` for secure encryption and decryption.

3. Develop a system for managing checkpoint versions that allows for backwards compatibility when the state structure changes. Implement functions to upgrade old checkpoint versions to the current version.

4. Build a LangGraph application that uses incremental state updates to optimize checkpoint size and performance. Compare its performance with an application that checkpoints the entire state each time.

5. Implement a distributed checkpointing system using PostgresSaver that allows multiple instances of a LangGraph application to share and resume from checkpoints. Consider issues like concurrency and consistency.

By completing these exercises, you'll gain hands-on experience in implementing advanced persistence and checkpointing strategies in LangGraph, further solidifying your understanding of these crucial concepts in building robust AI applications.

