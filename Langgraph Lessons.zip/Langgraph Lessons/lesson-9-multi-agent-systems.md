# Lesson 9: Multi-Agent Systems with LangGraph

## Introduction

In this lesson, we'll dive deep into the world of multi-agent systems using LangGraph. Multi-agent systems are a powerful paradigm in artificial intelligence that allows for the creation of complex, distributed problem-solving environments. By leveraging LangGraph's capabilities, we can design and implement sophisticated multi-agent workflows that can tackle a wide range of tasks with greater efficiency and flexibility than single-agent systems.

## 1. Concept of Multi-Agent Systems

Multi-agent systems (MAS) are computational systems where multiple intelligent agents interact to solve problems that are difficult or impossible for an individual agent to solve. These systems are characterized by:

- Decentralization: There's no single controlling agent; instead, control and information are distributed among multiple agents.
- Local views: Each agent has incomplete information or capabilities for solving the problem.
- Cooperation: Agents work together to achieve a common goal or to optimize their individual performances.
- Autonomy: Agents can make decisions independently within their scope of responsibility.
- Adaptability: The system can adjust to changes in the environment or in the problem structure.

In the context of LangGraph, multi-agent systems allow us to create more complex and powerful applications by combining the strengths of different specialized agents. This approach can lead to more robust, scalable, and efficient solutions for a wide range of problems.

## 2. Designing Multi-Agent Workflows

When designing multi-agent workflows in LangGraph, it's crucial to carefully plan the structure and interactions of your agents. Here's a step-by-step approach to designing effective multi-agent workflows:

1. Define the overall goal: Clearly articulate what you want your multi-agent system to achieve.

2. Identify agent roles: Break down the main goal into subtasks and define specific roles for different agents. Common roles might include:
   - Planner: Responsible for high-level strategy and task decomposition.
   - Researcher: Gathers and processes information from various sources.
   - Analyzer: Interprets data and provides insights.
   - Executor: Carries out specific actions based on plans and analyses.
   - Coordinator: Manages communication and resource allocation between agents.

3. Determine agent interactions: Decide how agents will communicate and share information. This includes defining the structure of messages and the protocols for information exchange.

4. Design the workflow: Create a flowchart or diagram that illustrates how tasks and information flow between agents. This will help you visualize the entire process and identify potential bottlenecks or inefficiencies.

5. Plan for scalability: Consider how your system will handle an increasing number of agents or more complex tasks.

6. Include error handling and conflict resolution mechanisms: Decide how your system will deal with failures, conflicting information, or competing goals between agents.

Let's look at an example workflow for a multi-agent research assistant system:

```
[User Query] -> [Planner Agent]
                     |
                     v
    [Researcher Agent] <-> [Analyzer Agent]
                     |
                     v
     [Writer Agent] <-> [Fact Checker Agent]
                     |
                     v
          [Summarizer Agent] -> [User Response]
```

In this workflow:
1. The Planner Agent receives the user query and breaks it down into research tasks.
2. The Researcher Agent gathers information based on these tasks.
3. The Analyzer Agent interprets the gathered data.
4. The Writer Agent creates a draft response.
5. The Fact Checker Agent verifies the accuracy of the draft.
6. The Summarizer Agent condenses the information into a concise response for the user.

## 3. Implementing Multi-Agent Workflows in LangGraph

Now that we've designed our multi-agent workflow, let's implement it using LangGraph. We'll create a simplified version of the research assistant system described above.

First, let's set up our project structure:

```
multi_agent_research/
│
├── agents/
│   ├── __init__.py
│   ├── planner.py
│   ├── researcher.py
│   ├── analyzer.py
│   ├── writer.py
│   ├── fact_checker.py
│   └── summarizer.py
│
├── graph/
│   ├── __init__.py
│   └── research_graph.py
│
├── main.py
└── requirements.txt
```

Now, let's implement each component:

1. Agents (in `agents/` directory):

Here's an example of how we might implement the Planner agent:

```python
# agents/planner.py
from typing import Dict, Any
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate

class PlannerAgent:
    def __init__(self):
        self.llm = ChatOpenAI(model_name="gpt-3.5-turbo")
        self.prompt = ChatPromptTemplate.from_template(
            "You are a research planner. Given the query: {query}, "
            "create a plan for researching this topic. Break it down into 3-5 subtasks."
        )

    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        query = state["query"]
        response = self.llm(self.prompt.format_messages(query=query))
        return {"plan": response.content}
```

You would create similar classes for each agent type, adjusting the prompts and processing logic as needed.

2. Graph Definition (in `graph/research_graph.py`):

```python
from typing import Dict, Any, Literal
from langgraph.graph import StateGraph, END
from agents import PlannerAgent, ResearcherAgent, AnalyzerAgent, WriterAgent, FactCheckerAgent, SummarizerAgent

def create_research_graph():
    workflow = StateGraph(Dict[str, Any])

    # Add nodes
    workflow.add_node("planner", PlannerAgent())
    workflow.add_node("researcher", ResearcherAgent())
    workflow.add_node("analyzer", AnalyzerAgent())
    workflow.add_node("writer", WriterAgent())
    workflow.add_node("fact_checker", FactCheckerAgent())
    workflow.add_node("summarizer", SummarizerAgent())

    # Define edges
    workflow.add_edge("planner", "researcher")
    workflow.add_edge("researcher", "analyzer")
    workflow.add_edge("analyzer", "writer")
    workflow.add_edge("writer", "fact_checker")
    workflow.add_edge("fact_checker", "summarizer")

    # Set entry and exit points
    workflow.set_entry_point("planner")
    workflow.add_edge("summarizer", END)

    return workflow.compile()
```

3. Main Application (in `main.py`):

```python
from graph.research_graph import create_research_graph

def main():
    research_graph = create_research_graph()

    query = "What are the latest advancements in renewable energy?"
    initial_state = {"query": query}

    for event in research_graph.stream(initial_state):
        if "agent" in event:
            print(f"Agent {event['agent']} completed.")
        elif "final" in event:
            print("Research completed. Final summary:")
            print(event["final"]["summary"])

if __name__ == "__main__":
    main()
```

This implementation creates a multi-agent system where each agent performs a specific role in the research process. The graph structure ensures that tasks are executed in the correct order, with information flowing between agents as needed.

## 4. Coordinating Multiple Agents in a Single Graph

Coordinating multiple agents within a single graph requires careful consideration of how agents communicate and share information. Here are some key strategies:

1. Shared State: Use the graph's state to store and pass information between agents. Each agent can read from and write to this shared state.

2. Message Passing: Implement a message passing system where agents can send structured messages to each other through the graph state.

3. Event-driven Architecture: Use events to trigger agent actions. For example, when one agent completes its task, it could emit an event that triggers the next agent in the workflow.

4. Conditional Routing: Implement conditional edges in your graph to dynamically route tasks based on the current state or the output of previous agents.

Here's an example of how you might implement conditional routing in your research graph:

```python
def route_after_fact_check(state: Dict[str, Any]) -> Literal["summarizer", "writer"]:
    if state["fact_check_passed"]:
        return "summarizer"
    else:
        return "writer"

workflow.add_conditional_edges(
    "fact_checker",
    route_after_fact_check,
    {
        "summarizer": "summarizer",
        "writer": "writer"
    }
)
```

This allows the system to re-route the workflow back to the writer if the fact check fails, ensuring the accuracy of the final output.

## 5. Communication Protocols Between Agents

Effective communication between agents is crucial for the success of a multi-agent system. Here are some approaches to implementing communication protocols:

1. Standardized Message Format: Define a consistent structure for messages passed between agents. For example:

```python
class AgentMessage:
    def __init__(self, sender: str, receiver: str, content: Any, message_type: str):
        self.sender = sender
        self.receiver = receiver
        self.content = content
        self.message_type = message_type
```

2. Publish-Subscribe Pattern: Implement a publish-subscribe system where agents can subscribe to specific types of messages or events.

3. Request-Response Protocol: For synchronous communications, implement a request-response protocol where agents can make direct requests to other agents and await responses.

4. Blackboard Architecture: Use a shared "blackboard" (a common data structure) where agents can post information and read updates from other agents.

Here's an example of how you might implement a simple publish-subscribe system:

```python
class PubSubSystem:
    def __init__(self):
        self.subscribers = {}

    def subscribe(self, topic: str, agent: Any):
        if topic not in self.subscribers:
            self.subscribers[topic] = []
        self.subscribers[topic].append(agent)

    def publish(self, topic: str, message: Any):
        if topic in self.subscribers:
            for agent in self.subscribers[topic]:
                agent.receive_message(message)

# Usage
pubsub = PubSubSystem()
pubsub.subscribe("research_results", analyzer_agent)
pubsub.publish("research_results", research_data)
```

## 6. Handling Conflicts and Decision-Making in Multi-Agent Systems

In multi-agent systems, conflicts can arise due to competing goals, limited resources, or inconsistent information. Here are some strategies for handling conflicts and making decisions:

1. Voting Mechanisms: Implement voting systems where agents can collectively make decisions.

2. Prioritization: Assign priorities to different agents or tasks to resolve conflicts.

3. Negotiation Protocols: Implement protocols for agents to negotiate and reach agreements.

4. Centralized Arbiter: Designate a specific agent or component as an arbiter to resolve conflicts.

5. Rule-based Conflict Resolution: Define a set of rules for resolving common types of conflicts.

Here's an example of a simple voting mechanism:

```python
class VotingSystem:
    def __init__(self, agents):
        self.agents = agents

    def vote(self, options):
        votes = {option: 0 for option in options}
        for agent in self.agents:
            vote = agent.cast_vote(options)
            votes[vote] += 1
        return max(votes, key=votes.get)

# Usage
voting_system = VotingSystem([agent1, agent2, agent3])
decision = voting_system.vote(["option A", "option B", "option C"])
```

## Conclusion

Multi-agent systems in LangGraph offer a powerful way to create complex, distributed AI applications. By carefully designing agent roles, implementing effective communication protocols, and handling conflicts gracefully, you can create robust and scalable systems capable of tackling a wide range of challenges.

As you continue to work with multi-agent systems, consider the following advanced topics:

- Implementing learning mechanisms for agents to improve their performance over time.
- Exploring different organizational structures for multi-agent systems (e.g., hierarchical, holonic, or market-based).
- Integrating multi-agent systems with external data sources and APIs to enhance their capabilities.
- Optimizing performance and resource allocation in large-scale multi-agent systems.

Remember that the key to successful multi-agent systems lies in striking the right balance between agent autonomy and system-wide coordination. As you gain more experience, you'll develop an intuition for designing and implementing effective multi-agent workflows tailored to your specific use cases.

## Exercises

1. Extend the research assistant system to include a "Critic" agent that evaluates the quality of the final summary and suggests improvements.

2. Implement a conflict resolution mechanism for cases where the Fact Checker and Writer agents disagree on the accuracy of the content.

3. Create a multi-agent system for a different use case, such as a collaborative story-writing application or a multi-agent game.

4. Experiment with different communication protocols and evaluate their impact on the system's performance and scalability.

5. Implement a learning mechanism that allows agents to improve their performance based on feedback from other agents or the final output quality.

By completing these exercises, you'll gain hands-on experience in designing and implementing complex multi-agent systems using LangGraph, further solidifying your understanding of this powerful paradigm in AI development.

