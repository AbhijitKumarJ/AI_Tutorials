# Lesson 7: Integrating Language Models in LangGraph

## Introduction

Welcome to Lesson 7 of our LangGraph series! In this lesson, we'll explore the exciting world of integrating Language Models (LLMs) into LangGraph applications. This integration is a crucial step in creating powerful, intelligent systems that can understand and generate human-like text, opening up a wide range of possibilities for your AI applications.

By the end of this lesson, you'll have a solid understanding of how to incorporate LLMs into your LangGraph projects, how to manage context and memory in language model interactions, and how to fine-tune models for specific tasks. We'll also cover best practices and common pitfalls to avoid when working with LLMs in graph-based applications.

## Table of Contents

1. Overview of Language Models
2. Connecting LLMs to LangGraph
3. Building Conversational Agents with LangGraph
4. Handling Context and Memory in Language Model Interactions
5. Fine-tuning Language Models for Specific Tasks
6. Best Practices and Common Pitfalls
7. Practical Exercise: Building a Multi-functional AI Assistant
8. Conclusion and Next Steps

Let's dive in and explore how to harness the power of language models in your LangGraph applications!

## 1. Overview of Language Models

Before we delve into the integration process, it's important to have a solid understanding of what language models are and how they work.

Language Models (LMs) are AI systems trained on vast amounts of text data to understand and generate human-like text. They can perform a wide range of tasks, including:

- Text generation
- Question answering
- Summarization
- Translation
- Sentiment analysis
- And much more

Some popular language models include:

- GPT (Generative Pre-trained Transformer) series by OpenAI
- BERT (Bidirectional Encoder Representations from Transformers) by Google
- T5 (Text-to-Text Transfer Transformer) by Google
- LLAMA (Large Language Model Meta AI) by Meta

These models use various architectures, but many of the most powerful ones are based on the Transformer architecture, which allows them to process and generate text with impressive coherence and contextual understanding.

When working with LLMs in LangGraph, we typically interact with them through APIs provided by companies like OpenAI, Google, or Anthropic, or by using open-source implementations that can be run locally or on cloud infrastructure.

## 2. Connecting LLMs to LangGraph

Integrating a language model into your LangGraph application involves several steps. Let's walk through the process using OpenAI's GPT model as an example.

First, you'll need to install the necessary libraries:

```bash
pip install openai langchain
```

We're installing `langchain` here because it provides convenient wrappers for various LLMs, making integration easier.

Next, let's set up our LangGraph application to use the OpenAI GPT model:

```python
import os
from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, END
from langgraph.channels import Topic
from langchain.chat_models import ChatOpenAI
from langchain.schema import HumanMessage, AIMessage, SystemMessage

# Set up your OpenAI API key
os.environ["OPENAI_API_KEY"] = "your-api-key-here"

# Define our state
class ConversationState(TypedDict):
    messages: Annotated[List[dict], Topic]
    
# Initialize our language model
llm = ChatOpenAI(temperature=0.7)

# Define a node that uses the language model
def generate_response(state: ConversationState) -> ConversationState:
    # Convert our messages to the format expected by langchain
    chain_messages = [
        SystemMessage(content="You are a helpful AI assistant."),
        *[HumanMessage(content=m['content']) if m['role'] == 'user' else AIMessage(content=m['content']) 
          for m in state['messages']]
    ]
    
    # Generate a response
    response = llm(chain_messages)
    
    # Add the response to our state
    return {
        **state,
        'messages': {'role': 'assistant', 'content': response.content}
    }

# Create our graph
graph = StateGraph(ConversationState)
graph.add_node('generate_response', generate_response)
graph.add_edge('generate_response', END)

# Compile the graph
compiled_graph = graph.compile()
```

In this example, we've created a simple graph that takes a conversation state (a list of messages) and uses the GPT model to generate a response. The `generate_response` node converts our messages into the format expected by the language model, sends them to the model, and then adds the model's response to our state.

This basic setup allows us to send messages to our graph and receive AI-generated responses. However, to create more sophisticated applications, we'll need to build on this foundation.

## 3. Building Conversational Agents with LangGraph

Now that we have a basic integration with a language model, let's explore how to build more complex conversational agents using LangGraph.

A conversational agent typically needs to:

1. Understand user input
2. Maintain context over multiple turns of conversation
3. Generate appropriate responses
4. Take actions based on user requests

Here's an example of how we might expand our previous graph to create a more fully-featured conversational agent:

```python
from langchain.chat_models import ChatOpenAI
from langchain.schema import HumanMessage, AIMessage, SystemMessage
from langchain.prompts import ChatPromptTemplate
from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, END
from langgraph.channels import Topic, LastValue

class AgentState(TypedDict):
    messages: Annotated[List[dict], Topic]
    current_task: Annotated[str, LastValue]
    task_status: Annotated[str, LastValue]

llm = ChatOpenAI(temperature=0.7)

def understand_input(state: AgentState) -> AgentState:
    last_message = state['messages'][-1]
    prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content="You are an AI assistant. Analyze the user's message and determine what task they are requesting. Respond with a brief task description."),
        HumanMessage(content=last_message['content'])
    ])
    task = llm(prompt.format_messages())
    return {**state, 'current_task': task.content}

def perform_task(state: AgentState) -> AgentState:
    task = state['current_task']
    # Here you would implement task-specific logic
    # For this example, we'll just generate a response about the task
    prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content="You are an AI assistant. Generate a response about performing the following task:"),
        HumanMessage(content=task)
    ])
    response = llm(prompt.format_messages())
    return {
        **state, 
        'messages': {'role': 'assistant', 'content': response.content},
        'task_status': 'completed'
    }

def should_continue(state: AgentState):
    if state['task_status'] == 'completed':
        return END
    return 'perform_task'

graph = StateGraph(AgentState)
graph.add_node('understand_input', understand_input)
graph.add_node('perform_task', perform_task)
graph.add_edge('understand_input', 'perform_task')
graph.add_conditional_edges('perform_task', should_continue, {END: END, 'perform_task': 'perform_task'})
compiled_graph = graph.compile()
```

This more advanced agent first understands the user's input to determine the requested task, then performs the task (in this case, by generating a response about performing the task), and finally decides whether to continue or end the conversation.

## 4. Handling Context and Memory in Language Model Interactions

One of the challenges when working with language models is maintaining context over multiple interactions. LangGraph's state management features are particularly useful for this purpose.

Here's an example of how we might modify our agent to maintain context:

```python
from langchain.memory import ConversationBufferMemory
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder

class AgentState(TypedDict):
    messages: Annotated[List[dict], Topic]
    memory: Annotated[ConversationBufferMemory, LastValue]

def initialize_state() -> AgentState:
    return {
        'messages': [],
        'memory': ConversationBufferMemory(return_messages=True)
    }

def generate_response(state: AgentState) -> AgentState:
    prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content="You are a helpful AI assistant. Use the conversation history to provide context-aware responses."),
        MessagesPlaceholder(variable_name="history"),
        HumanMessage(content=state['messages'][-1]['content'])
    ])
    
    messages = prompt.format_messages(history=state['memory'].chat_memory)
    response = llm(messages)
    
    # Update memory
    state['memory'].save_context({"input": state['messages'][-1]['content']}, {"output": response.content})
    
    return {
        **state,
        'messages': {'role': 'assistant', 'content': response.content}
    }

graph = StateGraph(AgentState)
graph.add_node('generate_response', generate_response)
graph.add_edge('generate_response', END)
compiled_graph = graph.compile()
```

In this example, we're using LangChain's `ConversationBufferMemory` to maintain a history of the conversation. This history is then included in the prompt for each new interaction, allowing the model to generate responses that take into account the full context of the conversation.

## 5. Fine-tuning Language Models for Specific Tasks

While pre-trained language models are incredibly versatile, they can be made even more effective for specific tasks through fine-tuning. Fine-tuning involves further training the model on a dataset that's representative of your specific use case.

Here's a high-level overview of the fine-tuning process:

1. **Prepare your dataset**: Collect a dataset of examples relevant to your task. This could be conversations, question-answer pairs, or any other format relevant to your use case.

2. **Format your data**: Convert your data into the format expected by the fine-tuning process. This often involves creating prompt-completion pairs.

3. **Choose a base model**: Select a pre-trained model to start with. This could be a smaller version of GPT, for example.

4. **Fine-tune the model**: Use the fine-tuning API provided by your LLM provider (e.g., OpenAI's fine-tuning API) or use open-source libraries if you're working with local models.

5. **Evaluate and iterate**: Test your fine-tuned model and iterate as necessary.

Here's a conceptual example of how you might use a fine-tuned model in LangGraph:

```python
from langchain.chat_models import ChatOpenAI

# Assume we've already fine-tuned a model and have its ID
fine_tuned_model = ChatOpenAI(model="ft:gpt-3.5-turbo-0613:your-org:your-model-name:your-model-id")

def generate_specialized_response(state: AgentState) -> AgentState:
    response = fine_tuned_model([HumanMessage(content=state['messages'][-1]['content'])])
    return {
        **state,
        'messages': {'role': 'assistant', 'content': response.content}
    }

graph = StateGraph(AgentState)
graph.add_node('generate_specialized_response', generate_specialized_response)
graph.add_edge('generate_specialized_response', END)
compiled_graph = graph.compile()
```

This example assumes you've already fine-tuned a model and have its ID. The fine-tuned model is then used in place of the general-purpose model for generating responses.

## 6. Best Practices and Common Pitfalls

When integrating language models into LangGraph applications, keep the following best practices in mind:

1. **Prompt Engineering**: Craft your prompts carefully. The quality of your prompts significantly affects the quality of the model's outputs. Be clear, specific, and provide examples when necessary.

2. **Error Handling**: Always implement robust error handling. API calls can fail, and models can sometimes generate unexpected outputs.

3. **Rate Limiting**: Be mindful of rate limits imposed by API providers. Implement appropriate rate limiting in your application to avoid exceeding these limits.

4. **Cost Management**: Using LLMs via API can be expensive. Monitor your usage and implement cost control measures.

5. **Privacy and Data Security**: Be cautious about what data you send to the LLM. Avoid sending sensitive information unless absolutely necessary.

6. **Output Validation**: Implement validation for model outputs, especially if you're using them to drive critical functionality in your application.

7. **Versioning**: Keep track of which model versions you're using. Changes in model behavior can affect your application's functionality.

Common pitfalls to avoid include:

1. **Overreliance on the Model**: Don't assume the model will always generate perfect or factual responses. Implement checks and balances in your system.

2. **Ignoring Context Limitations**: Most models have a maximum context length. Be aware of this limitation and manage your prompts and conversation history accordingly.

3. **Neglecting to Handle Edge Cases**: Consider how your system will handle unexpected inputs or outputs.

4. **Lack of Monitoring**: Implement logging and monitoring to track the performance and behavior of your LLM-integrated system over time.

## 7. Practical Exercise: Building a Multi-functional AI Assistant

Let's put everything we've learned together by building a multi-functional AI assistant using LangGraph and a language model. This assistant will be able to handle multiple types of tasks, maintain conversation context, and use specialized models for specific functions.

```python
import os
from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, END
from langgraph.channels import Topic, LastValue
from langchain.chat_models import ChatOpenAI
from langchain.schema import HumanMessage, AIMessage, SystemMessage
from langchain.prompts import ChatPromptTemplate
from langchain.memory import ConversationBufferMemory

# Set up your OpenAI API key
os.environ["OPENAI_API_KEY"] = "your-api-key-here"

class AssistantState(TypedDict):
    messages: Annotated[List[dict], Topic]
    memory: Annotated[ConversationBufferMemory, LastValue]
    current_task: Annotated[str, LastValue]
    task_status: Annotated[str, LastValue]

# Initialize models
general_llm = ChatOpenAI(temperature=0.7)
specialized_llm = ChatOpenAI(model="ft:gpt-3.5-turbo-0613:your-org:your-model-name:your-model-id")

def initialize_state() -> AssistantState:
    return {
        'messages': [],
        'memory': ConversationBufferMemory(return_messages=True),
        'current_task': '',
        'task_status': ''
    }

def understand_input(state: AssistantState) -> AssistantState:
    last_message = state['messages'][-1]
    prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content="You are an AI assistant. Analyze the user's message and determine what task they are requesting. Respond with a brief task description."),
        HumanMessage(content=last_message['content'])
    ])
    task = general_llm(prompt.format_messages())
    return {**state, 'current_task': task.content}

def perform_general_task(state: AssistantState) -> AssistantState:
    prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content="You are a helpful AI assistant. Use the conversation history to provide context-aware responses."),
        MessagesPlaceholder(variable_name="history"),
        HumanMessage(content=state['current_task'])
    ])
    
    messages = prompt.format_messages(history=state['memory'].chat_memory)
    response = general_llm(messages)
    
    state['memory'].save_context({"input": state['current_task']}, {"output": response.content})
    
    return {
        **state,
        'messages': {'role': 'assistant', 'content': response.content},
        'task_status': 'completed'
    }

def perform_specialized_task(state: AssistantState) -> AssistantState:
    prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content="You are a specialized AI assistant. Perform the following task:"),
        HumanMessage(content=state['current_task'])
    ])
    
    response = specialized_llm(prompt.format_messages())
    
    state['memory'].save_context({"input": state['current_task']}, {"output": response.content})
    
    return {
        **state,
        'messages': {'role': 'assistant', 'content': response.content},
        'task_status': 'completed'
    }

def route_task(state: AssistantState):
    if "specialized" in state['current_task'].lower():
        return "perform_specialized_task"
    return "perform_general_task"

def should_continue(state: AssistantState):
    if state['task_status'] == 'completed':
        return END
    return 'understand_input'

# Create the graph
graph = StateGraph(AssistantState)
graph.add_node('understand_input', understand_input)
graph.add_node('perform_general_task', perform_general_task)
graph.add_node('perform_specialized_task', perform_specialized_task)

graph.add_edge('understand_input', route_task)
graph.add_conditional_edges(route_task, {
    'perform_general_task': 'perform_general_task',
    'perform_specialized_task': 'perform_specialized_task'
})
graph.add_conditional_edges('perform_general_task', should_continue, {END: END, 'understand_input': 'understand_input'})
graph.add_conditional_edges('perform_specialized_task', should_continue, {END: END, 'understand_input': 'understand_input'})

# Compile the graph
compiled_graph = graph.compile()

# Example usage
initial_state = initialize_state()
initial_state['messages'] = [{'role': 'user', 'content': 'Tell me a joke about programming.'}]

for output in compiled_graph.stream(initial_state):
    if 'messages' in output and output['messages'][-1]['role'] == 'assistant':
        print("Assistant:", output['messages'][-1]['content'])
    print("Current task:", output['current_task'])
    print("Task status:", output['task_status'])
    print("---")

# You can continue the conversation by updating the state and running the graph again
```

This example brings together many of the concepts we've discussed:

1. It uses both a general-purpose and a specialized language model.
2. It maintains conversation context using `ConversationBufferMemory`.
3. It implements a multi-step process: understanding the input, routing to the appropriate task handler, and generating a response.
4. It uses conditional edges to create a conversational loop and to route tasks.

## 8. Conclusion and Next Steps

In this lesson, we've explored how to integrate language models into LangGraph applications. We've covered:

1. An overview of language models and their capabilities
2. How to connect LLMs to LangGraph
3. Building conversational agents
4. Handling context and memory in LM interactions
5. Fine-tuning language models for specific tasks
6. Best practices and common pitfalls to avoid
7. A practical exercise building a multi-functional AI assistant

This integration opens up a world of possibilities for creating sophisticated AI applications. As you continue your journey with LangGraph and LLMs, consider exploring:

1. More advanced prompt engineering techniques
2. Implementing more complex conversation flows
3. Integrating multiple specialized models for different tasks
4. Implementing advanced error handling and fallback mechanisms
5. Exploring ways to optimize performance and reduce costs when working with LLMs

Remember, the field of AI and language models is rapidly evolving. Stay curious, keep experimenting, and don't hesitate to push the boundaries of what's possible with LangGraph and LLMs!

