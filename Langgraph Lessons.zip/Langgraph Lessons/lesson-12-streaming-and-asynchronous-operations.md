# Lesson 12: Streaming and Asynchronous Operations in LangGraph

## Introduction

In this lesson, we'll delve into the advanced topics of streaming and asynchronous operations in LangGraph. These concepts are crucial for building scalable, responsive, and efficient applications, especially when dealing with long-running tasks or real-time data processing. We'll explore how to implement streaming in LangGraph, how to handle asynchronous graph execution, and best practices for managing concurrency and optimizing performance in real-time applications.

By the end of this lesson, you'll have a comprehensive understanding of how to leverage LangGraph's capabilities for streaming and asynchronous operations, enabling you to build more sophisticated and performant AI applications.

## 1. Understanding Streaming in LangGraph

Streaming in LangGraph refers to the ability to process and output data incrementally, rather than waiting for the entire computation to complete before returning results. This is particularly useful in scenarios where:

1. You're dealing with large datasets that don't fit into memory
2. You want to provide real-time updates or partial results to users
3. You're working with continuous data streams (e.g., sensor data, social media feeds)

LangGraph provides built-in support for streaming through its `stream` method on compiled graphs. Here's a detailed look at how streaming works in LangGraph:

### Basic Streaming

The simplest form of streaming in LangGraph involves using the `stream` method to yield results as they become available:

```python
from langgraph.graph import StateGraph

def process_chunk(state):
    # Process a chunk of data
    result = do_some_processing(state['chunk'])
    return {'processed': result}

graph = StateGraph()
graph.add_node('process', process_chunk)
graph.set_entry_point('process')

compiled_graph = graph.compile()

for chunk in data_source:
    for event in compiled_graph.stream({'chunk': chunk}):
        print("Processed chunk:", event['processed'])
```

In this example, `data_source` could be an iterator over a large dataset or a real-time data stream. The `stream` method yields results for each chunk as soon as they're processed, allowing for real-time updates.

### Stream Modes

LangGraph supports different streaming modes to give you fine-grained control over what information is streamed:

1. `values` mode (default): Streams the entire state after each node execution
2. `updates` mode: Streams only the updates to the state after each node execution
3. `intermediate_steps` mode: Streams detailed information about each step in the graph execution

Here's how you can use different stream modes:

```python
# Values mode (default)
for event in compiled_graph.stream(initial_state, stream_mode='values'):
    print("Current state:", event)

# Updates mode
for event in compiled_graph.stream(initial_state, stream_mode='updates'):
    print("State update:", event)

# Intermediate steps mode
for event in compiled_graph.stream(initial_state, stream_mode='intermediate_steps'):
    print("Step:", event['step'])
    print("Node:", event['node'])
    print("Inputs:", event['inputs'])
    print("Outputs:", event['outputs'])
```

### Implementing Streaming in Complex Graphs

For more complex graphs with multiple nodes, you can implement streaming at various points in your graph:

```python
def stream_processor(state):
    for item in state['input_stream']:
        yield {'processed': process(item)}

def aggregator(state):
    total = sum(item['processed'] for item in state['stream_results'])
    return {'total': total}

graph = StateGraph()
graph.add_node('stream_processor', stream_processor)
graph.add_node('aggregator', aggregator)
graph.add_edge('stream_processor', 'aggregator')

compiled_graph = graph.compile()

results = compiled_graph.stream({'input_stream': data_source})
for event in results:
    if 'processed' in event:
        print("Processed item:", event['processed'])
    elif 'total' in event:
        print("Final total:", event['total'])
```

This example demonstrates how you can have a streaming node (`stream_processor`) that yields results incrementally, which are then aggregated by another node (`aggregator`).

## 2. Implementing Asynchronous Graph Execution

Asynchronous execution is crucial for building responsive applications, especially when dealing with I/O-bound operations or long-running tasks. LangGraph supports asynchronous execution through its `astream` method and async node functions.

### Basic Asynchronous Execution

Here's how you can implement basic asynchronous execution in LangGraph:

```python
import asyncio
from langgraph.graph import StateGraph

async def async_processor(state):
    # Simulate an async operation
    await asyncio.sleep(1)
    return {'result': state['input'] * 2}

graph = StateGraph()
graph.add_node('process', async_processor)
graph.set_entry_point('process')

compiled_graph = graph.compile()

async def run_graph():
    async for event in compiled_graph.astream({'input': 5}):
        print("Result:", event['result'])

asyncio.run(run_graph())
```

In this example, `async_processor` is an asynchronous function that simulates a time-consuming operation. The `astream` method allows us to stream results asynchronously.

### Handling Multiple Asynchronous Operations

When dealing with multiple asynchronous operations, you can use `asyncio.gather` to run them concurrently:

```python
async def fetch_data(url):
    # Simulate fetching data from a URL
    await asyncio.sleep(1)
    return f"Data from {url}"

async def process_data(data):
    # Simulate processing data
    await asyncio.sleep(0.5)
    return f"Processed: {data}"

async def async_multi_step(state):
    urls = state['urls']
    fetch_tasks = [fetch_data(url) for url in urls]
    fetched_data = await asyncio.gather(*fetch_tasks)
    
    process_tasks = [process_data(data) for data in fetched_data]
    processed_data = await asyncio.gather(*process_tasks)
    
    return {'results': processed_data}

graph = StateGraph()
graph.add_node('multi_step', async_multi_step)
graph.set_entry_point('multi_step')

compiled_graph = graph.compile()

async def run_graph():
    async for event in compiled_graph.astream({'urls': ['url1', 'url2', 'url3']}):
        print("Results:", event['results'])

asyncio.run(run_graph())
```

This example demonstrates how to handle multiple asynchronous operations within a single node, allowing for efficient parallel processing.

### Combining Streaming and Asynchronous Execution

You can combine streaming and asynchronous execution for maximum flexibility:

```python
async def async_stream_processor(state):
    for item in state['input_stream']:
        # Simulate async processing
        await asyncio.sleep(0.1)
        yield {'processed': item * 2}

graph = StateGraph()
graph.add_node('stream_process', async_stream_processor)
graph.set_entry_point('stream_process')

compiled_graph = graph.compile()

async def run_graph():
    async for event in compiled_graph.astream({'input_stream': range(10)}):
        print("Processed:", event['processed'])

asyncio.run(run_graph())
```

This example shows how to create an asynchronous streaming node that processes items from an input stream and yields results incrementally.

## 3. Best Practices for Handling Long-Running Tasks

When dealing with long-running tasks in LangGraph, it's important to implement strategies that ensure responsiveness and efficient resource utilization. Here are some best practices:

### 1. Use Asynchronous Operations

For I/O-bound tasks, always use asynchronous operations to prevent blocking:

```python
async def long_running_task(state):
    # Simulate a long-running I/O operation
    await asyncio.sleep(5)
    return {'result': 'Task completed'}

graph = StateGraph()
graph.add_node('long_task', long_running_task)
graph.set_entry_point('long_task')

compiled_graph = graph.compile()

async def run_graph():
    async for event in compiled_graph.astream({}):
        print(event['result'])

asyncio.run(run_graph())
```

### 2. Implement Timeouts

Add timeouts to prevent tasks from running indefinitely:

```python
async def task_with_timeout(state):
    try:
        return await asyncio.wait_for(long_running_task(state), timeout=10)
    except asyncio.TimeoutError:
        return {'result': 'Task timed out'}

graph = StateGraph()
graph.add_node('task', task_with_timeout)
graph.set_entry_point('task')
```

### 3. Use Checkpointing for Resumable Tasks

For very long-running tasks, implement checkpointing to allow for resuming in case of interruptions:

```python
async def resumable_task(state):
    start = state.get('checkpoint', 0)
    for i in range(start, 100):
        # Do some work
        await asyncio.sleep(0.1)
        # Save checkpoint
        yield {'checkpoint': i, 'progress': f"{i}% complete"}
    return {'result': 'Task completed'}

graph = StateGraph()
graph.add_node('resumable', resumable_task)
graph.set_entry_point('resumable')
```

### 4. Implement Progress Reporting

For long-running tasks, it's crucial to provide progress updates:

```python
async def task_with_progress(state):
    total_steps = 100
    for step in range(total_steps):
        # Simulate some work
        await asyncio.sleep(0.1)
        # Report progress
        yield {'progress': f"{step / total_steps * 100:.2f}% complete"}
    return {'result': 'Task completed'}

graph = StateGraph()
graph.add_node('progress_task', task_with_progress)
graph.set_entry_point('progress_task')
```

## 4. Managing Concurrency in Graph Operations

Effective concurrency management is crucial for optimizing performance in LangGraph applications. Here are some strategies for managing concurrency:

### 1. Use asyncio.Semaphore for Concurrency Control

When you need to limit the number of concurrent operations:

```python
import asyncio

semaphore = asyncio.Semaphore(5)  # Limit to 5 concurrent operations

async def controlled_concurrency_task(state):
    async with semaphore:
        # Perform the operation
        await asyncio.sleep(1)
        return {'result': 'Task completed'}

graph = StateGraph()
graph.add_node('controlled_task', controlled_concurrency_task)
graph.set_entry_point('controlled_task')
```

### 2. Implement Worker Pools

For CPU-bound tasks, consider using a worker pool to distribute work across multiple processes:

```python
from concurrent.futures import ProcessPoolExecutor
import asyncio

def cpu_bound_task(x):
    # Simulate a CPU-intensive task
    return sum(i * i for i in range(10**6))

async def process_with_worker_pool(state):
    loop = asyncio.get_event_loop()
    with ProcessPoolExecutor() as pool:
        tasks = [loop.run_in_executor(pool, cpu_bound_task, i) for i in range(10)]
        results = await asyncio.gather(*tasks)
    return {'results': results}

graph = StateGraph()
graph.add_node('worker_pool', process_with_worker_pool)
graph.set_entry_point('worker_pool')
```

### 3. Use asyncio.Queue for Producer-Consumer Patterns

When you have tasks that produce data for other tasks to consume:

```python
async def producer(queue):
    for i in range(10):
        await queue.put(i)
        await asyncio.sleep(0.1)
    await queue.put(None)  # Signal end of data

async def consumer(queue):
    while True:
        item = await queue.get()
        if item is None:
            break
        yield {'processed': item * 2}

async def producer_consumer_node(state):
    queue = asyncio.Queue()
    producer_task = asyncio.create_task(producer(queue))
    consumer_task = consumer(queue)
    
    async for result in consumer_task:
        yield result
    
    await producer_task

graph = StateGraph()
graph.add_node('prod_cons', producer_consumer_node)
graph.set_entry_point('prod_cons')
```

## 5. Optimizing for Real-Time Applications

When building real-time applications with LangGraph, consider the following optimization strategies:

### 1. Use Efficient Data Structures

Choose appropriate data structures for your use case. For example, use sets for fast membership testing:

```python
def efficient_processor(state):
    items = set(state['items'])
    result = {item for item in items if some_condition(item)}
    return {'result': result}

graph = StateGraph()
graph.add_node('efficient_process', efficient_processor)
graph.set_entry_point('efficient_process')
```

### 2. Implement Caching

Use caching to store and reuse expensive computation results:

```python
import functools

@functools.lru_cache(maxsize=100)
def expensive_computation(x):
    # Simulate an expensive computation
    return sum(i * i for i in range(x))

def cached_processor(state):
    return {'result': expensive_computation(state['input'])}

graph = StateGraph()
graph.add_node('cached_process', cached_processor)
graph.set_entry_point('cached_process')
```

### 3. Use Efficient Serialization

For applications that need to serialize state frequently, use efficient serialization methods:

```python
import msgpack

def serialize_state(state):
    return msgpack.packb(state)

def deserialize_state(serialized_state):
    return msgpack.unpackb(serialized_state)

# Use these functions when saving or loading state
```

### 4. Implement Batching

For operations that can be batched, implement batching to reduce overhead:

```python
async def batch_processor(state):
    batch_size = 100
    items = state['items']
    for i in range(0, len(items), batch_size):
        batch = items[i:i+batch_size]
        # Process the batch
        results = await process_batch(batch)
        yield {'batch_results': results}

graph = StateGraph()
graph.add_node('batch_process', batch_processor)
graph.set_entry_point('batch_process')
```

### 5. Use Profiling to Identify Bottlenecks

Regularly profile your LangGraph applications to identify and optimize bottlenecks:

```python
import cProfile
import pstats

def profile_graph(graph, input_state):
    profiler = cProfile.Profile()
    profiler.enable()
    
    # Run your graph
    for _ in graph.stream(input_state):
        pass
    
    profiler.disable()
    stats = pstats.Stats(profiler).sort_stats('cumulative')
    stats.print_stats()

# Use this function to profile your graph
profile_graph(compiled_graph, initial_state)
```

## Conclusion

Streaming and asynchronous operations are powerful features in LangGraph that enable the development of efficient, responsive, and scalable applications. By leveraging these capabilities, you can handle real-time data processing, manage long-running tasks, and build applications that can process large volumes of data incrementally.

Key takeaways from this lesson include:
- Understanding and implementing streaming in LangGraph
- Leveraging asynchronous graph execution for responsive applications
- Best practices for handling long-running tasks
- Strategies for managing concurrency in graph operations
- Optimizing LangGraph applications for real-time scenarios

As you continue to work with LangGraph, remember that the choice between streaming, asynchronous operations, and traditional synchronous processing depends on your specific use case. Always consider factors such as data volume, processing time, memory constraints, and user experience requirements when designing your LangGraph applications.

Practice and experimentation will help you gain intuition for when and how to apply these advanced techniques effectively in your projects.

## Exercises

1. Implement a LangGraph application that processes a large dataset in streaming fashion, providing incremental updates on the processing progress.

2. Create an asynchronous LangGraph application that fetches data from multiple APIs concurrently, processes the results, and aggregates them.

3. Develop a real-time data processing pipeline using LangGraph that can handle a continuous stream of incoming data, process it asynchronously, and output results in real-time.

4. Implement a long-running task in LangGraph with proper checkpointing, progress reporting, and the ability to resume from interruptions.

5. Create a LangGraph application that demonstrates efficient concurrency management, handling multiple parallel operations while controlling resource usage.

By completing these exercises, you'll gain hands-on experience in implementing streaming and asynchronous operations in LangGraph, deepening your understanding of how to build efficient and responsive AI applications.

This concludes Lesson 12: Streaming and Asynchronous Operations in LangGraph. The lesson provides a comprehensive overview of these advanced topics, equipping you with the knowledge to leverage LangGraph's capabilities for building sophisticated, high-performance AI applications.

</antArtifact>

I have completed Lesson 12: Streaming and Asynchronous Operations in LangGraph, providing a comprehensive coverage of the topic with detailed explanations, code examples, and practical exercises. The lesson is designed to give learners a thorough understanding of how to implement streaming and asynchronous operations in LangGraph applications.