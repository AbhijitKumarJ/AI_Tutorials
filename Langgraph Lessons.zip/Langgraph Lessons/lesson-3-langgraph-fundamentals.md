# Lesson 3: LangGraph Fundamentals

In this lesson, we'll delve into the core components and concepts that form the foundation of LangGraph. We'll explore how LangGraph builds upon the graph theory concepts we've learned, providing a powerful framework for creating sophisticated AI applications. Let's begin by examining the fundamental building blocks of LangGraph.

## 1. State in LangGraph

State is a crucial concept in LangGraph, representing the current condition or context of your AI application as it progresses through its workflow. Unlike simple graph implementations where nodes might only pass simple values between them, LangGraph's state system allows for rich, complex data to be maintained and updated throughout the execution of your graph.

### Key Characteristics of State in LangGraph:

1. Persistence: State persists across node executions, allowing information to be carried forward and accumulated as the graph is traversed.

2. Flexibility: State can contain various types of data, from simple scalars to complex nested structures, accommodating diverse application needs.

3. Immutability: Each node receives a copy of the current state and returns a new state, ensuring thread-safety and predictability.

4. Accessibility: All nodes in the graph have access to the entire state, enabling complex decision-making based on accumulated context.

### Defining State:

In LangGraph, you typically define your state structure using a TypedDict. This provides a clear schema for your state and enables type checking for improved code reliability. Here's an example:

```python
from typing import TypedDict, List

class ConversationState(TypedDict):
    user_input: str
    conversation_history: List[str]
    current_topic: str
    sentiment_score: float
    response: str
```

In this example, we've defined a state for a conversational AI application. It includes the user's input, a history of the conversation, the current topic being discussed, a sentiment score, and the AI's response.

### Using State in Nodes:

Nodes in LangGraph receive the current state as input and return an updated state. Here's how you might use this state in a node function:

```python
def analyze_sentiment(state: ConversationState) -> ConversationState:
    # Perform sentiment analysis on the user_input
    sentiment_score = perform_sentiment_analysis(state['user_input'])
    
    # Update the state with the new sentiment score
    return {
        **state,
        'sentiment_score': sentiment_score
    }
```

This node function takes the current state, performs sentiment analysis on the user's input, and returns an updated state with the new sentiment score.

### State Management Best Practices:

1. Keep your state well-organized and documented. A clear state structure makes your graph easier to understand and maintain.

2. Be mindful of state size. While LangGraph can handle complex states, excessively large states can impact performance.

3. Use type hints and TypedDict to catch potential errors early and improve code readability.

4. Consider breaking very complex states into smaller, more manageable sub-states if your application logic allows for it.

By leveraging LangGraph's state system effectively, you can create AI applications that maintain rich context, make informed decisions based on accumulated information, and handle complex, multi-step processes with ease.

## 2. Channels and Their Types

Channels in LangGraph provide a way to manage how information flows through your graph and how state is updated. They define the behavior for how values are combined or updated when multiple nodes write to the same key in the state.

### Key Concepts of Channels:

1. State Keys: Each key in your state is associated with a specific channel type.

2. Update Behavior: Channels determine how values are updated when multiple nodes write to the same state key.

3. Flexibility: LangGraph provides several built-in channel types, and you can create custom channels for specific needs.

### Common Channel Types:

1. Topic Channel:
   - Behavior: Maintains a list of all values written to it.
   - Use Case: Useful for maintaining logs or history.

   ```python
   from langgraph.channels import Topic

   class LogState(TypedDict):
       events: Annotated[List[str], Topic()]
   ```

2. LastValue Channel:
   - Behavior: Keeps only the most recent value written to it.
   - Use Case: When you only need the latest update for a given piece of information.

   ```python
   from langgraph.channels import LastValue

   class SensorState(TypedDict):
       temperature: Annotated[float, LastValue()]
   ```

3. EphemeralValue Channel:
   - Behavior: Allows a value to be set once and automatically clears after being read.
   - Use Case: For passing temporary information between specific nodes.

   ```python
   from langgraph.channels import EphemeralValue

   class AuthState(TypedDict):
       temp_token: Annotated[str, EphemeralValue()]
   ```

4. BinaryOperatorAggregate Channel:
   - Behavior: Applies a binary operator to combine new values with the existing value.
   - Use Case: For cumulative operations like summing or averaging.

   ```python
   from langgraph.channels import BinaryOperatorAggregate
   from operator import add

   class AnalyticsState(TypedDict):
       total_views: Annotated[int, BinaryOperatorAggregate(add)]
   ```

### Using Channels in Practice:

Let's consider an example of how you might use different channel types in a more complex LangGraph application:

```python
from typing import Annotated, List, TypedDict
from langgraph.channels import Topic, LastValue, EphemeralValue, BinaryOperatorAggregate
from operator import add

class ComplexState(TypedDict):
    user_inputs: Annotated[List[str], Topic()]
    current_topic: Annotated[str, LastValue()]
    temp_data: Annotated[dict, EphemeralValue()]
    total_interactions: Annotated[int, BinaryOperatorAggregate(add)]

def process_user_input(state: ComplexState) -> ComplexState:
    new_input = get_user_input()  # Assume this function exists
    return {
        **state,
        'user_inputs': [new_input],  # This will be appended to the existing list
        'current_topic': detect_topic(new_input),  # This will replace the previous topic
        'temp_data': {'last_input_length': len(new_input)},  # This will be available for the next node and then clear
        'total_interactions': 1  # This will be added to the existing total
    }

# ... rest of the graph definition
```

In this example:
- `user_inputs` uses a Topic channel to maintain a history of all user inputs.
- `current_topic` uses a LastValue channel to always reflect the most recent topic.
- `temp_data` uses an EphemeralValue channel to pass temporary information to the next node.
- `total_interactions` uses a BinaryOperatorAggregate channel to keep a running total of interactions.

By leveraging these different channel types, you can create sophisticated data flow patterns in your LangGraph applications, enabling complex state management with minimal boilerplate code.

## 3. Graph Structure in LangGraph

The graph structure in LangGraph defines the overall architecture of your AI application. It determines how different components (nodes) are connected and how data flows between them. Understanding how to effectively structure your graph is key to building powerful and flexible LangGraph applications.

### Key Components of LangGraph's Graph Structure:

1. Nodes: Represent individual processing steps or decision points in your AI workflow.
2. Edges: Define the connections and data flow between nodes.
3. Entry Point: Specifies where execution of the graph begins.
4. End Conditions: Determine when the graph execution should terminate.

### Building a Graph in LangGraph:

Let's walk through the process of building a graph in LangGraph, using a simple conversational AI as an example:

```python
from langgraph.graph import StateGraph, END

# Define the state structure
class ConversationState(TypedDict):
    user_input: str
    conversation_history: List[str]
    response: str

# Create the graph
graph = StateGraph(ConversationState)

# Define node functions
def preprocess_input(state: ConversationState) -> ConversationState:
    # Preprocess the user input (e.g., lowercase, remove punctuation)
    processed_input = preprocess(state['user_input'])
    return {**state, 'user_input': processed_input}

def generate_response(state: ConversationState) -> ConversationState:
    # Generate a response based on the user input and conversation history
    response = ai_model(state['user_input'], state['conversation_history'])
    return {**state, 'response': response}

def update_history(state: ConversationState) -> ConversationState:
    # Update the conversation history
    new_history = state['conversation_history'] + [state['user_input'], state['response']]
    return {**state, 'conversation_history': new_history}

# Add nodes to the graph
graph.add_node("preprocess", preprocess_input)
graph.add_node("generate", generate_response)
graph.add_node("update", update_history)

# Define edges to connect the nodes
graph.add_edge("preprocess", "generate")
graph.add_edge("generate", "update")

# Set the entry point
graph.set_entry_point("preprocess")

# Define end condition
def should_end(state: ConversationState) -> bool:
    return "goodbye" in state['user_input'].lower()

graph.add_conditional_edges(
    "update",
    should_end,
    {
        True: END,
        False: "preprocess"
    }
)

# Compile the graph
compiled_graph = graph.compile()
```

In this example:

1. We define the state structure using a TypedDict.
2. We create a StateGraph instance, specifying our state type.
3. We define node functions that operate on and return the state.
4. We add these functions as nodes to our graph using `add_node`.
5. We connect the nodes using `add_edge` to define the flow of our application.
6. We set the entry point of our graph to the "preprocess" node.
7. We add a conditional edge after the "update" node. If the user says "goodbye", the graph ends. Otherwise, it loops back to "preprocess" for the next interaction.
8. Finally, we compile the graph, which prepares it for execution.

This graph structure creates a loop that preprocesses user input, generates a response, updates the conversation history, and then checks if the conversation should end. If not, it loops back to preprocess the next user input.

### Advanced Graph Structures:

LangGraph allows for more complex graph structures to handle sophisticated AI workflows. Here are some advanced techniques:

1. Parallel Processing:
   You can create parallel branches in your graph to perform multiple operations simultaneously. This is useful for tasks that don't depend on each other.

   ```python
   def analyze_sentiment(state: ConversationState) -> ConversationState:
       sentiment = sentiment_model(state['user_input'])
       return {**state, 'sentiment': sentiment}

   graph.add_node("sentiment", analyze_sentiment)
   graph.add_edge("preprocess", "sentiment")
   graph.add_edge("preprocess", "generate")
   ```

   In this modification, sentiment analysis happens in parallel with response generation.

2. Conditional Branching:
   You can use conditional edges to create different paths through your graph based on the current state.

   ```python
   def determine_intent(state: ConversationState) -> str:
       intent = classify_intent(state['user_input'])
       return "handle_query" if intent == "question" else "handle_statement"

   graph.add_conditional_edges(
       "preprocess",
       determine_intent,
       {
           "handle_query": "query_handler",
           "handle_statement": "statement_handler"
       }
   )
   ```

   This allows your graph to handle different types of user inputs in different ways.

3. Subgraphs:
   For complex applications, you can create subgraphs to encapsulate related functionality and improve modularity.

   ```python
   query_subgraph = StateGraph(ConversationState)
   # ... define nodes and edges for query handling

   main_graph.add_subgraph("query_handler", query_subgraph)
   ```

   This allows you to break down complex workflows into more manageable pieces.

By leveraging these advanced structuring techniques, you can create highly sophisticated AI workflows that can handle complex decision-making processes, parallel operations, and modular functionality.

## 4. The Concept of Compilation in LangGraph

Compilation is a crucial step in LangGraph that transforms your graph definition into an executable form. It's the bridge between the declarative graph structure you've defined and the actual runtime behavior of your AI application.

### Purpose of Compilation:

1. Validation: Compilation checks for structural errors in your graph, such as disconnected nodes or invalid edge definitions.

2. Optimization: The compilation process can apply optimizations to improve the performance of your graph execution.

3. Preparation for Execution: Compilation prepares the graph for efficient execution, setting up the necessary data structures and execution paths.

### The Compilation Process:

When you call the `compile()` method on your graph, LangGraph performs several steps:

1. Graph Validation: It checks that all nodes are reachable, all referenced nodes exist, and there are no circular dependencies that could cause infinite loops.

2. State Validation: It ensures that the state structure you've defined is consistent and that all nodes operate on the correct state type.

3. Edge Resolution: It resolves all edges, including conditional edges, to create a complete map of possible execution paths.

4. Optimization: It may apply optimizations such as function inlining or execution path pre-computation where possible.

5. Execution Preparation: It prepares the graph for execution, which may include setting up caches, initializing state management structures, or preparing for parallel execution where applicable.

### Using Compiled Graphs:

Once compiled, you can use your graph to process inputs and generate outputs. Here's an example of how you might use a compiled graph:

```python
# Assuming we've compiled our conversation graph from earlier
compiled_graph = graph.compile()

# Initial state
initial_state = {
    "user_input": "Hello, AI!",
    "conversation_history": [],
    "response": ""
}

# Run the graph
result = compiled_graph.invoke(initial_state)

print(f"AI Response: {result['response']}")
print(f"Conversation History: {result['conversation_history']}")

# Continue the conversation
while True:
    user_input = input("You: ")
    result = compiled_graph.invoke({**result, "user_input": user_input})
    print(f"AI: {result['response']}")
    if "goodbye" in user_input.lower():
        break
```

In this example, we first invoke the compiled graph with an initial state. Then, we enter a loop where we continually update the state with new user input and invoke the graph again. The graph handles all the processing steps we defined (preprocessing, response generation, history updating) internally.

### Benefits of Compilation:

1. Performance: Compiled graphs can execute more efficiently than interpreted graph structures.

2. Error Detection: Many potential errors are caught at compile-time rather than runtime, improving reliability.

3. Optimization: The compilation process can apply optimizations that wouldn't be possible with a purely interpreted approach.

4. Separation of Concerns: Compilation separates the graph definition (what your AI should do) from its execution (how it actually runs), allowing you to focus on the logic of your AI workflow when building the graph.

### Best Practices for Graph Compilation:

1. Compile Once, Run Many: Compile your graph once and reuse the compiled version for multiple executions, rather than recompiling for each run.

2. Error Handling: Pay attention to any errors or warnings raised during compilation. They often indicate issues in your graph structure that could lead to problems during execution.

3. Testing: Create unit tests for your graphs that include the compilation step. This can catch structural issues early in your development process.

4. Version Control: If your graph structure is likely to change over time, consider versioning your compiled graphs alongside your source code.

By understanding the compilation process and following these best practices, you can create more robust, efficient, and maintainable AI applications with LangGraph.

## Conclusion

In this lesson, we've covered the fundamental concepts of LangGraph: State, Channels, Graph Structure, and Compilation. These elements form the backbone of LangGraph applications, allowing you to create sophisticated, stateful AI workflows with clear, modular structures.

- State provides a flexible, persistent way to maintain context across your AI application.
- Channels offer fine-grained control over how information flows and updates through your graph.
- Graph Structure allows you to define complex, branching workflows with parallel processing and conditional paths.
- Compilation bridges the gap between your graph definition and its efficient execution.

As you move forward in your LangGraph journey, keep these concepts in mind. They'll serve as the building blocks for creating powerful, flexible AI applications that can handle complex, multi-step reasoning processes and maintain rich context over extended interactions.

In the next lesson, we'll build on these fundamentals to create your first complete LangGraph application, putting all these concepts into practice in a real-world scenario.

