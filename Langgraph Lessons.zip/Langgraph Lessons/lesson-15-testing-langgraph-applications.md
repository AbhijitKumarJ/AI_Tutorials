# Lesson 15: Testing LangGraph Applications

## Introduction

Welcome to Lesson 15 of our LangGraph mastery series. In this lesson, we'll delve into the critical topic of testing LangGraph applications. As you build more complex graph-based AI systems, ensuring their reliability, correctness, and robustness becomes increasingly important. We'll explore various testing strategies and techniques specifically tailored for LangGraph applications, from unit testing individual components to integration testing of entire graphs.

## Learning Objectives

By the end of this lesson, you will be able to:

1. Implement unit tests for individual graph components
2. Design and execute integration tests for complex workflows
3. Utilize mocking techniques to isolate components during testing
4. Apply property-based testing to graph structures
5. Develop continuous testing strategies for LangGraph projects

## 1. Unit Testing Graph Components

Unit testing is the practice of testing individual components of your application in isolation. In the context of LangGraph, this often means testing individual nodes and their functions.

### 1.1 Testing Individual Nodes

When testing individual nodes, we want to ensure that given a specific input state, the node produces the expected output state. Here's an example of how you might unit test a node:

```python
import unittest
from langgraph.graph import StateGraph, END
from typing import TypedDict

class State(TypedDict):
    count: int

def increment_node(state: State) -> State:
    state["count"] += 1
    return state

class TestIncrementNode(unittest.TestCase):
    def test_increment_node(self):
        initial_state = {"count": 0}
        expected_state = {"count": 1}
        result = increment_node(initial_state)
        self.assertEqual(result, expected_state)

    def test_increment_node_negative(self):
        initial_state = {"count": -1}
        expected_state = {"count": 0}
        result = increment_node(initial_state)
        self.assertEqual(result, expected_state)

if __name__ == '__main__':
    unittest.main()
```

In this example, we're testing the `increment_node` function to ensure it correctly increments the `count` value in the state. We test both a positive and negative initial count to cover different scenarios.

### 1.2 Testing State Transitions

It's also important to test how state transitions occur within your graph. Here's an example of testing a simple graph with state transitions:

```python
import unittest
from langgraph.graph import StateGraph, END
from typing import TypedDict

class State(TypedDict):
    value: int
    done: bool

def process_node(state: State) -> State:
    state["value"] *= 2
    if state["value"] > 100:
        state["done"] = True
    return state

class TestStateTransitions(unittest.TestCase):
    def setUp(self):
        self.graph = StateGraph(State)
        self.graph.add_node("process", process_node)
        self.graph.add_edge("process", "process")
        self.graph.add_edge("process", END, lambda s: s["done"])
        self.compiled_graph = self.graph.compile()

    def test_state_transitions(self):
        initial_state = {"value": 10, "done": False}
        result = self.compiled_graph.invoke(initial_state)
        self.assertEqual(result["value"], 160)
        self.assertTrue(result["done"])

    def test_early_termination(self):
        initial_state = {"value": 60, "done": False}
        result = self.compiled_graph.invoke(initial_state)
        self.assertEqual(result["value"], 120)
        self.assertTrue(result["done"])

if __name__ == '__main__':
    unittest.main()
```

In this example, we're testing a graph that doubles a value until it exceeds 100. We test both a case where multiple iterations are needed and a case where the process terminates after a single iteration.

## 2. Integration Testing for Complex Workflows

While unit tests are great for testing individual components, integration tests ensure that these components work together correctly in the context of your entire graph.

### 2.1 Testing End-to-End Workflows

Here's an example of an integration test for a more complex workflow:

```python
import unittest
from langgraph.graph import StateGraph, END
from typing import TypedDict

class State(TypedDict):
    input: str
    processed: str
    output: str

def preprocess_node(state: State) -> State:
    state["processed"] = state["input"].lower()
    return state

def process_node(state: State) -> State:
    state["output"] = ''.join(sorted(state["processed"]))
    return state

class TestWorkflow(unittest.TestCase):
    def setUp(self):
        self.graph = StateGraph(State)
        self.graph.add_node("preprocess", preprocess_node)
        self.graph.add_node("process", process_node)
        self.graph.add_edge("preprocess", "process")
        self.graph.add_edge("process", END)
        self.compiled_graph = self.graph.compile()

    def test_end_to_end_workflow(self):
        initial_state = {"input": "Hello World", "processed": "", "output": ""}
        expected_output = "dehllloorw"
        result = self.compiled_graph.invoke(initial_state)
        self.assertEqual(result["output"], expected_output)

if __name__ == '__main__':
    unittest.main()
```

This integration test verifies that the entire workflow, from input to output, functions correctly. It tests the interaction between the `preprocess_node` and `process_node`, ensuring that the final output is as expected.

### 2.2 Testing Error Handling and Edge Cases

It's crucial to test how your graph handles errors and edge cases. Here's an example:

```python
import unittest
from langgraph.graph import StateGraph, END
from typing import TypedDict

class State(TypedDict):
    input: int
    output: int

def divide_node(state: State) -> State:
    if state["input"] == 0:
        raise ValueError("Cannot divide by zero")
    state["output"] = 100 // state["input"]
    return state

class TestErrorHandling(unittest.TestCase):
    def setUp(self):
        self.graph = StateGraph(State)
        self.graph.add_node("divide", divide_node)
        self.graph.add_edge("divide", END)
        self.compiled_graph = self.graph.compile()

    def test_normal_case(self):
        initial_state = {"input": 4, "output": 0}
        result = self.compiled_graph.invoke(initial_state)
        self.assertEqual(result["output"], 25)

    def test_edge_case(self):
        initial_state = {"input": 1, "output": 0}
        result = self.compiled_graph.invoke(initial_state)
        self.assertEqual(result["output"], 100)

    def test_error_case(self):
        initial_state = {"input": 0, "output": 0}
        with self.assertRaises(ValueError):
            self.compiled_graph.invoke(initial_state)

if __name__ == '__main__':
    unittest.main()
```

This test suite covers a normal case, an edge case (dividing by 1), and an error case (dividing by zero), ensuring that the graph behaves correctly in all scenarios.

## 3. Mocking External Dependencies

When testing LangGraph applications, you often need to isolate the component you're testing from its external dependencies. This is where mocking comes in handy.

### 3.1 Mocking API Calls

Here's an example of how you might mock an external API call in a LangGraph node:

```python
import unittest
from unittest.mock import patch
from langgraph.graph import StateGraph, END
from typing import TypedDict

class State(TypedDict):
    query: str
    result: str

def api_node(state: State) -> State:
    # In a real scenario, this would make an API call
    response = make_api_call(state["query"])
    state["result"] = response
    return state

def make_api_call(query: str) -> str:
    # This function would typically make a real API call
    pass

class TestApiNode(unittest.TestCase):
    def setUp(self):
        self.graph = StateGraph(State)
        self.graph.add_node("api", api_node)
        self.graph.add_edge("api", END)
        self.compiled_graph = self.graph.compile()

    @patch('__main__.make_api_call')
    def test_api_node(self, mock_api):
        mock_api.return_value = "Mocked API response"
        initial_state = {"query": "test query", "result": ""}
        result = self.compiled_graph.invoke(initial_state)
        self.assertEqual(result["result"], "Mocked API response")
        mock_api.assert_called_once_with("test query")

if __name__ == '__main__':
    unittest.main()
```

In this example, we're using Python's `unittest.mock` to patch the `make_api_call` function. This allows us to test the `api_node` without actually making an API call, ensuring our tests are fast and don't depend on external services.

### 3.2 Mocking Complex Dependencies

For more complex dependencies, you might need to create mock objects that mimic the behavior of the real dependency. Here's an example:

```python
import unittest
from unittest.mock import MagicMock
from langgraph.graph import StateGraph, END
from typing import TypedDict

class State(TypedDict):
    input: str
    output: str

class ComplexDependency:
    def process(self, input: str) -> str:
        # In reality, this might be a complex operation
        pass

def complex_node(state: State) -> State:
    dependency = ComplexDependency()
    state["output"] = dependency.process(state["input"])
    return state

class TestComplexNode(unittest.TestCase):
    def setUp(self):
        self.graph = StateGraph(State)
        self.graph.add_node("complex", complex_node)
        self.graph.add_edge("complex", END)
        self.compiled_graph = self.graph.compile()

    def test_complex_node(self):
        mock_dependency = MagicMock()
        mock_dependency.process.return_value = "Processed output"
        
        with patch('__main__.ComplexDependency', return_value=mock_dependency):
            initial_state = {"input": "test input", "output": ""}
            result = self.compiled_graph.invoke(initial_state)
            self.assertEqual(result["output"], "Processed output")
            mock_dependency.process.assert_called_once_with("test input")

if __name__ == '__main__':
    unittest.main()
```

In this example, we're creating a mock object for the `ComplexDependency` class and patching it into our test. This allows us to control the behavior of the dependency and verify how it's used within our node.

## 4. Property-Based Testing for Graph Structures

Property-based testing is a powerful technique that generates multiple test cases based on properties that should hold true for your code. It's particularly useful for testing graph structures where you want to ensure certain invariants hold across many different inputs.

### 4.1 Testing Graph Invariants

Here's an example of how you might use property-based testing to verify invariants in a LangGraph application:

```python
import hypothesis
from hypothesis import given, strategies as st
from langgraph.graph import StateGraph, END
from typing import TypedDict

class State(TypedDict):
    value: int

def process_node(state: State) -> State:
    state["value"] *= 2
    return state

class TestGraphProperties(unittest.TestCase):
    def setUp(self):
        self.graph = StateGraph(State)
        self.graph.add_node("process", process_node)
        self.graph.add_edge("process", END)
        self.compiled_graph = self.graph.compile()

    @given(st.integers())
    def test_value_always_even(self, initial_value):
        initial_state = {"value": initial_value}
        result = self.compiled_graph.invoke(initial_state)
        self.assertTrue(result["value"] % 2 == 0)

    @given(st.integers(min_value=1))
    def test_value_increases(self, initial_value):
        initial_state = {"value": initial_value}
        result = self.compiled_graph.invoke(initial_state)
        self.assertTrue(result["value"] > initial_value)

if __name__ == '__main__':
    unittest.main()
```

In this example, we're using the Hypothesis library to generate test cases. We're testing two properties:

1. The output value is always even, regardless of the input.
2. For positive inputs, the output value is always greater than the input.

These tests will run multiple times with different randomly generated inputs, helping to catch edge cases that we might not have thought of when writing manual tests.

### 4.2 Testing Graph Structure Properties

We can also use property-based testing to verify properties of the graph structure itself:

```python
from hypothesis import given, strategies as st
from langgraph.graph import StateGraph, END
from typing import TypedDict

class State(TypedDict):
    value: int

def node_a(state: State) -> State:
    state["value"] += 1
    return state

def node_b(state: State) -> State:
    state["value"] *= 2
    return state

@given(st.lists(st.sampled_from(["a", "b"]), min_size=1, max_size=10))
def test_graph_composition(node_sequence):
    graph = StateGraph(State)
    graph.add_node("a", node_a)
    graph.add_node("b", node_b)
    
    for i in range(len(node_sequence) - 1):
        graph.add_edge(node_sequence[i], node_sequence[i+1])
    graph.add_edge(node_sequence[-1], END)
    
    compiled_graph = graph.compile()
    
    initial_state = {"value": 1}
    result = compiled_graph.invoke(initial_state)
    
    # The final value should always be positive
    assert result["value"] > 0
    
    # The final value should be odd if and only if the last operation was "a"
    assert (result["value"] % 2 == 1) == (node_sequence[-1] == "a")

```

This test generates random sequences of nodes and verifies that certain properties hold regardless of the graph structure.

## 5. Continuous Testing Strategies

Implementing a continuous testing strategy is crucial for maintaining the reliability of your LangGraph applications as they evolve. Here are some key components of a continuous testing strategy:

### 5.1 Automated Test Suites

Create comprehensive automated test suites that cover unit tests, integration tests, and property-based tests. These should run automatically whenever changes are made to your codebase.

### 5.2 Continuous Integration (CI)

Set up a CI pipeline that runs your test suite on every commit or pull request. This helps catch issues early in the development process. Here's an example of what a GitHub Actions workflow for a LangGraph project might look like:

```yaml
name: LangGraph CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Run tests
      run: python -m unittest discover tests
```

### 5.3 Code Coverage

Use code coverage tools to ensure that your tests are adequately exercising your codebase. Aim for high coverage, especially in critical parts of your application.

### 5.4 Performance Testing

Incorporate performance tests into your continuous testing strategy. This can help catch performance regressions early.

```python
import unittest
import time
from langgraph.graph import StateGraph, END

class PerformanceTests(unittest.TestCase):
    def setUp(self):
        # Set up your graph here
        pass

    def test_graph_performance(self):
        start_time = time.time()
        # Run your graph here
        end_time = time.time()
        
        execution_time = end_time - start_time
        self.assertLess(execution_time, 1.0)  # Assert that execution takes less than 1 second
```

## Conclusion

In this lesson, we've covered a wide range of testing strategies for LangGraph applications, from unit testing individual components to integration testing complex workflows. We've explored techniques for mocking external dependencies, applying property-based testing to graph structures, and implementing continuous testing strategies.

Remember that effective testing is crucial for building reliable and maintainable LangGraph applications. As you develop more complex graph-based AI systems, investing time in comprehensive testing will pay off in the form of fewer bugs, easier maintenance, and more confident development.

## Practice Exercises

To reinforce your learning, try the following exercises:

1. Write a comprehensive test suite for a LangGraph application that includes at least five different nodes. Include unit tests for each node and integration tests for the entire graph.

2. Implement property-based tests for a graph that processes numerical data. Define at least three properties that should hold true for any input.

3. Create a mock for an external API in a LangGraph node, and write tests that verify the node's behavior with different mock responses.

4. Set up a continuous integration pipeline for a LangGraph project using a tool of your choice (e.g., GitHub Actions, GitLab CI, Jenkins).

5. Write performance tests for a LangGraph application and integrate them into your CI pipeline.

By completing these exercises, you'll gain practical experience in applying the testing techniques covered in this lesson to real-world LangGraph applications.

