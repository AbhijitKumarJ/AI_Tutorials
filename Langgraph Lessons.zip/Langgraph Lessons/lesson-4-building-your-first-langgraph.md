# Lesson 4: Building Your First LangGraph

In this lesson, we'll put the concepts we've learned into practice by building a complete LangGraph application. We'll create a simple but functional AI assistant that can engage in conversation, answer questions, and perform basic tasks. This hands-on experience will help solidify your understanding of LangGraph's core components and give you a foundation for building more complex applications.

## Project Overview: AI Assistant

Our AI assistant will be able to:
1. Engage in general conversation
2. Answer questions by searching the internet
3. Perform simple calculations
4. Remember context from earlier in the conversation

We'll build this assistant step-by-step, explaining each component as we go.

## Step 1: Setting Up the Project

First, let's set up our project structure and install the necessary dependencies.

1. Create a new directory for your project:
   ```
   mkdir ai_assistant
   cd ai_assistant
   ```

2. Create a virtual environment and activate it:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
   ```

3. Install the required packages:
   ```
   pip install langgraph langchain openai
   ```

4. Create a new Python file for our assistant:
   ```
   touch ai_assistant.py
   ```

## Step 2: Defining the State

Let's start by defining the state for our AI assistant. Open `ai_assistant.py` and add the following code:

```python
from typing import List, TypedDict, Annotated
from langgraph.channels import Topic, LastValue, BinaryOperatorAggregate
from operator import add

class AssistantState(TypedDict):
    conversation_history: Annotated[List[str], Topic()]
    current_query: Annotated[str, LastValue()]
    response: Annotated[str, LastValue()]
    context: Annotated[str, LastValue()]
    interaction_count: Annotated[int, BinaryOperatorAggregate(add)]
```

Here's what each part of our state represents:
- `conversation_history`: A list of all messages in the conversation.
- `current_query`: The user's most recent input.
- `response`: The assistant's most recent response.
- `context`: Any additional context the assistant should consider.
- `interaction_count`: A running count of interactions.

We're using different channel types to manage how each piece of state is updated:
- `Topic()` for `conversation_history` ensures we keep a full history.
- `LastValue()` for `current_query`, `response`, and `context` keeps only the most recent value.
- `BinaryOperatorAggregate(add)` for `interaction_count` allows us to increment the count easily.

## Step 3: Creating the Graph Structure

Now, let's create the basic structure of our graph:

```python
from langgraph.graph import StateGraph, END

# Create the graph
graph = StateGraph(AssistantState)

# Define node functions (we'll implement these later)
def process_input(state: AssistantState) -> AssistantState:
    # Process the user's input
    pass

def generate_response(state: AssistantState) -> AssistantState:
    # Generate a response
    pass

def update_context(state: AssistantState) -> AssistantState:
    # Update the context based on the conversation
    pass

# Add nodes to the graph
graph.add_node("process_input", process_input)
graph.add_node("generate_response", generate_response)
graph.add_node("update_context", update_context)

# Define edges
graph.add_edge("process_input", "generate_response")
graph.add_edge("generate_response", "update_context")

# Set the entry point
graph.set_entry_point("process_input")

# Define end condition
def should_end(state: AssistantState) -> bool:
    return "goodbye" in state['current_query'].lower()

graph.add_conditional_edges(
    "update_context",
    should_end,
    {
        True: END,
        False: "process_input"
    }
)
```

This graph structure defines the flow of our assistant:
1. Process the user's input
2. Generate a response
3. Update the context
4. Check if the conversation should end. If not, loop back to process the next input.

## Step 4: Implementing Node Functions

Now let's implement the functions for each node:

```python
from langchain.llms import OpenAI
from langchain.tools import GoogleSearchAPIWrapper, Tool
from langchain.agents import initialize_agent, AgentType

# Initialize LLM and tools
llm = OpenAI(temperature=0.7)
search = GoogleSearchAPIWrapper()
tools = [
    Tool(
        name="Search",
        func=search.run,
        description="useful for when you need to answer questions about current events"
    )
]
agent = initialize_agent(tools, llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, verbose=True)

def process_input(state: AssistantState) -> AssistantState:
    # Add the current query to the conversation history
    return {
        **state,
        "conversation_history": [state["current_query"]],
        "interaction_count": 1
    }

def generate_response(state: AssistantState) -> AssistantState:
    # Combine conversation history and context
    full_context = "\n".join(state["conversation_history"]) + "\nContext: " + state["context"]
    
    # Generate a response using the agent
    response = agent.run(f"{full_context}\nHuman: {state['current_query']}\nAI:")
    
    return {
        **state,
        "response": response,
        "conversation_history": [response]
    }

def update_context(state: AssistantState) -> AssistantState:
    # For simplicity, we'll just use the last exchange as context
    new_context = f"Last exchange - Human: {state['current_query']} AI: {state['response']}"
    return {**state, "context": new_context}
```

In these implementations:
- `process_input` adds the current query to the conversation history and increments the interaction count.
- `generate_response` uses a LangChain agent to generate a response based on the conversation history, context, and current query.
- `update_context` creates a new context based on the last exchange.

## Step 5: Compiling and Running the Graph

Finally, let's compile our graph and create a function to run the assistant:

```python
# Compile the graph
compiled_graph = graph.compile()

def run_assistant():
    # Initial state
    initial_state = {
        "conversation_history": [],
        "current_query": "",
        "response": "",
        "context": "",
        "interaction_count": 0
    }
    
    print("AI Assistant: Hello! How can I help you today?")
    
    while True:
        user_input = input("You: ")
        result = compiled_graph.invoke({**initial_state, "current_query": user_input})
        print(f"AI Assistant: {result['response']}")
        
        if "goodbye" in user_input.lower():
            print("AI Assistant: Goodbye! Have a great day!")
            break
        
        # Update the initial state for the next iteration
        initial_state = result

if __name__ == "__main__":
    run_assistant()
```

This final piece compiles our graph and provides a simple interface to interact with our AI assistant.

## Running the Assistant

To run your AI assistant, simply execute the Python script:

```
python ai_assistant.py
```

You should now be able to interact with your AI assistant! It will engage in conversation, answer questions using internet search when necessary, and maintain context throughout the interaction.

## Conclusion

Congratulations! You've built your first LangGraph application. This simple AI assistant demonstrates several key concepts:

1. State Management: We used various channel types to manage different aspects of the assistant's state.
2. Graph Structure: We defined a clear flow for processing inputs, generating responses, and updating context.
3. Node Implementation: We created node functions that interact with external tools (like the search API) and maintain conversation state.
4. Compilation and Execution: We compiled the graph and created a simple interface for interacting with the assistant.

While this is a basic implementation, it provides a solid foundation for more complex applications. You could extend this assistant by:

- Adding more sophisticated context management
- Incorporating additional tools and APIs
- Implementing more advanced natural language processing
- Adding error handling and fallback mechanisms

Remember, the power of LangGraph lies in its flexibility and modularity. As you build more complex applications, you can easily add new nodes, rearrange your graph structure, or incorporate subgraphs for specific functionalities.

In the next lesson, we'll explore more advanced graph structures and techniques for handling complex workflows. Keep experimenting with your assistant, and don't hesitate to



Remember, the power of LangGraph lies in its flexibility and modularity. As you build more complex applications, you can easily add new nodes, rearrange your graph structure, or incorporate subgraphs for specific functionalities.

## Exercises for Practice

To reinforce your understanding and encourage experimentation, try these exercises:

1. Error Handling: Add a new node to the graph that handles errors (e.g., if the internet search fails). Update the graph structure to incorporate this error handling node.

2. Sentiment Analysis: Implement a sentiment analysis node that analyzes the user's input. Use this to adjust the assistant's response tone.

3. Multiple Tools: Add more tools to the agent (e.g., a weather API, a calculator). Modify the `generate_response` function to use these new tools when appropriate.

4. Conversation Summary: Create a new node that periodically summarizes the conversation. Add this summary to the context to give the assistant a broader view of the conversation history.

5. User Preferences: Extend the state to include user preferences (e.g., verbose or concise responses). Implement a node that sets these preferences based on user input, and modify the response generation to respect these preferences.

## Final Thoughts

Building this AI assistant has given you hands-on experience with the core concepts of LangGraph:

- Defining and managing state
- Creating a graph structure
- Implementing node functions
- Compiling and running a graph

As you work on the exercises and continue to expand your assistant, you'll gain a deeper understanding of how these components work together to create flexible, powerful AI applications.

Remember that LangGraph is a tool that shines in complex, stateful applications. As you build more sophisticated systems, you'll find even more opportunities to leverage its strengths in managing workflow, maintaining context, and coordinating multiple AI components.

In the next lesson, we'll dive into advanced graph structures, exploring how to create more complex workflows, handle parallel processing, and implement sophisticated decision-making processes. Until then, happy coding, and enjoy experimenting with your new AI assistant!

