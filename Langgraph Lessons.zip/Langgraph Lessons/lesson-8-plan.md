# Lesson 8: Tools and External Integrations

## 1. Introduction (15 minutes)

Welcome to Lesson 8 of our LangGraph course! In this lesson, we'll dive deep into the concept of tools and external integrations within LangGraph. Tools are a powerful feature that allow our language models and graph structures to interact with the outside world, greatly expanding the capabilities of our AI systems.

### What are tools in LangGraph?

Tools in LangGraph are essentially functions or classes that enable our graph nodes to perform specific actions or retrieve information from external sources. They act as bridges between our AI models and the vast world of data and services available outside the immediate context of our application.

### Why are tools important?

Tools are crucial because they allow us to create more versatile and powerful AI applications. By integrating external services and data sources, we can build systems that not only process language but also interact with real-world information and perform concrete actions. This opens up a wide range of possibilities, from creating AI assistants that can book appointments to developing complex decision-making systems that consider real-time data.

## 2. Understanding the Concept of Tools in LangGraph (30 minutes)

Let's delve deeper into how tools work within the LangGraph framework.

### Tool Structure

In LangGraph, a tool is typically represented as a Python function or class that takes specific inputs and returns outputs. These tools are designed to be easily integrated into our graph structures and can be called by our language models when needed.

Here's a basic structure of a tool function:

```python
def simple_tool(input_parameter: str) -> str:
    # Tool logic here
    result = process_input(input_parameter)
    return result
```

And here's how a tool might be structured as a class:

```python
class ComplexTool:
    def __init__(self, config_parameter: str):
        self.config = config_parameter

    def __call__(self, input_parameter: str) -> str:
        # Tool logic here
        result = self.process_input(input_parameter)
        return result

    def process_input(self, input_parameter: str) -> str:
        # Processing logic
        return f"Processed: {input_parameter} with config {self.config}"
```

### Tool Registration

To use tools in LangGraph, we need to register them with our language model or graph structure. This is typically done using a decorator or a specific registration method provided by LangGraph.

Here's an example of how tool registration might look:

```python
from langgraph.prebuilt import ToolNode

tools = [simple_tool, ComplexTool("some_config")]
tool_node = ToolNode(tools=tools)

graph.add_node("tool_executor", tool_node)
```

### Tool Invocation

Once registered, tools can be invoked by our language model when it determines that external information or actions are needed. The language model will typically output a structured format indicating which tool to use and with what parameters.

For example, a language model might output:

```json
{
  "tool": "simple_tool",
  "parameters": {
    "input_parameter": "some input"
  }
}
```

LangGraph would then interpret this output and call the appropriate tool with the given parameters.

## 3. Implementing and Using Custom Tools (45 minutes)

Now that we understand the basics, let's create and implement some custom tools.

### Example: Weather Information Tool

Let's create a tool that fetches weather information for a given city. We'll use a hypothetical weather API for this example.

First, let's set up our project structure:

```
weather_bot/
├── main.py
├── tools/
│   ├── __init__.py
│   └── weather_tool.py
└── requirements.txt
```

Now, let's implement our weather tool in `weather_tool.py`:

```python
import requests

class WeatherTool:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.weatherapi.com/v1/current.json"

    def __call__(self, city: str) -> str:
        params = {
            "key": self.api_key,
            "q": city
        }
        response = requests.get(self.base_url, params=params)
        if response.status_code == 200:
            data = response.json()
            temp_c = data['current']['temp_c']
            condition = data['current']['condition']['text']
            return f"The current weather in {city} is {condition} with a temperature of {temp_c}°C."
        else:
            return f"Sorry, I couldn't fetch the weather information for {city}."

def get_weather_tool(api_key: str):
    return WeatherTool(api_key)
```

Now, let's use this tool in our main LangGraph application. In `main.py`:

```python
from langgraph.graph import StateGraph
from langgraph.prebuilt import ToolNode, create_react_agent
from langchain_anthropic import ChatAnthropic
from tools.weather_tool import get_weather_tool

# Set up our graph
graph_builder = StateGraph()

# Set up our language model
llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")

# Set up our tools
weather_tool = get_weather_tool("your_api_key_here")
tools = [weather_tool]

# Create our agent
agent = create_react_agent(llm, tools, prompt="You are a helpful assistant that can provide weather information.")

# Add nodes to our graph
graph_builder.add_node("agent", agent)
graph_builder.add_node("tools", ToolNode(tools=tools))

# Add edges
graph_builder.add_edge("agent", "tools")
graph_builder.add_edge("tools", "agent")

# Compile the graph
graph = graph_builder.compile()

# Run the graph
result = graph.invoke({"input": "What's the weather like in London?"})
print(result)
```

This example demonstrates how we can create a custom tool (the weather tool) and integrate it into a LangGraph application. The language model can now access real-time weather data, greatly enhancing its capabilities.

## 4. Integrating External APIs and Services (30 minutes)

The weather tool we created is a great example of integrating an external API. Let's discuss some best practices and considerations when working with external services:

### API Keys and Security

When working with external APIs, we often need to use API keys or other forms of authentication. It's crucial to handle these securely:

1. Never hardcode API keys in your source code.
2. Use environment variables or secure configuration management systems to store sensitive information.
3. If your application is open source, make sure to include instructions for users to obtain and configure their own API keys.

### Error Handling

External services can fail or be unavailable. Always implement proper error handling:

1. Use try-except blocks to catch and handle exceptions.
2. Implement retry logic for transient failures.
3. Provide meaningful error messages to the user when a service is unavailable.

### Rate Limiting

Many APIs have rate limits. Respect these limits to ensure your application doesn't get blocked:

1. Implement exponential backoff for retries.
2. Use caching where appropriate to reduce the number of API calls.
3. Consider using a rate limiting library to manage your API requests.

## 5. Creating Tool-Using Agents (30 minutes)

Now that we have our tools set up, let's discuss how to create agents that can effectively use these tools.

### Prompt Engineering

The key to creating effective tool-using agents lies in prompt engineering. We need to design our prompts in a way that encourages the language model to use tools when appropriate.

Here's an example of a prompt that encourages tool use:

```python
PROMPT = """You are an AI assistant capable of using various tools to help users.
When you need information that you don't have, use the appropriate tool to find it.
Always use tools when asked about specific, current information like weather or news.

Available tools:
{tool_descriptions}