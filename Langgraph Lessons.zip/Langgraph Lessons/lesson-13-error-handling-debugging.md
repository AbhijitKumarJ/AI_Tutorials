# Lesson 13: Error Handling and Debugging in LangGraph

## Introduction

Welcome to Lesson 13 of our LangGraph mastery series. In this lesson, we'll dive deep into error handling and debugging techniques specifically tailored for LangGraph applications. As you build more complex graph-based systems, you'll inevitably encounter errors and unexpected behaviors. Understanding how to effectively handle these issues and debug your LangGraph applications is crucial for developing robust and reliable AI systems.

## Learning Objectives

By the end of this lesson, you will be able to:

1. Identify and understand common errors in LangGraph applications
2. Implement effective error handling strategies
3. Apply debugging techniques specific to graph-based applications
4. Create and use custom error types for graph-specific issues
5. Utilize logging effectively in LangGraph applications

## 1. Common Errors in LangGraph Applications

Let's start by exploring some of the most common errors you might encounter when working with LangGraph. Understanding these errors will help you anticipate potential issues and implement appropriate error handling strategies.

### 1.1 State-related Errors

One of the most common sources of errors in LangGraph applications is related to state management. These errors often occur when there's a mismatch between the expected state structure and the actual state during graph execution.

Example of a state-related error:

```python
from langgraph.graph import StateGraph, END

class State(TypedDict):
    counter: int

def increment_counter(state):
    state["counter"] += 1
    return state

graph = StateGraph(State)
graph.add_node("increment", increment_counter)
graph.add_edge("increment", END)

# This will raise a KeyError because 'counter' is not initialized
result = graph.invoke({})
```

In this example, we're trying to increment a counter that doesn't exist in the initial state. To prevent this error, we should ensure that the state is properly initialized before invoking the graph:

```python
result = graph.invoke({"counter": 0})
```

### 1.2 Type Mismatch Errors

Another common issue arises when the types of data flowing through the graph don't match the expected types. This can happen when nodes return unexpected data types or when the initial state doesn't conform to the defined structure.

Example of a type mismatch error:

```python
from typing import Annotated
from langgraph.graph import StateGraph, END

class State(TypedDict):
    messages: Annotated[list[str], "add"]

def add_message(state):
    state["messages"].append("New message")
    return state

graph = StateGraph(State)
graph.add_node("add_message", add_message)
graph.add_edge("add_message", END)

# This will raise an AttributeError because 'messages' is not a list
result = graph.invoke({"messages": "Not a list"})
```

To fix this, ensure that the initial state matches the expected structure:

```python
result = graph.invoke({"messages": []})
```

### 1.3 Circular Dependencies

When designing complex graphs, it's possible to accidentally create circular dependencies between nodes. This can lead to infinite loops or unexpected behavior.

Example of a circular dependency:

```python
from langgraph.graph import StateGraph

class State(TypedDict):
    value: int

def node_a(state):
    state["value"] += 1
    return state

def node_b(state):
    state["value"] *= 2
    return state

graph = StateGraph(State)
graph.add_node("A", node_a)
graph.add_node("B", node_b)
graph.add_edge("A", "B")
graph.add_edge("B", "A")  # This creates a circular dependency

# This will result in an infinite loop
graph.invoke({"value": 1})
```

To avoid circular dependencies, carefully design your graph structure and use conditional edges or explicit end conditions.

## 2. Implementing Effective Error Handling

Now that we've identified some common errors, let's explore strategies for handling them effectively in LangGraph applications.

### 2.1 Using Try-Except Blocks

One of the most basic error handling techniques is using try-except blocks. This allows you to catch and handle specific exceptions that might occur during graph execution.

Example of using try-except in a node:

```python
def safe_increment(state):
    try:
        state["counter"] += 1
    except KeyError:
        # Handle the case where 'counter' doesn't exist
        state["counter"] = 1
    except TypeError:
        # Handle the case where 'counter' is not a number
        state["counter"] = int(state["counter"]) + 1
    return state

graph = StateGraph(State)
graph.add_node("safe_increment", safe_increment)
graph.add_edge("safe_increment", END)

# Now this won't raise an error, even if 'counter' is missing or of the wrong type
result = graph.invoke({})
```

### 2.2 Implementing Default Values

Another effective strategy is to implement default values for your state. This can help prevent errors caused by missing or incorrectly initialized state values.

Example of using default values:

```python
from typing import Annotated

class State(TypedDict):
    counter: Annotated[int, "default=0"]
    messages: Annotated[list[str], "default=[]"]

def increment_and_add_message(state):
    state["counter"] += 1
    state["messages"].append(f"Counter incremented to {state['counter']}")
    return state

graph = StateGraph(State)
graph.add_node("process", increment_and_add_message)
graph.add_edge("process", END)

# This will work even if the initial state is empty
result = graph.invoke({})
```

### 2.3 Using Validators

LangGraph allows you to define validators for your state and channel values. Validators can help catch errors early by ensuring that the data flowing through your graph meets certain criteria.

Example of using a validator:

```python
from pydantic import BaseModel, validator

class StateModel(BaseModel):
    counter: int
    messages: list[str]

    @validator('counter')
    def counter_must_be_positive(cls, v):
        if v < 0:
            raise ValueError('Counter must be non-negative')
        return v

class State(TypedDict):
    state: Annotated[StateModel, "validate"]

def process(state):
    state.state.counter += 1
    state.state.messages.append(f"Counter: {state.state.counter}")
    return state

graph = StateGraph(State)
graph.add_node("process", process)
graph.add_edge("process", END)

# This will raise a ValidationError because the counter is negative
try:
    result = graph.invoke({"state": StateModel(counter=-1, messages=[])})
except ValueError as e:
    print(f"Validation error: {e}")
```

## 3. Debugging Techniques for Graph-based Applications

Debugging graph-based applications can be challenging due to their complex nature. Here are some techniques specifically useful for debugging LangGraph applications.

### 3.1 Using Print Statements

While simple, print statements can be very effective for understanding the flow of data through your graph and identifying where errors occur.

Example of using print statements for debugging:

```python
def debug_node(state):
    print(f"Entering debug_node. State: {state}")
    try:
        result = some_operation(state)
        print(f"Operation successful. Result: {result}")
    except Exception as e:
        print(f"Error in debug_node: {e}")
        raise
    print(f"Exiting debug_node. New state: {state}")
    return state

graph.add_node("debug", debug_node)
```

### 3.2 Utilizing LangGraph's Built-in Debugging Features

LangGraph provides built-in debugging features that can help you understand the execution flow of your graph. One such feature is the ability to stream execution events.

Example of using event streaming for debugging:

```python
graph = StateGraph(State)
# ... add nodes and edges ...

compiled_graph = graph.compile()

for event in compiled_graph.stream({"initial": "state"}, stream_mode="debug"):
    print(f"Event: {event}")
```

This will print detailed information about each step of the graph execution, including which nodes are being executed and how the state is changing.

### 3.3 Using Breakpoints

If you're using an IDE with debugging capabilities, you can set breakpoints in your node functions to pause execution and inspect the state at specific points.

Example of setting a breakpoint in PyCharm:

```python
def breakpoint_node(state):
    # Set a breakpoint on the next line
    state["counter"] += 1
    return state

graph.add_node("breakpoint", breakpoint_node)
```

When you run your graph in debug mode and execution reaches this node, it will pause, allowing you to inspect the current state and step through the execution.

## 4. Creating Custom Error Types

For more specific error handling, you can create custom error types that are tailored to your LangGraph application.

Example of custom error types:

```python
class GraphStateError(Exception):
    """Base class for errors related to graph state"""
    pass

class InvalidStateTransitionError(GraphStateError):
    """Raised when an invalid state transition is attempted"""
    pass

class NodeExecutionError(GraphStateError):
    """Raised when there's an error executing a specific node"""
    def __init__(self, node_name, original_error):
        self.node_name = node_name
        self.original_error = original_error
        super().__init__(f"Error in node '{node_name}': {original_error}")

def risky_node(state):
    try:
        # Some risky operation
        if state["value"] < 0:
            raise InvalidStateTransitionError("Value cannot be negative")
        state["value"] = 1 / state["value"]
    except Exception as e:
        raise NodeExecutionError("risky_node", e)
    return state

graph.add_node("risky", risky_node)
```

Using custom error types allows you to handle specific error scenarios more effectively and provide more informative error messages.

## 5. Effective Logging in LangGraph Applications

Logging is crucial for understanding the behavior of your LangGraph applications, especially in production environments where you can't use interactive debugging techniques.

### 5.1 Setting Up Logging

First, let's set up a basic logging configuration:

```python
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
```

### 5.2 Logging in Nodes

Now, let's use logging in our node functions:

```python
def logged_node(state):
    logger.info(f"Entered logged_node with state: {state}")
    try:
        state["value"] *= 2
        logger.debug(f"State value doubled: {state['value']}")
    except KeyError:
        logger.error("KeyError: 'value' not found in state")
        state["value"] = 0
    except Exception as e:
        logger.exception(f"Unexpected error in logged_node: {e}")
        raise
    logger.info(f"Exiting logged_node with state: {state}")
    return state

graph.add_node("logged", logged_node)
```

### 5.3 Logging Graph Execution

You can also log the overall execution of your graph:

```python
def execute_graph(initial_state):
    logger.info(f"Starting graph execution with initial state: {initial_state}")
    try:
        result = graph.invoke(initial_state)
        logger.info(f"Graph execution completed successfully. Final state: {result}")
        return result
    except Exception as e:
        logger.error(f"Graph execution failed: {e}")
        raise

execute_graph({"value": 10})
```

By implementing comprehensive logging, you can track the flow of your graph execution, making it easier to identify and debug issues, especially in production environments.

## Conclusion

In this lesson, we've covered essential techniques for error handling and debugging in LangGraph applications. We've explored common errors, implemented effective error handling strategies, discussed debugging techniques specific to graph-based applications, created custom error types, and utilized logging for better visibility into graph execution.

Remember, robust error handling and effective debugging are crucial for building reliable and maintainable LangGraph applications. As you continue to work with LangGraph, you'll develop a deeper understanding of these techniques and how to apply them in various scenarios.

## Practice Exercises

To reinforce your learning, try the following exercises:

1. Create a LangGraph application that implements at least three different nodes, and add comprehensive error handling to each node.
2. Implement a custom error type for a specific error scenario in your graph, and demonstrate how to handle it effectively.
3. Set up logging for your LangGraph application, ensuring that you log important events at appropriate levels (INFO, DEBUG, ERROR, etc.).
4. Use LangGraph's event streaming feature to debug a complex graph execution, and analyze the output to understand the flow of data through your graph.

By completing these exercises, you'll gain practical experience in applying the concepts covered in this lesson to real-world LangGraph applications.

