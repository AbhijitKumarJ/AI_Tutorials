# Lesson 17: Real-world Project - Building an Advanced AI Assistant

## Introduction

In this lesson, we'll put all the knowledge and skills we've acquired throughout the course into practice by building an advanced AI assistant using LangGraph. This project will demonstrate how to design and implement a sophisticated AI system that can handle complex workflows, integrate multiple components, and provide a seamless user experience.

Our AI assistant, which we'll call "LangAssist," will be capable of performing various tasks such as answering questions, scheduling appointments, summarizing documents, and even basic code generation. It will leverage the power of large language models, external tools, and the flexible architecture provided by LangGraph.

## Lesson Objectives

By the end of this lesson, you will be able to:

1. Design a complex architecture for an AI assistant using LangGraph
2. Implement advanced workflows that integrate multiple AI components
3. Handle edge cases and ensure robustness in a real-world AI application
4. Create a user-friendly interface for interacting with the AI assistant
5. Apply best practices for testing, debugging, and optimizing a large-scale LangGraph project

## Project Overview: LangAssist

LangAssist will be an AI assistant capable of handling various tasks through natural language interaction. Here's an overview of its key features:

1. Natural Language Understanding: Process and understand user queries
2. Task Routing: Determine the appropriate action based on the user's request
3. Information Retrieval: Search and retrieve relevant information from various sources
4. Appointment Scheduling: Manage and schedule appointments
5. Document Summarization: Summarize long documents or articles
6. Code Generation: Provide basic code snippets based on user requirements
7. Conversational Memory: Maintain context across multiple interactions
8. Multi-turn Dialogue: Handle complex, multi-step conversations

Let's dive into building this advanced AI assistant step by step.

## 1. Designing the Assistant's Architecture

The first step in building our advanced AI assistant is to design its architecture. We'll use LangGraph to create a flexible and modular system that can be easily extended and maintained.

### 1.1 High-level Architecture

Our assistant will consist of several interconnected components:

1. User Interface: Handles user input and output (could be CLI, web interface, or API)
2. Natural Language Understanding (NLU) Module: Processes user input to extract intent and entities
3. Task Router: Determines which module should handle the user's request
4. Task-specific Modules: Specialized components for different tasks (e.g., scheduling, summarization)
5. Knowledge Base: Stores and retrieves information for the assistant to use
6. Conversation Manager: Maintains context and manages multi-turn dialogues

### 1.2 LangGraph Structure

Let's define the basic structure of our LangGraph:

```python
from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode

class AssistantState(TypedDict):
    messages: Annotated[list, "add_messages"]
    current_task: str
    context: dict

graph = StateGraph(AssistantState)

# Define nodes
def nlu_node(state: AssistantState):
    # Process the last user message and extract intent and entities
    # Update the state with the extracted information
    return {"current_task": "determined_task", "context": {"intent": "...", "entities": {...}}}

def task_router(state: AssistantState):
    # Based on the current_task, decide which node to execute next
    task = state["current_task"]
    if task == "scheduling":
        return "scheduling_node"
    elif task == "summarization":
        return "summarization_node"
    # ... other task routes ...
    else:
        return "general_response_node"

def scheduling_node(state: AssistantState):
    # Handle appointment scheduling logic
    # Update the state with scheduling results
    return {"messages": [{"role": "assistant", "content": "Appointment scheduled."}]}

def summarization_node(state: AssistantState):
    # Handle document summarization logic
    # Update the state with summary results
    return {"messages": [{"role": "assistant", "content": "Here's the summary: ..."}]}

def general_response_node(state: AssistantState):
    # Generate a general response using an LLM
    return {"messages": [{"role": "assistant", "content": "I can help you with that."}]}

# Add nodes to the graph
graph.add_node("nlu", nlu_node)
graph.add_node("task_router", task_router)
graph.add_node("scheduling", scheduling_node)
graph.add_node("summarization", summarization_node)
graph.add_node("general_response", general_response_node)

# Define edges
graph.add_edge("nlu", "task_router")
graph.add_conditional_edges("task_router", task_router)
graph.add_edge("scheduling", END)
graph.add_edge("summarization", END)
graph.add_edge("general_response", END)

# Set the entry point
graph.set_entry_point("nlu")

# Compile the graph
assistant = graph.compile()
```

This basic structure provides a foundation for our AI assistant. We'll expand on each component as we build out the functionality.

## 2. Implementing Complex Workflows

Now that we have our basic structure, let's implement some of the complex workflows our assistant will handle.

### 2.1 Natural Language Understanding (NLU)

We'll use a large language model to perform NLU. This will help us extract the user's intent and any relevant entities from their input.

```python
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model_name="gpt-3.5-turbo")

def nlu_node(state: AssistantState):
    user_input = state["messages"][-1]["content"]
    prompt = f"""
    Analyze the following user input and extract the intent and entities:
    User Input: {user_input}
    
    Provide your analysis in the following JSON format:
    {{
        "intent": "The main intention of the user",
        "entities": {{
            "entity1": "value1",
            "entity2": "value2"
        }}
    }}
    """
    
    response = llm.invoke(prompt)
    analysis = json.loads(response.content)
    
    return {
        "current_task": determine_task(analysis["intent"]),
        "context": analysis
    }

def determine_task(intent):
    intent_task_mapping = {
        "schedule": "scheduling",
        "summarize": "summarization",
        "code": "code_generation",
        # Add more mappings as needed
    }
    return intent_task_mapping.get(intent, "general_response")
```

### 2.2 Appointment Scheduling

For appointment scheduling, we'll implement a more complex workflow that handles checking availability, confirming with the user, and updating a calendar.

```python
import datetime

def scheduling_node(state: AssistantState):
    context = state["context"]
    date = context["entities"].get("date")
    time = context["entities"].get("time")
    
    if not date or not time:
        return {
            "messages": [{"role": "assistant", "content": "I need both a date and time to schedule an appointment. Can you provide those?"}],
            "current_task": "scheduling"
        }
    
    # Check availability (implement this function based on your calendar system)
    if is_available(date, time):
        # Confirm with the user
        return {
            "messages": [{"role": "assistant", "content": f"I can schedule an appointment for {date} at {time}. Shall I go ahead and book it?"}],
            "current_task": "confirm_scheduling"
        }
    else:
        alternative = find_next_available_slot(date, time)
        return {
            "messages": [{"role": "assistant", "content": f"I'm sorry, that slot is not available. The next available slot is {alternative}. Would you like me to book that instead?"}],
            "current_task": "suggest_alternative"
        }

def confirm_scheduling_node(state: AssistantState):
    user_response = state["messages"][-1]["content"].lower()
    if "yes" in user_response or "sure" in user_response:
        # Book the appointment (implement this function based on your calendar system)
        book_appointment(state["context"]["entities"]["date"], state["context"]["entities"]["time"])
        return {
            "messages": [{"role": "assistant", "content": "Great! I've booked the appointment for you."}],
            "current_task": END
        }
    else:
        return {
            "messages": [{"role": "assistant", "content": "No problem. Is there another time you'd like me to check?"}],
            "current_task": "scheduling"
        }

# Add these new nodes to the graph
graph.add_node("confirm_scheduling", confirm_scheduling_node)
graph.add_edge("confirm_scheduling", END)
graph.add_edge("confirm_scheduling", "scheduling")
```

### 2.3 Document Summarization

For document summarization, we'll implement a workflow that can handle large documents by breaking them into chunks and summarizing each chunk before creating a final summary.

```python
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_core.prompts import PromptTemplate

def summarization_node(state: AssistantState):
    context = state["context"]
    document_url = context["entities"].get("document_url")
    
    if not document_url:
        return {
            "messages": [{"role": "assistant", "content": "I need a document URL to summarize. Can you provide one?"}],
            "current_task": "summarization"
        }
    
    # Fetch the document content (implement this function based on your document system)
    document_content = fetch_document(document_url)
    
    # Split the document into chunks
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    chunks = text_splitter.split_text(document_content)
    
    # Summarize each chunk
    chunk_summaries = []
    for chunk in chunks:
        summary_prompt = PromptTemplate.from_template("Summarize the following text:\n\n{text}\n\nSummary:")
        chunk_summary = llm.invoke(summary_prompt.format(text=chunk)).content
        chunk_summaries.append(chunk_summary)
    
    # Create a final summary
    final_summary_prompt = PromptTemplate.from_template("Combine the following summaries into a coherent final summary:\n\n{summaries}\n\nFinal Summary:")
    final_summary = llm.invoke(final_summary_prompt.format(summaries="\n\n".join(chunk_summaries))).content
    
    return {
        "messages": [{"role": "assistant", "content": f"Here's a summary of the document:\n\n{final_summary}"}],
        "current_task": END
    }

# Add the summarization node to the graph
graph.add_node("summarization", summarization_node)
```

## 3. Handling Edge Cases and Ensuring Robustness

To make our AI assistant more robust, we need to handle various edge cases and potential errors. Let's implement some error handling and fallback mechanisms.

### 3.1 Input Validation

Add input validation to ensure that the user's input is in a format we can process:

```python
def validate_input(state: AssistantState):
    user_input = state["messages"][-1]["content"]
    if not user_input or len(user_input.strip()) == 0:
        return {
            "messages": [{"role": "assistant", "content": "I'm sorry, but I didn't receive any input. Could you please try again?"}],
            "current_task": "input_validation"
        }
    elif len(user_input) > 1000:  # Arbitrary limit, adjust as needed
        return {
            "messages": [{"role": "assistant", "content": "I'm sorry, but your input is too long for me to process. Could you please try to be more concise?"}],
            "current_task": "input_validation"
        }
    else:
        return {"current_task": "nlu"}

# Add the input validation node to the graph
graph.add_node("input_validation", validate_input)
graph.set_entry_point("input_validation")
graph.add_edge("input_validation", "nlu")
```

### 3.2 Error Handling

Implement a general error handling mechanism to catch and gracefully handle unexpected errors:

```python
import traceback

def error_handler(state: AssistantState, error: Exception):
    error_message = str(error)
    stack_trace = traceback.format_exc()
    
    # Log the error (implement proper logging in a production system)
    print(f"Error occurred: {error_message}\n{stack_trace}")
    
    return {
        "messages": [{"role": "assistant", "content": "I apologize, but I encountered an unexpected error. Could you please try rephrasing your request?"}],
        "current_task": END
    }

# Add error handling to the graph compilation
assistant = graph.compile(error_handler=error_handler)
```

### 3.3 Fallback Mechanism

Implement a fallback mechanism for when the assistant can't understand or handle the user's request:

```python
def fallback_node(state: AssistantState):
    return {
        "messages": [{"role": "assistant", "content": "I'm sorry, but I'm not sure how to help with that request. Could you please try rephrasing it or asking for something else?"}],
        "current_task": END
    }

# Add the fallback node to the graph
graph.add_node("fallback", fallback_node)
graph.add_edge("task_router", "fallback")
```

## 4. User Experience Considerations

To ensure a good user experience, we need to consider factors such as response time, clarity of communication, and handling of multi-turn conversations.

### 4.1 Progress Updates

For long-running tasks, provide progress updates to the user:

```python
def long_running_task_node(state: AssistantState):
    yield {"messages": [{"role": "assistant", "content": "I'm working on that for you. This might take a moment..."}]}
    
    # Simulate a long-running task
    import time
    time.sleep(5)
    
    yield {"messages": [{"role": "assistant", "content": "I'm about halfway done..."}]}
    
    time.sleep(5)
    
    return {"messages": [{"role": "assistant", "content": "I've completed the task. Here are the results..."}]}

# Add the long-running task node to the graph
graph.add_node("long_running_task", long_running_task_node)
```

### 4.2 Conversation Memory

Implement a conversation memory to maintain context across multiple turns:

```python
class ConversationMemory:
    def __init__(self, max_turns=5):
        self.memory = []
        self.max_turns = max_turns
    
    def add_turn(self, user_message, assistant_message):
        self.memory.append((user_message, assistant_message))
        if len(self.memory) > self.max_turns:
            self.memory.pop(0)
    
    def get_context(self):
        return "\n".join([f"User: {turn[0]}\nAssistant: {turn[1]}" for turn in self.memory])

conversation_memory = ConversationMemory()

def update_memory_node(state: AssistantState):
    user_message = state["messages"][-2]["content"]  # Second to last message
    assistant_message = state["messages"][-1]["content"]  # Last message
    conversation_memory.add_turn(user_message, assistant_message)
    return {"context": {"conversation_history": conversation_memory.get_context()}}

# Add the update memory node to the graph
graph.add_node("update_memory", update_memory_node)
graph.add_edge(END, "update_memory")
```

### 4.3 Natural Language Generation

To make our AI assistant's responses more natural and engaging, let's implement a natural language generation step that refines the raw responses:

```python
def natural_language_generation(state: AssistantState):
    raw_response = state["messages"][-1]["content"]
    
    refinement_prompt = f"""
    Refine the following AI assistant response to make it more natural, engaging, and empathetic:
    
    Original response: {raw_response}
    
    Refined response:
    """
    
    refined_response = llm.invoke(refinement_prompt).content
    
    return {"messages": [{"role": "assistant", "content": refined_response}]}

# Add the NLG node to the graph
graph.add_node("nlg", natural_language_generation)
graph.add_edge("general_response", "nlg")
graph.add_edge("scheduling", "nlg")
graph.add_edge("summarization", "nlg")
graph.add_edge("nlg", END)
```

## 5. Testing and Debugging

To ensure the reliability and correctness of our AI assistant, we need to implement comprehensive testing and debugging strategies.

### 5.1 Unit Testing

Let's write unit tests for some of our key components:

```python
import unittest

class TestAIAssistant(unittest.TestCase):
    def setUp(self):
        self.graph = StateGraph(AssistantState)
        # ... initialize the graph as before ...
        self.assistant = self.graph.compile()
    
    def test_nlu_node(self):
        state = {
            "messages": [{"role": "user", "content": "Schedule a meeting for tomorrow at 2 PM"}],
            "current_task": "",
            "context": {}
        }
        result = nlu_node(state)
        self.assertEqual(result["current_task"], "scheduling")
        self.assertIn("intent", result["context"])
        self.assertIn("entities", result["context"])
    
    def test_scheduling_node(self):
        state = {
            "messages": [{"role": "user", "content": "Schedule a meeting"}],
            "current_task": "scheduling",
            "context": {"entities": {"date": "2023-06-01", "time": "14:00"}}
        }
        result = scheduling_node(state)
        self.assertIn("appointment", result["messages"][0]["content"].lower())
    
    # Add more unit tests for other components

if __name__ == '__main__':
    unittest.main()
```

### 5.2 Integration Testing

We should also perform integration tests to ensure that different components of our AI assistant work well together:

```python
def test_end_to_end_scheduling():
    initial_state = {
        "messages": [{"role": "user", "content": "I want to schedule a meeting for tomorrow at 2 PM"}],
        "current_task": "",
        "context": {}
    }
    
    result = assistant.invoke(initial_state)
    
    # Check if the final state contains a scheduled appointment
    assert "scheduled" in result["messages"][-1]["content"].lower()
    assert "2 PM" in result["messages"][-1]["content"]
    assert "tomorrow" in result["messages"][-1]["content"]

# Run the integration test
test_end_to_end_scheduling()
```

### 5.3 Debugging Techniques

To facilitate debugging, we can add logging throughout our graph:

```python
import logging

logging.basicConfig(level=logging.DEBUG)

def logging_decorator(func):
    def wrapper(state: AssistantState):
        logging.debug(f"Entering node: {func.__name__}")
        result = func(state)
        logging.debug(f"Exiting node: {func.__name__}")
        return result
    return wrapper

# Apply the logging decorator to all nodes
graph.add_node("nlu", logging_decorator(nlu_node))
graph.add_node("task_router", logging_decorator(task_router))
# ... apply to all other nodes ...
```

## 6. Optimization and Scaling

As we prepare our AI assistant for production use, we need to consider optimization and scaling strategies.

### 6.1 Caching

Implement caching for expensive operations, such as LLM calls:

```python
from functools import lru_cache

@lru_cache(maxsize=100)
def cached_llm_call(prompt: str) -> str:
    return llm.invoke(prompt).content

# Use the cached version in our nodes
def nlu_node(state: AssistantState):
    user_input = state["messages"][-1]["content"]
    prompt = f"Analyze the following user input: {user_input}"
    response = cached_llm_call(prompt)
    # ... rest of the function ...
```

### 6.2 Asynchronous Processing

For better performance, especially with long-running tasks, we can implement asynchronous processing:

```python
import asyncio
from langgraph.graph import StateGraph, END

async def async_summarization_node(state: AssistantState):
    # ... same logic as before, but use async calls ...
    chunk_summaries = await asyncio.gather(*[async_summarize_chunk(chunk) for chunk in chunks])
    # ... rest of the function ...

async def async_summarize_chunk(chunk: str) -> str:
    # Implement async version of chunk summarization
    pass

# Create an async version of the graph
async_graph = StateGraph(AssistantState)
# ... add nodes and edges as before, but use async versions of functions ...
async_assistant = async_graph.compile()

# Run the async assistant
async def run_assistant(initial_state):
    return await async_assistant.ainvoke(initial_state)
```

### 6.3 Horizontal Scaling

To handle increased load, we can design our system to be horizontally scalable. This involves:

1. Using stateless nodes where possible
2. Storing state in a distributed cache or database
3. Using a message queue for communication between components

Here's a high-level example of how we might adapt our system for horizontal scaling:

```python
import redis
from rq import Queue

# Set up Redis for distributed state management
redis_client = redis.Redis(host='localhost', port=6379, db=0)

# Set up RQ for distributed task processing
q = Queue(connection=redis_client)

def distributed_nlu_node(state_id: str):
    state = redis_client.get(state_id)
    # ... process the state ...
    result = nlu_node(state)
    redis_client.set(state_id, result)
    return state_id

# Enqueue a job
job = q.enqueue(distributed_nlu_node, state_id)

# In another process or machine, we can get the result
result = job.result
```

## Conclusion

In this lesson, we've built a sophisticated AI assistant using LangGraph. We've covered complex workflow implementation, error handling, user experience considerations, testing and debugging strategies, and optimization techniques. This project demonstrates how LangGraph can be used to create powerful, flexible AI systems that can handle a wide range of tasks and interactions.

Remember that building such a system is an iterative process. As you develop and use your AI assistant, you'll likely discover areas for improvement and optimization. Continuous refinement based on user feedback and performance metrics is key to creating a truly effective AI assistant.

## Additional Resources

1. LangChain Documentation: https://python.langchain.com/en/latest/
2. OpenAI API Documentation: https://platform.openai.com/docs/api-reference
3. Redis Documentation: https://redis.io/documentation
4. RQ (Redis Queue) Documentation: https://python-rq.org/
5. Asyncio Documentation: https://docs.python.org/3/library/asyncio.html

## Practice Exercises

1. Extend the AI assistant to handle a new type of task, such as setting reminders or performing calculations.
2. Implement a user feedback mechanism and use it to improve the assistant's responses over time.
3. Create a web interface for interacting with the AI assistant using a framework like Flask or FastAPI.
4. Develop a more sophisticated conversation memory system that can handle long-term context and user preferences.
5. Implement a monitoring system to track the assistant's performance and identify areas for improvement.

By completing these exercises, you'll gain hands-on experience in expanding and refining complex AI systems built with LangGraph.

