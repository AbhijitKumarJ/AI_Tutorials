# Lesson 8 Part 2C: Document Analysis System

## Overview
An AI-powered document analysis system using LiteLLM for:
- Document summarization
- Information extraction
- Question answering

## Project Structure
```
doc-analyzer/
├── app/
│   ├── analyzer.py         # Core analysis logic
│   ├── router_config.py    # LiteLLM router setup
│   └── chunk_manager.py    # Document chunking
└── api/
    └── main.py            # FastAPI endpoints
```

## 1. Core Implementation

### Router Configuration
```python
# app/router_config.py
from litellm import Router

def setup_router():
    model_list = [
        {
            "model_name": "text-analyzer",
            "litellm_params": {
                "model": "gpt-4-turbo-preview",
                "api_key": "os.environ/OPENAI_API_KEY",
                "max_tokens": 4000
            }
        },
        {
            "model_name": "summarizer",
            "litellm_params": {
                "model": "anthropic/claude-instant-v1",
                "api_key": "os.environ/ANTHROPIC_API_KEY",
                "max_tokens": 2000
            }
        }
    ]

    return Router(model_list=model_list)
```

### Document Analysis
```python
# app/analyzer.py
from typing import List, Dict, Optional
from pydantic import BaseModel
from .chunk_manager import ChunkManager

class AnalysisRequest(BaseModel):
    text: str
    analysis_type: str  # 'summarize', 'extract', 'qa'
    query: Optional[str] = None
    extraction_fields: Optional[List[str]] = None

class DocumentAnalyzer:
    def __init__(self, router):
        self.router = router
        self.chunk_manager = ChunkManager()

    async def analyze(self, request: AnalysisRequest) -> Dict:
        # Split text into manageable chunks
        chunks = self.chunk_manager.split_text(request.text)
        
        if request.analysis_type == "summarize":
            return await self._summarize(chunks)
        elif request.analysis_type == "extract":
            return await self._extract_info(chunks, request.extraction_fields)
        elif request.analysis_type == "qa":
            return await self._answer_question(chunks, request.query)
        else:
            raise ValueError("Invalid analysis type")

    async def _summarize(self, chunks: List[str]) -> Dict:
        summaries = []
        for chunk in chunks:
            response = await self.router.acompletion(
                model="summarizer",
                messages=[{
                    "role": "user",
                    "content": f"Summarize this text concisely: {chunk}"
                }]
            )
            summaries.append(response.choices[0].message.content)

        # Generate final summary
        final_summary = await self.router.acompletion(
            model="summarizer",
            messages=[{
                "role": "user",
                "content": f"Create a coherent summary from these summaries: {' '.join(summaries)}"
            }]
        )

        return {
            "summary": final_summary.choices[0].message.content,
            "chunk_count": len(chunks)
        }

    async def _extract_info(
        self,
        chunks: List[str],
        fields: List[str]
    ) -> Dict:
        results = []
        field_list = ", ".join(fields)

        for chunk in chunks:
            response = await self.router.acompletion(
                model="text-analyzer",
                messages=[{
                    "role": "user",
                    "content": f"Extract the following information from this text: {field_list}. Text: {chunk}"
                }]
            )
            results.append(response.choices[0].message.content)

        return {
            "extracted_info": self._merge_extracted_info(results),
            "chunk_count": len(chunks)
        }

    async def _answer_question(
        self,
        chunks: List[str],
        question: str
    ) -> Dict:
        # Find relevant chunks
        relevant_chunks = self.chunk_manager.get_relevant_chunks(
            chunks,
            question
        )

        # Generate answer
        response = await self.router.acompletion(
            model="text-analyzer",
            messages=[{
                "role": "user",
                "content": f"Answer this question using the following context: {' '.join(relevant_chunks)}. Question: {question}"
            }]
        )

        return {
            "answer": response.choices[0].message.content,
            "used_chunks": len(relevant_chunks)
        }
```

### Text Chunking
```python
# app/chunk_manager.py
from typing import List
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class ChunkManager:
    def __init__(self, chunk_size: int = 2000):
        self.chunk_size = chunk_size
        self.vectorizer = TfidfVectorizer()

    def split_text(self, text: str) -> List[str]:
        # Split text into sentences
        sentences = text.split(". ")
        chunks = []
        current_chunk = []
        current_size = 0

        for sentence in sentences:
            if current_size + len(sentence) > self.chunk_size:
                chunks.append(". ".join(current_chunk))
                current_chunk = [sentence]
                current_size = len(sentence)
            else:
                current_chunk.append(sentence)
                current_size += len(sentence)

        if current_chunk:
            chunks.append(". ".join(current_chunk))

        return chunks

    def get_relevant_chunks(
        self,
        chunks: List[str],
        query: str,
        top_k: int = 3
    ) -> List[str]:
        # Create TF-IDF matrix
        tfidf_matrix = self.vectorizer.fit_transform(chunks + [query])
        
        # Calculate similarity
        similarities = cosine_similarity(
            tfidf_matrix[-1:],
            tfidf_matrix[:-1]
        )[0]

        # Get top chunks
        top_indices = np.argsort(similarities)[-top_k:]
        return [chunks[i] for i in top_indices]
```

## 2. API Implementation

```python
# api/main.py
from fastapi import FastAPI, HTTPException
from typing import List
from app.analyzer import DocumentAnalyzer, AnalysisRequest
from app.router_config import setup_router

app = FastAPI()
router = setup_router()
analyzer = DocumentAnalyzer(router)

@app.post("/analyze")
async def analyze_document(request: AnalysisRequest):
    try:
        result = await analyzer.analyze(request)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/batch-analyze")
async def batch_analyze(requests: List[AnalysisRequest]):
    try:
        results = []
        for request in requests:
            result = await analyzer.analyze(request)
            results.append(result)
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

## 3. Usage Examples

### Summarization
```python
# Summarize a document
request = AnalysisRequest(
    text="[Long document text...]",
    analysis_type="summarize"
)
result = await analyzer.analyze(request)
```

### Information Extraction
```python
# Extract specific information
request = AnalysisRequest(
    text="[Document text...]",
    analysis_type="extract",
    extraction_fields=["dates", "names", "locations"]
)
result = await analyzer.analyze(request)
```

### Question Answering
```python
# Answer questions about the document
request = AnalysisRequest(
    text="[Document text...]",
    analysis_type="qa",
    query="What were the key findings?"
)
result = await analyzer.analyze(request)
```

## 4. Key Features

1. **Smart Chunking**
   - Automatic text splitting
   - Sentence boundary preservation
   - Semantic chunk retrieval

2. **Multiple Analysis Types**
   - Document summarization
   - Information extraction
   - Question answering

3. **Efficient Processing**
   - Parallel chunk processing
   - Relevant chunk selection
   - Multiple model support

## 5. Production Considerations

1. **Scaling**
   - Use Redis for caching
   - Implement chunk result caching
   - Add request queuing

2. **Monitoring**
   - Track token usage
   - Monitor processing time
   - Log analysis success rates

3. **Cost Optimization**
   - Cache common analyses
   - Optimize chunk sizes
   - Use cheaper models for initial processing

This implementation provides a robust document analysis system that efficiently processes large documents using LiteLLM's routing capabilities.