# Lesson 8 Part 2A: Building an AI Chat Application with LiteLLM

## Project Overview: AI Chat Application
We'll build a production-ready chat application that supports multiple LLM models, streaming responses, and conversation history.

## Project Structure
```
ai-chat-app/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py              # FastAPI application
│   │   ├── chat_manager.py      # Chat session management
│   │   ├── models.py            # Pydantic models
│   │   └── config.py            # Configuration
│   ├── tests/
│   │   └── test_chat.py         # Tests
│   └── config.yaml              # LiteLLM configuration
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── Chat.tsx         # Chat interface
    │   │   └── ModelSelector.tsx # Model selection
    │   └── utils/
    │       └── api.ts           # API client
    └── package.json
```

## 1. Backend Implementation

### LiteLLM Configuration
```yaml
# config.yaml
model_list:
  - model_name: "gpt-4"
    litellm_params:
      model: "azure/gpt-4-1106-preview"
      api_key: "os.environ/AZURE_API_KEY"
      api_base: "os.environ/AZURE_API_BASE"
      api_version: "2023-11-01"
  - model_name: "claude-2"
    litellm_params:
      model: "anthropic/claude-2"
      api_key: "os.environ/ANTHROPIC_API_KEY"
  - model_name: "palm-2"
    litellm_params:
      model: "palm/chat-bison"
      api_key: "os.environ/PALM_API_KEY"

router_settings:
  routing_strategy: "usage-based-routing"
  num_retries: 3
  cache_responses: true
```

### Chat Session Management
```python
# backend/app/chat_manager.py
from datetime import datetime
from typing import Dict, List, Optional
from pydantic import BaseModel
import uuid
from litellm import Router
import asyncio

class Message(BaseModel):
    role: str
    content: str
    created_at: datetime = datetime.now()

class ChatSession(BaseModel):
    id: str
    messages: List[Message]
    model: str
    created_at: datetime = datetime.now()
    updated_at: datetime = datetime.now()

class ChatManager:
    def __init__(self, router: Router):
        self.sessions: Dict[str, ChatSession] = {}
        self.router = router

    def create_session(self, model: str) -> ChatSession:
        session_id = str(uuid.uuid4())
        session = ChatSession(
            id=session_id,
            messages=[],
            model=model
        )
        self.sessions[session_id] = session
        return session

    async def send_message(
        self,
        session_id: str,
        content: str,
        stream: bool = False
    ) -> Optional[str]:
        if session_id not in self.sessions:
            raise ValueError("Invalid session ID")

        session = self.sessions[session_id]
        user_message = Message(role="user", content=content)
        session.messages.append(user_message)

        messages = [
            {"role": m.role, "content": m.content}
            for m in session.messages
        ]

        response = await self.router.acompletion(
            model=session.model,
            messages=messages,
            stream=stream
        )

        if not stream:
            assistant_message = Message(
                role="assistant",
                content=response.choices[0].message.content
            )
            session.messages.append(assistant_message)
            session.updated_at = datetime.now()
            return assistant_message.content
        
        return response

    async def process_stream(self, stream_response, callback):
        collected_content = []
        async for chunk in stream_response:
            content = chunk.choices[0].delta.content
            if content:
                collected_content.append(content)
                await callback(content)
        
        return "".join(collected_content)
```

### FastAPI Application
```python
# backend/app/main.py
from fastapi import FastAPI, WebSocket, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .chat_manager import ChatManager
from .models import StartChatRequest, ChatMessage
from litellm import Router
import yaml
import json

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load configuration
with open("config.yaml") as f:
    config = yaml.safe_load(f)

router = Router(**config)
chat_manager = ChatManager(router)

@app.post("/chat/start")
async def start_chat(request: StartChatRequest):
    try:
        session = chat_manager.create_session(request.model)
        return {"session_id": session.id}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/chat/{session_id}/message")
async def send_message(session_id: str, message: ChatMessage):
    try:
        response = await chat_manager.send_message(
            session_id,
            message.content
        )
        return {"response": response}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.websocket("/chat/{session_id}/stream")
async def stream_chat(websocket: WebSocket, session_id: str):
    await websocket.accept()
    try:
        while True:
            message = await websocket.receive_text()
            message_data = json.loads(message)
            
            async def send_chunk(chunk):
                await websocket.send_text(chunk)

            stream_response = await chat_manager.send_message(
                session_id,
                message_data["content"],
                stream=True
            )
            
            final_content = await chat_manager.process_stream(
                stream_response,
                send_chunk
            )
            
            # Send completion message
            await websocket.send_json({
                "type": "completion",
                "content": final_content
            })
            
    except Exception as e:
        await websocket.send_json({
            "type": "error",
            "content": str(e)
        })
    finally:
        await websocket.close()
```

### Pydantic Models
```python
# backend/app/models.py
from pydantic import BaseModel

class StartChatRequest(BaseModel):
    model: str

class ChatMessage(BaseModel):
    content: str
```

## 2. Testing Implementation

### Unit Tests
```python
# backend/tests/test_chat.py
import pytest
from app.chat_manager import ChatManager, Message
from litellm import Router
import asyncio

@pytest.fixture
def router():
    return Router(
        model_list=[{
            "model_name": "test-model",
            "litellm_params": {
                "model": "gpt-4",
                "api_key": "test-key"
            }
        }]
    )

@pytest.fixture
def chat_manager(router):
    return ChatManager(router)

def test_create_session(chat_manager):
    session = chat_manager.create_session("test-model")
    assert session.id is not None
    assert session.model == "test-model"
    assert len(session.messages) == 0

@pytest.mark.asyncio
async def test_send_message(chat_manager):
    session = chat_manager.create_session("test-model")
    response = await chat_manager.send_message(
        session.id,
        "Hello, world!"
    )
    assert response is not None
    assert len(chat_manager.sessions[session.id].messages) == 2
```

## 3. Frontend Interface

### Chat Component
```typescript
// frontend/src/components/Chat.tsx
import React, { useState, useEffect, useRef } from 'react';
import { ModelSelector } from './ModelSelector';

interface Message {
    role: 'user' | 'assistant';
    content: string;
}

export const Chat: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState('');
    const [sessionId, setSessionId] = useState<string | null>(null);
    const [selectedModel, setSelectedModel] = useState('gpt-4');
    const websocketRef = useRef<WebSocket | null>(null);

    useEffect(() => {
        return () => {
            if (websocketRef.current) {
                websocketRef.current.close();
            }
        };
    }, []);

    const startChat = async () => {
        const response = await fetch('/api/chat/start', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ model: selectedModel }),
        });
        const data = await response.json();
        setSessionId(data.session_id);

        // Setup WebSocket
        websocketRef.current = new WebSocket(
            `ws://localhost:8000/chat/${data.session_id}/stream`
        );

        websocketRef.current.onmessage = (event) => {
            const data = JSON.parse(event.data);
            if (data.type === 'completion') {
                setMessages(prev => [
                    ...prev,
                    { role: 'assistant', content: data.content }
                ]);
            }
        };
    };

    const sendMessage = async () => {
        if (!input.trim() || !sessionId) return;

        setMessages(prev => [
            ...prev,
            { role: 'user', content: input }
        ]);

        if (websocketRef.current?.readyState === WebSocket.OPEN) {
            websocketRef.current.send(JSON.stringify({
                content: input
            }));
        }

        setInput('');
    };

    return (
        <div className="chat-container">
            <ModelSelector
                value={selectedModel}
                onChange={setSelectedModel}
                onStart={startChat}
            />
            <div className="messages">
                {messages.map((message, index) => (
                    <div
                        key={index}
                        className={`message ${message.role}`}
                    >
                        {message.content}
                    </div>
                ))}
            </div>
            <div className="input-container">
                <input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                    placeholder="Type your message..."
                    disabled={!sessionId}
                />
                <button
                    onClick={sendMessage}
                    disabled={!sessionId}
                >
                    Send
                </button>
            </div>
        </div>
    );
};
```

### Model Selector Component
```typescript
// frontend/src/components/ModelSelector.tsx
import React from 'react';

interface Props {
    value: string;
    onChange: (model: string) => void;
    onStart: () => void;
}

export const ModelSelector: React.FC<Props> = ({
    value,
    onChange,
    onStart
}) => {
    return (
        <div className="model-selector">
            <select
                value={value}
                onChange={(e) => onChange(e.target.value)}
            >
                <option value="gpt-4">GPT-4</option>
                <option value="claude-2">Claude 2</option>
                <option value="palm-2">PaLM 2</option>
            </select>
            <button onClick={onStart}>Start Chat</button>
        </div>
    );
};
```

## 4. Key Features

1. **Multi-Model Support**
   - Seamless switching between different LLM providers
   - Unified interface for all models
   - Automatic fallbacks and retries

2. **Streaming Responses**
   - Real-time message streaming
   - WebSocket implementation
   - Efficient chunk processing

3. **Session Management**
   - Persistent chat sessions
   - Message history tracking
   - Session state management

4. **Error Handling**
   - Graceful error recovery
   - User-friendly error messages
   - Connection management

## 5. Production Considerations

1. **Scaling**
   - Use Redis for session storage
   - Implement load balancing
   - Handle WebSocket connections properly

2. **Monitoring**
   - Track response times
   - Monitor error rates
   - Log user interactions

3. **Security**
   - Implement authentication
   - Rate limiting
   - Input validation

4. **Cost Management**
   - Token usage tracking
   - Budget controls
   - Usage analytics

This implementation demonstrates a production-ready chat application using LiteLLM's router capabilities for managing multiple LLM providers, streaming responses, and handling chat sessions.