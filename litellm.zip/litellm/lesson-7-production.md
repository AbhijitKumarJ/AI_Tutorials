# Lesson 7: Production Deployment and Best Practices

## Overview
This lesson covers deploying LiteLLM in production environments, focusing on high availability, monitoring, cost optimization, security, and performance tuning.

## Project Structure
```
production-litellm/
├── config/
│   ├── config.yaml           # Main configuration file
│   ├── monitoring.yaml       # Prometheus/Grafana configuration
│   └── alerting.yaml         # Alerting rules
├── deployment/
│   ├── docker-compose.yml    # Docker deployment setup
│   └── kubernetes/
│       ├── deployment.yaml   # K8s deployment
│       └── service.yaml      # K8s service
├── scripts/
│   ├── health_check.py      # Health check script
│   └── backup.sh            # Backup script
└── src/
    ├── main.py              # Main application
    └── middleware/
        ├── auth.py          # Authentication
        ├── rate_limit.py    # Rate limiting
        └── logging.py       # Logging setup
```

## 1. Production Deployment Strategies

### Docker Deployment
```yaml
# docker-compose.yml
version: '3.8'
services:
  litellm-proxy:
    image: ghcr.io/berriai/litellm:main-latest
    ports:
      - "8000:8000"
    environment:
      - REDIS_HOST=redis
      - REDIS_PORT=6379
    volumes:
      - ./config:/app/config
    command: ["--config", "/app/config/config.yaml"]
    restart: always
    depends_on:
      - redis

  redis:
    image: redis:6.2-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    restart: always

volumes:
  redis-data:
```

### Kubernetes Deployment
```yaml
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: litellm-proxy
spec:
  replicas: 3
  selector:
    matchLabels:
      app: litellm-proxy
  template:
    metadata:
      labels:
        app: litellm-proxy
    spec:
      containers:
      - name: litellm-proxy
        image: ghcr.io/berriai/litellm:main-latest
        ports:
        - containerPort: 8000
        env:
        - name: REDIS_HOST
          value: "redis-service"
        volumeMounts:
        - name: config-volume
          mountPath: /app/config
      volumes:
      - name: config-volume
        configMap:
          name: litellm-config
```

## 2. High Availability Setup

### Load Balancer Configuration
```yaml
# config.yaml
model_list:
  - model_name: gpt-4
    litellm_params:
      model: azure/gpt-4-1
      api_base: "https://azure1.openai.azure.com/"
      api_key: os.environ/AZURE_API_KEY_1
      rpm: 10000
  - model_name: gpt-4
    litellm_params:
      model: azure/gpt-4-2
      api_base: "https://azure2.openai.azure.com/"
      api_key: os.environ/AZURE_API_KEY_2
      rpm: 10000

router_settings:
  retry_strategy: exponential_backoff
  num_retries: 3
  availability_strategy: fallback_on_timeout

litellm_settings:
  cache: True
  cache_params:
    type: redis
    host: os.environ/REDIS_HOST
    port: os.environ/REDIS_PORT
    password: os.environ/REDIS_PASSWORD
```

### Health Checks
```python
# health_check.py
import requests
import json
import os
import time

def check_endpoint_health(endpoint):
    try:
        response = requests.get(f"{endpoint}/health")
        if response.status_code == 200:
            print(f"Endpoint {endpoint} is healthy")
            return True
        print(f"Endpoint {endpoint} returned status code {response.status_code}")
        return False
    except Exception as e:
        print(f"Error checking endpoint {endpoint}: {str(e)}")
        return False

while True:
    check_endpoint_health("http://litellm-proxy:8000")
    time.sleep(30)  # Check every 30 seconds
```

## 3. Monitoring and Alerting

### Prometheus Configuration
```yaml
# monitoring.yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'litellm'
    static_configs:
      - targets: ['litellm-proxy:8000']
    metrics_path: '/metrics'
```

### Grafana Dashboard
Key metrics to monitor:
- Request rate and latency
- Error rates and types
- Cache hit/miss ratios
- Cost per model/request
- Token usage
- Response times

### Alerting Rules
```yaml
# alerting.yaml
groups:
- name: litellm_alerts
  rules:
  - alert: HighErrorRate
    expr: rate(litellm_error_count[5m]) > 0.1
    for: 5m
    labels:
      severity: critical
    annotations:
      summary: High error rate detected

  - alert: HighLatency
    expr: rate(litellm_request_duration_seconds_sum[5m]) / rate(litellm_request_duration_seconds_count[5m]) > 2
    for: 5m
    labels:
      severity: warning
```

## 4. Cost Optimization

### Budget Management
```yaml
# config.yaml
general_settings:
  master_key: sk-1234
  budget:
    daily_limit: 100  # $100 per day
    max_parallel_requests: 1000
    alerts:
      - threshold: 0.8  # Alert at 80% of budget
        webhook: "https://alerts.company.com/budget"
```

### Caching Strategy
```yaml
litellm_settings:
  cache: True
  cache_params:
    type: redis
    host: redis
    port: 6379
    ttl: 3600  # Cache responses for 1 hour
```

## 5. Security Best Practices

### Authentication Middleware
```python
# auth.py
from fastapi import Request, HTTPException
import jwt
from typing import Optional

async def verify_token(request: Request, token: Optional[str] = None):
    if token is None:
        token = request.headers.get("Authorization", "").replace("Bearer ", "")
    
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        return payload
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
```

### Rate Limiting
```python
# rate_limit.py
from fastapi import Request, HTTPException
import redis
import time

class RateLimiter:
    def __init__(self, redis_client, limit: int, window: int):
        self.redis = redis_client
        self.limit = limit
        self.window = window

    async def check_rate_limit(self, key: str):
        current = int(time.time())
        pipeline = self.redis.pipeline()
        
        pipeline.zremrangebyscore(key, 0, current - self.window)
        pipeline.zadd(key, {str(current): current})
        pipeline.zcard(key)
        
        results = pipeline.execute()
        request_count = results[2]

        if request_count > self.limit:
            raise HTTPException(status_code=429, detail="Rate limit exceeded")
```

## 6. Performance Optimization

### Response Time Optimization
- Use streaming for long responses
- Implement caching for repeated requests
- Set appropriate timeouts
- Use async handlers for concurrent requests

```python
# main.py
from fastapi import FastAPI
from litellm import completion
import asyncio

app = FastAPI()

@app.post("/chat/completions")
async def chat_completion(request: Request):
    try:
        # Process multiple requests concurrently
        async with asyncio.TaskGroup() as tg:
            tasks = [
                tg.create_task(process_request(req))
                for req in batch_requests
            ]
        return [task.result() for task in tasks]
    except Exception as e:
        handle_error(e)
```

### Resource Management
```python
# config.yaml
litellm_settings:
  num_workers: 4  # Number of worker processes
  max_tokens_per_request: 8000
  request_timeout: 30
  connection_pool_size: 100
```

## 7. Troubleshooting and Maintenance

### Logging Configuration
```python
# logging.py
import logging
import json
from datetime import datetime

class CustomFormatter(logging.Formatter):
    def format(self, record):
        log_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
        }
        
        if hasattr(record, "request_id"):
            log_data["request_id"] = record.request_id
            
        return json.dumps(log_data)

def setup_logging():
    logger = logging.getLogger("litellm")
    handler = logging.StreamHandler()
    handler.setFormatter(CustomFormatter())
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
```

### Backup Strategy
```bash
# backup.sh
#!/bin/bash

# Backup Redis data
redis-cli save
cp /data/dump.rdb /backups/redis_$(date +%Y%m%d_%H%M%S).rdb

# Backup configurations
cp -r /app/config /backups/config_$(date +%Y%m%d_%H%M%S)

# Clean old backups (keep last 7 days)
find /backups -type f -mtime +7 -exec rm {} \;
```

## Best Practices Summary

1. **Deployment**
   - Use container orchestration (Kubernetes/Docker Swarm)
   - Implement rolling updates
   - Use health checks and automatic restarts
   - Set up proper logging and monitoring

2. **High Availability**
   - Deploy multiple instances
   - Use load balancing
   - Implement fallback strategies
   - Set up automatic failover

3. **Monitoring**
   - Use Prometheus/Grafana for metrics
   - Set up alerting for critical issues
   - Monitor costs and usage
   - Track error rates and latency

4. **Security**
   - Implement proper authentication
   - Use rate limiting
   - Secure sensitive data
   - Regular security audits

5. **Performance**
   - Use caching effectively
   - Optimize request handling
   - Configure timeouts appropriately
   - Monitor and tune resource usage

6. **Maintenance**
   - Regular backups
   - Update dependencies
   - Monitor logs
   - Document procedures

## Further Reading
- [LiteLLM Documentation](https://docs.litellm.ai/docs/)
- [OpenAI Best Practices](https://platform.openai.com/docs/guides/production-best-practices)
- [Redis Documentation](https://redis.io/documentation)
- [Kubernetes Documentation](https://kubernetes.io/docs/)