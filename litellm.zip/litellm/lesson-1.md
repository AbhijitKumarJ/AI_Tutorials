# Lesson 1: Introduction to LiteLLM and Unified LLM Access

## Section 1: Understanding LiteLLM

LiteLLM is a powerful toolkit that simplifies interactions with Large Language Models (LLMs) by providing a unified interface to access 100+ LLM APIs using the familiar OpenAI format. At its core, LiteLLM translates your API calls into the appropriate format for each provider while maintaining consistent input/output structures, making it significantly easier to work with multiple LLM providers without changing your code.

### Key Benefits of LiteLLM
When working with multiple LLM providers, developers typically face challenges like learning different APIs, managing various authentication methods, and handling different response formats. LiteLLM solves these challenges by:
1. Providing a single, consistent interface modeled after OpenAI's widely-adopted format
2. Automatically handling authentication and API specifics for each provider
3. Offering built-in reliability features like retries, fallbacks, and load balancing
4. Standardizing error handling across all providers

## Section 2: Development Environment Setup

Let's set up our development environment. Create a new project directory with the following structure:

```plaintext
litellm-learning/
├── .env                 # For storing API keys
├── requirements.txt     # Project dependencies
└── src/                # Source code directory
    └── first_steps.py  # Our first LiteLLM code
```

### Setting Up Dependencies

1. First, create a virtual environment and install LiteLLM:

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install litellm python-dotenv
```

2. Create a requirements.txt file:
```plaintext
litellm>=1.0.0
python-dotenv>=0.19.0
```

3. Create a .env file to store your API keys:
```plaintext
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
COHERE_API_KEY=...
```

## Section 3: Your First LiteLLM Integration

Let's create our first script (src/first_steps.py) to interact with different LLM providers:

```python
import os
from dotenv import load_dotenv
from litellm import completion

# Load environment variables
load_dotenv()

def basic_completion_call():
    """
    Demonstrate a basic completion call using LiteLLM
    """
    messages = [
        {"role": "user", "content": "What is the capital of France?"}
    ]
    
    # Making a completion call to OpenAI
    try:
        response = completion(
            model="gpt-3.5-turbo",
            messages=messages
        )
        print("OpenAI Response:", response.choices[0].message.content)
    except Exception as e:
        print(f"OpenAI Error: {e}")

    # Making a completion call to Anthropic
    try:
        response = completion(
            model="claude-2",
            messages=messages
        )
        print("Anthropic Response:", response.choices[0].message.content)
    except Exception as e:
        print(f"Anthropic Error: {e}")

if __name__ == "__main__":
    basic_completion_call()
```

## Section 4: Understanding the OpenAI-Compatible Format

LiteLLM uses the OpenAI format for all interactions. Here's a breakdown of the key components:

### Messages Format
Messages are structured as a list of dictionaries, each containing:
- role: can be "system", "user", or "assistant"
- content: the actual message content

```python
messages = [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "What is the capital of France?"}
]
```

### Response Format
Responses follow the OpenAI structure:
```python
{
    "choices": [{
        "message": {
            "content": "The capital of France is Paris.",
            "role": "assistant"
        },
        "finish_reason": "stop",
        "index": 0
    }],
    "model": "gpt-3.5-turbo",
    "usage": {
        "prompt_tokens": 15,
        "completion_tokens": 10,
        "total_tokens": 25
    }
}
```

## Section 5: Provider-Specific Setup

Different providers require different environment variables. Here's a comprehensive setup for major providers:

### OpenAI Setup
```python
os.environ["OPENAI_API_KEY"] = "sk-..."
```

### Azure OpenAI Setup
```python
os.environ["AZURE_API_KEY"] = "..."
os.environ["AZURE_API_BASE"] = "https://your-endpoint.openai.azure.com/"
os.environ["AZURE_API_VERSION"] = "2023-07-01-preview"
```

### Anthropic Setup
```python
os.environ["ANTHROPIC_API_KEY"] = "sk-ant-..."
```

### Cohere Setup
```python
os.environ["COHERE_API_KEY"] = "..."
```

Let's extend our example to include provider-specific configurations:

```python
def provider_specific_setup():
    """
    Demonstrate provider-specific configurations
    """
    messages = [
        {"role": "user", "content": "What is the capital of France?"}
    ]
    
    # Azure OpenAI call
    azure_response = completion(
        model="azure/gpt-35-turbo",  # Azure deployment name
        messages=messages,
        api_base=os.getenv("AZURE_API_BASE"),
        api_key=os.getenv("AZURE_API_KEY"),
        api_version=os.getenv("AZURE_API_VERSION")
    )
    
    # Cohere call
    cohere_response = completion(
        model="command-nightly",
        messages=messages
    )
```

## Section 6: Exercise - Creating a Multi-Provider Chat Application

Let's put everything together in a practical exercise. Create a new file called `chat_app.py`:

```python
import os
from dotenv import load_dotenv
from litellm import completion

load_dotenv()

def multi_provider_chat():
    # List of available models
    models = {
        "1": "gpt-3.5-turbo",
        "2": "claude-2",
        "3": "command-nightly"
    }
    
    print("Available Models:")
    for key, model in models.items():
        print(f"{key}: {model}")
    
    # Get user choice
    choice = input("Select a model (1-3): ")
    model = models.get(choice)
    
    if not model:
        print("Invalid choice")
        return
    
    # Start chat loop
    messages = []
    print(f"\nStarting chat with {model}. Type 'exit' to quit.")
    
    while True:
        user_input = input("\nYou: ")
        if user_input.lower() == 'exit':
            break
            
        messages.append({"role": "user", "content": user_input})
        
        try:
            response = completion(
                model=model,
                messages=messages
            )
            assistant_message = response.choices[0].message.content
            print(f"\nAssistant: {assistant_message}")
            
            messages.append({"role": "assistant", "content": assistant_message})
            
        except Exception as e:
            print(f"Error: {e}")
            break

if __name__ == "__main__":
    multi_provider_chat()
```

## Conclusion and Next Steps

In this lesson, we've covered:
- Understanding LiteLLM's core purpose and benefits
- Setting up a development environment
- Making basic completion calls
- Understanding the OpenAI-compatible format
- Setting up different providers
- Creating a practical multi-provider chat application

For practice, try:
1. Implementing the chat application with different models
2. Adding error handling for rate limits and API issues
3. Extending the chat application to support streaming responses
4. Adding support for additional providers

In the next lesson, we'll dive deeper into LiteLLM's completion functions, streaming capabilities, and advanced parameter configurations.

Remember to always check your API key usage and costs when testing with different providers. Some providers offer free tiers with limited tokens, while others may charge for all usage.
