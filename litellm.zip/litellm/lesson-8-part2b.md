# Lesson 8 Part 2B: Building a Content Generation System

## Project Overview: AI Content Generator
A production content generation system using LiteLLM to create blog posts, social media content, and marketing copy with multiple LLM providers.

## Project Structure
```
content-generator/
├── app/
│   ├── core/
│   │   ├── generator.py        # Content generation logic
│   │   ├── templates.py        # Prompt templates
│   │   └── validators.py       # Content validation
│   ├── api/
│   │   ├── routes.py          # API endpoints
│   │   └── models.py          # Data models
│   ├── services/
│   │   ├── llm_service.py     # LLM integration
│   │   └── queue_service.py   # Job queue management
│   └── config/
│       └── llm_config.yaml    # LiteLLM configuration
└── tests/
    └── test_generator.py      # Test suite
```

## 1. Core Implementation

### LLM Service Configuration
```python
# app/config/llm_config.yaml
model_list:
  - model_name: "content-generator"
    litellm_params:
      model: "gpt-4"
      api_key: "os.environ/OPENAI_API_KEY"
      temperature: 0.7
    fallbacks: ["azure/gpt-4", "azure/gpt-35-turbo"]
  - model_name: "content-validator"
    litellm_params:
      model: "anthropic/claude-2"
      api_key: "os.environ/ANTHROPIC_API_KEY"
      temperature: 0.3

router_settings:
  routing_strategy: "latency-based-routing"
  cache_responses: true
```

### Content Generation Service
```python
# app/core/generator.py
from typing import Dict, List, Optional
from pydantic import BaseModel
from litellm import Router
import asyncio
from .templates import ContentTemplates

class ContentRequest(BaseModel):
    content_type: str
    topic: str
    tone: str
    target_audience: str
    keywords: List[str]
    length: str

class ContentPiece(BaseModel):
    title: str
    content: str
    metadata: Dict[str, str]
    keywords_used: List[str]

class ContentGenerator:
    def __init__(self, router: Router, templates: ContentTemplates):
        self.router = router
        self.templates = templates

    async def generate_content(
        self,
        request: ContentRequest
    ) -> ContentPiece:
        # Get appropriate prompt template
        prompt = self.templates.get_template(
            request.content_type,
            request.tone
        )

        # Format prompt with request details
        formatted_prompt = prompt.format(
            topic=request.topic,
            audience=request.target_audience,
            keywords=", ".join(request.keywords),
            length=request.length
        )

        messages = [
            {
                "role": "system",
                "content": "You are a professional content creator."
            },
            {
                "role": "user",
                "content": formatted_prompt
            }
        ]

        # Generate content
        response = await self.router.acompletion(
            model="content-generator",
            messages=messages,
            temperature=0.7
        )

        content = response.choices[0].message.content

        # Validate content
        validation_response = await self.validate_content(
            content,
            request
        )

        if not validation_response["is_valid"]:
            return await self.regenerate_content(
                request,
                validation_response["feedback"]
            )

        return ContentPiece(
            title=self._extract_title(content),
            content=content,
            metadata={
                "type": request.content_type,
                "tone": request.tone,
                "audience": request.target_audience
            },
            keywords_used=request.keywords
        )

    async def validate_content(
        self,
        content: str,
        request: ContentRequest
    ) -> Dict[str, any]:
        validation_prompt = f"""
        Please validate this content based on:
        1. Tone matches '{request.tone}'
        2. Appropriate for '{request.target_audience}'
        3. Uses keywords: {', '.join(request.keywords)}
        4. Meets length requirement: {request.length}

        Content:
        {content}

        Provide a JSON response with:
        - is_valid: boolean
        - feedback: string (if not valid)
        """

        validation_messages = [
            {
                "role": "user",
                "content": validation_prompt
            }
        ]

        response = await self.router.acompletion(
            model="content-validator",
            messages=validation_messages,
            temperature=0.3
        )

        return eval(response.choices[0].message.content)

    @staticmethod
    def _extract_title(content: str) -> str:
        lines = content.split("\n")
        for line in lines:
            if line.strip():
                return line.strip()
        return "Untitled"
```

### Prompt Templates
```python
# app/core/templates.py
class ContentTemplates:
    def __init__(self):
        self.templates = {
            "blog_post": {
                "professional": """
                Create a professional blog post about {topic}.
                Target Audience: {audience}
                Required Keywords: {keywords}
                Length: {length}
                
                The post should be informative, well-structured, and maintain a professional tone.
                Include relevant examples and data points where appropriate.
                """,
                "casual": """
                Write a casual, conversational blog post about {topic}.
                Target Audience: {audience}
                Required Keywords: {keywords}
                Length: {length}
                
                Keep the tone friendly and relatable, using everyday language.
                Include personal anecdotes or examples where relevant.
                """
            },
            "social_post": {
                "engagement": """
                Create an engaging social media post about {topic}.
                Target Audience: {audience}
                Required Keywords: {keywords}
                Length: {length}
                
                Focus on driving engagement with questions or calls to action.
                Use appropriate hashtags and engaging language.
                """,
                "informative": """
                Write an informative social media post about {topic}.
                Target Audience: {audience}
                Required Keywords: {keywords}
                Length: {length}
                
                Focus on providing valuable information concisely.
                Include key facts or statistics where relevant.
                """
            }
        }

    def get_template(self, content_type: str, tone: str) -> str:
        return self.templates[content_type][tone]
```

## 2. API Implementation

### FastAPI Routes
```python
# app/api/routes.py
from fastapi import FastAPI, BackgroundTasks
from .models import ContentRequest, ContentResponse
from ..services.queue_service import QueueService
from ..core.generator import ContentGenerator

app = FastAPI()
queue_service = QueueService()
content_generator = ContentGenerator()

@app.post("/generate")
async def generate_content(
    request: ContentRequest,
    background_tasks: BackgroundTasks
):
    # Create job and add to queue
    job_id = queue_service.create_job(request)
    
    # Add generation task to background tasks
    background_tasks.add_task(
        process_content_generation,
        job_id,
        request
    )
    
    return {"job_id": job_id}

@app.get("/status/{job_id}")
async def get_job_status(job_id: str):
    return queue_service.get_job_status(job_id)

@app.get("/content/{job_id}")
async def get_content(job_id: str):
    return queue_service.get_job_result(job_id)

async def process_content_generation(job_id: str, request: ContentRequest):
    try:
        # Update job status
        queue_service.update_job_status(job_id, "processing")
        
        # Generate content
        content = await content_generator.generate_content(request)
        
        # Store result
        queue_service.complete_job(job_id, content)
    except Exception as e:
        queue_service.fail_job(job_id, str(e))
```

## 3. Queue Management

### Queue Service
```python
# app/services/queue_service.py
from typing import Dict, Any
import redis
import json
import uuid

class QueueService:
    def __init__(self):
        self.redis = redis.Redis(
            host="localhost",
            port=6379,
            decode_responses=True
        )

    def create_job(self, request: Dict[str, Any]) -> str:
        job_id = str(uuid.uuid4())
        job_data = {
            "status": "pending",
            "request": request.dict(),
            "result": None,
            "error": None
        }
        
        self.redis.set(
            f"job:{job_id}",
            json.dumps(job_data)
        )
        return job_id

    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        job_data = self.redis.get(f"job:{job_id}")
        if not job_data:
            raise ValueError("Job not found")
        
        return json.loads(job_data)

    def update_job_status(
        self,
        job_id: str,
        status: str,
        error: str = None
    ):
        job_data = self.get_job_status(job_id)
        job_data["status"] = status
        if error:
            job_data["error"] = error
            
        self.redis.set(
            f"job:{job_id}",
            json.dumps(job_data)
        )

    def complete_job(self, job_id: str, result: Dict[str, Any]):
        job_data = self.get_job_status(job_id)
        job_data["status"] = "completed"
        job_data["result"] = result
        
        self.redis.set(
            f"job:{job_id}",
            json.dumps(job_data)
        )

    def fail_job(self, job_id: str, error: str):
        self.update_job_status(job_id, "failed", error)
```

## 4. Testing Implementation

```python
# tests/test_generator.py
import pytest
from unittest.mock import Mock
from app.core.generator import ContentGenerator
from app.core.templates import ContentTemplates

@pytest.fixture
def mock_router():
    router = Mock()
    router.acompletion.return_value = Mock(
        choices=[
            Mock(
                message=Mock(
                    content="Test Title\n\nTest content"
                )
            )
        ]
    )
    return router

@pytest.fixture
def content_generator(mock_router):
    templates = ContentTemplates()
    return ContentGenerator(mock_router, templates)

@pytest.mark.asyncio
async def test_generate_content(content_generator):
    request = ContentRequest(
        content_type="blog_post",
        topic="AI Testing",
        tone="professional",
        target_audience="developers",
        keywords=["testing", "AI"],
        length="medium"
    )

    result = await content_generator.generate_content(request)
    
    assert result.title == "Test Title"
    assert "Test content" in result.content
    assert result.metadata["type"] == "blog_post"
    assert "testing" in result.keywords_used
```

## 5. Production Considerations

### 1. Performance Optimization
- Implement caching for similar content requests
- Use connection pooling for Redis
- Implement request batching
- Configure timeouts and retries

### 2. Scaling Strategy
```python
# Docker Compose for scaling
services:
  content-api:
    build: .
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
    environment:
      - REDIS_HOST=redis
      
  redis:
    image: redis:alpine
    volumes:
      - redis-data:/data
```

### 3. Monitoring Setup
```python
# Prometheus metrics
from prometheus_client import Counter, Histogram

CONTENT_GENERATION_TIME = Histogram(
    'content_generation_seconds',
    'Time spent generating content',
    ['content_type', 'model']
)

GENERATION_ERRORS = Counter(
    'content_generation_errors_total',
    'Total content generation errors',
    ['error_type']
)
```

### 4. Cost Management
```python
# Cost tracking
async def track_generation_cost(response, content_type):
    usage = response.usage
    model_cost = get_model_cost(response.model)
    
    total_cost = (
        usage.prompt_tokens * model_cost.input_cost +
        usage.completion_tokens * model_cost.output_cost
    )
    
    await update_cost_metrics(
        content_type=content_type,
        tokens_used=usage.total_tokens,
        cost=total_cost
    )
```

This implementation demonstrates a scalable content generation system that:
- Supports multiple content types and tones
- Implements content validation
- Handles asynchronous processing
- Includes comprehensive testing
- Provides production-ready monitoring and scaling capabilities