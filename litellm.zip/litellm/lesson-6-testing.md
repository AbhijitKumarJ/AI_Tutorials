# Lesson 6: Testing and Evaluation

## Table of Contents
1. [Setting Up Test Environments](#1-setting-up-test-environments)
2. [Mock Testing Framework](#2-mock-testing-framework)
3. [LLM Benchmarking](#3-llm-benchmarking)
4. [Performance Testing](#4-performance-testing)
5. [Integration Testing](#5-integration-testing)
6. [Automated Testing Pipeline](#6-automated-testing-pipeline)
7. [Evaluation Frameworks](#7-evaluation-frameworks)

## Learning Objectives
By the end of this lesson, you will be able to:
- Set up comprehensive test environments
- Implement mock testing for LLM calls
- Conduct benchmarking of different LLMs
- Perform performance testing
- Create integration tests
- Build automated testing pipelines
- Use evaluation frameworks effectively

## 1. Setting Up Test Environments

### Project Structure
```plaintext
tests/
├── unit/
│   ├── test_completion.py
│   ├── test_embedding.py
│   └── test_router.py
├── integration/
│   ├── test_proxy.py
│   └── test_callbacks.py
├── performance/
│   ├── test_throughput.py
│   └── test_latency.py
├── conftest.py
└── requirements-test.txt
```

### Test Environment Setup

1. Install Testing Dependencies
```bash
pip install -r requirements-test.txt
```

2. Configure Test Settings (conftest.py)
```python
import pytest
import os
from litellm import Router

@pytest.fixture
def test_router():
    router = Router(
        model_list=[
            {
                "model_name": "test-model",
                "litellm_params": {
                    "model": "gpt-3.5-turbo",
                    "api_key": "test-key"
                }
            }
        ],
        test_mode=True
    )
    return router

@pytest.fixture
def test_environment():
    os.environ["OPENAI_API_KEY"] = "test-key"
    os.environ["TEST_MODE"] = "true"
    yield
    del os.environ["OPENAI_API_KEY"]
    del os.environ["TEST_MODE"]
```

## 2. Mock Testing Framework

### Basic Mock Testing

1. Create Mock Responses
```python
from litellm import completion
import pytest

def test_completion_mock():
    mock_response = {
        "choices": [{
            "message": {
                "content": "This is a test response",
                "role": "assistant"
            }
        }]
    }
    
    response = completion(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": "Hello"}],
        mock_response=mock_response
    )
    
    assert response.choices[0].message.content == "This is a test response"
```

2. Testing Error Scenarios
```python
def test_completion_error_handling():
    with pytest.raises(Exception) as exc_info:
        response = completion(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": "Hello"}],
            mock_response=Exception("API Error")
        )
    
    assert str(exc_info.value) == "API Error"
```

3. Advanced Mock Testing
```python
class TestCompletionScenarios:
    @pytest.mark.parametrize("model,expected", [
        ("gpt-3.5-turbo", "Response 1"),
        ("claude-2", "Response 2"),
        ("palm/chat-bison", "Response 3")
    ])
    def test_multiple_models(self, model, expected):
        response = completion(
            model=model,
            messages=[{"role": "user", "content": "Test"}],
            mock_response={"choices": [{"message": {"content": expected}}]}
        )
        assert response.choices[0].message.content == expected
```

## 3. LLM Benchmarking

### Setting Up Benchmarking Framework

1. Basic Benchmark Configuration
```python
from litellm import benchmark

benchmark_config = {
    "models": [
        "gpt-3.5-turbo",
        "claude-2",
        "palm/chat-bison"
    ],
    "test_cases": [
        {
            "messages": [{"role": "user", "content": "What is 2+2?"}],
            "expected": "4"
        }
    ],
    "metrics": ["accuracy", "latency", "cost"]
}

results = benchmark.run(benchmark_config)
```

2. Custom Evaluation Metrics
```python
def custom_metric(response, expected):
    return {
        "score": 1.0 if expected in response else 0.0,
        "reasoning": "Exact match found" if expected in response else "No match"
    }

benchmark_config["metrics"].append({
    "name": "custom_metric",
    "function": custom_metric
})
```

3. Advanced Benchmarking
```python
from litellm.benchmark import BenchmarkSuite

class CustomBenchmark(BenchmarkSuite):
    def setup(self):
        self.load_test_cases("test_cases.json")
        self.setup_logging()
    
    def evaluate_response(self, response, test_case):
        metrics = {
            "latency": response.response_ms,
            "tokens": response.usage.total_tokens,
            "cost": self.calculate_cost(response)
        }
        return metrics
    
    def calculate_cost(self, response):
        return response.usage.total_tokens * self.get_token_cost(response.model)
```

## 4. Performance Testing

### Load Testing Implementation

1. Basic Load Test
```python
from litellm.testing import LoadTester

load_test = LoadTester(
    model="gpt-3.5-turbo",
    num_requests=100,
    concurrent_requests=10
)

results = load_test.run()
```

2. Advanced Load Testing Scenarios
```python
class CustomLoadTest(LoadTester):
    def __init__(self):
        self.metrics = {
            "success_rate": 0,
            "avg_latency": 0,
            "throughput": 0
        }
    
    async def execute_test(self):
        start_time = time.time()
        responses = await self.send_concurrent_requests()
        end_time = time.time()
        
        self.calculate_metrics(responses, end_time - start_time)
    
    def calculate_metrics(self, responses, duration):
        self.metrics["success_rate"] = len([r for r in responses if r.success]) / len(responses)
        self.metrics["avg_latency"] = sum([r.latency for r in responses]) / len(responses)
        self.metrics["throughput"] = len(responses) / duration
```

3. Performance Monitoring
```python
class PerformanceMonitor:
    def __init__(self):
        self.metrics = []
    
    def record_metric(self, name, value):
        self.metrics.append({
            "name": name,
            "value": value,
            "timestamp": time.time()
        })
    
    def generate_report(self):
        return {
            "summary": self.calculate_summary(),
            "detailed_metrics": self.metrics
        }
    
    def calculate_summary(self):
        return {
            metric["name"]: {
                "min": min(m["value"] for m in self.metrics if m["name"] == metric["name"]),
                "max": max(m["value"] for m in self.metrics if m["name"] == metric["name"]),
                "avg": sum(m["value"] for m in self.metrics if m["name"] == metric["name"]) / 
                      len([m for m in self.metrics if m["name"] == metric["name"]])
            }
            for metric in self.metrics
        }
```

## 5. Integration Testing

### Integration Test Implementation

1. Basic Integration Tests
```python
class TestProxyIntegration:
    def test_proxy_completion(self):
        proxy = LiteLLMProxy(config="test_config.yaml")
        
        response = proxy.completion(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": "Test"}]
        )
        
        assert response.status_code == 200
        assert "choices" in response.json()
```

2. Testing Multiple Components
```python
class TestRouterIntegration:
    @pytest.fixture
    def router(self):
        return Router(
            model_list=[...],
            cache_config={...},
            callback_list=[...]
        )
    
    def test_routing_with_cache(self, router):
        # First call - should hit API
        response1 = router.completion(...)
        
        # Second call - should hit cache
        response2 = router.completion(...)
        
        assert response1.id != response2.id
        assert response1.choices[0].message.content == response2.choices[0].message.content
```

3. End-to-End Testing
```python
class TestEndToEnd:
    def test_complete_flow(self):
        # Initialize components
        router = Router(...)
        cache = Cache(...)
        callbacks = [MockCallback(), LogCallback()]
        
        # Test flow
        response = router.completion(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": "Test"}],
            cache=cache,
            callbacks=callbacks
        )
        
        # Verify results
        assert response.success
        assert cache.get(response.cache_key) is not None
        assert all(callback.called for callback in callbacks)
```

## 6. Automated Testing Pipeline

### CI/CD Implementation

1. GitHub Actions Configuration
```yaml
# .github/workflows/test.yml
name: LiteLLM Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: [3.8, 3.9, 3.10]
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: ${{ matrix.python-version }}
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements-test.txt
    
    - name: Run tests
      run: |
        pytest tests/ --cov=litellm --cov-report=xml
    
    - name: Upload coverage
      uses: codecov/codecov-action@v2
```

2. Pre-commit Hooks
```yaml
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.4.0
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
      - id: check-yaml
  
  - repo: https://github.com/PyCQA/flake8
    rev: 6.0.0
    hooks:
      - id: flake8
        additional_dependencies: [flake8-docstrings]
  
  - repo: https://github.com/psf/black
    rev: 23.3.0
    hooks:
      - id: black
```

3. Continuous Testing Setup
```python
# test_runner.py
class ContinuousTestRunner:
    def __init__(self):
        self.test_suites = {
            "unit": unittest.TestLoader().discover("tests/unit"),
            "integration": unittest.TestLoader().discover("tests/integration"),
            "performance": unittest.TestLoader().discover("tests/performance")
        }
    
    def run_all_tests(self):
        results = {}
        for suite_name, suite in self.test_suites.items():
            runner = unittest.TextTestRunner()
            result = runner.run(suite)
            results[suite_name] = {
                "runs": result.testsRun,
                "failures": len(result.failures),
                "errors": len(result.errors)
            }
        return results
```

## 7. Evaluation Frameworks

### Implementing Evaluation Frameworks

1. Basic Evaluation Setup
```python
from litellm.evaluation import Evaluator

evaluator = Evaluator(
    metrics=["accuracy", "latency", "cost"],
    test_cases="test_cases.json"
)

results = evaluator.evaluate(model="gpt-3.5-turbo")
```

2. Custom Evaluation Metrics
```python
class CustomEvaluator:
    def __init__(self):
        self.metrics = []
    
    def add_metric(self, name, function):
        self.metrics.append({
            "name": name,
            "function": function
        })
    
    def evaluate_response(self, response, expected):
        results = {}
        for metric in self.metrics:
            results[metric["name"]] = metric["function"](response, expected)
        return results
```

3. Comprehensive Evaluation Framework
```python
class ComprehensiveEvaluator:
    def __init__(self):
        self.frameworks = {
            "accuracy": AccuracyEvaluator(),
            "performance": PerformanceEvaluator(),
            "cost": CostEvaluator()
        }
    
    def evaluate_model(self, model, test_cases):
        results = {
            framework: evaluator.evaluate(model, test_cases)
            for framework, evaluator in self.frameworks.items()
        }
        
        return self.aggregate_results(results)
    
    def aggregate_results(self, results):
        # Combine results from different frameworks
        return {
            "overall_score": self.calculate_overall_score(results),
            "detailed_results": results,
            "recommendations": self.generate_recommendations(results)
        }
```

## Exercises and Practice Tasks

1. Basic Testing Setup
- Create a basic test suite for LiteLLM
- Implement mock responses
- Write basic unit tests

2. Performance Testing
- Create a load testing script
- Measure and analyze performance metrics
- Implement performance monitoring

3. Integration Testing
- Set up integration tests for the proxy server
- Test multiple component interactions
- Implement end-to-end tests

4. Evaluation Framework
- Create a custom evaluation framework
- Implement multiple evaluation metrics
- Generate comprehensive evaluation reports

5. Automated Testing
- Set up GitHub Actions for continuous testing
- Implement pre-commit hooks
- Create automated test reports

## Additional Resources

1. Testing Documentation
- [LiteLLM Testing Guide](https://docs.litellm.ai/docs/testing)
- [Performance Testing Docs](https://docs.litellm.ai/docs/performance)

2. Example Implementations
- [Test Suite Examples](https://github.com/BerriAI/litellm/tree/main/tests)
- [Evaluation Framework Examples](https://github.com/BerriAI/litellm/tree/main/examples/evaluation)

3. Best Practices
- [Testing Best Practices Guide](https://docs.litellm.ai/docs/testing/best_practices)
- [Performance Testing Guidelines](https://docs.litellm.ai/docs/testing/performance)

4. Community Resources
- [Testing Discussion Forum](https://github.com/BerriAI/litellm/discussions/category/testing)
- [Performance Benchmarks](https://github.com/BerriAI/litellm/discussions/category/benchmarks)