# Lesson 3: Working with Multiple LLM Providers

## Project Structure

Let's set up our project structure for working with multiple providers:

```plaintext
multi-provider-litellm/
├── .env                        # Environment variables
├── requirements.txt            # Project dependencies
├── config/
│   └── provider_config.yaml    # Provider configurations
└── src/
    ├── provider_setup.py       # Provider initialization
    ├── load_balancer.py        # Load balancing logic
    ├── fallback_handler.py     # Fallback implementations
    ├── rate_limiter.py        # Rate limiting logic
    └── templates/             # Custom prompt templates
        └── custom_prompts.py
```

## Section 1: Setting Up Multiple Providers

First, let's create our configuration file `config/provider_config.yaml`:

```yaml
model_list:
  - model_name: gpt-4
    litellm_params:
      model: azure/gpt-4
      api_base: https://azure1.openai.azure.com/
      api_key: os.environ/AZURE_API_KEY_1
      api_version: "2023-07-01-preview"
      rpm: 6

  - model_name: gpt-4
    litellm_params:
      model: azure/gpt-4-backup
      api_base: https://azure2.openai.azure.com/
      api_key: os.environ/AZURE_API_KEY_2
      api_version: "2023-07-01-preview"
      rpm: 6

  - model_name: gpt-3.5-turbo
    litellm_params:
      model: openai/gpt-3.5-turbo
      api_key: os.environ/OPENAI_API_KEY

  - model_name: claude-2
    litellm_params:
      model: anthropic/claude-2
      api_key: os.environ/ANTHROPIC_API_KEY

litellm_settings:
  fallbacks: [{"gpt-4": ["gpt-3.5-turbo", "claude-2"]}]
  context_window_fallbacks: [{"gpt-4": ["gpt-4-32k"]}]
  allowed_fails: 3
  retry_after: 60
```

Now let's create our provider setup code in `src/provider_setup.py`:

```python
from litellm import Router
import os
import yaml
from typing import Dict, List
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ProviderManager:
    def __init__(self, config_path: str):
        self.config_path = config_path
        self.router = None
        self.load_config()
        
    def load_config(self):
        """Load and validate configuration"""
        try:
            with open(self.config_path, 'r') as file:
                config = yaml.safe_load(file)
                
            # Initialize router with config
            self.router = Router(
                model_list=config["model_list"],
                fallbacks=config.get("litellm_settings", {}).get("fallbacks", []),
                context_window_fallbacks=config.get("litellm_settings", {}).get("context_window_fallbacks", []),
                allowed_fails=config.get("litellm_settings", {}).get("allowed_fails", 3),
                retry_after=config.get("litellm_settings", {}).get("retry_after", 60)
            )
            
            logger.info(f"Successfully initialized {len(config['model_list'])} model deployments")
            
        except Exception as e:
            logger.error(f"Failed to load config: {str(e)}")
            raise
    
    async def get_completion(self, model: str, messages: List[Dict], **kwargs):
        """
        Get completion using the router
        """
        try:
            response = await self.router.acompletion(
                model=model,
                messages=messages,
                **kwargs
            )
            return response
        except Exception as e:
            logger.error(f"Error getting completion: {str(e)}")
            raise

    def get_available_models(self) -> List[str]:
        """
        Get list of available models
        """
        return list(set(m["model_name"] for m in self.router.model_list))

```

## Section 2: Implementing Load Balancing

Create `src/load_balancer.py` to implement custom load balancing strategies:

```python
from litellm import Router
from typing import List, Dict, Optional
import random
import time
import asyncio
from collections import defaultdict

class LoadBalancer:
    def __init__(self, router: Router):
        self.router = router
        self.usage_metrics = defaultdict(lambda: {
            "requests": 0,
            "tokens": 0,
            "last_used": 0,
            "errors": 0
        })
        
    def _update_metrics(self, model_id: str, tokens: int = 0, error: bool = False):
        """Update usage metrics for a model"""
        self.usage_metrics[model_id]["requests"] += 1
        self.usage_metrics[model_id]["tokens"] += tokens
        self.usage_metrics[model_id]["last_used"] = time.time()
        if error:
            self.usage_metrics[model_id]["errors"] += 1

    async def least_busy_deployment(self, model_name: str) -> Optional[Dict]:
        """
        Select least busy deployment based on recent usage
        """
        available_deployments = [
            m for m in self.router.model_list 
            if m["model_name"] == model_name
        ]
        
        if not available_deployments:
            return None
        
        # Sort by number of recent requests
        sorted_deployments = sorted(
            available_deployments,
            key=lambda x: self.usage_metrics[x.get("model_info", {}).get("id", "")]["requests"]
        )
        
        return sorted_deployments[0]

    async def latency_based_deployment(self, model_name: str) -> Optional[Dict]:
        """
        Test latency to each deployment and choose fastest
        """
        available_deployments = [
            m for m in self.router.model_list 
            if m["model_name"] == model_name
        ]
        
        if not available_deployments:
            return None
        
        async def test_latency(deployment):
            start_time = time.time()
            try:
                test_message = [{"role": "user", "content": "test"}]
                await self.router.acompletion(
                    model=deployment["model_name"],
                    messages=test_message,
                    max_tokens=1
                )
                return deployment, time.time() - start_time
            except Exception as e:
                return deployment, float('inf')
        
        # Test all deployments concurrently
        latency_tests = [test_latency(d) for d in available_deployments]
        results = await asyncio.gather(*latency_tests)
        
        # Sort by latency
        sorted_results = sorted(results, key=lambda x: x[1])
        return sorted_results[0][0]

    async def cost_based_deployment(self, model_name: str) -> Optional[Dict]:
        """
        Choose deployment based on cost efficiency
        """
        available_deployments = [
            m for m in self.router.model_list 
            if m["model_name"] == model_name
        ]
        
        if not available_deployments:
            return None
        
        # Calculate cost efficiency (tokens processed / total cost)
        def calculate_efficiency(deployment):
            metrics = self.usage_metrics[deployment.get("model_info", {}).get("id", "")]
            total_tokens = metrics["tokens"]
            # Get cost per token from deployment config or default
            cost_per_token = deployment.get("litellm_params", {}).get("cost_per_token", 0.0001)
            total_cost = total_tokens * cost_per_token
            
            if total_cost == 0:
                return float('inf')
            return total_tokens / total_cost
        
        # Sort by efficiency
        sorted_deployments = sorted(
            available_deployments,
            key=calculate_efficiency,
            reverse=True
        )
        
        return sorted_deployments[0]
```

## Section 3: Implementing Fallback Strategies

Create `src/fallback_handler.py`:

```python
from litellm import Router
from typing import List, Dict, Optional
import logging
import time
from enum import Enum

logger = logging.getLogger(__name__)

class FallbackTrigger(Enum):
    ERROR = "error"
    TIMEOUT = "timeout"
    CONTENT_VIOLATION = "content_violation"
    CONTEXT_WINDOW = "context_window"

class FallbackHandler:
    def __init__(self, router: Router):
        self.router = router
        self.fallback_history = []
        
    def _record_fallback(self, 
                        original_model: str, 
                        fallback_model: str, 
                        trigger: FallbackTrigger,
                        error_message: str):
        """Record fallback event for analysis"""
        self.fallback_history.append({
            "timestamp": time.time(),
            "original_model": original_model,
            "fallback_model": fallback_model,
            "trigger": trigger.value,
            "error_message": error_message
        })
    
    async def handle_fallback(self, 
                            error: Exception, 
                            model: str, 
                            messages: List[Dict],
                            **kwargs) -> Optional[Dict]:
        """
        Handle different types of errors with appropriate fallback strategies
        """
        try:
            # Determine fallback trigger
            if "context length" in str(error).lower():
                trigger = FallbackTrigger.CONTEXT_WINDOW
                fallback_models = self.router.context_window_fallbacks.get(model, [])
            elif "content policy violation" in str(error).lower():
                trigger = FallbackTrigger.CONTENT_VIOLATION
                fallback_models = self.router.content_policy_fallbacks.get(model, [])
            elif "timeout" in str(error).lower():
                trigger = FallbackTrigger.TIMEOUT
                fallback_models = self.router.fallbacks.get(model, [])
            else:
                trigger = FallbackTrigger.ERROR
                fallback_models = self.router.fallbacks.get(model, [])
            
            # Try fallback models
            for fallback_model in fallback_models:
                try:
                    response = await self.router.acompletion(
                        model=fallback_model,
                        messages=messages,
                        **kwargs
                    )
                    
                    self._record_fallback(
                        original_model=model,
                        fallback_model=fallback_model,
                        trigger=trigger,
                        error_message=str(error)
                    )
                    
                    return response
                    
                except Exception as e:
                    logger.error(f"Fallback to {fallback_model} failed: {str(e)}")
                    continue
            
            # If all fallbacks fail, raise original error
            raise error
            
        except Exception as e:
            logger.error(f"Error in fallback handler: {str(e)}")
            raise
```

## Section 4: Rate Limiting Implementation

Create `src/rate_limiter.py`:

```python
import time
import asyncio
from collections import defaultdict
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)

class RateLimiter:
    def __init__(self):
        self.request_counts = defaultdict(lambda: {
            "count": 0,
            "last_reset": time.time()
        })
        self.token_counts = defaultdict(lambda: {
            "count": 0,
            "last_reset": time.time()
        })
        
    def _should_reset(self, last_reset: float, interval: int) -> bool:
        """Check if the counting window should be reset"""
        return time.time() - last_reset >= interval
    
    def _reset_counts(self, model_id: str):
        """Reset request and token counts"""
        self.request_counts[model_id] = {
            "count": 0,
            "last_reset": time.time()
        }
        self.token_counts[model_id] = {
            "count": 0,
            "last_reset": time.time()
        }
    
    async def check_rate_limit(self, 
                             model_id: str, 
                             rpm_limit: int,
                             tpm_limit: Optional[int] = None) -> bool:
        """
        Check if request is within rate limits
        """
        current_time = time.time()
        
        # Reset counts if minute has passed
        if self._should_reset(self.request_counts[model_id]["last_reset"], 60):
            self._reset_counts(model_id)
        
        # Check RPM
        if self.request_counts[model_id]["count"] >= rpm_limit:
            logger.warning(f"RPM limit ({rpm_limit}) exceeded for {model_id}")
            return False
        
        # Check TPM if specified
        if tpm_limit and self.token_counts[model_id]["count"] >= tpm_limit:
            logger.warning(f"TPM limit ({tpm_limit}) exceeded for {model_id}")
            return False
        
        return True
    
    def update_counts(self, model_id: str, tokens_used: int = 0):
        """
        Update request and token counts
        """
        self.request_counts[model_id]["count"] += 1
        self.token_counts[model_id]["count"] += tokens_used
```

## Section 5: Custom Prompt Templates

Create `src/templates/custom_prompts.py`:

```python
from typing import Dict, List
import litellm

class PromptTemplate:
    def __init__(self):
        self.templates = {}
        
    def register_template(self, model: str, template: Dict):
        """