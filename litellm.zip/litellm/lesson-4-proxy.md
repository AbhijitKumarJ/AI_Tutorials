# Lesson 4: LiteLLM Proxy Server - From Setup to Production

## Table of Contents
1. [Understanding LiteLLM Proxy Architecture](#1-understanding-litellm-proxy-architecture)
2. [Setting Up Your First Proxy Server](#2-setting-up-your-first-proxy-server)
3. [Virtual Key Management](#3-virtual-key-management)
4. [Advanced Load Balancing](#4-advanced-load-balancing)
5. [Logging and Monitoring](#5-logging-and-monitoring)
6. [Tracking Costs](#6-tracking-costs)
7. [Security and Authentication](#7-security-and-authentication)
8. [Production Deployment](#8-production-deployment)

## Learning Objectives
By the end of this lesson, you will be able to:
- Set up and configure a LiteLLM proxy server
- Manage virtual API keys securely
- Implement load balancing across multiple LLM providers
- Configure comprehensive logging and monitoring
- Track and analyze API costs
- Secure your proxy server
- Deploy to production

## 1. Understanding LiteLLM Proxy Architecture

### Overview
The LiteLLM proxy server provides an OpenAI-compatible server interface that can route requests to 100+ LLM providers. Here's the high-level architecture:

```plaintext
┌──────────────┐         ┌──────────────┐         ┌──────────────┐
│              │         │  LiteLLM     │         │   LLM        │
│   Client     │ ───────▶│   Proxy      │ ───────▶│  Providers   │
│              │         │   Server     │         │              │
└──────────────┘         └──────────────┘         └──────────────┘
                               │
                               │
                        ┌──────┴──────┐
                        │   Redis/DB  │
                        │  (Optional) │
                        └─────────────┘
```

### Key Components
1. **Router**: Handles request routing to different LLM providers
2. **Virtual Key Manager**: Manages API key authentication and permissions
3. **Load Balancer**: Distributes traffic across models/providers
4. **Logging System**: Captures request/response data
5. **Cost Tracker**: Monitors API usage and costs

## 2. Setting Up Your First Proxy Server

### Project Structure
```plaintext
my-litellm-proxy/
├── config.yaml       # LiteLLM configuration
├── .env             # Environment variables
├── requirements.txt  # Python dependencies
└── logs/            # Log directory
```

### Basic Setup Steps

1. Install Required Packages
```bash
pip install 'litellm[proxy]'
```

2. Create config.yaml
```yaml
model_list:
  - model_name: gpt-4
    litellm_params:
      model: gpt-4
      api_key: sk-...
  
  - model_name: azure-gpt-4
    litellm_params:
      model: azure/gpt-4
      api_key: sk-...
      api_base: https://...
      api_version: 2023-05-15

general_settings:
  master_key: sk-1234 # For admin operations
  database_url: sqlite:///auth.db
```

3. Start the Proxy Server
```bash
litellm --config /path/to/config.yaml
```

4. Test the Connection
```bash
curl http://localhost:8000/health
```

## 3. Virtual Key Management

### Setting Up Virtual Keys

1. Generate Admin Key
```bash
litellm --init-key
```

2. Create Virtual Key with Specific Permissions
```bash
curl -X POST "http://localhost:8000/key/generate" \
  -H "Authorization: Bearer sk-1234" \
  -H "Content-Type: application/json" \
  -d '{
    "models": ["gpt-4", "azure-gpt-4"],
    "duration": "24h",
    "metadata": {
      "team": "ML",
      "project": "qa-bot"
    }
  }'
```

3. Key Management Operations
```yaml
# List all keys
GET /key/list

# Update key permissions
POST /key/update

# Delete key
DELETE /key/delete
```

## 4. Advanced Load Balancing

### Load Balancing Strategies

1. Simple Router Configuration
```yaml
router_settings:
  routing_strategy: "simple-shuffle"
  retry_attempts: 3
  timeout: 30
```

2. Usage-Based Routing
```yaml
router_settings:
  routing_strategy: "usage-based-routing"
  model_group: [
    {
      "model_name": "gpt-4",
      "deployments": [
        {
          "id": "deployment-1",
          "rpm": 10000
        },
        {
          "id": "deployment-2",
          "rpm": 5000
        }
      ]
    }
  ]
```

3. Implementing Fallbacks
```yaml
router_settings:
  fallbacks: [
    {
      "gpt-4": ["azure-gpt-4", "anthropic-claude-2"]
    }
  ]
```

## 5. Logging and Monitoring

### Setting Up Logging

1. Basic Logging Configuration
```yaml
litellm_settings:
  callbacks: ["local_logger"]
  log_level: "debug"
```

2. Advanced Logging with External Services
```yaml
litellm_settings:
  callbacks: ["langfuse", "prometheus"]
  langfuse_public_key: "pk-..."
  langfuse_secret_key: "sk-..."
```

3. Request/Response Logging Schema
```python
log_event = {
    "timestamp": "2024-01-16T10:00:00Z",
    "request_id": "req_123",
    "model": "gpt-4",
    "input_tokens": 150,
    "output_tokens": 50,
    "duration_ms": 2000,
    "success": true,
    "error": null,
    "cost": 0.15
}
```

## 6. Tracking Costs

### Cost Tracking Setup

1. Enable Cost Tracking
```yaml
litellm_settings:
  track_costs: true
  cost_tracking_mode: "detailed"
```

2. Cost Limits and Budgets
```yaml
budget_settings:
  total_budget: 100.00
  user_budgets:
    team_ml: 50.00
    team_research: 30.00
```

3. Cost Reporting
```python
# Get cost reports
GET /costs/report
{
    "total_costs": 85.50,
    "costs_by_model": {
        "gpt-4": 45.20,
        "azure-gpt-4": 40.30
    },
    "costs_by_team": {
        "team_ml": 35.40,
        "team_research": 50.10
    }
}
```

## 7. Security and Authentication

### Security Configurations

1. Basic Authentication
```yaml
general_settings:
  master_key: "sk-1234"
  auth_strategy: "bearer_token"
```

2. Advanced Security Settings
```yaml
security_settings:
  allowed_domains: ["company.com"]
  rate_limits:
    global_rpm: 1000
    user_rpm: 100
  cors_settings:
    allowed_origins: ["https://app.company.com"]
```

3. SSL/TLS Configuration
```yaml
ssl_settings:
  cert_file: "/path/to/cert.pem"
  key_file: "/path/to/key.pem"
```

## 8. Production Deployment

### Deployment Checklist

1. Environment Configuration
```bash
# Production environment variables
export LITELLM_ENV=production
export MASTER_KEY=sk-...
export DATABASE_URL=postgresql://...
```

2. Docker Deployment
```dockerfile
# Dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY config.yaml .
COPY .env .

CMD ["litellm", "--config", "config.yaml"]
```

3. Kubernetes Deployment
```yaml
# kubernetes/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: litellm-proxy
spec:
  replicas: 3
  template:
    spec:
      containers:
      - name: litellm-proxy
        image: litellm-proxy:latest
        ports:
        - containerPort: 8000
        env:
        - name: LITELLM_ENV
          value: "production"
```

### Production Best Practices

1. High Availability Setup
- Use multiple replicas
- Implement health checks
- Set up monitoring and alerting
- Configure automatic scaling

2. Performance Optimization
- Enable caching where appropriate
- Optimize database queries
- Set proper timeout values
- Configure connection pooling

3. Security Measures
- Regular security audits
- API key rotation
- Rate limiting
- Request validation
- Error handling

4. Monitoring and Maintenance
- Set up metrics collection
- Configure log aggregation
- Implement backup strategies
- Plan upgrade procedures

## Exercises and Practice Tasks

1. Basic Proxy Setup
- Set up a basic proxy server with two different LLM providers
- Implement basic request logging
- Test the server with different types of requests

2. Load Balancing Implementation
- Configure load balancing between multiple model deployments
- Test failover scenarios
- Measure and optimize response times

3. Security Implementation
- Set up virtual keys with different permissions
- Implement rate limiting
- Configure SSL/TLS
- Test security measures

4. Production Deployment
- Create a Docker container for the proxy
- Set up Kubernetes deployment
- Implement monitoring and logging
- Test scaling and failover

## Additional Resources

1. Official Documentation
- [LiteLLM Proxy Documentation](https://docs.litellm.ai/docs/simple_proxy)
- [Configuration Reference](https://docs.litellm.ai/docs/proxy/configs)

2. Example Projects
- [Basic Proxy Implementation](https://github.com/BerriAI/litellm/tree/main/examples/proxy)
- [Production Setup Examples](https://github.com/BerriAI/litellm/tree/main/examples/production)