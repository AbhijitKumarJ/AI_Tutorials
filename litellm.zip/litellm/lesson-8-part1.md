# Lesson 8: Integration Projects (Part 1)
## Building Production-Ready LLM Applications with LiteLLM

### Overview
This lesson covers integrating LiteLLM into production applications, focusing on core patterns, framework integrations, and implementation strategies.

## Project Structure
```
litellm-integration/
├── core/
│   ├── config.py           # Core configuration
│   ├── llm_manager.py      # LLM management layer
│   └── middleware.py       # Common middleware
├── frameworks/
│   ├── fastapi_app/        # FastAPI integration
│   ├── flask_app/          # Flask integration
│   ├── streamlit_app/      # Streamlit integration
│   └── gradio_app/         # Gradio integration
├── services/
│   ├── completion.py       # Completion service
│   ├── embedding.py        # Embedding service
│   └── moderation.py       # Content moderation
└── utils/
    ├── logging.py          # Logging utilities
    ├── metrics.py          # Metrics collection
    └── error_handling.py   # Error handling
```

## 1. Core Integration Patterns

### LLM Manager Layer
```python
# core/llm_manager.py
from typing import List, Dict, Any, Optional
from litellm import Router, completion
import asyncio
import logging

class LLMManager:
    def __init__(self, config: Dict[str, Any]):
        self.router = Router(
            model_list=config["model_list"],
            fallbacks=config.get("fallbacks", []),
            cache_responses=config.get("cache_responses", True),
            timeout=config.get("timeout", 30),
            routing_strategy=config.get("routing_strategy", "simple-shuffle")
        )
        self.logger = logging.getLogger(__name__)

    async def process_completion(
        self,
        messages: List[Dict[str, str]],
        model: str,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stream: bool = False
    ):
        try:
            response = await self.router.acompletion(
                messages=messages,
                model=model,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=stream
            )
            return response
        except Exception as e:
            self.logger.error(f"Error in completion: {str(e)}")
            raise

    def get_model_info(self, model: str) -> Dict[str, Any]:
        """Get information about a specific model"""
        model_info = self.router.get_model_info(model)
        return {
            "name": model_info.get("name"),
            "max_tokens": model_info.get("max_tokens"),
            "tokenizer": model_info.get("tokenizer"),
            "provider": model_info.get("provider")
        }
```

### Configuration Management
```python
# core/config.py
from typing import Dict, Any
import yaml
import os

class Config:
    def __init__(self, config_path: str):
        self.config = self._load_config(config_path)
        self.model_configs = self._setup_models()
        self._validate_config()

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        return config

    def _setup_models(self) -> Dict[str, Any]:
        models = {}
        for model in self.config["model_list"]:
            models[model["model_name"]] = {
                "litellm_params": model["litellm_params"],
                "max_tokens": model.get("max_tokens"),
                "timeout": model.get("timeout", 30),
                "retry_count": model.get("retry_count", 3)
            }
        return models

    def _validate_config(self):
        required_keys = ["model_list", "router_settings"]
        for key in required_keys:
            if key not in self.config:
                raise ValueError(f"Missing required config key: {key}")
```

## 2. Framework Integrations

### FastAPI Integration
```python
# frameworks/fastapi_app/main.py
from fastapi import FastAPI, HTTPException, Depends
from typing import List, Optional
from pydantic import BaseModel
from core.llm_manager import LLMManager
from core.config import Config

app = FastAPI()
config = Config("config.yaml")
llm_manager = LLMManager(config.config)

class CompletionRequest(BaseModel):
    messages: List[dict]
    model: str
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = 1000
    stream: Optional[bool] = False

@app.post("/v1/completions")
async def create_completion(request: CompletionRequest):
    try:
        response = await llm_manager.process_completion(
            messages=request.messages,
            model=request.model,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            stream=request.stream
        )
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

### Streamlit Integration
```python
# frameworks/streamlit_app/app.py
import streamlit as st
from core.llm_manager import LLMManager
from core.config import Config
import asyncio

config = Config("config.yaml")
llm_manager = LLMManager(config.config)

st.title("LiteLLM Chat Interface")

# Session state initialization
if 'messages' not in st.session_state:
    st.session_state.messages = []

# Display chat messages
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Chat input
if prompt := st.chat_input("What would you like to know?"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Get AI response
    with st.chat_message("assistant"):
        async def get_response():
            response = await llm_manager.process_completion(
                messages=st.session_state.messages,
                model="gpt-4",
                stream=True
            )
            return response

        response = asyncio.run(get_response())
        st.session_state.messages.append(
            {"role": "assistant", "content": response.choices[0].message.content}
        )
        st.markdown(response.choices[0].message.content)
```

### Gradio Integration
```python
# frameworks/gradio_app/app.py
import gradio as gr
from core.llm_manager import LLMManager
from core.config import Config
import asyncio

config = Config("config.yaml")
llm_manager = LLMManager(config.config)

def format_message(user_message, history):
    messages = []
    for human, assistant in history:
        messages.append({"role": "user", "content": human})
        messages.append({"role": "assistant", "content": assistant})
    messages.append({"role": "user", "content": user_message})
    return messages

async def chat(user_message, history):
    messages = format_message(user_message, history)
    response = await llm_manager.process_completion(
        messages=messages,
        model="gpt-4",
        temperature=0.7
    )
    return response.choices[0].message.content

interface = gr.ChatInterface(
    fn=chat,
    title="LiteLLM Chat",
    description="Chat with multiple LLM models",
    examples=["Tell me about LiteLLM", "How do I use multiple models?"],
    retry_btn="Retry",
    undo_btn="Undo",
    clear_btn="Clear",
)

if __name__ == "__main__":
    interface.launch()
```

## 3. Service Layer Implementation

### Completion Service
```python
# services/completion.py
from typing import List, Dict, Any, Optional
from core.llm_manager import LLMManager
import asyncio

class CompletionService:
    def __init__(self, llm_manager: LLMManager):
        self.llm_manager = llm_manager

    async def batch_completion(
        self,
        messages_list: List[List[Dict[str, str]]],
        model: str,
        temperature: float = 0.7
    ) -> List[Any]:
        """Process multiple completion requests concurrently"""
        async def process_single(messages):
            return await self.llm_manager.process_completion(
                messages=messages,
                model=model,
                temperature=temperature
            )

        tasks = [process_single(messages) for messages in messages_list]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return results

    async def interactive_completion(
        self,
        messages: List[Dict[str, str]],
        model: str,
        callback: Optional[callable] = None
    ):
        """Stream responses with callback for interactive applications"""
        response = await self.llm_manager.process_completion(
            messages=messages,
            model=model,
            stream=True
        )
        
        async for chunk in response:
            if callback:
                await callback(chunk)
            yield chunk
```

### Error Handling
```python
# utils/error_handling.py
from typing import Dict, Any
import traceback
from litellm import (
    BadRequestError,
    AuthenticationError,
    RateLimitError,
    ServiceUnavailableError
)

class ErrorHandler:
    @staticmethod
    def handle_error(e: Exception) -> Dict[str, Any]:
        error_mapping = {
            BadRequestError: (400, "Bad Request"),
            AuthenticationError: (401, "Authentication Error"),
            RateLimitError: (429, "Rate Limit Exceeded"),
            ServiceUnavailableError: (503, "Service Unavailable")
        }

        error_class = type(e)
        status_code, message = error_mapping.get(
            error_class,
            (500, "Internal Server Error")
        )

        return {
            "error": {
                "message": str(e),
                "type": error_class.__name__,
                "status_code": status_code,
                "details": message,
                "traceback": traceback.format_exc()
            }
        }
```

## 4. Integration Best Practices

### 1. Error Handling and Logging
- Implement comprehensive error handling
- Use structured logging
- Track and monitor performance metrics
- Set up proper alerting

### 2. Caching Strategy
- Implement response caching
- Use distributed caching for scalability
- Set appropriate TTL values
- Handle cache invalidation

### 3. Rate Limiting
- Implement per-user and global rate limits
- Use token bucket algorithm
- Handle rate limit exceptions gracefully
- Implement backoff strategies

### 4. Security Considerations
- Implement proper authentication
- Validate and sanitize inputs
- Secure API keys and secrets
- Monitor for abuse

### 5. Performance Optimization
- Use connection pooling
- Implement request batching
- Optimize prompt handling
- Monitor and adjust timeouts

## Common Integration Patterns

### 1. Chain of Responsibility
```python
class LLMChain:
    def __init__(self, steps: List[callable]):
        self.steps = steps

    async def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        result = input_data
        for step in self.steps:
            result = await step(result)
        return result
```

### 2. Pub/Sub Pattern
```python
class LLMEventManager:
    def __init__(self):
        self.subscribers = {}

    def subscribe(self, event_type: str, callback: callable):
        if event_type not in self.subscribers:
            self.subscribers[event_type] = []
        self.subscribers[event_type].append(callback)

    async def publish(self, event_type: str, data: Any):
        if event_type in self.subscribers:
            for callback in self.subscribers[event_type]:
                await callback(data)
```

### 3. Factory Pattern
```python
class LLMFactory:
    @staticmethod
    def create_llm(provider: str, config: Dict[str, Any]) -> LLMManager:
        if provider == "openai":
            return OpenAIManager(config)
        elif provider == "anthropic":
            return AnthropicManager(config)
        elif provider == "azure":
            return AzureManager(config)
        raise ValueError(f"Unsupported provider: {provider}")
```

## Testing Strategies

### 1. Unit Testing
```python
# test_llm_manager.py
import pytest
from core.llm_manager import LLMManager

@pytest.mark.asyncio
async def test_completion():
    config = {
        "model_list": [
            {
                "model_name": "gpt-4",
                "litellm_params": {
                    "mock_response": "Test response"
                }
            }
        ]
    }
    manager = LLMManager(config)
    response = await manager.process_completion(
        messages=[{"role": "user", "content": "test"}],
        model="gpt-4"
    )
    assert response.choices[0].message.content == "Test response"
```

### 2. Integration Testing
```python
# test_integration.py
import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_completion_endpoint():
    response = client.post(
        "/v1/completions",
        json={
            "messages": [{"role": "user", "content": "test"}],
            "model": "gpt-4"
        }
    )
    assert response.status_code == 200
    assert "choices" in response.json()
```

## Deployment Considerations

### 1. Environment Configuration
```yaml
# config/production.yaml
environment: production
redis_cache:
  host: redis.production.internal
  port: 6379
monitoring:
  enabled: true
  provider: datadog
rate_limiting:
  enabled: true
  redis_key_prefix: prod
```

### 2. Health Checks
```python
@app.get("/health")
async def health_check():
    try:
        # Check LLM connectivity
        response = await llm_manager.process_completion(
            messages=[{"role": "user", "content": "test"}],
            model="gpt-4"
        )
        return {"status": "healthy", "latency": response.latency}
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}
```

## Further Reading and Resources
1. [LiteLLM Documentation](https://docs.litellm.ai/docs/)
2. [FastAPI Documentation](https://fastapi.tiangolo.com/)
3. [Streamlit Documentation](https://docs.streamlit.io/)
4. [Gradio Documentation](https://gradio.app/docs/)