# Lesson 2: Core LiteLLM Operations

## Section 1: Deep Dive into Completion Function

Let's create a project structure to explore core LiteLLM operations:

```plaintext
litellm-core/
├── .env                    # API keys and configuration
├── requirements.txt        # Project dependencies
└── src/
    ├── completion_ops.py   # Completion operations
    ├── streaming_ops.py    # Streaming operations
    ├── async_ops.py       # Async operations
    └── error_handling.py  # Error handling examples
```

Let's start with understanding the completion function in detail. Create `src/completion_ops.py`:

```python
from litellm import completion
import os
from dotenv import load_dotenv

load_dotenv()

def explore_completion_parameters():
    """
    Demonstrate different parameters of the completion function
    """
    # Basic messages structure
    messages = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Write a short poem about programming."}
    ]
    
    # 1. Basic completion with temperature control
    response = completion(
        model="gpt-3.5-turbo",
        messages=messages,
        temperature=0.2  # Lower temperature for more focused outputs
    )
    print("1. Controlled Temperature Output:", response.choices[0].message.content)
    
    # 2. Completion with max tokens and stop sequences
    response = completion(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": "Count from 1 to 10"}],
        max_tokens=20,
        stop=["5"]  # Stop when reaching number 5
    )
    print("\n2. Limited Output:", response.choices[0].message.content)
    
    # 3. Completion with presence and frequency penalties
    response = completion(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": "Write three similar sentences"}],
        presence_penalty=0.6,  # Encourage diversity in tokens
        frequency_penalty=0.6  # Discourage token repetition
    )
    print("\n3. Diverse Output:", response.choices[0].message.content)

```

## Section 2: Understanding Chat vs Text Completions

LiteLLM supports both chat and text completion formats. Let's explore both in `src/completion_ops.py`:

```python
def compare_completion_types():
    """
    Compare chat completions vs text completions
    """
    # Chat completion
    chat_response = completion(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "user", "content": "Explain what is an API"}
        ]
    )
    
    # Text completion (older format)
    from litellm import text_completion
    text_response = text_completion(
        model="gpt-3.5-turbo",
        prompt="Explain what is an API"
    )
    
    print("Chat Completion:", chat_response.choices[0].message.content)
    print("\nText Completion:", text_response.choices[0].text)
```

## Section 3: Streaming Responses

Streaming is crucial for real-time applications. Create `src/streaming_ops.py`:

```python
from litellm import completion

def stream_completion():
    """
    Demonstrate streaming responses
    """
    messages = [{"role": "user", "content": "Write a story about a programmer"}]
    
    # Basic streaming
    response = completion(
        model="gpt-3.5-turbo",
        messages=messages,
        stream=True
    )
    
    print("Streaming Response:")
    for chunk in response:
        if hasattr(chunk.choices[0].delta, 'content'):
            print(chunk.choices[0].delta.content, end='', flush=True)

def stream_with_callback():
    """
    Streaming with custom callback handling
    """
    def custom_callback(chunk):
        # Process each chunk as needed
        if hasattr(chunk.choices[0].delta, 'content'):
            content = chunk.choices[0].delta.content
            # You could save to database, process, or transform here
            print(f"Processing chunk: {content}")
    
    messages = [{"role": "user", "content": "Tell me about streaming APIs"}]
    
    response = completion(
        model="gpt-3.5-turbo",
        messages=messages,
        stream=True,
        stream_callback=custom_callback
    )
    
    # Consume the stream
    for chunk in response:
        pass  # Processing handled by callback
```

## Section 4: Async Operations

For high-performance applications, async operations are essential. Create `src/async_ops.py`:

```python
import asyncio
from litellm import acompletion

async def async_completion_example():
    """
    Demonstrate async completion operations
    """
    messages = [{"role": "user", "content": "What is async programming?"}]
    
    response = await acompletion(
        model="gpt-3.5-turbo",
        messages=messages
    )
    print("Async Response:", response.choices[0].message.content)

async def parallel_completions():
    """
    Demonstrate parallel async completions
    """
    messages = [
        {"role": "user", "content": "What is Python?"},
        {"role": "user", "content": "What is JavaScript?"},
        {"role": "user", "content": "What is Rust?"}
    ]
    
    # Create tasks for parallel execution
    tasks = [
        acompletion(model="gpt-3.5-turbo", messages=[msg])
        for msg in messages
    ]
    
    # Execute all tasks concurrently
    responses = await asyncio.gather(*tasks)
    
    for i, response in enumerate(responses):
        print(f"\nQuery {i+1} Response:", response.choices[0].message.content)

# Run async functions
if __name__ == "__main__":
    asyncio.run(parallel_completions())
```

## Section 5: Error Handling and Exception Management

Proper error handling is crucial. Create `src/error_handling.py`:

```python
from litellm import completion
from litellm.exceptions import (
    BadRequestError,
    ContextWindowExceededError,
    RateLimitError,
    InvalidRequestError
)

def demonstrate_error_handling():
    """
    Show how to handle different types of errors
    """
    # 1. Handle Context Length
    try:
        long_message = "hello " * 1000000
        completion(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": long_message}]
        )
    except ContextWindowExceededError as e:
        print(f"Context Window Error: {e}")
    
    # 2. Handle Rate Limits
    try:
        # Simulate rapid requests
        for _ in range(100):
            completion(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": "Quick test"}]
            )
    except RateLimitError as e:
        print(f"Rate Limit Error: {e}")
    
    # 3. Handle Invalid Requests
    try:
        completion(
            model="non-existent-model",
            messages=[{"role": "user", "content": "Test"}]
        )
    except InvalidRequestError as e:
        print(f"Invalid Request Error: {e}")

def implement_retry_logic():
    """
    Implement retry logic for handling transient errors
    """
    from litellm import completion_with_retries
    
    response = completion_with_retries(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": "Test with retries"}],
        max_retries=3,
        retry_delay=1
    )
    return response
```

## Section 6: Cost Tracking and Budget Management

Let's explore cost tracking features:

```python
from litellm import completion, completion_cost

def track_costs():
    """
    Demonstrate cost tracking functionality
    """
    messages = [{"role": "user", "content": "Write a short story"}]
    
    # Make completion call
    response = completion(
        model="gpt-3.5-turbo",
        messages=messages
    )
    
    # Calculate cost
    cost = completion_cost(completion_response=response)
    print(f"Request cost: ${cost}")
    
    # Track accumulated costs
    print(f"Total tokens used: {response.usage.total_tokens}")
    print(f"Prompt tokens: {response.usage.prompt_tokens}")
    print(f"Completion tokens: {response.usage.completion_tokens}")
```

## Practice Exercise: Building a Production-Ready Chat Application

Let's combine everything we've learned into a robust chat application:

```python
import asyncio
import os
from litellm import completion, completion_cost, BadRequestError, RateLimitError
from typing import List, Dict
import json
from datetime import datetime

class ChatApplication:
    def __init__(self):
        self.conversation_history: List[Dict] = []
        self.total_cost = 0.0
        
    async def process_message(self, user_input: str):
        """
        Process a single message with error handling and cost tracking
        """
        try:
            # Add user message to history
            self.conversation_history.append({
                "role": "user",
                "content": user_input,
                "timestamp": datetime.now().isoformat()
            })
            
            # Get completion with streaming
            response = completion(
                model="gpt-3.5-turbo",
                messages=self.conversation_history,
                stream=True
            )
            
            # Process stream
            collected_message = []
            async for chunk in response:
                if hasattr(chunk.choices[0].delta, 'content'):
                    content = chunk.choices[0].delta.content
                    collected_message.append(content)
                    print(content, end='', flush=True)
            
            # Calculate cost
            cost = completion_cost(completion_response=response)
            self.total_cost += cost
            
            # Add assistant response to history
            self.conversation_history.append({
                "role": "assistant",
                "content": ''.join(collected_message),
                "timestamp": datetime.now().isoformat()
            })
            
            # Save conversation to file
            self.save_conversation()
            
        except RateLimitError:
            print("\nRate limit reached. Waiting before retry...")
            await asyncio.sleep(20)
            return await self.process_message(user_input)
            
        except BadRequestError as e:
            print(f"\nError in request: {e}")
            return False
            
        except Exception as e:
            print(f"\nUnexpected error: {e}")
            return False
            
        return True
    
    def save_conversation(self):
        """
        Save conversation history to file
        """
        with open('chat_history.json', 'w') as f:
            json.dump({
                'history': self.conversation_history,
                'total_cost': self.total_cost
            }, f, indent=2)

async def main():
    chat = ChatApplication()
    print("Welcome to the Production Chat Application!")
    print(f"Type 'exit' to quit, 'cost' to see total cost")
    
    while True:
        user_input = input("\nYou: ")
        
        if user_input.lower() == 'exit':
            break
        elif user_input.lower() == 'cost':
            print(f"\nTotal cost so far: ${chat.total_cost:.4f}")
            continue
            
        success = await chat.process_message(user_input)
        if not success:
            print("\nFailed to process message. Please try again.")

if __name__ == "__main__":
    asyncio.run(main())
```

## Conclusion and Next Steps

In this lesson, we've covered:
- Detailed understanding of completion function parameters
- Chat vs Text completion differences
- Streaming implementations
- Async operations and parallel processing
- Comprehensive error handling
- Cost tracking and management
- Building a production-ready application

Practice Exercises:
1. Modify the chat application to support multiple models with fallbacks
2. Implement a token budget limit in the chat application
3. Add support for system messages and conversation management
4. Implement a message queue for handling high volume of requests
5. Add logging and monitoring capabilities

In the next lesson, we'll explore working with multiple LLM providers, including load balancing and fallback strategies.
