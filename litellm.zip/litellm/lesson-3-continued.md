## Section 5: Custom Prompt Templates

Create `src/templates/custom_prompts.py`:

```python
from typing import Dict, List
import litellm

class PromptTemplate:
    def __init__(self):
        self.templates = {}
        
    def register_template(self, model: str, template: Dict):
        """
        Register a custom prompt template for a model
        
        template format:
        {
            "system_message": {"pre": "<system>", "post": "</system>"},
            "user_message": {"pre": "<user>", "post": "</user>"},
            "assistant_message": {"pre": "<assistant>", "post": "</assistant>"}
        }
        """
        self.templates[model] = template
        litellm.register_prompt_template(
            model=model,
            roles={
                "system": template["system_message"],
                "user": template["user_message"],
                "assistant": template["assistant_message"]
            }
        )
    
    def format_messages(self, model: str, messages: List[Dict]) -> str:
        """
        Format messages according to template if it exists
        """
        if model not in self.templates:
            return messages
        
        template = self.templates[model]
        formatted_messages = []
        
        for message in messages:
            role = message["role"]
            content = message["content"]
            
            if role == "system":
                formatted = f"{template['system_message']['pre']}{content}{template['system_message']['post']}"
            elif role == "user":
                formatted = f"{template['user_message']['pre']}{content}{template['user_message']['post']}"
            elif role == "assistant":
                formatted = f"{template['assistant_message']['pre']}{content}{template['assistant_message']['post']}"
            
            formatted_messages.append({"role": role, "content": formatted})
        
        return formatted_messages

# Example Usage:
prompt_manager = PromptTemplate()

# Register a template for Llama2
llama2_template = {
    "system_message": {"pre": "<s>[INST] <<SYS>>\n", "post": "\n<</SYS>>\n\n"},
    "user_message": {"pre": "[INST] ", "post": " [/INST]"},
    "assistant_message": {"pre": "", "post": "</s>"}
}
prompt_manager.register_template("llama2", llama2_template)

# Register a template for Claude
claude_template = {
    "system_message": {"pre": "\n\nHuman: Here's how you should behave:", "post": "\n\nAssistant: I understand."},
    "user_message": {"pre": "\n\nHuman: ", "post": ""},
    "assistant_message": {"pre": "\n\nAssistant: ", "post": ""}
}
prompt_manager.register_template("claude-2", claude_template)
```

## Section 6: Putting It All Together

Let's create a comprehensive implementation that uses all the components we've created:

```python
import asyncio
import logging
from typing import List, Dict, Optional
from litellm import Router
import yaml
import json
import time
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MultiProviderManager:
    def __init__(self, config_path: str):
        # Initialize components
        self.provider_manager = ProviderManager(config_path)
        self.load_balancer = LoadBalancer(self.provider_manager.router)
        self.fallback_handler = FallbackHandler(self.provider_manager.router)
        self.rate_limiter = RateLimiter()
        self.prompt_template = PromptTemplate()
        
        # Load custom prompt templates
        self._load_prompt_templates()
        
        # Tracking metrics
        self.request_history = []
        
    def _load_prompt_templates(self):
        """Load custom prompt templates for different models"""
        # Add your model-specific templates here
        llama2_template = {
            "system_message": {"pre": "<s>[INST] <<SYS>>\n", "post": "\n<</SYS>>\n\n"},
            "user_message": {"pre": "[INST] ", "post": " [/INST]"},
            "assistant_message": {"pre": "", "post": "</s>"}
        }
        self.prompt_template.register_template("llama2", llama2_template)
        
    async def process_request(self, 
                            model: str, 
                            messages: List[Dict], 
                            strategy: str = "least_busy",
                            **kwargs) -> Dict:
        """
        Process a request with full error handling, rate limiting, and fallbacks
        """
        try:
            # 1. Format messages using template if available
            formatted_messages = self.prompt_template.format_messages(model, messages)
            
            # 2. Select deployment based on strategy
            deployment = None
            if strategy == "least_busy":
                deployment = await self.load_balancer.least_busy_deployment(model)
            elif strategy == "latency":
                deployment = await self.load_balancer.latency_based_deployment(model)
            elif strategy == "cost":
                deployment = await self.load_balancer.cost_based_deployment(model)
            
            if not deployment:
                raise Exception(f"No available deployments for model {model}")
            
            # 3. Check rate limits
            deployment_id = deployment.get("model_info", {}).get("id", "")
            rpm_limit = deployment.get("litellm_params", {}).get("rpm", float('inf'))
            tpm_limit = deployment.get("litellm_params", {}).get("tpm", float('inf'))
            
            if not await self.rate_limiter.check_rate_limit(deployment_id, rpm_limit, tpm_limit):
                # Try alternative deployment if rate limited
                deployments = [d for d in self.provider_manager.router.model_list 
                             if d["model_name"] == model and d != deployment]
                for alt_deployment in deployments:
                    alt_id = alt_deployment.get("model_info", {}).get("id", "")
                    alt_rpm = alt_deployment.get("litellm_params", {}).get("rpm", float('inf'))
                    alt_tpm = alt_deployment.get("litellm_params", {}).get("tpm", float('inf'))
                    
                    if await self.rate_limiter.check_rate_limit(alt_id, alt_rpm, alt_tpm):
                        deployment = alt_deployment
                        deployment_id = alt_id
                        break
                else:
                    raise Exception("All deployments rate limited")
            
            # 4. Make the completion call
            start_time = time.time()
            try:
                response = await self.provider_manager.get_completion(
                    model=model,
                    messages=formatted_messages,
                    **kwargs
                )
                
                # 5. Update metrics
                completion_tokens = response.usage.completion_tokens
                self.rate_limiter.update_counts(deployment_id, completion_tokens)
                self.load_balancer._update_metrics(
                    deployment_id,
                    tokens=completion_tokens
                )
                
                # 6. Record request history
                self.request_history.append({
                    "timestamp": datetime.now().isoformat(),
                    "model": model,
                    "deployment_id": deployment_id,
                    "success": True,
                    "latency": time.time() - start_time,
                    "tokens": completion_tokens
                })
                
                return response
                
            except Exception as e:
                # 7. Handle errors with fallback
                return await self.fallback_handler.handle_fallback(
                    error=e,
                    model=model,
                    messages=formatted_messages,
                    **kwargs
                )
                
        except Exception as e:
            logger.error(f"Error processing request: {str(e)}")
            raise

    def get_metrics(self) -> Dict:
        """
        Get usage metrics and statistics
        """
        metrics = {
            "total_requests": len(self.request_history),
            "success_rate": sum(1 for r in self.request_history if r["success"]) / len(self.request_history) if self.request_history else 0,
            "average_latency": sum(r["latency"] for r in self.request_history) / len(self.request_history) if self.request_history else 0,
            "total_tokens": sum(r["tokens"] for r in self.request_history),
            "deployment_metrics": self.load_balancer.usage_metrics,
            "fallback_history": self.fallback_handler.fallback_history
        }
        return metrics

    async def health_check(self) -> Dict:
        """
        Perform health check on all deployments
        """
        results = {}
        test_message = [{"role": "user", "content": "test"}]
        
        for deployment in self.provider_manager.router.model_list:
            model_name = deployment["model_name"]
            deployment_id = deployment.get("model_info", {}).get("id", "")
            
            try:
                start_time = time.time()
                await self.provider_manager.get_completion(
                    model=model_name,
                    messages=test_message,
                    max_tokens=1
                )
                latency = time.time() - start_time
                results[deployment_id] = {
                    "status": "healthy",
                    "latency": latency
                }
            except Exception as e:
                results[deployment_id] = {
                    "status": "unhealthy",
                    "error": str(e)
                }
        
        return results
```

## Example Usage

Here's how to use the complete implementation:

```python
async def main():
    # Initialize the manager
    manager = MultiProviderManager("config/provider_config.yaml")
    
    # Perform health check
    health_status = await manager.health_check()
    print("Health Status:", json.dumps(health_status, indent=2))
    
    # Process some requests
    messages = [
        {"role": "user", "content": "What's the weather like?"}
    ]
    
    # Try different strategies
    strategies = ["least_busy", "latency", "cost"]
    
    for strategy in strategies:
        try:
            print(f"\nTrying strategy: {strategy}")
            response = await manager.process_request(
                model="gpt-4",
                messages=messages,
                strategy=strategy
            )
            print(f"Response: {response.choices[0].message.content}")
        except Exception as e:
            print(f"Error with strategy {strategy}: {str(e)}")
    
    # Get metrics
    metrics = manager.get_metrics()
    print("\nMetrics:", json.dumps(metrics, indent=2))

if __name__ == "__main__":
    asyncio.run(main())
```

## Practice Exercises

1. Implement a new load balancing strategy:
   - Develop a strategy that considers both cost and latency
   - Add geographic routing based on deployment regions
   - Implement a priority-based routing system

2. Enhance the fallback system:
   - Add support for model-specific retry policies
   - Implement gradual degradation of model capabilities
   - Add custom fallback chains based on error types

3. Extend the prompt template system:
   - Add support for few-shot examples in templates
   - Implement template versioning
   - Add template validation and testing

4. Create a monitoring dashboard:
   - Visualize deployment health status
   - Track costs across providers
   - Monitor rate limit usage
   - Display fallback patterns

## Conclusion

In this lesson, we've covered:
- Setting up multiple provider configurations
- Implementing various load balancing strategies
- Creating a robust fallback system
- Managing rate limits
- Handling custom prompt templates
- Building a comprehensive multi-provider management system

Next lesson will focus on the LiteLLM Proxy Server, which provides a centralized way to manage multiple LLM providers through a REST API interface.
