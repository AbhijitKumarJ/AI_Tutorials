# GitHub Actions Testing: Example Solutions and Common Pitfalls

## Example Solutions

### 1. Basic Workflow Implementation

#### Exemplary Solution
```yaml
# .github/workflows/comprehensive-tests.yml
name: Comprehensive Testing Suite

on:
  push:
    branches: [ main, develop ]
    paths-ignore:
      - '**.md'
      - 'docs/**'
      - 'LICENSE'
  pull_request:
    branches: [ main, develop ]
  workflow_dispatch:  # Allow manual triggering

jobs:
  test:
    name: Python ${{ matrix.python-version }} on ${{ matrix.os }}
    runs-on: ${{ matrix.os }}
    strategy:
      fail-fast: false  # Continue with other versions if one fails
      matrix:
        os: [ubuntu-latest, windows-latest, macos-latest]
        python-version: ['3.9', '3.10', '3.11', '3.12']

    steps:
      - uses: actions/checkout@v4

      - name: Set up Python ${{ matrix.python-version }}
        uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
          cache: 'pip'  # Enable pip caching

      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements/requirements-dev.txt
          if [ "$RUNNER_OS" == "Windows" ]; then
            pip install -r requirements/requirements-windows.txt
          elif [ "$RUNNER_OS" == "Linux" ]; then
            pip install -r requirements/requirements-linux.txt
          fi
        shell: bash

      - name: Run tests
        run: |
          python -m pytest tests/ --cov=src --cov-report=xml

      - name: Upload coverage
        uses: actions/upload-artifact@v3
        with:
          name: coverage-${{ matrix.os }}-${{ matrix.python-version }}
          path: coverage.xml
```

### 2. Cross-Platform File Handling

#### Exemplary Implementation
```python
# src/file_handler.py
import os
import platform
import tempfile
from pathlib import Path
from typing import Union, Optional
import logging

logger = logging.getLogger(__name__)

class FileHandler:
    """
    Handles file operations across different platforms safely.
    
    Attributes:
        system (str): Current operating system
        temp_base (Path): Base directory for temporary files
    """
    
    def __init__(self, temp_base: Optional[Path] = None):
        self.system = platform.system()
        self.temp_base = temp_base or self._get_default_temp_base()
        self._ensure_temp_directory()
    
    def _get_default_temp_base(self) -> Path:
        """Determines the appropriate temporary directory for the platform."""
        if self.system == 'Windows':
            return Path(os.environ.get('TEMP', os.path.expanduser('~\\AppData\\Local\\Temp')))
        return Path('/tmp')
    
    def _ensure_temp_directory(self) -> None:
        """Ensures the temporary directory exists with proper permissions."""
        try:
            self.temp_base.mkdir(parents=True, exist_ok=True)
            if self.system != 'Windows':
                self.temp_base.chmod(0o755)
        except PermissionError as e:
            logger.error(f"Failed to create temp directory: {e}")
            raise
    
    def create_temp_file(
        self, 
        content: str, 
        suffix: str = '.txt',
        encoding: str = 'utf-8'
    ) -> Path:
        """
        Creates a temporary file with the given content.
        
        Args:
            content: The content to write to the file
            suffix: File extension to use
            encoding: Text encoding to use
            
        Returns:
            Path to the created temporary file
        
        Raises:
            OSError: If file creation fails
            PermissionError: If lacking required permissions
        """
        try:
            fd, path = tempfile.mkstemp(suffix=suffix, dir=self.temp_base)
            try:
                with os.fdopen(fd, 'w', encoding=encoding) as f:
                    f.write(content)
                
                file_path = Path(path)
                if self.system != 'Windows':
                    file_path.chmod(0o644)
                
                return file_path
            except Exception:
                os.unlink(path)
                raise
        except Exception as e:
            logger.error(f"Failed to create temp file: {e}")
            raise
```

### 3. Platform-Specific Testing

#### Exemplary Test Implementation
```python
# tests/test_file_handler.py
import os
import platform
import pytest
from pathlib import Path
from src.file_handler import FileHandler

@pytest.fixture
def file_handler(tmp_path):
    """Provides a FileHandler instance using a temporary directory."""
    return FileHandler(temp_base=tmp_path)

def test_temp_file_creation(file_handler):
    """Test basic file creation functionality."""
    content = "Test content\nWith multiple lines"
    file_path = file_handler.create_temp_file(content)
    
    assert file_path.exists()
    assert file_path.read_text() == content
    
    # Platform-specific checks
    if platform.system() != 'Windows':
        assert oct(file_path.stat().st_mode)[-3:] == '644'

@pytest.mark.skipif(
    platform.system() == 'Windows',
    reason="Unix-specific permission tests"
)
def test_unix_permissions(file_handler):
    """Test Unix-specific permission handling."""
    file_path = file_handler.create_temp_file("content")
    stat = file_path.stat()
    
    # Check owner read/write permissions
    assert bool(stat.st_mode & 0o400)  # Owner read
    assert bool(stat.st_mode & 0o200)  # Owner write
    
    # Check group/other read permissions
    assert bool(stat.st_mode & 0o040)  # Group read
    assert bool(stat.st_mode & 0o004)  # Other read

@pytest.mark.skipif(
    platform.system() != 'Windows',
    reason="Windows-specific path tests"
)
def test_windows_paths(file_handler):
    """Test Windows-specific path handling."""
    long_name = "a" * 200 + ".txt"  # Test long path handling
    
    # This should handle long paths on Windows
    try:
        file_path = file_handler.create_temp_file("content", suffix=long_name)
        assert file_path.exists()
    except OSError as e:
        if "name too long" not in str(e):
            raise

def test_error_handling(file_handler, monkeypatch):
    """Test error handling scenarios."""
    # Simulate permission error
    def mock_open(*args, **kwargs):
        raise PermissionError("Access denied")
    
    monkeypatch.setattr('builtins.open', mock_open)
    
    with pytest.raises(PermissionError):
        file_handler.create_temp_file("content")
```

## Common Pitfalls and Solutions

### 1. Path Handling Issues

#### Incorrect Implementation
```python
# Bad: Platform-dependent path handling
def create_file(self, filename):
    if platform.system() == 'Windows':
        path = "C:\\temp\\" + filename
    else:
        path = "/tmp/" + filename
    
    with open(path, 'w') as f:
        f.write("content")
```

#### Correct Implementation
```python
# Good: Using pathlib for cross-platform compatibility
def create_file(self, filename):
    base_path = Path(tempfile.gettempdir())
    file_path = base_path / filename
    
    file_path.write_text("content")
    return file_path
```

### 2. Workflow Configuration Issues

#### Common Mistake
```yaml
# Bad: Inconsistent shell usage
steps:
  - name: Run commands
    run: |
      if [ "$RUNNER_OS" == "Windows" ]; then
        dir
      else
        ls
      fi
```

#### Better Approach
```yaml
# Good: Consistent shell with platform-specific commands
steps:
  - name: List files (Windows)
    if: runner.os == 'Windows'
    shell: cmd
    run: dir

  - name: List files (Unix)
    if: runner.os != 'Windows'
    shell: bash
    run: ls
```

### 3. Test Organization Problems

#### Poor Structure
```python
# Bad: Mixed platform-specific and general tests
def test_everything():
    # Windows-specific tests
    if platform.system() == 'Windows':
        # Windows tests here
    
    # Unix-specific tests
    else:
        # Unix tests here
```

#### Better Organization
```python
# Good: Separated platform-specific tests
@pytest.mark.windows_only
def test_windows_features():
    """Windows-specific test cases."""
    pass

@pytest.mark.unix_only
def test_unix_features():
    """Unix-specific test cases."""
    pass

def test_common_features():
    """Platform-independent test cases."""
    pass
```

## Best Practices and Tips

### 1. Error Handling

```python
class PlatformAwareHandler:
    def safe_operation(self):
        try:
            # Platform-specific operation
            if platform.system() == 'Windows':
                return self._windows_operation()
            return self._unix_operation()
        except Exception as e:
            logger.error(f"Operation failed on {platform.system()}: {e}")
            raise PlatformError(f"Operation failed: {e}") from e
```

### 2. Workflow Optimization

```yaml
jobs:
  test:
    strategy:
      # Optimize test matrix
      matrix:
        include:
          - os: ubuntu-latest
            python-version: '3.11'
            experimental: false
          - os: windows-latest
            python-version: '3.11'
            experimental: false
          # Experimental configurations
          - os: ubuntu-latest
            python-version: '3.12'
            experimental: true
    
    continue-on-error: ${{ matrix.experimental }}
```

### 3. Test Coverage

```python
# pytest.ini
[pytest]
markers =
    windows_only: marks tests as Windows-specific
    unix_only: marks tests as Unix-specific
    integration: marks tests as integration tests
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
```

## Remember:
- Always use Path objects for file operations
- Implement proper error handling for each platform
- Separate platform-specific code into dedicated modules
- Use GitHub Actions' built-in conditions for platform-specific steps
- Maintain comprehensive test coverage across all platforms
