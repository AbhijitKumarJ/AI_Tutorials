# Lesson 2 Part B: Windows Testing Configuration

## Cross-Platform Testing Strategy

Understanding how Aider implements Windows testing alongside Ubuntu tests is crucial for ensuring broad platform compatibility. This section explores the specific considerations and implementations for Windows testing in the GitHub Actions workflow.

## Windows Test Workflow Analysis

Let's examine the windows-tests.yml file in detail:

```yaml
name: Windows Python Tests
on:
  push:
    paths-ignore:
      - 'aider/website/**'
      - README.md
      - HISTORY.md
    branches:
      - main
  pull_request:
    paths-ignore:
      - 'aider/website/**'
      - README.md
    branches:
      - main
```

### Trigger Configuration Comparison

The Windows workflow uses identical trigger conditions to the Ubuntu workflow, ensuring consistent testing across platforms. This parallel structure serves several purposes:

1. Synchronized Testing:
   Changes are simultaneously tested on both operating systems, preventing platform-specific issues from being merged.

2. Resource Optimization:
   The same paths-ignore rules apply, preventing unnecessary test runs for documentation changes.

3. Branch Protection:
   Both Windows and Ubuntu tests must pass before changes can be merged to main, ensuring cross-platform compatibility.

### Windows-Specific Environment Setup

```yaml
jobs:
  build:
    runs-on: windows-latest
    strategy:
      matrix:
        python-version: ["3.9", "3.10", "3.11", "3.12"]

    steps:
    - name: Check out repository
      uses: actions/checkout@v4

    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v5
      with:
        python-version: ${{ matrix.python-version }}
```

The Windows environment setup requires special consideration:

1. Runner Selection:
   Uses windows-latest instead of ubuntu-latest, providing a Windows Server environment.

2. Python Installation:
   The setup-python action handles Windows-specific Python installation, including:
   - Setting up the appropriate PATH variables
   - Configuring pip and virtualenv
   - Ensuring Windows-compatible Python binaries

### Platform-Specific Considerations

Windows testing requires attention to several unique aspects:

1. Path Separators:
   Windows uses backslashes (\) while Unix uses forward slashes (/). Aider's codebase must handle both:
   ```python
   from pathlib import Path
   
   # Using Path ensures cross-platform compatibility
   project_root = Path(__file__).parent.parent
   config_file = project_root / "config" / "settings.yml"
   ```

2. File Permissions:
   Windows has different permission models. The tests must account for this:
   ```python
   import os
   import platform
   
   def set_executable(path):
       """Set executable bits in a platform-independent way"""
       if platform.system() != 'Windows':
           current = os.stat(path).st_mode
           os.chmod(path, current | 0o111)
   ```

3. Process Management:
   Windows handles process creation and termination differently:
   ```python
   import subprocess
   import sys
   
   def run_command(cmd):
       """Cross-platform command execution"""
       shell = sys.platform == 'win32'
       return subprocess.run(cmd, shell=shell, text=True, check=True)
   ```

## Implementation Details

### Test Discovery and Execution

```yaml
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install pytest
        pip install .

    - name: Run tests
      run: |
        pytest
```

The test execution process on Windows follows these steps:

1. Package Installation:
   - Updates pip to ensure Windows compatibility
   - Installs pytest and project dependencies
   - Installs Aider in development mode

2. Test Running:
   pytest automatically handles Windows-specific aspects:
   - Uses appropriate path separators
   - Manages file handles correctly
   - Handles Windows-style line endings

### Cross-Platform Test Writing

When writing tests that run on both Windows and Ubuntu, follow these guidelines:

1. Path Handling:
   ```python
   from pathlib import Path
   
   def test_file_operations():
       temp_dir = Path("temp_test_dir")
       temp_dir.mkdir(exist_ok=True)
       test_file = temp_dir / "test.txt"
       
       # Write test data
       test_file.write_text("test content")
       
       # Clean up
       test_file.unlink()
       temp_dir.rmdir()
   ```

2. Environment Variables:
   ```python
   import os
   
   def test_environment_setup():
       # Use os.pathsep for PATH-like variables
       paths = ["path1", "path2"]
       os_path = os.pathsep.join(paths)
       
       # Set environment variables safely
       os.environ["TEST_PATH"] = os_path
   ```

3. Command Execution:
   ```python
   import subprocess
   import sys
   
   def test_command_execution():
       # Platform-specific command adjustment
       cmd = ["dir"] if sys.platform == "win32" else ["ls"]
       result = subprocess.run(cmd, capture_output=True, text=True, shell=True)
       assert result.returncode == 0
   ```

## Usage Guidelines

To effectively maintain cross-platform testing:

1. Local Testing:
   Developers should test on both platforms when possible:
   ```bash
   # Windows (PowerShell)
   python -m pytest
   
   # Ubuntu/macOS
   python -m pytest
   ```

2. Platform-Specific Test Marking:
   Use pytest marks for platform-specific tests:
   ```python
   import pytest
   import sys
   
   @pytest.mark.skipif(sys.platform == "win32", reason="Linux-only test")
   def test_linux_specific_feature():
       # Test implementation
       pass
   ```

3. CI Configuration Updates:
   When modifying the workflow, ensure changes work for both platforms:
   ```yaml
   - name: Platform-specific setup
     run: |
       if [ "$RUNNER_OS" == "Windows" ]; then
         # Windows-specific commands
       else
         # Ubuntu-specific commands
       fi
     shell: bash
   ```