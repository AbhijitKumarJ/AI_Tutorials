# Visual Studio Code Integration Guide for Aider

## Basic VS Code Setup

### Required Extensions

1. **Core Extensions Setup**
Create `.vscode/extensions.json`:
```json
{
    "recommendations": [
        "ms-python.python",
        "ms-python.vscode-pylance",
        "ms-python.black-formatter",
        "ms-python.flake8",
        "ms-python.isort",
        "eamodio.gitlens",
        "davidanson.vscode-markdownlint",
        "yzhang.markdown-all-in-one",
        "gruntfuggly.todo-tree"
    ]
}
```

2. **Installing Extensions Script**
Create `scripts/setup_vscode.sh`:
```bash
#!/bin/bash

# Install VS Code extensions
extensions=(
    "ms-python.python"
    "ms-python.vscode-pylance"
    "ms-python.black-formatter"
    "ms-python.flake8"
    "ms-python.isort"
    "eamodio.gitlens"
    "davidanson.vscode-markdownlint"
    "yzhang.markdown-all-in-one"
    "gruntfuggly.todo-tree"
)

for extension in "${extensions[@]}"; do
    code --install-extension "$extension"
done
```

## Workspace Configuration

### Basic Settings

1. **Core Workspace Settings**
Create `.vscode/settings.json`:
```json
{
    "files.exclude": {
        "**/__pycache__": true,
        "**/.pytest_cache": true,
        "**/*.pyc": true,
        ".coverage": true,
        "htmlcov": true
    },
    "files.watcherExclude": {
        "**/__pycache__/**": true,
        "**/.git/**": true,
        "**/venv/**": true
    },
    "files.associations": {
        ".aider.conf.yml": "yaml",
        ".aider.chat.history.md": "markdown"
    },
    
    // Editor settings
    "editor.rulers": [100],
    "editor.formatOnSave": true,
    "editor.codeActionsOnSave": {
        "source.organizeImports": true
    },
    
    // Python settings
    "python.defaultInterpreterPath": "${workspaceFolder}/venv/bin/python",
    "python.analysis.typeCheckingMode": "basic",
    "python.formatting.provider": "black",
    "python.formatting.blackArgs": ["--line-length", "100"],
    "python.linting.enabled": true,
    "python.linting.flake8Enabled": true,
    "python.linting.flake8Args": ["--max-line-length=100"],
    "python.testing.pytestEnabled": true,
    "python.testing.unittestEnabled": false,
    "python.testing.nosetestsEnabled": false,
    
    // Markdown settings
    "markdown.extension.toc.updateOnSave": true,
    "[markdown]": {
        "editor.defaultFormatter": "yzhang.markdown-all-in-one",
        "editor.formatOnSave": true
    }
}
```

### Advanced Settings

1. **Custom Color Theme for Aider Files**
Add to `.vscode/settings.json`:
```json
{
    "workbench.colorCustomizations": {
        "editor.background": "#1E1E1E",
        "editor.foreground": "#D4D4D4",
        "[Aider Chat]": {
            "editor.background": "#1A1A1A",
            "editor.foreground": "#89D185"
        }
    },
    "editor.tokenColorCustomizations": {
        "textMateRules": [
            {
                "scope": "markup.heading.aider",
                "settings": {
                    "foreground": "#569CD6",
                    "fontStyle": "bold"
                }
            },
            {
                "scope": "markup.quote.aider",
                "settings": {
                    "foreground": "#608B4E",
                    "fontStyle": "italic"
                }
            }
        ]
    }
}
```

## Task Configuration

### Basic Tasks

1. **VS Code Tasks**
Create `.vscode/tasks.json`:
```json
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "Start Aider",
            "type": "shell",
            "command": "${config:python.defaultInterpreterPath}",
            "args": [
                "-m",
                "aider",
                "${file}"
            ],
            "presentation": {
                "reveal": "always",
                "panel": "new",
                "focus": true
            },
            "problemMatcher": []
        },
        {
            "label": "Aider: New Chat",
            "type": "shell",
            "command": "${config:python.defaultInterpreterPath}",
            "args": [
                "-m",
                "aider",
                "--new-chat"
            ],
            "presentation": {
                "reveal": "always",
                "panel": "new"
            }
        },
        {
            "label": "Aider: Continue Last Chat",
            "type": "shell",
            "command": "${config:python.defaultInterpreterPath}",
            "args": [
                "-m",
                "aider",
                "--continue"
            ],
            "presentation": {
                "reveal": "always",
                "panel": "new"
            }
        }
    ]
}
```

### Advanced Tasks

1. **Extended Task Configuration**
Add to `.vscode/tasks.json`:
```json
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "Aider: Setup Project",
            "type": "shell",
            "command": "${workspaceFolder}/scripts/setup_project.sh",
            "presentation": {
                "reveal": "always",
                "panel": "new"
            },
            "problemMatcher": []
        },
        {
            "label": "Aider: Run Tests",
            "type": "shell",
            "command": "${config:python.defaultInterpreterPath}",
            "args": [
                "-m",
                "pytest",
                "tests/",
                "-v"
            ],
            "group": {
                "kind": "test",
                "isDefault": true
            }
        },
        {
            "label": "Aider: Format Code",
            "type": "shell",
            "command": "${config:python.defaultInterpreterPath}",
            "args": [
                "-m",
                "black",
                "${workspaceFolder}"
            ],
            "presentation": {
                "reveal": "silent"
            },
            "problemMatcher": []
        },
        {
            "label": "Aider: Generate Documentation",
            "type": "shell",
            "command": "${workspaceFolder}/scripts/generate_docs.sh",
            "presentation": {
                "reveal": "always",
                "panel": "new"
            }
        }
    ]
}
```

## Keyboard Shortcuts

### Custom Keybindings

1. **Keyboard Shortcuts Configuration**
Create `.vscode/keybindings.json`:
```json
{
    "key": "ctrl+shift+a",
    "command": "workbench.action.tasks.runTask",
    "args": "Start Aider",
    "when": "editorTextFocus"
},
{
    "key": "ctrl+shift+n",
    "command": "workbench.action.tasks.runTask",
    "args": "Aider: New Chat"
},
{
    "key": "ctrl+shift+c",
    "command": "workbench.action.tasks.runTask",
    "args": "Aider: Continue Last Chat"
},
{
    "key": "ctrl+shift+t",
    "command": "workbench.action.tasks.runTask",
    "args": "Aider: Run Tests"
},
{
    "key": "ctrl+shift+f",
    "command": "workbench.action.tasks.runTask",
    "args": "Aider: Format Code"
}
```

## Debug Configuration

### Python Debugging

1. **Debug Configuration**
Create `.vscode/launch.json`:
```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Python: Aider Module",
            "type": "python",
            "request": "launch",
            "module": "aider",
            "args": ["${file}"],
            "console": "integratedTerminal",
            "justMyCode": false,
            "env": {
                "PYTHONPATH": "${workspaceFolder}",
                "OPENAI_API_KEY": "${env:OPENAI_API_KEY}"
            }
        },
        {
            "name": "Python: Current File with Aider",
            "type": "python",
            "request": "launch",
            "program": "${file}",
            "console": "integratedTerminal",
            "justMyCode": true,
            "env": {
                "PYTHONPATH": "${workspaceFolder}"
            }
        },
        {
            "name": "Python: Debug Tests",
            "type": "python",
            "request": "launch",
            "module": "pytest",
            "args": [
                "-v",
                "--no-cov"
            ],
            "console": "integratedTerminal",
            "justMyCode": false
        }
    ]
}
```

## Snippets Configuration

### Custom Code Snippets

1. **Python Snippets**
Create `.vscode/python.code-snippets`:
```json
{
    "Aider Function Template": {
        "prefix": "aidef",
        "body": [
            "def ${1:function_name}(${2:parameters}):",
            "    \"\"\"",
            "    ${3:Function description}",
            "",
            "    Args:",
            "        ${4:param_name}: ${5:param_description}",
            "",
            "    Returns:",
            "        ${6:return_description}",
            "    \"\"\"",
            "    ${0:pass}"
        ],
        "description": "Create a new function with docstring"
    },
    "Aider Class Template": {
        "prefix": "aicls",
        "body": [
            "class ${1:ClassName}:",
            "    \"\"\"",
            "    ${2:Class description}",
            "    \"\"\"",
            "",
            "    def __init__(self, ${3:parameters}):",
            "        \"\"\"",
            "        Initialize the ${1:ClassName}",
            "",
            "        Args:",
            "            ${4:param_name}: ${5:param_description}",
            "        \"\"\"",
            "        ${0:pass}"
        ],
        "description": "Create a new class with docstring"
    }
}
```

2. **Markdown Snippets**
Create `.vscode/markdown.code-snippets`:
```json
{
    "Aider Chat Header": {
        "prefix": "aich",
        "body": [
            "# Aider Chat Session - ${CURRENT_DATE}/${CURRENT_MONTH}/${CURRENT_YEAR}",
            "",
            "## Context",
            "",
            "${1:context}",
            "",
            "## Objective",
            "",
            "${2:objective}",
            "",
            "## Notes",
            "",
            "- ${0}"
        ],
        "description": "Create a new Aider chat session header"
    }
}
```

## Project Templates

### VS Code Workspace Template

1. **Workspace Template**
Create `template.code-workspace`:
```json
{
    "folders": [
        {
            "path": "."
        }
    ],
    "settings": {
        "python.defaultInterpreterPath": "${workspaceFolder}/venv/bin/python",
        "python.analysis.extraPaths": [
            "${workspaceFolder}/src"
        ],
        "python.testing.pytestArgs": [
            "tests"
        ],
        "python.testing.unittestEnabled": false,
        "python.testing.nosetestsEnabled": false,
        "python.testing.pytestEnabled": true,
        "python.formatting.provider": "black",
        "python.linting.enabled": true,
        "python.linting.flake8Enabled": true
    },
    "extensions": {
        "recommendations": [
            "ms-python.python",
            "ms-python.vscode-pylance"
        ]
    }
}
```

These configurations provide a comprehensive VS Code setup for working with Aider, including tasks, keybindings, debugging configurations, and custom snippets. Users can customize these settings based on their specific needs and preferences.

