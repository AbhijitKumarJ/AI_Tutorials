# IDE Integration Guide (Continued)

## Sublime Text Integration (Continued)

### Package Control Settings
```json
{
    "installed_packages": [
        "Python 3",
        "Anaconda",
        "SublimeLinter",
        "SublimeLinter-flake8",
        "Black",
        "GitGutter"
    ],
    "ignored_packages": ["Vintage"]
}
```

### Project Configuration
Create a `.sublime-project` file:
```json
{
    "folders": [
        {
            "path": ".",
            "folder_exclude_patterns": ["venv", "__pycache__", "*.egg-info"],
            "file_exclude_patterns": [".aider.chat.history.md"]
        }
    ],
    "settings": {
        "python_interpreter": "$project_path/venv/bin/python",
        "auto_format_on_save": true,
        "rulers": [100],
        "translate_tabs_to_spaces": true
    },
    "build_systems": [
        {
            "name": "Aider",
            "cmd": ["$project_path/venv/bin/aider", "$file"],
            "working_dir": "$project_path",
            "env": {
                "PYTHONUNBUFFERED": "1",
                "PATH": "$project_path/venv/bin:$PATH"
            }
        }
    ]
}
```

### Key Bindings
Create custom key bindings in `Default.sublime-keymap`:
```json
[
    {
        "keys": ["ctrl+shift+a"],
        "command": "build",
        "args": {"variant": "Aider"}
    },
    {
        "keys": ["ctrl+shift+b"],
        "command": "black_file"
    }
]
```

## Vim/Neovim Integration

### Plugin Setup

1. **Install Vim-Plug**
```bash
# For Vim
curl -fLo ~/.vim/autoload/plug.vim --create-dirs \
    https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim

# For Neovim
sh -c 'curl -fLo "${XDG_DATA_HOME:-$HOME/.local/share}"/nvim/site/autoload/plug.vim --create-dirs \
       https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim'
```

2. **Configure Plugins**
Add to `~/.vimrc` or `~/.config/nvim/init.vim`:
```vim
call plug#begin()
" Python support
Plug 'davidhalter/jedi-vim'
Plug 'dense-analysis/ale'
Plug 'psf/black'
Plug 'tpope/vim-fugitive'
" Optional: Additional plugins
Plug 'nvim-lua/plenary.nvim'
Plug 'nvim-telescope/telescope.nvim'
call plug#end()

" Aider specific configurations
let g:aider_path = '$HOME/.local/bin/aider'
let g:python3_host_prog = '$HOME/venv/bin/python'

" Custom commands for Aider
command! -nargs=* Aider terminal aider <args>
command! AiderCurrent execute 'Aider' expand('%:p')

" Key mappings
nnoremap <leader>a :AiderCurrent<CR>
```

3. **ALE Configuration**
```vim
" ALE settings
let g:ale_linters = {
\   'python': ['flake8', 'pylint'],
\}
let g:ale_fixers = {
\   'python': ['black', 'isort'],
\}
let g:ale_fix_on_save = 1
```

### Project-Specific Settings

Create `.lvimrc` for project-specific settings:
```vim
" Project settings
let g:ale_python_flake8_options = '--max-line-length=100'
let g:ale_python_black_options = '--line-length 100'

" Environment variables
let $PYTHONPATH = getcwd()
let $OPENAI_API_KEY = $OPENAI_API_KEY
```

## Emacs Integration

### Package Configuration

1. **Initialize Package System**
Add to `~/.emacs.d/init.el`:
```lisp
(require 'package)
(add-to-list 'package-archives
             '("melpa" . "https://melpa.org/packages/") t)
(package-initialize)

;; Install use-package if not already installed
(unless (package-installed-p 'use-package)
  (package-refresh-contents)
  (package-install 'use-package))

(require 'use-package)
```

2. **Python Development Setup**
```lisp
(use-package python-mode
  :ensure t
  :custom
  (python-shell-interpreter "python3"))

(use-package blacken
  :ensure t
  :hook (python-mode . blacken-mode))

(use-package flycheck
  :ensure t
  :init (global-flycheck-mode))

(use-package company
  :ensure t
  :hook (after-init . global-company-mode))
```

3. **Aider Integration**
```lisp
(defun run-aider-on-file ()
  "Run aider on the current file."
  (interactive)
  (let ((file-name (buffer-file-name)))
    (if file-name
        (start-process "aider" "*aider*" "aider" file-name)
      (message "Buffer is not visiting a file"))))

(global-set-key (kbd "C-c a") 'run-aider-on-file)
```

### Project Management

1. **Project Configuration**
Create `.dir-locals.el`:
```lisp
((python-mode
  (python-shell-interpreter . "venv/bin/python")
  (flycheck-python-flake8-executable . "venv/bin/flake8")
  (blacken-executable . "venv/bin/black")))
```

2. **Project Build System**
```lisp
(use-package projectile
  :ensure t
  :config
  (projectile-mode +1)
  (define-key projectile-mode-map (kbd "C-c p") 'projectile-command-map)
  
  (projectile-register-project-type 'python-aider '("pyproject.toml")
                                  :compile "python setup.py build"
                                  :test "pytest"
                                  :test-suffix "_test"))
```

## Terminal Integration

### tmux Configuration

1. **Create tmux Configuration**
Add to `~/.tmux.conf`:
```bash
# Split pane and run aider
bind-key A split-window -h "aider #{pane_current_path}"

# Set environment variables
set-environment -g PYTHONPATH "#{pane_current_path}"
```

2. **Create Helper Scripts**
```bash
# Create aider-tmux.sh
cat > ~/bin/aider-tmux.sh << 'EOL'
#!/bin/bash
SESSION="aider"

tmux new-session -d -s $SESSION
tmux split-window -h
tmux select-pane -t 0
tmux send-keys "aider $1" C-m
tmux select-pane -t 1
tmux attach-session -t $SESSION
EOL

chmod +x ~/bin/aider-tmux.sh
```

### direnv Integration

1. **Setup direnv**
Create `.envrc` in project directory:
```bash
# Load Python virtual environment
layout python3

# Set up environment variables
export PYTHONPATH=$PWD
export AIDER_CHAT_HISTORY_PATH=$PWD/.aider.chat.history.md
```

2. **Create Shell Aliases**
Add to `~/.bashrc` or `~/.zshrc`:
```bash
# Aider aliases
alias aider-here='aider $(git ls-files --modified --others --exclude-standard)'
alias aider-python='aider *.py'
alias aider-commit='aider --commit-message-prefix "feat: "'
```

These integrations provide comprehensive development environment setups for various editors and tools, making it easier to work with Aider in your preferred environment.

