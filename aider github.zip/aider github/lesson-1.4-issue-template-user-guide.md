# GitHub Issue Templates: A Complete User Guide for Aider

## Getting Started with GitHub Issues

### Creating Your GitHub Account

Before you can submit issues to the Aider project, you'll need a GitHub account:

1. **Account Setup**
   - Visit github.com and click "Sign up"
   - Choose a username, email, and password
   - Verify your email address
   - Enable two-factor authentication (recommended)

2. **Profile Configuration**
   - Add a profile picture (helps maintainers recognize regular contributors)
   - Set your time zone (helps with communication timing)
   - Configure notification preferences

### Navigating to Aider's Issue Page

The process of finding and using Aider's issue system:

1. **Accessing the Repository**
   - Visit https://github.com/Aider-AI/aider
   - Click the "Issues" tab in the repository navigation bar
   - Look for the green "New Issue" button

2. **Understanding the Issues Interface**
   ```
   Repository Navigation:
   Code | Issues | Pull Requests | Actions | Projects | Wiki | Security | Insights
          ^
          |
   Click here to access issues
   ```

## Creating an Issue Step by Step

### Before Creating an Issue

1. **Preparation Steps**
   - Check if your issue already exists using the search bar
   - Gather necessary information about your Aider installation:
     ```bash
     # Get Aider version
     aider --version
     
     # Check Python version
     python --version
     
     # Note your operating system version
     # On Linux:
     lsb_release -a
     # On macOS:
     sw_vers
     # On Windows:
     ver
     ```
   - Document the specific model you're using
   - Have any error messages ready to copy/paste

2. **Search Techniques**
   ```
   Advanced Search Tips:
   - Use quotes for exact phrases: "connection error"
   - Use label:bug to find bug reports
   - Use is:open to find open issues
   - Use author:username to find issues by user
   ```

### Using the Issue Template

1. **Starting a New Issue**
   - Click "New Issue"
   - Select "Question or bug report" template
   - You'll see a form with two main sections:
     ```
     +------------------------+
     |    Issue Template     |
     |------------------------|
     | 1. Issue Description  |
     | [Required text area]  |
     |                      |
     | 2. Version Info      |
     | [Optional text area] |
     +------------------------+
     ```

2. **Filling Out the Description**
   
   Good example of an issue description:
   ```
   When using aider with Claude 3.5 Sonnet, I encountered an error
   while trying to modify multiple files:

   Steps to reproduce:
   1. Created two Python files: test.py and utils.py
   2. Ran: aider test.py utils.py
   3. Asked to "add error handling to both files"

   Error received:
   [Error message copied exactly as shown]

   Expected behavior:
   - Aider should modify both files
   - Changes should include error handling

   Actual behavior:
   - Received error message
   - No changes were made to files
   ```

3. **Providing Version Information**
   
   Example of well-formatted version info:
   ```
   Aider v0.16.1
   Model: claude-3.5-sonnet using diff edit format
   Git repo: Clean .git with 3 files
   Repo-map: using 2048 tokens
   OS: Ubuntu 22.04
   Python: 3.11.5
   ```

### After Submission

1. **Post-Creation Steps**
   - Subscribe to notifications (automatically done when you create an issue)
   - Monitor your email for responses
   - Be prepared to provide additional information if requested

2. **Managing Notifications**
   ```
   Notification Settings:
   Watch → All Activity
   Releases only
   Not watching → Issues only
   Ignore → Never notify
   ```

## Interacting with Your Issue

### Following Up

1. **Responding to Questions**
   - Use "Reply" to respond directly to comments
   - Use code blocks for any code or error messages:
     ```
     ```python
     your_code_here
     ```
     ```
   - Use quotes to reference previous comments:
     ```
     > Original comment
     Your response
     ```

2. **Adding Additional Information**
   - Use the edit button (pencil icon) to update your original description
   - Add comments for new information
   - Upload screenshots if needed:
     ```
     1. Click the camera icon, or
     2. Drag and drop images into the comment box
     ```

### Understanding Issue Status

1. **Label Meanings**
   - `bug`: Confirmed problem with Aider
   - `enhancement`: Feature request
   - `question`: General inquiry
   - `needs-info`: Maintainers need more information
   - `in-progress`: Being worked on
   - `solved`: Issue has been resolved

2. **Status Indicators**
   ```
   Open (green) → Issue is active
   Closed (red) → Issue is resolved/completed
   Locked (gray) → No new comments allowed
   ```

### Best Practices for Issue Updates

1. **Providing Updates**
   - Comment when you've tried a suggestion
   - Include results of any troubleshooting
   - Mention if the problem is resolved
   - Example update:
     ```
     I tried the suggested fix:
     1. Updated to aider v0.16.2
     2. Cleared the cache as suggested
     3. Result: Error is now resolved
     
     Thank you for the help!
     ```

2. **Closing Your Issue**
   - Close the issue if you've solved it
   - Explain how you solved it
   - Thank the contributors
   - Example closing comment:
     ```
     This issue is resolved. The problem was fixed by:
     1. [Explain solution]
     2. [List any relevant changes]
     
     Thanks to @maintainer for the help!
     ```

## Troubleshooting Common Issues

1. **Template Not Loading**
   - Clear browser cache
   - Try a different browser
   - Check GitHub status page

2. **Can't Find Issue Template**
   ```
   Common solutions:
   1. Refresh the page
   2. Check if you're logged in
   3. Verify you're on the main Aider repository
   ```

3. **Notification Problems**
   - Check spam folder
   - Verify email settings on GitHub
   - Check repository notification settings

## Additional Resources

1. **Helpful Links**
   - [Aider Documentation](https://aider.chat/docs/)
   - [GitHub's Guide to Issues](https://docs.github.com/en/issues)
   - [Markdown Formatting Guide](https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax)

2. **Community Resources**
   - Discord server for real-time help
   - Stack Overflow tags
   - GitHub Discussions