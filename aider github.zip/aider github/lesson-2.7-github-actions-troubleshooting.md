# GitHub Actions Testing: Debugging and Troubleshooting Guide

## Introduction

This comprehensive guide addresses common issues encountered when implementing GitHub Actions workflows and cross-platform testing. It provides detailed debugging strategies, solutions, and preventive measures.

## Common GitHub Actions Issues

### 1. Workflow Not Triggering

#### Symptoms
- Pushes or pull requests don't start the workflow
- No workflow runs appear in the Actions tab

#### Diagnostic Steps
1. Check workflow file location:
```bash
# Correct location
.github/workflows/your-workflow.yml
```

2. Validate trigger configuration:
```yaml
# Problematic configuration
on:
  push:
    branches: main  # Wrong syntax

# Correct configuration
on:
  push:
    branches: [ main ]  # Correct syntax
```

3. Verify paths-ignore patterns:
```yaml
# Debug paths-ignore issues
on:
  push:
    paths-ignore:
      - '**.md'
    paths:
      - '**.py'  # Conflicts with paths-ignore!
```

#### Solution Template
```yaml
name: Debug Workflow

on:
  # Enable manual triggering for testing
  workflow_dispatch:
  
  push:
    branches: [ main, develop ]
    paths-ignore:
      - '**.md'
      - 'docs/**'
  
  pull_request:
    branches: [ main, develop ]

jobs:
  debug:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Debug Information
        run: |
          echo "GitHub ref: ${{ github.ref }}"
          echo "Event name: ${{ github.event_name }}"
          echo "Repository: ${{ github.repository }}"
```

### 2. Matrix Strategy Failures

#### Symptoms
- Some matrix combinations fail while others succeed
- Inconsistent test results across platforms

#### Diagnostic Implementation
```yaml
jobs:
  test:
    strategy:
      fail-fast: false  # Continue other jobs if one fails
      matrix:
        os: [ubuntu-latest, windows-latest]
        python-version: ['3.9', '3.10', '3.11', '3.12']
    
    steps:
      - name: Debug Matrix
        run: |
          echo "OS: ${{ matrix.os }}"
          echo "Python: ${{ matrix.python-version }}"
          echo "Runner OS: ${{ runner.os }}"
          python --version
      
      - name: Platform Info
        shell: bash
        run: |
          uname -a || echo "uname not available"
          python -c "import platform; print(platform.platform())"
```

### 3. Cross-Platform Path Issues

#### Debugging Tools

1. Path Debug Helper:
```python
# debug_paths.py
import os
import platform
from pathlib import Path

def debug_path_info(path):
    """Print detailed path information for debugging."""
    path = Path(path)
    print(f"""
Path Debug Information:
----------------------
Original path: {path}
Absolute path: {path.absolute()}
Resolved path: {path.resolve()}
Parts: {path.parts}
Drive: {path.drive}
Root: {path.root}
Parents: {list(path.parents)}
Platform: {platform.system()}
Path separator: {os.path.sep}
Alternative separator: {os.path.altsep}
""")
```

2. Path Testing Module:
```python
# test_paths.py
import pytest
from pathlib import Path
from .debug_paths import debug_path_info

@pytest.fixture
def sample_paths():
    return [
        "relative/path/file.txt",
        "/absolute/path/file.txt",
        "C:\\Windows\\Path\\file.txt",
        "../../parent/path/file.txt",
    ]

def test_path_handling(sample_paths, capfd):
    for path_str in sample_paths:
        debug_path_info(path_str)
        out, _ = capfd.readouterr()
        print(f"\nTesting path: {path_str}")
        print(out)
```

### 4. Environment Variable Issues

#### Diagnostic Tools

1. Environment Debug Workflow:
```yaml
name: Environment Debug

jobs:
  debug-env:
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        os: [ubuntu-latest, windows-latest]
    
    steps:
      - name: Dump Environment
        run: |
          echo "GitHub Environment:"
          echo "GITHUB_WORKSPACE: $GITHUB_WORKSPACE"
          echo "GITHUB_PATH: $GITHUB_PATH"
          echo "GITHUB_ENV: $GITHUB_ENV"
          
          echo "\nPython Environment:"
          python -c "import sys; print(f'Python path: {sys.path}')"
          python -c "import os; print(f'PYTHONPATH: {os.environ.get(\"PYTHONPATH\")}')"
```

2. Environment Validation Script:
```python
# validate_env.py
import os
import platform
import sys

def validate_environment():
    """Validate and report on environment configuration."""
    issues = []
    
    # Check Python version
    py_version = sys.version_info
    if py_version < (3, 9):
        issues.append(f"Python version {py_version} is below minimum 3.9")
    
    # Check critical environment variables
    critical_vars = ['PATH', 'PYTHONPATH', 'TEMP', 'TMP']
    for var in critical_vars:
        if var not in os.environ:
            issues.append(f"Missing environment variable: {var}")
    
    # Check platform-specific variables
    if platform.system() == 'Windows':
        if 'SYSTEMROOT' not in os.environ:
            issues.append("Missing SYSTEMROOT on Windows")
    else:
        if 'HOME' not in os.environ:
            issues.append("Missing HOME on Unix")
    
    return issues

if __name__ == '__main__':
    issues = validate_environment()
    if issues:
        print("Environment Issues Found:")
        for issue in issues:
            print(f"- {issue}")
        sys.exit(1)
    print("Environment validation passed")
```

### 5. Test Output Parsing Issues

#### Debug Utilities

1. Test Output Parser:
```python
# parse_test_output.py
import re
import sys
from pathlib import Path

def parse_test_output(output_file):
    """Parse and analyze pytest output for common issues."""
    output = Path(output_file).read_text()
    
    # Pattern matching for common issues
    patterns = {
        'import_error': r'ImportError: (.+)',
        'assertion_error': r'AssertionError: (.+)',
        'platform_error': r'Skipped: (.+platform.+)',
        'permission_error': r'PermissionError: (.+)',
    }
    
    issues = defaultdict(list)
    for error_type, pattern in patterns.items():
        matches = re.finditer(pattern, output)
        for match in matches:
            issues[error_type].append(match.group(1))
    
    return issues

def print_analysis(issues):
    """Print formatted analysis of test issues."""
    print("\nTest Output Analysis")
    print("===================")
    
    if not issues:
        print("No recognized issues found.")
        return
    
    for error_type, messages in issues.items():
        print(f"\n{error_type.replace('_', ' ').title()}:")
        for msg in messages:
            print(f"  - {msg}")

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: python parse_test_output.py <test_output_file>")
        sys.exit(1)
    
    issues = parse_test_output(sys.argv[1])
    print_analysis(issues)
```

2. Test Debug Workflow Step:
```yaml
      - name: Run Tests with Debug
        run: |
          python -m pytest tests/ -v --full-trace > test_output.txt 2>&1 || true
          python parse_test_output.py test_output.txt
```

## Platform-Specific Debugging

### Windows-Specific Issues

1. Path Length Issues:
```python
# windows_path_checker.py
import os
from pathlib import Path
import win32api

def check_windows_paths(directory):
    """Check for Windows path length issues."""
    long_paths = []
    
    for root, dirs, files in os.walk(directory):
        for name in files + dirs:
            path = Path(root) / name
            try:
                # Test if Windows API can handle the path
                win32api.GetShortPathName(str(path))
            except win32api.error as e:
                if e.winerror == 206:  # PATH_NOT_FOUND
                    long_paths.append((str(path), len(str(path))))
    
    return long_paths
```

### Unix-Specific Issues

1. Permission Debug Helper:
```python
# unix_permission_debug.py
import os
import stat
import pwd
import grp

def debug_permissions(path):
    """Debug Unix permission issues."""
    st = os.stat(path)
    
    # Get numeric mode
    mode = st.st_mode
    
    # Get ownership
    try:
        owner = pwd.getpwuid(st.st_uid).pw_name
    except KeyError:
        owner = f"UID: {st.st_uid}"
    
    try:
        group = grp.getgrgid(st.st_gid).gr_name
    except KeyError:
        group = f"GID: {st.st_gid}"
    
    # Format permissions string
    perms = stat.filemode(mode)
    
    return {
        'path': path,
        'owner': owner,
        'group': group,
        'mode': perms,
        'mode_octal': oct(mode & 0o777),
        'is_symlink': os.path.islink(path),
        'real_path': os.path.realpath(path) if os.path.islink(path) else None,
    }
```

## Best Practices for Debugging

1. Use Comprehensive Logging:
```python
import logging

# Configure logging for debugging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('debug.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)
```

2. Implement Debug Mode in Tests:
```python
import pytest

def pytest_addoption(parser):
    parser.addoption(
        "--debug",
        action="store_true",
        default=False,
        help="Run tests in debug mode"
    )

@pytest.fixture
def debug_mode(request):
    return request.config.getoption("--debug")

def test_with_debug(debug_mode):
    if debug_mode:
        logging.getLogger().setLevel(logging.DEBUG)
```

## Common Error Resolution Checklist

1. Workflow Errors:
   - Verify YAML syntax
   - Check workflow trigger conditions
   - Validate environment variables
   - Review action versions

2. Test Failures:
   - Check platform compatibility
   - Verify file permissions
   - Validate path handling
   - Review test dependencies

3. Environment Issues:
   - Validate Python versions
   - Check system dependencies
   - Verify environment variables
   - Review path configurations
