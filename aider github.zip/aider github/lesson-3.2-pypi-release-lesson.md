# Lesson 3 Part B: PyPI Release Process

## Introduction to PyPI Release Automation

The Python Package Index (PyPI) is the official repository for Python software packages. Aider implements an automated release process to PyPI using GitHub Actions, ensuring that new versions are consistently and securely published. This lesson provides a detailed examination of the PyPI release automation process.

## File Structure Overview

The PyPI release process involves several key files in the Aider repository:

```
.github/
  └── workflows/
      └── release.yml          # Main PyPI release workflow
pyproject.toml                # Project metadata and build configuration
requirements.txt              # Core dependencies
requirements/                 # Additional requirement files
  ├── requirements-browser.txt
  ├── requirements-dev.txt
  ├── requirements-help.txt
  └── requirements-playwright.txt
scripts/
  └── versionbump.py          # Version management script
```

## Understanding the PyPI Release Workflow

### Version Management

The `versionbump.py` script plays a crucial role in managing versions:

```python
def main():
    parser = argparse.ArgumentParser(description="Bump version")
    parser.add_argument("new_version", help="New version in x.y.z format")
    parser.add_argument("--dry-run", action="store_true",
                       help="Print each step without executing")
```

This script handles:
- Version validation
- Git tag creation
- Development version updates
- Automated commits

### Release Workflow Configuration

The `release.yml` workflow is configured to handle PyPI releases:

```yaml
name: PyPI Release
on:
  workflow_dispatch:
  push:
    tags:
      - 'v[0-9]+.[0-9]+.[0-9]+'

jobs:
  build_and_publish:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Set up Python
      uses: actions/setup-python@v5
      with:
        python-version: 3.x
```

### Build System Configuration

The `pyproject.toml` file defines the build system and project metadata:

```toml
[project]
name = "aider-chat"
description = "Aider is AI pair programming in your terminal"
readme = "README.md"
requires-python = ">=3.9,<3.13"
dynamic = ["dependencies", "optional-dependencies", "version"]

[build-system]
requires = ["setuptools>=68", "setuptools_scm[toml]>=8"]
build-backend = "setuptools.build_meta"
```

### Dependency Management

Dependencies are managed through multiple requirement files:
- `requirements.txt`: Core dependencies
- `requirements-browser.txt`: Browser-specific dependencies
- `requirements-dev.txt`: Development dependencies
- `requirements-help.txt`: Help system dependencies
- `requirements-playwright.txt`: Playwright testing dependencies

## Release Process Implementation

### Build and Distribution

The workflow handles package building:

```yaml
- name: Install dependencies
  run: |
    python -m pip install --upgrade pip
    pip install build setuptools wheel twine

- name: Build and publish
  env:
    TWINE_USERNAME: __token__
    TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
  run: |
    python -m build
    twine upload dist/*
```

This process:
1. Updates pip and installs build tools
2. Builds both wheel and source distributions
3. Uploads to PyPI using secure token authentication

### Version Management Process

The version bump process includes several steps:

1. Pre-release checks:
   - Verify clean working directory
   - Ensure main branch is up to date
   - Validate new version format

2. Version update:
   - Update version in `aider/__init__.py`
   - Create and push version tag
   - Update to next development version

3. Post-release tasks:
   - Push changes to GitHub
   - Create development version tag
   - Clean up temporary files

## Usage Guide

### Manual Version Bump Process

To initiate a new release:

```bash
# First, ensure you're on the main branch with latest changes
git checkout main
git pull origin main

# Run the version bump script
python scripts/versionbump.py 1.2.3
```

### Automated Release Process

The release workflow triggers automatically when a version tag is pushed:

1. The version bump script creates and pushes the tag
2. GitHub Actions detects the tag and starts the release workflow
3. The workflow builds and publishes to PyPI
4. The package becomes available on PyPI

### Verification Steps

After a release:

1. Check PyPI listing:
   ```bash
   pip index versions aider-chat
   ```

2. Verify installation:
   ```bash
   pip install --no-cache-dir aider-chat=={version}
   ```

3. Confirm version:
   ```python
   import aider
   print(aider.__version__)
   ```

## Best Practices and Considerations

### Version Management
- Follow semantic versioning strictly
- Document changes in HISTORY.md
- Maintain a consistent version scheme
- Test packages before release

### Security
- Rotate PyPI tokens regularly
- Use dedicated tokens for CI/CD
- Review dependency updates
- Implement security scanning

### Documentation
- Update documentation with new features
- Include migration guides if needed
- Maintain clear changelog entries
- Document breaking changes

### Quality Assurance
- Run full test suite before release
- Test installation in clean environment
- Verify documentation accuracy
- Check compatibility across Python versions
