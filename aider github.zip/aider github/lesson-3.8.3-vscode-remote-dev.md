# VS Code Remote Development Configuration Guide for Aider

## Remote Development Containers

### Basic Container Configuration

1. **Dev Container Configuration**
Create `.devcontainer/devcontainer.json`:
```json
{
    "name": "Aider Development Environment",
    "build": {
        "dockerfile": "Dockerfile",
        "context": "..",
        "args": {
            "PYTHON_VERSION": "3.10",
            "NODE_VERSION": "16"
        }
    },
    "customizations": {
        "vscode": {
            "extensions": [
                "ms-python.python",
                "ms-python.vscode-pylance",
                "ms-python.black-formatter",
                "ms-python.flake8",
                "eamodio.gitlens",
                "github.copilot"
            ],
            "settings": {
                "python.defaultInterpreterPath": "/usr/local/bin/python",
                "python.linting.enabled": true,
                "python.formatting.provider": "black",
                "editor.formatOnSave": true,
                "editor.rulers": [100],
                "files.trimTrailingWhitespace": true
            }
        }
    },
    "forwardPorts": [8000],
    "postCreateCommand": "pip install -e '.[dev]'",
    "remoteUser": "vscode"
}
```

2. **Dockerfile Configuration**
Create `.devcontainer/Dockerfile`:
```dockerfile
ARG PYTHON_VERSION
FROM mcr.microsoft.com/vscode/devcontainers/python:${PYTHON_VERSION}

# Install additional OS packages
RUN apt-get update && export DEBIAN_FRONTEND=noninteractive \
    && apt-get -y install --no-install-recommends \
    git \
    curl \
    ssh \
    build-essential \
    && apt-get clean \
    && rm -rf /var/lib/apt/lists/*

# Install Node.js
ARG NODE_VERSION
RUN curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash - \
    && apt-get install -y nodejs

# Create non-root user
ARG USERNAME=vscode
ARG USER_UID=1000
ARG USER_GID=$USER_UID

RUN if [ ! $(getent group $USER_GID) ]; then groupadd -g $USER_GID $USERNAME; fi \
    && if [ ! $(getent passwd $USER_UID) ]; then useradd -s /bin/bash -u $USER_UID -g $USER_GID -m $USERNAME; fi \
    && mkdir -p /home/$USERNAME/.vscode-server/extensions \
    && chown -R $USERNAME:$USERNAME /home/$USERNAME

# Setup Aider environment
ENV PYTHONUNBUFFERED=1
ENV PATH="/home/vscode/.local/bin:${PATH}"

# Copy requirements and install dependencies
COPY requirements/ /tmp/requirements/
RUN pip install --upgrade pip \
    && pip install -r /tmp/requirements/requirements-dev.txt

# Switch to non-root user
USER $USERNAME
```

### Advanced Container Features

1. **Multi-Stage Development Container**
Create `.devcontainer/docker-compose.yml`:
```yaml
version: '3.8'

services:
  aider-dev:
    build:
      context: ..
      dockerfile: .devcontainer/Dockerfile
      args:
        PYTHON_VERSION: 3.10
        NODE_VERSION: 16
    volumes:
      - ..:/workspace:cached
      - aider-extensions:/home/vscode/.vscode-server/extensions
      - aider-cache:/home/vscode/.cache
      - type: bind
        source: ${HOME}/.gitconfig
        target: /home/vscode/.gitconfig
        read_only: true
    command: sleep infinity
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}
    networks:
      - aider-network

  redis:
    image: redis:alpine
    ports:
      - "6379:6379"
    networks:
      - aider-network

volumes:
  aider-extensions:
  aider-cache:

networks:
  aider-network:
    driver: bridge
```

## Remote SSH Development

### SSH Configuration

1. **SSH Config Setup**
Create `.vscode/ssh-config`:
```
Host aider-remote
    HostName your-remote-server
    User vscode
    Port 22
    IdentityFile ~/.ssh/id_rsa
    ForwardAgent yes
    RemoteCommand cd /workspace && exec $SHELL -l
    RequestTTY yes
```

2. **Remote SSH Settings**
Create `.vscode/settings.json` for remote:
```json
{
    "remote.SSH.configFile": "${workspaceFolder}/.vscode/ssh-config",
    "remote.SSH.defaultExtensions": [
        "ms-python.python",
        "ms-python.vscode-pylance"
    ],
    "remote.SSH.lockfilesInTmp": true,
    "remote.SSH.showLoginTerminal": true,
    "remote.SSH.useLocalServer": true
}
```

### Remote Environment Setup

1. **Remote Installation Script**
Create `scripts/setup-remote.sh`:
```bash
#!/bin/bash

# Configuration
PYTHON_VERSION="3.10"
NODE_VERSION="16"
USERNAME="vscode"

# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install required packages
sudo apt-get install -y \
    git \
    curl \
    build-essential \
    python${PYTHON_VERSION} \
    python${PYTHON_VERSION}-venv \
    python3-pip

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | sudo -E bash -
sudo apt-get install -y nodejs

# Setup Python virtual environment
python${PYTHON_VERSION} -m venv ~/.venv
source ~/.venv/bin/activate

# Install Python packages
pip install --upgrade pip
pip install -r requirements/requirements-dev.txt

# Setup Git configuration
git config --global user.name "${GIT_USER_NAME}"
git config --global user.email "${GIT_USER_EMAIL}"

# Create workspace directory
mkdir -p ~/workspace
cd ~/workspace

# Clone repository if needed
if [ ! -d "aider" ]; then
    git clone https://github.com/yourusername/aider.git
fi
```

## GitHub Codespaces

### Codespaces Configuration

1. **Codespaces Default Configuration**
Create `.devcontainer/codespaces.json`:
```json
{
    "name": "Aider Codespace",
    "extensions": [
        "ms-python.python",
        "ms-python.vscode-pylance",
        "github.copilot",
        "github.vscode-github-actions"
    ],
    "dockerFile": "Dockerfile",
    "settings": {
        "python.pythonPath": "/usr/local/bin/python",
        "python.linting.enabled": true,
        "python.formatting.provider": "black",
        "editor.formatOnSave": true,
        "github.codespaces.defaultExtensions": [
            "github.codespaces",
            "github.vscode-pull-request-github"
        ]
    },
    "postCreateCommand": "bash .devcontainer/post-create.sh",
    "features": {
        "ghcr.io/devcontainers/features/python:1": {
            "version": "3.10"
        },
        "ghcr.io/devcontainers/features/node:1": {
            "version": "16"
        },
        "ghcr.io/devcontainers/features/git:1": {
            "version": "latest"
        }
    }
}
```

2. **Post-Create Script**
Create `.devcontainer/post-create.sh`:
```bash
#!/bin/bash

# Activate virtual environment
source ~/.venv/bin/activate

# Install development dependencies
pip install -e ".[dev]"

# Setup git configuration
git config --global pull.rebase false
git config --global core.autocrlf input

# Setup pre-commit hooks
pre-commit install

# Configure GitHub CLI
if [ -n "${GITHUB_TOKEN}" ]; then
    gh auth login --with-token <<< "${GITHUB_TOKEN}"
fi
```

## Remote Debugging

### Debug Configurations

1. **Remote Debug Setup**
Update `.vscode/launch.json`:
```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Remote Python: Attach",
            "type": "python",
            "request": "attach",
            "connect": {
                "host": "localhost",
                "port": 5678
            },
            "pathMappings": [
                {
                    "localRoot": "${workspaceFolder}",
                    "remoteRoot": "/workspace"
                }
            ]
        },
        {
            "name": "Remote Python: Current File",
            "type": "python",
            "request": "launch",
            "program": "${file}",
            "console": "integratedTerminal",
            "justMyCode": false,
            "env": {
                "PYTHONPATH": "${workspaceFolder}"
            }
        }
    ]
}
```

2. **Debug Helper Script**
Create `scripts/debug-setup.sh`:
```bash
#!/bin/bash

# Install debugpy
pip install debugpy

# Start debug server
python -m debugpy --listen 0.0.0.0:5678 --wait-for-client "$@"
```

## Remote Extensions

### Extension Sync Configuration

1. **Extension Settings Sync**
Create `.vscode/sync.json`:
```json
{
    "extensions.autoUpdate": true,
    "extensions.autoCheckUpdates": true,
    "extensions.ignoreRecommendations": false,
    "extensions.syncedExtensions": [
        "ms-python.python",
        "ms-python.vscode-pylance",
        "ms-python.black-formatter",
        "ms-python.flake8",
        "eamodio.gitlens",
        "github.copilot"
    ],
    "settings.sync.keybindingsPerPlatform": false,
    "settingsSync.ignoredSettings": [
        "window.zoomLevel",
        "workbench.colorTheme"
    ]
}
```

2. **Extension Installation Script**
Create `scripts/install-extensions.sh`:
```bash
#!/bin/bash

# Function to install VS Code extension
install_extension() {
    local extension=$1
    code --install-extension "$extension" --force
}

# Install required extensions
extensions=(
    "ms-python.python"
    "ms-python.vscode-pylance"
    "ms-python.black-formatter"
    "ms-python.flake8"
    "eamodio.gitlens"
    "github.copilot"
)

for extension in "${extensions[@]}"; do
    install_extension "$extension"
done
```

These configurations provide comprehensive setup for remote development environments, including container-based development, SSH connections, GitHub Codespaces, and remote debugging capabilities. Users can customize these configurations based on their specific needs and requirements.

