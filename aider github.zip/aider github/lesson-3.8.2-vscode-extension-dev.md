# VS Code Extension Development Guide for Aider

## Extension Project Setup

### Initial Project Structure

1. **Create Extension Project**
```bash
# Install yeoman and VS Code extension generator
npm install -g yo generator-code

# Generate extension project
yo code

# Select options:
# > New Extension (TypeScript)
# > aider-vscode
# > Description: Aider integration for VS Code
# > Initialize git repository? Yes
```

2. **Project Structure**
```
aider-vscode/
├── .vscode/
│   ├── launch.json
│   └── tasks.json
├── src/
│   ├── extension.ts
│   ├── aiderCommands.ts
│   ├── aiderProvider.ts
│   └── utils/
│       ├── config.ts
│       └── git.ts
├── package.json
├── tsconfig.json
└── README.md
```

## Core Extension Components

### Extension Entry Point

1. **Main Extension File**
Create `src/extension.ts`:
```typescript
import * as vscode from 'vscode';
import { AiderProvider } from './aiderProvider';
import { registerCommands } from './aiderCommands';

export function activate(context: vscode.ExtensionContext) {
    // Initialize Aider provider
    const aiderProvider = new AiderProvider(context);
    
    // Register custom editor provider
    context.subscriptions.push(
        vscode.window.registerCustomEditorProvider(
            'aider.chatView',
            aiderProvider
        )
    );
    
    // Register commands
    registerCommands(context, aiderProvider);
    
    // Register status bar item
    const statusBarItem = vscode.window.createStatusBarItem(
        vscode.StatusBarAlignment.Left,
        100
    );
    statusBarItem.text = "$(robot) Aider";
    statusBarItem.command = 'aider.showMenu';
    statusBarItem.show();
    
    context.subscriptions.push(statusBarItem);
}

export function deactivate() {
    // Cleanup code here
}
```

2. **Provider Implementation**
Create `src/aiderProvider.ts`:
```typescript
import * as vscode from 'vscode';
import { AiderConfig } from './utils/config';

export class AiderProvider implements vscode.CustomEditorProvider {
    private config: AiderConfig;
    
    constructor(private context: vscode.ExtensionContext) {
        this.config = new AiderConfig();
    }
    
    async resolveCustomEditor(
        document: vscode.CustomDocument,
        webviewPanel: vscode.WebviewPanel,
        token: vscode.CancellationToken
    ): Promise<void> {
        webviewPanel.webview.options = {
            enableScripts: true,
            localResourceRoots: [
                vscode.Uri.joinPath(this.context.extensionUri, 'media')
            ]
        };
        
        webviewPanel.webview.html = this.getHtmlForWebview(webviewPanel.webview);
        
        // Handle messages from webview
        webviewPanel.webview.onDidReceiveMessage(
            message => {
                switch (message.command) {
                    case 'sendMessage':
                        this.handleChatMessage(message.text);
                        break;
                }
            },
            undefined,
            this.context.subscriptions
        );
    }
    
    private getHtmlForWebview(webview: vscode.Webview): string {
        return `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Aider Chat</title>
            </head>
            <body>
                <div id="chat-container">
                    <div id="messages"></div>
                    <div id="input-container">
                        <textarea id="message-input"></textarea>
                        <button id="send-button">Send</button>
                    </div>
                </div>
                <script>
                    // Webview script implementation
                </script>
            </body>
            </html>
        `;
    }
    
    private async handleChatMessage(text: string): Promise<void> {
        // Implement chat message handling
    }
}
```

### Command Registration

1. **Command Definitions**
Create `src/aiderCommands.ts`:
```typescript
import * as vscode from 'vscode';
import { AiderProvider } from './aiderProvider';

export function registerCommands(
    context: vscode.ExtensionContext,
    provider: AiderProvider
): void {
    // Register command for starting new chat
    context.subscriptions.push(
        vscode.commands.registerCommand('aider.newChat', () => {
            const editor = vscode.window.activeTextEditor;
            if (editor) {
                // Implementation
            }
        })
    );
    
    // Register command for continuing chat
    context.subscriptions.push(
        vscode.commands.registerCommand('aider.continueChat', () => {
            // Implementation
        })
    );
    
    // Register command for applying changes
    context.subscriptions.push(
        vscode.commands.registerCommand('aider.applyChanges', () => {
            // Implementation
        })
    );
    
    // Register command for showing menu
    context.subscriptions.push(
        vscode.commands.registerCommand('aider.showMenu', () => {
            vscode.window.showQuickPick([
                'New Chat',
                'Continue Chat',
                'Apply Changes',
                'Show Settings'
            ]).then(selection => {
                // Handle selection
            });
        })
    );
}
```

## Extension Features

### Chat Integration

1. **Chat Implementation**
Create `src/features/chat.ts`:
```typescript
import * as vscode from 'vscode';

export class ChatManager {
    private chatHistory: Array<{
        role: 'user' | 'assistant',
        content: string
    }> = [];
    
    constructor(private context: vscode.ExtensionContext) {}
    
    public async sendMessage(message: string): Promise<void> {
        this.chatHistory.push({
            role: 'user',
            content: message
        });
        
        try {
            // Implement API call to Aider
            const response = await this.callAiderAPI(message);
            
            this.chatHistory.push({
                role: 'assistant',
                content: response
            });
            
            // Notify webview to update
            this.updateWebview();
        } catch (error) {
            vscode.window.showErrorMessage('Failed to send message to Aider');
        }
    }
    
    private async callAiderAPI(message: string): Promise<string> {
        // Implement actual API call
        return 'Response from Aider';
    }
    
    private updateWebview(): void {
        // Implementation
    }
}
```

### File System Integration

1. **File System Watcher**
Create `src/features/fileSystem.ts`:
```typescript
import * as vscode from 'vscode';
import { promises as fs } from 'fs';

export class FileSystemManager {
    private fileWatcher: vscode.FileSystemWatcher;
    
    constructor(private context: vscode.ExtensionContext) {
        this.fileWatcher = vscode.workspace.createFileSystemWatcher(
            '**/*.{py,js,ts,json,md}',
            false,
            false,
            false
        );
        
        this.registerFileWatcherEvents();
    }
    
    private registerFileWatcherEvents(): void {
        this.fileWatcher.onDidChange(async uri => {
            // Handle file changes
        });
        
        this.fileWatcher.onDidCreate(async uri => {
            // Handle new files
        });
        
        this.fileWatcher.onDidDelete(async uri => {
            // Handle deleted files
        });
        
        this.context.subscriptions.push(this.fileWatcher);
    }
    
    public async readFile(uri: vscode.Uri): Promise<string> {
        return await fs.readFile(uri.fsPath, 'utf-8');
    }
    
    public async writeFile(uri: vscode.Uri, content: string): Promise<void> {
        await fs.writeFile(uri.fsPath, content, 'utf-8');
    }
}
```

### Configuration Management

1. **Configuration Handler**
Create `src/utils/config.ts`:
```typescript
import * as vscode from 'vscode';

export class AiderConfig {
    private config: vscode.WorkspaceConfiguration;
    
    constructor() {
        this.config = vscode.workspace.getConfiguration('aider');
    }
    
    public get apiKey(): string {
        return this.config.get('apiKey', '');
    }
    
    public get model(): string {
        return this.config.get('model', 'gpt-4');
    }
    
    public get editFormat(): string {
        return this.config.get('editFormat', 'whole');
    }
    
    public async updateConfig(
        section: string,
        value: any,
        configurationTarget = vscode.ConfigurationTarget.Global
    ): Promise<void> {
        await this.config.update(section, value, configurationTarget);
    }
}
```

## Testing Setup

### Test Configuration

1. **Test Setup**
Create `src/test/suite/index.ts`:
```typescript
import * as path from 'path';
import * as Mocha from 'mocha';
import * as glob from 'glob';

export function run(): Promise<void> {
    const mocha = new Mocha({
        ui: 'tdd',
        color: true
    });
    
    const testsRoot = path.resolve(__dirname, '..');
    
    return new Promise((resolve, reject) => {
        glob('**/**.test.js', { cwd: testsRoot }, (err, files) => {
            if (err) {
                return reject(err);
            }
            
            files.forEach(f => mocha.addFile(path.resolve(testsRoot, f)));
            
            try {
                mocha.run(failures => {
                    if (failures > 0) {
                        reject(new Error(`${failures} tests failed.`));
                    } else {
                        resolve();
                    }
                });
            } catch (err) {
                reject(err);
            }
        });
    });
}
```

2. **Sample Test File**
Create `src/test/suite/extension.test.ts`:
```typescript
import * as assert from 'assert';
import * as vscode from 'vscode';

suite('Extension Test Suite', () => {
    vscode.window.showInformationMessage('Starting all tests.');
    
    test('Sample test', () => {
        assert.strictEqual(-1, [1, 2, 3].indexOf(5));
        assert.strictEqual(-1, [1, 2, 3].indexOf(0));
    });
});
```

## Debugging Configuration

### Debug Setup

1. **Launch Configuration**
Update `.vscode/launch.json`:
```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Extension",
            "type": "extensionHost",
            "request": "launch",
            "args": [
                "--extensionDevelopmentPath=${workspaceFolder}"
            ],
            "outFiles": [
                "${workspaceFolder}/out/**/*.js"
            ],
            "preLaunchTask": "${defaultBuildTask}"
        },
        {
            "name": "Extension Tests",
            "type": "extensionHost",
            "request": "launch",
            "args": [
                "--extensionDevelopmentPath=${workspaceFolder}",
                "--extensionTestsPath=${workspaceFolder}/out/test/suite/index"
            ],
            "outFiles": [
                "${workspaceFolder}/out/test/**/*.js"
            ],
            "preLaunchTask": "${defaultBuildTask}"
        }
    ]
}
```

These configurations and implementations provide a foundation for developing a VS Code extension that integrates Aider functionality. Developers can build upon this structure to add more features and capabilities as needed.

