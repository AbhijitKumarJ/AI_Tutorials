# VS Code Multi-root Workspace Configuration Guide for Aider

## Basic Multi-root Setup

### Workspace Configuration

1. **Main Workspace File**
Create `aider.code-workspace`:
```json
{
    "folders": [
        {
            "name": "Aider Core",
            "path": "."
        },
        {
            "name": "Aider Extensions",
            "path": "../aider-extensions"
        },
        {
            "name": "Aider Documentation",
            "path": "../aider-docs"
        },
        {
            "name": "Aider Examples",
            "path": "../aider-examples"
        }
    ],
    "settings": {
        "files.exclude": {
            "**/__pycache__": true,
            "**/*.pyc": true,
            "**/.pytest_cache": true,
            "**/.coverage": true
        },
        "search.exclude": {
            "**/node_modules": true,
            "**/bower_components": true,
            "**/*.code-search": true
        },
        "files.watcherExclude": {
            "**/.git/objects/**": true,
            "**/.git/subtree-cache/**": true,
            "**/node_modules/**": true,
            "**/.hg/store/**": true,
            "**/venv/**": true
        }
    },
    "extensions": {
        "recommendations": [
            "ms-python.python",
            "ms-python.vscode-pylance",
            "ms-python.black-formatter"
        ]
    }
}
```

### Root-Specific Settings

1. **Core Project Settings**
Create `.vscode/settings.json` in core project:
```json
{
    "python.defaultInterpreterPath": "${workspaceFolder}/venv/bin/python",
    "python.analysis.extraPaths": [
        "${workspaceFolder}/src"
    ],
    "python.testing.pytestEnabled": true,
    "python.testing.unittestEnabled": false,
    "python.testing.pytestArgs": [
        "tests"
    ],
    "aider.core": {
        "rootPath": "${workspaceFolder}",
        "srcPath": "${workspaceFolder}/src",
        "testsPath": "${workspaceFolder}/tests"
    }
}
```

2. **Extensions Project Settings**
Create `aider-extensions/.vscode/settings.json`:
```json
{
    "python.defaultInterpreterPath": "${workspaceFolder}/../aider/venv/bin/python",
    "python.analysis.extraPaths": [
        "${workspaceFolder}/src",
        "${workspaceFolder}/../aider/src"
    ],
    "aider.extensions": {
        "rootPath": "${workspaceFolder}",
        "extensionsPath": "${workspaceFolder}/extensions",
        "sharedPath": "${workspaceFolder}/../aider/src"
    }
}
```

## Project Organization

### Multi-root Structure

1. **Project Organization Script**
Create `scripts/setup-multiroot.sh`:
```bash
#!/bin/bash

# Configuration
BASE_DIR=$(pwd)
PROJECTS=(
    "aider"
    "aider-extensions"
    "aider-docs"
    "aider-examples"
)

# Function to setup virtual environment
setup_venv() {
    local project_dir=$1
    
    if [ ! -d "$project_dir/venv" ]; then
        echo "Creating virtual environment for $project_dir"
        python -m venv "$project_dir/venv"
        source "$project_dir/venv/bin/activate"
        pip install -e ".[dev]"
    fi
}

# Function to setup Git hooks
setup_git_hooks() {
    local project_dir=$1
    
    if [ -d "$project_dir/.git" ]; then
        echo "Setting up Git hooks for $project_dir"
        cd "$project_dir"
        pre-commit install
        cd "$BASE_DIR"
    fi
}

# Main setup
for project in "${PROJECTS[@]}"; do
    if [ ! -d "../$project" ]; then
        echo "Creating $project directory"
        mkdir -p "../$project"
    fi
    
    setup_venv "../$project"
    setup_git_hooks "../$project"
done

# Create workspace file if it doesn't exist
if [ ! -f "aider.code-workspace" ]; then
    echo "Creating workspace file"
    cat > aider.code-workspace << EOL
{
    "folders": [
        {
            "name": "Aider Core",
            "path": "."
        },
$(for project in "${PROJECTS[@]}"; do
    if [ "$project" != "aider" ]; then
        echo "        {
            \"name\": \"${project^}\",
            \"path\": \"../$project\"
        },"
    fi
done | sed '$ s/,$//')
    ],
    "settings": {}
}
EOL
fi
```

### Workspace Tasks

1. **Multi-root Tasks Configuration**
Create `.vscode/tasks.json`:
```json
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "Install All Dependencies",
            "type": "shell",
            "command": "${workspaceFolder}/scripts/install-all.sh",
            "presentation": {
                "reveal": "always",
                "panel": "new"
            },
            "problemMatcher": []
        },
        {
            "label": "Run All Tests",
            "type": "shell",
            "command": "${workspaceFolder}/scripts/test-all.sh",
            "group": {
                "kind": "test",
                "isDefault": true
            }
        },
        {
            "label": "Build Documentation",
            "type": "shell",
            "command": "cd ${workspaceFolder:Aider Documentation} && make html",
            "problemMatcher": []
        }
    ]
}
```

## Multi-root Development Workflows

### Integrated Development Scripts

1. **Development Environment Setup**
Create `scripts/dev-setup.sh`:
```bash
#!/bin/bash

# Configuration
ROOT_DIR=$(pwd)
VENV_DIR="venv"
PYTHON_VERSION="3.10"

# Function to setup project
setup_project() {
    local project_dir=$1
    local project_name=$2
    
    echo "Setting up $project_name..."
    
    # Create virtual environment
    if [ ! -d "$project_dir/$VENV_DIR" ]; then
        python${PYTHON_VERSION} -m venv "$project_dir/$VENV_DIR"
    fi
    
    # Activate virtual environment
    source "$project_dir/$VENV_DIR/bin/activate"
    
    # Install dependencies
    if [ -f "$project_dir/requirements-dev.txt" ]; then
        pip install -r "$project_dir/requirements-dev.txt"
    fi
    
    # Install project in development mode
    if [ -f "$project_dir/setup.py" ]; then
        pip install -e "$project_dir[dev]"
    fi
    
    # Setup pre-commit hooks
    if [ -f "$project_dir/.pre-commit-config.yaml" ]; then
        cd "$project_dir"
        pre-commit install
        cd "$ROOT_DIR"
    fi
    
    deactivate
}

# Setup all projects
setup_project "." "Aider Core"
setup_project "../aider-extensions" "Aider Extensions"
setup_project "../aider-docs" "Aider Documentation"
setup_project "../aider-examples" "Aider Examples"
```

2. **Development Workflow Scripts**
Create `scripts/workflow/`:
```bash
# scripts/workflow/sync-all.sh
#!/bin/bash

# Synchronize all projects
git pull origin main
cd ../aider-extensions && git pull origin main
cd ../aider-docs && git pull origin main
cd ../aider-examples && git pull origin main

# scripts/workflow/test-all.sh
#!/bin/bash

# Run tests for all projects
source venv/bin/activate
pytest tests/
cd ../aider-extensions && pytest tests/
deactivate

# scripts/workflow/lint-all.sh
#!/bin/bash

# Run linting for all projects
source venv/bin/activate
flake8 .
black . --check
cd ../aider-extensions && flake8 .
cd ../aider-extensions && black . --check
deactivate
```

## Multi-root Source Control

### Git Configuration

1. **Git Workspace Configuration**
Create `.gitconfig-workspace`:
```ini
[core]
    excludesfile = ~/.gitignore_global
    autocrlf = input
    
[includeIf "gitdir:./"]
    path = .gitconfig-core
    
[includeIf "gitdir:../aider-extensions/"]
    path = .gitconfig-extensions
    
[includeIf "gitdir:../aider-docs/"]
    path = .gitconfig-docs
    
[includeIf "gitdir:../aider-examples/"]
    path = .gitconfig-examples
```

2. **Project-Specific Git Settings**
Create project-specific git configs:
```ini
# .gitconfig-core
[user]
    email = core@aider.chat
    
[commit]
    template = .gitmessage-core
    
# .gitconfig-extensions
[user]
    email = extensions@aider.chat
    
[commit]
    template = .gitmessage-extensions
```

## Multi-root Testing

### Test Configuration

1. **Pytest Configuration**
Create `pytest.ini`:
```ini
[pytest]
testpaths =
    tests
    ../aider-extensions/tests
python_files = test_*.py
python_classes = Test
python_functions = test_*
addopts = --verbose --cov=aider --cov=aider_extensions
markers =
    core: marks tests as core functionality
    extensions: marks tests as extension functionality
```

2. **Test Runner Script**
Create `scripts/run-tests.sh`:
```bash
#!/bin/bash

# Configuration
COVERAGE_DIR="coverage"
mkdir -p "$COVERAGE_DIR"

# Function to run tests for a project
run_project_tests() {
    local project_dir=$1
    local project_name=$2
    
    echo "Running tests for $project_name..."
    
    if [ -d "$project_dir/tests" ]; then
        cd "$project_dir"
        source venv/bin/activate
        
        pytest tests/ \
            --cov \
            --cov-report=html:../$COVERAGE_DIR/$project_name \
            --cov-report=xml:../$COVERAGE_DIR/$project_name/coverage.xml
        
        deactivate
        cd ..
    fi
}

# Run tests for all projects
run_project_tests "." "aider"
run_project_tests "aider-extensions" "extensions"
```

These configurations provide a comprehensive setup for multi-root workspace development in VS Code, including project organization, shared settings, integrated workflows, and testing configurations. Users can adapt these settings based on their specific project requirements and development workflows.

