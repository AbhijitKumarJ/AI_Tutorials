# End User Guide: Using Aider's Release Systems

## Setting Up Your Environment

### Initial Configuration

Before working with Aider's release systems, you'll need to set up your environment properly. Here's a step-by-step guide:

1. **Python Environment Setup**
   ```bash
   # Create a virtual environment
   python -m venv venv
   
   # Activate the virtual environment
   # On Windows:
   venv\Scripts\activate
   # On Unix/MacOS:
   source venv/bin/activate
   
   # Verify Python version
   python --version  # Should be 3.9 or higher
   ```

2. **Installing Development Tools**
   ```bash
   # Install basic development requirements
   pip install -r requirements/requirements-dev.txt
   
   # For contributing to documentation
   pip install -r requirements/requirements-help.txt
   ```

3. **Git Configuration**
   ```bash
   # Configure Git with your details
   git config --global user.name "Your Name"
   git config --global user.email "your.email@example.com"
   
   # Set up GPG signing if you'll be creating releases
   git config --global commit.gpgsign true
   git config --global user.signingkey YOUR_GPG_KEY_ID
   ```

## Working with Docker Images

### Using Aider Docker Images

1. **Pulling the Images**
   ```bash
   # Pull the standard image
   docker pull aider/aider:latest
   
   # Pull the full image with all dependencies
   docker pull aider/aider-full:latest
   ```

2. **Running Aider in Docker**
   ```bash
   # Basic usage
   docker run -it --rm aider/aider
   
   # With local files mounted
   docker run -it --rm \
     -v $(pwd):/workspace \
     -w /workspace \
     aider/aider
   
   # With environment variables
   docker run -it --rm \
     -e OPENAI_API_KEY=your_key_here \
     aider/aider
   ```

3. **Custom Docker Configurations**
   Create a `.env` file for your environment variables:
   ```ini
   OPENAI_API_KEY=your_key_here
   ANTHROPIC_API_KEY=your_key_here
   ```

   Create a docker-compose.yml for easier usage:
   ```yaml
   version: '3'
   services:
     aider:
       image: aider/aider:latest
       volumes:
         - .:/workspace
       working_dir: /workspace
       env_file: .env
       tty: true
       stdin_open: true
   ```

   Then use it:
   ```bash
   docker-compose run --rm aider
   ```

## Installing and Using Aider

### Installation Methods

1. **Using pip (Recommended for Users)**
   ```bash
   # Basic installation
   pip install aider-chat
   
   # With all optional dependencies
   pip install "aider-chat[all]"
   
   # Development installation
   pip install -e ".[dev]"
   ```

2. **Using pipx (Isolated Installation)**
   ```bash
   # Install pipx if needed
   python -m pip install --user pipx
   python -m pipx ensurepath
   
   # Install aider
   pipx install aider-chat
   ```

### Configuration Setup

1. **API Keys Setup**
   Create a `.env` file in your project directory:
   ```ini
   # OpenAI configuration
   OPENAI_API_KEY=sk-...
   
   # Anthropic configuration
   ANTHROPIC_API_KEY=sk-ant-...
   ```

2. **Aider Configuration File**
   Create an `aider.conf.yml` file:
   ```yaml
   # Model configuration
   model: gpt-4-0125-preview
   edit_format: whole
   
   # Git configuration
   auto_commits: true
   commit_messages: true
   
   # Editor configuration
   editor: code
   ```

## Using Package Releases

### Installing Different Versions

1. **Standard Installation**
   ```bash
   # Latest stable version
   pip install aider-chat
   
   # Specific version
   pip install aider-chat==0.8.0
   
   # Latest development version
   pip install --pre aider-chat
   ```

2. **Installing Extras**
   ```bash
   # Install with browser support
   pip install "aider-chat[browser]"
   
   # Install with help system
   pip install "aider-chat[help]"
   
   # Install all extras
   pip install "aider-chat[all]"
   ```

### Version Management

1. **Checking Versions**
   ```bash
   # Check installed version
   aider --version
   
   # List all installed dependencies
   pip freeze | grep aider
   ```

2. **Upgrading Aider**
   ```bash
   # Upgrade to latest stable
   pip install --upgrade aider-chat
   
   # Upgrade including pre-releases
   pip install --upgrade --pre aider-chat
   ```

## Common Workflows

### Development Workflow

1. **Starting a Development Session**
   ```bash
   # Clone the repository
   git clone https://github.com/Aider-AI/aider.git
   cd aider
   
   # Create and activate virtual environment
   python -m venv venv
   source venv/bin/activate  # or `venv\Scripts\activate` on Windows
   
   # Install development dependencies
   pip install -e ".[dev]"
   ```

2. **Running Tests**
   ```bash
   # Run all tests
   pytest
   
   # Run specific test file
   pytest tests/basic/test_main.py
   
   # Run with coverage
   pytest --cov=aider
   ```

3. **Code Quality Checks**
   ```bash
   # Run pre-commit hooks
   pre-commit run --all-files
   
   # Run specific checks
   flake8 aider
   black aider --check
   isort aider --check-only
   ```

### Troubleshooting Common Issues

1. **Docker Issues**
   
   Issue: Permission denied when mounting volumes
   ```bash
   # Fix permissions
   sudo chown -R $USER:$USER .
   
   # Or run with correct user
   docker run -it --rm \
     -u $(id -u):$(id -g) \
     -v $(pwd):/workspace \
     aider/aider
   ```

2. **Installation Issues**
   
   Issue: Dependency conflicts
   ```bash
   # Create clean environment
   python -m venv fresh-env
   source fresh-env/bin/activate
   
   # Install with verbose output
   pip install -v aider-chat
   ```

3. **API Key Issues**
   
   Issue: API key not found
   ```bash
   # Verify environment variables
   python -c "import os; print(os.getenv('OPENAI_API_KEY'))"
   
   # Set temporary key
   export OPENAI_API_KEY=your_key_here
   ```

## Advanced Usage

### Custom Configuration

1. **Creating a Custom Configuration File**
   ```yaml
   # ~/.aider.conf.yml
   
   # Model settings
   model: gpt-4-0125-preview
   temperature: 0.7
   max_tokens: 4096
   
   # Editor settings
   editor: vim
   pair_programming: true
   
   # Git settings
   auto_commits: true
   commit_message_prefix: "aider: "
   
   # Logging settings
   verbose: true
   log_file: ~/.aider/debug.log
   ```

2. **Using Environment Variables**
   ```bash
   # Set in shell
   export AIDER_MODEL=gpt-4-0125-preview
   export AIDER_EDIT_FORMAT=whole
   
   # Or in .env file
   AIDER_MODEL=gpt-4-0125-preview
   AIDER_EDIT_FORMAT=whole
   ```

### Working with Git

1. **Commit Management**
   ```bash
   # Enable auto-commits
   aider --auto-commits
   
   # Disable auto-commits
   aider --no-auto-commits
   
   # Custom commit message prefix
   aider --commit-message-prefix "feat: "
   ```

2. **Branch Management**
   ```bash
   # Create and switch to feature branch
   git checkout -b feature/new-feature
   
   # Start aider in branch
   aider --git-branch feature/new-feature
   ```

## Best Practices

### Project Organization

1. **Recommended Directory Structure**
   ```
   your-project/
   ├── .env                    # Environment variables
   ├── .aider.conf.yml        # Aider configuration
   ├── .gitignore             # Git ignore file
   ├── venv/                  # Virtual environment
   ├── src/                   # Source code
   ├── tests/                 # Test files
   └── docs/                  # Documentation
   ```

2. **Version Control Best Practices**
   ```bash
   # Create .gitignore
   echo "venv/
   .env
   *.pyc
   .aider.chat.history.md" > .gitignore
   
   # Regular commits
   git add .
   git commit -m "feat: add new feature"
   
   # Create version tags
   git tag -a v1.0.0 -m "Release version 1.0.0"
   ```

3. **Environment Management**
   ```bash
   # Create requirements files
   pip freeze > requirements.txt
   
   # Create environment file template
   cat > .env.template << EOL
   OPENAI_API_KEY=your_key_here
   ANTHROPIC_API_KEY=your_key_here
   EOL
   ```

These usage details provide a comprehensive guide for end users working with Aider's release systems and related tools. The information covers both basic and advanced usage patterns, along with troubleshooting tips and best practices for optimal use of the system.

