# Practical Exercises: Release Automation in Aider

## Exercise Set 1: Docker Release Configuration

### Exercise 1.1: Multi-Stage Dockerfile Development

In this exercise, you will create a multi-stage Dockerfile similar to Aider's approach. This hands-on experience will help you understand the benefits and implementation of multi-stage builds.

**Task Requirements:**
1. Create a Python application with the following structure:
```
myapp/
├── app/
│   ├── __init__.py
│   └── main.py
├── requirements/
│   ├── requirements.txt
│   └── requirements-full.txt
└── Dockerfile
```

2. Implement a multi-stage Dockerfile that:
   - Uses python:3.10-slim as the base image
   - Creates a 'base' stage with common dependencies
   - Builds both 'standard' and 'full' variants
   - Implements proper permission handling
   - Sets up environment variables
   - Configures appropriate entrypoints

**Implementation Guide:**

Start with this basic structure and expand it:
```dockerfile
FROM python:3.10-slim AS base

# Add your base configuration here

FROM base AS myapp-full
# Add full version configuration

FROM base AS myapp
# Add standard version configuration
```

### Exercise 1.2: GitHub Actions Workflow Development

Create a GitHub Actions workflow for Docker image building and publishing.

**Task Requirements:**
1. Create a workflow file with the following features:
   - Triggers on version tags and manual dispatch
   - Implements multi-platform builds
   - Uses repository secrets
   - Includes proper error handling
   - Implements build caching
   - Adds image scanning

2. Test the workflow with both successful and failure scenarios

**Template Structure:**
```yaml
name: Docker Release
on:
  workflow_dispatch:
  push:
    tags:
      - 'v[0-9]+.[0-9]+.[0-9]+'

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      # Add your steps here
```

## Exercise Set 2: PyPI Release Automation

### Exercise 2.1: Version Management Script

Develop a version management script similar to Aider's versionbump.py.

**Task Requirements:**
1. Create a script that:
   - Validates version numbers
   - Updates version in package files
   - Creates and pushes Git tags
   - Handles development versions
   - Implements dry-run functionality
   - Includes error handling

**Implementation Framework:**
```python
#!/usr/bin/env python
import argparse
import re
import subprocess
from packaging import version

def validate_version(version_str):
    # Implement version validation

def update_version_files(new_version, dry_run=False):
    # Implement version file updates

def create_git_tag(version, dry_run=False):
    # Implement git tagging

def main():
    parser = argparse.ArgumentParser()
    # Add argument parsing
    
if __name__ == "__main__":
    main()
```

### Exercise 2.2: PyPI Release Workflow

Implement a complete PyPI release workflow including build configuration.

**Task Requirements:**
1. Create a pyproject.toml with:
   - Dynamic version handling
   - Multiple dependency groups
   - Build system configuration
   - Project metadata

2. Implement a GitHub Actions workflow that:
   - Builds the package
   - Runs tests before release
   - Publishes to PyPI
   - Creates GitHub releases
   - Generates release notes

**Configuration Template:**
```toml
[project]
name = "your-package"
dynamic = ["version"]
# Add additional configuration

[build-system]
requires = ["setuptools>=68", "setuptools_scm[toml]>=8"]
build-backend = "setuptools.build_meta"
```

## Exercise Set 3: Integration Challenges

### Exercise 3.1: Coordinated Release Process

Develop a script that coordinates both Docker and PyPI releases.

**Task Requirements:**
1. Create a script that:
   - Ensures version consistency
   - Coordinates release timing
   - Implements rollback capabilities
   - Adds validation checks
   - Generates release documentation

2. Handle various edge cases:
   - Failed builds
   - Network issues
   - Version conflicts
   - Incomplete releases

### Exercise 3.2: Release Testing Framework

Create a testing framework for release processes.

**Task Requirements:**
1. Implement tests for:
   - Version validation
   - Build processes
   - Release workflows
   - Installation verification
   - Documentation accuracy

2. Create test environments for:
   - Multiple Python versions
   - Different operating systems
   - Various dependency combinations

## Assessment Criteria

### Docker Release Exercises
- Correct implementation of multi-stage builds
- Proper handling of permissions and security
- Successful multi-platform builds
- Effective use of build caching
- Proper secret management
- Clear documentation

### PyPI Release Exercises
- Accurate version management
- Successful build and distribution
- Proper dependency handling
- Effective error management
- Complete documentation
- Successful test execution

### Integration Exercises
- Coordination of release processes
- Handling of edge cases
- Comprehensive testing
- Clear error reporting
- Complete documentation
- Successful validation