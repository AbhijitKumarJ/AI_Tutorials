# IDE and Development Environment Integration Guide

## Visual Studio Code Integration

### Setup and Configuration

1. **Workspace Configuration**
   Create a `.vscode/settings.json` file:
   ```json
   {
     "python.pythonPath": "${workspaceFolder}/venv/bin/python",
     "python.linting.enabled": true,
     "python.linting.flake8Enabled": true,
     "python.formatting.provider": "black",
     "editor.formatOnSave": true,
     "files.watcherExclude": {
       "**/.aider.chat.history.md": true
     }
   }
   ```

2. **Extensions Setup**
   Install recommended extensions:
   ```json
   // .vscode/extensions.json
   {
     "recommendations": [
       "ms-python.python",
       "ms-python.vscode-pylance",
       "njpwerner.autodocstring",
       "streetsidesoftware.code-spell-checker"
     ]
   }
   ```

### Task Configuration

1. **VS Code Tasks**
   Create `.vscode/tasks.json`:
   ```json
   {
     "version": "2.0.0",
     "tasks": [
       {
         "label": "Start Aider",
         "type": "shell",
         "command": "${workspaceFolder}/venv/bin/aider",
         "args": ["${file}"],
         "presentation": {
           "reveal": "always",
           "panel": "new"
         }
       },
       {
         "label": "Run Tests",
         "type": "shell",
         "command": "pytest",
         "group": {
           "kind": "test",
           "isDefault": true
         }
       }
     ]
   }
   ```

2. **Keyboard Shortcuts**
   Create `.vscode/keybindings.json`:
   ```json
   {
     "key": "ctrl+shift+a",
     "command": "workbench.action.tasks.runTask",
     "args": "Start Aider"
   }
   ```

## PyCharm Integration

### Project Setup

1. **Project Interpreter Configuration**
   ```bash
   # Create virtual environment
   python -m venv venv
   
   # Configure in PyCharm:
   # Settings > Project > Python Interpreter > Add Interpreter > Existing Environment
   ```

2. **Run Configurations**
   Create a run configuration for Aider:
   ```xml
   <!-- .idea/runConfigurations/Aider.xml -->
   <configuration default="false" name="Aider" type="PythonConfigurationType">
     <module name="your-project" />
     <option name="INTERPRETER_OPTIONS" value="" />
     <option name="PARENT_ENVS" value="true" />
     <envs>
       <env name="PYTHONUNBUFFERED" value="1" />
       <env name="OPENAI_API_KEY" value="$OPENAI_API_KEY" />
     </envs>
     <option name="SDK_HOME" value="$PROJECT_DIR$/venv/bin/python" />
     <option name="WORKING_DIRECTORY" value="$PROJECT_DIR$" />
     <option name="IS_MODULE_SDK" value="false" />
     <option name="ADD_CONTENT_ROOTS" value="true" />
     <option name="ADD_SOURCE_ROOTS" value="true" />
     <option name="SCRIPT_NAME" value="$PROJECT_DIR$/venv/bin/aider" />
     <option name="PARAMETERS" value="" />
     <option name="SHOW_COMMAND_LINE" value="false" />
     <option name="EMULATE_TERMINAL" value="true" />
     <method v="2" />
   </configuration>
   ```

### File Watchers

1. **Configure File Watchers**
   ```xml
   <!-- .idea/watcherTasks.xml -->
   <component name="ProjectTasksOptions">
     <TaskOptions isEnabled="true">
       <option name="arguments" value="$FilePath$" />
       <option name="checkSyntaxErrors" value="true" />
       <option name="description" />
       <option name="exitCodeBehavior" value="ERROR" />
       <option name="fileExtension" value="py" />
       <option name="immediateSync" value="false" />
       <option name="name" value="Black" />
       <option name="output" value="$FilePath$" />
       <option name="outputFilters">
         <array />
       </option>
       <option name="outputFromStdout" value="false" />
       <option name="program" value="$PyInterpreterDirectory$/black" />
       <option name="runOnExternalChanges" value="true" />
       <option name="scopeName" value="Project Files" />
       <option name="trackOnlyRoot" value="false" />
       <option name="workingDir" value="$ProjectFileDir$" />
       <envs />
     </TaskOptions>
   </component>
   ```

## Sublime Text Integration

### Package Configuration

1. **Package Control Settings**
   ```json