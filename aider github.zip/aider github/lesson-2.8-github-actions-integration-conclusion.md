# GitHub Actions Testing: Integration and Course Conclusion

## Comprehensive Integration Example

Let's examine a complete integration example that combines all the concepts covered in our lessons.

### Project Structure
```
cross-platform-project/
├── .github/
│   └── workflows/
│       ├── integration-tests.yml
│       └── platform-tests.yml
├── src/
│   ├── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── file_handler.py
│   │   └── platform_utils.py
│   └── utils/
│       ├── __init__.py
│       ├── logging_config.py
│       └── test_helpers.py
├── tests/
│   ├── __init__.py
│   ├── conftest.py
│   ├── integration/
│   │   ├── __init__.py
│   │   └── test_cross_platform.py
│   └── platform_specific/
│       ├── __init__.py
│       ├── test_unix.py
│       └── test_windows.py
└── pytest.ini
```

### 1. Integration Workflow Configuration

```yaml
# .github/workflows/integration-tests.yml
name: Integration Tests

on:
  push:
    branches: [ main, develop ]
    paths-ignore:
      - '**.md'
      - 'docs/**'
  pull_request:
    branches: [ main, develop ]
  workflow_dispatch:
    inputs:
      debug-enabled:
        description: 'Enable debug mode'
        required: false
        default: 'false'

jobs:
  integration:
    name: Integration Tests (${{ matrix.os }})
    runs-on: ${{ matrix.os }}
    strategy:
      fail-fast: false
      matrix:
        os: [ubuntu-latest, windows-latest]
        python-version: ['3.11']
        include:
          - os: ubuntu-latest
            test_command: pytest tests/integration/
          - os: windows-latest
            test_command: pytest tests\integration\

    steps:
      - uses: actions/checkout@v4

      - name: Set up Python ${{ matrix.python-version }}
        uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
          cache: 'pip'

      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements/requirements-dev.txt
          pip install -e .
        
      - name: Debug Info
        if: github.event.inputs.debug-enabled == 'true'
        run: |
          python -c "import sys; print(sys.version)"
          python -c "import platform; print(platform.platform())"
          pip list

      - name: Run Integration Tests
        run: ${{ matrix.test_command }}
        env:
          PYTHONPATH: ${{ github.workspace }}
          TEST_DEBUG: ${{ github.event.inputs.debug-enabled }}
```

### 2. Cross-Platform Integration Tests

```python
# tests/integration/test_cross_platform.py
import os
import platform
import pytest
from pathlib import Path
from src.core.file_handler import FileHandler
from src.core.platform_utils import PlatformUtils

class TestCrossPlatformIntegration:
    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        self.tmp_path = tmp_path
        self.file_handler = FileHandler(base_path=tmp_path)
        self.platform_utils = PlatformUtils()

    def test_file_operations_integration(self):
        """Test integrated file operations across platforms."""
        # Create a complex file structure
        test_content = "Test content\nWith multiple lines"
        file_path = self.file_handler.create_file(
            "test.txt",
            content=test_content,
            make_executable=True
        )

        # Verify basic file properties
        assert file_path.exists()
        assert file_path.read_text() == test_content

        # Verify platform-specific behaviors
        if platform.system() != 'Windows':
            # Check Unix permissions
            mode = file_path.stat().st_mode
            assert mode & 0o111  # Executable bits
            assert mode & 0o444  # Readable bits
        else:
            # Check Windows attributes
            import stat
            assert not bool(file_path.stat().st_mode & stat.S_IEXEC)

    def test_path_manipulation_integration(self):
        """Test path handling integration across platforms."""
        # Create nested directory structure
        deep_path = self.tmp_path / "level1" / "level2" / "level3"
        deep_path.mkdir(parents=True)

        # Create files in nested structure
        files = []
        for i in range(3):
            file_path = deep_path / f"file_{i}.txt"
            file_path.write_text(f"Content {i}")
            files.append(file_path)

        # Test path resolution
        resolved_paths = [
            self.platform_utils.resolve_path(str(f))
            for f in files
        ]

        # Verify all paths exist and are absolute
        for path in resolved_paths:
            assert os.path.exists(path)
            assert os.path.isabs(path)

    def test_complex_file_operations(self):
        """Test complex file operations with platform considerations."""
        # Create a file with platform-specific line endings
        content = "Line 1\nLine 2\nLine 3"
        file_path = self.file_handler.create_file(
            "test.txt",
            content=content
        )

        # Read and verify line endings
        with open(file_path, 'rb') as f:
            raw_content = f.read()

        if platform.system() == 'Windows':
            assert b'\r\n' in raw_content
        else:
            assert b'\n' in raw_content and b'\r\n' not in raw_content

    @pytest.mark.skipif(
        platform.system() == 'Windows',
        reason="Symlink tests not reliable on Windows CI"
    )
    def test_symlink_handling(self):
        """Test symlink handling on Unix platforms."""
        # Create original file
        original = self.tmp_path / "original.txt"
        original.write_text("Original content")

        # Create symlink
        link = self.tmp_path / "link.txt"
        link.symlink_to(original)

        # Verify symlink properties
        assert link.is_symlink()
        assert link.resolve() == original.resolve()
        assert link.read_text() == "Original content"

        # Test symlink preservation in file operations
        moved_link = self.file_handler.move_file(link, "moved_link.txt")
        assert moved_link.is_symlink()
        assert moved_link.read_text() == "Original content"
```

### 3. Platform-Specific Utilities

```python
# src/core/platform_utils.py
import os
import platform
import logging
from pathlib import Path
from typing import Union, Optional

logger = logging.getLogger(__name__)

class PlatformUtils:
    """Utility class for platform-specific operations."""
    
    def __init__(self):
        self.system = platform.system()
        self._setup_platform_specifics()
    
    def _setup_platform_specifics(self):
        """Configure platform-specific settings."""
        if self.system == 'Windows':
            self.path_separator = '\\'
            self.line_ending = '\r\n'
            self.executable_extensions = ('.exe', '.bat', '.cmd')
        else:
            self.path_separator = '/'
            self.line_ending = '\n'
            self.executable_extensions = ()
    
    def resolve_path(
        self,
        path: Union[str, Path],
        make_absolute: bool = True
    ) -> Path:
        """
        Resolve a path considering platform-specific requirements.
        
        Args:
            path: Path to resolve
            make_absolute: Convert to absolute path if True
            
        Returns:
            Resolved Path object
        """
        try:
            path = Path(path)
            if make_absolute:
                path = path.absolute()
            
            # Handle Windows-specific path length limitation
            if self.system == 'Windows':
                # Prepend long path prefix if needed
                str_path = str(path)
                if len(str_path) >= 260 and not str_path.startswith('\\\\?\\'):
                    return Path('\\\\?\\' + str_path)
            
            return path
        except Exception as e:
            logger.error(f"Path resolution failed: {e}")
            raise
```

## Final Assessment Project

### Project Requirements

Create a complete cross-platform file management system that:

1. Handles file operations safely across platforms:
   - Create, read, write, and delete files
   - Manage directories and nested structures
   - Handle permissions appropriately
   - Process symlinks where supported

2. Implements comprehensive testing:
   - Unit tests for all components
   - Integration tests for system interaction
   - Platform-specific test suites
   - Property-based tests for edge cases

3. Uses GitHub Actions for CI/CD:
   - Matrix testing across platforms
   - Automated test execution
   - Coverage reporting
   - Performance benchmarking

### Example Implementation Outline

1. Core Component Structure:
```python
# src/core/file_system.py
class CrossPlatformFileSystem:
    def __init__(self):
        self.platform_utils = PlatformUtils()
        self.file_handler = FileHandler()
    
    def process_directory(self, path: Union[str, Path]) -> dict:
        """Process a directory and return its structure."""
        path = self.platform_utils.resolve_path(path)
        structure = {
            'path': str(path),
            'files': [],
            'directories': [],
            'symlinks': [],
            'errors': []
        }
        
        try:
            for item in path.iterdir():
                try:
                    if item.is_symlink():
                        structure['symlinks'].append(self._process_symlink(item))
                    elif item.is_file():
                        structure['files'].append(self._process_file(item))
                    elif item.is_dir():
                        structure['directories'].append(
                            self.process_directory(item)
                        )
                except Exception as e:
                    structure['errors'].append({
                        'path': str(item),
                        'error': str(e)
                    })
        except Exception as e:
            structure['errors'].append({
                'path': str(path),
                'error': str(e)
            })
        
        return structure
```

2. Integration Tests:
```python
# tests/integration/test_file_system.py
class TestFileSystemIntegration:
    def test_complex_directory_processing(self, tmp_path):
        fs = CrossPlatformFileSystem()
        
        # Create complex directory structure
        structure = create_test_directory_structure(tmp_path)
        
        # Process and verify
        result = fs.process_directory(tmp_path)
        
        # Verify structure matches expected
        verify_directory_structure(result, structure)
    
    def test_error_handling(self, tmp_path):
        fs = CrossPlatformFileSystem()
        
        # Create problematic files/directories
        create_problem_cases(tmp_path)
        
        # Process and verify error handling
        result = fs.process_directory(tmp_path)
        
        # Verify errors are captured properly
        verify_error_handling(result)
```

## Course Conclusion

### Key Takeaways

1. Cross-Platform Development:
   - Always use platform-agnostic tools like `pathlib`
   - Implement proper error handling for each platform
   - Test thoroughly on all target platforms

2. GitHub Actions Best Practices:
   - Implement matrix testing effectively
   - Use proper trigger conditions
   - Handle secrets and environment variables securely
   - Optimize workflow execution

3. Testing Strategies:
   - Separate unit and integration tests
   - Implement platform-specific test suites
   - Use fixtures and helpers effectively
   - Maintain high test coverage

### Next Steps

1. Advanced Topics:
   - Container-based testing
   - Performance optimization
   - Advanced GitHub Actions features
   - Custom action development

2. Additional Resources:
   - GitHub Actions documentation
   - Python testing best practices
   - Cross-platform development guides
   - Community forums and support

### Final Tips

1. Always start with platform-agnostic code
2. Test early and often on all target platforms
3. Use proper error handling and logging
4. Keep workflows modular and maintainable
5. Document platform-specific requirements clearly
6. Maintain comprehensive test coverage
7. Regular dependency updates and security checks

This concludes our comprehensive course on GitHub Actions testing and cross-platform development. Remember to regularly review and update your knowledge as tools and best practices evolve.
