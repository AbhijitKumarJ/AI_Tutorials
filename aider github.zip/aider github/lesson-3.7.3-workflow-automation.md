# Workflow Automation and CI/CD Integration Guide

## GitHub Actions Integration

### Local Development Workflow

1. **Pre-commit Configuration**
Create `.pre-commit-config.yaml`:
```yaml
repos:
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.4.0
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
      - id: check-yaml
      - id: check-added-large-files
  
  - repo: https://github.com/psf/black
    rev: 23.3.0
    hooks:
      - id: black
        args: ["--line-length", "100"]
  
  - repo: https://github.com/pycqa/flake8
    rev: 6.0.0
    hooks:
      - id: flake8
        args: ["--max-line-length=100"]
```

2. **Local Automation Scripts**
Create `scripts/local_checks.sh`:
```bash
#!/bin/bash
set -e

# Function to run checks
run_checks() {
    echo "Running local checks..."
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Run tests
    pytest
    
    # Run linting
    flake8 .
    
    # Run type checking
    mypy .
    
    # Run security checks
    bandit -r .
}

# Setup git hooks
setup_hooks() {
    pre-commit install
    pre-commit install --hook-type commit-msg
}

# Main execution
main() {
    if [ ! -d "venv" ]; then
        python -m venv venv
        source venv/bin/activate
        pip install -r requirements/requirements-dev.txt
    fi
    
    setup_hooks
    run_checks
}

main "$@"
```

### Continuous Integration Setup

1. **Basic CI Workflow**
Create `.github/workflows/ci.yml`:
```yaml
name: CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: [3.9, 3.10, 3.11]

    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v4
      with:
        python-version: ${{ matrix.python-version }}
        
    - name: Cache pip packages
      uses: actions/cache@v3
      with:
        path: ~/.cache/pip
        key: pip-${{ runner.os }}-${{ matrix.python-version }}-${{ hashFiles('requirements/*.txt') }}
        
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -e ".[dev]"
        
    - name: Run tests
      run: pytest
      
    - name: Run linting
      run: |
        flake8 .
        black . --check
```

2. **Automated Release Process**
Create `.github/workflows/release.yml`:
```yaml
name: Release

on:
  push:
    tags:
      - 'v*.*.*'

jobs:
  release:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.10'
        
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install build twine
        
    - name: Build and publish
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: |
        python -m build
        twine upload dist/*
```

## Jenkins Pipeline Integration

### Pipeline Configuration

1. **Jenkinsfile Setup**
Create `Jenkinsfile`:
```groovy
pipeline {
    agent {
        docker {
            image 'python:3.10-slim'
            args '-v $HOME/.cache/pip:/root/.cache/pip'
        }
    }
    
    environment {
        PYTHON_PATH = "${WORKSPACE}/venv/bin:$PATH"
    }
    
    stages {
        stage('Setup') {
            steps {
                sh '''
                    python -m venv venv
                    . venv/bin/activate
                    pip install -e ".[dev]"
                '''
            }
        }
        
        stage('Test') {
            steps {
                sh '''
                    . venv/bin/activate
                    pytest --junitxml=test-results/junit.xml
                '''
            }
            post {
                always {
                    junit 'test-results/junit.xml'
                }
            }
        }
        
        stage('Quality Checks') {
            parallel {
                stage('Lint') {
                    steps {
                        sh '''
                            . venv/bin/activate
                            flake8 . --output-file=flake8.txt
                            black . --check
                        '''
                    }
                }
                
                stage('Security') {
                    steps {
                        sh '''
                            . venv/bin/activate
                            bandit -r . -f json -o bandit-report.json
                        '''
                    }
                }
            }
        }
    }
    
    post {
        always {
            cleanWs()
        }
    }
}
```

## Automated Testing Framework

### Test Configuration

1. **Pytest Configuration**
Create `pytest.ini`:
```ini
[pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test
python_functions = test_*
addopts = 
    --verbose
    --cov=aider
    --cov-report=html
    --cov-report=xml
    --junitxml=test-results/junit.xml
markers =
    slow: marks tests as slow
    integration: marks tests as integration tests
```

2. **Test Helper Scripts**
Create `scripts/run_tests.sh`:
```bash
#!/bin/bash

# Function to run tests with different configurations
run_test_suite() {
    local test_type=$1
    shift
    
    case $test_type in
        "unit")
            pytest tests/unit "$@"
            ;;
        "integration")
            pytest tests/integration "$@"
            ;;
        "all")
            pytest tests "$@"
            ;;
        *)
            echo "Unknown test type: $test_type"
            exit 1
            ;;
    esac
}

# Parse command line arguments
TEST_TYPE=${1:-"all"}
shift || true

# Run tests
run_test_suite "$TEST_TYPE" "$@"
```

## Deployment Automation

### Deployment Scripts

1. **Docker Deployment**
Create `scripts/deploy_docker.sh`:
```bash
#!/bin/bash

# Configuration
IMAGE_NAME="aider/aider"
CONTAINER_NAME="aider-instance"
CONFIG_DIR="$HOME/.aider"

# Function to check prerequisites
check_prereqs() {
    command -v docker >/dev/null 2>&1 || { 
        echo "Docker is required but not installed."
        exit 1
    }
}

# Function to deploy container
deploy_container() {
    local version=$1
    
    # Pull image
    docker pull "$IMAGE_NAME:$version"
    
    # Stop and remove existing container
    docker stop "$CONTAINER_NAME" 2>/dev/null || true
    docker rm "$CONTAINER_NAME" 2>/dev/null || true
    
    # Run new container
    docker run -d \
        --name "$CONTAINER_NAME" \
        -v "$CONFIG_DIR:/root/.aider" \
        -e OPENAI_API_KEY="$OPENAI_API_KEY" \
        "$IMAGE_NAME:$version"
}

# Main execution
main() {
    local version=${1:-"latest"}
    
    check_prereqs
    deploy_container "$version"
    
    echo "Deployment complete. Container ID:"
    docker ps -q -f name="$CONTAINER_NAME"
}

main "$@"
```

2. **Version Management**
Create `scripts/version_manager.sh`:
```bash
#!/bin/bash

# Configuration
PACKAGE_NAME="aider-chat"
VENV_DIR="venv"

# Function to get current version
get_current_version() {
    pip show "$PACKAGE_NAME" | grep Version | cut -d' ' -f2
}

# Function to update to specific version
update_version() {
    local target_version=$1
    
    # Activate virtual environment
    source "$VENV_DIR/bin/activate"
    
    # Install specific version
    pip install "$PACKAGE_NAME==$target_version"
}

# Function to list available versions
list_versions() {
    pip index versions "$PACKAGE_NAME"
}

# Main execution
main() {
    case $1 in
        "current")
            get_current_version
            ;;
        "list")
            list_versions
            ;;
        "update")
            if [ -z "$2" ]; then
                echo "Version required for update"
                exit 1
            fi
            update_version "$2"
            ;;
        *)
            echo "Usage: $0 {current|list|update VERSION}"
            exit 1
            ;;
    esac
}

main "$@"
```

These automation scripts and configurations provide a robust foundation for continuous integration, testing, and deployment workflows. They can be customized based on specific project needs and requirements.

