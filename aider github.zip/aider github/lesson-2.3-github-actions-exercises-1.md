# Practical Exercise Set 1: Implementing Test Workflows

## Exercise Overview

This set of practical exercises will guide you through implementing and customizing GitHub Actions test workflows similar to those used in the Aider project. You'll gain hands-on experience with workflow configuration, matrix testing, and path filtering.

## Exercise 1: Basic Test Workflow Implementation

### Objective
Create a basic GitHub Actions workflow that runs Python tests on Ubuntu.

### Step-by-Step Instructions

1. First, create the following directory structure in your repository:
```
my-project/
├── .github/
│   └── workflows/
│       └── basic-tests.yml
├── tests/
│   ├── __init__.py
│   └── test_example.py
└── src/
    ├── __init__.py
    └── example.py
```

2. Create a sample Python module to test. In src/example.py:
```python
class Calculator:
    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b

    def multiply(self, a, b):
        return a * b

    def divide(self, a, b):
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a / b
```

3. Create corresponding tests in tests/test_example.py:
```python
import pytest
from src.example import Calculator

def test_calculator_add():
    calc = Calculator()
    assert calc.add(2, 3) == 5
    assert calc.add(-1, 1) == 0
    assert calc.add(0, 0) == 0

def test_calculator_divide():
    calc = Calculator()
    assert calc.divide(6, 2) == 3
    with pytest.raises(ValueError):
        calc.divide(1, 0)
```

4. Implement the basic workflow in .github/workflows/basic-tests.yml:
```yaml
name: Basic Python Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install pytest
      - name: Run tests
        run: |
          pytest tests/

```

### Tasks

1. Implement the above structure in a test repository
2. Add the workflow file and commit it
3. Push to GitHub and verify the workflow runs
4. Check the Actions tab to see the test results

### Advanced Challenges

1. Add test coverage reporting:
   - Install and configure pytest-cov
   - Add coverage report to the workflow output
   - Set minimum coverage requirements

2. Implement test artifacts:
   - Configure the workflow to save test results as artifacts
   - Add a step to upload coverage reports

## Exercise 2: Matrix Testing Implementation

### Objective
Extend the basic workflow to test across multiple Python versions using matrix testing.

### Implementation Steps

1. Modify the workflow file to use matrix testing:
```yaml
name: Matrix Python Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.9', '3.10', '3.11', '3.12']
        
    steps:
      - uses: actions/checkout@v4
      - name: Set up Python ${{ matrix.python-version }}
        uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install pytest
      - name: Run tests
        run: |
          python -m pytest tests/
```

2. Add version-specific tests to test_example.py:
```python
import sys
import pytest

@pytest.mark.skipif(sys.version_info < (3, 11), reason="Requires Python 3.11+")
def test_modern_feature():
    # Test something that requires Python 3.11+
    pass
```

### Tasks

1. Implement the matrix testing workflow
2. Add version-specific test cases
3. Verify tests run correctly across all Python versions
4. Review the matrix build results in GitHub Actions

### Advanced Challenges

1. Add Conditional Testing:
   - Configure specific tests to run only on certain Python versions
   - Add environment-specific dependencies
   - Implement version-specific test skipping

2. Optimize Matrix Execution:
   - Add fail-fast configuration
   - Implement test result caching
   - Add parallel job execution limits

## Exercise 3: Path Filtering Implementation

### Objective
Implement smart path filtering to optimize when tests run.

### Implementation Steps

1. Create a documentation directory structure:
```
my-project/
├── .github/
│   └── workflows/
│       └── filtered-tests.yml
├── docs/
│   ├── user-guide.md
│   └── api-reference.md
└── src/
    └── ...
```

2. Implement path filtering in the workflow:
```yaml
name: Filtered Python Tests
on:
  push:
    paths-ignore:
      - 'docs/**'
      - '**.md'
      - 'LICENSE'
    branches:
      - main
  pull_request:
    paths-ignore:
      - 'docs/**'
      - '**.md'
      - 'LICENSE'
    branches:
      - main

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install pytest
      - name: Run tests
        run: |
          pytest tests/
```

### Tasks

1. Implement the filtered workflow
2. Test by making documentation-only changes
3. Verify tests don't run for doc changes
4. Test with code changes to verify tests do run

### Advanced Challenges

1. Implement Complex Filtering:
   - Add multiple path patterns
   - Configure branch-specific filters
   - Add tag-based filtering

2. Add Conditional Execution:
   - Implement different test sets based on changed files
   - Add manual workflow dispatch with parameters
   - Configure scheduled test runs

## Submission and Verification

For each exercise:
1. Push your changes to a public GitHub repository
2. Verify all workflows run successfully
3. Document any issues encountered and their solutions
4. Create a summary of the implemented features
5. Share the repository URL for review

## Assessment Criteria

Your implementations will be evaluated on:
1. Correct workflow configuration
2. Effective use of GitHub Actions features
3. Proper implementation of testing patterns
4. Code organization and documentation
5. Successful execution of all tests
