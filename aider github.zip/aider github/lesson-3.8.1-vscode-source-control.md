# VS Code Source Control Integration Guide for Aider

## Source Control Configuration

### Git Integration Settings

1. **VS Code Git Settings**
Add to `.vscode/settings.json`:
```json
{
    "git.enableSmartCommit": true,
    "git.autofetch": true,
    "git.confirmSync": false,
    "git.autoStash": true,
    "git.branchPrefix": "aider/",
    "git.defaultBranchName": "main",
    "git.showActionButton": {
        "commit": true,
        "publish": true,
        "sync": true
    },
    "git.inputValidation": "always",
    "git.inputValidationSubjectLength": 50,
    "git.inputValidationLength": 100,
    "gitlens.hovers.currentLine.over": "line",
    "gitlens.currentLine.enabled": true,
    "gitlens.statusBar.enabled": true,
    "gitlens.codeLens.enabled": true
}
```

### Custom SCM Providers

1. **Aider-Specific SCM Configuration**
Create `.vscode/scm.json`:
```json
{
    "customScmProviders": {
        "aider": {
            "label": "Aider Changes",
            "id": "aider",
            "contextValue": "aiderScm"
        }
    },
    "scmGroups": {
        "aider": {
            "hideWhenEmpty": true
        },
        "working": {
            "label": "Working Tree"
        },
        "staged": {
            "label": "Staged Changes"
        }
    }
}
```

## Source Control Views

### Custom Source Control Views

1. **SCM View Configuration**
Create `.vscode/scm-view.json`:
```json
{
    "contributes": {
        "views": {
            "scm": [
                {
                    "id": "aiderChanges",
                    "name": "Aider Changes",
                    "when": "workspaceHasGit"
                },
                {
                    "id": "aiderHistory",
                    "name": "Aider Chat History",
                    "when": "workspaceHasGit"
                }
            ]
        }
    }
}
```

### Custom View Commands

1. **View Commands Configuration**
Add to `package.json`:
```json
{
    "contributes": {
        "commands": [
            {
                "command": "aider.stageChange",
                "title": "Stage Aider Change",
                "category": "Aider"
            },
            {
                "command": "aider.unstageChange",
                "title": "Unstage Aider Change",
                "category": "Aider"
            },
            {
                "command": "aider.discardChange",
                "title": "Discard Aider Change",
                "category": "Aider"
            }
        ],
        "menus": {
            "scm/title": [
                {
                    "command": "aider.stageAll",
                    "group": "navigation",
                    "when": "scmProvider == git"
                }
            ],
            "scm/resourceState/context": [
                {
                    "command": "aider.stageChange",
                    "when": "scmProvider == git && scmResourceGroup == aider",
                    "group": "inline"
                }
            ]
        }
    }
}
```

## Commit Templates

### Aider-Specific Commit Templates

1. **Commit Message Template**
Create `.vscode/commit-templates.json`:
```json
{
    "commitTemplates": {
        "aiderFix": {
            "prefix": "fix(aider):",
            "description": "Fix implemented by Aider",
            "body": [
                "fix(aider): ${1:description}",
                "",
                "Problem:",
                "- ${2:problem description}",
                "",
                "Solution:",
                "- ${3:solution description}",
                "",
                "Chat: ${4:chat history reference}"
            ]
        },
        "aiderFeature": {
            "prefix": "feat(aider):",
            "description": "New feature implemented by Aider",
            "body": [
                "feat(aider): ${1:description}",
                "",
                "Details:",
                "- ${2:feature details}",
                "",
                "Chat: ${3:chat history reference}"
            ]
        },
        "aiderRefactor": {
            "prefix": "refactor(aider):",
            "description": "Code refactoring by Aider",
            "body": [
                "refactor(aider): ${1:description}",
                "",
                "Changes:",
                "- ${2:change details}",
                "",
                "Chat: ${3:chat history reference}"
            ]
        }
    }
}
```

## Branch Management

### Branch Configuration

1. **Branch Naming Configuration**
Create `.vscode/branch-config.json`:
```json
{
    "branchNaming": {
        "patterns": {
            "feature": "feature/aider/${1:feature-name}",
            "bugfix": "bugfix/aider/${1:bug-description}",
            "refactor": "refactor/aider/${1:refactor-description}"
        },
        "forbidden": [
            "master",
            "main",
            "develop"
        ],
        "prefixes": {
            "feature": "feature/aider/",
            "bugfix": "bugfix/aider/",
            "refactor": "refactor/aider/"
        }
    }
}
```

### Branch Commands

1. **Branch Management Commands**
Add to `.vscode/tasks.json`:
```json
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "Create Aider Feature Branch",
            "type": "shell",
            "command": "git checkout -b feature/aider/${input:featureName}",
            "problemMatcher": []
        },
        {
            "label": "Create Aider Bugfix Branch",
            "type": "shell",
            "command": "git checkout -b bugfix/aider/${input:bugName}",
            "problemMatcher": []
        },
        {
            "inputs": [
                {
                    "id": "featureName",
                    "description": "Feature name:",
                    "default": "",
                    "type": "promptString"
                },
                {
                    "id": "bugName",
                    "description": "Bug name:",
                    "default": "",
                    "type": "promptString"
                }
            ]
        }
    ]
}
```

## Change Review Integration

### Review Features

1. **Review Configuration**
Add to `.vscode/settings.json`:
```json
{
    "workbench.editorAssociations": {
        "*.aider.diff": "default"
    },
    "diffEditor.ignoreTrimWhitespace": true,
    "diffEditor.renderSideBySide": true,
    "diffEditor.maxComputationTime": 0,
    "scm.alwaysShowActions": true,
    "scm.diffDecorations": "all",
    "scm.diffDecorationsGutterWidth": 2,
    "scm.diffDecorationsGutterVisibility": "always"
}
```

### Review Commands

1. **Review Command Configuration**
Add to `package.json`:
```json
{
    "contributes": {
        "commands": [
            {
                "command": "aider.reviewChanges",
                "title": "Review Aider Changes",
                "category": "Aider"
            },
            {
                "command": "aider.acceptChange",
                "title": "Accept Aider Change",
                "category": "Aider"
            },
            {
                "command": "aider.rejectChange",
                "title": "Reject Aider Change",
                "category": "Aider"
            }
        ],
        "menus": {
            "editor/title": [
                {
                    "command": "aider.reviewChanges",
                    "when": "resourceExtname == .py",
                    "group": "navigation"
                }
            ]
        }
    }
}
```

## Status Bar Integration

### Status Bar Items

1. **Status Bar Configuration**
Add to `package.json`:
```json
{
    "contributes": {
        "statusBarItems": [
            {
                "id": "aiderStatus",
                "alignment": "left",
                "priority": 100,
                "name": "Aider Status",
                "command": "aider.showStatus"
            },
            {
                "id": "aiderBranch",
                "alignment": "left",
                "priority": 90,
                "name": "Aider Branch",
                "command": "aider.showBranchInfo"
            }
        ]
    }
}
```

These configurations provide comprehensive source control integration for Aider in VS Code, including custom commit templates, branch management, review features, and status bar integration. Users can adapt these settings based on their specific workflow needs.

