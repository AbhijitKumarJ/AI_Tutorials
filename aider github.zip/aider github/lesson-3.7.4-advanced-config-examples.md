# Advanced Configuration Examples for End Users

## Custom Configuration Profiles

### Multiple Environment Configurations

1. **Base Configuration**
Create `~/.aider/config/base.yml`:
```yaml
# Base configuration settings
model: gpt-4-0125-preview
edit_format: whole
auto_commits: true
git_messaging: true

# Common paths and settings
chat_history_file: ~/.aider/chat_history.md
input_history_file: ~/.aider/input_history.txt
local_file_pattern: "*.{py,md,txt,yml,yaml,json,html,css,js}"

# Default behavior settings
pretty: true
auto_save: true
add_to_git: true
```

2. **Environment-Specific Configurations**
Create development config `~/.aider/config/development.yml`:
```yaml
# Development environment settings
includes:
  - base.yml

model: gpt-3.5-turbo-0125
temperature: 0.7
max_tokens: 4000
stream: true

# Development-specific settings
auto_commits: false
verbose: true
dirty_commits: true
message_prefix: "dev: "

# Additional tools
use_git: true
git_autocommit: false
git_local_only: true

# Debugging
debug: true
log_level: DEBUG
log_file: ~/.aider/dev_debug.log
```

Create production config `~/.aider/config/production.yml`:
```yaml
# Production environment settings
includes:
  - base.yml

model: gpt-4-0125-preview
temperature: 0.2
max_tokens: 8000
stream: false

# Production-specific settings
auto_commits: true
verbose: false
dirty_commits: false
message_prefix: "prod: "

# Security settings
require_git_clean: true
git_autocommit: true
git_local_only: false

# Logging
debug: false
log_level: INFO
log_file: ~/.aider/prod.log
```

3. **Profile Selection Script**
Create `~/.aider/select_profile.sh`:
```bash
#!/bin/bash

# Configuration profile selector
CONFIG_DIR="$HOME/.aider/config"
CURRENT_LINK="$CONFIG_DIR/current"

select_profile() {
    local profile=$1
    local profile_path="$CONFIG_DIR/$profile.yml"
    
    if [ ! -f "$profile_path" ]; then
        echo "Profile '$profile' not found"
        exit 1
    }
    
    ln -sf "$profile_path" "$CURRENT_LINK"
    echo "Switched to profile: $profile"
}

# Usage
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <profile_name>"
    echo "Available profiles:"
    ls -1 "$CONFIG_DIR" | grep '\.yml$' | sed 's/\.yml$//'
    exit 1
fi

select_profile "$1"
```

## Advanced Model Configurations

### Multi-Model Setup

1. **Model Configuration File**
Create `~/.aider/models.yml`:
```yaml
models:
  gpt4_precise:
    name: gpt-4-0125-preview
    temperature: 0.1
    max_tokens: 8000
    top_p: 0.9
    presence_penalty: 0.1
    frequency_penalty: 0.1
    context_window: 128000
    edit_format: whole
    specific_settings:
      require_git_clean: true
      auto_commits: true
  
  gpt4_creative:
    name: gpt-4-0125-preview
    temperature: 0.7
    max_tokens: 4000
    top_p: 0.95
    presence_penalty: 0.2
    frequency_penalty: 0.2
    context_window: 128000
    edit_format: whole
    specific_settings:
      require_git_clean: false
      auto_commits: false
  
  gpt35_fast:
    name: gpt-3.5-turbo-0125
    temperature: 0.3
    max_tokens: 4000
    top_p: 0.9
    presence_penalty: 0
    frequency_penalty: 0
    context_window: 16000
    edit_format: whole
    specific_settings:
      require_git_clean: false
      auto_commits: true

  claude_precise:
    name: claude-3-opus-20240229
    temperature: 0.1
    max_tokens: 4000
    top_p: 0.9
    edit_format: whole
    specific_settings:
      require_git_clean: true
      auto_commits: true
```

2. **Model Selection Script**
Create `~/.aider/select_model.sh`:
```bash
#!/bin/bash

# Model configuration selector
MODELS_FILE="$HOME/.aider/models.yml"
CURRENT_MODEL="$HOME/.aider/current_model"

select_model() {
    local model=$1
    
    # Verify model exists in config
    if ! yq e ".models.$model" "$MODELS_FILE" > /dev/null 2>&1; then
        echo "Model '$model' not found in configuration"
        exit 1
    }
    
    # Extract and save model configuration
    yq e ".models.$model" "$MODELS_FILE" > "$CURRENT_MODEL"
    echo "Switched to model: $model"
    
    # Apply model-specific settings
    apply_model_settings "$model"
}

apply_model_settings() {
    local model=$1
    local settings_file="$HOME/.aider/settings.yml"
    
    # Extract model-specific settings
    yq e ".models.$model.specific_settings" "$MODELS_FILE" > "$settings_file"
    echo "Applied settings for model: $model"
}

# Usage
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <model_name>"
    echo "Available models:"
    yq e '.models | keys' "$MODELS_FILE"
    exit 1
fi

select_model "$1"
```

## Project-Specific Configurations

### Multi-Project Setup

1. **Project Configuration Template**
Create `.aider-project-template.yml`:
```yaml
# Project configuration
name: "project-name"
description: "Project description"

# Version control settings
git:
  commit_message_prefix: ""
  branches:
    main: main
    development: dev
    feature_prefix: feature/
    release_prefix: release/

# Editor settings
editor:
  line_length: 100
  indent_style: space
  indent_size: 4
  
# Linting and formatting
linting:
  enabled: true
  tools:
    - black
    - flake8
    - isort
  max_line_length: 100
  ignore_patterns:
    - "*.pyc"
    - "__pycache__"
    - ".git"

# Testing
testing:
  framework: pytest
  test_path: tests/
  markers:
    - unit
    - integration
    - slow

# Documentation
documentation:
  format: markdown
  paths:
    - docs/
    - README.md
  auto_generate: true

# Dependencies
dependencies:
  management: poetry
  development:
    - pytest
    - black
    - flake8
  production:
    - requests
    - pyyaml

# Workflows
workflows:
  continuous_integration:
    enabled: true
    triggers:
      - push
      - pull_request
    branches:
      - main
      - dev
  
  deployment:
    enabled: true
    environments:
      - staging
      - production
    require_approval: true
```

2. **Project Initialization Script**
Create `~/.aider/init_project.sh`:
```bash
#!/bin/bash

# Project initialization script
TEMPLATE_FILE="$HOME/.aider/templates/project-template.yml"

init_project() {
    local project_name=$1
    local project_dir=$2
    
    # Create project directory
    mkdir -p "$project_dir"
    cd "$project_dir" || exit 1
    
    # Initialize git repository
    git init
    
    # Copy and customize template
    cp "$TEMPLATE_FILE" ".aider.yml"
    sed -i "s/project-name/$project_name/g" ".aider.yml"
    
    # Create project structure
    mkdir -p {src,tests,docs}
    
    # Initialize Python project
    poetry init \
        --name "$project_name" \
        --description "A new project" \
        --author "$(git config user.name) <$(git config user.email)>" \
        --python "^3.9" \
        --dependency "requests" \
        --dependency "pyyaml" \
        --dev-dependency "pytest" \
        --dev-dependency "black" \
        --dev-dependency "flake8" \
        --no-interaction
    
    # Create initial files
    echo "# $project_name" > README.md
    touch src/__init__.py
    touch tests/__init__.py
    
    # Initialize git
    git add .
    git commit -m "Initial commit"
}

# Usage
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <project_name> <project_directory>"
    exit 1
fi

init_project "$1" "$2"
```

## Advanced Git Integration

### Custom Git Hooks

1. **Pre-Commit Hook**
Create `.git/hooks/pre-commit`:
```bash
#!/bin/bash

# Configuration
PYTHON_FILES=$(git diff --cached --name-only --diff-filter=ACM | grep '\.py$')
CONFIG_FILE=".aider.yml"

# Load configuration
if [ -f "$CONFIG_FILE" ]; then
    MAX_LINE_LENGTH=$(yq e '.linting.max_line_length' "$CONFIG_FILE")
else
    MAX_LINE_LENGTH=100
fi

# Run checks on staged Python files
for file in $PYTHON_FILES; do
    # Run black
    poetry run black --check --quiet --line-length "$MAX_LINE_LENGTH" "$file" || {
        echo "Black check failed for $file"
        exit 1
    }
    
    # Run flake8
    poetry run flake8 --max-line-length "$MAX_LINE_LENGTH" "$file" || {
        echo "Flake8 check failed for $file"
        exit 1
    }
    
    # Run tests related to changed files
    related_test="tests/$(basename "$file" .py)_test.py"
    if [ -f "$related_test" ]; then
        poetry run pytest "$related_test" -v || {
            echo "Tests failed for $file"
            exit 1
        }
    fi
done
```

These advanced configurations provide extensive customization options for different environments, models, and project requirements. Users can adapt these templates to their specific needs while maintaining consistent coding standards and workflows.

