# Lesson 2 Part A: Understanding Test Workflow Configuration

## Introduction to GitHub Actions Testing in Aider

In this comprehensive lesson, we'll explore how Aider implements automated testing using GitHub Actions, focusing specifically on the Ubuntu testing workflow. We'll examine the structure, components, and best practices employed in the project's continuous integration pipeline.

## Repository Structure

The GitHub Actions workflow files in Aider are organized as follows:

```
.github/
└── workflows/
    ├── docker-build-test.yml
    ├── docker-release.yml
    ├── pages.yml
    ├── release.yml
    ├── ubuntu-tests.yml
    └── windows-tests.yml
```

## Deep Dive: Ubuntu Tests Configuration

Let's examine the ubuntu-tests.yml file in detail, breaking down each section to understand its purpose and implementation.

### Workflow Triggers

```yaml
name: Ubuntu Python Tests
on:
  push:
    paths-ignore:
      - 'aider/website/**'
      - README.md
      - HISTORY.md
    branches:
      - main
  pull_request:
    paths-ignore:
      - 'aider/website/**'
      - README.md
    branches:
      - main
```

This configuration sets up automated testing that triggers under two specific circumstances:

1. Push Events:
   The workflow activates when code is pushed directly to the main branch. However, it implements intelligent path filtering through paths-ignore. This means changes to the website content or documentation won't trigger unnecessary test runs, saving computational resources and CI minutes. The specific paths ignored are:
   - The entire website directory (aider/website/**)
   - The main README.md file
   - The HISTORY.md changelog file

2. Pull Request Events:
   Tests also run when pull requests are opened or updated against the main branch. Similar path ignoring rules apply, ensuring that documentation-only changes don't trigger the test suite.

### Matrix Testing Strategy

```yaml
jobs:
  build:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.9", "3.10", "3.11", "3.12"]
```

The matrix testing configuration is a powerful feature that enables parallel testing across multiple Python versions. Let's understand why each version is included:

- Python 3.9: Represents the minimum supported version in Aider
- Python 3.10: A widely adopted production version
- Python 3.11: Current stable release with performance improvements
- Python 3.12: Latest Python version, ensuring forward compatibility

This matrix approach provides several benefits:
1. Early Detection: Compatibility issues with specific Python versions are caught immediately
2. Parallel Execution: Tests run simultaneously across all versions, reducing total CI time
3. Comprehensive Coverage: Ensures Aider works consistently across different Python environments

### Test Environment Setup

```yaml
    steps:
    - name: Check out repository
      uses: actions/checkout@v4

    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v5
      with:
        python-version: ${{ matrix.python-version }}

    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install pytest
        pip install .
```

The test environment setup follows a carefully ordered sequence:

1. Repository Checkout:
   Uses actions/checkout@v4 to clone the repository, ensuring access to the latest code.

2. Python Installation:
   The actions/setup-python action configures the specified Python version from the matrix.

3. Dependency Installation:
   - Updates pip to the latest version
   - Installs pytest for running the test suite
   - Installs Aider itself in development mode

### Test Execution

```yaml
    - name: Run tests
      run: |
        pytest
```

The actual test execution is straightforward but powerful. pytest automatically discovers and runs all tests in the specified directories (defined in pytest.ini):

```ini
[pytest]
testpaths =
    tests/basic
    tests/help
    tests/browser
    tests/scrape
```

## Usage and Implementation

To effectively use and maintain this testing infrastructure:

1. Local Testing:
   Before pushing changes, developers should run the same tests locally:
   ```bash
   python -m pytest
   ```

2. Adding New Tests:
   Place new test files in the appropriate directory under tests/:
   - basic/ for core functionality tests
   - help/ for documentation tests
   - browser/ for web interface tests
   - scrape/ for web scraping tests

3. Path Ignore Updates:
   When adding new documentation or website files, update the paths-ignore section to prevent unnecessary test runs:
   ```yaml
   paths-ignore:
      - 'aider/website/**'
      - 'new-docs-directory/**'
   ```

4. Matrix Updates:
   When dropping support for older Python versions or adding new ones, modify the matrix configuration:
   ```yaml
   python-version: ["3.10", "3.11", "3.12", "3.13"]  # Example future update
   ```