# Practical Exercise Set 2: Cross-Platform Testing Implementation

## Exercise Overview

This set of exercises focuses on implementing and managing cross-platform testing workflows using GitHub Actions. You'll learn how to handle platform-specific challenges and ensure your code works consistently across different operating systems.

## Exercise 1: Cross-Platform Test Environment Setup

### Objective
Create a test workflow that runs on multiple operating systems while handling platform-specific requirements.

### Setup Instructions

1. Create the following project structure:
```
cross-platform-project/
├── .github/
│   └── workflows/
│       └── cross-platform-tests.yml
├── src/
│   ├── __init__.py
│   ├── file_handler.py
│   └── path_utils.py
└── tests/
    ├── __init__.py
    ├── test_file_handler.py
    └── test_path_utils.py
```

2. Implement platform-aware file handling in src/file_handler.py:
```python
import os
from pathlib import Path
import platform
import tempfile

class FileHandler:
    def __init__(self):
        self.system = platform.system()
        
    def get_temp_dir(self):
        """Create a temporary directory in the platform-appropriate location"""
        if self.system == 'Windows':
            base_dir = os.environ.get('TEMP', os.path.expanduser('~\\AppData\\Local\\Temp'))
        else:
            base_dir = '/tmp'
        return Path(tempfile.mkdtemp(dir=base_dir))
    
    def create_file(self, directory, filename, content):
        """Create a file with proper line endings for the current platform"""
        file_path = Path(directory) / filename
        # Use proper line endings for the platform
        content = content.replace('\n', os.linesep)
        file_path.write_text(content, encoding='utf-8')
        return file_path
    
    def set_executable(self, file_path):
        """Set executable permissions in a platform-appropriate way"""
        file_path = Path(file_path)
        if self.system != 'Windows':
            current = file_path.stat().st_mode
            file_path.chmod(current | 0o111)
```

3. Implement the cross-platform test workflow in .github/workflows/cross-platform-tests.yml:
```yaml
name: Cross-Platform Tests
on: [push, pull_request]

jobs:
  test:
    strategy:
      matrix:
        os: [ubuntu-latest, windows-latest, macos-latest]
        python-version: ['3.11']
    runs-on: ${{ matrix.os }}
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Python ${{ matrix.python-version }}
        uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
          
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install pytest
          
      - name: Run tests
        run: |
          pytest tests/ -v
```

4. Create platform-aware tests in tests/test_file_handler.py:
```python
import os
import platform
import pytest
from src.file_handler import FileHandler

def test_temp_dir_creation():
    handler = FileHandler()
    temp_dir = handler.get_temp_dir()
    
    try:
        assert temp_dir.exists()
        if platform.system() == 'Windows':
            assert 'Temp' in str(temp_dir)
        else:
            assert '/tmp' in str(temp_dir)
    finally:
        # Clean up
        temp_dir.rmdir()

def test_file_creation():
    handler = FileHandler()
    temp_dir = handler.get_temp_dir()
    
    try:
        test_content = "Line 1\nLine 2\nLine 3"
        file_path = handler.create_file(temp_dir, "test.txt", test_content)
        
        assert file_path.exists()
        content = file_path.read_text(encoding='utf-8')
        expected_content = test_content.replace('\n', os.linesep)
        assert content == expected_content
    finally:
        # Clean up
        file_path.unlink()
        temp_dir.rmdir()

@pytest.mark.skipif(
    platform.system() == 'Windows',
    reason="Executable permissions not applicable on Windows"
)
def test_executable_permissions():
    handler = FileHandler()
    temp_dir = handler.get_temp_dir()
    
    try:
        file_path = handler.create_file(temp_dir, "script.sh", "#!/bin/sh\necho 'Hello'")
        handler.set_executable(file_path)
        
        assert os.access(file_path, os.X_OK)
    finally:
        # Clean up
        file_path.unlink()
        temp_dir.rmdir()
```

### Tasks

1. Implement the provided code structure
2. Add the workflow file and commit changes
3. Push to GitHub and verify the workflow runs on all platforms
4. Review test results for each operating system

### Advanced Challenges

1. Add Platform-Specific Error Handling:
   - Implement different error handling strategies per platform
   - Add platform-specific recovery mechanisms
   - Test error conditions on each platform

2. Implement Path Manipulation Tests:
   - Add tests for path normalization
   - Handle symlinks across platforms
   - Test path length limitations

## Exercise 2: Platform-Specific Dependencies

### Objective
Create a workflow that handles different dependencies and configurations based on the operating system.

### Implementation Steps

1. Create a requirements structure:
```
cross-platform-project/
├── requirements/
│   ├── requirements-base.txt
│   ├── requirements-windows.txt
│   ├── requirements-linux.txt
│   └── requirements-macos.txt
└── .github/
    └── workflows/
        └── platform-deps-tests.yml
```

2. Implement platform-specific requirements:

requirements-base.txt:
```
pytest>=7.0.0
requests>=2.28.0
```

requirements-windows.txt:
```
pywin32>=305
```

requirements-linux.txt:
```
python-systemd>=0.0.9
```

3. Create the workflow file:
```yaml
name: Platform-Specific Dependencies
on: [push, pull_request]

jobs:
  test:
    strategy:
      matrix:
        os: [ubuntu-latest, windows-latest, macos-latest]
        python-version: ['3.11']
        
    runs-on: ${{ matrix.os }}
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
          
      - name: Install base dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements/requirements-base.txt
          
      - name: Install Windows dependencies
        if: matrix.os == 'windows-latest'
        run: |
          pip install -r requirements/requirements-windows.txt
          
      - name: Install Linux dependencies
        if: matrix.os == 'ubuntu-latest'
        run: |
          pip install -r requirements/requirements-linux.txt
          
      - name: Run tests
        run: |
          python -m pytest tests/ -v
```

### Tasks

1. Implement the requirements structure
2. Create platform-specific test cases
3. Verify dependency installation
4. Test platform-specific features

### Advanced Challenges

1. Add Conditional Feature Testing:
   - Implement feature detection
   - Add platform-specific test skipping
   - Handle optional dependencies

2. Optimize Dependency Installation:
   - Implement dependency caching
   - Add parallel dependency installation
   - Handle conflicting dependencies

## Exercise 3: Cross-Platform Command Execution

### Objective
Implement safe command execution across different platforms.

### Implementation Steps

1. Create a command execution module:
```python
# src/command_runner.py
import subprocess
import platform
import shlex

class CommandRunner:
    def __init__(self):
        self.is_windows = platform.system() == 'Windows'
    
    def run_command(self, command, shell=False):
        """Run a command safely on any platform"""
        if isinstance(command, str) and not shell:
            if self.is_windows:
                command = command.replace('/', '\\')
            else:
                command = shlex.split(command)
                
        result = subprocess.run(
            command,
            shell=shell,
            text=True,
            capture_output=True,
            encoding='utf-8'
        )
        return result
    
    def list_directory(self):
        """List directory contents using platform-appropriate command"""
        command = 'dir' if self.is_windows else 'ls'
        return self.run_command(command, shell=True)
```

2. Create corresponding tests:
```python
# tests/test_command_runner.py
import pytest
from src.command_runner import CommandRunner

def test_directory_listing():
    runner = CommandRunner()
    result = runner.list_directory()
    assert result.returncode == 0
    assert len(result.stdout) > 0

def test_command_execution():
    runner = CommandRunner()
    if runner.is_windows:
        command = 'echo Hello'
    else:
        command = ['echo', 'Hello']
    
    result = runner.run_command(command)
    assert result.returncode == 0
    assert 'Hello' in result.stdout
```

### Tasks

1. Implement the command execution module
2. Create platform-specific test cases
3. Verify command execution on all platforms
4. Handle command failures appropriately

### Advanced Challenges

1. Add Process Management:
   - Implement process timeout handling
   - Add signal handling
   - Handle subprocess environment variables

2. Implement Command Queueing:
   - Add command chain execution
   - Implement rollback mechanisms
   - Handle interdependent commands

## Submission and Verification

For each exercise:
1. Push your implementation to GitHub
2. Verify workflows run successfully on all platforms
3. Document platform-specific issues encountered
4. Create a testing report showing cross-platform results
5. Share repository URL for review

## Assessment Criteria

Your implementation will be evaluated on:
1. Cross-platform compatibility
2. Proper handling of platform differences
3. Effective error handling
4. Test coverage across platforms
5. Code organization and documentation
