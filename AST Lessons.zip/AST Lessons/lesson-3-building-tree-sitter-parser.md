# Lesson 3: Building a Simple Parser with Tree-sitter

## Objective
By the end of this lesson, students will be able to set up a Tree-sitter project, implement a grammar, generate and compile the parser, and use it in a Python project.

## 1. Setting up a Tree-sitter Project

### Project Structure
```
tree-sitter-math-python/
│
├── tree-sitter-math/
│   ├── grammar.js
│   ├── src/
│   │   └── parser.c
│   ├── binding.gyp
│   └── package.json
│
├── main.py
└── requirements.txt
```

### Dependencies
In `requirements.txt`:
```
tree-sitter
```

Install the dependencies:
```
pip install -r requirements.txt
```

## 2. Implementing the Grammar

We'll use the grammar from the previous lesson and extend it slightly.

In `tree-sitter-math/grammar.js`:

```javascript
module.exports = grammar({
  name: 'math',

  rules: {
    expression: $ => choice(
      $.number,
      $.variable,
      $.binary_expression,
      $.parenthesized_expression
    ),

    number: $ => /\d+/,

    variable: $ => /[a-zA-Z]+/,

    binary_expression: $ => prec.left(1, seq(
      field('left', $.expression),
      field('operator', choice('+', '-', '*', '/')),
      field('right', $.expression)
    )),

    parenthesized_expression: $ => seq(
      '(',
      $.expression,
      ')'
    )
  }
});
```

## 3. Generating and Compiling the Parser

### Using Tree-sitter CLI
In the `tree-sitter-math` directory, run:
```
tree-sitter generate
```

### Cross-platform Compilation Considerations
- On Unix-like systems (Linux, macOS):
  ```
  gcc -o parser.so -shared src/parser.c -I./src
  ```
- On Windows (with MSVC):
  ```
  cl /LD src/parser.c /I src
  ```

## 4. Using the Generated Parser in Python

Create `main.py`:

```python
from tree_sitter import Language, Parser

def build_tree_sitter_math():
    Language.build_library(
        # Store the library in the `build` directory
        'build/my-languages.so',
        # Include one or more languages
        [
            'tree-sitter-math'
        ]
    )

def main():
    build_tree_sitter_math()
    MATH_LANGUAGE = Language('build/my-languages.so', 'math')
    parser = Parser()
    parser.set_language(MATH_LANGUAGE)

    code = "2 + 3 * (4 - x)"
    tree = parser.parse(bytes(code, "utf8"))

    print(f"AST for expression: {code}")
    print(tree.root_node.sexp())

    # Traverse the AST
    cursor = tree.walk()

    def traverse(cursor):
        yield cursor.node

        if cursor.goto_first_child():
            yield from traverse(cursor)
            while cursor.goto_next_sibling():
                yield from traverse(cursor)

        cursor.goto_parent()

    print("\nTraversing the AST:")
    for node in traverse(cursor):
        print(f"Node type: {node.type}, Text: {node.text.decode('utf8')}")

if __name__ == "__main__":
    main()
```

## Running the Example

Run the script:
```
python main.py
```

Expected output:
```
AST for expression: 2 + 3 * (4 - x)
(expression (binary_expression (number) (binary_expression (number) (parenthesized_expression (expression (binary_expression (number) (variable)))))))

Traversing the AST:
Node type: expression, Text: 2 + 3 * (4 - x)
Node type: binary_expression, Text: 2 + 3 * (4 - x)
Node type: number, Text: 2
Node type: +, Text: +
Node type: binary_expression, Text: 3 * (4 - x)
Node type: number, Text: 3
Node type: *, Text: *
Node type: parenthesized_expression, Text: (4 - x)
Node type: expression, Text: 4 - x
Node type: binary_expression, Text: 4 - x
Node type: number, Text: 4
Node type: -, Text: -
Node type: variable, Text: x
```

## Exercise

1. Modify the grammar to support floating-point numbers.
2. Add support for exponentiation (e.g., 2^3) in the grammar and parser.
3. Implement a function to evaluate the expression by traversing the AST.

## Conclusion

In this lesson, we've built a simple parser using Tree-sitter and integrated it into a Python project. We've seen how to generate the parser from a grammar, compile it for different platforms, and use it to parse and analyze mathematical expressions. This forms the foundation for more advanced code analysis and manipulation techniques that we'll explore in the upcoming lessons.

