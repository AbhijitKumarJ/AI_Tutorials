# Lesson 2: Understanding Tree-sitter

## Objective
By the end of this lesson, students will understand what Tree-sitter is, its advantages over traditional parsers, and how to write a simple Tree-sitter grammar.

## 1. Introduction to Tree-sitter

### What is Tree-sitter?
Tree-sitter is a parser generator tool and an incremental parsing library. It can build a concrete syntax tree for a source file and efficiently update the syntax tree as the source file is edited.

### Advantages over Traditional Parsers
- Incremental: Can update the AST efficiently when small changes are made to the input
- Error-tolerant: Produces a valid tree even if the input has syntax errors
- Language-agnostic: Can be used to parse any programming language
- Fast: Capable of parsing on every keystroke in a text editor

## 2. Tree-sitter Architecture

### Grammar Definition
- Written in JavaScript
- Defines the structure of the language

### Parser Generation
- Converts the grammar into C code
- Creates a parser specific to the defined language

### Runtime Parsing
- Uses the generated parser to create and update syntax trees

## 3. Writing a Simple Tree-sitter Grammar

Let's create a grammar for a basic arithmetic expression language.

### Project Structure
```
tree-sitter-math/
│
├── grammar.js
├── src/
│   └── parser.c
├── binding.gyp
└── package.json
```

### Step 1: Define the Grammar

In `grammar.js`:

```javascript
module.exports = grammar({
  name: 'math',

  rules: {
    expression: $ => choice(
      $.number,
      $.binary_expression
    ),

    number: $ => /\d+/,

    binary_expression: $ => prec.left(1, seq(
      field('left', $.expression),
      field('operator', choice('+', '-', '*', '/')),
      field('right', $.expression)
    ))
  }
});
```

### Explanation of the Grammar
- `expression`: The main rule, can be either a number or a binary expression
- `number`: Matches one or more digits
- `binary_expression`: Represents operations, with left-associativity

### Step 2: Generate the Parser

To generate the parser, you need to install Tree-sitter CLI:

```
npm install -g tree-sitter-cli
```

Then, in the `tree-sitter-math` directory, run:

```
tree-sitter generate
```

This will create the necessary C files in the `src` directory.

## 4. Cross-platform Considerations

### Supported Languages and Platforms
- Tree-sitter can be used with many programming languages
- Works on major operating systems (Windows, macOS, Linux)

### Compilation and Distribution
- Compilation process may vary slightly between platforms
- Use appropriate build tools for each platform (e.g., gcc on Unix, MSVC on Windows)

## Exercise

1. Extend the grammar to include parenthesized expressions.
2. Add support for variable names in the grammar.
3. Generate the parser with your modified grammar and examine the generated C code.

## Conclusion

In this lesson, we've introduced Tree-sitter, a powerful and flexible parsing tool. We've learned about its architecture and how to write a simple grammar. Tree-sitter's incremental parsing and error tolerance make it an excellent choice for applications like code editors and analysis tools.

In the next lesson, we'll dive deeper into building and using a Tree-sitter parser in a Python project.

