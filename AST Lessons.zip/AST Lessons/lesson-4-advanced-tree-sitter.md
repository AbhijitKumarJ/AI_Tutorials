# Lesson 4: Advanced Tree-sitter Techniques and Cross-platform Considerations

## Objective
By the end of this lesson, students will understand advanced Tree-sitter techniques such as querying the AST, incremental parsing, and error recovery. They will also learn about cross-platform challenges and solutions when working with Tree-sitter.

## 1. Querying the AST

Tree-sitter provides a powerful query language to extract specific information from the AST.

### Writing and Executing Queries

Let's extend our previous example to include queries:

```python
from tree_sitter import Language, Parser

def build_tree_sitter_math():
    Language.build_library(
        'build/my-languages.so',
        ['tree-sitter-math']
    )

def main():
    build_tree_sitter_math()
    MATH_LANGUAGE = Language('build/my-languages.so', 'math')
    parser = Parser()
    parser.set_language(MATH_LANGUAGE)

    code = "2 + 3 * (4 - x) + y"
    tree = parser.parse(bytes(code, "utf8"))

    print(f"AST for expression: {code}")
    print(tree.root_node.sexp())

    # Query for variables
    query = MATH_LANGUAGE.query("""
    (variable) @var
    """)

    captures = query.captures(tree.root_node)
    print("\nVariables found:")
    for capture in captures:
        print(capture[0].text.decode('utf8'))

    # Query for binary expressions with multiplication
    query = MATH_LANGUAGE.query("""
    (binary_expression
      left: (_) @left
      operator: "*"
      right: (_) @right)
    """)

    captures = query.captures(tree.root_node)
    print("\nMultiplication expressions:")
    for i in range(0, len(captures), 2):
        left = captures[i][0].text.decode('utf8')
        right = captures[i+1][0].text.decode('utf8')
        print(f"{left} * {right}")

if __name__ == "__main__":
    main()
```

This example demonstrates how to write and execute queries to extract specific information from the AST.

## 2. Incremental Parsing

Tree-sitter supports incremental parsing, which allows efficient updates to the AST when small changes are made to the input.

```python
def demonstrate_incremental_parsing(parser, code):
    print("\nDemonstrating incremental parsing:")
    
    # Initial parse
    tree = parser.parse(bytes(code, "utf8"))
    print("Initial AST:")
    print(tree.root_node.sexp())

    # Make a small change
    new_code = code.replace("3", "5")
    new_tree = parser.parse(bytes(new_code, "utf8"), tree)
    
    print("\nAST after changing 3 to 5:")
    print(new_tree.root_node.sexp())

    # Check if the trees are different objects
    print(f"\nAre the trees different objects? {tree is not new_tree}")

# Add this to the main function
demonstrate_incremental_parsing(parser, code)
```

This example shows how Tree-sitter efficiently updates the AST when a small change is made to the input.

## 3. Error Recovery and Fault Tolerance

Tree-sitter can handle syntax errors gracefully and still produce a usable AST.

```python
def demonstrate_error_recovery(parser):
    print("\nDemonstrating error recovery:")
    
    code_with_error = "2 + * 4"
    tree = parser.parse(bytes(code_with_error, "utf8"))
    
    print(f"AST for expression with error: {code_with_error}")
    print(tree.root_node.sexp())
    
    print("\nTraversing the AST with error:")
    cursor = tree.walk()
    
    def traverse(cursor):
        node = cursor.node
        if node.has_error:
            print(f"Error at node: {node.type}")
        
        if cursor.goto_first_child():
            traverse(cursor)
            while cursor.goto_next_sibling():
                traverse(cursor)
        
        cursor.goto_parent()
    
    traverse(cursor)

# Add this to the main function
demonstrate_error_recovery(parser)
```

This example shows how Tree-sitter handles syntax errors and still produces a usable AST.

## 4. Cross-platform Challenges and Solutions

When working with Tree-sitter across different platforms, you may encounter several challenges:

1. Compilation differences
2. Path handling
3. Dynamic library loading

### Compilation Differences

To handle compilation differences, you can use conditional compilation in your build scripts:

```python
import platform

def compile_parser():
    system = platform.system()
    if system == "Windows":
        # Windows-specific compilation command
        os.system("cl /LD src/parser.c /I src")
    elif system == "Darwin":
        # macOS-specific compilation command
        os.system("gcc -dynamiclib -o libtreesitter-math.dylib src/parser.c -I./src")
    else:
        # Linux and other Unix-like systems
        os.system("gcc -shared -o libtreesitter-math.so src/parser.c -I./src")
```

### Path Handling

Use `os.path` for cross-platform path handling:

```python
import os

def get_parser_library_path():
    system = platform.system()
    if system == "Windows":
        return os.path.join("build", "treesitter-math.dll")
    elif system == "Darwin":
        return os.path.join("build", "libtreesitter-math.dylib")
    else:
        return os.path.join("build", "libtreesitter-math.so")

# Use in main function
parser_path = get_parser_library_path()
MATH_LANGUAGE = Language(parser_path, 'math')
```

### Dynamic Library Loading

Tree-sitter handles dynamic library loading internally, but you may need to ensure that the library is in the correct location or added to the system's library search path.

## Exercise

1. Modify the grammar to support unary minus (e.g., -5).
2. Write a query to find all negative numbers in an expression.
3. Implement error recovery for mismatched parentheses.

## Conclusion

In this lesson, we've explored advanced Tree-sitter techniques including AST querying, incremental parsing, and error recovery. We've also discussed cross-platform considerations when working with Tree-sitter. These techniques form the foundation for building sophisticated code analysis and manipulation tools that work across different operating systems.

