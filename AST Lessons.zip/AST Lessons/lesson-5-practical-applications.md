# Lesson 5: Practical Applications of ASTs and Tree-sitter in Real-world Projects

## Objective
By the end of this lesson, students will understand how to apply ASTs and Tree-sitter in practical scenarios such as code analysis, syntax highlighting, and simple refactoring.

## 1. Code Analysis and Linting

Let's create a simple code analyzer for our math language that identifies potential issues and suggests improvements.

```python
from tree_sitter import Language, Parser

class MathAnalyzer:
    def __init__(self):
        Language.build_library(
            'build/my-languages.so',
            ['tree-sitter-math']
        )
        self.MATH_LANGUAGE = Language('build/my-languages.so', 'math')
        self.parser = Parser()
        self.parser.set_language(self.MATH_LANGUAGE)

    def analyze(self, code):
        tree = self.parser.parse(bytes(code, "utf8"))
        issues = []

        # Check for division by zero
        query = self.MATH_LANGUAGE.query("""
        (binary_expression
          left: (_)
          operator: "/"
          right: (number) @divisor
        )
        """)

        captures = query.captures(tree.root_node)
        for capture in captures:
            if capture[0].text == b"0":
                issues.append(f"Potential division by zero at position {capture[0].start_point}")

        # Check for unused variables
        defined_vars = set()
        used_vars = set()

        var_query = self.MATH_LANGUAGE.query("""
        (variable) @var
        """)

        var_captures = var_query.captures(tree.root_node)
        for capture in var_captures:
            var_name = capture[0].text.decode('utf8')
            if capture[0].parent.type == 'expression' and capture[0].parent.children[0] == capture[0]:
                defined_vars.add(var_name)
            else:
                used_vars.add(var_name)

        unused_vars = defined_vars - used_vars
        for var in unused_vars:
            issues.append(f"Unused variable: {var}")

        return issues

def main():
    analyzer = MathAnalyzer()
    
    code_samples = [
        "x = 10 / 0",
        "y = 5\nz = x + 2"
    ]

    for i, code in enumerate(code_samples, 1):
        print(f"\nAnalyzing code sample {i}:")
        print(code)
        print("\nIssues found:")
        issues = analyzer.analyze(code)
        for issue in issues:
            print(f"- {issue}")

if __name__ == "__main__":
    main()
```

This example demonstrates how to use Tree-sitter for code analysis, identifying potential issues like division by zero and unused variables.

## 2. Syntax Highlighting

While full syntax highlighting typically requires integration with text editors, we can demonstrate a simple console-based syntax highlighting:

```python
from tree_sitter import Language, Parser
from colorama import Fore, Back, Style, init

init(autoreset=True)

class MathHighlighter:
    def __init__(self):
        Language.build_library(
            'build/my-languages.so',
            ['tree-sitter-math']
        )
        self.MATH_LANGUAGE = Language('build/my-languages.so', 'math')
        self.parser = Parser()
        self.parser.set_language(self.MATH_LANGUAGE)

    def highlight(self, code):
        tree = self.parser.parse(bytes(code, "utf8"))
        highlighted = list(code)

        def apply_highlight(node):
            start, end = node.start_byte, node.end_byte
            if node.type == 'number':
                highlighted[start:end] = [Fore.BLUE + c + Fore.RESET for c in highlighted[start:end]]
            elif node.type == 'variable':
                highlighted[start:end] = [Fore.GREEN + c + Fore.RESET for c in highlighted[start:end]]
            elif node.type in ['+', '-', '*', '/']:
                highlighted[start:end] = [Fore.RED + c + Fore.RESET for c in highlighted[start:end]]
            
            for child in node.children:
                apply_highlight(child)

        apply_highlight(tree.root_node)
        return ''.join(highlighted)

def main():
    highlighter = MathHighlighter()
    
    code_samples = [
        "2 + 3 * (4 - x)",
        "y = 10 / (z + 5)"
    ]

    for i, code in enumerate(code_samples, 1):
        print(f"\nHighlighting code sample {i}:")
        print(highlighter.highlight(code))

if __name__ == "__main__":
    main()
```

This example shows how to use Tree-sitter to implement basic syntax highlighting.

## 3. Simple Refactoring

Let's implement a simple refactoring tool that renames variables:

```python
from tree_sitter import Language, Parser

class MathRefactor:
    def __init__(self):
        Language.build_library(
            'build/my-languages.so',
            ['tree-sitter-math']
        )
        self.MATH_LANGUAGE = Language('build/my-languages.so', 'math')
        self.parser = Parser()
        self.parser.set_language(self.MATH_LANGUAGE)

    def rename_variable(self, code, old_name, new_name):
        tree = self.parser.parse(bytes(code, "utf8"))
        
        query = self.MATH_LANGUAGE.query("""
        (variable) @var
        """)

        captures = query.captures(tree.root_node)
        replacements = []

        for capture in captures:
            if capture[0].text.decode('utf8') == old_name:
                replacements.append((capture[0].start_byte, capture[0].end_byte, new_name))

        replacements.sort(reverse=True)
        new_code = list(code)

        for start, end, replacement in replacements:
            new_code[start:end] = replacement

        return ''.join(new_code)

def main():
    refactor = MathRefactor()
    
    code = "x = 5\ny = x + 3\nz = x * y"
    print("Original code:")
    print(code)

    new_code = refactor.rename_variable(code, 'x', 'num')
    print("\nAfter renaming 'x' to 'num':")
    print(new_code)

if __name__ == "__main__":
    main()
```

This example demonstrates how to use Tree-sitter for a simple refactoring task: renaming variables.

## 4. Integration with Development Tools

While full integration with IDEs is beyond the scope of this lesson, here are some ideas for how Tree-sitter can be used in development tools:

1. Code completion: Use AST analysis to suggest context-aware completions.
2. Error detection: Identify syntax errors and logical issues in real-time.
3. Code navigation: Jump to definitions or find references using AST queries.
4. Code folding: Use the AST structure to determine foldable regions of code.

## Exercise

1. Extend the MathAnalyzer to check for complex expressions that could be simplified.
2. Implement a function to extract all mathematical operations from an expression and list them in order.
3. Create a simple "prettifier" that formats the math expressions with consistent spacing.

## Conclusion

In this lesson, we've explored practical applications of ASTs and Tree-sitter in real-world scenarios. We've seen how these tools can be used for code analysis, syntax highlighting, and simple refactoring tasks. These examples demonstrate the power and flexibility of Tree-sitter in working with code structure, opening up possibilities for more advanced code manipulation and analysis tools.

As you continue to work with Tree-sitter, you'll find that it's a powerful tool for building sophisticated development tools and language-aware applications. Its cross-platform nature and support for incremental parsing make it particularly well-suited for real-time code analysis and manipulation tasks.

