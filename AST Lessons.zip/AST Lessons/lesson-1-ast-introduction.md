# Lesson 1: Introduction to Abstract Syntax Trees (ASTs)

## Objective
By the end of this lesson, students will understand what Abstract Syntax Trees (ASTs) are, their importance in programming, and how to create a simple AST for basic arithmetic expressions.

## 1. What are Abstract Syntax Trees?

### Definition
An Abstract Syntax Tree (AST) is a tree representation of the abstract syntactic structure of source code written in a programming language. Each node of the tree denotes a construct occurring in the source code.

### Purpose
ASTs are used to:
- Represent the structure of program code
- Facilitate code analysis and manipulation
- Aid in the compilation process

### Comparison with Parse Trees
While both represent the structure of code, ASTs are more compact:
- Parse trees represent every detail from the grammar
- ASTs eliminate syntactic details and focus on the structure

## 2. Basic Structure of ASTs

### Components
- Nodes: Represent constructs in the code (e.g., operations, variables)
- Edges: Connect nodes, showing relationships

### Types of Nodes
- Root: The topmost node of the tree
- Parent: A node with child nodes
- Child: A node connected to another node when moving away from the root
- Leaf: A node without any children

## 3. Importance of ASTs in Programming

ASTs are crucial in various programming tasks:
- Code Analysis: Understand structure and flow
- Compilation: Transform code into machine instructions
- Refactoring: Restructure code while preserving functionality
- Syntax Highlighting: Improve code readability in editors

## 4. Creating a Simple AST

Let's create an AST for the expression: 2 + 3 * 4

### Project Structure
```
ast_example/
│
├── ast_node.py
└── main.py
```

### Step 1: Define the ASTNode class

In `ast_node.py`:

```python
class ASTNode:
    def __init__(self, type, value=None, left=None, right=None):
        self.type = type
        self.value = value
        self.left = left
        self.right = right

def create_ast(expression):
    tokens = expression.split()
    stack = []
    
    for token in tokens:
        if token in ['+', '-', '*', '/']:
            right = stack.pop()
            left = stack.pop()
            node = ASTNode(token, left=left, right=right)
            stack.append(node)
        else:
            stack.append(ASTNode('number', value=int(token)))
    
    return stack[0]

def print_ast(node, level=0):
    if node is None:
        return
    
    print('  ' * level + f"{node.type}: {node.value if node.value is not None else ''}")
    print_ast(node.left, level + 1)
    print_ast(node.right, level + 1)
```

### Step 2: Use the AST in main.py

In `main.py`:

```python
from ast_node import create_ast, print_ast

def main():
    expression = "2 + 3 * 4"
    ast = create_ast(expression)
    print(f"AST for expression: {expression}")
    print_ast(ast)

if __name__ == "__main__":
    main()
```

### Step 3: Run the Example

Run `main.py` to see the AST:

```
AST for expression: 2 + 3 * 4
+: 
  number: 2
  *: 
    number: 3
    number: 4
```

## Exercise

1. Modify the `create_ast` function to handle parentheses in expressions.
2. Create an AST for the expression: (2 + 3) * 4
3. Implement a function to evaluate the AST and compute the result of the expression.

## Conclusion

In this lesson, we've learned about Abstract Syntax Trees, their structure, importance, and how to create a simple AST for arithmetic expressions. ASTs are fundamental in many areas of programming and form the basis for more advanced code analysis and manipulation techniques.

