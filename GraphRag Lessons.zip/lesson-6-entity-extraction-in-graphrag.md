# Lesson 6: Entity Extraction in GraphRAG

## Table of Contents
1. [Introduction](#introduction)
2. [Understanding Entity Extraction](#understanding-entity-extraction)
3. [NLTK-based Entity Extraction](#nltk-based-extraction)
4. [Graph Intelligence-based Entity Extraction](#graph-intelligence-extraction)
5. [Customizing Entity Extraction Strategies](#customizing-strategies)
6. [Handling Different Entity Types](#handling-entity-types)
7. [Practical Example](#practical-example)
8. [Conclusion and Next Steps](#conclusion)

<a name="introduction"></a>
## 1. Introduction

Welcome to Lesson 6 of our GraphRAG series. In this lesson, we'll dive deep into entity extraction, a crucial component of the GraphRAG system. Entity extraction is the process of identifying and classifying key information (entities) from unstructured text. This process is fundamental to building the knowledge graph that powers GraphRAG's advanced querying capabilities.

By the end of this lesson, you'll understand different entity extraction methods, how to implement them in GraphRAG, and how to customize the extraction process for your specific needs.

<a name="understanding-entity-extraction"></a>
## 2. Understanding Entity Extraction

Entity extraction, also known as Named Entity Recognition (NER), is a subtask of information extraction that seeks to locate and classify named entities in text into predefined categories such as person names, organizations, locations, medical codes, time expressions, quantities, monetary values, percentages, etc.

In the context of GraphRAG, entity extraction serves several purposes:
1. Identifying key concepts in the input text
2. Providing structure to unstructured data
3. Enabling the creation of a knowledge graph
4. Facilitating more accurate and context-aware queries

GraphRAG provides two main approaches to entity extraction:
1. NLTK-based extraction
2. Graph Intelligence-based extraction (using LLMs)

Let's explore each of these methods in detail.

<a name="nltk-based-extraction"></a>
## 3. NLTK-based Entity Extraction

NLTK (Natural Language Toolkit) is a leading platform for building Python programs to work with human language data. GraphRAG leverages NLTK's capabilities to provide a fast and reliable entity extraction method.

### 3.1 How NLTK-based Extraction Works

NLTK uses pre-trained models and rule-based systems to identify entities. The process typically involves:
1. Tokenization: Breaking the text into individual words or tokens
2. Part-of-speech tagging: Assigning grammatical categories to each token
3. Chunking: Grouping adjacent tokens into named entities

### 3.2 Configuring NLTK-based Extraction in GraphRAG

To use NLTK-based entity extraction in GraphRAG, you can specify it in your pipeline configuration:

```yaml
workflows:
  - name: entity_extraction
    config:
      entity_extract:
        strategy:
          type: nltk
```

### 3.3 Advantages and Limitations

Advantages:
- Fast processing
- No need for external API calls
- Works well for common entity types

Limitations:
- Less flexible for custom entity types
- May miss context-dependent entities
- Lower accuracy compared to advanced LLM-based methods

<a name="graph-intelligence-extraction"></a>
## 4. Graph Intelligence-based Entity Extraction

Graph Intelligence-based extraction in GraphRAG uses advanced Language Models (LLMs) to perform entity extraction. This method provides more flexibility and can often capture more nuanced entities.

### 4.1 How Graph Intelligence-based Extraction Works

This method leverages the power of large language models to understand context and extract entities. The process typically involves:
1. Sending the text to the LLM with a prompt asking to identify entities
2. Parsing the LLM's response to extract the identified entities
3. Optionally, using multiple passes or "gleanings" to refine the extraction

### 4.2 Configuring Graph Intelligence-based Extraction in GraphRAG

To use Graph Intelligence-based entity extraction, you can specify it in your pipeline configuration:

```yaml
workflows:
  - name: entity_extraction
    config:
      entity_extract:
        strategy:
          type: graph_intelligence
          llm:
            type: openai_chat
            api_key: ${OPENAI_API_KEY}
            model: gpt-3.5-turbo
            max_tokens: 2500
            temperature: 0
```

### 4.3 Advantages and Limitations

Advantages:
- Higher accuracy, especially for complex or domain-specific texts
- Ability to identify context-dependent entities
- Flexibility to extract custom entity types

Limitations:
- Slower than NLTK-based extraction
- Requires API calls to external LLM services
- May be more expensive due to API usage

<a name="customizing-strategies"></a>
## 5. Customizing Entity Extraction Strategies

GraphRAG allows you to customize the entity extraction process to fit your specific needs. This can involve modifying existing strategies or creating entirely new ones.

### 5.1 Customizing NLTK-based Extraction

You can customize NLTK-based extraction by modifying the underlying NLTK models or rules. This typically involves extending the `NLTKExtractor` class:

```python
from graphrag.index.graph.extractors.nltk import NLTKExtractor
import nltk

class CustomNLTKExtractor(NLTKExtractor):
    def __init__(self, config):
        super().__init__(config)
        # Add custom initialization if needed

    async def extract(self, text):
        # Implement custom extraction logic
        tokens = nltk.word_tokenize(text)
        tagged = nltk.pos_tag(tokens)
        entities = nltk.chunk.ne_chunk(tagged)
        # Process entities and return in the expected format
        return self.format_entities(entities)

    def format_entities(self, nltk_entities):
        # Convert NLTK entities to the format expected by GraphRAG
        # ...
```

### 5.2 Customizing Graph Intelligence-based Extraction

For Graph Intelligence-based extraction, you can customize the prompts sent to the LLM or modify how the responses are processed. This involves extending the `GraphIntelligenceExtractor` class:

```python
from graphrag.index.graph.extractors.graph_intelligence import GraphIntelligenceExtractor

class CustomGraphIntelligenceExtractor(GraphIntelligenceExtractor):
    def __init__(self, config):
        super().__init__(config)
        # Add custom initialization if needed

    async def extract(self, text):
        # Customize the prompt or extraction process
        custom_prompt = f"Extract entities from the following text, focusing on [YOUR CUSTOM REQUIREMENTS]: {text}"
        response = await self.llm.acomplete(custom_prompt)
        # Process the response and return entities in the expected format
        return self.parse_response(response)

    def parse_response(self, response):
        # Implement custom parsing of the LLM response
        # ...
```

### 5.3 Registering Custom Extractors

To use your custom extractor, you need to register it with GraphRAG:

```python
from graphrag.index import run_pipeline

custom_extractors = {
    "custom_nltk": CustomNLTKExtractor,
    "custom_graph_intelligence": CustomGraphIntelligenceExtractor
}

async for output in run_pipeline(
    config_or_path="your_config.yml",
    additional_extractors=custom_extractors
):
    # Process output
```

Then, in your configuration file, you can specify your custom extractor:

```yaml
workflows:
  - name: entity_extraction
    config:
      entity_extract:
        strategy:
          type: custom_nltk  # or custom_graph_intelligence
```

<a name="handling-entity-types"></a>
## 6. Handling Different Entity Types

GraphRAG supports various entity types out of the box, but you may need to work with custom entity types or modify how existing types are handled.

### 6.1 Default Entity Types

By default, GraphRAG recognizes the following entity types:
- Person
- Organization
- Location
- Date
- Time
- Money
- Percent
- Facility
- GPE (Geo-Political Entity)

### 6.2 Specifying Custom Entity Types

You can specify custom entity types in your configuration:

```yaml
workflows:
  - name: entity_extraction
    config:
      entity_extract:
        strategy:
          type: graph_intelligence
          entity_types:
            - Product
            - Technology
            - Scientific_Concept
```

### 6.3 Handling Entity Types in Custom Extractors

When creating custom extractors, you'll need to ensure that your extractor can handle the specified entity types. For NLTK-based extractors, this might involve training custom models. For Graph Intelligence-based extractors, you'll need to modify the prompts and response parsing to accommodate the new entity types.

<a name="practical-example"></a>
## 7. Practical Example

Let's put all these concepts together in a practical example. We'll create a pipeline that extracts entities from a dataset of scientific abstracts, using both NLTK and Graph Intelligence methods, and then compares the results.

First, let's look at the file structure:

```
project_root/
├── data/
│   └── scientific_abstracts.csv
├── config/
│   └── pipeline.yml
├── custom_extractors.py
└── run_pipeline.py
```

Now, let's create the `pipeline.yml` configuration:

```yaml
input:
  type: file
  file_type: csv
  base_dir: "./data"
  file_pattern: "scientific_abstracts\\.csv$"
  text_column: "abstract"

workflows:
  - name: nltk_extraction
    config:
      entity_extract:
        strategy:
          type: nltk

  - name: graph_intelligence_extraction
    config:
      entity_extract:
        strategy:
          type: graph_intelligence
          llm:
            type: openai_chat
            api_key: ${OPENAI_API_KEY}
            model: gpt-3.5-turbo
            max_tokens: 2500
            temperature: 0
          entity_types:
            - Person
            - Organization
            - Scientific_Concept
            - Technology

  - name: comparison
    steps:
      - verb: custom.compare_extractions
        args:
          nltk_source: "workflow:nltk_extraction"
          graph_intelligence_source: "workflow:graph_intelligence_extraction"
```

Next, let's create the `custom_extractors.py` file:

```python
from graphrag.index.graph.extractors.nltk import NLTKExtractor
from graphrag.index.graph.extractors.graph_intelligence import GraphIntelligenceExtractor

class CustomNLTKExtractor(NLTKExtractor):
    async def extract(self, text):
        entities = await super().extract(text)
        # Add custom post-processing if needed
        return entities

class CustomGraphIntelligenceExtractor(GraphIntelligenceExtractor):
    async def extract(self, text):
        prompt = f"""
        Extract entities from the following scientific abstract. Focus on Person, Organization, Scientific_Concept, and Technology entities.
        
        Abstract: {text}
        
        Format the output as a JSON list of objects, each with 'name', 'type', and 'description' fields.
        """
        response = await self.llm.acomplete(prompt)
        return self.parse_response(response)

    def parse_response(self, response):
        # Implement custom parsing of the LLM response
        # ...
```

Finally, let's create the `run_pipeline.py` script:

```python
import asyncio
from graphrag.index import run_pipeline_with_config
from custom_extractors import CustomNLTKExtractor, CustomGraphIntelligenceExtractor

def compare_extractions(df, nltk_df, graph_intelligence_df):
    # Implement comparison logic
    # ...
    return comparison_results

custom_verbs = {
    "compare_extractions": compare_extractions
}

custom_extractors = {
    "custom_nltk": CustomNLTKExtractor,
    "custom_graph_intelligence": CustomGraphIntelligenceExtractor
}

async def main():
    async for result in run_pipeline_with_config(
        config_or_path="./config/pipeline.yml",
        additional_verbs=custom_verbs,
        additional_extractors=custom_extractors
    ):
        print(f"Completed workflow: {result.workflow}")
        if result.workflow == "comparison":
            print("Extraction comparison results:")
            print(result.result)

if __name__ == "__main__":
    asyncio.run(main())
```

This example demonstrates:
- Using both NLTK and Graph Intelligence-based entity extraction
- Customizing extractors for specific needs
- Handling custom entity types
- Comparing results from different extraction methods

<a name="conclusion"></a>
## 8. Conclusion and Next Steps

In this lesson, we've covered the fundamentals of entity extraction in GraphRAG, including:
- Understanding the importance of entity extraction in building knowledge graphs
- Implementing NLTK-based and Graph Intelligence-based extraction methods
- Customizing extraction strategies for specific needs
- Handling different entity types
- Creating a practical pipeline that compares different extraction methods

Entity extraction is a crucial step in transforming unstructured text into structured, queryable knowledge. The flexibility of GraphRAG allows you to fine-tune this process to best suit your specific use case.

To reinforce your learning, try to:
1. Experiment with different entity types and extraction strategies on your own datasets
2. Implement a custom extractor that uses a different NLP library or LLM service
3. Analyze the performance and accuracy of different extraction methods on various types of text

In the next lesson, we'll explore graph processing techniques in GraphRAG, including clustering, embedding, and layout algorithms. These techniques will help you make the most of the entities and relationships extracted from your data.

Remember, effective entity extraction is key to building a rich and useful knowledge graph. Continue to experiment and refine your extraction strategies as you work with different types of data and use cases.

