dag = DAG(
    'graphrag_pipeline',
    default_args=default_args,
    description='A GraphRAG pipeline DAG',
    schedule_interval=timedelta(days=1),
)

def run_graphrag_pipeline(**kwargs):
    config = kwargs['dag_run'].conf.get('config', {})
    return run_pipeline(config)

graphrag_task = PythonOperator(
    task_id='run_graphrag_pipeline',
    python_callable=run_graphrag_pipeline,
    provide_context=True,
    dag=dag,
)
```

## 6. Hands-on Project: Building a Production-Ready GraphRAG Application

Let's put everything we've learned into practice by building a production-ready GraphRAG application for a real-world scenario: A News Article Recommendation System.

### Project Overview

We'll create a system that ingests news articles, builds a knowledge graph, and provides personalized article recommendations based on user interests.

### Project Structure

```
news_recommender/
│
├── data/
│   └── articles.csv
│
├── src/
│   ├── __init__.py
│   ├── config.py
│   ├── data_loader.py
│   ├── preprocessor.py
│   ├── entity_extractor.py
│   ├── graph_builder.py
│   ├── embedder.py
│   ├── recommender.py
│   └── main.py
│
├── tests/
│   ├── __init__.py
│   ├── test_data_loader.py
│   ├── test_preprocessor.py
│   ├── test_entity_extractor.py
│   ├── test_graph_builder.py
│   ├── test_embedder.py
│   └── test_recommender.py
│
├── Dockerfile
├── requirements.txt
├── README.md
└── .env
```

### Implementation

Let's go through each component of our news recommendation system:

#### 1. Configuration (config.py)

```python
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    DATA_PATH = os.getenv("DATA_PATH", "data/articles.csv")
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-ada-002")
    MAX_ARTICLES = int(os.getenv("MAX_ARTICLES", 1000))
    CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", 500))
    OVERLAP = int(os.getenv("OVERLAP", 50))
```

#### 2. Data Loader (data_loader.py)

```python
import pandas as pd
from src.config import Config

def load_articles():
    df = pd.read_csv(Config.DATA_PATH)
    return df.head(Config.MAX_ARTICLES)
```

#### 3. Preprocessor (preprocessor.py)

```python
import nltk
from nltk.tokenize import sent_tokenize
nltk.download('punkt')

def preprocess_text(text):
    sentences = sent_tokenize(text)
    chunks = []
    current_chunk = ""
    
    for sentence in sentences:
        if len(current_chunk) + len(sentence) <= Config.CHUNK_SIZE:
            current_chunk += " " + sentence
        else:
            chunks.append(current_chunk.strip())
            current_chunk = sentence
    
    if current_chunk:
        chunks.append(current_chunk.strip())
    
    return chunks
```

#### 4. Entity Extractor (entity_extractor.py)

```python
import openai
from src.config import Config

openai.api_key = Config.OPENAI_API_KEY

def extract_entities(text):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant that extracts entities from text."},
            {"role": "user", "content": f"Extract key entities (people, organizations, locations) from the following text:\n\n{text}"}
        ]
    )
    return response.choices[0].message['content']
```

#### 5. Graph Builder (graph_builder.py)

```python
import networkx as nx

def build_graph(articles, entities):
    G = nx.Graph()
    
    for idx, (article, article_entities) in enumerate(zip(articles, entities)):
        article_node = f"Article_{idx}"
        G.add_node(article_node, type="article", title=article['title'])
        
        for entity in article_entities.split(','):
            entity = entity.strip()
            if entity:
                G.add_node(entity, type="entity")
                G.add_edge(article_node, entity)
    
    return G
```

#### 6. Embedder (embedder.py)

```python
import openai
import numpy as np
from src.config import Config

openai.api_key = Config.OPENAI_API_KEY

def get_embedding(text):
    response = openai.Embedding.create(input=text, model=Config.EMBEDDING_MODEL)
    return response['data'][0]['embedding']

def embed_graph(G):
    for node in G.nodes():
        if G.nodes[node]['type'] == 'article':
            text = G.nodes[node]['title']
        else:
            text = node
        G.nodes[node]['embedding'] = get_embedding(text)
    return G
```

#### 7. Recommender (recommender.py)

```python
import numpy as np

def cosine_similarity(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

def recommend_articles(G, user_interests, top_n=5):
    user_embedding = get_embedding(" ".join(user_interests))
    article_similarities = []
    
    for node in G.nodes():
        if G.nodes[node]['type'] == 'article':
            similarity = cosine_similarity(user_embedding, G.nodes[node]['embedding'])
            article_similarities.append((node, similarity))
    
    article_similarities.sort(key=lambda x: x[1], reverse=True)
    return [G.nodes[node]['title'] for node, _ in article_similarities[:top_n]]
```

#### 8. Main Application (main.py)

```python
from src.data_loader import load_articles
from src.preprocessor import preprocess_text
from src.entity_extractor import extract_entities
from src.graph_builder import build_graph
from src.embedder import embed_graph
from src.recommender import recommend_articles

def main():
    # Load and preprocess articles
    articles = load_articles()
    preprocessed_articles = [preprocess_text(article['content']) for _, article in articles.iterrows()]
    
    # Extract entities
    entities = [extract_entities(chunk[0]) for chunk in preprocessed_articles]
    
    # Build and embed graph
    G = build_graph(articles.to_dict('records'), entities)
    G = embed_graph(G)
    
    # Get user interests and recommend articles
    user_interests = input("Enter your interests (comma-separated): ").split(',')
    recommendations = recommend_articles(G, user_interests)
    
    print("Recommended articles:")
    for i, title in enumerate(recommendations, 1):
        print(f"{i}. {title}")

if __name__ == "__main__":
    main()
```

### Deployment

To deploy this application, we can use Docker for containerization:

```dockerfile
# Dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["python", "src/main.py"]
```

Build and run the Docker container:

```bash
docker build -t news-recommender .
docker run -it --env-file .env news-recommender
```

### Security Considerations

1. Use environment variables for sensitive information (API keys).
2. Implement rate limiting for the OpenAI API calls.
3. Validate and sanitize user inputs.
4. Use HTTPS for any web-based interfaces.

### Scalability Considerations

1. Use a distributed graph database (e.g., Neo4j) for larger datasets.
2. Implement caching for embeddings and frequently accessed data.
3. Use message queues for asynchronous processing of articles and recommendations.
4. Consider deploying the application on a scalable cloud platform (e.g., Kubernetes).

## Conclusion

In this lesson, we've covered best practices for designing and implementing GraphRAG pipelines, explored important security considerations, discussed cross-platform deployment strategies, examined real-world case studies, and learned how to integrate GraphRAG with existing systems. The hands-on project demonstrated how to apply these concepts to build a production-ready GraphRAG application.

As you continue to work with GraphRAG, remember to:

1. Design modular and configurable pipelines
2. Prioritize security in all aspects of your application
3. Choose appropriate deployment strategies based on your specific requirements
4. Learn from real-world case studies and adapt their solutions to your problems
5. Integrate GraphRAG seamlessly with your existing infrastructure

In the next lesson, we'll explore advanced topics and future directions in GraphRAG development.

