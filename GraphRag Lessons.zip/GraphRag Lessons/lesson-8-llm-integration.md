# Lesson 8: LLM Integration in GraphRAG

## Table of Contents
1. Introduction to Language Models (LLMs)
2. Integrating OpenAI models
3. Configuring Azure OpenAI
4. LLM caching and optimization strategies
5. Prompt engineering for GraphRAG
6. Hands-on Exercise
7. Recap and Next Steps

## 1. Introduction to Language Models (LLMs)

Language Models (LLMs) are sophisticated AI systems trained on vast amounts of text data to understand and generate human-like text. In the context of GraphRAG, LLMs play a crucial role in various tasks such as entity extraction, relationship identification, and query processing.

Key concepts:
- Tokenization: The process of breaking text into smaller units (tokens) for LLM processing.
- Embeddings: Dense vector representations of text that capture semantic meaning.
- Inference: The process of generating text or making predictions using a trained LLM.

## 2. Integrating OpenAI models

GraphRAG supports integration with OpenAI models, which are known for their powerful language understanding and generation capabilities. Let's explore how to set up and use OpenAI models within GraphRAG.

### File Layout

```
graphrag/
├── index/
│   ├── graph/
│   │   └── extractors/
│   │       └── graph/
│   │           ├── __init__.py
│   │           ├── prompts.py
│   │           └── strategy.py
├── query/
│   └── llm/
│       └── oai/
│           ├── __init__.py
│           ├── chat_openai.py
│           └── embedding.py
└── examples/
    └── entity_extraction/
        └── with_graph_intelligence/
            ├── pipeline.yml
            └── run.py
```

### Setting up OpenAI integration

1. Install the required dependencies:

```bash
pip install openai tiktoken
```

2. Set up your OpenAI API key:

```python
import os
os.environ["OPENAI_API_KEY"] = "your-api-key-here"
```

3. Configure GraphRAG to use OpenAI models:

```yaml
# pipeline.yml
workflows:
  - name: entity_extraction
    config:
      entity_extract:
        strategy:
          type: graph_intelligence
          llm:
            type: openai_chat
            api_key: ${OPENAI_API_KEY}
            model: gpt-3.5-turbo
            max_tokens: 2500
            temperature: 0
```

### Using OpenAI models in GraphRAG

GraphRAG uses OpenAI models for various tasks, including entity extraction. Here's an example of how it's implemented in the code:

```python
# graphrag/index/graph/extractors/graph/strategy.py

from graphrag.llm.oai import ChatOpenAI

class GraphIntelligenceStrategy(BaseEntityExtractionStrategy):
    def __init__(self, config: dict):
        self.llm = ChatOpenAI(**config.get("llm", {}))
    
    async def extract_entities(self, text: str) -> List[Entity]:
        # Implementation using self.llm for entity extraction
```

## 3. Configuring Azure OpenAI

For users who prefer or require Azure-hosted OpenAI services, GraphRAG also supports Azure OpenAI integration. Here's how to set it up:

1. Set up Azure OpenAI environment variables:

```bash
export AZURE_OPENAI_API_KEY="your-azure-api-key"
export AZURE_OPENAI_ENDPOINT="https://your-resource-name.openai.azure.com/"
```

2. Configure GraphRAG to use Azure OpenAI:

```yaml
# pipeline.yml
workflows:
  - name: entity_extraction
    config:
      entity_extract:
        strategy:
          type: graph_intelligence
          llm:
            type: azure_openai_chat
            api_key: ${AZURE_OPENAI_API_KEY}
            api_base: ${AZURE_OPENAI_ENDPOINT}
            api_version: "2023-05-15"
            deployment_name: "your-model-deployment-name"
```

## 4. LLM caching and optimization strategies

To improve performance and reduce API calls, GraphRAG implements LLM caching strategies. Let's explore how this works and how to configure it.

### LLM Caching

GraphRAG uses a caching mechanism to store and reuse LLM responses for identical inputs. This significantly reduces API calls and improves overall performance.

```python
# graphrag/index/cache.py

class LLMCache:
    def __init__(self, cache_type: str = "memory"):
        self.cache = self._get_cache(cache_type)

    async def get(self, key: str) -> Any:
        return await self.cache.get(key)

    async def set(self, key: str, value: Any) -> None:
        await self.cache.set(key, value)

# Usage in LLM calls
cache = LLMCache()
cached_response = await cache.get(input_key)
if cached_response is None:
    response = await llm.generate(input)
    await cache.set(input_key, response)
```

### Optimization Strategies

1. Batching: Group multiple inputs into a single API call to reduce overhead.
2. Streaming: For long-running tasks, use streaming to process partial results as they become available.
3. Model selection: Choose the appropriate model size based on the task complexity.

Configure these strategies in your `pipeline.yml`:

```yaml
workflows:
  - name: entity_extraction
    config:
      entity_extract:
        strategy:
          type: graph_intelligence
          llm:
            type: openai_chat
            model: gpt-3.5-turbo
            max_tokens: 2500
            temperature: 0
            batch_size: 10
            stream: true
```

## 5. Prompt engineering for GraphRAG

Effective prompt engineering is crucial for getting the best results from LLMs in GraphRAG. Let's explore some techniques and best practices.

### Prompt Template

GraphRAG uses prompt templates to structure inputs for LLMs. Here's an example from the entity extraction process:

```python
# graphrag/index/graph/extractors/graph/prompts.py

ENTITY_EXTRACTION_PROMPT = """
Analyze the following text and extract entities of the following types: {entity_types}.

For each entity, provide:
1. The entity name
2. The entity type
3. A brief description of the entity

Text to analyze:
{input_text}

Respond in the following format:
entity_name{tuple_delimiter}entity_type{tuple_delimiter}entity_description{record_delimiter}

{completion_delimiter}
"""
```

### Best Practices for Prompt Engineering in GraphRAG

1. Be specific: Clearly define the task and expected output format.
2. Provide examples: Include sample inputs and outputs in your prompts.
3. Use consistent formatting: Maintain a consistent structure across prompts.
4. Iterate and refine: Continuously improve prompts based on LLM outputs.

## 6. Hands-on Exercise

Let's create a simple GraphRAG pipeline that uses an LLM for entity extraction.

1. Create a new file `llm_entity_extraction.py`:

```python
import asyncio
import os
from graphrag.index import run_pipeline
from graphrag.index.config import PipelineWorkflowReference

os.environ["OPENAI_API_KEY"] = "your-api-key-here"

async def main():
    workflows = [
        PipelineWorkflowReference(
            name="entity_extraction",
            config={
                "entity_extract": {
                    "strategy": {
                        "type": "graph_intelligence",
                        "llm": {
                            "type": "openai_chat",
                            "model": "gpt-3.5-turbo",
                            "max_tokens": 2500,
                            "temperature": 0,
                        },
                    }
                }
            },
        ),
    ]

    sample_text = "Apple Inc. is a technology company founded by Steve Jobs and Steve Wozniak in Cupertino, California."
    
    tables = []
    async for table in run_pipeline(dataset=sample_text, workflows=workflows):
        tables.append(table)
    
    result = tables[-1]
    if result.result is not None:
        print("Extracted entities:", result.result["entities"].to_list())
    else:
        print("No results!")

if __name__ == "__main__":
    asyncio.run(main())
```

2. Run the script:

```bash
python llm_entity_extraction.py
```

This exercise demonstrates how to set up a simple GraphRAG pipeline that uses an LLM for entity extraction.

## 7. Recap and Next Steps

In this lesson, we covered:
- Introduction to Language Models (LLMs)
- Integrating OpenAI models with GraphRAG
- Configuring Azure OpenAI
- LLM caching and optimization strategies
- Prompt engineering techniques for GraphRAG

Next steps:
1. Experiment with different LLM models and configurations.
2. Implement custom prompt templates for specific use cases.
3. Explore advanced caching strategies for improved performance.
4. Investigate how LLMs are used in other parts of the GraphRAG pipeline, such as relationship extraction and query processing.

In the next lesson, we'll dive into custom verbs and workflows, learning how to extend GraphRAG's functionality with custom components.

