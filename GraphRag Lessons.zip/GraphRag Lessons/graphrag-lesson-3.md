# Lesson 3: Understanding GraphRAG Configuration

## Table of Contents
1. [Introduction to GraphRAG Configuration](#1-introduction-to-graphrag-configuration)
2. [Default Configuration Mode](#2-default-configuration-mode)
3. [Configuration Using Environment Variables](#3-configuration-using-environment-variables)
4. [Configuration Using JSON/YAML Files](#4-configuration-using-jsonyaml-files)
5. [Creating and Using .env Files](#5-creating-and-using-env-files)
6. [Understanding Config Sections](#6-understanding-config-sections)

## 1. Introduction to GraphRAG Configuration

Configuring GraphRAG properly is crucial for its effective operation. GraphRAG offers flexibility in how you can set up its various components, allowing you to tailor the system to your specific needs. In this lesson, we'll explore the different configuration methods and options available in GraphRAG.

## 2. Default Configuration Mode

The default configuration mode in GraphRAG is designed to work out-of-the-box with minimal setup. This mode is ideal for getting started quickly or for simple use cases.

### 2.1 How to Use Default Configuration

To use the default configuration, you don't need to specify any configuration files. Simply run GraphRAG without any config arguments:

```python
from graphrag.index import run_pipeline

async def main():
    async for output in run_pipeline(dataset=your_dataset):
        # Process output
        pass

# Run the main function
import asyncio
asyncio.run(main())
```

### 2.2 Default Settings

The default configuration includes sensible defaults for various components, such as:

- Input processing
- LLM settings
- Embedding configurations
- Caching strategies
- Storage options

While these defaults work for many scenarios, you may need to customize them for specific use cases or to optimize performance.

## 3. Configuration Using Environment Variables

GraphRAG allows you to configure many of its settings using environment variables. This method is particularly useful for keeping sensitive information (like API keys) out of your code and for configuring deployments across different environments.

### 3.1 Key Environment Variables

Here are some of the most important environment variables you can set:

```bash
# Base LLM Settings
GRAPHRAG_API_KEY="your_api_key"
GRAPHRAG_API_BASE="http://<domain>.openai.azure.com"  # For Azure OpenAI
GRAPHRAG_API_VERSION="2023-05-15"  # API version

# LLM Configuration
GRAPHRAG_LLM_TYPE="azure_openai_chat"  # or "openai_chat"
GRAPHRAG_LLM_DEPLOYMENT_NAME="gpt-4"
GRAPHRAG_LLM_MODEL="gpt-4"
GRAPHRAG_LLM_MAX_TOKENS=4000

# Embedding Configuration
GRAPHRAG_EMBEDDING_TYPE="azure_openai_embedding"  # or "openai_embedding"
GRAPHRAG_EMBEDDING_DEPLOYMENT_NAME="text-embedding-ada-002"
GRAPHRAG_EMBEDDING_MODEL="text-embedding-ada-002"

# Input Configuration
GRAPHRAG_INPUT_TYPE="file"  # or "blob"
GRAPHRAG_INPUT_FILE_TYPE="csv"  # or "text"
GRAPHRAG_INPUT_FILE_PATTERN=".*\.csv$"

# Chunking Configuration
GRAPHRAG_CHUNK_SIZE=1200
GRAPHRAG_CHUNK_OVERLAP=100
```

### 3.2 Setting Environment Variables in Python

You can set environment variables programmatically in Python:

```python
import os

os.environ['GRAPHRAG_API_KEY'] = 'your_api_key_here'
os.environ['GRAPHRAG_LLM_TYPE'] = 'azure_openai_chat'
```

## 4. Configuration Using JSON/YAML Files

For more complex configurations, GraphRAG supports using JSON or YAML files. This method allows for more structured and readable configurations, especially for large projects.

### 4.1 YAML Configuration Example

```yaml
# config.yml
input:
  type: file
  file_type: csv
  base_dir: ./data
  file_pattern: .*\.csv$

llm:
  type: azure_openai_chat
  api_key: ${GRAPHRAG_API_KEY}
  model: gpt-4
  max_tokens: 4000

embeddings:
  type: azure_openai_embedding
  model: text-embedding-ada-002

chunks:
  size: 1200
  overlap: 100

cache:
  type: file
  base_dir: ./cache

storage:
  type: file
  base_dir: ./output
```

### 4.2 Using a Configuration File

To use a configuration file with GraphRAG:

```python
from graphrag.index import run_pipeline_with_config

async def main():
    config_path = 'path/to/your/config.yml'
    async for output in run_pipeline_with_config(config_path):
        # Process output
        pass

# Run the main function
import asyncio
asyncio.run(main())
```

## 5. Creating and Using .env Files

A `.env` file is a convenient way to store environment variables, especially for local development. GraphRAG can automatically load variables from a `.env` file in your project directory.

### 5.1 Sample .env File

```
# .env
GRAPHRAG_API_KEY=your_api_key_here
GRAPHRAG_API_BASE=https://your-resource.openai.azure.com/
GRAPHRAG_API_VERSION=2023-05-15
GRAPHRAG_LLM_MODEL=gpt-4
GRAPHRAG_EMBEDDING_MODEL=text-embedding-ada-002
```

### 5.2 Loading .env File

GraphRAG automatically loads the `.env` file if it's present in your project directory. You can also load it manually:

```python
from dotenv import load_dotenv

load_dotenv()  # This loads the variables from .env
```

## 6. Understanding Config Sections

GraphRAG configuration is divided into several sections, each controlling different aspects of the system. Let's explore the key sections:

### 6.1 Input Configuration

Controls how GraphRAG reads input data.

```yaml
input:
  type: file  # or 'blob'
  file_type: csv  # or 'text'
  base_dir: ./data
  file_pattern: .*\.csv$
  source_column: author
  text_column: message
  timestamp_column: date
  timestamp_format: "%Y%m%d%H%M%S"
```

### 6.2 LLM Configuration

Configures the Language Model settings.

```yaml
llm:
  type: azure_openai_chat
  api_key: ${GRAPHRAG_API_KEY}
  model: gpt-4
  max_tokens: 4000
  temperature: 0.7
```

### 6.3 Embeddings Configuration

Sets up the text embedding model.

```yaml
embeddings:
  type: azure_openai_embedding
  model: text-embedding-ada-002
  batch_size: 16
```

### 6.4 Chunks Configuration

Defines how input text is chunked for processing.

```yaml
chunks:
  size: 1200
  overlap: 100
  encoding_model: cl100k_base
```

### 6.5 Cache Configuration

Sets up caching for improved performance.

```yaml
cache:
  type: file  # or 'memory', 'blob'
  base_dir: ./cache
```

### 6.6 Storage Configuration

Configures where and how processed data is stored.

```yaml
storage:
  type: file  # or 'memory', 'blob'
  base_dir: ./output
```

### 6.7 Reporting Configuration

Sets up how GraphRAG generates reports and logs.

```yaml
reporting:
  type: file  # or 'console', 'blob'
  base_dir: ./reports
```

### 6.8 Entity Extraction Configuration

Configures the entity extraction process.

```yaml
entity_extraction:
  prompt: prompts/entity_extraction.txt
  entity_types: [organization, person, event, geo]
  max_gleanings: 1
```

### 6.9 Community Reports Configuration

Sets up the generation of community reports.

```yaml
community_reports:
  prompt: prompts/community_report.txt
  max_length: 1500
```

By understanding these configuration sections, you can fine-tune GraphRAG to best suit your specific use case and data characteristics.

In the next lesson, we'll dive into the GraphRAG Indexing Pipeline basics, where we'll see how these configurations come into play during the data processing stage.

