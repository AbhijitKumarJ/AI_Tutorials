# Lesson 4: GraphRAG Indexing Pipeline Basics

## Table of Contents
1. [Introduction to the Indexing Pipeline](#1-introduction-to-the-indexing-pipeline)
2. [Understanding Workflows and Steps](#2-understanding-workflows-and-steps)
3. [Basic Indexing Pipeline Execution](#3-basic-indexing-pipeline-execution)
4. [Exploring the Single_Verb Example](#4-exploring-the-single_verb-example)
5. [Introduction to DataShaper Library Concepts](#5-introduction-to-datashaper-library-concepts)

## 1. Introduction to the Indexing Pipeline

The Indexing Pipeline is a core component of GraphRAG, responsible for processing input data and creating the structured knowledge graph. It transforms raw, unstructured data into a rich, interconnected knowledge structure that can be efficiently queried.

### 1.1 Key Functions of the Indexing Pipeline

1. **Text Chunking**: Divides input documents into manageable pieces.
2. **Entity Extraction**: Identifies entities and relationships from the text chunks.
3. **Graph Construction**: Builds a graph structure from the extracted entities and relationships.
4. **Community Detection**: Applies algorithms to identify hierarchical communities within the graph.
5. **Embedding Generation**: Creates vector representations of entities and text chunks.
6. **Summary Generation**: Produces summaries for communities at different levels of the hierarchy.

### 1.2 Pipeline Architecture

The Indexing Pipeline is built on top of the DataShaper library, which allows for declarative expression of data pipelines using well-defined schemas. The pipeline is composed of a series of workflows, each containing one or more steps.

```mermaid
graph TD
    A[Input Data] --> B[Workflow 1]
    B --> C[Workflow 2]
    C --> D[Workflow 3]
    D --> E[Output: Structured Knowledge Graph]
```

## 2. Understanding Workflows and Steps

In GraphRAG, the indexing process is organized into workflows and steps. This structure allows for modular, reusable, and easily configurable data processing pipelines.

### 2.1 Workflows

A workflow is a sequence of processing steps that are executed in order. Workflows can be thought of as high-level tasks in the indexing process, such as "entity extraction" or "graph construction".

### 2.2 Steps

Steps are individual operations within a workflow. Each step typically corresponds to a specific data transformation or processing task.

### 2.3 Workflow Definition Example

Here's an example of how a workflow might be defined in a YAML configuration file:

```yaml
workflows:
  - name: entity_extraction
    steps:
      - verb: chunk_text
        args:
          chunk_size: 1000
          overlap: 100
      - verb: extract_entities
        args:
          model: gpt-4
          max_entities: 10
  - name: graph_construction
    steps:
      - verb: create_graph
        args:
          relationship_threshold: 0.5
      - verb: detect_communities
        args:
          algorithm: leiden
```

In this example, we have two workflows: `entity_extraction` and `graph_construction`. Each workflow consists of multiple steps, with each step using a specific "verb" (operation) and associated arguments.

## 3. Basic Indexing Pipeline Execution

Executing the Indexing Pipeline involves setting up your configuration and running the pipeline using the GraphRAG API. Here's a basic example of how to run the Indexing Pipeline:

```python
import asyncio
from graphrag.index import run_pipeline_with_config

async def run_indexing_pipeline():
    config_path = 'path/to/your/config.yml'
    
    async for output in run_pipeline_with_config(config_path):
        print(f"Completed workflow: {output.workflow}")
        print(f"Output shape: {output.result.shape if output.result is not None else 'No output'}")

# Run the pipeline
asyncio.run(run_indexing_pipeline())
```

This script does the following:

1. Imports the necessary function from GraphRAG.
2. Defines an asynchronous function to run the pipeline.
3. Specifies the path to the configuration file.
4. Uses `run_pipeline_with_config` to execute the pipeline, which yields outputs for each completed workflow.
5. Prints information about each completed workflow.

## 4. Exploring the Single_Verb Example

The single_verb example is a simple demonstration of how to use a single operation in the GraphRAG pipeline. Let's break it down:

### 4.1 Configuration File (pipeline.yml)

```yaml
input:
  file_type: csv
  base_dir: ./input
  file_pattern: .*\.csv$
workflows:
  - steps:
      - verb: derive
        args:
          column1: "col1"
          column2: "col2"
          to: "col_multiplied"
          operator: "*"
```

This configuration:
- Specifies CSV input from the ./input directory
- Defines a workflow with a single step using the "derive" verb
- The step multiplies values from "col1" and "col2", storing the result in "col_multiplied"

### 4.2 Python Script (run.py)

```python
import asyncio
import os
import pandas as pd
from graphrag.index import run_pipeline_with_config

# Sample dataset
dataset = pd.DataFrame([{"col1": 2, "col2": 4}, {"col1": 5, "col2": 10}])

async def run_with_config():
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "./pipeline.yml")
    
    outputs = []
    async for output in run_pipeline_with_config(config_or_path=config_path, dataset=dataset):
        outputs.append(output)
    
    pipeline_result = outputs[-1]
    
    if pipeline_result.result is not None:
        print(pipeline_result.result)
    else:
        print("No results!")

if __name__ == "__main__":
    asyncio.run(run_with_config())
```

This script:
1. Creates a sample dataset
2. Defines an asynchronous function to run the pipeline
3. Loads the configuration file
4. Executes the pipeline and collects the outputs
5. Prints the final result

The expected output would be:
```
   col1  col2  col_multiplied
0     2     4               8
1     5    10              50
```

This example demonstrates how to use a single verb (derive) to perform a simple calculation on input data, showcasing the basic structure of a GraphRAG workflow.

## 5. Introduction to DataShaper Library Concepts

DataShaper is the underlying library that powers GraphRAG's data processing capabilities. Understanding its key concepts is crucial for effectively using GraphRAG.

### 5.1 Core Concepts

1. **Verbs**: These are the basic operations that can be performed on data. Examples include:
   - `derive`: Create a new column based on existing ones
   - `filter`: Remove rows based on a condition
   - `aggregate`: Perform grouping and aggregation operations

2. **Workflow**: A sequence of verbs that defines a data processing pipeline.

3. **TableContainer**: The primary data structure used in DataShaper, representing tabular data.

### 5.2 Example of a DataShaper Workflow

Here's a simple example of how you might use DataShaper concepts directly:

```python
from datashaper import TableContainer
from datashaper.verbs import derive, filter

# Create a sample dataset
data = TableContainer({"A": [1, 2, 3, 4], "B": [10, 20, 30, 40]})

# Define a workflow
workflow = [
    derive(to="C", column1="A", column2="B", operator="*"),
    filter(predicate="C > 50")
]

# Apply the workflow
for verb in workflow:
    data = verb(data)

print(data.to_pandas())
```

This would output:
```
   A   B    C
2  3  30   90
3  4  40  160
```

### 5.3 Integration with GraphRAG

GraphRAG extends these DataShaper concepts, adding specialized verbs and workflows for tasks like entity extraction, graph construction, and community detection. The configuration files and pipeline execution in GraphRAG ultimately translate into DataShaper operations.

Understanding these DataShaper concepts allows you to:
1. Better comprehend how GraphRAG processes data
2. Create custom verbs or workflows when needed
3. Optimize your pipelines by understanding the underlying operations

In the next lesson, we'll dive deeper into advanced Indexing Pipeline concepts, exploring multiple workflows, custom input handlers, and more complex data processing scenarios.

