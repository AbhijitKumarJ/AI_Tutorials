# Lesson 2: Python Basics for GraphRAG

## Table of Contents
1. [Quick Python Refresher](#1-quick-python-refresher)
2. [Working with pandas DataFrames](#2-working-with-pandas-dataframes)
3. [Asynchronous Programming in Python (asyncio)](#3-asynchronous-programming-in-python-asyncio)
4. [Introduction to YAML and JSON](#4-introduction-to-yaml-and-json)
5. [Basic File I/O Operations](#5-basic-file-io-operations)

## 1. Quick Python Refresher

Before diving into GraphRAG-specific concepts, let's quickly review some Python basics that are particularly relevant to working with GraphRAG.

### 1.1 List Comprehensions

List comprehensions are a concise way to create lists in Python. They're often used in data processing tasks.

```python
# Example: Creating a list of squared numbers
squares = [x**2 for x in range(10)]
print(squares)  # Output: [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]

# Example: Filtering a list
even_squares = [x**2 for x in range(10) if x % 2 == 0]
print(even_squares)  # Output: [0, 4, 16, 36, 64]
```

### 1.2 Dictionary Comprehensions

Similar to list comprehensions, dictionary comprehensions allow you to create dictionaries concisely.

```python
# Example: Creating a dictionary of squared numbers
square_dict = {x: x**2 for x in range(5)}
print(square_dict)  # Output: {0: 0, 1: 1, 2: 4, 3: 9, 4: 16}
```

### 1.3 Lambda Functions

Lambda functions are small, anonymous functions that can be used in place of traditional function definitions.

```python
# Example: Using a lambda function with sorted()
data = [('Alice', 25), ('Bob', 30), ('Charlie', 22)]
sorted_data = sorted(data, key=lambda x: x[1])
print(sorted_data)  # Output: [('Charlie', 22), ('Alice', 25), ('Bob', 30)]
```

### 1.4 Context Managers

Context managers, used with the `with` statement, are useful for managing resources like file handles.

```python
# Example: Using a context manager to open a file
with open('example.txt', 'w') as f:
    f.write('Hello, GraphRAG!')
# File is automatically closed after the block
```

## 2. Working with pandas DataFrames

pandas is a crucial library for data manipulation in GraphRAG. Let's explore some common operations.

### 2.1 Creating DataFrames

```python
import pandas as pd

# Creating a DataFrame from a dictionary
data = {
    'name': ['Alice', 'Bob', 'Charlie'],
    'age': [25, 30, 22],
    'city': ['New York', 'San Francisco', 'Chicago']
}
df = pd.DataFrame(data)
print(df)
```

Output:
```
      name  age           city
0   Alice   25      New York
1     Bob   30  San Francisco
2  Charlie  22        Chicago
```

### 2.2 Reading and Writing DataFrames

```python
# Reading from CSV
df = pd.read_csv('data.csv')

# Writing to CSV
df.to_csv('output.csv', index=False)

# Reading from Parquet (common in GraphRAG)
df = pd.read_parquet('data.parquet')

# Writing to Parquet
df.to_parquet('output.parquet')
```

### 2.3 Basic DataFrame Operations

```python
# Selecting columns
print(df['name'])

# Filtering rows
young_people = df[df['age'] < 30]
print(young_people)

# Adding a new column
df['is_adult'] = df['age'] >= 18

# Grouping and aggregation
age_by_city = df.groupby('city')['age'].mean()
print(age_by_city)

# Sorting
sorted_df = df.sort_values('age', ascending=False)
print(sorted_df)
```

### 2.4 Applying Functions to DataFrames

```python
# Apply a function to a column
def age_category(age):
    return 'Young' if age < 30 else 'Adult'

df['age_category'] = df['age'].apply(age_category)
print(df)
```

## 3. Asynchronous Programming in Python (asyncio)

GraphRAG uses asynchronous programming for efficient I/O operations. Here's an introduction to asyncio.

### 3.1 Basic Concepts

- **Coroutines**: Functions that can be paused and resumed
- **Event Loop**: The core of async programming, manages execution of coroutines
- `async def`: Defines a coroutine
- `await`: Used to call a coroutine and wait for its result

### 3.2 Simple Example

```python
import asyncio

async def greet(name):
    await asyncio.sleep(1)  # Simulating an I/O operation
    print(f"Hello, {name}!")

async def main():
    await asyncio.gather(
        greet("Alice"),
        greet("Bob"),
        greet("Charlie")
    )

asyncio.run(main())
```

### 3.3 Asynchronous Context Managers

```python
import asyncio

class AsyncResource:
    async def __aenter__(self):
        print("Acquiring resource")
        await asyncio.sleep(1)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        print("Releasing resource")
        await asyncio.sleep(1)

async def main():
    async with AsyncResource() as resource:
        print("Using resource")

asyncio.run(main())
```

## 4. Introduction to YAML and JSON

YAML and JSON are common formats for configuration files in GraphRAG.

### 4.1 YAML Basics

YAML is a human-readable data serialization format.

```yaml
# Example YAML file: config.yaml
database:
  host: localhost
  port: 5432
  user: admin
users:
  - name: Alice
    role: admin
  - name: Bob
    role: user
```

Reading YAML in Python:

```python
import yaml

with open('config.yaml', 'r') as file:
    config = yaml.safe_load(file)

print(config['database']['host'])  # Output: localhost
print(config['users'][0]['name'])  # Output: Alice
```

### 4.2 JSON Basics

JSON is a lightweight data interchange format.

```json
{
  "database": {
    "host": "localhost",
    "port": 5432,
    "user": "admin"
  },
  "users": [
    {
      "name": "Alice",
      "role": "admin"
    },
    {
      "name": "Bob",
      "role": "user"
    }
  ]
}
```

Reading JSON in Python:

```python
import json

with open('config.json', 'r') as file:
    config = json.load(file)

print(config['database']['host'])  # Output: localhost
print(config['users'][0]['name'])  # Output: Alice
```

## 5. Basic File I/O Operations

File I/O is crucial for handling input data and storing results in GraphRAG.

### 5.1 Reading Files

```python
# Reading entire file
with open('example.txt', 'r') as file:
    content = file.read()
    print(content)

# Reading line by line
with open('example.txt', 'r') as file:
    for line in file:
        print(line.strip())
```

### 5.2 Writing Files

```python
# Writing to a file
with open('output.txt', 'w') as file:
    file.write("Hello, GraphRAG!\n")
    file.write("This is a new line.")

# Appending to a file
with open('output.txt', 'a') as file:
    file.write("\nAppended line.")
```

### 5.3 Working with CSV Files

```python
import csv

# Reading CSV
with open('data.csv', 'r') as file:
    csv_reader = csv.reader(file)
    for row in csv_reader:
        print(row)

# Writing CSV
data = [
    ['Name', 'Age', 'City'],
    ['Alice', '25', 'New York'],
    ['Bob', '30', 'San Francisco']
]
with open('output.csv', 'w', newline='') as file:
    csv_writer = csv.writer(file)
    csv_writer.writerows(data)
```

### 5.4 Working with JSON Files

```python
import json

# Reading JSON
with open('config.json', 'r') as file:
    data = json.load(file)
    print(data)

# Writing JSON
data = {
    'name': 'Alice',
    'age': 30,
    'city': 'New York'
}
with open('output.json', 'w') as file:
    json.dump(data, file, indent=2)
```

This lesson covers the essential Python concepts and libraries you'll need to work effectively with GraphRAG. In the next lesson, we'll dive into understanding GraphRAG configuration, where we'll apply many of these concepts in practice.

