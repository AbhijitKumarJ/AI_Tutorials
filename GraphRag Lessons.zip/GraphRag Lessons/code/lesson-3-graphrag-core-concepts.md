# Lesson 3: GraphRAG Core Concepts

## 1. Understanding Graphs and Their Representation in GraphRAG

Graphs are fundamental to the GraphRAG system, providing a powerful way to represent and analyze relationships between entities extracted from text data. In this section, we'll explore how graphs are conceptualized and implemented in GraphRAG.

### 1.1 Graph Theory Basics

A graph is a mathematical structure consisting of nodes (also called vertices) and edges that connect these nodes. In the context of GraphRAG, nodes typically represent entities (e.g., people, organizations, locations), while edges represent relationships or connections between these entities.

GraphRAG uses both directed and undirected graphs, depending on the specific use case:
- Directed graphs: Used when the relationship between entities has a specific direction (e.g., "Person A works for Company B")
- Undirected graphs: Used when the relationship is symmetric (e.g., "Person A and Person B are colleagues")

### 1.2 Graph Representation in GraphRAG

GraphRAG primarily uses the NetworkX library to represent and manipulate graphs. NetworkX is a powerful Python package for working with complex networks and graph structures. Here's an example of how graphs are created and manipulated in GraphRAG:

```python
# File: graphrag/index/graph/extractors/graph/graph_extractor.py

import networkx as nx

class GraphExtractor:
    # ... other methods ...

    async def __call__(
        self, texts: list[str], prompt_variables: dict[str, Any] | None = None
    ) -> GraphExtractionResult:
        # ... other code ...

        graph = nx.Graph()
        for source_doc_id, extracted_data in results.items():
            records = [r.strip() for r in extracted_data.split(record_delimiter)]

            for record in records:
                record = re.sub(r"^\(|\)$", "", record.strip())
                record_attributes = record.split(tuple_delimiter)

                if record_attributes[0] == '"entity"' and len(record_attributes) >= 4:
                    # Add node to the graph
                    entity_name = clean_str(record_attributes[1].upper())
                    entity_type = clean_str(record_attributes[2].upper())
                    entity_description = clean_str(record_attributes[3])

                    if entity_name in graph.nodes():
                        # Update existing node
                        node = graph.nodes[entity_name]
                        # ... update node attributes ...
                    else:
                        # Add new node
                        graph.add_node(
                            entity_name,
                            type=entity_type,
                            description=entity_description,
                            source_id=str(source_doc_id),
                        )

                if record_attributes[0] == '"relationship"' and len(record_attributes) >= 5:
                    # Add edge to the graph
                    source = clean_str(record_attributes[1].upper())
                    target = clean_str(record_attributes[2].upper())
                    edge_description = clean_str(record_attributes[3])
                    edge_source_id = clean_str(str(source_doc_id))
                    weight = float(record_attributes[-1])

                    # ... add nodes if they don't exist ...

                    graph.add_edge(
                        source,
                        target,
                        weight=weight,
                        description=edge_description,
                        source_id=edge_source_id,
                    )

        return GraphExtractionResult(
            output=graph,
            source_docs=source_doc_map,
        )
```

This code snippet demonstrates how GraphRAG constructs a graph by adding nodes (entities) and edges (relationships) based on extracted information from text documents.

### 1.3 Graph Algorithms in GraphRAG

GraphRAG leverages various graph algorithms to analyze and process the constructed graphs. Some key algorithms used in the project include:

1. Community Detection: Used to identify clusters of closely related entities within the graph.
2. Centrality Measures: Help identify important nodes in the graph based on their connections.
3. Shortest Path: Used for finding connections between entities.
4. Graph Embedding: Techniques like Node2Vec are used to create vector representations of nodes for machine learning tasks.

Example of community detection using the Leiden algorithm:

```python
# File: graphrag/index/operations/cluster_graph.py

from graspologic.partition import hierarchical_leiden

def _compute_leiden_communities(
    graph: nx.Graph | nx.DiGraph,
    max_cluster_size: int,
    use_lcc: bool,
    seed=0xDEADBEEF,
) -> dict[int, dict[str, int]]:
    """Return Leiden root communities."""
    if use_lcc:
        graph = stable_largest_connected_component(graph)

    community_mapping = hierarchical_leiden(
        graph, max_cluster_size=max_cluster_size, random_seed=seed
    )
    results: dict[int, dict[str, int]] = {}
    for partition in community_mapping:
        results[partition.level] = results.get(partition.level, {})
        results[partition.level][partition.node] = partition.cluster

    return results
```

This function uses the Leiden algorithm to perform hierarchical community detection on the input graph, which is crucial for organizing and understanding the structure of the extracted information.

## 2. Introduction to RAG (Retrieval-Augmented Generation)

Retrieval-Augmented Generation (RAG) is a powerful approach that combines the strengths of retrieval-based and generation-based AI models. RAG systems enhance the capabilities of large language models by providing them with relevant contextual information retrieved from a knowledge base.

### 2.1 RAG Workflow

The typical RAG workflow consists of the following steps:

1. Index Creation: Process and store documents in a searchable format (e.g., vector embeddings).
2. Query Processing: Convert user queries into a format suitable for retrieval.
3. Retrieval: Find relevant documents or passages based on the processed query.
4. Context Integration: Combine retrieved information with the original query.
5. Generation: Use a language model to generate a response based on the query and retrieved context.

### 2.2 GraphRAG's Approach

GraphRAG extends the traditional RAG approach by incorporating graph-based knowledge representation and retrieval. This allows for more nuanced and context-aware information retrieval and generation. Key enhancements include:

1. Entity and Relationship Extraction: GraphRAG identifies entities and their relationships from input documents, creating a rich knowledge graph.
2. Graph-based Retrieval: Instead of simple keyword or vector similarity search, GraphRAG can leverage graph structures to find relevant information.
3. Context-aware Generation: The language model can use the graph structure to generate more coherent and contextually appropriate responses.

Here's an example of how GraphRAG processes queries using graph-based information:

```python
# File: graphrag/query/structured_search/local_search/search.py

async def search(
    query: str,
    callbacks: VerbCallbacks,
    cache: PipelineCache,
    text_units: pd.DataFrame,
    communities: pd.DataFrame,
    entities: pd.DataFrame,
    relationships: pd.DataFrame,
    llm: CompletionLLM,
    args: dict,
) -> pd.DataFrame:
    # ... other code ...

    # Step 1: Generate questions
    questions = await generate_questions(
        query, question_gen_llm, callbacks, cache, args
    )

    # Step 2: Find relevant text units
    relevant_text_units = await find_relevant_text_units(
        text_units, questions, text_unit_embed_llm, callbacks, cache, args
    )

    # Step 3: Map entities
    mapped_entities = await map_entities(
        relevant_text_units,
        entities,
        entity_embed_llm,
        callbacks,
        cache,
        args,
    )

    # Step 4: Get relationships
    relationships_df = await get_relationships(
        mapped_entities, relationships, callbacks, args
    )

    # Step 5: Build context
    context = build_mixed_context(
        relevant_text_units,
        mapped_entities,
        relationships_df,
        communities,
        args,
    )

    # Step 6: Generate response
    response = await generate_response(
        query, context, llm, callbacks, cache, args
    )

    # ... process and return response ...
```

This code snippet demonstrates how GraphRAG combines various components (text units, entities, relationships, and communities) to process a query and generate a response using graph-based context.

## 3. Key Data Structures: PipelineConfig, PipelineStorage, PipelineCache

GraphRAG uses several key data structures to manage configuration, storage, and caching throughout the pipeline. Let's explore each of these in detail.

### 3.1 PipelineConfig

The `PipelineConfig` class is responsible for storing and managing the configuration settings for the GraphRAG pipeline. It uses Pydantic for data validation and serialization.

```python
# File: graphrag/index/config/pipeline.py

from pydantic import BaseModel
from pydantic import Field as pydantic_Field

from .cache import PipelineCacheConfigTypes
from .input import PipelineInputConfigTypes
from .reporting import PipelineReportingConfigTypes
from .storage import PipelineStorageConfigTypes
from .workflow import PipelineWorkflowReference

class PipelineConfig(BaseModel):
    """Represent the configuration for a pipeline."""

    extends: list[str] | str | None = pydantic_Field(
        description="Extends another pipeline configuration", default=None
    )

    input: PipelineInputConfigTypes | None = pydantic_Field(
        default=None, discriminator="file_type"
    )

    reporting: PipelineReportingConfigTypes | None = pydantic_Field(
        default=None, discriminator="type"
    )

    storage: PipelineStorageConfigTypes | None = pydantic_Field(
        default=None, discriminator="type"
    )

    cache: PipelineCacheConfigTypes | None = pydantic_Field(
        default=None, discriminator="type"
    )

    root_dir: str | None = pydantic_Field(
        description="The root directory for the pipeline. All other paths will be based on this root_dir.",
        default=None,
    )

    workflows: list[PipelineWorkflowReference] = pydantic_Field(
        description="The workflows for the pipeline.", default_factory=list
    )

    # ... other methods ...
```

This structure allows for easy configuration management, including input sources, storage options, caching strategies, and workflow definitions.

### 3.2 PipelineStorage

The `PipelineStorage` abstract base class defines the interface for storage operations in GraphRAG. Various implementations (e.g., file-based, in-memory, blob storage) inherit from this base class.

```python
# File: graphrag/index/storage/typing.py

from abc import ABCMeta, abstractmethod
from typing import Any

class PipelineStorage(metaclass=ABCMeta):
    """Provide a storage interface for the pipeline. This is where the pipeline will store its output data."""

    @abstractmethod
    async def get(self, key: str, as_bytes: bool | None = None, encoding: str | None = None) -> Any:
        """Get the value for the given key."""

    @abstractmethod
    async def set(self, key: str, value: str | bytes | None, encoding: str | None = None) -> None:
        """Set the value for the given key."""

    @abstractmethod
    async def has(self, key: str) -> bool:
        """Return True if the given key exists in the storage."""

    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete the given key from the storage."""

    @abstractmethod
    async def clear(self) -> None:
        """Clear the storage."""

    @abstractmethod
    def child(self, name: str | None) -> "PipelineStorage":
        """Create a child storage instance."""
```

This abstraction allows GraphRAG to work with different storage backends seamlessly, providing flexibility in deployment and usage scenarios.

### 3.3 PipelineCache

Similar to `PipelineStorage`, the `PipelineCache` abstract base class defines the interface for caching operations in GraphRAG.

```python
# File: graphrag/index/cache/pipeline_cache.py

from abc import ABCMeta, abstractmethod
from typing import Any

class PipelineCache(metaclass=ABCMeta):
    """Provide a cache interface for the pipeline."""

    @abstractmethod
    async def get(self, key: str) -> Any:
        """Get the value for the given key."""

    @abstractmethod
    async def set(self, key: str, value: Any, debug_data: dict | None = None) -> None:
        """Set the value for the given key."""

    @abstractmethod
    async def has(self, key: str) -> bool:
        """Return True if the given key exists in the cache."""

    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete the given key from the cache."""

    @abstractmethod
    async def clear(self) -> None:
        """Clear the cache."""

    @abstractmethod
    def child(self, name: str) -> "PipelineCache":
        """Create a child cache with the given name."""
```

The caching system in GraphRAG helps improve performance by storing and reusing intermediate results, particularly for computationally expensive operations like LLM calls or complex graph algorithms.

## 4. Workflow Concepts and Pipeline Design

GraphRAG's pipeline design is based on a flexible workflow system that allows for easy customization and extension of the processing steps. 

### 4.1 Workflow Structure

A workflow in GraphRAG is essentially a series of steps (or "verbs") that perform specific operations on the input data. Each workflow is defined using a declarative syntax, making it easy to understand and modify.

```python
# File: graphrag/index/workflows/v1/create_base_documents.py

from graphrag.index.config import PipelineWorkflowConfig, PipelineWorkflowStep

workflow_name = "create_base_documents"

def build_steps(
    config: PipelineWorkflowConfig,
) -> list[PipelineWorkflowStep]:
    """
    Create the documents table.

    ## Dependencies
    * `workflow:create_final_text_units`
    """
    document_attribute_columns = config.get("document_attribute_columns", [])
    return [
        {
            "verb": "create_base_documents",
            "args": {
                "document_attribute_columns": document_attribute_columns,
            },
            "input": {
                "source": DEFAULT_INPUT_NAME,
                "text_units": "workflow:create_final_text_units",
            },
        },
    ]
```

This example defines a workflow for creating base documents. It specifies the verb to be executed, its arguments, and the required input data.

### 4.2 Pipeline Execution

The pipeline execution in GraphRAG is managed by the `run_pipeline` function, which orchestrates the execution of multiple workflows in the correct order, handling dependencies and data flow between them.

```python
# File: graphrag/index/run/run.py

async def run_pipeline(
    workflows: list[PipelineWorkflowReference],
    dataset: pd.DataFrame,
    storage: PipelineStorage | None = None,
    cache: PipelineCache | None = None,
    callbacks: WorkflowCallbacks | None = None,
    progress_reporter: ProgressReporter | None = None,
    input_post_process_steps: list[PipelineWorkflowStep] | None = None,
    additional_verbs: VerbDefinitions | None = None,
    additional_workflows: WorkflowDefinitions | None = None,
    emit: list[TableEmitterType] | None = None,
    memory_profile: bool = False,
    is_resume_run: bool = False,
    **_kwargs: dict,
) -> AsyncIterable[PipelineRunResult]:
    # ... implementation ...

    for workflow_to_run in workflows_to_run:
        # Try to flush out any intermediate dataframes
        gc.collect()

        last_workflow = workflow_to_run.workflow.name
        result = await _process_workflow(
            workflow_to_run.workflow,
            context,
            callbacks,
            emitters,
            workflow_dependencies,
            dataset,
            start_time,
            is_resume_run,
        )
        if result:
            yield result

    # ... error handling and cleanup ...
```

This function iterates through the workflows, executing each one and yielding the results. It handles aspects such as garbage collection, error handling, and progress reporting.

### 4.3 Workflow Dependencies

GraphRAG manages workflow dependencies to ensure that workflows are executed in the correct order. This is crucial for maintaining data consistency and avoiding errors due to missing or outdated information.

```python
# File: graphrag/index/workflows/load.py

def load_workflows(
    workflows_to_load: list[PipelineWorkflowReference],
    additional_verbs: VerbDefinitions | None = None,
    additional_workflows: WorkflowDefinitions | None = None,
    memory_profile: bool = False,
) -> LoadWorkflowResult:
    # ... implementation ...

    def filter_wf_dependencies(name: str) -> list[str]:
        externals = [
            e.replace("workflow:", "")
            for e in workflow_graph[name].workflow.dependencies
        ]
        return [e for e in externals if e in workflow_graph]

    task_graph = {name: filter_wf_dependencies(name) for name in workflow_graph}
    workflow_run_order = topological_sort(task_graph)
    workflows = [workflow_graph[name] for name in workflow_run_order]
    log.info("Workflow Run Order: %s", workflow_run_order)
    return LoadWorkflowResult(workflows=workflows, dependencies=task_graph)
```

This code snippet demonstrates how GraphRAG determines the correct order of workflow execution based on their dependencies. It uses a topological sort to ensure that all dependencies are satisfied before a workflow is executed.

## Conclusion

In this lesson, we've explored the core concepts of GraphRAG, including graph representations, the RAG approach, key data structures, and workflow concepts. These fundamental elements form the backbone of the GraphRAG system, enabling powerful and flexible information processing and generation.

Understanding these concepts is crucial for effectively working with and extending the GraphRAG project. In the next lesson, we'll dive into the Natural Language Processing aspects of GraphRAG, exploring how it handles tasks such as tokenization, named entity recognition, and text embedding.

## Review Questions

1. How does GraphRAG represent and manipulate graphs? What library does it primarily use for this purpose?
2. Explain the concept of Retrieval-Augmented Generation (RAG) and how GraphRAG extends this approach.
3. Describe the purpose and structure of the `PipelineConfig` class in GraphRAG.
4. What is the role of the `PipelineStorage` and `PipelineCache` abstractions in the GraphRAG system?
5. How are workflows defined and structured in GraphRAG?
6. Explain how GraphRAG manages workflow dependencies and ensures correct execution order.
7. What is the purpose of the `run_pipeline` function, and how does it handle workflow execution?

## Hands-on Exercise

1. Create a simple graph structure representing a small social network using NetworkX. Include at least 5 nodes (representing people) and edges representing friendships.

2. Implement a function that performs community detection on your graph using the Leiden algorithm (you can use the `graspologic` library for this).

3. Create a basic workflow that does the following:
   a. Takes the graph as input
   b. Performs community detection
   c. Outputs a summary of the communities found

4. Implement a simple `PipelineStorage` class that stores the results in memory.

5. Use your implemented workflow and storage class to process the graph and store the results.

This exercise will help you practice working with graphs, implementing simple workflows, and using storage abstractions similar to those in GraphRAG.

