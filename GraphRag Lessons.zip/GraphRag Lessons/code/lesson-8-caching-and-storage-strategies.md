# Lesson 8: Caching and Storage Strategies in GraphRAG

## Introduction

In this lesson, we'll dive deep into the caching and storage strategies employed in the GraphRAG project. Effective caching and storage are crucial for optimizing performance and managing large datasets in graph-based retrieval-augmented generation systems. We'll explore various implementations, including in-memory caching, file-based storage, and Azure Blob Storage integration.

## File Structure

Before we begin, let's take a look at the relevant file structure for this lesson:

```
graphrag/
├── index/
│   ├── cache/
│   │   ├── __init__.py
│   │   ├── json_pipeline_cache.py
│   │   ├── load_cache.py
│   │   ├── memory_pipeline_cache.py
│   │   ├── noop_pipeline_cache.py
│   │   └── pipeline_cache.py
│   └── storage/
│       ├── __init__.py
│       ├── blob_pipeline_storage.py
│       ├── file_pipeline_storage.py
│       ├── load_storage.py
│       ├── memory_pipeline_storage.py
│       └── typing.py
└── config/
    ├── __init__.py
    ├── enums.py
    └── models.py
```

This structure shows the main components we'll be discussing in this lesson. The `cache` and `storage` directories contain the implementations for different caching and storage strategies.

## 1. Caching Strategies

Caching is a technique used to store and retrieve frequently accessed data quickly. In GraphRAG, caching is implemented to optimize performance by reducing the need for repeated computations or external API calls.

### 1.1 The PipelineCache Abstract Base Class

At the core of GraphRAG's caching system is the `PipelineCache` abstract base class. Let's examine its structure:

```python
# graphrag/index/cache/pipeline_cache.py

from abc import ABCMeta, abstractmethod
from typing import Any

class PipelineCache(metaclass=ABCMeta):
    @abstractmethod
    async def get(self, key: str) -> Any:
        """Get the value for the given key."""

    @abstractmethod
    async def set(self, key: str, value: Any, debug_data: dict | None = None) -> None:
        """Set the value for the given key."""

    @abstractmethod
    async def has(self, key: str) -> bool:
        """Return True if the given key exists in the cache."""

    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete the given key from the cache."""

    @abstractmethod
    async def clear(self) -> None:
        """Clear the cache."""

    @abstractmethod
    def child(self, name: str) -> "PipelineCache":
        """Create a child cache with the given name."""
```

This abstract base class defines the interface for all cache implementations in GraphRAG. It includes methods for getting, setting, checking, deleting, and clearing cache entries, as well as creating child caches.

### 1.2 In-Memory Caching

The simplest and fastest caching strategy is in-memory caching. GraphRAG implements this using the `InMemoryCache` class:

```python
# graphrag/index/cache/memory_pipeline_cache.py

from typing import Any
from .pipeline_cache import PipelineCache

class InMemoryCache(PipelineCache):
    def __init__(self, name: str | None = None):
        self._cache = {}
        self._name = name or ""

    async def get(self, key: str) -> Any:
        key = self._create_cache_key(key)
        return self._cache.get(key)

    async def set(self, key: str, value: Any, debug_data: dict | None = None) -> None:
        key = self._create_cache_key(key)
        self._cache[key] = value

    async def has(self, key: str) -> bool:
        key = self._create_cache_key(key)
        return key in self._cache

    async def delete(self, key: str) -> None:
        key = self._create_cache_key(key)
        del self._cache[key]

    async def clear(self) -> None:
        self._cache.clear()

    def child(self, name: str) -> PipelineCache:
        return InMemoryCache(name)

    def _create_cache_key(self, key: str) -> str:
        return f"{self._name}{key}"
```

The `InMemoryCache` class uses a simple Python dictionary to store key-value pairs in memory. This provides fast access but is limited by available RAM and doesn't persist between program runs.

### 1.3 JSON Pipeline Cache

For cases where persistence is needed, GraphRAG implements a JSON-based cache that can work with various storage backends:

```python
# graphrag/index/cache/json_pipeline_cache.py

import json
from typing import Any
from graphrag.index.storage import PipelineStorage
from .pipeline_cache import PipelineCache

class JsonPipelineCache(PipelineCache):
    def __init__(self, storage: PipelineStorage, encoding="utf-8"):
        self._storage = storage
        self._encoding = encoding

    async def get(self, key: str) -> str | None:
        if await self.has(key):
            try:
                data = await self._storage.get(key, encoding=self._encoding)
                data = json.loads(data)
            except (UnicodeDecodeError, json.decoder.JSONDecodeError):
                await self._storage.delete(key)
                return None
            else:
                return data.get("result")
        return None

    async def set(self, key: str, value: Any, debug_data: dict | None = None) -> None:
        if value is None:
            return
        data = {"result": value, **(debug_data or {})}
        await self._storage.set(
            key, json.dumps(data, ensure_ascii=False), encoding=self._encoding
        )

    async def has(self, key: str) -> bool:
        return await self._storage.has(key)

    async def delete(self, key: str) -> None:
        if await self.has(key):
            await self._storage.delete(key)

    async def clear(self) -> None:
        await self._storage.clear()

    def child(self, name: str) -> "JsonPipelineCache":
        return JsonPipelineCache(self._storage.child(name), encoding=self._encoding)
```

The `JsonPipelineCache` class serializes cache entries as JSON and uses a `PipelineStorage` backend for persistence. This allows for flexible storage options while maintaining a consistent caching interface.

## 2. Storage Strategies

Storage strategies in GraphRAG are designed to handle persistent data storage across different backends. The project implements file-based storage, memory storage, and Azure Blob Storage.

### 2.1 The PipelineStorage Abstract Base Class

Similar to caching, storage in GraphRAG is built around an abstract base class:

```python
# graphrag/index/storage/typing.py

from abc import ABCMeta, abstractmethod
import re
from typing import Any
from collections.abc import Iterator
from graphrag.logging import ProgressReporter

class PipelineStorage(metaclass=ABCMeta):
    @abstractmethod
    def find(
        self,
        file_pattern: re.Pattern[str],
        base_dir: str | None = None,
        progress: ProgressReporter | None = None,
        file_filter: dict[str, Any] | None = None,
        max_count=-1,
    ) -> Iterator[tuple[str, dict[str, Any]]]:
        """Find files in the storage using a file pattern and custom filter."""

    @abstractmethod
    async def get(
        self, key: str, as_bytes: bool | None = None, encoding: str | None = None
    ) -> Any:
        """Get the value for the given key."""

    @abstractmethod
    async def set(
        self, key: str, value: str | bytes | None, encoding: str | None = None
    ) -> None:
        """Set the value for the given key."""

    @abstractmethod
    async def has(self, key: str) -> bool:
        """Return True if the given key exists in the storage."""

    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete the given key from the storage."""

    @abstractmethod
    async def clear(self) -> None:
        """Clear the storage."""

    @abstractmethod
    def child(self, name: str | None) -> "PipelineStorage":
        """Create a child storage instance."""
```

This abstract class defines the interface for all storage implementations in GraphRAG, including methods for finding, getting, setting, checking, deleting, and clearing stored data.

### 2.2 File-Based Storage

File-based storage is implemented in the `FilePipelineStorage` class:

```python
# graphrag/index/storage/file_pipeline_storage.py

import os
import re
import shutil
from pathlib import Path
from typing import Any
import aiofiles
from aiofiles.os import remove
from aiofiles.ospath import exists
from graphrag.logging import ProgressReporter
from .typing import PipelineStorage

class FilePipelineStorage(PipelineStorage):
    def __init__(self, root_dir: str | None = None, encoding: str | None = None):
        self._root_dir = root_dir or ""
        self._encoding = encoding or "utf-8"
        Path(self._root_dir).mkdir(parents=True, exist_ok=True)

    # Implementation of abstract methods...

    async def get(self, key: str, as_bytes: bool | None = False, encoding: str | None = None) -> Any:
        file_path = join_path(self._root_dir, key)
        if await self.has(key):
            return await self._read_file(file_path, as_bytes, encoding)
        if await exists(key):
            return await self._read_file(key, as_bytes, encoding)
        return None

    async def set(self, key: str, value: Any, encoding: str | None = None) -> None:
        is_bytes = isinstance(value, bytes)
        write_type = "wb" if is_bytes else "w"
        encoding = None if is_bytes else encoding or self._encoding
        async with aiofiles.open(
            join_path(self._root_dir, key),
            cast(Any, write_type),
            encoding=encoding,
        ) as f:
            await f.write(value)

    # Other method implementations...
```

This class provides a file system-based storage solution, where data is stored as files in a specified directory.

### 2.3 Azure Blob Storage

For cloud-based storage, GraphRAG implements Azure Blob Storage support:

```python
# graphrag/index/storage/blob_pipeline_storage.py

from azure.storage.blob import BlobServiceClient
from azure.identity import DefaultAzureCredential
from .typing import PipelineStorage

class BlobPipelineStorage(PipelineStorage):
    def __init__(
        self,
        connection_string: str | None,
        container_name: str,
        encoding: str | None = None,
        path_prefix: str | None = None,
        storage_account_blob_url: str | None = None,
    ):
        if connection_string:
            self._blob_service_client = BlobServiceClient.from_connection_string(
                connection_string
            )
        else:
            if storage_account_blob_url is None:
                raise ValueError("Either connection_string or storage_account_blob_url must be provided.")
            self._blob_service_client = BlobServiceClient(
                account_url=storage_account_blob_url,
                credential=DefaultAzureCredential(),
            )
        self._encoding = encoding or "utf-8"
        self._container_name = container_name
        self._connection_string = connection_string
        self._path_prefix = path_prefix or ""
        self._storage_account_blob_url = storage_account_blob_url
        self._storage_account_name = (
            storage_account_blob_url.split("//")[1].split(".")[0]
            if storage_account_blob_url
            else None
        )
        self.create_container()

    # Implementation of abstract methods...

    async def get(self, key: str, as_bytes: bool | None = False, encoding: str | None = None) -> Any:
        try:
            key = self._keyname(key)
            container_client = self._blob_service_client.get_container_client(
                self._container_name
            )
            blob_client = container_client.get_blob_client(key)
            blob_data = blob_client.download_blob().readall()
            if not as_bytes:
                coding = encoding or "utf-8"
                blob_data = blob_data.decode(coding)
        except Exception:
            return None
        else:
            return blob_data

    async def set(self, key: str, value: Any, encoding: str | None = None) -> None:
        try:
            key = self._keyname(key)
            container_client = self._blob_service_client.get_container_client(
                self._container_name
            )
            blob_client = container_client.get_blob_client(key)
            if isinstance(value, bytes):
                blob_client.upload_blob(value, overwrite=True)
            else:
                coding = encoding or "utf-8"
                blob_client.upload_blob(value.encode(coding), overwrite=True)
        except Exception:
            pass

    # Other method implementations...
```

This class provides an interface to store and retrieve data from Azure Blob Storage, allowing GraphRAG to work with cloud-based storage solutions.

## 3. Configuring Caching and Storage

GraphRAG uses a configuration system to specify which caching and storage strategies to use. This is done through the `GraphRagConfig` class:

```python
# graphrag/config/models.py

from pydantic import BaseModel
from .enums import CacheType, StorageType

class CacheConfig(BaseModel):
    type: CacheType
    base_dir: str | None = None
    connection_string: str | None = None
    container_name: str | None = None
    storage_account_blob_url: str | None = None

class StorageConfig(BaseModel):
    type: StorageType
    base_dir: str | None = None
    connection_string: str | None = None
    container_name: str | None = None
    storage_account_blob_url: str | None = None

class GraphRagConfig(BaseModel):
    # Other configuration fields...
    cache: CacheConfig
    storage: StorageConfig
    # More configuration fields...
```

Users can specify their desired caching and storage strategies in a YAML configuration file, which is then parsed into this `GraphRagConfig` object.

## 4. Best Practices and Considerations

When working with caching and storage in GraphRAG, consider the following best practices:

1. Choose the appropriate caching strategy based on your needs. In-memory caching is fastest but doesn't persist, while JSON-based caching with file or blob storage persists but is slower.

2. For large datasets, consider using Azure Blob Storage or another cloud storage solution to handle scalability.

3. Be mindful of cache invalidation. Implement a strategy to update or clear cache entries when the underlying data changes.

4. When using file-based storage, ensure proper file system permissions and consider disk space limitations.

5. For Azure Blob Storage, manage access keys securely and consider using Managed Identities in production environments.

6. Implement error handling and logging for storage operations, especially when working with remote storage like Azure Blob Storage.

7. Consider implementing a caching layer on top of your chosen storage strategy to optimize performance.

8. Use asynchronous operations (as implemented in GraphRAG) to improve performance when dealing with I/O-bound operations like file or blob storage access.

## 5. Implementing Custom Storage Backends

GraphRAG's modular design allows for easy implementation of custom storage backends. To create a custom storage backend:

1. Subclass the `PipelineStorage` abstract base class.
2. Implement all the required abstract methods.
3. Register your custom storage class in the `load_storage` function in `graphrag/index/storage/load_storage.py`.

Here's an example of how you might implement a simple Redis-based storage backend:

```python
import redis
from graphrag.index.storage.typing import PipelineStorage

class RedisPipelineStorage(PipelineStorage):
    def __init__(self, host='localhost', port=6379, db=0):
        self.redis = redis.Redis(host=host, port=port, db=db)

    async def get(self, key: str, as_bytes: bool | None = False, encoding: str | None = None) -> Any:
        value = self.redis.get(key)
        if as_bytes:
            return value
        return value.decode(encoding or 'utf-8') if value else None

    async def set(self, key: str, value: str | bytes | None, encoding: str | None = None) -> None:
        if isinstance(value, str):
            value = value.encode(encoding or 'utf-8')
        self.redis.set(key, value)

    async def has(self, key: str) -> bool:
        return self.redis.exists(key)

    async def delete(self, key: str) -> None:
        self.redis.delete(key)

    async def clear(self) -> None:
        self.redis.flushdb()

    def child(self, name: str | None) -> "PipelineStorage":
        # For Redis, we could use a naming convention for keys to simulate child storages
        return RedisPipelineStorage(self.redis.connection_pool.connection_kwargs)

    # Implement other required methods...
```

## 6. Performance Optimization

When working with large datasets or complex graph structures, optimizing caching and storage performance becomes crucial. Here are some strategies to consider:

1. **Caching Strategy**: Implement a multi-level caching strategy. Use in-memory caching for frequently accessed, small pieces of data, and persistent caching (file or blob storage) for larger, less frequently accessed data.

2. **Batch Operations**: When performing multiple read or write operations, consider batching them to reduce the number of I/O operations.

3. **Compression**: For large datasets, implement data compression before storage to reduce storage requirements and potentially improve I/O performance.

4. **Indexing**: If your storage backend supports it, implement indexing on frequently queried fields to improve search performance.

5. **Asynchronous Operations**: Utilize asynchronous operations to perform I/O-bound tasks concurrently, improving overall system throughput.

6. **Connection Pooling**: For database or network-based storage backends, implement connection pooling to reduce the overhead of creating new connections.

7. **Monitoring and Profiling**: Implement comprehensive logging and monitoring to identify performance bottlenecks in your caching and storage operations.

## Conclusion

Effective caching and storage strategies are crucial for the performance and scalability of GraphRAG applications. By understanding and properly utilizing the various caching and storage options provided by GraphRAG, you can optimize your application's performance and resource usage.

Remember to consider your specific use case when choosing between in-memory caching, file-based storage, and cloud storage solutions like Azure Blob Storage. Each has its own strengths and is suited to different scenarios.

In the next lesson, we'll explore text processing and chunking strategies in GraphRAG, which are essential for preparing input data for graph-based analysis and generation tasks.

