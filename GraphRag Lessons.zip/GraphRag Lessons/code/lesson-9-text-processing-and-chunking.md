# Lesson 9: Text Processing and Chunking in GraphRAG

## Introduction

In this lesson, we'll dive into the text processing and chunking strategies employed in the GraphRAG project. These techniques are crucial for preparing large text documents for efficient processing, embedding, and analysis within the graph-based retrieval-augmented generation system.

## File Structure

Before we begin, let's take a look at the relevant file structure for this lesson:

```
graphrag/
├── index/
│   ├── text_splitting/
│   │   ├── __init__.py
│   │   ├── check_token_limit.py
│   │   └── text_splitting.py
│   └── operations/
│       └── chunk_text/
│           ├── __init__.py
│           ├── chunk_text.py
│           ├── strategies.py
│           └── typing.py
└── config/
    ├── __init__.py
    ├── defaults.py
    └── models.py
```

This structure shows the main components we'll be discussing in this lesson. The `text_splitting` directory contains the core text splitting logic, while the `chunk_text` directory under `operations` contains the chunking strategies used in the GraphRAG pipeline.

## 1. Text Splitting Fundamentals

Text splitting is the process of breaking down large text documents into smaller, manageable pieces. This is crucial for several reasons:

1. **Token Limits**: Many language models have a maximum token limit for input. Splitting text ensures we stay within these limits.
2. **Efficient Processing**: Smaller chunks of text can be processed more efficiently, especially in parallel.
3. **Relevant Context**: For tasks like question answering or summarization, working with smaller, relevant chunks of text can improve accuracy.

### 1.1 The TextSplitter Abstract Base Class

At the core of GraphRAG's text splitting system is the `TextSplitter` abstract base class:

```python
# graphrag/index/text_splitting/text_splitting.py

from abc import ABC, abstractmethod

class TextSplitter(ABC):
    def __init__(
        self,
        chunk_size: int = 8191,
        chunk_overlap: int = 100,
        length_function: LengthFn = len,
        keep_separator: bool = False,
        add_start_index: bool = False,
        strip_whitespace: bool = True,
    ):
        self._chunk_size = chunk_size
        self._chunk_overlap = chunk_overlap
        self._length_function = length_function
        self._keep_separator = keep_separator
        self._add_start_index = add_start_index
        self._strip_whitespace = strip_whitespace

    @abstractmethod
    def split_text(self, text: str | list[str]) -> Iterable[str]:
        """Split text method definition."""
```

This abstract base class defines the interface for all text splitter implementations in GraphRAG. It includes parameters for controlling chunk size, overlap, and other splitting behaviors.

### 1.2 TokenTextSplitter

The `TokenTextSplitter` is a concrete implementation of `TextSplitter` that splits text based on token counts:

```python
# graphrag/index/text_splitting/text_splitting.py

import tiktoken

class TokenTextSplitter(TextSplitter):
    def __init__(
        self,
        encoding_name: str = "cl100k_base",
        model_name: str | None = None,
        allowed_special: Literal["all"] | set[str] | None = None,
        disallowed_special: Literal["all"] | Collection[str] = "all",
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        if model_name is not None:
            try:
                enc = tiktoken.encoding_for_model(model_name)
            except KeyError:
                enc = tiktoken.get_encoding(encoding_name)
        else:
            enc = tiktoken.get_encoding(encoding_name)
        self._tokenizer = enc
        self._allowed_special = allowed_special or set()
        self._disallowed_special = disallowed_special

    def split_text(self, text: str | list[str]) -> list[str]:
        if isinstance(text, list):
            text = " ".join(text)
        if not isinstance(text, str):
            raise TypeError(f"Attempting to split a non-string value, actual is {type(text)}")

        tokenizer = Tokenizer(
            chunk_overlap=self._chunk_overlap,
            tokens_per_chunk=self._chunk_size,
            decode=self._tokenizer.decode,
            encode=lambda text: self.encode(text),
        )

        return split_text_on_tokens(text=text, tokenizer=tokenizer)
```

This class uses the `tiktoken` library to perform token-based splitting, which is particularly useful when working with transformer-based language models that have specific token limits.

## 2. Chunking Strategies

Chunking is the process of dividing text into smaller, manageable pieces. GraphRAG implements several chunking strategies to handle different types of input and requirements.

### 2.1 The ChunkText Operation

The main chunking operation in GraphRAG is implemented in the `chunk_text` function:

```python
# graphrag/index/operations/chunk_text/chunk_text.py

def chunk_text(
    input: pd.DataFrame,
    column: str,
    to: str,
    callbacks: VerbCallbacks,
    strategy: dict[str, Any] | None = None,
) -> pd.DataFrame:
    strategy_name = strategy.get("type", ChunkStrategyType.tokens)
    strategy_config = {**strategy}
    strategy_exec = load_strategy(strategy_name)

    num_total = _get_num_total(output, column)
    tick = progress_ticker(callbacks.progress, num_total)

    output[to] = output.apply(
        cast(
            Any,
            lambda x: run_strategy(strategy_exec, x[column], strategy_config, tick),
        ),
        axis=1,
    )
    return output
```

This function applies a chunking strategy to a specified column in a DataFrame, creating a new column with the chunked text.

### 2.2 Chunking Strategy Types

GraphRAG supports different chunking strategies, defined in the `ChunkStrategyType` enum:

```python
# graphrag/index/operations/chunk_text/typing.py

class ChunkStrategyType(str, Enum):
    tokens = "tokens"
    sentence = "sentence"
```

Each strategy type corresponds to a different method of splitting text:

1. **Tokens Strategy**: This strategy splits text based on token counts, which is useful when working with language models that have specific token limits.

2. **Sentence Strategy**: This strategy splits text into sentences, which can be more natural for certain types of analysis or generation tasks.

### 2.3 Implementing Chunking Strategies

The actual implementation of these strategies is done in the `strategies.py` file:

```python
# graphrag/index/operations/chunk_text/strategies.py

def run_tokens(
    input: list[str], args: dict[str, Any], tick: ProgressTicker
) -> Iterable[TextChunk]:
    tokens_per_chunk = args.get("chunk_size", defs.CHUNK_SIZE)
    chunk_overlap = args.get("chunk_overlap", defs.CHUNK_OVERLAP)
    encoding_name = args.get("encoding_name", defs.ENCODING_MODEL)
    enc = tiktoken.get_encoding(encoding_name)

    def encode(text: str) -> list[int]:
        if not isinstance(text, str):
            text = f"{text}"
        return enc.encode(text)

    def decode(tokens: list[int]) -> str:
        return enc.decode(tokens)

    return _split_text_on_tokens(
        input,
        Tokenizer(
            chunk_overlap=chunk_overlap,
            tokens_per_chunk=tokens_per_chunk,
            encode=encode,
            decode=decode,
        ),
        tick,
    )

def run_sentences(
    input: list[str], _args: dict[str, Any], tick: ProgressTicker
) -> Iterable[TextChunk]:
    for doc_idx, text in enumerate(input):
        sentences = nltk.sent_tokenize(text)
        for sentence in sentences:
            yield TextChunk(
                text_chunk=sentence,
                source_doc_indices=[doc_idx],
            )
        tick(1)
```

These functions implement the token-based and sentence-based chunking strategies, respectively.

## 3. Configuration and Usage

Chunking behavior in GraphRAG can be configured through the `GraphRagConfig` class:

```python
# graphrag/config/models.py

class ChunkConfig(BaseModel):
    size: int = Field(default=defs.CHUNK_SIZE)
    overlap: int = Field(default=defs.CHUNK_OVERLAP)
    group_by_columns: list[str] = Field(default=defs.CHUNK_GROUP_BY_COLUMNS)

class GraphRagConfig(BaseModel):
    # Other fields...
    chunks: ChunkConfig = Field(default_factory=ChunkConfig)
    # More fields...
```

Users can specify their desired chunking parameters in a YAML configuration file, which is then parsed into this `GraphRagConfig` object.

## 4. Best Practices and Considerations

When working with text processing and chunking in GraphRAG, consider the following best practices:

1. **Choose the Right Strategy**: Select the chunking strategy that best fits your data and task. Token-based chunking is often preferable when working with transformer models, while sentence-based chunking might be more appropriate for tasks that require preserving sentence structure.

2. **Overlap Considerations**: The chunk overlap parameter helps maintain context between chunks. However, larger overlaps increase the total number of chunks and processing time. Strike a balance based on your specific needs.

3. **Token Limits**: Be aware of the token limits of your target models. Ensure your chunking strategy produces chunks that fit within these limits.

4. **Preserve Context**: When chunking, try to preserve meaningful units of text (e.g., paragraphs or sentences) where possible. This can help maintain coherence in downstream tasks.

5. **Performance Optimization**: For large datasets, consider implementing parallel processing for chunking operations to improve performance.

6. **Chunk Metadata**: Consider adding metadata to your chunks (e.g., original document ID, chunk position) to help with reassembly or context tracking in later stages of processing.

7. **Adaptive Chunking**: For varied input texts, consider implementing adaptive chunking strategies that adjust based on the content or structure of the input.

## 5. Advanced Topics

### 5.1 Custom Chunking Strategies

GraphRAG's modular design allows for easy implementation of custom chunking strategies. To create a custom strategy:

1. Define a new strategy type in the `ChunkStrategyType` enum.
2. Implement the strategy function in `strategies.py`.
3. Update the `load_strategy` function to include your new strategy.

Here's an example of how you might implement a simple paragraph-based chunking strategy:

```python
# In typing.py
class ChunkStrategyType(str, Enum):
    # Existing strategies...
    paragraph = "paragraph"

# In strategies.py
def run_paragraphs(
    input: list[str], args: dict[str, Any], tick: ProgressTicker
) -> Iterable[TextChunk]:
    max_paragraphs = args.get("max_paragraphs", 5)
    for doc_idx, text in enumerate(input):
        paragraphs = text.split('\n\n')
        for i in range(0, len(paragraphs), max_paragraphs):
            chunk = '\n\n'.join(paragraphs[i:i+max_paragraphs])
            yield TextChunk(
                text_chunk=chunk,
                source_doc_indices=[doc_idx],
            )
        tick(1)

# In chunk_text.py
def load_strategy(strategy: ChunkStrategyType) -> ChunkStrategy:
    match strategy:
        case ChunkStrategyType.tokens:
            return run_tokens
        case ChunkStrategyType.sentence:
            return run_sentences
        case ChunkStrategyType.paragraph:
            return run_paragraphs
        case _:
            raise ValueError(f"Unknown strategy: {strategy}")
```

### 5.2 Handling Special Cases

When implementing text processing and chunking, it's important to consider special cases that might arise:

1. **Multi-language Support**: If your application needs to handle multiple languages, ensure your chunking strategies are language-agnostic or can be adapted for different languages. For sentence-based chunking, you might need to use language-specific tokenizers.

2. **Handling Code or Structured Text**: When dealing with code snippets or structured text (like JSON or XML), you might need specialized chunking strategies that preserve the structure of the content.

3. **Dealing with Very Long Input**: For extremely long input texts, consider implementing a two-stage chunking process: first divide the text into large sections, then apply more fine-grained chunking to each section.

4. **Handling Short Inputs**: For very short inputs that are smaller than your chunk size, you might want to implement logic to avoid unnecessary splitting.

Here's an example of how you might implement a chunking strategy that handles both very long and very short inputs:

```python
def adaptive_chunking(
    input: list[str], args: dict[str, Any], tick: ProgressTicker
) -> Iterable[TextChunk]:
    tokens_per_chunk = args.get("chunk_size", defs.CHUNK_SIZE)
    chunk_overlap = args.get("chunk_overlap", defs.CHUNK_OVERLAP)
    min_chunk_size = args.get("min_chunk_size", tokens_per_chunk // 2)
    max_input_tokens = args.get("max_input_tokens", tokens_per_chunk * 10)

    enc = tiktoken.get_encoding(args.get("encoding_name", defs.ENCODING_MODEL))

    for doc_idx, text in enumerate(input):
        tokens = enc.encode(text)
        
        if len(tokens) <= min_chunk_size:
            # For very short inputs, yield the entire text as one chunk
            yield TextChunk(text_chunk=text, source_doc_indices=[doc_idx])
        elif len(tokens) > max_input_tokens:
            # For very long inputs, first split into large sections
            sections = split_into_sections(tokens, max_input_tokens)
            for section in sections:
                # Then apply normal chunking to each section
                yield from _split_text_on_tokens(
                    [enc.decode(section)],
                    Tokenizer(
                        chunk_overlap=chunk_overlap,
                        tokens_per_chunk=tokens_per_chunk,
                        encode=enc.encode,
                        decode=enc.decode,
                    ),
                    tick,
                )
        else:
            # For normal-length inputs, use standard chunking
            yield from _split_text_on_tokens(
                [text],
                Tokenizer(
                    chunk_overlap=chunk_overlap,
                    tokens_per_chunk=tokens_per_chunk,
                    encode=enc.encode,
                    decode=enc.decode,
                ),
                tick,
            )
        
        tick(1)

def split_into_sections(tokens: list[int], max_section_tokens: int) -> list[list[int]]:
    sections = []
    for i in range(0, len(tokens), max_section_tokens):
        sections.append(tokens[i:i+max_section_tokens])
    return sections
```

This adaptive chunking strategy handles three cases:
1. Very short inputs that are kept as a single chunk
2. Very long inputs that are first split into large sections, then chunked
3. Normal-length inputs that use standard chunking

### 5.3 Optimizing Chunking Performance

For large-scale applications, the performance of your chunking operations can become a bottleneck. Here are some strategies to optimize chunking performance:

1. **Parallel Processing**: Implement parallel processing for chunking operations. This can significantly speed up processing for large datasets.

```python
import concurrent.futures

def parallel_chunk_text(
    input: pd.DataFrame,
    column: str,
    to: str,
    callbacks: VerbCallbacks,
    strategy: dict[str, Any] | None = None,
    max_workers: int = 4,
) -> pd.DataFrame:
    strategy_exec = load_strategy(strategy.get("type", ChunkStrategyType.tokens))
    strategy_config = {**strategy}

    def process_row(row):
        return run_strategy(strategy_exec, row[column], strategy_config, lambda _: None)

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(executor.map(process_row, input.itertuples(index=False)))

    input[to] = results
    return input
```

2. **Caching**: Implement caching for chunking results. This can be particularly useful if you're processing the same texts multiple times.

3. **Streaming Processing**: For very large inputs that don't fit in memory, implement a streaming approach to chunking.

```python
def stream_chunk_text(
    input_stream: Iterable[str],
    strategy: dict[str, Any] | None = None,
) -> Iterable[str]:
    strategy_exec = load_strategy(strategy.get("type", ChunkStrategyType.tokens))
    strategy_config = {**strategy}

    for text in input_stream:
        yield from run_strategy(strategy_exec, text, strategy_config, lambda _: None)
```

4. **Optimized Tokenization**: If you're using token-based chunking, ensure you're using an efficient tokenization method. Consider using faster tokenizers or pre-tokenizing your data if possible.

## Conclusion

Text processing and chunking are crucial components in the GraphRAG pipeline, enabling efficient handling of large text inputs and preparing data for downstream tasks such as embedding, entity extraction, and graph construction. By understanding the various chunking strategies and how to implement and configure them, you can optimize your GraphRAG applications for your specific use cases and data characteristics.

Remember that the choice of chunking strategy can significantly impact the performance and effectiveness of your application. Always consider the nature of your input data, the requirements of your downstream tasks, and the constraints of your target models when designing your text processing pipeline.

In the next lesson, we'll explore entity extraction and relationship detection in GraphRAG, building on the chunked text to construct meaningful graph representations of your data.

