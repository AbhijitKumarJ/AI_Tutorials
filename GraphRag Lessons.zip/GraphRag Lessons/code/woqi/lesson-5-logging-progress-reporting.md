# Lesson 5: Logging and Progress Reporting in GraphRAG

## Introduction

In this lesson, we'll explore the logging and progress reporting mechanisms implemented in GraphRAG. Effective logging and progress reporting are crucial for monitoring the execution of complex data processing pipelines, debugging issues, and providing user feedback. We'll examine how GraphRAG implements these features, focusing on different types of loggers, progress reporters, and their integration into the broader system.

## File Structure

Before we dive into the details, let's look at the relevant file structure for logging and progress reporting in GraphRAG:

```
graphrag/
├── logging/
│   ├── __init__.py
│   ├── console.py
│   ├── factories.py
│   ├── null_progress.py
│   ├── print_progress.py
│   ├── rich_progress.py
│   └── types.py
```

This structure shows the organization of logging-related code in GraphRAG. The `logging/` directory contains various implementations of loggers and progress reporters, as well as type definitions and factory functions.

## 1. Logging and Progress Reporting Abstractions

GraphRAG defines abstract base classes and protocols for logging and progress reporting to ensure consistency across different implementations. Let's examine the key abstractions:

### 1.1 StatusLogger Protocol

The `StatusLogger` protocol, defined in `logging/types.py`, specifies the interface for status logging:

```python
class StatusLogger(ABC):
    """Provides a way to report status updates from the pipeline."""

    @abstractmethod
    def error(self, message: str, details: dict[str, Any] | None = None):
        """Report an error."""

    @abstractmethod
    def warning(self, message: str, details: dict[str, Any] | None = None):
        """Report a warning."""

    @abstractmethod
    def log(self, message: str, details: dict[str, Any] | None = None):
        """Report a log."""
```

This protocol defines methods for reporting errors, warnings, and general log messages. By adhering to this protocol, different logger implementations can be used interchangeably throughout the system.

### 1.2 ProgressReporter Abstract Base Class

The `ProgressReporter` abstract base class, also defined in `logging/types.py`, provides the interface for progress reporting:

```python
class ProgressReporter(ABC):
    """
    Abstract base class for progress reporters.

    This is used to report workflow processing progress via mechanisms like progress-bars.
    """

    @abstractmethod
    def __call__(self, update: Progress):
        """Update progress."""

    @abstractmethod
    def dispose(self):
        """Dispose of the progress reporter."""

    @abstractmethod
    def child(self, prefix: str, transient=True) -> "ProgressReporter":
        """Create a child progress bar."""

    # ... (other abstract methods)
```

This abstract base class defines methods for updating progress, creating child progress reporters (for nested operations), and managing the lifecycle of the progress reporter.

## 2. Logger Implementations

GraphRAG provides several implementations of the `StatusLogger` protocol to cater to different logging needs. Let's examine some key implementations:

### 2.1 ConsoleReporter

The `ConsoleReporter` class, defined in `logging/console.py`, implements a simple console-based logger:

```python
class ConsoleReporter(StatusLogger):
    """A reporter that writes to a console."""

    def error(self, message: str, details: dict[str, Any] | None = None):
        """Report an error."""
        print(message, details)  # noqa T201

    def warning(self, message: str, details: dict[str, Any] | None = None):
        """Report a warning."""
        _print_warning(message)

    def log(self, message: str, details: dict[str, Any] | None = None):
        """Report a log."""
        print(message, details)  # noqa T201
```

This implementation provides a straightforward way to log messages to the console, with different formatting for errors and warnings.

### 2.2 Other Logger Implementations

GraphRAG may include other logger implementations for different use cases, such as file-based logging or integration with external logging systems. These would follow a similar pattern, implementing the `StatusLogger` protocol with specific behaviors for each logging method.

## 3. Progress Reporter Implementations

GraphRAG offers several implementations of the `ProgressReporter` abstract base class, each catering to different progress reporting needs. Let's examine some key implementations:

### 3.1 NullProgressReporter

The `NullProgressReporter` class, defined in `logging/null_progress.py`, provides a no-op implementation of the progress reporter:

```python
class NullProgressReporter(ProgressReporter):
    """A progress reporter that does nothing."""

    def __call__(self, update: Progress) -> None:
        """Update progress."""

    def dispose(self) -> None:
        """Dispose of the progress reporter."""

    def child(self, prefix: str, transient: bool = True) -> ProgressReporter:
        """Create a child progress bar."""
        return self

    # ... (other method implementations)
```

This implementation is useful in scenarios where progress reporting is not needed or should be suppressed.

### 3.2 PrintProgressReporter

The `PrintProgressReporter` class, defined in `logging/print_progress.py`, implements a simple text-based progress reporter:

```python
class PrintProgressReporter(ProgressReporter):
    """A progress reporter that prints to the console."""

    prefix: str

    def __init__(self, prefix: str):
        """Create a new progress reporter."""
        self.prefix = prefix
        print(f"\n{self.prefix}", end="")  # noqa T201

    def __call__(self, update: Progress) -> None:
        """Update progress."""
        print(".", end="")  # noqa T201

    # ... (other method implementations)
```

This implementation provides a basic progress indication by printing dots to the console as progress updates are received.

### 3.3 RichProgressReporter

The `RichProgressReporter` class, defined in `logging/rich_progress.py`, uses the `rich` library to provide a more sophisticated progress reporting interface:

```python
class RichProgressReporter(ProgressReporter):
    """A rich-based progress reporter for CLI use."""

    _console: Console
    _group: Group
    _tree: Tree
    _live: Live
    _task: TaskID | None = None
    _prefix: str
    _transient: bool
    _disposing: bool = False
    _progressbar: Progress
    _last_refresh: float = 0

    def __init__(
        self,
        prefix: str,
        parent: "RichProgressReporter | None" = None,
        transient: bool = True,
    ) -> None:
        # ... (initialization)

    def __call__(self, progress_update: DSProgress) -> None:
        """Update progress."""
        # ... (progress update logic)

    # ... (other method implementations)
```

This implementation leverages the `rich` library to create visually appealing and informative progress bars in the console. It supports nested progress reporting and provides more detailed progress information compared to simpler implementations.

## 4. Factory Methods for Creating Loggers and Progress Reporters

GraphRAG uses factory functions to create appropriate logger and progress reporter instances based on configuration or runtime parameters. These factory functions are defined in `logging/factories.py`:

```python
def create_progress_reporter(
    reporter_type: ReporterType = ReporterType.NONE,
) -> ProgressReporter:
    """Load a progress reporter."""
    match reporter_type:
        case ReporterType.RICH:
            return RichProgressReporter("GraphRAG Indexer ")
        case ReporterType.PRINT:
            return PrintProgressReporter("GraphRAG Indexer ")
        case ReporterType.NONE:
            return NullProgressReporter()
        case _:
            msg = f"Invalid progress reporter type: {reporter_type}"
            raise ValueError(msg)
```

This factory function allows the system to create the appropriate progress reporter based on the specified type, making it easy to switch between different reporting styles based on the execution environment or user preferences.

## 5. Integration with GraphRAG Workflows

Logging and progress reporting are integrated throughout GraphRAG's workflows to provide visibility into the system's operation. For example, in the pipeline execution code, progress reporters are used to track the progress of individual workflows:

```python
async def run_pipeline(
    workflows: list[PipelineWorkflowReference],
    dataset: pd.DataFrame,
    storage: PipelineStorage | None = None,
    cache: PipelineCache | None = None,
    callbacks: WorkflowCallbacks | None = None,
    progress_reporter: ProgressReporter | None = None,
    # ... (other parameters)
) -> AsyncIterable[PipelineRunResult]:
    # ... (pipeline setup)

    for workflow_to_run in workflows_to_run:
        result = await _process_workflow(
            workflow_to_run.workflow,
            context,
            callbacks,
            emitters,
            workflow_dependencies,
            dataset,
            start_time,
            is_resume_run,
        )
        if result:
            yield result

        if progress_reporter:
            if result.errors and len(result.errors) > 0:
                progress_reporter.error(result.workflow)
            else:
                progress_reporter.success(result.workflow)
            progress_reporter.info(str(result.result))

    # ... (error handling and cleanup)
```

This integration ensures that users receive real-time feedback on the progress of complex operations, making it easier to monitor long-running tasks and identify issues quickly.

## Conclusion

GraphRAG's logging and progress reporting system provides a flexible and extensible framework for monitoring and reporting on the status of data processing pipelines. By using abstract base classes and protocols, it allows for easy implementation of different logging and reporting mechanisms to suit various use cases and environments.

Key takeaways from this lesson include:
1. The use of abstract base classes and protocols to define consistent interfaces for logging and progress reporting.
2. Implementation of different logger and progress reporter classes for various use cases, from simple console output to rich, interactive progress bars.
3. Factory methods for creating appropriate logger and progress reporter instances based on configuration or runtime parameters.
4. Integration of logging and progress reporting throughout GraphRAG's workflows to provide real-time feedback on system operation.

Understanding these concepts is crucial for effectively monitoring and debugging GraphRAG pipelines, as well as for extending the system with custom logging or reporting mechanisms if needed.

## Review Questions

1. What are the main components of GraphRAG's logging and progress reporting system, and how do they interact?
2. How does the `StatusLogger` protocol contribute to the flexibility of GraphRAG's logging system?
3. Describe the purpose and implementation of the `RichProgressReporter` class. How does it differ from simpler progress reporting implementations?
4. What is the role of the factory functions in creating logger and progress reporter instances?
5. How are logging and progress reporting integrated into GraphRAG's workflow execution process?
6. Explain the purpose of the `NullProgressReporter`. In what scenarios would this implementation be useful?
7. How does GraphRAG's logging and progress reporting system support nested or hierarchical progress tracking?
8. Describe how you would extend GraphRAG's logging system to support a new type of logger (e.g., logging to a remote service).

## Hands-on Exercise

1. Implement a simple `FileLogger` class that adheres to the `StatusLogger` protocol. This logger should write log messages to a file, with appropriate formatting for errors, warnings, and general log messages.

2. Create a custom progress reporter that displays progress as a percentage completed, along with an estimated time remaining. Implement this as a subclass of `ProgressReporter`.

3. Extend the `create_progress_reporter` factory function to support your new progress reporter type.

4. Write a simple script that simulates a multi-step process, using your custom logger and progress reporter to provide updates. Include nested progress reporting to simulate sub-tasks within the main process.

5. Implement a basic configuration system that allows users to specify the desired logger and progress reporter types. Use this configuration to create the appropriate instances in your script.

This exercise will give you hands-on experience with the key concepts of logging and progress reporting in GraphRAG, including implementation of the core interfaces, creation of custom loggers and progress reporters, and integration of these components into a workflow.

By completing this exercise, you'll gain a deeper understanding of how GraphRAG manages logging and progress reporting, and you'll be better prepared to work with or extend these functionalities in real-world applications using the GraphRAG framework.


6. Enhance your custom progress reporter to support ANSI color codes for better visual distinction between different types of progress (e.g., green for completed tasks, yellow for in-progress tasks, red for errors).

7. Implement a `CompositeLogger` that can manage multiple `StatusLogger` instances, allowing log messages to be sent to multiple destinations simultaneously (e.g., console and file).

8. Create a decorator that can be applied to functions or methods to automatically log their entry and exit, including execution time. This can be useful for performance monitoring and debugging.

9. Develop a simple command-line interface that allows users to dynamically adjust the verbosity of logging and the style of progress reporting during runtime.

10. Write unit tests for your custom logger and progress reporter implementations, ensuring they correctly handle edge cases such as very large progress values or long log messages.

This extended exercise will give you a more comprehensive understanding of logging and progress reporting systems, and how they can be integrated into larger applications. It will also provide practice in creating more advanced features that are often found in production-grade logging systems.

By completing these additional tasks, you'll gain insight into:
- How to enhance visual feedback in console applications
- The implementation of composite design patterns in logging systems
- The use of Python decorators for aspect-oriented programming in logging
- Techniques for creating dynamic, user-configurable logging systems
- Best practices for testing logging and progress reporting components

These skills will be valuable not only for working with GraphRAG but also for developing robust, user-friendly command-line applications in general.



