# Lesson 3: Core Data Models in GraphRAG

## 1. Introduction to Core Data Models

In any complex software system, the way data is represented and structured is fundamental to its operation. This is especially true for GraphRAG, where the core functionality revolves around processing and analyzing graph-structured data. In this lesson, we'll dive deep into the core data models used in GraphRAG, exploring how they represent various entities, relationships, and other key concepts within the system.

We'll cover the following main topics:

1. Overview of the model module
2. Detailed examination of key data structures
3. Use of dataclasses in GraphRAG
4. Serialization and deserialization methods

By the end of this lesson, you'll have a comprehensive understanding of how GraphRAG represents its core data, which will be crucial for working with and extending the system.

## 2. The Model Module

The model module in GraphRAG is responsible for defining the core data structures used throughout the system. Let's examine its structure:

```
model/
├── __init__.py
├── community.py
├── community_report.py
├── covariate.py
├── document.py
├── entity.py
├── identified.py
├── named.py
├── relationship.py
├── text_unit.py
└── types.py
```

This structure reveals a well-organized approach to data modeling, with separate files for different types of data entities. Let's explore each of these in detail.

## 3. Key Data Structures

### 3.1 Identified

The `identified.py` file likely defines a base class for objects that have a unique identifier. This is a fundamental concept in GraphRAG, as many entities in the system need to be uniquely identifiable. Here's what it might look like:

```python
# model/identified.py

from dataclasses import dataclass

@dataclass
class Identified:
    """A base class for objects with a unique identifier."""
    id: str
    short_id: str | None
```

This class provides a foundation for other models in the system, ensuring that they all have a consistent way of being identified. The `short_id` field is an optional, human-readable identifier that can be used in contexts where a full ID might be too long or complex.

### 3.2 Named

Building on the `Identified` class, the `Named` class in `named.py` likely adds a name or title to the entity:

```python
# model/named.py

from dataclasses import dataclass
from .identified import Identified

@dataclass
class Named(Identified):
    """A base class for named objects."""
    title: str
```

This class serves as a base for entities that have both an identifier and a human-readable name or title.

### 3.3 Entity

The `Entity` class, defined in `entity.py`, is one of the core concepts in GraphRAG. It represents a node in the knowledge graph and might look something like this:

```python
# model/entity.py

from dataclasses import dataclass, field
from typing import List, Dict, Any
from .named import Named

@dataclass
class Entity(Named):
    """Represents an entity in the knowledge graph."""
    type: str | None = None
    description: str | None = None
    description_embedding: List[float] | None = None
    name_embedding: List[float] | None = None
    graph_embedding: List[float] | None = None
    community_ids: List[str] | None = None
    text_unit_ids: List[str] | None = None
    document_ids: List[str] | None = None
    rank: int = 1
    attributes: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'Entity':
        """Create an Entity instance from a dictionary."""
        return cls(
            id=d['id'],
            title=d['title'],
            short_id=d.get('short_id'),
            type=d.get('type'),
            description=d.get('description'),
            description_embedding=d.get('description_embedding'),
            name_embedding=d.get('name_embedding'),
            graph_embedding=d.get('graph_embedding'),
            community_ids=d.get('community'),
            rank=d.get('rank', 1),
            text_unit_ids=d.get('text_unit_ids'),
            document_ids=d.get('document_ids'),
            attributes=d.get('attributes', {})
        )
```

This `Entity` class encapsulates a wealth of information about each entity in the knowledge graph:

- It inherits from `Named`, so it has an ID and a title.
- It includes a type and description for classification and summarization.
- It stores various embeddings (description, name, and graph) which are crucial for similarity searches and other AI operations.
- It maintains references to related objects (communities, text units, and documents) through ID lists.
- It includes a rank for importance or relevance scoring.
- It allows for arbitrary additional attributes through the `attributes` dictionary.

The `from_dict` class method provides a convenient way to create `Entity` instances from dictionary data, which is useful for deserialization from JSON or other data formats.

### 3.4 Relationship

The `Relationship` class, defined in `relationship.py`, represents edges in the knowledge graph:

```python
# model/relationship.py

from dataclasses import dataclass, field
from typing import Dict, Any, List
from .identified import Identified

@dataclass
class Relationship(Identified):
    """Represents a relationship between two entities in the knowledge graph."""
    source: str
    target: str
    weight: float = 1.0
    description: str | None = None
    description_embedding: List[float] | None = None
    text_unit_ids: List[str] | None = None
    document_ids: List[str] | None = None
    attributes: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'Relationship':
        """Create a Relationship instance from a dictionary."""
        return cls(
            id=d['id'],
            short_id=d.get('short_id'),
            source=d['source'],
            target=d['target'],
            weight=d.get('weight', 1.0),
            description=d.get('description'),
            description_embedding=d.get('description_embedding'),
            text_unit_ids=d.get('text_unit_ids'),
            document_ids=d.get('document_ids'),
            attributes=d.get('attributes', {})
        )
```

The `Relationship` class captures the connections between entities:

- It includes source and target entities, representing the direction of the relationship.
- It has a weight to represent the strength or importance of the relationship.
- Like `Entity`, it includes a description and embedding for that description.
- It maintains references to the text units and documents where this relationship was identified.
- It also allows for additional attributes through the `attributes` dictionary.

### 3.5 Community

The `Community` class, defined in `community.py`, represents groups of related entities:

```python
# model/community.py

from dataclasses import dataclass, field
from typing import Dict, Any, List
from .named import Named

@dataclass
class Community(Named):
    """Represents a community of entities in the knowledge graph."""
    level: str = ""
    entity_ids: List[str] | None = None
    relationship_ids: List[str] | None = None
    covariate_ids: Dict[str, List[str]] | None = None
    attributes: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'Community':
        """Create a Community instance from a dictionary."""
        return cls(
            id=d['id'],
            title=d['title'],
            short_id=d.get('short_id'),
            level=d['level'],
            entity_ids=d.get('entity_ids'),
            relationship_ids=d.get('relationship_ids'),
            covariate_ids=d.get('covariate_ids'),
            attributes=d.get('attributes', {})
        )
```

The `Community` class groups related entities and relationships:

- It includes a level, which could represent the granularity or hierarchy of the community.
- It maintains lists of entity and relationship IDs that belong to this community.
- It includes a `covariate_ids` dictionary, which could represent additional data associated with the community.

### 3.6 Document and TextUnit

The `Document` and `TextUnit` classes (in `document.py` and `text_unit.py` respectively) likely represent the source data from which the knowledge graph is constructed:

```python
# model/document.py

from dataclasses import dataclass, field
from typing import Dict, Any, List
from .named import Named

@dataclass
class Document(Named):
    """Represents a source document in the system."""
    type: str = "text"
    text_unit_ids: List[str] = field(default_factory=list)
    raw_content: str = ""
    summary: str | None = None
    summary_embedding: List[float] | None = None
    raw_content_embedding: List[float] | None = None
    attributes: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'Document':
        """Create a Document instance from a dictionary."""
        return cls(
            id=d['id'],
            short_id=d.get('short_id'),
            title=d['title'],
            type=d.get('type', 'text'),
            raw_content=d['raw_content'],
            summary=d.get('summary'),
            summary_embedding=d.get('summary_embedding'),
            raw_content_embedding=d.get('raw_content_embedding'),
            text_unit_ids=d.get('text_units', []),
            attributes=d.get('attributes', {})
        )

# model/text_unit.py

from dataclasses import dataclass, field
from typing import Dict, Any, List
from .identified import Identified

@dataclass
class TextUnit(Identified):
    """Represents a unit of text (e.g., a paragraph) from a document."""
    text: str
    text_embedding: List[float] | None = None
    entity_ids: List[str] | None = None
    relationship_ids: List[str] | None = None
    covariate_ids: Dict[str, List[str]] | None = None
    n_tokens: int | None = None
    document_ids: List[str] | None = None
    attributes: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'TextUnit':
        """Create a TextUnit instance from a dictionary."""
        return cls(
            id=d['id'],
            short_id=d.get('short_id'),
            text=d['text'],
            text_embedding=d.get('text_embedding'),
            entity_ids=d.get('entity_ids'),
            relationship_ids=d.get('relationship_ids'),
            covariate_ids=d.get('covariate_ids'),
            n_tokens=d.get('n_tokens'),
            document_ids=d.get('document_ids'),
            attributes=d.get('attributes', {})
        )
```

These classes represent the raw data and its processed form:

- `Document` represents entire documents, with raw content, summaries, and embeddings.
- `TextUnit` represents smaller units of text (like paragraphs) extracted from documents, with links to the entities and relationships extracted from them.

## 4. Use of Dataclasses in GraphRAG

As you've seen in the examples above, GraphRAG makes extensive use of Python's `dataclass` decorator. This choice brings several benefits:

1. **Concise syntax**: Dataclasses reduce boilerplate code for creating classes that are primarily used to store data.

2. **Automatic method generation**: Dataclasses automatically generate methods like `__init__`, `__repr__`, and `__eq__`, saving development time and reducing the chance of errors.

3. **Type hinting**: Dataclasses encourage the use of type hints, which improves code readability and enables better static type checking.

4. **Immutability option**: Dataclasses can be made immutable (using `@dataclass(frozen=True)`), which can help prevent accidental modifications and make objects hashable.

5. **Easy customization**: When needed, dataclasses still allow for custom methods and properties to be added.

## 5. Serialization and Deserialization

GraphRAG implements serialization and deserialization through the `from_dict` class methods we've seen in the examples above. This approach has several advantages:

1. **Flexibility**: It allows for easy conversion between dictionary representations (which are common in JSON data) and the strongly-typed dataclass instances.

2. **Robustness**: The `from_dict` methods can handle missing or extra data gracefully, using default values or ignoring unnecessary fields.

3. **Consistency**: By implementing this method consistently across all models, GraphRAG ensures a uniform approach to data loading throughout the system.

4. **Extensibility**: If more complex serialization logic is needed in the future, it can be easily added to these methods without changing the rest of the system.

For serialization (converting instances to dictionaries or JSON), GraphRAG likely relies on the `asdict` function from the `dataclasses` module, possibly with some custom logic to handle special cases.

## Conclusion

The core data models in GraphRAG demonstrate a well-thought-out approach to representing complex, interconnected data. By using dataclasses and providing consistent serialization methods, GraphRAG achieves a balance of type safety, ease of use, and flexibility.

Key takeaways from this lesson include:

1. GraphRAG uses a hierarchical structure of data models, with base classes like `Identified` and `Named` providing common functionality.

2. The central concepts of the knowledge graph (entities, relationships, and communities) are represented as rich data structures with multiple attributes and references.

3. Source data (documents and text units) are modeled separately, maintaining clear links to the derived knowledge graph elements.

4. The use of dataclasses provides a concise and robust way to define these data structures.

5. Consistent `from_dict` methods across all models ensure uniform data loading and deserialization.

Understanding these core data models is crucial for working with GraphRAG, whether you're using it as is, extending its functionality, or integrating it with other systems. In the next lesson, we'll explore how GraphRAG integrates with Large Language Models (LLMs), building on the foundation of data representation we've established here.

