# Lesson 6: Vector Stores and Embeddings in GraphRAG

## Introduction

In this lesson, we'll explore the vector stores and embeddings functionality in GraphRAG. Vector stores and embeddings play a crucial role in modern natural language processing systems, enabling efficient similarity search and semantic understanding of text data. We'll examine how GraphRAG implements and manages vector stores, how it handles embeddings, and how these components integrate with the broader system.

## File Structure

Before we dive into the details, let's look at the relevant file structure for vector stores and embeddings in GraphRAG:

```
graphrag/
├── vector_stores/
│   ├── __init__.py
│   ├── azure_ai_search.py
│   ├── base.py
│   ├── lancedb.py
│   └── typing.py
└── model/
    ├── __init__.py
    └── types.py
```

This structure shows the organization of vector store-related code in GraphRAG. The `vector_stores/` directory contains implementations for different vector store backends, while the `model/types.py` file includes relevant type definitions.

## 1. Vector Store Abstractions

GraphRAG defines abstract base classes and protocols for vector stores to ensure consistency across different implementations. Let's examine the key abstractions:

### 1.1 BaseVectorStore Abstract Base Class

The `BaseVectorStore` abstract base class, defined in `vector_stores/base.py`, provides the interface for all vector store implementations:

```python
class BaseVectorStore(ABC):
    """The base class for vector storage data-access classes."""

    def __init__(
        self,
        collection_name: str,
        db_connection: Any | None = None,
        document_collection: Any | None = None,
        query_filter: Any | None = None,
        **kwargs: Any,
    ):
        self.collection_name = collection_name
        self.db_connection = db_connection
        self.document_collection = document_collection
        self.query_filter = query_filter
        self.kwargs = kwargs

    @abstractmethod
    def connect(self, **kwargs: Any) -> None:
        """Connect to vector storage."""

    @abstractmethod
    def load_documents(
        self, documents: list[VectorStoreDocument], overwrite: bool = True
    ) -> None:
        """Load documents into the vector-store."""

    @abstractmethod
    def similarity_search_by_vector(
        self, query_embedding: list[float], k: int = 10, **kwargs: Any
    ) -> list[VectorStoreSearchResult]:
        """Perform ANN search by vector."""

    @abstractmethod
    def similarity_search_by_text(
        self, text: str, text_embedder: TextEmbedder, k: int = 10, **kwargs: Any
    ) -> list[VectorStoreSearchResult]:
        """Perform ANN search by text."""

    @abstractmethod
    def filter_by_id(self, include_ids: list[str] | list[int]) -> Any:
        """Build a query filter to filter documents by id."""
```

This abstract base class defines the core functionality that all vector store implementations must provide, including methods for connecting to the store, loading documents, performing similarity searches, and filtering results.

### 1.2 VectorStoreDocument and VectorStoreSearchResult

GraphRAG defines data classes to represent documents and search results in vector stores:

```python
@dataclass
class VectorStoreDocument:
    """A document that is stored in vector storage."""

    id: str | int
    """unique id for the document"""

    text: str | None
    vector: list[float] | None

    attributes: dict[str, Any] = field(default_factory=dict)
    """store any additional metadata, e.g. title, date ranges, etc"""

@dataclass
class VectorStoreSearchResult:
    """A vector storage search result."""

    document: VectorStoreDocument
    """Document that was found."""

    score: float
    """Similarity score between -1 and 1. Higher is more similar."""
```

These data classes provide a consistent structure for working with documents and search results across different vector store implementations.

## 2. Vector Store Implementations

GraphRAG provides implementations for different vector store backends. Let's examine two key implementations:

### 2.1 LanceDBVectorStore

The `LanceDBVectorStore` class, defined in `vector_stores/lancedb.py`, implements the `BaseVectorStore` interface for the LanceDB backend:

```python
class LanceDBVectorStore(BaseVectorStore):
    """The LanceDB vector storage implementation."""

    def connect(self, **kwargs: Any) -> Any:
        """Connect to the vector storage."""
        db_uri = kwargs.get("db_uri", "./lancedb")
        self.db_connection = lancedb.connect(db_uri)  # type: ignore

    def load_documents(
        self, documents: list[VectorStoreDocument], overwrite: bool = True
    ) -> None:
        """Load documents into vector storage."""
        data = [
            {
                "id": document.id,
                "text": document.text,
                "vector": document.vector,
                "attributes": json.dumps(document.attributes),
            }
            for document in documents
            if document.vector is not None
        ]

        # ... (implementation details)

    def similarity_search_by_vector(
        self, query_embedding: list[float], k: int = 10, **kwargs: Any
    ) -> list[VectorStoreSearchResult]:
        """Perform a vector-based similarity search."""
        # ... (implementation details)

    # ... (other method implementations)
```

This implementation provides LanceDB-specific logic for connecting to the database, loading documents, and performing similarity searches.

### 2.2 AzureAISearch

The `AzureAISearch` class, defined in `vector_stores/azure_ai_search.py`, implements the `BaseVectorStore` interface for Azure AI Search:

```python
class AzureAISearch(BaseVectorStore):
    """The Azure AI Search vector storage implementation."""

    index_client: SearchIndexClient

    def connect(self, **kwargs: Any) -> Any:
        """Connect to the AzureAI vector store."""
        url = kwargs.get("url")
        api_key = kwargs.get("api_key")
        audience = kwargs.get("audience")
        self.vector_size = kwargs.get("vector_size", DEFAULT_VECTOR_SIZE)

        # ... (connection logic)

    def load_documents(
        self, documents: list[VectorStoreDocument], overwrite: bool = True
    ) -> None:
        """Load documents into the Azure AI Search index."""
        # ... (implementation details)

    def similarity_search_by_vector(
        self, query_embedding: list[float], k: int = 10, **kwargs: Any
    ) -> list[VectorStoreSearchResult]:
        """Perform a vector-based similarity search."""
        # ... (implementation details)

    # ... (other method implementations)
```

This implementation provides Azure AI Search-specific logic for connecting to the service, creating and managing indexes, and performing similarity searches.

## 3. Embeddings

Embeddings are a crucial component in GraphRAG's vector store functionality. They are used to convert text into dense vector representations that can be efficiently stored and searched in vector stores.

### 3.1 TextEmbedder Type

GraphRAG defines a `TextEmbedder` type in `model/types.py`:

```python
TextEmbedder = Callable[[str], list[float]]
```

This type represents a function that takes a string as input and returns a list of floats (the embedding). This abstraction allows GraphRAG to work with different embedding models or services interchangeably.

### 3.2 Embedding in Vector Store Operations

The `similarity_search_by_text` method in vector store implementations uses a `TextEmbedder` to convert input text to embeddings before performing a search:

```python
def similarity_search_by_text(
    self, text: str, text_embedder: TextEmbedder, k: int = 10, **kwargs: Any
) -> list[VectorStoreSearchResult]:
    """Perform a similarity search using a given input text."""
    query_embedding = text_embedder(text)
    if query_embedding:
        return self.similarity_search_by_vector(query_embedding, k)
    return []
```

This design allows GraphRAG to use different embedding models or services without changing the vector store implementation.

## 4. Vector Store Factory

GraphRAG uses a factory pattern to create vector store instances based on configuration. The `VectorStoreFactory` class in `vector_stores/typing.py` implements this pattern:

```python
class VectorStoreFactory:
    """A factory class for creating vector stores."""

    vector_store_types: ClassVar[dict[str, type]] = {}

    @classmethod
    def register(cls, vector_store_type: str, vector_store: type):
        """Register a vector store type."""
        cls.vector_store_types[vector_store_type] = vector_store

    @classmethod
    def get_vector_store(
        cls, vector_store_type: VectorStoreType | str, kwargs: dict
    ) -> LanceDBVectorStore | AzureAISearch:
        """Get the vector store type from a string."""
        match vector_store_type:
            case VectorStoreType.LanceDB:
                return LanceDBVectorStore(**kwargs)
            case VectorStoreType.AzureAISearch:
                return AzureAISearch(**kwargs)
            case _:
                if vector_store_type in cls.vector_store_types:
                    return cls.vector_store_types[vector_store_type](**kwargs)
                msg = f"Unknown vector store type: {vector_store_type}"
                raise ValueError(msg)
```

This factory allows for easy creation of different vector store instances based on configuration, and it can be extended to support additional vector store types in the future.

## 5. Integration with GraphRAG Workflows

Vector stores and embeddings are integrated throughout GraphRAG's workflows, particularly in tasks related to semantic search and similarity-based retrieval. For example, in a query processing workflow, vector stores might be used to find relevant documents or entities based on the semantic similarity of their embeddings to the query embedding.

Here's a simplified example of how vector stores might be used in a query processing workflow:

```python
async def process_query(query: str, vector_store: BaseVectorStore, text_embedder: TextEmbedder):
    # Generate query embedding
    query_embedding = text_embedder(query)

    # Perform similarity search
    search_results = vector_store.similarity_search_by_vector(query_embedding, k=10)

    # Process search results
    for result in search_results:
        # ... (process each result)

    # Generate response based on search results
    response = generate_response(query, search_results)

    return response
```

This integration allows GraphRAG to leverage the power of semantic search in its query processing and information retrieval tasks.

## Conclusion

GraphRAG's vector store and embedding system provides a flexible and extensible framework for managing and searching vector representations of text data. By using abstract base classes and protocols, it allows for easy implementation of different vector store backends and embedding models to suit various use cases and environments.

Key takeaways from this lesson include:
1. The use of abstract base classes to define a consistent interface for vector stores.
2. Implementation of different vector store backends (LanceDB and Azure AI Search) adhering to the common interface.
3. The abstraction of text embedding functionality through the `TextEmbedder` type.
4. Use of a factory pattern for creating appropriate vector store instances based on configuration.
5. Integration of vector stores and embeddings into GraphRAG's workflows for semantic search and similarity-based retrieval.

Understanding these concepts is crucial for effectively working with vector-based representations in GraphRAG, as well as for extending the system with custom vector store implementations or embedding models if needed.

## Review Questions

1. What are the main components of GraphRAG's vector store system, and how do they interact?
2. How does the `BaseVectorStore` abstract base class contribute to the flexibility of GraphRAG's vector store system?
3. Describe the purpose and implementation of the `LanceDBVectorStore` class. How does it differ from the `AzureAISearch` implementation?
4. What is the role of the `VectorStoreFactory` class, and how does it support extensibility in GraphRAG's vector store system?
5. How are embeddings represented and used in GraphRAG's vector store operations?
6. Explain the purpose of the `similarity_search_by_text` method in vector store implementations. How does it leverage the `TextEmbedder` type?
7. How might vector stores and embeddings be used in a typical GraphRAG workflow, such as query processing or information retrieval?
8. Describe how you would extend GraphRAG's vector store system to support a new type of vector database (e.g., Pinecone or Weaviate).

## Hands-on Exercise

1. Implement a simple in-memory vector store that adheres to the `BaseVectorStore` interface. This store should maintain vectors in memory and support basic similarity search operations.

2. Create a basic text embedding function that converts text to vectors using a simple method (e.g., averaging word vectors from a pre-trained word embedding model like Word2Vec or GloVe).

3. Extend the `VectorStoreFactory` to support your new in-memory vector store implementation.

4. Write a script that demonstrates the use of your in-memory vector store and embedding function. The script should:
   - Load a small corpus of text documents
   - Generate embeddings for these documents
   - Store the embeddings in your in-memory vector store
   - Perform similarity searches using both vector and text inputs

5. Implement a simple caching mechanism for your text embedding function to avoid recomputing embeddings for previously seen text.

6. Create a basic benchmark that compares the performance of your in-memory vector store with one of the existing implementations (e.g., LanceDBVectorStore) for a series of search operations.

This exercise will give you hands-on experience with the key concepts of vector stores and embeddings in GraphRAG, including implementation of the core interfaces, creation of custom vector stores and embedding functions, and integration of these components into a workflow.

By completing this exercise, you'll gain a deeper understanding of how GraphRAG manages vector-based representations and similarity search, and you'll be better prepared to work with or extend these functionalities in real-world applications using the Graph RAG framework.

7. Implement a simple dimensionality reduction technique (e.g., Principal Component Analysis or PCA) to compress your embeddings. Modify your in-memory vector store to support both full-dimensional and reduced-dimensional vectors. Compare the performance and accuracy of similarity searches using both representations.

8. Create a simple visualization tool that plots the embeddings of your documents in 2D space (you can use techniques like t-SNE or UMAP for dimensionality reduction). This will help you understand the distribution of your document embeddings and the effectiveness of your similarity search.

9. Implement a basic index structure (e.g., a ball tree or KD-tree) in your in-memory vector store to optimize similarity search for larger datasets. Compare the performance of brute-force search versus indexed search as your dataset size increases.

10. Extend your vector store implementation to support incremental updates. This should allow you to add new documents or update existing ones without rebuilding the entire index.

11. Implement a simple query expansion technique that enhances the input query with related terms before performing the similarity search. Compare the search results with and without query expansion.

12. Create a basic evaluation framework that measures the relevance of search results. You can use metrics like precision@k or mean average precision (MAP) to quantify the quality of your similarity search results.

This extended exercise will give you a more comprehensive understanding of vector stores and embeddings, and how they can be optimized and evaluated in real-world scenarios. It will also provide practice in implementing more advanced features that are often found in production-grade vector search systems.

By completing these additional tasks, you'll gain insight into:
- Techniques for optimizing vector representations and similarity search
- Methods for visualizing high-dimensional data
- Advanced indexing structures for efficient similarity search
- Strategies for maintaining and updating vector indexes
- Techniques for improving search quality through query expansion
- Approaches to evaluating the performance and quality of similarity search systems

These skills will be valuable not only for working with GraphRAG but also for developing and optimizing vector-based search systems in general. They will help you understand the trade-offs between search speed, memory usage, and result quality, which are crucial considerations in designing efficient and effective information retrieval systems.

