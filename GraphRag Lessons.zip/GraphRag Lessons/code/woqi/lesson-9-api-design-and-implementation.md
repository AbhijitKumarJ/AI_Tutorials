# Lesson 9: API Design and Implementation in GraphRAG

In this lesson, we will explore the API design and implementation in the GraphRAG codebase. The API layer is crucial as it provides the interface through which users and other systems interact with GraphRAG. We'll examine how the indexing and query functionalities are exposed through well-defined APIs, and how these APIs are implemented to ensure efficiency, flexibility, and ease of use.

## 1. Project Structure Overview

Before we dive into the details, let's look at the relevant file structure for this lesson:

```
graphrag/
└── api/
    ├── index_api.py
    ├── prompt_tune_api.py
    ├── query_api.py
    └── __init__.py
```

This structure shows that the API functionality is organized in the `api` directory, with separate files for different API categories. We'll focus primarily on `index_api.py` and `query_api.py` in this lesson.

## 2. Indexing API Implementation

Let's start by examining the indexing API implementation. This API is responsible for building and managing the knowledge graph that forms the core of GraphRAG's functionality.

### 2.1 File: api/index_api.py

```python
# Copyright (c) 2024 Microsoft Corporation.
# Licensed under the MIT License

"""
Indexing API for GraphRAG.

WARNING: This API is under development and may undergo changes in future releases.
Backwards compatibility is not guaranteed at this time.
"""

from graphrag.config import CacheType, GraphRagConfig
from graphrag.index.cache.noop_pipeline_cache import NoopPipelineCache
from graphrag.index.create_pipeline_config import create_pipeline_config
from graphrag.index.emit.types import TableEmitterType
from graphrag.index.run import run_pipeline_with_config
from graphrag.index.typing import PipelineRunResult
from graphrag.logging import ProgressReporter

async def build_index(
    config: GraphRagConfig,
    run_id: str = "",
    is_resume_run: bool = False,
    is_update_run: bool = False,
    memory_profile: bool = False,
    progress_reporter: ProgressReporter | None = None,
    emit: list[TableEmitterType] = [TableEmitterType.Parquet],  # noqa: B006
) -> list[PipelineRunResult]:
    """Run the pipeline with the given configuration.

    Parameters
    ----------
    config : PipelineConfig
        The configuration.
    run_id : str
        The run id. Creates a output directory with this name.
    is_resume_run : bool default=False
        Whether to resume a previous index run.
    is_update_run : bool default=False
        Whether to update a previous index run.
    memory_profile : bool
        Whether to enable memory profiling.
    progress_reporter : ProgressReporter | None default=None
        The progress reporter.
    emit : list[str]
        The list of emitter types to emit.
        Accepted values {"parquet", "csv"}.

    Returns
    -------
    list[PipelineRunResult]
        The list of pipeline run results
    """
    if is_resume_run and is_update_run:
        msg = "Cannot resume and update a run at the same time."
        raise ValueError(msg)

    pipeline_config = create_pipeline_config(config)
    pipeline_cache = (
        NoopPipelineCache() if config.cache.type == CacheType.none is None else None
    )
    outputs: list[PipelineRunResult] = []
    async for output in run_pipeline_with_config(
        pipeline_config,
        run_id=run_id,
        memory_profile=memory_profile,
        cache=pipeline_cache,
        progress_reporter=progress_reporter,
        emit=emit,
        is_resume_run=is_resume_run,
        is_update_run=is_update_run,
    ):
        outputs.append(output)
        if progress_reporter:
            if output.errors and len(output.errors) > 0:
                progress_reporter.error(output.workflow)
            else:
                progress_reporter.success(output.workflow)
            progress_reporter.info(str(output.result))
    return outputs
```

This file defines the `build_index` function, which serves as the main entry point for the indexing process in GraphRAG. Let's break down its key components and functionalities:

1. **Function Signature**: The function is defined as asynchronous (`async def`), allowing for non-blocking execution. This is particularly important for long-running indexing processes, as it allows the system to handle other tasks concurrently.

2. **Parameters**: 
   - `config`: A `GraphRagConfig` object that contains all the configuration settings for the indexing process.
   - `run_id`: A string identifier for the current run, used to create a unique output directory.
   - `is_resume_run` and `is_update_run`: Boolean flags to control whether the run should resume a previous indexing process or update an existing index.
   - `memory_profile`: A flag to enable memory profiling, useful for performance optimization.
   - `progress_reporter`: An optional `ProgressReporter` object to provide feedback on the indexing progress.
   - `emit`: A list of `TableEmitterType` values specifying the output formats for the indexed data.

3. **Input Validation**: The function starts with a check to ensure that `is_resume_run` and `is_update_run` are not both True, as these are mutually exclusive operations.

4. **Pipeline Configuration**: The function creates a pipeline configuration using the `create_pipeline_config` function, which likely translates the high-level `GraphRagConfig` into a more detailed configuration for the indexing pipeline.

5. **Caching**: The function sets up a pipeline cache, using a `NoopPipelineCache` if the cache type is set to "none" in the configuration. This allows for flexible caching strategies depending on the user's needs.

6. **Pipeline Execution**: The core of the function is the asynchronous loop that runs the indexing pipeline:
   ```python
   async for output in run_pipeline_with_config(
       pipeline_config,
       run_id=run_id,
       memory_profile=memory_profile,
       cache=pipeline_cache,
       progress_reporter=progress_reporter,
       emit=emit,
       is_resume_run=is_resume_run,
       is_update_run=is_update_run,
   ):
   ```
   This loop iterates over the outputs of the `run_pipeline_with_config` function, which is likely where the actual indexing work happens.

7. **Progress Reporting**: For each output from the pipeline, the function updates the progress reporter (if provided) with success, error, or info messages. This allows for real-time feedback on the indexing process.

8. **Result Aggregation**: The function collects all the `PipelineRunResult` objects in a list, which is then returned to the caller.

This API design showcases several important principles:

- **Asynchronous Design**: The use of async/await allows for efficient handling of I/O-bound operations, which are common in indexing tasks.
- **Configurability**: The function accepts a comprehensive configuration object, allowing for flexible customization of the indexing process.
- **Progress Reporting**: The integration of a progress reporter allows for real-time feedback, which is crucial for long-running processes.
- **Error Handling**: The function includes basic error checking (e.g., the mutual exclusivity of resume and update runs) and propagates errors from the underlying pipeline.
- **Flexibility**: The API supports different run modes (new, resume, update) and output formats, making it adaptable to various use cases.

## 3. Query API Implementation

Now, let's examine the query API implementation. This API is responsible for executing queries against the knowledge graph built by the indexing process.

### 3.1 File: api/query_api.py

```python
# Copyright (c) 2024 Microsoft Corporation.
# Licensed under the MIT License

"""
Query Engine API.

This API provides access to the query engine of graphrag, allowing external applications
to hook into graphrag and run queries over a knowledge graph generated by graphrag.

Contains the following functions:
 - global_search: Perform a global search.
 - global_search_streaming: Perform a global search and stream results back.
 - local_search: Perform a local search.
 - local_search_streaming: Perform a local search and stream results back.

WARNING: This API is under development and may undergo changes in future releases.
Backwards compatibility is not guaranteed at this time.
"""

from collections.abc import AsyncGenerator
from pathlib import Path
from typing import Any

import pandas as pd
from pydantic import validate_call

from graphrag.config import GraphRagConfig
from graphrag.logging import PrintProgressReporter
from graphrag.model.entity import Entity
from graphrag.query.factories import get_global_search_engine, get_local_search_engine
from graphrag.query.indexer_adapters import (
    read_indexer_covariates,
    read_indexer_entities,
    read_indexer_relationships,
    read_indexer_reports,
    read_indexer_text_units,
)
from graphrag.query.input.loaders.dfs import store_entity_semantic_embeddings
from graphrag.query.structured_search.base import SearchResult  # noqa: TCH001
from graphrag.vector_stores.lancedb import LanceDBVectorStore
from graphrag.vector_stores.typing import VectorStoreFactory, VectorStoreType

reporter = PrintProgressReporter("")

@validate_call(config={"arbitrary_types_allowed": True})
async def global_search(
    config: GraphRagConfig,
    nodes: pd.DataFrame,
    entities: pd.DataFrame,
    community_reports: pd.DataFrame,
    community_level: int,
    response_type: str,
    query: str,
) -> tuple[
    str | dict[str, Any] | list[dict[str, Any]],
    str | list[pd.DataFrame] | dict[str, pd.DataFrame],
]:
    """Perform a global search and return the context data and response.

    Parameters
    ----------
    - config (GraphRagConfig): A graphrag configuration (from settings.yaml)
    - nodes (pd.DataFrame): A DataFrame containing the final nodes (from create_final_nodes.parquet)
    - entities (pd.DataFrame): A DataFrame containing the final entities (from create_final_entities.parquet)
    - community_reports (pd.DataFrame): A DataFrame containing the final community reports (from create_final_community_reports.parquet)
    - community_level (int): The community level to search at.
    - response_type (str): The type of response to return.
    - query (str): The user query to search for.

    Returns
    -------
    TODO: Document the search response type and format.

    Raises
    ------
    TODO: Document any exceptions to expect.
    """
    reports = read_indexer_reports(community_reports, nodes, community_level)
    _entities = read_indexer_entities(nodes, entities, community_level)
    search_engine = get_global_search_engine(
        config,
        reports=reports,
        entities=_entities,
        response_type=response_type,
    )
    result: SearchResult = await search_engine.asearch(query=query)
    response = result.response
    context_data = _reformat_context_data(result.context_data)  # type: ignore
    return response, context_data

@validate_call(config={"arbitrary_types_allowed": True})
async def global_search_streaming(
    config: GraphRagConfig,
    nodes: pd.DataFrame,
    entities: pd.DataFrame,
    community_reports: pd.DataFrame,
    community_level: int,
    response_type: str,
    query: str,
) -> AsyncGenerator:
    """Perform a global search and return the context data and response via a generator.

    Context data is returned as a dictionary of lists, with one list entry for each record.

    Parameters
    ----------
    - config (GraphRagConfig): A graphrag configuration (from settings.yaml)
    - nodes (pd.DataFrame): A DataFrame containing the final nodes (from create_final_nodes.parquet)
    - entities (pd.DataFrame): A DataFrame containing the final entities (from create_final_entities.parquet)
    - community_reports (pd.DataFrame): A DataFrame containing the final community reports (from create_final_community_reports.parquet)
    - community_level (int): The community level to search at.
    - response_type (str): The type of response to return.
    - query (str): The user query to search for.

    Returns
    -------
    TODO: Document the search response type and format.

    Raises
    ------
    TODO: Document any exceptions to expect.
    """
    reports = read_indexer_reports(community_reports, nodes, community_level)
    _entities = read_indexer_entities(nodes, entities, community_level)
    search_engine = get_global_search_engine(
        config,
        reports=reports,
        entities=_entities,
        response_type=response_type,
    )
    search_result = search_engine.astream_search(query=query)

    # when streaming results, a context data object is returned as the first result
    # and the query response in subsequent tokens
    context_data = None
    get_context_data = True
    async for stream_chunk in search_result:
        if get_context_data:
            context_data = _reformat_context_data(stream_chunk)  # type: ignore
            yield context_data
            get_context_data = False
        else:
            yield stream_chunk

@validate_call(config={"arbitrary_types_allowed": True})
async def local_search(
    config: GraphRagConfig,
    nodes: pd.DataFrame,
    entities: pd.DataFrame,
    community_reports: pd.DataFrame,
    text_units: pd.DataFrame,
    relationships: pd.DataFrame,
    covariates: pd.DataFrame | None,
    community_level: int,
    response_type: str,
    query: str,
) -> tuple[
    str | dict[str, Any] | list[dict[str, Any]],
    str | list[pd.DataFrame] | dict[str, pd.DataFrame],
]:
    """Perform a local search and return the context data and response.

    Parameters
    ----------
    - config (GraphRagConfig): A graphrag configuration (from settings.yaml)
    - nodes (pd.DataFrame): A DataFrame containing the final nodes (from create_final_nodes.parquet)
    - entities (pd.DataFrame): A DataFrame containing the final entities (from create_final_entities.parquet)
    - community_reports (pd.DataFrame): A DataFrame containing the final community reports (from create_final_community_reports.parquet)
    - text_units (pd.DataFrame): A DataFrame containing the final text units (from create_final_text_units.parquet)
    - relationships (pd.DataFrame): A DataFrame containing the final relationships (from create_final_relationships.parquet)
    - covariates (pd.DataFrame): A DataFrame containing the final covariates (from create_final_covariates.parquet)
    - community_level (int): The community level to search at.
    - response_type (str): The response type to return.
    - query (str): The user query to search for.

    Returns
    -------
    TODO: Document the search response type and format.

    Raises
    ------
    TODO: Document any exceptions to expect.
    """
    vector_store_args = (
        config.embeddings.vector_store if config.embeddings.vector_store else {}
    )
    reporter.info(f"Vector Store Args: {vector_store_args}")

    vector_store_type = vector_store_args.get("type", VectorStoreType.LanceDB)

    _entities = read_indexer_entities(nodes, entities, community_level)

    lancedb_dir = Path(config.storage.base_dir) / "lancedb"

    vector_store_args.update({"db_uri": str(lancedb_dir)})
    description_embedding_store = _get_embedding_description_store(
        entities=_entities,
        vector_store_type=vector_store_type,
        config_args=vector_store_args,
    )

    _covariates = read_indexer_covariates(covariates) if covariates is not None else []

    search_engine = get_local_search_engine(
        config=config,
        reports=read_indexer_reports(community_reports, nodes, community_level),
        text_units=read_indexer_text_units(text_units),
        entities=_entities,
        relationships=read_indexer_relationships(relationships),
        covariates={"claims": _covariates},
        description_embedding_store=description_embedding_store,
        response_type=response_type,
    )

    result: SearchResult = await search_engine.asearch(query=query)
    response = result.response
    context_data = _reformat_context_data(result.context_data)  # type: ignore
    return response, context_data

@validate_call(config={"arbitrary_types_allowed": True})
async def local_search_streaming(
    config: GraphRagConfig,
    nodes: pd.DataFrame,
    entities: pd.DataFrame,
    community_reports: pd.DataFrame,
    text_units: pd.DataFrame,
    relationships: pd.DataFrame,
    covariates: pd.DataFrame | None,
    community_level: int,
    response_type: str,
    query: str,
) -> AsyncGenerator:
    """Perform a local search and return the context data and response via a generator.

    Parameters
    ----------
    - config (GraphRagConfig): A graphrag configuration (from settings.yaml)
    - nodes (pd.DataFrame): A DataFrame containing the final nodes (from create_final_nodes.parquet)
    - entities (pd.DataFrame): A DataFrame containing the final entities (from create_final_entities.parquet)
    - community_reports (pd.DataFrame): A DataFrame containing the final community reports (from create_final_community_reports.parquet)
    - text_units (pd.DataFrame): A DataFrame containing the final text units (from create_final_text_units.parquet)
    - relationships (pd.DataFrame): A DataFrame containing the final relationships (from create_final_relationships.parquet)
    - covariates (pd.DataFrame): A DataFrame containing the final covariates (from create_final_covariates.parquet)
    - community_level (int): The community level to search at.
    - response_type (str): The response type to return.
    - query (str): The user query to search for.

    Returns
    -------
    TODO: Document the search response type and format.

    Raises
    ------
    TODO: Document any exceptions to expect.
    """
    vector_store_args = (
        config.embeddings.vector_store if config.embeddings.vector_store else {}
    )
    reporter.info(f"Vector Store Args: {vector_store_args}")

    vector_store_type = vector_store_args.get("type", VectorStoreType.LanceDB)

    _entities = read_indexer_entities(nodes, entities, community_level)

    lancedb_dir = Path(config.storage.base_dir) / "lancedb"

    vector_store_args.update({"db_uri": str(lancedb_dir)})
    description_embedding_store = _get_embedding_description_store(
        entities=_entities,
        vector_store_type=vector_store_type,
        config_args=vector_store_args,
    )

    _covariates = read_indexer_covariates(covariates) if covariates is not None else []

    search_engine = get_local_search_engine(
        config=config,
        reports=read_indexer_reports(community_reports, nodes, community_level),
        text_units=read_indexer_text_units(text_units),
        entities=_entities,
        relationships=read_indexer_relationships(relationships),
        covariates={"claims": _covariates},
        description_embedding_store=description_embedding_store,
        response_type=response_type,
    )
    search_result = search_engine.astream_search(query=query)

    # when streaming results, a context data object is returned as the first result
    # and the query response in subsequent tokens
    context_data = None
    get_context_data = True
    async for stream_chunk in search_result:
        if get_context_data:
            context_data = _reformat_context_data(stream_chunk)  # type: ignore
            yield context_data
            get_context_data = False
        else:
            yield stream_chunk
```

This file defines four main functions for querying the GraphRAG system: `global_search`, `global_search_streaming`, `local_search`, and `local_search_streaming`. Let's break down the key components and functionalities:

1. **Global vs. Local Search**: The API provides both global and local search capabilities. Global search likely operates on the entire knowledge graph, while local search might focus on specific communities or subgraphs.

2. **Streaming vs. Non-Streaming**: For both global and local searches, there are streaming and non-streaming versions. The streaming versions return an `AsyncGenerator`, allowing for real-time processing of results as they become available.

3. **Input Data**: All search functions take various DataFrame inputs (nodes, entities, community_reports, etc.) along with the GraphRAG configuration and query string. This allows for flexible querying of different aspects of the knowledge graph.

4. **Vector Store Integration**: The local search functions integrate with a vector store (defaulting to LanceDB) for efficient similarity search of entity embeddings.

5. **Search Engine Factory**: The functions use factory methods (`get_global_search_engine` and `get_local_search_engine`) to create the appropriate search engine based on the configuration and input data.

6. **Asynchronous Design**: All functions are asynchronous, allowing for non-blocking execution of potentially long-running search operations.

7. **Type Validation**: The `@validate_call` decorator is used to enforce type checking on the function parameters, enhancing the robustness of the API.

8. **Context Data Reformatting**: The `_reformat_context_data` function is used to standardize the format of the context data returned by the search engines.

Key Design Principles:

1. **Flexibility**: The API supports different types of searches (global/local) and result delivery methods (streaming/non-streaming), catering to various use cases.

2. **Modularity**: The use of factory methods for creating search engines allows for easy extension or modification of search capabilities.

3. **Performance**: The integration with vector stores and the use of streaming results demonstrate a focus on performance, particularly for large-scale knowledge graphs.

4. **Type Safety**: The use of type hints and the `@validate_call` decorator ensures that the API is used correctly, reducing the likelihood of runtime errors.

5. **Extensibility**: The API is designed to work with different types of vector stores and can be easily extended to support new search strategies or data sources.

Conclusion:

The API design in GraphRAG showcases a well-thought-out approach to providing flexible and performant access to the underlying knowledge graph. By offering both global and local search capabilities, as well as streaming and non-streaming options, the API caters to a wide range of use cases and performance requirements.

The asynchronous nature of the API allows for efficient handling of potentially long-running operations, while the use of type validation and factory methods promotes code robustness and extensibility.

One area for potential improvement is the documentation of return types and possible exceptions, as indicated by the TODO comments in the function docstrings. Completing this documentation would further enhance the usability of the API.

Overall, this API design provides a solid foundation for building applications that leverage the power of GraphRAG's knowledge graph capabilities.

