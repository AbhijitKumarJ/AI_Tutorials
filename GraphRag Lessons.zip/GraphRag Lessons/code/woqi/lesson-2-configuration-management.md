# Lesson 2: Configuration Management in GraphRAG

## 1. Introduction to Configuration Management in GraphRAG

Configuration management is a crucial aspect of any large-scale software system, and GraphRAG is no exception. Proper configuration management allows a system to be flexible, adaptable to different environments, and easily maintainable. In this lesson, we'll explore how GraphRAG implements its configuration system, focusing on the following key areas:

1. The structure and components of the config module
2. Configuration models and input models
3. Environment variable handling and .env files
4. Configuration loading and validation processes

By the end of this lesson, you'll have a deep understanding of how GraphRAG manages its configuration, enabling you to effectively customize and deploy the system in various scenarios.

## 2. The Config Module Structure

The configuration system in GraphRAG is primarily implemented in the `config/` directory. Let's examine its structure in more detail:

```
config/
├── __init__.py
├── config_file_loader.py
├── create_graphrag_config.py
├── defaults.py
├── enums.py
├── environment_reader.py
├── errors.py
├── load_config.py
├── logging.py
├── read_dotenv.py
├── resolve_path.py
├── input_models/
│   ├── __init__.py
│   ├── cache_config_input.py
│   ├── chunking_config_input.py
│   ├── claim_extraction_config_input.py
│   └── ... (other input model files)
└── models/
    ├── __init__.py
    ├── cache_config.py
    ├── chunking_config.py
    ├── claim_extraction_config.py
    └── ... (other model files)
```

This structure reveals a well-organized approach to configuration management. Let's break down the key components:

### 2.1 Core Configuration Files

- `config_file_loader.py`: This file likely contains functions for loading configuration from files (e.g., YAML or JSON).
- `create_graphrag_config.py`: This file is responsible for creating the main GraphRAG configuration object.
- `defaults.py`: Defines default values for various configuration settings.
- `enums.py`: Contains enumeration classes used in the configuration system.
- `environment_reader.py`: Implements functionality for reading configuration values from environment variables.
- `errors.py`: Defines custom exception classes for configuration-related errors.
- `load_config.py`: Coordinates the overall process of loading and validating the configuration.
- `logging.py`: Configures logging for the configuration system.
- `read_dotenv.py`: Implements functionality for reading .env files.
- `resolve_path.py`: Likely contains utilities for resolving file paths in the configuration.

### 2.2 Input Models and Models

The `input_models/` and `models/` directories contain Pydantic model definitions for various aspects of the configuration. The separation into two directories suggests a two-stage approach to configuration:

1. `input_models/`: These likely represent the raw input format of the configuration, possibly directly mapping to configuration file structures or environment variables.
2. `models/`: These are probably the final, validated configuration models used throughout the system.

This separation allows for a clear distinction between the input format and the internal representation, enabling additional processing or validation steps between the two.

## 3. Configuration Models and Input Models

Let's dive deeper into the configuration models and input models used in GraphRAG.

### 3.1 Input Models

Input models serve as the initial representation of configuration data, often directly mapping to the structure of configuration files or environment variables. Here's an example of what an input model might look like, based on the file names we see:

```python
# config/input_models/cache_config_input.py

from typing import Optional
from pydantic import BaseModel

class CacheConfigInput(BaseModel):
    type: Optional[str] = None
    base_dir: Optional[str] = None
    connection_string: Optional[str] = None
    container_name: Optional[str] = None
```

This input model defines the structure of the cache configuration as it might appear in a configuration file. The use of `Optional` fields allows for partial configurations, with missing values potentially filled in by defaults or other sources.

### 3.2 Configuration Models

Configuration models represent the final, validated configuration used throughout the system. They often include additional logic for derived values, constraints, and inter-field validations. Here's an example of what a configuration model might look like:

```python
# config/models/cache_config.py

from pydantic import BaseModel, Field
from graphrag.config.enums import CacheType

class CacheConfig(BaseModel):
    type: CacheType = Field(default=CacheType.file)
    base_dir: str = Field(default="cache")
    connection_string: Optional[str] = None
    container_name: Optional[str] = None

    @property
    def is_remote(self) -> bool:
        return self.type in {CacheType.blob, CacheType.redis}

    class Config:
        use_enum_values = True
```

This configuration model adds several enhancements over the input model:

1. It uses an enumeration (`CacheType`) for the `type` field, ensuring only valid cache types are used.
2. It provides default values for some fields.
3. It includes a derived property (`is_remote`) that computes a value based on other fields.
4. It uses Pydantic's `Config` class to specify model-wide behaviors.

### 3.3 Main Configuration Model

The main configuration model for GraphRAG likely brings together all the individual configuration components. It might look something like this:

```python
# config/models/graph_rag_config.py

from pydantic import BaseModel, Field
from .cache_config import CacheConfig
from .llm_config import LLMConfig
# ... other imports ...

class GraphRagConfig(BaseModel):
    root_dir: str
    cache: CacheConfig = Field(default_factory=CacheConfig)
    llm: LLMConfig
    # ... other configuration fields ...

    class Config:
        extra = "forbid"
```

This main configuration model demonstrates how GraphRAG composes its configuration from multiple sub-configurations, each handled by its own model. The `extra = "forbid"` setting ensures that no unexpected configuration keys are present, adding an extra layer of validation.

## 4. Environment Variable Handling and .env Files

GraphRAG implements a flexible system for loading configuration values from environment variables and .env files. This approach allows for easy configuration in different deployment environments and secure handling of sensitive information like API keys.

### 4.1 Reading .env Files

The `read_dotenv.py` file likely contains functionality for loading environment variables from a .env file. Here's a possible implementation:

```python
# config/read_dotenv.py

import os
from pathlib import Path
from dotenv import load_dotenv

def read_dotenv(path: str | Path | None = None) -> None:
    """Read environment variables from a .env file."""
    dotenv_path = Path(path or ".") / ".env"
    if dotenv_path.exists():
        load_dotenv(dotenv_path)
```

This function allows GraphRAG to load environment variables from a .env file, either at a specified path or in the current directory. This is particularly useful for development environments or when deploying in containers.

### 4.2 Environment Variable Reading

The `environment_reader.py` file implements more sophisticated environment variable handling. It likely includes functionality for:

1. Reading variables with fallback values
2. Type conversion (e.g., parsing strings into integers or booleans)
3. Handling nested configurations using prefix-based naming conventions

Here's a simplified example of what this might look like:

```python
# config/environment_reader.py

import os
from typing import Any, Optional

class EnvironmentReader:
    def __init__(self, prefix: str = "GRAPHRAG_"):
        self.prefix = prefix

    def get(self, key: str, default: Any = None) -> Any:
        return os.getenv(f"{self.prefix}{key.upper()}", default)

    def get_int(self, key: str, default: Optional[int] = None) -> Optional[int]:
        value = self.get(key)
        return int(value) if value is not None else default

    def get_bool(self, key: str, default: Optional[bool] = None) -> Optional[bool]:
        value = self.get(key)
        if value is not None:
            return value.lower() in ("true", "1", "yes")
        return default
```

This `EnvironmentReader` class provides a convenient interface for reading and parsing environment variables, with support for different data types and default values.

## 5. Configuration Loading and Validation

The process of loading and validating the configuration in GraphRAG is likely orchestrated by the `load_config.py` file. This process typically involves several steps:

1. Loading raw configuration data from files and/or environment variables
2. Parsing this data into input models
3. Validating and transforming the input models into final configuration models
4. Performing any necessary post-processing or derived calculations

Here's a simplified example of what this process might look like:

```python
# config/load_config.py

from pathlib import Path
from .config_file_loader import load_config_file
from .environment_reader import EnvironmentReader
from .input_models import GraphRagConfigInput
from .models import GraphRagConfig

def load_config(config_path: Path | str | None = None) -> GraphRagConfig:
    # Load configuration from file
    raw_config = load_config_file(config_path) if config_path else {}

    # Read environment variables
    env_reader = EnvironmentReader()
    env_config = {
        "root_dir": env_reader.get("ROOT_DIR"),
        "cache": {
            "type": env_reader.get("CACHE_TYPE"),
            "base_dir": env_reader.get("CACHE_BASE_DIR"),
        },
        # ... other configuration fields ...
    }

    # Merge file config and environment config
    merged_config = {**raw_config, **env_config}

    # Parse into input model
    config_input = GraphRagConfigInput(**merged_config)

    # Validate and create final config model
    return GraphRagConfig(**config_input.dict())
```

This loading process ensures that configuration values are properly loaded, merged, and validated before being used in the system. The use of Pydantic models at both the input and final stages provides robust type checking and validation.

## 6. Error Handling in Configuration

Proper error handling is crucial in configuration management to provide clear feedback when configuration issues arise. GraphRAG implements custom exception classes for this purpose in the `errors.py` file:

```python
# config/errors.py

class ConfigurationError(Exception):
    """Base class for configuration errors."""

class MissingConfigurationError(ConfigurationError):
    """Raised when a required configuration value is missing."""

class InvalidConfigurationError(ConfigurationError):
    """Raised when a configuration value is invalid."""

class ConfigurationFileNotFoundError(ConfigurationError):
    """Raised when a specified configuration file is not found."""
```

These custom exception classes allow for more specific error handling and reporting throughout the configuration loading and validation process.

## Conclusion

GraphRAG's configuration management system demonstrates a well-thought-out approach to handling complex configuration requirements. By leveraging Pydantic for model definitions and validation, supporting multiple configuration sources (files and environment variables), and implementing robust error handling, GraphRAG achieves a flexible and reliable configuration system.

Key takeaways from this lesson include:

1. The use of separate input models and final configuration models allows for clear distinction between raw input and validated configuration.
2. Environment variable support, including .env file handling, enables easy configuration in various deployment scenarios.
3. The modular structure of the configuration system makes it easy to add or modify configuration options as the system evolves.
4. Strong typing and validation through Pydantic models help catch configuration errors early and provide clear feedback.

Understanding this configuration system is crucial for effectively deploying and customizing GraphRAG in different environments and use cases. In the next lesson, we'll explore the core data models used throughout GraphRAG, building on the foundation of configuration management we've established here.

