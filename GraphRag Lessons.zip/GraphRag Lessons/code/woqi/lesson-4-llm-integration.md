# Lesson 4: Large Language Model (LLM) Integration in GraphRAG

## Introduction

In this lesson, we'll dive deep into the Large Language Model (LLM) integration within the GraphRAG system. LLMs are a crucial component of GraphRAG, enabling sophisticated natural language processing tasks such as text generation, completion, and embedding. We'll explore how GraphRAG implements and manages these models, focusing on the architecture, error handling, rate limiting, and caching mechanisms.

## File Structure

Before we begin, let's look at the relevant file structure for LLM integration in GraphRAG:

```
graphrag/
├── llm/
│   ├── __init__.py
│   ├── errors.py
│   ├── base/
│   │   ├── __init__.py
│   │   ├── base_llm.py
│   │   ├── caching_llm.py
│   │   ├── rate_limiting_llm.py
│   │   └── _create_cache_key.py
│   ├── limiting/
│   │   ├── __init__.py
│   │   ├── composite_limiter.py
│   │   ├── create_limiters.py
│   │   ├── llm_limiter.py
│   │   ├── noop_llm_limiter.py
│   │   └── tpm_rpm_limiter.py
│   ├── mock/
│   │   ├── __init__.py
│   │   ├── mock_chat_llm.py
│   │   └── mock_completion_llm.py
│   ├── openai/
│   │   ├── __init__.py
│   │   ├── create_openai_client.py
│   │   ├── factories.py
│   │   ├── json_parsing_llm.py
│   │   ├── openai_chat_llm.py
│   │   ├── openai_completion_llm.py
│   │   ├── openai_configuration.py
│   │   ├── openai_embeddings_llm.py
│   │   ├── openai_history_tracking_llm.py
│   │   ├── openai_token_replacing_llm.py
│   │   ├── types.py
│   │   ├── utils.py
│   │   └── _prompts.py
│   └── types/
│       ├── __init__.py
│       ├── llm.py
│       ├── llm_cache.py
│       ├── llm_callbacks.py
│       ├── llm_config.py
│       ├── llm_invocation_result.py
│       ├── llm_io.py
│       └── llm_types.py
```

This structure shows the organization of LLM-related code in GraphRAG. The `llm/` directory contains various subdirectories and files that handle different aspects of LLM integration.

## 1. Core LLM Abstractions

At the heart of GraphRAG's LLM integration is a set of abstract base classes that define the interface for working with language models. Let's examine the key abstractions:

### 1.1 BaseLLM

The `BaseLLM` class, defined in `llm/base/base_llm.py`, serves as the foundation for all LLM implementations in GraphRAG. It provides a common interface for executing LLM operations:

```python
class BaseLLM(ABC, LLM[TIn, TOut], Generic[TIn, TOut]):
    _on_error: ErrorHandlerFn | None

    def on_error(self, on_error: ErrorHandlerFn | None) -> None:
        self._on_error = on_error

    @abstractmethod
    async def _execute_llm(
        self,
        input: TIn,
        **kwargs: Unpack[LLMInput],
    ) -> TOut | None:
        pass

    async def __call__(
        self,
        input: TIn,
        **kwargs: Unpack[LLMInput],
    ) -> LLMOutput[TOut]:
        if kwargs.get("json"):
            return await self._invoke_json(input, **kwargs)
        return await self._invoke(input, **kwargs)

    # ... (other methods)
```

This abstract base class defines the core structure for LLM implementations, including error handling and the main execution method (`__call__`). It uses generics to allow for different input and output types, making it flexible for various LLM use cases.

### 1.2 LLM Protocol

The `LLM` protocol, defined in `llm/types/llm.py`, specifies the interface that all LLM implementations must adhere to:

```python
class LLM(Protocol, Generic[TIn, TOut]):
    async def __call__(
        self,
        input: TIn,
        **kwargs: Unpack[LLMInput],
    ) -> LLMOutput[TOut]:
        """Invoke the LLM, treating the LLM as a function."""
        ...
```

This protocol ensures that all LLM implementations have a consistent interface, allowing for easy interchangeability and extension.

## 2. LLM Implementations

GraphRAG provides several concrete implementations of the LLM interface, catering to different use cases and providers. Let's examine some key implementations:

### 2.1 OpenAIChatLLM

The `OpenAIChatLLM` class, defined in `llm/openai/openai_chat_llm.py`, implements the LLM interface for OpenAI's chat-based models:

```python
class OpenAIChatLLM(BaseLLM[CompletionInput, CompletionOutput]):
    _client: OpenAIClientTypes
    _configuration: OpenAIConfiguration

    def __init__(self, client: OpenAIClientTypes, configuration: OpenAIConfiguration):
        self.client = client
        self.configuration = configuration

    async def _execute_llm(
        self, input: CompletionInput, **kwargs: Unpack[LLMInput]
    ) -> CompletionOutput | None:
        args = get_completion_llm_args(
            kwargs.get("model_parameters"), self.configuration
        )
        history = kwargs.get("history") or []
        messages = [
            *history,
            {"role": "user", "content": input},
        ]
        completion = await self.client.chat.completions.create(
            messages=messages, **args
        )
        return completion.choices[0].message.content

    # ... (other methods)
```

This implementation handles the specifics of interacting with OpenAI's chat API, including message formatting and response parsing.

### 2.2 OpenAICompletionLLM

For text completion tasks, GraphRAG provides the `OpenAICompletionLLM` class in `llm/openai/openai_completion_llm.py`:

```python
class OpenAICompletionLLM(BaseLLM[CompletionInput, CompletionOutput]):
    _client: OpenAIClientTypes
    _configuration: OpenAIConfiguration

    def __init__(self, client: OpenAIClientTypes, configuration: OpenAIConfiguration):
        self.client = client
        self.configuration = configuration

    async def _execute_llm(
        self,
        input: CompletionInput,
        **kwargs: Unpack[LLMInput],
    ) -> CompletionOutput | None:
        args = get_completion_llm_args(
            kwargs.get("model_parameters"), self.configuration
        )
        completion = await self.client.completions.create(prompt=input, **args)
        return completion.choices[0].text
```

This class is tailored for text completion tasks, using the OpenAI completions API.

### 2.3 MockLLMs

For testing and development purposes, GraphRAG includes mock implementations of LLMs. For example, the `MockChatLLM` in `llm/mock/mock_chat_llm.py`:

```python
class MockChatLLM(
    BaseLLM[
        CompletionInput,
        CompletionOutput,
    ]
):
    responses: list[str]
    i: int = 0

    def __init__(self, responses: list[str]):
        self.i = 0
        self.responses = responses

    async def _execute_llm(
        self,
        input: CompletionInput,
        **kwargs: Unpack[LLMInput],
    ) -> CompletionOutput:
        if self.i >= len(self.responses):
            msg = f"No more responses, requested {self.i} but only have {len(self.responses)}"
            raise ValueError(msg)
        response = self.responses[self.i]
        self.i += 1
        return response
```

These mock implementations allow developers to test LLM-dependent code without making actual API calls.

## 3. Rate Limiting and Caching

To manage API usage and improve performance, GraphRAG implements rate limiting and caching mechanisms for LLM operations.

### 3.1 Rate Limiting

The `RateLimitingLLM` class in `llm/base/rate_limiting_llm.py` wraps an LLM implementation with rate limiting functionality:

```python
class RateLimitingLLM(LLM[TIn, TOut], Generic[TIn, TOut]):
    def __init__(
        self,
        delegate: LLM[TIn, TOut],
        config: LLMConfig,
        operation: str,
        retryable_errors: list[type[Exception]],
        rate_limit_errors: list[type[Exception]],
        rate_limiter: LLMLimiter | None = None,
        semaphore: asyncio.Semaphore | None = None,
        count_tokens: Callable[[str], int] | None = None,
        get_sleep_time: Callable[[BaseException], float] | None = None,
    ):
        # ... (initialization)

    async def __call__(
        self,
        input: TIn,
        **kwargs: Unpack[LLMInput],
    ) -> LLMOutput[TOut]:
        # ... (rate limiting logic)
```

This class implements token-based and request-based rate limiting, as well as retry logic for handling rate limit errors.

### 3.2 Caching

The `CachingLLM` class in `llm/base/caching_llm.py` provides caching functionality for LLM operations:

```python
class CachingLLM(LLM[TIn, TOut], Generic[TIn, TOut]):
    def __init__(
        self,
        delegate: LLM[TIn, TOut],
        llm_parameters: dict,
        operation: str,
        cache: LLMCache,
    ):
        # ... (initialization)

    async def __call__(
        self,
        input: TIn,
        **kwargs: Unpack[LLMInput],
    ) -> LLMOutput[TOut]:
        # ... (caching logic)
```

This class implements a caching layer that stores and retrieves LLM responses based on input and configuration parameters, reducing unnecessary API calls.

## 4. Configuration and Factory Methods

GraphRAG uses a configuration-based approach to create and manage LLM instances. The `OpenAIConfiguration` class in `llm/openai/openai_configuration.py` encapsulates the configuration options for OpenAI models:

```python
class OpenAIConfiguration(Hashable, LLMConfig):
    _api_key: str
    _model: str
    _api_base: str | None
    _api_version: str | None
    _cognitive_services_endpoint: str | None
    _deployment_name: str | None
    # ... (other configuration options)

    def __init__(
        self,
        config: dict,
    ):
        # ... (initialization from config dict)

    # ... (property getters and other methods)
```

Factory functions in `llm/openai/factories.py` use this configuration to create LLM instances with appropriate wrappers:

```python
def create_openai_chat_llm(
    client: OpenAIClientTypes,
    config: OpenAIConfiguration,
    cache: LLMCache | None = None,
    limiter: LLMLimiter | None = None,
    semaphore: asyncio.Semaphore | None = None,
    on_invoke: LLMInvocationFn | None = None,
    on_error: ErrorHandlerFn | None = None,
    on_cache_hit: OnCacheActionFn | None = None,
    on_cache_miss: OnCacheActionFn | None = None,
) -> CompletionLLM:
    # ... (creation of OpenAIChatLLM with appropriate wrappers)
```

These factory functions allow for easy creation of LLM instances with consistent configuration and optional caching and rate limiting.

## 5. Error Handling

GraphRAG implements custom error types for LLM-related exceptions. The `RetriesExhaustedError` in `llm/errors.py` is an example:

```python
class RetriesExhaustedError(RuntimeError):
    """Retries exhausted error."""

    def __init__(self, name: str, num_retries: int) -> None:
        """Init method definition."""
        super().__init__(f"Operation '{name}' failed - {num_retries} retries exhausted")
```

This error is used in the rate limiting logic to indicate when the maximum number of retries has been reached.

## Conclusion

GraphRAG's LLM integration is a sophisticated system that provides a flexible and extensible framework for working with large language models. By using abstract base classes and protocols, it allows for easy implementation of different LLM providers and types. The rate limiting and caching mechanisms help manage API usage and improve performance, while the configuration-based approach and factory methods make it easy to create and manage LLM instances.

Key takeaways from this lesson include:
1. The use of abstract base classes and protocols to define a consistent interface for LLMs.
2. Implementation of concrete LLM classes for different providers and use cases.
3. Rate limiting and caching mechanisms to manage API usage and improve performance.
4. Configuration-based approach and factory methods for easy creation and management of LLM instances.
5. Custom error types and handling for LLM-specific exceptions.

Understanding these concepts is crucial for effectively working with and extending GraphRAG's LLM capabilities. In the next lesson, we'll explore how GraphRAG uses these LLM components in its core workflows for tasks like entity extraction, relationship detection, and query processing.

## Review Questions

1. What are the main components of GraphRAG's LLM integration, and how do they interact?
2. How does the `BaseLLM` class contribute to the flexibility of GraphRAG's LLM system?
3. Describe the purpose and implementation of the `RateLimitingLLM` class. How does it help manage API usage?
4. What is the role of the `OpenAIConfiguration` class, and how is it used in creating LLM instances?
5. How does GraphRAG implement caching for LLM operations, and what are the benefits of this approach?
6. Explain the purpose of the mock LLM implementations. In what scenarios would these be useful?
7. How does GraphRAG handle errors in LLM operations? Provide an example of a custom error type and its use case.
8. Describe the factory pattern used in creating LLM instances. What advantages does this pattern offer?

## Hands-on Exercise

1. Implement a simple LLM class that adheres to the `LLM` protocol. This LLM should generate responses based on a predefined set of rules (e.g., always responding with the reverse of the input text).

2. Create a custom rate limiter that limits the number of requests per minute. Implement this as a wrapper around your simple LLM class.

3. Implement a basic caching mechanism for your LLM that stores responses for previously seen inputs. Wrap your rate-limited LLM with this caching layer.

4. Create a configuration class for your custom LLM, similar to the `OpenAIConfiguration` class. Include parameters such as response delay, maximum input length, and whether to use caching.

5. Develop a factory function that creates an instance of your LLM with the appropriate wrappers (rate limiting and caching) based on the provided configuration.

6. Write unit tests for your LLM implementation, including tests for the rate limiting and caching functionality.

This exercise will give you hands-on experience with the key concepts of LLM integration in GraphRAG, including implementation of the core LLM interface, rate limiting, caching, configuration management, and factory patterns.

By completing this exercise, you'll gain a deeper understanding of how GraphRAG manages and interacts with language models, and you'll be better prepared to work with or extend the LLM functionality in real-world applications using the GraphRAG framework.

