# Lesson 13: Workflow Execution and Pipeline Runs in GraphRAG

## Introduction

In this lesson, we'll dive deep into the workflow execution and pipeline runs in GraphRAG. These components form the backbone of GraphRAG's processing capabilities, allowing users to define complex data processing pipelines and execute them efficiently. We'll explore the implementation details, examine how workflows are structured and executed, and discuss techniques for managing dependencies and optimizing performance.

## 1. Understanding the Run Module in GraphRAG

The run module in GraphRAG is responsible for orchestrating the execution of workflows and managing pipeline runs. It's a crucial part of the system that ties together various components and ensures smooth execution of data processing tasks.

### 1.1 Run Module Architecture

The run module is primarily implemented in the `run.py` file within the `index` directory. Here's the file structure:

```
graphrag/
└── index/
    └── run/
        ├── run.py
        ├── cache.py
        ├── postprocess.py
        ├── profiling.py
        ├── utils.py
        └── workflow.py
```

The `run.py` file contains the main functions for executing pipelines and workflows. Let's examine the key components:

```python
async def run_pipeline_with_config(
    config_or_path: PipelineConfig | str,
    workflows: list[PipelineWorkflowReference] | None = None,
    dataset: pd.DataFrame | None = None,
    storage: PipelineStorage | None = None,
    cache: PipelineCache | None = None,
    callbacks: WorkflowCallbacks | None = None,
    progress_reporter: ProgressReporter | None = None,
    input_post_process_steps: list[PipelineWorkflowStep] | None = None,
    additional_verbs: VerbDefinitions | None = None,
    additional_workflows: WorkflowDefinitions | None = None,
    emit: list[TableEmitterType] | None = None,
    memory_profile: bool = False,
    run_id: str | None = None,
    is_resume_run: bool = False,
    is_update_run: bool = False,
    **_kwargs: dict,
) -> AsyncIterable[PipelineRunResult]:
    # ... (implementation details)
```

This function is the entry point for running a pipeline with a given configuration. It handles the setup of various components (storage, cache, callbacks) and orchestrates the execution of workflows.

### 1.2 Pipeline Configuration

GraphRAG uses a flexible configuration system to define pipelines. The `PipelineConfig` class, defined in `index/config/pipeline.py`, represents the configuration:

```python
class PipelineConfig(BaseModel):
    extends: list[str] | str | None = pydantic_Field(
        description="Extends another pipeline configuration", default=None
    )
    input: PipelineInputConfigTypes | None = pydantic_Field(
        default=None, discriminator="file_type"
    )
    reporting: PipelineReportingConfigTypes | None = pydantic_Field(
        default=None, discriminator="type"
    )
    storage: PipelineStorageConfigTypes | None = pydantic_Field(
        default=None, discriminator="type"
    )
    cache: PipelineCacheConfigTypes | None = pydantic_Field(
        default=None, discriminator="type"
    )
    root_dir: str | None = pydantic_Field(
        description="The root directory for the pipeline. All other paths will be based on this root_dir.",
        default=None,
    )
    workflows: list[PipelineWorkflowReference] = pydantic_Field(
        description="The workflows for the pipeline.", default_factory=list
    )
```

This configuration allows users to define various aspects of the pipeline, including input sources, storage options, caching strategies, and the workflows to be executed.

## 2. Implementation of run_pipeline and run_pipeline_with_config

The `run_pipeline` and `run_pipeline_with_config` functions are the main entry points for executing pipelines in GraphRAG. Let's examine their implementation and key features.

### 2.1 run_pipeline_with_config

This function is responsible for setting up the pipeline based on the provided configuration and then executing it. Here's a breakdown of its key steps:

1. **Configuration Loading**: If a configuration path is provided, it loads the configuration from the file.
   ```python
   config = load_pipeline_config(config_or_path)
   ```

2. **Component Setup**: It sets up various components based on the configuration, including storage, cache, and callbacks.
   ```python
   storage = storage or _create_storage(config.storage, root_dir=root_dir)
   cache = cache or _create_cache(config.cache, root_dir)
   callbacks = callbacks or _create_reporter(config.reporting, root_dir)
   ```

3. **Input Data Loading**: If no dataset is provided, it loads the input data based on the configuration.
   ```python
   dataset = dataset if dataset is not None else await _create_input(config.input, progress_reporter, root_dir)
   ```

4. **Workflow Execution**: It then calls `run_pipeline` to execute the workflows.
   ```python
   async for table in run_pipeline(
       workflows=workflows,
       dataset=dataset,
       storage=storage,
       cache=cache,
       callbacks=callbacks,
       input_post_process_steps=post_process_steps,
       memory_profile=memory_profile,
       additional_verbs=additional_verbs,
       additional_workflows=additional_workflows,
       progress_reporter=progress_reporter,
       emit=emit,
       is_resume_run=is_resume_run,
   ):
       yield table
   ```

### 2.2 run_pipeline

The `run_pipeline` function is responsible for executing the actual pipeline workflows. Here are its key features:

1. **Workflow Loading**: It loads the workflows and their dependencies.
   ```python
   loaded_workflows = load_workflows(
       workflows,
       additional_verbs=additional_verbs,
       additional_workflows=additional_workflows,
       memory_profile=memory_profile,
   )
   ```

2. **Input Preprocessing**: If any post-processing steps are defined, it applies them to the input data.
   ```python
   dataset = await _run_post_process_steps(
       input_post_process_steps, dataset, context, callbacks
   )
   ```

3. **Workflow Execution**: It iterates through the workflows and executes them in the correct order.
   ```python
   for workflow_to_run in workflows_to_run:
       result = await _process_workflow(
           workflow_to_run.workflow,
           context,
           callbacks,
           emitters,
           workflow_dependencies,
           dataset,
           start_time,
           is_resume_run,
       )
       if result:
           yield result
   ```

4. **Error Handling**: It includes error handling to catch and report any issues during execution.
   ```python
   except Exception as e:
       log.exception("error running workflow %s", last_workflow)
       cast(WorkflowCallbacks, callbacks).on_error(
           "Error running pipeline!", e, traceback.format_exc()
       )
       yield PipelineRunResult(last_workflow, None, [e])
   ```

## 3. Workflow Dependencies and Execution Order

GraphRAG handles workflow dependencies to ensure that workflows are executed in the correct order. This is managed in the `load_workflows` function in `workflows/load.py`:

```python
def load_workflows(
    workflows_to_load: list[PipelineWorkflowReference],
    additional_verbs: VerbDefinitions | None = None,
    additional_workflows: WorkflowDefinitions | None = None,
    memory_profile: bool = False,
) -> LoadWorkflowResult:
    workflow_graph: dict[str, WorkflowToRun] = {}
    # ... (code to build the workflow graph)

    def filter_wf_dependencies(name: str) -> list[str]:
        externals = [
            e.replace("workflow:", "")
            for e in workflow_graph[name].workflow.dependencies
        ]
        return [e for e in externals if e in workflow_graph]

    task_graph = {name: filter_wf_dependencies(name) for name in workflow_graph}
    workflow_run_order = topological_sort(task_graph)
    workflows = [workflow_graph[name] for name in workflow_run_order]
    log.info("Workflow Run Order: %s", workflow_run_order)
    return LoadWorkflowResult(workflows=workflows, dependencies=task_graph)
```

This function builds a dependency graph of workflows and uses topological sorting to determine the correct execution order. This ensures that all dependencies of a workflow are executed before the workflow itself.

## 4. Profiling and Performance Monitoring

GraphRAG includes built-in profiling and performance monitoring capabilities to help users optimize their pipelines. These features are implemented in the `profiling.py` file:

```python
async def _save_profiler_stats(
    storage: PipelineStorage, workflow_name: str, profile: MemoryProfile
):
    await storage.set(
        f"{workflow_name}_profiling.peak_stats.csv",
        profile.peak_stats.to_csv(index=True),
    )

    await storage.set(
        f"{workflow_name}_profiling.snapshot_stats.csv",
        profile.snapshot_stats.to_csv(index=True),
    )

    await storage.set(
        f"{workflow_name}_profiling.time_stats.csv",
        profile.time_stats.to_csv(index=True),
    )

    await storage.set(
        f"{workflow_name}_profiling.detailed_view.csv",
        profile.detailed_view.to_csv(index=True),
    )
```

This function saves detailed profiling information for each workflow, including peak memory usage, memory snapshots over time, and timing statistics. Users can analyze this data to identify performance bottlenecks and optimize their pipelines.

## Conclusion

In this lesson, we've explored the intricacies of workflow execution and pipeline runs in GraphRAG. We've seen how the system manages pipeline configurations, loads and executes workflows, handles dependencies, and provides profiling capabilities. Understanding these components is crucial for effectively using GraphRAG and optimizing its performance for your specific use cases.

## Exercises

1. Create a custom workflow that processes a large dataset and includes multiple interdependent steps. Implement this workflow in GraphRAG and analyze its execution using the built-in profiling tools.

2. Extend the `run_pipeline` function to include a feature for pausing and resuming pipeline execution at specific checkpoints. This could be useful for long-running pipelines that may need to be interrupted and resumed later.

3. Implement a new profiling metric in GraphRAG, such as I/O operations or network usage. Modify the profiling system to capture and report on this new metric.

4. Design and implement a visualization tool that can display the workflow dependency graph and execution order based on the output of `load_workflows`.

5. Create a custom `WorkflowCallbacks` implementation that sends real-time execution updates to a web-based dashboard. Integrate this with the pipeline execution process.

## Review Questions

1. How does GraphRAG manage pipeline configurations, and what are the key components of a `PipelineConfig`?

2. Explain the process of how GraphRAG determines the execution order of workflows. Why is this important?

3. What are the main steps involved in the `run_pipeline` function, and how does it handle errors during execution?

4. How does GraphRAG's profiling system work, and what kinds of information does it capture? How can this information be used to optimize pipeline performance?

5. Describe the role of the `WorkflowCallbacks` in pipeline execution. How might you extend this to add custom behavior during pipeline runs?

By mastering these concepts and techniques, you'll be well-equipped to create, execute, and optimize complex data processing pipelines using GraphRAG. You'll be able to leverage its powerful workflow management capabilities to build scalable and efficient graph-based applications.
