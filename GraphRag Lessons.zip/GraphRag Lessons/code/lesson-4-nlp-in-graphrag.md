# Lesson 4: Natural Language Processing in GraphRAG

## 1. NLP Concepts Used in GraphRAG

Natural Language Processing (NLP) is a crucial component of the GraphRAG system, enabling it to understand, process, and generate human-like text. In this lesson, we'll explore the key NLP concepts and techniques used in GraphRAG, including tokenization, text preprocessing, Named Entity Recognition (NER), and text embedding.

## 2. Tokenization and Text Preprocessing

Tokenization is the process of breaking down text into smaller units, typically words or subwords. This is a fundamental step in many NLP tasks, as it allows the system to work with discrete units of text. GraphRAG uses advanced tokenization techniques to prepare text for further processing.

### 2.1 Tokenization in GraphRAG

GraphRAG primarily uses the `tiktoken` library for tokenization, which is particularly well-suited for working with OpenAI's language models. Here's an example of how tokenization is implemented in GraphRAG:

```python
# File: graphrag/index/text_splitting/text_splitting.py

import tiktoken

class TokenTextSplitter(TextSplitter):
    """Token text splitter class definition."""

    def __init__(
        self,
        encoding_name: str = "cl100k_base",
        model_name: str | None = None,
        allowed_special: Literal["all"] | set[str] | None = None,
        disallowed_special: Literal["all"] | Collection[str] = "all",
        **kwargs: Any,
    ):
        """Init method definition."""
        super().__init__(**kwargs)
        if model_name is not None:
            try:
                enc = tiktoken.encoding_for_model(model_name)
            except KeyError:
                log.exception("Model %s not found, using %s", model_name, encoding_name)
                enc = tiktoken.get_encoding(encoding_name)
        else:
            enc = tiktoken.get_encoding(encoding_name)
        self._tokenizer = enc
        self._allowed_special = allowed_special or set()
        self._disallowed_special = disallowed_special

    def encode(self, text: str) -> list[int]:
        """Encode the given text into an int-vector."""
        return self._tokenizer.encode(
            text,
            allowed_special=self._allowed_special,
            disallowed_special=self._disallowed_special,
        )

    def num_tokens(self, text: str) -> int:
        """Return the number of tokens in a string."""
        return len(self.encode(text))
```

This implementation allows for flexible tokenization based on different encoding schemes and models. It's particularly useful for ensuring compatibility with the specific tokenization used by the language models employed in GraphRAG.

### 2.2 Text Preprocessing

Text preprocessing in GraphRAG involves several steps to clean and standardize the input text. This includes operations such as removing HTML tags, handling special characters, and normalizing text. Here's an example of a text cleaning function used in GraphRAG:

```python
# File: graphrag/utils/string.py

import html
import re
from typing import Any

def clean_str(input: Any) -> str:
    """Clean an input string by removing HTML escapes, control characters, and other unwanted characters."""
    # If we get non-string input, just give it back
    if not isinstance(input, str):
        return input

    result = html.unescape(input.strip())
    # Remove control characters
    return re.sub(r"[\x00-\x1f\x7f-\x9f]", "", result)
```

This function performs several important preprocessing steps:
1. It checks if the input is a string, returning non-string inputs unchanged.
2. It strips leading and trailing whitespace.
3. It unescapes HTML entities, converting them to their corresponding characters.
4. It removes control characters, which can cause issues in further processing or display.

## 3. Named Entity Recognition (NER) Implementation

Named Entity Recognition is a crucial task in GraphRAG, as it forms the basis for identifying important entities in the text and constructing the knowledge graph. GraphRAG implements a flexible approach to NER, allowing for different strategies including rule-based, machine learning-based, and hybrid approaches.

### 3.1 Entity Extraction Framework

The core of GraphRAG's entity extraction is implemented in the `GraphExtractor` class. This class uses a language model to identify entities and their relationships in the input text. Here's a simplified version of the key method:

```python
# File: graphrag/index/graph/extractors/graph/graph_extractor.py

class GraphExtractor:
    # ... other methods ...

    async def __call__(
        self, texts: list[str], prompt_variables: dict[str, Any] | None = None
    ) -> GraphExtractionResult:
        # ... other code ...

        for doc_index, text in enumerate(texts):
            try:
                # Invoke the entity extraction
                result = await self._process_document(text, prompt_variables)
                source_doc_map[doc_index] = text
                all_records[doc_index] = result
            except Exception as e:
                logging.exception("error extracting graph")
                self._on_error(
                    e,
                    traceback.format_exc(),
                    {
                        "doc_index": doc_index,
                        "text": text,
                    },
                )

        output = await self._process_results(
            all_records,
            prompt_variables.get(self._tuple_delimiter_key, DEFAULT_TUPLE_DELIMITER),
            prompt_variables.get(self._record_delimiter_key, DEFAULT_RECORD_DELIMITER),
        )

        return GraphExtractionResult(
            output=output,
            source_docs=source_doc_map,
        )
```

This method processes each input text, extracting entities and their relationships. It uses a language model (through the `_process_document` method) to perform the extraction, which allows for sophisticated, context-aware entity recognition.

### 3.2 NLTK-based NER

For simpler use cases or as a fallback, GraphRAG also includes an NLTK-based NER implementation. This provides a lightweight, rule-based approach to entity recognition:

```python
# File: graphrag/index/operations/extract_entities/strategies/nltk.py

import nltk
from nltk.corpus import words

async def run(
    docs: list[Document],
    entity_types: EntityTypes,
    callbacks: VerbCallbacks,
    cache: PipelineCache,
    args: StrategyConfig,
) -> EntityExtractionResult:
    """Run method definition."""
    entity_map = {}
    graph = nx.Graph()
    for doc in docs:
        connected_entities = []
        for chunk in nltk.ne_chunk(nltk.pos_tag(nltk.word_tokenize(doc.text))):
            if hasattr(chunk, "label"):
                entity_type = chunk.label().lower()
                if entity_type in entity_types:
                    name = (" ".join(c[0] for c in chunk)).upper()
                    connected_entities.append(name)
                    if name not in entity_map:
                        entity_map[name] = entity_type
                        graph.add_node(
                            name, type=entity_type, description=name, source_id=doc.id
                        )

        # Connect entities if they appear in the same document
        if len(connected_entities) > 1:
            for i in range(len(connected_entities)):
                for j in range(i + 1, len(connected_entities)):
                    description = f"{connected_entities[i]} -> {connected_entities[j]}"
                    graph.add_edge(
                        connected_entities[i],
                        connected_entities[j],
                        description=description,
        

                source_id=doc.id,
                    )

    return EntityExtractionResult(
        entities=[
            {"type": entity_type, "name": name}
            for name, entity_type in entity_map.items()
        ],
        graphml_graph="".join(nx.generate_graphml(graph)),
    )
```

This implementation uses NLTK's built-in named entity chunker to identify entities in the text. It then constructs a graph based on these entities and their co-occurrences in documents.

## 4. Text Embedding and Vector Representations

Text embedding is a crucial component in GraphRAG, allowing for efficient similarity search and semantic understanding of text. GraphRAG supports various embedding strategies, with a focus on compatibility with state-of-the-art language models.

### 4.1 Embedding Implementation

The core embedding functionality is implemented in the `embed_text` function:

```python
# File: graphrag/index/operations/embed_text/embed_text.py

async def embed_text(
    input: pd.DataFrame,
    callbacks: VerbCallbacks,
    cache: PipelineCache,
    column: str,
    strategy: dict,
    embedding_name: str = "default",
):
    """Embed a piece of text into a vector space."""
    vector_store_config = strategy.get("vector_store")

    if vector_store_config:
        collection_name = _get_collection_name(vector_store_config, embedding_name)
        vector_store: BaseVectorStore = _create_vector_store(
            vector_store_config, collection_name
        )
        vector_store_workflow_config = vector_store_config.get(
            embedding_name, vector_store_config
        )
        return await _text_embed_with_vector_store(
            input,
            callbacks,
            cache,
            column,
            strategy,
            vector_store,
            vector_store_workflow_config,
            vector_store_config.get("store_in_table", False),
        )

    return await _text_embed_in_memory(
        input,
        callbacks,
        cache,
        column,
        strategy,
    )
```

This function supports both in-memory embedding and embedding with vector store integration. It's designed to be flexible, allowing for different embedding strategies and storage options.

### 4.2 OpenAI Embedding Strategy

GraphRAG includes an implementation for using OpenAI's embedding models. Here's a simplified version of the OpenAI embedding strategy:

```python
# File: graphrag/index/operations/embed_text/strategies/openai.py

async def run(
    input: list[str],
    callbacks: VerbCallbacks,
    cache: PipelineCache,
    args: dict[str, Any],
) -> TextEmbeddingResult:
    """Run the OpenAI embedding strategy."""
    if is_null(input):
        return TextEmbeddingResult(embeddings=None)

    llm_config = args.get("llm", {})
    batch_size = args.get("batch_size", 16)
    batch_max_tokens = args.get("batch_max_tokens", 8191)
    oai_config = OpenAIConfiguration(llm_config)
    splitter = _get_splitter(oai_config, batch_max_tokens)
    llm = _get_llm(oai_config, callbacks, cache)
    semaphore: asyncio.Semaphore = asyncio.Semaphore(args.get("num_threads", 4))

    texts, input_sizes = _prepare_embed_texts(input, splitter)
    text_batches = _create_text_batches(
        texts,
        batch_size,
        batch_max_tokens,
        splitter,
    )

    embeddings = await _execute(llm, text_batches, ticker, semaphore)
    embeddings = _reconstitute_embeddings(embeddings, input_sizes)

    return TextEmbeddingResult(embeddings=embeddings)

# ... (previous code)

async def _execute(
    llm: EmbeddingLLM,
    chunks: list[list[str]],
    tick: ProgressTicker,
    semaphore: asyncio.Semaphore,
) -> list[list[float]]:
    async def embed(chunk: list[str]):
        async with semaphore:
            chunk_embeddings = await llm(chunk)
            result = np.array(chunk_embeddings.output)
            tick(1)
        return result

    futures = [embed(chunk) for chunk in chunks]
    results = await asyncio.gather(*futures)
    # merge results in a single list of lists (reduce the collect dimension)
    return [item for sublist in results for item in sublist]
```

This implementation showcases several important aspects of text embedding in GraphRAG:

1. Batch processing: The input texts are processed in batches to optimize performance and adhere to API limitations.
2. Token limit handling: The `_get_splitter` function ensures that individual texts don't exceed the maximum token limit of the embedding model.
3. Asynchronous execution: The embedding process is performed asynchronously, allowing for efficient parallel processing of multiple text chunks.
4. Progress tracking: The `ProgressTicker` is used to provide feedback on the embedding progress.
5. Semaphore usage: A semaphore is employed to limit the number of concurrent API calls, preventing overload of the embedding service.

### 4.3 Vector Store Integration

GraphRAG supports integration with vector stores for efficient storage and retrieval of embeddings. This is particularly useful for large-scale applications where in-memory storage of embeddings is not feasible. Here's an example of how vector store integration is implemented:

```python
# File: graphrag/index/operations/embed_text/embed_text.py

async def _text_embed_with_vector_store(
    input: pd.DataFrame,
    callbacks: VerbCallbacks,
    cache: PipelineCache,
    column: str,
    strategy: dict[str, Any],
    vector_store: BaseVectorStore,
    vector_store_config: dict,
    store_in_table: bool = False,
):
    strategy_type = strategy["type"]
    strategy_exec = load_strategy(strategy_type)
    strategy_args = {**strategy}

    # Get vector-storage configuration
    insert_batch_size: int = (
        vector_store_config.get("batch_size") or DEFAULT_EMBEDDING_BATCH_SIZE
    )
    title_column: str = vector_store_config.get("title_column", "title")
    id_column: str = vector_store_config.get("id_column", "id")
    overwrite: bool = vector_store_config.get("overwrite", True)

    # ... (input validation)

    i = 0
    starting_index = 0

    all_results = []

    while insert_batch_size * i < input.shape[0]:
        batch = input.iloc[insert_batch_size * i : insert_batch_size * (i + 1)]
        texts: list[str] = batch[column].to_numpy().tolist()
        titles: list[str] = batch[title_column].to_numpy().tolist()
        ids: list[str] = batch[id_column].to_numpy().tolist()
        result = await strategy_exec(
            texts,
            callbacks,
            cache,
            strategy_args,
        )
        if store_in_table and result.embeddings:
            embeddings = [
                embedding for embedding in result.embeddings if embedding is not None
            ]
            all_results.extend(embeddings)

        vectors = result.embeddings or []
        documents: list[VectorStoreDocument] = []
        for id, text, title, vector in zip(ids, texts, titles, vectors, strict=True):
            if type(vector) is np.ndarray:
                vector = vector.tolist()
            document = VectorStoreDocument(
                id=id,
                text=text,
                vector=vector,
                attributes={"title": title},
            )
            documents.append(document)

        vector_store.load_documents(documents, overwrite and i == 0)
        starting_index += len(documents)
        i += 1

    if store_in_table:
        return all_results

    return None
```

This implementation demonstrates several key aspects of vector store integration in GraphRAG:

1. Batch processing: Embeddings are processed and stored in batches to manage memory usage and optimize performance.
2. Flexible configuration: The function allows for configuration of batch size, column mappings, and overwrite behavior.
3. Vector store abstraction: The `BaseVectorStore` interface allows for easy integration of different vector store backends.
4. Document creation: Embeddings are packaged with metadata (like title and ID) into `VectorStoreDocument` objects for storage.
5. Optional in-table storage: The function can optionally store embeddings in the input DataFrame, in addition to the vector store.

## Conclusion

In this lesson, we've explored the Natural Language Processing aspects of GraphRAG, including tokenization, text preprocessing, Named Entity Recognition, and text embedding. These components form the foundation of GraphRAG's ability to understand and process textual data, enabling the creation of rich knowledge graphs and powerful information retrieval capabilities.

Key takeaways from this lesson include:

1. GraphRAG uses advanced tokenization techniques, primarily relying on the `tiktoken` library for compatibility with state-of-the-art language models.
2. Text preprocessing in GraphRAG involves careful cleaning and normalization of input text to ensure consistent and high-quality results.
3. Named Entity Recognition in GraphRAG is flexible, supporting both sophisticated LLM-based approaches and simpler rule-based methods using NLTK.
4. Text embedding in GraphRAG is designed for scalability and performance, with support for batch processing, asynchronous execution, and vector store integration.

Understanding these NLP components is crucial for effectively working with and extending the GraphRAG system, as they form the basis for many of its core functionalities.

## Review Questions

1. How does GraphRAG handle tokenization, and why is the choice of tokenizer important?
2. Describe the text preprocessing steps implemented in GraphRAG's `clean_str` function. Why are these steps necessary?
3. Compare and contrast the LLM-based and NLTK-based approaches to Named Entity Recognition in GraphRAG.
4. How does GraphRAG's embedding implementation handle large volumes of text efficiently?
5. Explain the purpose of vector store integration in GraphRAG's embedding process. What advantages does this offer for large-scale applications?
6. How does GraphRAG ensure that embedding requests don't overwhelm the underlying API or service?
7. What considerations are taken into account when storing embeddings in a vector store, as implemented in GraphRAG?

## Hands-on Exercise

1. Implement a simple tokenization function using the `tiktoken` library. The function should take a string as input and return a list of token IDs.

2. Create a text preprocessing pipeline that includes the following steps:
   - Convert text to lowercase
   - Remove HTML tags
   - Remove special characters (except for punctuation)
   - Remove extra whitespace

3. Implement a basic Named Entity Recognition function using NLTK. The function should identify and return a list of named entities (persons, organizations, and locations) from an input text.

4. Create a simple embedding function that uses a pre-trained model (you can use a library like `sentence-transformers` for this). The function should take a list of strings as input and return their embeddings.

5. Implement a basic vector store class that can store and retrieve embeddings. It should have methods for:
   - Adding new documents (with their embeddings)
   - Retrieving the most similar documents given a query embedding

6. Combine all the above components into a simple pipeline that:
   - Preprocesses input text
   - Extracts named entities
   - Generates embeddings for the text and entities
   - Stores the embeddings in your vector store

This exercise will give you hands-on experience with the key NLP components used in GraphRAG, helping you understand how they work together in a simplified context.

