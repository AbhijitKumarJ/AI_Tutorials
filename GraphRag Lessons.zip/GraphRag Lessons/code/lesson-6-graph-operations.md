# Lesson 6: Graph Operations in GraphRAG

## Introduction

In this lesson, we'll delve into the heart of GraphRAG's functionality: graph operations. We'll explore how GraphRAG creates, manipulates, and analyzes graph structures to represent complex relationships between entities. By the end of this lesson, you'll have a deep understanding of how GraphRAG leverages graph theory and network analysis to enhance its retrieval and generation capabilities.

## File Structure

Before we dive into the details, let's examine the relevant file structure for graph operations in GraphRAG:

```
graphrag/
├── index/
│   ├── graph/
│   │   ├── __init__.py
│   │   ├── embedding/
│   │   │   ├── __init__.py
│   │   │   └── embedding.py
│   │   ├── extractors/
│   │   │   ├── __init__.py
│   │   │   ├── claims/
│   │   │   ├── community_reports/
│   │   │   ├── graph/
│   │   │   └── summarize/
│   │   ├── utils/
│   │   │   ├── __init__.py
│   │   │   ├── normalize_node_names.py
│   │   │   └── stable_lcc.py
│   │   └── visualization/
│   │       ├── __init__.py
│   │       ├── compute_umap_positions.py
│   │       └── typing.py
│   ├── operations/
│   │   ├── __init__.py
│   │   ├── cluster_graph.py
│   │   ├── compute_edge_combined_degree.py
│   │   ├── embed_graph/
│   │   │   ├── __init__.py
│   │   │   ├── embed_graph.py
│   │   │   └── typing.py
│   │   ├── merge_graphs/
│   │   │   ├── __init__.py
│   │   │   ├── merge_graphs.py
│   │   │   └── typing.py
│   │   └── unpack_graph.py
├── utils/
│   ├── __init__.py
│   └── load_graph.py
```

This structure shows the organization of graph-related code in GraphRAG. The `index/graph/` directory contains core graph operations, while `index/operations/` houses higher-level graph manipulation functions.

## Graph Creation and Manipulation

GraphRAG primarily uses the NetworkX library for graph operations. NetworkX is a powerful Python package for the creation, manipulation, and study of the structure, dynamics, and functions of complex networks.

### Loading and Saving Graphs

The `load_graph` function in `utils/load_graph.py` is a crucial utility for loading graph data:

```python
import networkx as nx

def load_graph(graphml: str | nx.Graph) -> nx.Graph:
    """Load a graph from a graphml file or a networkx graph."""
    return nx.parse_graphml(graphml) if isinstance(graphml, str) else graphml
```

This function can load a graph from a GraphML string or return an existing NetworkX graph object. GraphML is an XML-based file format for graphs, which allows for easy serialization and deserialization of graph structures.

### Graph Normalization

The `normalize_node_names` function in `index/graph/utils/normalize_node_names.py` ensures consistency in node naming:

```python
import html
import networkx as nx

def normalize_node_names(graph: nx.Graph | nx.DiGraph) -> nx.Graph | nx.DiGraph:
    """Normalize node names."""
    node_mapping = {node: html.unescape(node.upper().strip()) for node in graph.nodes()}
    return nx.relabel_nodes(graph, node_mapping)
```

This function performs two important operations:
1. It unescapes HTML entities in node names, ensuring that special characters are properly represented.
2. It converts all node names to uppercase and strips whitespace, creating a standardized format for node labels.

Normalization is crucial for maintaining consistency across different data sources and ensuring accurate graph operations.

## Graph Clustering

Graph clustering is a key operation in GraphRAG, used to identify communities or groups within the graph structure. The `cluster_graph` function in `index/operations/cluster_graph.py` implements this functionality:

```python
from enum import Enum
from typing import Any, cast
import networkx as nx
import pandas as pd
from graspologic.partition import hierarchical_leiden

class GraphCommunityStrategyType(str, Enum):
    leiden = "leiden"

def cluster_graph(
    input: pd.DataFrame,
    callbacks: VerbCallbacks,
    strategy: dict[str, Any],
    column: str,
    to: str,
    level_to: str | None = None,
) -> pd.DataFrame:
    # ... (implementation details)
```

This function uses the Leiden algorithm, a hierarchical community detection method, to cluster the graph. The Leiden algorithm is particularly effective for identifying communities in large networks.

Key points about the clustering process:
- It operates on a DataFrame containing graph data, allowing for batch processing of multiple graphs.
- The clustering strategy is configurable, with 'leiden' as the default method.
- The function returns a DataFrame with new columns containing the clustered graph and community levels.

## Graph Embedding

Graph embedding is the process of representing nodes in a graph as vectors in a lower-dimensional space. This is crucial for many machine learning tasks on graphs. GraphRAG implements graph embedding in `index/operations/embed_graph/embed_graph.py`:

```python
from enum import Enum
from typing import Any, cast
import networkx as nx
import pandas as pd
from graspologic.embed import node2vec_embed

class EmbedGraphStrategyType(str, Enum):
    node2vec = "node2vec"

async def embed_graph(
    input: pd.DataFrame,
    callbacks: VerbCallbacks,
    strategy: dict[str, Any],
    column: str,
    num_threads: int = 4,
):
    # ... (implementation details)
```

Key features of the graph embedding process:
- It uses the Node2Vec algorithm, which learns continuous feature representations for nodes in networks.
- The embedding is configurable, allowing for adjustment of parameters like dimensions, number of walks, and walk length.
- The function operates asynchronously, enabling efficient processing of large graphs or multiple graphs in parallel.

## Graph Merging

In many scenarios, it's necessary to combine information from multiple graphs. GraphRAG implements graph merging in `index/operations/merge_graphs/merge_graphs.py`:

```python
import networkx as nx
import pandas as pd
from datashaper import VerbCallbacks

def merge_graphs(
    input: pd.DataFrame,
    callbacks: VerbCallbacks,
    column: str,
    to: str,
    nodes: dict[str, Any] = DEFAULT_NODE_OPERATIONS,
    edges: dict[str, Any] = DEFAULT_EDGE_OPERATIONS,
) -> pd.DataFrame:
    # ... (implementation details)
```

This function allows for sophisticated merging of graphs with configurable operations for handling node and edge attributes. Key aspects of the merge operation include:
- Separate configurations for merging node and edge attributes.
    - For example, node descriptions might be concatenated, while edge weights might be summed.
- The ability to handle conflicts when merging, such as choosing the most recent value or combining values.
- Preservation of graph structure while enhancing the information content of nodes and edges.

## Graph Analysis

GraphRAG includes several functions for analyzing graph properties. One important example is the computation of edge degrees, implemented in `index/operations/compute_edge_combined_degree.py`:

```python
import pandas as pd

def compute_edge_combined_degree(
    edge_df: pd.DataFrame,
    node_degree_df: pd.DataFrame,
    to: str,
    node_name_column: str,
    node_degree_column: str,
    edge_source_column: str,
    edge_target_column: str,
) -> pd.DataFrame:
    # ... (implementation details)
```

This function computes a combined degree for each edge based on the degrees of its source and target nodes. This can be useful for identifying important connections in the graph or for weighting edges in subsequent analyses.

## Graph Visualization

While GraphRAG is primarily focused on backend operations, it includes functionality for preparing graph data for visualization. The `compute_umap_positions` function in `index/graph/visualization/compute_umap_positions.py` is used for this purpose:

```python
import numpy as np
import umap
from .typing import NodePosition

def compute_umap_positions(
    embedding_vectors: np.ndarray,
    node_labels: list[str],
    node_categories: list[int] | None = None,
    node_sizes: list[int] | None = None,
    min_dist: float = 0.75,
    n_neighbors: int = 25,
    spread: int = 1,
    metric: str = "euclidean",
    n_components: int = 2,
    random_state: int = 86,
) -> list[NodePosition]:
    # ... (implementation details)
```

This function uses UMAP (Uniform Manifold Approximation and Projection) to compute 2D or 3D positions for nodes based on their embeddings. This is particularly useful for visualizing high-dimensional graph embeddings in a lower-dimensional space.

## Practical Exercise

Let's create a practical exercise that demonstrates some of the graph operations we've discussed. We'll create a simple graph, perform some operations, and analyze the results.

```python
import networkx as nx
from graphrag.index.operations.cluster_graph import cluster_graph
from graphrag.index.operations.embed_graph.embed_graph import embed_graph
from graphrag.index.operations.merge_graphs.merge_graphs import merge_graphs
import pandas as pd

async def graph_operations_demo():
    # Create two simple graphs
    G1 = nx.Graph()
    G1.add_edges_from([(1, 2), (2, 3), (3, 4), (4, 1)])
    G2 = nx.Graph()
    G2.add_edges_from([(3, 4), (4, 5), (5, 6), (6, 3)])

    # Convert to GraphML strings
    graphml1 = "\n".join(nx.generate_graphml(G1))
    graphml2 = "\n".join(nx.generate_graphml(G2))

    # Create a DataFrame with the graphs
    df = pd.DataFrame({"graph": [graphml1, graphml2]})

    # Cluster the graphs
    clustered_df = cluster_graph(
        df,
        callbacks=None,
        strategy={"type": "leiden"},
        column="graph",
        to="clustered_graph"
    )

    # Embed the clustered graphs
    embedded_df = await embed_graph(
        clustered_df,
        callbacks=None,
        strategy={"type": "node2vec"},
        column="clustered_graph"
    )

    # Merge the graphs
    merged_df = merge_graphs(
        embedded_df,
        callbacks=None,
        column="clustered_graph",
        to="merged_graph"
    )

    # Analyze the result
    final_graph = nx.parse_graphml(merged_df["merged_graph"].iloc[0])
    print(f"Number of nodes: {final_graph.number_of_nodes()}")
    print(f"Number of edges: {final_graph.number_of_edges()}")
    print(f"Graph density: {nx.density(final_graph)}")

# Run the demo
import asyncio
asyncio.run(graph_operations_demo())
```

This exercise demonstrates the process of clustering, embedding, and merging graphs using GraphRAG's operations. It showcases how these operations can be chained together to perform complex graph analyses.

## Review Questions

1. What is the purpose of the `load_graph` function, and why is it important in GraphRAG?
2. How does the `normalize_node_names` function contribute to maintaining consistency in graph data?
3. Describe the Leiden algorithm and its role in graph clustering within GraphRAG.
4. What is graph embedding, and how does GraphRAG implement it using Node2Vec?
5. Explain the process of merging graphs in GraphRAG. What considerations are made when combining node and edge attributes?
6. How does GraphRAG prepare graph data for visualization using UMAP?
7. What is the significance of computing edge combined degrees in graph analysis?
8. How might the graph operations in GraphRAG be used in a real-world application for knowledge discovery or information retrieval?

## Conclusion

In this lesson, we've explored the diverse and powerful graph operations implemented in GraphRAG. We've seen how the system leverages NetworkX for basic graph structures and operations, and how it extends these capabilities with advanced clustering, embedding, and analysis techniques.

These graph operations form the backbone of GraphRAG's ability to represent and analyze complex relationships between entities. By combining these graph-theoretic approaches with the natural language processing capabilities we discussed in previous lessons, GraphRAG creates a powerful system for knowledge representation and retrieval.

In our next lesson, we'll explore how these graph operations are integrated into GraphRAG's data processing pipelines, forming complete workflows for information extraction and analysis.

