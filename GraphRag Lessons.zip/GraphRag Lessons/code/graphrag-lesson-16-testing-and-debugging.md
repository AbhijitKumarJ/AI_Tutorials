# Lesson 16: Testing and Debugging GraphRAG

## Introduction

In this lesson, we'll dive deep into the testing and debugging strategies for GraphRAG. We'll explore various testing methodologies, from unit testing individual components to integration testing of entire workflows. We'll also discuss debugging techniques specific to graph operations and performance profiling. By the end of this lesson, you'll have a comprehensive understanding of how to ensure the reliability and efficiency of GraphRAG implementations.

## File Structure

Before we begin, let's examine the relevant file structure within the GraphRAG project:

```
graphrag/
├── tests/
│   ├── unit/
│   │   ├── config/
│   │   ├── index/
│   │   ├── llm/
│   │   └── ...
│   ├── integration/
│   │   ├── workflows/
│   │   ├── pipelines/
│   │   └── ...
│   ├── fixtures/
│   │   ├── sample_data/
│   │   ├── mock_responses/
│   │   └── ...
│   └── conftest.py
├── index/
│   ├── run/
│   │   ├── profiling.py
│   │   └── ...
│   └── ...
└── utils/
    ├── debug.py
    └── ...
```

This structure shows the main components we'll be discussing in this lesson. The `tests` directory contains unit and integration tests, while debugging and profiling utilities are scattered throughout the project.

## Unit Testing Strategies for GraphRAG Components

Unit testing is crucial for ensuring the correctness of individual components in GraphRAG. Let's explore some strategies and best practices for unit testing different parts of the system.

### Testing Configuration Components

Configuration components are the building blocks of GraphRAG's setup. Here's an example of how we might test a configuration class:

```python
# tests/unit/config/test_llm_config.py

import pytest
from graphrag.config.models import LLMConfig
from graphrag.config.enums import LLMType

def test_llm_config_validation():
    # Test valid configuration
    valid_config = LLMConfig(
        api_key="test_key",
        type=LLMType.openai,
        model="gpt-4"
    )
    assert valid_config.api_key == "test_key"
    assert valid_config.type == LLMType.openai
    assert valid_config.model == "gpt-4"

    # Test invalid configuration
    with pytest.raises(ValueError):
        LLMConfig(
            api_key="test_key",
            type="invalid_type",  # This should raise a validation error
            model="gpt-4"
        )

def test_llm_config_default_values():
    config = LLMConfig(
        api_key="test_key",
        type=LLMType.openai,
        model="gpt-4"
    )
    assert config.max_tokens is None  # Assuming this is an optional field with None as default
    assert config.request_timeout is None  # Assuming this is an optional field with None as default
```

In these tests, we're verifying that:
1. Valid configurations are accepted and their values are correctly set.
2. Invalid configurations raise appropriate validation errors.
3. Default values are correctly applied for optional fields.

### Testing Graph Operations

Graph operations are at the core of GraphRAG. Here's an example of how we might test a graph clustering function:

```python
# tests/unit/index/operations/test_cluster_graph.py

import networkx as nx
from graphrag.index.operations.cluster_graph import cluster_graph

def test_cluster_graph():
    # Create a simple test graph
    G = nx.Graph()
    G.add_edges_from([(1, 2), (2, 3), (3, 4), (4, 1), (5, 6)])

    # Mock callbacks and strategy
    mock_callbacks = MagicMock()
    mock_strategy = {"type": "leiden", "resolution": 1.0}

    # Run clustering
    result = cluster_graph(
        nx.to_pandas_edgelist(G),
        mock_callbacks,
        strategy=mock_strategy,
        column="source",
        to="clustered_graph",
        level_to="level"
    )

    # Assert the result has the expected columns
    assert "clustered_graph" in result.columns
    assert "level" in result.columns

    # Check that we have the expected number of clusters
    unique_clusters = result["clustered_graph"].apply(lambda x: len(set(nx.get_node_attributes(x, "cluster").values()))).unique()
    assert len(unique_clusters) > 0  # We should have at least one cluster
    assert len(unique_clusters) <= len(G.nodes)  # We can't have more clusters than nodes
```

This test creates a simple graph, applies the clustering algorithm, and verifies that the result has the expected structure and properties.

### Mocking External Dependencies

When testing components that rely on external services (like LLMs), it's important to use mocks to isolate the component being tested. Here's an example of how we might test an entity extractor that uses an LLM:

```python
# tests/unit/index/graph/extractors/test_graph_extractor.py

from unittest.mock import Mock
from graphrag.index.graph.extractors import GraphExtractor

def test_graph_extractor():
    # Mock LLM
    mock_llm = Mock()
    mock_llm.return_value = Mock(output="(\"entity\",\"COMPANY A\",\"ORGANIZATION\",\"A large tech company\")\n(\"relationship\",\"COMPANY A\",\"PERSON B\",\"CEO\",\"1.0\")")

    # Create extractor with mock LLM
    extractor = GraphExtractor(mock_llm)

    # Run extraction
    result = extractor(["Company A is led by Person B."])

    # Assert the result contains the expected entities and relationships
    assert "COMPANY A" in result.output.nodes()
    assert "PERSON B" in result.output.nodes()
    assert result.output.has_edge("COMPANY A", "PERSON B")
    assert result.output.edges["COMPANY A", "PERSON B"]["description"] == "CEO"
```

This test mocks the LLM to return a predefined response, allowing us to test the extractor's parsing logic without actually calling an external API.

## Integration Testing for Workflows and Pipelines

While unit tests are great for testing individual components, integration tests are crucial for ensuring that different parts of GraphRAG work together correctly. Let's look at how we might set up integration tests for a complete workflow.

```python
# tests/integration/workflows/test_entity_extraction_workflow.py

import pytest
from graphrag.index.workflows import create_workflow
from graphrag.index.run import run_pipeline_with_config
from graphrag.config import load_config

@pytest.fixture
def sample_config():
    return load_config("tests/fixtures/sample_config.yaml")

@pytest.fixture
def sample_data(tmp_path):
    # Create some sample input data
    data_file = tmp_path / "input.csv"
    data_file.write_text("id,text\n1,Company A is based in City B.\n2,Person C works for Company A.")
    return str(data_file)

async def test_entity_extraction_workflow(sample_config, sample_data):
    # Modify config to use our sample data
    sample_config.input.base_dir = sample_data

    # Run the pipeline
    results = [result async for result in run_pipeline_with_config(sample_config)]

    # Check that we got the expected outputs
    assert len(results) > 0
    final_entities = next(r.result for r in results if r.workflow == "create_final_entities")
    assert len(final_entities) > 0
    assert "Company A" in final_entities["name"].values
    assert "City B" in final_entities["name"].values
    assert "Person C" in final_entities["name"].values
```

This integration test:
1. Sets up a sample configuration and input data.
2. Runs the entire pipeline using this configuration.
3. Checks that the output contains the expected entities.

Such tests are invaluable for catching issues that arise from the interaction between different components, which might not be apparent from unit tests alone.

## Debugging Techniques for Complex Graph Operations

Debugging graph operations can be challenging due to the complex nature of graph structures. Here are some techniques and tools that can be helpful:

### Logging and Visualization

Extensive logging can be crucial for understanding what's happening inside complex graph algorithms. Here's an example of how we might enhance our clustering function with detailed logging:

```python
import logging
import networkx as nx
import matplotlib.pyplot as plt

def cluster_graph(G, algorithm="leiden", resolution=1.0):
    logging.info(f"Starting clustering of graph with {len(G.nodes)} nodes and {len(G.edges)} edges")
    
    if algorithm == "leiden":
        from leidenalg import find_partition
        partition = find_partition(G, resolution_parameter=resolution)
    else:
        raise ValueError(f"Unknown algorithm: {algorithm}")

    logging.info(f"Clustering complete. Found {len(partition)} communities")

    # Assign cluster labels to nodes
    for i, community in enumerate(partition):
        for node in community:
            G.nodes[node]['cluster'] = i

    # Visualize the result
    pos = nx.spring_layout(G)
    plt.figure(figsize=(12, 8))
    nx.draw(G, pos, node_color=[G.nodes[n]['cluster'] for n in G.nodes], cmap=plt.cm.rainbow)
    plt.savefig("clustered_graph.png")
    logging.info("Clustered graph visualization saved as clustered_graph.png")

    return G
```

This enhanced version:
1. Logs the start of the clustering process and the graph's initial size.
2. Logs the number of communities found.
3. Visualizes the clustered graph, saving it as an image file.

These additional outputs can be invaluable when debugging clustering issues.

### Using Debuggers

For step-by-step debugging of graph algorithms, using a debugger like `pdb` (Python's built-in debugger) or an IDE's debugger can be very helpful. Here's an example of how you might use `pdb`:

```python
import pdb

def process_graph(G):
    for node in G.nodes:
        pdb.set_trace()  # The debugger will pause here for each node
        # Process the node...
```

When this function runs, it will pause at each node, allowing you to inspect the current state of the graph and the node being processed.

### Custom Debugging Utilities

For GraphRAG-specific debugging, we might create custom utilities. For example:

```python
# graphrag/utils/debug.py

import networkx as nx

def print_graph_summary(G):
    print(f"Graph Summary:")
    print(f"  Nodes: {len(G.nodes)}")
    print(f"  Edges: {len(G.edges)}")
    print(f"  Connected components: {nx.number_connected_components(G)}")
    print(f"  Largest component size: {len(max(nx.connected_components(G), key=len))}")

def print_node_details(G, node):
    print(f"Node Details for {node}:")
    print(f"  Degree: {G.degree[node]}")
    print(f"  Neighbors: {list(G.neighbors(node))}")
    print(f"  Attributes: {G.nodes[node]}")

# Usage:
# print_graph_summary(my_graph)
# print_node_details(my_graph, "Node A")
```

These utilities provide quick insights into the structure of a graph and details of specific nodes, which can be very helpful when debugging graph-related issues.

## Performance Profiling and Optimization

Performance is crucial in graph processing, especially for large graphs. Let's explore some techniques for profiling and optimizing GraphRAG.

### Using cProfile

Python's `cProfile` module is a powerful tool for identifying performance bottlenecks. Here's how we might use it to profile a GraphRAG pipeline:

```python
# graphrag/utils/profiling.py

import cProfile
import pstats
import io
from graphrag.index.run import run_pipeline_with_config

def profile_pipeline(config):
    pr = cProfile.Profile()
    pr.enable()

    # Run the pipeline
    list(run_pipeline_with_config(config))

    pr.disable()
    s = io.StringIO()
    sortby = 'cumulative'
    ps = pstats.Stats(pr, stream=s).sort_stats(sortby)
    ps.print_stats()
    return s.getvalue()

# Usage:
# config = load_config("my_config.yaml")
# profile_results = profile_pipeline(config)
# print(profile_results)
```

This will provide a detailed breakdown of where time is being spent in the pipeline, helping identify potential bottlenecks.

### Memory Profiling

For memory-intensive operations, tools like `memory_profiler` can be very useful. Here's an example of how to use it:

```python
# graphrag/utils/profiling.py

from memory_profiler import profile

@profile
def memory_intensive_operation(G):
    # Perform some memory-intensive graph operation...
    pass

# Usage:
# memory_intensive_operation(my_large_graph)
```

This will output a line-by-line analysis of memory usage, helping identify memory leaks or inefficient memory usage.

### Optimization Strategies

Once bottlenecks are identified, there are several strategies for optimization:

1. **Algorithmic Improvements**: Sometimes, using a more efficient algorithm can dramatically improve performance. For example, using approximate algorithms for certain graph problems can provide good results much faster than exact algorithms.

2. **Parallel Processing**: Many graph algorithms can benefit from parallelization. Python's `multiprocessing` module can be used for this:

   ```python
   from multiprocessing import Pool

   def process_node(node):
       # Process a single node...
       pass

   def parallel_node_processing(G):
       with Pool() as p:
           results = p.map(process_node, G.nodes())
       return results
   ```

3. **Caching**: For operations that are repeated often, caching results can significantly improve performance:

   ```python
   from functools import lru_cache

   @lru_cache(maxsize=None)
   def expensive_node_operation(node):
       # Perform some expensive operation on the node...
       pass
   ```

4. **Using Efficient Data Structures**: Sometimes, using a more appropriate data structure can improve performance. For example, using a set instead of a list for membership testing:

   ```python
   # Slow
   if node in list_of_nodes:
       # do something...

   # Fast
   if node in set_of_nodes:
       # do something...
   ```

Remember, premature optimization can lead to more complex, harder-to-maintain code. Always profile first to identify real bottlenecks before optimizing.

## Conclusion

In this lesson, we've explored the intricate details of testing and debugging GraphRAG. We've seen how unit tests can verify the correctness of individual components, how integration tests ensure that different parts of the system work together, and how to approach debugging complex graph operations. We've also looked at performance profiling and optimization strategies.

Key takeaways:
1. Unit tests are crucial for verifying the behavior of individual components like configuration classes and graph operations.
2. Mocking is essential when testing components that depend on external services like LLMs.
3. Integration tests help ensure that different parts of GraphRAG work together correctly in real-world scenarios.
4. Debugging graph operations often requires a combination of logging, visualization, and step-by-step debugging.
5. Performance profiling is crucial for identifying bottlenecks in graph processing pipelines.
6. Various optimization strategies, from algorithmic improvements to caching, can be applied to improve performance once bottlenecks are identified.

When working with GraphRAG, it's crucial to have a comprehensive testing strategy and to be prepared to debug complex graph operations


## Exercises

1. **Unit Test Creation**: Write a set of unit tests for the `ChunkingConfig` class in GraphRAG. Include tests for valid configurations, invalid configurations, and edge cases.

2. **Mock LLM Integration**: Create a mock LLM class that simulates different types of responses (successful, error, timeout). Use this mock to write tests for the `GraphExtractor` class that cover various scenarios.

3. **Integration Test Pipeline**: Design and implement an integration test for a complete GraphRAG pipeline that includes entity extraction, relationship detection, and community detection. Use sample input data and verify the output at each stage.

4. **Custom Debugging Tool**: Develop a custom debugging tool for GraphRAG that visualizes the state of a graph at different stages of processing. The tool should be able to output graph statistics and visualizations at specified checkpoints in the pipeline.

5. **Performance Profiling**: Use cProfile to profile the performance of a GraphRAG pipeline on a large dataset. Identify the top 3 performance bottlenecks and propose optimization strategies for each.

6. **Memory Optimization**: Use the `memory_profiler` to analyze the memory usage of the graph clustering function. Implement optimizations to reduce peak memory usage without significantly impacting performance.

7. **Parallel Processing**: Implement a parallel version of the entity extraction process using Python's `multiprocessing` module. Compare the performance of the parallel version with the sequential version for different input sizes.

8. **Error Handling Test**: Write a set of tests that verify the error handling capabilities of GraphRAG. Include scenarios such as invalid input data, network failures when calling LLMs, and out-of-memory errors during graph processing.

## Review Questions

1. What are the key differences between unit testing and integration testing in the context of GraphRAG? Provide examples of what each type of test would typically cover.

2. Explain the importance of mocking in testing GraphRAG components. How does mocking contribute to creating reliable and repeatable tests?

3. Describe three debugging techniques that are particularly useful for complex graph operations. How would you apply these techniques to debug a community detection algorithm that's producing unexpected results?

4. What role does logging play in the debugging process for GraphRAG? Provide an example of how you would enhance a graph processing function with logging to aid in debugging.

5. Explain the process of using cProfile to identify performance bottlenecks in a GraphRAG pipeline. What kinds of insights can you gain from this profiling, and how would you use this information?

6. Discuss the trade-offs between exact and approximate algorithms in graph processing. In what scenarios might you choose to use an approximate algorithm in GraphRAG, and what are the potential benefits and drawbacks?

7. How can parallel processing be applied to improve the performance of GraphRAG operations? Provide an example of a graph operation that could benefit from parallelization and explain how you would implement it.

8. Describe the concept of caching in the context of GraphRAG. When would caching be particularly beneficial, and what are some potential pitfalls to be aware of when implementing caching?

9. Explain the importance of cross-platform testing for GraphRAG. What strategies would you employ to ensure that GraphRAG functions correctly across different operating systems and environments?

10. Discuss the role of visualization in debugging graph operations. What types of visualizations would be most helpful for understanding the structure and properties of graphs in GraphRAG, and how would you implement these visualizations?

## Final Summary

Testing and debugging are critical aspects of developing and maintaining a complex system like GraphRAG. Throughout this lesson, we've explored a range of strategies and techniques:

1. **Unit Testing**: We've seen how to create targeted tests for individual components, ensuring that each part of GraphRAG functions correctly in isolation.

2. **Integration Testing**: We've discussed the importance of testing how different components interact within complete workflows and pipelines.

3. **Mocking**: We've explored how to use mocks to isolate components and test them independently of external services or complex dependencies.

4. **Debugging Techniques**: We've covered various approaches to debugging complex graph operations, including logging, visualization, and using debuggers.

5. **Performance Profiling**: We've looked at tools and techniques for identifying performance bottlenecks in GraphRAG pipelines.

6. **Optimization Strategies**: We've discussed various approaches to improving performance, from algorithmic improvements to parallelization and caching.

Remember that effective testing and debugging in GraphRAG requires a combination of:

- A deep understanding of graph theory and algorithms
- Familiarity with Python testing frameworks and debugging tools
- Knowledge of the specific components and workflows in GraphRAG
- An analytical approach to identifying and solving problems

As you work with GraphRAG, continually refine your testing suite and debugging techniques. This ongoing process will help ensure the reliability, performance, and maintainability of your GraphRAG implementations.

By mastering these testing and debugging skills, you'll be well-equipped to develop robust, efficient, and reliable graph-based applications using GraphRAG.

