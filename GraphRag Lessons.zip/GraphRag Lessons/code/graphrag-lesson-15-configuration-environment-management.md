# Lesson 15: Configuration and Environment Management in GraphRAG

## Introduction

In this lesson, we'll dive deep into the configuration and environment management system of GraphRAG. We'll explore how GraphRAG uses configuration files, environment variables, and code structures to manage its settings and adapt to different execution environments. By the end of this lesson, you'll have a comprehensive understanding of how to configure GraphRAG for various scenarios, handle environment-specific settings, and implement robust error handling for configuration issues.

## File Structure

Before we begin, let's examine the relevant file structure within the GraphRAG project:

```
graphrag/
├── config/
│   ├── config_file_loader.py
│   ├── create_graphrag_config.py
│   ├── defaults.py
│   ├── enums.py
│   ├── environment_reader.py
│   ├── errors.py
│   ├── load_config.py
│   ├── logging.py
│   ├── read_dotenv.py
│   ├── resolve_path.py
│   ├── __init__.py
│   ├── input_models/
│   │   ├── cache_config_input.py
│   │   ├── chunking_config_input.py
│   │   ├── claim_extraction_config_input.py
│   │   ├── ...
│   │   └── __init__.py
│   └── models/
│       ├── cache_config.py
│       ├── chunking_config.py
│       ├── claim_extraction_config.py
│       ├── ...
│       └── __init__.py
└── index/
    ├── config/
    │   ├── cache.py
    │   ├── input.py
    │   ├── pipeline.py
    │   ├── reporting.py
    │   ├── storage.py
    │   ├── workflow.py
    │   └── __init__.py
    └── ...
```

This structure shows the main components we'll be discussing in this lesson. The `config` directory contains modules for handling different aspects of configuration, while the `index/config` directory contains more specific configuration classes for the indexing pipeline.

## Deep Dive into GraphRagConfig and its Components

The heart of GraphRAG's configuration system is the `GraphRagConfig` class. This class is composed of multiple sub-configurations, each responsible for a specific aspect of the system. Let's explore the main components:

### GraphRagConfig

```python
# graphrag/config/models/graph_rag_config.py

class GraphRagConfig(BaseModel):
    root_dir: str
    encoding_model: str = Field(default=defaults.ENCODING_MODEL)
    skip_workflows: list[str] = Field(default_factory=list)
    llm: LLMConfig
    parallelization: ParallelizationParameters = Field(default_factory=ParallelizationParameters)
    async_mode: AsyncType = Field(default=defaults.ASYNC_MODE)
    embeddings: TextEmbeddingConfig
    chunks: ChunkingConfig
    input: InputConfig
    cache: CacheConfig
    storage: StorageConfig
    reporting: ReportingConfig
    entity_extraction: EntityExtractionConfig
    summarize_descriptions: SummarizeDescriptionsConfig
    claim_extraction: ClaimExtractionConfig
    community_reports: CommunityReportsConfig
    cluster_graph: ClusterGraphConfig
    embed_graph: EmbedGraphConfig
    umap: UMAPConfig
    snapshots: SnapshotsConfig
    local_search: LocalSearchConfig = Field(default_factory=LocalSearchConfig)
    global_search: GlobalSearchConfig = Field(default_factory=GlobalSearchConfig)
```

This class brings together all the configuration components needed for GraphRAG. Let's break down some of the key components:

1. **LLMConfig**: Configures the Large Language Model settings.
   
   ```python
   class LLMConfig(BaseModel):
       api_key: str
       type: LLMType
       model: str
       model_supports_json: bool = False
       max_tokens: int | None = None
       request_timeout: float | None = None
       # ... more fields ...
   ```

   This configuration allows users to specify the API key, model type, and various parameters for interacting with the language model.

2. **TextEmbeddingConfig**: Manages text embedding settings.

   ```python
   class TextEmbeddingConfig(BaseModel):
       target: TextEmbeddingTarget = Field(default=defaults.EMBEDDING_TARGET)
       skip: list[str] = Field(default_factory=list)
       llm: LLMConfig
       batch_size: int | None = None
       batch_max_tokens: int | None = None
       # ... more fields ...
   ```

   This configuration controls how text is embedded, including which elements to skip and batch processing parameters.

3. **ChunkingConfig**: Defines how text is split into chunks.

   ```python
   class ChunkingConfig(BaseModel):
       size: int = Field(default=defaults.CHUNK_SIZE)
       overlap: int = Field(default=defaults.CHUNK_OVERLAP)
       group_by_columns: list[str] = Field(default=defaults.CHUNK_GROUP_BY_COLUMNS)
       # ... more fields ...
   ```

   This allows users to control the size and overlap of text chunks, which is crucial for processing large documents.

4. **InputConfig**, **CacheConfig**, **StorageConfig**, **ReportingConfig**: These configurations manage various I/O aspects of GraphRAG.

Each of these configurations is designed to be extensible and adaptable to different use cases. For example, the `StorageConfig` can be specialized for different storage backends:

```python
class StorageConfig(BaseModel):
    type: StorageType
    base_dir: str | None = None

class BlobStorageConfig(StorageConfig):
    type: Literal[StorageType.blob] = StorageType.blob
    connection_string: str | None = None
    container_name: str
    storage_account_blob_url: str | None = None
```

This structure allows GraphRAG to easily support multiple storage options while maintaining a consistent configuration interface.

## Environment Variable Handling and .env Files

GraphRAG uses environment variables to manage sensitive information and environment-specific settings. The system supports loading these variables from `.env` files, making it easy to manage different configurations for development, testing, and production environments.

### Reading .env Files

The `read_dotenv` function in `graphrag/config/read_dotenv.py` is responsible for loading environment variables from a `.env` file:

```python
def read_dotenv(path: str | Path | None = None) -> None:
    base_dir = Path(path or ".").resolve()
    dotenv_path = base_dir / ".env"
    if dotenv_path.exists():
        load_dotenv(dotenv_path)
```

This function looks for a `.env` file in the specified directory (or the current directory if not specified) and loads its contents into the environment.

### Using Environment Variables in Configuration

Environment variables can be used in YAML configuration files using the `!ENV` tag. For example:

```yaml
llm:
  api_key: !ENV ${GRAPHRAG_API_KEY}
  type: openai
  model: !ENV ${GRAPHRAG_MODEL:gpt-4-turbo-preview}
```

This allows for flexible configuration that can adapt to different environments without changing the configuration files.

## Configuration Validation and Error Handling

GraphRAG implements robust validation and error handling for its configuration to ensure that the system is correctly set up before running.

### Validation

The `pydantic` library is used extensively for configuration validation. Each configuration class inherits from `pydantic.BaseModel`, which provides automatic validation of field types and values.

For example, in the `LLMConfig` class:

```python
class LLMConfig(BaseModel):
    api_key: str
    type: LLMType
    model: str
    # ... more fields ...

    @validator("type")
    def validate_llm_type(cls, v):
        if v not in LLMType.__members__:
            raise ValueError(f"Invalid LLM type: {v}")
        return v
```

This ensures that the `type` field is a valid `LLMType` enum value.

### Error Handling

GraphRAG uses custom exception classes for configuration-related errors, defined in `graphrag/config/errors.py`:

```python
class ConfigurationError(Exception):
    """Base class for configuration errors."""

class MissingConfigurationError(ConfigurationError):
    """Exception raised when a required configuration is missing."""

class InvalidConfigurationError(ConfigurationError):
    """Exception raised when a configuration is invalid."""
```

These custom exceptions allow for more specific error handling and provide clear feedback to users when configuration issues arise.

## Cross-platform Considerations in Configuration

GraphRAG is designed to work across different operating systems. Here are some key considerations:

1. **Path Handling**: The `pathlib` library is used for cross-platform path manipulation.

   ```python
   from pathlib import Path

   config_path = Path(config_file).resolve()
   ```

2. **Environment Variables**: Environment variables are used instead of hard-coded paths or settings, allowing for easy adaptation to different environments.

3. **File Encodings**: UTF-8 encoding is used by default for configuration files, ensuring consistency across platforms.

   ```python
   with open(config_path, "r", encoding="utf-8") as f:
       config_data = yaml.safe_load(f)
   ```

## Implementing Custom Configuration Components

GraphRAG's modular configuration system allows for easy extension with custom components. Here's how you can create a custom configuration:

1. Define your configuration class in a new file in the `graphrag/config/models/` directory.
2. Inherit from `pydantic.BaseModel` and define your fields.
3. Implement any necessary validation methods.
4. Update the `GraphRagConfig` class to include your new configuration.

Example of a custom configuration for a hypothetical plugin system:

```python
# graphrag/config/models/plugin_config.py

from pydantic import BaseModel, Field
from typing import List

class PluginConfig(BaseModel):
    enabled_plugins: List[str] = Field(default_factory=list)
    plugin_directory: str = "./plugins"

    @validator("plugin_directory")
    def validate_plugin_directory(cls, v):
        path = Path(v)
        if not path.is_dir():
            raise ValueError(f"Plugin directory does not exist: {v}")
        return str(path.resolve())

# Update GraphRagConfig
class GraphRagConfig(BaseModel):
    # ... existing fields ...
    plugins: PluginConfig = Field(default_factory=PluginConfig)
```

This new configuration can now be used throughout the GraphRAG system to manage plugin-related settings.

## Conclusion

In this lesson, we've explored the intricate details of GraphRAG's configuration and environment management system. We've seen how the `GraphRagConfig` class brings together various configuration components, how environment variables and `.env` files are used to manage sensitive and environment-specific settings, and how the system implements validation and error handling.

Key takeaways:
1. GraphRAG uses a hierarchical configuration system with the `GraphRagConfig` class at its core.
2. Environment variables and `.env` files provide flexibility for different deployment scenarios.
3. The `pydantic` library is used extensively for configuration validation and type checking.
4. Custom exception classes allow for specific error handling related to configuration issues.
5. Cross-platform considerations are built into the configuration system, ensuring consistency across different operating systems.
6. The modular design allows for easy extension with custom configuration components.

When working with GraphRAG, it's crucial to understand these configuration mechanisms to effectively set up and customize the system for your specific use case. Proper configuration management ensures that GraphRAG can adapt to various environments and requirements while maintaining robust error handling and validation.

## Exercises

1. Create a custom configuration component for a new feature in GraphRAG, such as a data preprocessing step. Implement the necessary validation logic and integrate it into the `GraphRagConfig` class.

2. Modify the `read_dotenv` function to support multiple `.env` files (e.g., `.env.development`, `.env.production`) and implement a mechanism to choose the appropriate file based on a runtime argument.

3. Implement a configuration migration system that can update old configuration files to a new format when the structure of `GraphRagConfig` changes.

4. Create a command-line interface for validating GraphRAG configuration files, providing detailed error messages for any validation issues.

5. Extend the configuration system to support remote configuration sources (e.g., a configuration server or a database) in addition to local files.

## Review Questions

1. Explain the role of the `GraphRagConfig` class in GraphRAG's configuration system. How does its structure facilitate the management of complex configurations?

2. How does GraphRAG handle sensitive information like API keys in its configuration? What are the advantages and potential drawbacks of this approach?

3. Describe the process of adding a new configuration option to an existing component of GraphRAG. What steps would you need to take to ensure it's properly integrated and validated?

4. How does GraphRAG's use of environment variables and `.env` files contribute to its flexibility across different deployment environments?

5. Explain the importance of configuration validation in GraphRAG. How does the system leverage `pydantic` for this purpose, and what are the benefits of this approach?

6. Discuss the cross-platform considerations in GraphRAG's configuration system. How does the system ensure consistent behavior across different operating systems?

7. How does GraphRAG's configuration error handling contribute to the overall robustness of the system? Provide an example of how custom exception classes are used.

8. Compare and contrast the different storage configuration options available in GraphRAG. How does the configuration system support multiple storage backends?

9. Explain the role of the `ChunkingConfig` in GraphRAG. How might different chunking configurations affect the system's performance and output?

10. Describe a scenario where you might need to implement a custom configuration component for GraphRAG. What considerations would you need to keep in mind during the implementation?

By understanding these concepts and completing the exercises, you'll gain a comprehensive grasp of GraphRAG's configuration and environment management capabilities. This knowledge will enable you to effectively set up, customize, and troubleshoot GraphRAG deployments across various scenarios and environments.

