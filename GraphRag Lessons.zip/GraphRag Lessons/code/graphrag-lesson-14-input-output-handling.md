# Lesson 14: Input and Output Handling in GraphRAG

## Introduction

In this lesson, we'll dive deep into how GraphRAG handles input data loading, preprocessing, and output generation. We'll explore the various input types supported by GraphRAG, such as CSV and text files, and how the system processes and transforms this data. We'll also look at the output formats GraphRAG can produce, including Parquet, CSV, and JSON. By the end of this lesson, you'll have a comprehensive understanding of GraphRAG's input/output mechanisms and be able to implement custom handlers for specific use cases.

## File Structure

Before we begin, let's take a look at the relevant file structure within the GraphRAG project:

```
graphrag/
├── index/
│   ├── input/
│   │   ├── csv.py
│   │   ├── load_input.py
│   │   ├── text.py
│   │   └── __init__.py
│   ├── emit/
│   │   ├── csv_table_emitter.py
│   │   ├── factories.py
│   │   ├── json_table_emitter.py
│   │   ├── parquet_table_emitter.py
│   │   ├── table_emitter.py
│   │   ├── types.py
│   │   └── __init__.py
│   └── config/
│       ├── input.py
│       └── ...
└── config/
    ├── models/
    │   ├── input_config.py
    │   └── ...
    └── ...
```

This structure shows the main components we'll be discussing in this lesson. The `input` directory contains modules for handling different input types, while the `emit` directory deals with output generation. The `config` directory contains configuration-related code for input and output operations.

## Input Data Loading and Preprocessing

### Understanding Input Configuration

GraphRAG uses a flexible configuration system to define how input data should be loaded and processed. The main configuration classes for input handling are defined in `graphrag/config/models/input_config.py`:

```python
class InputConfig(BaseModel):
    type: InputType
    file_type: InputFileType
    base_dir: str | None = None
    file_pattern: str
    file_filter: dict[str, str] | None = None
    encoding: str | None = None
    connection_string: str | None = None
    container_name: str | None = None
    storage_account_blob_url: str | None = None

class CSVInputConfig(InputConfig):
    source_column: str | None = None
    timestamp_column: str | None = None
    timestamp_format: str | None = None
    text_column: str | None = None
    title_column: str | None = None

class TextInputConfig(InputConfig):
    title_text_length: int | None = None
```

These configuration classes allow users to specify details such as the input type (file or blob storage), file type (CSV or text), directory paths, file patterns, and specific column mappings for CSV files.

### Loading Input Data

The main entry point for loading input data is the `load_input` function in `graphrag/index/input/load_input.py`:

```python
async def load_input(
    config: PipelineInputConfig | InputConfig,
    progress_reporter: ProgressReporter | None = None,
    root_dir: str | None = None,
) -> pd.DataFrame:
    # ... implementation details ...
```

This function takes an input configuration and returns a pandas DataFrame containing the loaded data. It supports different input types and storage backends:

1. File-based input:
   - For CSV files: Handled by `graphrag/index/input/csv.py`
   - For text files: Handled by `graphrag/index/input/text.py`

2. Blob storage input:
   - Uses Azure Blob Storage for both CSV and text files

Let's look at how CSV files are loaded:

```python
# graphrag/index/input/csv.py

async def load(
    config: PipelineInputConfig,
    progress: ProgressReporter | None,
    storage: PipelineStorage,
) -> pd.DataFrame:
    # ... implementation details ...

    async def load_file(path: str, group: dict | None) -> pd.DataFrame:
        buffer = BytesIO(await storage.get(path, as_bytes=True))
        data = pd.read_csv(buffer, encoding=config.encoding or "latin-1")
        # ... additional processing ...
        return data

    # ... file discovery and loading logic ...
```

This function reads CSV files, applies any specified column mappings, and performs additional processing such as generating unique IDs and parsing timestamps.

For text files, a similar process is followed, but with different parsing logic:

```python
# graphrag/index/input/text.py

async def load(
    config: PipelineInputConfig,
    progress: ProgressReporter | None,
    storage: PipelineStorage,
) -> pd.DataFrame:
    # ... implementation details ...

    async def load_file(
        path: str, group: dict | None = None, _encoding: str = "utf-8"
    ) -> dict[str, Any]:
        text = await storage.get(path, encoding="utf-8")
        new_item = {**group, "text": text}
        new_item["id"] = gen_md5_hash(new_item, new_item.keys())
        new_item["title"] = str(Path(path).name)
        return new_item

    # ... file discovery and loading logic ...
```

### Preprocessing

After loading the raw data, GraphRAG performs several preprocessing steps:

1. **ID Generation**: If not present, unique IDs are generated for each document.
2. **Timestamp Parsing**: For CSV inputs with timestamp columns, dates are parsed and split into separate year, month, day, hour, minute, and second columns.
3. **Title Extraction**: For text inputs, titles are extracted from filenames or the beginning of the text content.
4. **Encoding Handling**: The system handles different text encodings, defaulting to UTF-8 for text files and Latin-1 for CSV files.

## Output Generation and Formatting

GraphRAG supports multiple output formats, including Parquet, CSV, and JSON. The output generation is handled by the `emit` module.

### Table Emitter Interface

The base interface for output generation is defined in `graphrag/index/emit/table_emitter.py`:

```python
class TableEmitter(Protocol):
    async def emit(self, name: str, data: pd.DataFrame) -> None:
        """Emit a dataframe to storage."""
```

This protocol defines a common interface for all output emitters, allowing for easy extension and customization.

### Output Formats

1. **Parquet Output**:
   Implemented in `graphrag/index/emit/parquet_table_emitter.py`:

   ```python
   class ParquetTableEmitter(TableEmitter):
       async def emit(self, name: str, data: pd.DataFrame) -> None:
           filename = f"{name}.parquet"
           log.info("emitting parquet table %s", filename)
           try:
               await self._storage.set(filename, data.to_parquet())
           except (ArrowTypeError, ArrowInvalid) as e:
               # ... error handling ...
   ```

   Parquet is a columnar storage format that provides efficient compression and encoding schemes, making it ideal for large-scale data processing.

2. **CSV Output**:
   Implemented in `graphrag/index/emit/csv_table_emitter.py`:

   ```python
   class CSVTableEmitter(TableEmitter):
       async def emit(self, name: str, data: pd.DataFrame) -> None:
           filename = f"{name}.csv"
           log.info("emitting CSV table %s", filename)
           await self._storage.set(
               filename,
               data.to_csv(),
           )
   ```

   CSV (Comma-Separated Values) is a simple, widely supported format for tabular data.

3. **JSON Output**:
   Implemented in `graphrag/index/emit/json_table_emitter.py`:

   ```python
   class JsonTableEmitter(TableEmitter):
       async def emit(self, name: str, data: pd.DataFrame) -> None:
           filename = f"{name}.json"
           log.info("emitting JSON table %s", filename)
           await self._storage.set(
               filename,
               data.to_json(orient="records", lines=True, force_ascii=False),
           )
   ```

   JSON (JavaScript Object Notation) provides a human-readable, hierarchical data format.

### Emitter Factory

To simplify the creation of appropriate emitters, GraphRAG uses a factory pattern implemented in `graphrag/index/emit/factories.py`:

```python
def create_table_emitter(
    emitter_type: TableEmitterType,
    storage: PipelineStorage,
    on_error: ErrorHandlerFn
) -> TableEmitter:
    match emitter_type:
        case TableEmitterType.Json:
            return JsonTableEmitter(storage)
        case TableEmitterType.Parquet:
            return ParquetTableEmitter(storage, on_error)
        case TableEmitterType.CSV:
            return CSVTableEmitter(storage)
        case _:
            raise ValueError(f"Unsupported table emitter type: {emitter_type}")
```

This factory function allows the system to create the appropriate emitter based on the desired output format.

## Implementing Custom Input and Output Handlers

GraphRAG's modular design allows for easy implementation of custom input and output handlers. Here's how you can extend the system:

### Custom Input Handler

To create a custom input handler for a new file type:

1. Create a new module in the `graphrag/index/input/` directory.
2. Implement an async `load` function that takes a `PipelineInputConfig`, `ProgressReporter`, and `PipelineStorage` as arguments.
3. Register the new input type in `graphrag/config/enums.py` and update the `load_input` function in `load_input.py` to use your new handler.

Example skeleton for a custom XML input handler:

```python
# graphrag/index/input/xml.py

import xml.etree.ElementTree as ET
import pandas as pd

async def load(
    config: PipelineInputConfig,
    progress: ProgressReporter | None,
    storage: PipelineStorage,
) -> pd.DataFrame:
    async def load_file(path: str, group: dict | None) -> pd.DataFrame:
        xml_content = await storage.get(path, encoding=config.encoding or "utf-8")
        root = ET.fromstring(xml_content)
        # Parse XML and convert to DataFrame
        # ...
        return data

    # Implement file discovery and loading logic
    # ...

    return pd.concat(files_loaded)
```

### Custom Output Handler

To create a custom output handler:

1. Create a new class that implements the `TableEmitter` protocol in the `graphrag/index/emit/` directory.
2. Implement the `emit` method to handle the output generation.
3. Update the `create_table_emitter` factory function to support your new emitter type.

Example skeleton for a custom YAML output handler:

```python
# graphrag/index/emit/yaml_table_emitter.py

import yaml
from graphrag.index.emit.table_emitter import TableEmitter

class YamlTableEmitter(TableEmitter):
    def __init__(self, storage: PipelineStorage):
        self._storage = storage

    async def emit(self, name: str, data: pd.DataFrame) -> None:
        filename = f"{name}.yaml"
        log.info("emitting YAML table %s", filename)
        yaml_data = yaml.dump(data.to_dict(orient="records"), allow_unicode=True)
        await self._storage.set(filename, yaml_data)
```

Then update the factory:

```python
# graphrag/index/emit/factories.py

def create_table_emitter(
    emitter_type: TableEmitterType,
    storage: PipelineStorage,
    on_error: ErrorHandlerFn
) -> TableEmitter:
    match emitter_type:
        # ... existing cases ...
        case TableEmitterType.Yaml:
            return YamlTableEmitter(storage)
        # ...
```

## Conclusion

In this lesson, we've explored the intricacies of input and output handling in GraphRAG. We've seen how the system loads different types of input data, preprocesses it, and generates output in various formats. The modular design of GraphRAG allows for easy extension and customization of both input and output handlers.

Key takeaways:
1. GraphRAG supports multiple input types (CSV, text) and storage backends (file-based, Azure Blob Storage).
2. Input configuration is flexible and allows for detailed specification of data loading parameters.
3. Preprocessing steps include ID generation, timestamp parsing, and title extraction.
4. Output can be generated in multiple formats (Parquet, CSV, JSON) using a common `TableEmitter` interface.
5. The system can be extended with custom input and output handlers to support new data formats or storage systems.

In your projects, consider the specific requirements of your data sources and output needs. GraphRAG's flexible architecture allows you to adapt the system to various use cases while maintaining a consistent interface for data processing pipelines.

## Exercises

1. Implement a custom input handler for XML files, following the structure of the existing CSV and text handlers.
2. Create a custom output handler for YAML files, implementing the `TableEmitter` protocol.
3. Modify the `load_input` function to support your new XML input handler, and update the necessary configuration classes.
4. Implement error handling and logging in your custom handlers, following the patterns used in the existing code.
5. Write unit tests for your new input and output handlers to ensure they work correctly with the rest of the GraphRAG system.

## Review Questions

1. How does GraphRAG handle different input file types? Describe the process for both CSV and text inputs.
2. What preprocessing steps does GraphRAG perform on input data, and why are these steps important?
3. Explain the role of the `TableEmitter` protocol in output generation. How does this design facilitate the addition of new output formats?
4. How does GraphRAG's factory pattern for creating table emitters contribute to the system's extensibility?
5. Describe the process of implementing a custom input handler for a new file type. What components need to be modified or created?
6. How does GraphRAG handle errors during input loading and output generation? Why is proper error handling important in these processes?
7. Explain the differences between Parquet, CSV, and JSON output formats. In what scenarios might each format be preferable?
8. How does GraphRAG's input and output handling system contribute to its overall pipeline architecture?
9. What considerations should be taken into account when implementing custom input or output handlers for large-scale data processing?
10. How might GraphRAG's input and output handling be extended to support streaming data or real-time processing?

By understanding these concepts and completing the exercises, you'll gain a comprehensive grasp of GraphRAG's input and output handling capabilities and be well-equipped to extend the system for various data processing needs.

