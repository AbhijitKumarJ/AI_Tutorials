# Lesson 1: Introduction to GraphRAG and Project Structure

## 1. Overview of the GraphRAG project and its purpose

GraphRAG (Graph Retrieval-Augmented Generation) is an advanced information retrieval and processing system that combines graph-based data structures with large language models (LLMs) to enhance the capabilities of traditional RAG systems. The primary purpose of GraphRAG is to efficiently process, analyze, and generate insights from large volumes of textual data by leveraging the power of graph representations and natural language processing.

Key features of GraphRAG include:
- Entity extraction and relationship mapping
- Graph-based information retrieval
- Text summarization and report generation
- Customizable workflows for various NLP tasks
- Integration with popular LLMs like OpenAI's GPT models

GraphRAG is designed to be highly modular and extensible, allowing developers to customize and extend its functionality for specific use cases in areas such as knowledge management, content analysis, and information synthesis.

## 2. Understanding the project structure and main components

The GraphRAG project follows a well-organized structure to maintain code clarity and separation of concerns. Let's examine the main components and their purposes:

```
graphrag/
├── api/
├── callbacks/
├── config/
│   ├── input_models/
│   └── models/
├── index/
│   ├── cache/
│   ├── config/
│   ├── emit/
│   ├── flows/
│   ├── graph/
│   │   ├── embedding/
│   │   ├── extractors/
│   │   ├── utils/
│   │   └── visualization/
│   ├── input/
│   ├── llm/
│   ├── operations/
│   ├── run/
│   ├── storage/
│   ├── text_splitting/
│   ├── update/
│   ├── utils/
│   └── workflows/
├── llm/
├── logging/
├── model/
├── prompt_tune/
├── query/
├── utils/
└── vector_stores/
```

Let's break down the main directories and their purposes:

- `api/`: Contains the API endpoints for interacting with GraphRAG.
- `callbacks/`: Implements various callback mechanisms for progress reporting and error handling.
- `config/`: Manages configuration models and input validation for the entire project.
- `index/`: The core of GraphRAG, containing the main processing pipeline and associated components.
- `llm/`: Handles interactions with large language models.
- `logging/`: Provides logging utilities for the project.
- `model/`: Defines core data models used throughout the system.
- `prompt_tune/`: Tools for fine-tuning prompts used in LLM interactions.
- `query/`: Implements query processing and execution.
- `utils/`: General utility functions used across the project.
- `vector_stores/`: Manages vector storage and retrieval for embeddings.

This structure allows for clear separation of concerns and makes it easier to maintain and extend the project.

## 3. Key modules: index, config, workflows, operations, storage

Let's dive deeper into some of the key modules of GraphRAG:

### 3.1. index

The `index` module is the heart of GraphRAG, containing the core processing pipeline and associated components. It's responsible for managing the indexing process, which involves extracting entities, building graphs, and generating embeddings.

Key components of the `index` module include:
- `cache/`: Implements caching mechanisms to improve performance.
- `flows/`: Contains the main processing flows for various tasks.
- `graph/`: Manages graph-related operations, including entity extraction and graph construction.
- `operations/`: Implements various data processing operations used in the pipeline.
- `run/`: Handles the execution of the indexing pipeline.
- `workflows/`: Defines the sequence of operations for different indexing tasks.

### 3.2. config

The `config` module is responsible for managing the configuration of GraphRAG. It uses Pydantic models to ensure type safety and validation of configuration parameters.

Key components of the `config` module include:
- `input_models/`: Defines Pydantic models for input validation.
- `models/`: Contains the main configuration models used throughout the project.

Example of a configuration model (`graphrag/config/models/graph_rag_config.py`):

```python
from pydantic import BaseModel, Field

class GraphRagConfig(BaseModel):
    root_dir: str = Field(description="The root directory for the project")
    encoding_model: str = Field(description="The encoding model to use for tokenization")
    skip_workflows: list[str] = Field(default_factory=list, description="Workflows to skip")
    # ... other configuration fields ...
```

### 3.3. workflows

The `workflows` module defines the sequence of operations that make up the indexing pipeline. Each workflow is a series of steps that perform specific tasks, such as entity extraction, graph construction, or text summarization.

Workflows are defined using a declarative syntax, making it easy to customize and extend the pipeline for different use cases.

Example of a workflow definition (`graphrag/index/workflows/v1/create_base_documents.py`):

```python
from graphrag.index.config import PipelineWorkflowConfig, PipelineWorkflowStep

workflow_name = "create_base_documents"

def build_steps(
    config: PipelineWorkflowConfig,
) -> list[PipelineWorkflowStep]:
    document_attribute_columns = config.get("document_attribute_columns", [])
    return [
        {
            "verb": "create_base_documents",
            "args": {
                "document_attribute_columns": document_attribute_columns,
            },
            "input": {
                "source": DEFAULT_INPUT_NAME,
                "text_units": "workflow:create_final_text_units",
            },
        },
    ]
```

### 3.4. operations

The `operations` module contains the individual data processing operations used in the pipeline. These operations are the building blocks of workflows and perform tasks such as text chunking, entity extraction, and graph manipulation.

Example of an operation (`graphrag/index/operations/chunk_text/chunk_text.py`):

```python
import pandas as pd
from datashaper import VerbCallbacks

def chunk_text(
    input: pd.DataFrame,
    column: str,
    to: str,
    callbacks: VerbCallbacks,
    strategy: dict[str, Any] | None = None,
) -> pd.DataFrame:
    # ... implementation of text chunking ...
```

### 3.5. storage

The `storage` module handles data persistence and retrieval for GraphRAG. It provides abstractions for different storage backends, such as in-memory storage, file-based storage, and cloud storage solutions like Azure Blob Storage.

Example of a storage implementation (`graphrag/index/storage/file_pipeline_storage.py`):

```python
import os
from pathlib import Path
from typing import Any

from graphrag.index.storage.typing import PipelineStorage

class FilePipelineStorage(PipelineStorage):
    def __init__(self, root_dir: str | None = None, encoding: str | None = None):
        self._root_dir = root_dir or ""
        self._encoding = encoding or "utf-8"
        Path(self._root_dir).mkdir(parents=True, exist_ok=True)

    async def get(self, key: str, as_bytes: bool | None = False, encoding: str | None = None) -> Any:
        # ... implementation of file retrieval ...

    async def set(self, key: str, value: Any, encoding: str | None = None) -> None:
        # ... implementation of file storage ...

    # ... other methods ...
```

## 4. Configuration management using YAML files

GraphRAG uses YAML files for configuration management, allowing users to easily customize the behavior of the system without modifying the code. The YAML configuration files are parsed and validated using the Pydantic models defined in the `config` module.

Example of a GraphRAG configuration file (`settings.yaml`):

```yaml
encoding_model: cl100k_base
skip_workflows: []
llm:
  api_key: ${GRAPHRAG_API_KEY}
  type: openai
  model: gpt-4-turbo-preview
  model_supports_json: true

embeddings:
  async_mode: asyncio
  llm:
    api_key: ${GRAPHRAG_API_KEY}
    type: openai_embedding
    model: text-embedding-3-small

chunks:
  size: 1000
  overlap: 100
  group_by_columns: [id]

input:
  type: file
  file_type: csv
  base_dir: "./input"
  file_encoding: utf-8
  file_pattern: ".*\\.csv$"

cache:
  type: file
  base_dir: "./cache"

storage:
  type: file
  base_dir: "./output"

reporting:
  type: file
  base_dir: "./reports"

# ... other configuration sections ...
```

This configuration file allows users to specify various aspects of GraphRAG's behavior, such as the LLM to use, embedding settings, input data location, and storage options.

## 5. Dependency management with requirements.txt

GraphRAG manages its dependencies using a `requirements.txt` file, which lists all the required Python packages and their versions. This ensures that all developers and users are working with compatible versions of the dependencies.

Example `requirements.txt`:

```
aiofiles==23.2.1
azure-identity==1.15.0
azure-storage-blob==12.19.0
datashaper==0.1.28
graspologic==3.3.2
networkx==3.2.1
nltk==3.8.1
numpy==1.26.4
openai==1.11.1
pandas==2.2.1
pyarrow==15.0.0
pydantic==2.6.1
pyaml-env==1.2.1
tiktoken==0.5.2
umap-learn==0.5.5
```

To install the dependencies, users can run:

```
pip install -r requirements.txt
```

This ensures that all the required packages are installed with the correct versions, minimizing potential compatibility issues.

## Conclusion

In this lesson, we've explored the fundamental structure and components of the GraphRAG project. We've covered the project's purpose, its main modules, configuration management, and dependency handling. This overview provides a solid foundation for understanding how GraphRAG is organized and how its various components work together to create a powerful graph-based RAG system.

In the next lesson, we'll dive deeper into the Python fundamentals used throughout the GraphRAG codebase, including dataclasses, type hints, exception handling, and asynchronous programming.

## Review Questions

1. What is the main purpose of GraphRAG, and how does it enhance traditional RAG systems?
2. Describe the key components of the GraphRAG project structure and their roles.
3. How does GraphRAG manage configuration, and what are the benefits of using YAML files for this purpose?
4. Explain the role of the `index` module in GraphRAG and list some of its key subcomponents.
5. How are workflows defined in GraphRAG, and why is this approach beneficial?
6. Describe the purpose of the `operations` module and give an example of an operation.
7. What is the role of the `storage` module, and what types of storage backends does it support?
8. How does GraphRAG manage its dependencies, and why is this important for the project?

## Hands-on Exercise

Create a simple GraphRAG configuration file (`my_graphrag_config.yaml`) that includes the following settings:

1. Set the encoding model to "cl100k_base"
2. Configure the LLM to use OpenAI's GPT-4 model
3. Set up file-based input for CSV files in a directory called "my_input"
4. Configure file-based storage for output in a directory called "my_output"
5. Set the chunk size to 800 and overlap to 50

After creating the configuration file, write a Python script that loads and validates the configuration using the appropriate Pydantic models from the GraphRAG codebase. Print out the validated configuration to ensure it's correctly loaded.

This exercise will help you understand how GraphRAG manages configuration and how to work with its configuration models.

