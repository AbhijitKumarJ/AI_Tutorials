# Lesson 5: Large Language Models (LLMs) Integration in GraphRAG

## Introduction

In this lesson, we'll explore how GraphRAG integrates Large Language Models (LLMs) into its architecture. We'll focus on the implementation details, including how GraphRAG works with different LLM providers, handles API interactions, and manages prompts for various tasks. By the end of this lesson, you'll have a deep understanding of how LLMs are leveraged within the GraphRAG codebase.

## File Structure

Before we dive into the details, let's look at the relevant file structure for LLM integration in GraphRAG:

```
graphrag/
├── index/
│   ├── llm/
│   │   ├── __init__.py
│   │   ├── load_llm.py
│   │   └── types.py
├── llm/
│   ├── __init__.py
│   ├── base/
│   │   ├── base_llm.py
│   │   ├── caching_llm.py
│   │   └── rate_limiting_llm.py
│   ├── errors.py
│   ├── limiting/
│   │   ├── composite_limiter.py
│   │   ├── create_limiters.py
│   │   ├── llm_limiter.py
│   │   ├── noop_llm_limiter.py
│   │   └── tpm_rpm_limiter.py
│   ├── mock/
│   │   ├── mock_chat_llm.py
│   │   └── mock_completion_llm.py
│   ├── openai/
│   │   ├── create_openai_client.py
│   │   ├── factories.py
│   │   ├── json_parsing_llm.py
│   │   ├── openai_chat_llm.py
│   │   ├── openai_completion_llm.py
│   │   ├── openai_configuration.py
│   │   ├── openai_embeddings_llm.py
│   │   ├── openai_history_tracking_llm.py
│   │   ├── openai_token_replacing_llm.py
│   │   ├── types.py
│   │   └── utils.py
│   └── types/
│       ├── llm.py
│       ├── llm_cache.py
│       ├── llm_callbacks.py
│       ├── llm_config.py
│       ├── llm_invocation_result.py
│       ├── llm_io.py
│       └── llm_types.py
```

This structure shows the organization of LLM-related code in GraphRAG. The `index/llm/` directory contains high-level integration code, while the `llm/` directory houses the core LLM implementation.

## LLM Integration Overview

GraphRAG integrates LLMs primarily through two main interfaces: `CompletionLLM` for text generation tasks and `EmbeddingLLM` for text embedding tasks. These interfaces are implemented for different LLM providers, with OpenAI and Azure OpenAI being the primary supported providers.

### Key Components

1. **LLM Configuration**: The `OpenAIConfiguration` class in `llm/openai/openai_configuration.py` manages the configuration for OpenAI and Azure OpenAI services.

2. **LLM Loading**: The `load_llm` and `load_llm_embeddings` functions in `index/llm/load_llm.py` are responsible for creating and configuring LLM instances based on the provided settings.

3. **Rate Limiting**: The `llm/limiting/` directory contains implementations for rate limiting to ensure API usage stays within allowed limits.

4. **Caching**: The `llm/base/caching_llm.py` file implements caching mechanisms to reduce redundant API calls and improve performance.

5. **Error Handling**: The `llm/errors.py` file defines custom error types for LLM-related exceptions.

## Detailed Implementation Analysis

### LLM Configuration

The `OpenAIConfiguration` class in `llm/openai/openai_configuration.py` is central to configuring LLM usage in GraphRAG. Let's examine its key attributes:

```python
class OpenAIConfiguration:
    api_key: str
    api_base: str | None
    api_version: str | None
    organization: str | None
    proxy: str | None
    model: str
    model_supports_json: bool
    deployment_name: str | None
    max_tokens: int | None
    temperature: float
    top_p: float
    n: int
    tokens_per_minute: float | None
    requests_per_minute: float | None
    max_retries: int
    max_retry_wait: float
    sleep_on_rate_limit_recommendation: bool
    concurrent_requests: int
    encoding_model: str
    cognitive_services_endpoint: str | None
```

This configuration allows for fine-grained control over LLM behavior, including API endpoints, model selection, rate limiting, and output parameters. The `model_supports_json` flag is particularly important for tasks that require structured output.

### LLM Loading

The `load_llm` function in `index/llm/load_llm.py` is responsible for creating LLM instances. Here's a simplified version of its implementation:

```python
def load_llm(
    name: str,
    llm_type: LLMType,
    callbacks: VerbCallbacks,
    cache: PipelineCache | None,
    llm_config: dict[str, Any] | None = None,
    chat_only=False,
) -> CompletionLLM:
    on_error = _create_error_handler(callbacks)
    if llm_type in loaders:
        if chat_only and not loaders[llm_type]["chat"]:
            raise ValueError(f"LLM type {llm_type} does not support chat")
        if cache is not None:
            cache = cache.child(name)
        loader = loaders[llm_type]
        return loader["load"](on_error, cache, llm_config or {})
    raise ValueError(f"Unknown LLM type {llm_type}")
```

This function uses a dictionary of loaders to instantiate the appropriate LLM based on the specified type. It also handles caching and error callbacks.

### Rate Limiting

Rate limiting is crucial for managing API usage. The `TpmRpmLLMLimiter` class in `llm/limiting/tpm_rpm_limiter.py` implements a token-per-minute (TPM) and requests-per-minute (RPM) limiter:

```python
class TpmRpmLLMLimiter(LLMLimiter):
    def __init__(
        self,
        tokens_per_minute: float | None = None,
        requests_per_minute: float | None = None,
    ):
        self._tpm_limiter = LeakyBucketLimiter(tokens_per_minute, 60) if tokens_per_minute else None
        self._rpm_limiter = LeakyBucketLimiter(requests_per_minute, 60) if requests_per_minute else None

    async def wait(self, num_tokens: int):
        if self._tpm_limiter:
            await self._tpm_limiter.acquire(num_tokens)
        if self._rpm_limiter:
            await self._rpm_limiter.acquire(1)
```

This limiter uses a leaky bucket algorithm to enforce rate limits on both token usage and request frequency.

### Caching

The `CachingLLM` class in `llm/base/caching_llm.py` implements caching for LLM responses:

```python
class CachingLLM(BaseLLM):
    def __init__(self, llm: BaseLLM, cache: LLMCache):
        self._llm = llm
        self._cache = cache

    async def __call__(
        self,
        prompt: str,
        name: str | None = None,
        variables: dict[str, Any] | None = None,
        history: list[LLMInvocationIOPair] | None = None,
        json: bool = False,
        is_response_valid: Callable[[Any], bool] | None = None,
        model_parameters: dict[str, Any] | None = None,
    ) -> LLMInvocationResult:
        cache_key = _create_cache_key(prompt, variables, history, json, model_parameters)
        cached_result = await self._cache.get(cache_key)
        if cached_result is not None:
            return LLMInvocationResult(output=cached_result, history=history)
        result = await self._llm(prompt, name, variables, history, json, is_response_valid, model_parameters)
        await self._cache.set(cache_key, result.output)
        return result
```

This caching mechanism helps reduce API calls for repeated prompts, improving performance and reducing costs.

### Error Handling

Custom error types are defined in `llm/errors.py` to handle LLM-specific exceptions:

```python
class LLMError(Exception):
    """Base class for LLM errors."""

class LLMUnavailableError(LLMError):
    """Raised when the LLM service is unavailable."""

class LLMInvalidResponseError(LLMError):
    """Raised when the LLM returns an invalid response."""

class LLMRateLimitError(LLMError):
    """Raised when the LLM rate limit is exceeded."""
```

These custom error types allow for more granular error handling and provide meaningful information about the nature of LLM-related issues.

## Prompt Engineering

GraphRAG uses carefully crafted prompts for various tasks such as entity extraction and summarization. These prompts are typically stored in separate files and loaded as needed. For example, the entity extraction prompt is defined in `index/graph/extractors/graph/prompts.py`:

```python
GRAPH_EXTRACTION_PROMPT = """
-Goal-
Given a text document that is potentially relevant to this activity and a list of entity types, identify all entities of those types from the text and all relationships among the identified entities.
 
-Steps-
1. Identify all entities. For each identified entity, extract the following information:
- entity_name: Name of the entity, capitalized
- entity_type: One of the following types: [{entity_types}]
- entity_description: Comprehensive description of the entity's attributes and activities
Format each entity as ("entity"{tuple_delimiter}<entity_name>{tuple_delimiter}<entity_type>{tuple_delimiter}<entity_description>)
 
2. From the entities identified in step 1, identify all pairs of (source_entity, target_entity) that are *clearly related* to each other.
For each pair of related entities, extract the following information:
- source_entity: name of the source entity, as identified in step 1
- target_entity: name of the target entity, as identified in step 1
- relationship_description: explanation as to why you think the source entity and the target entity are related to each other
- relationship_strength: a numeric score indicating strength of the relationship between the source entity and target entity
 Format each relationship as ("relationship"{tuple_delimiter}<source_entity>{tuple_delimiter}<target_entity>{tuple_delimiter}<relationship_description>{tuple_delimiter}<relationship_strength>)
 
3. Return output in English as a single list of all the entities and relationships identified in steps 1 and 2. Use **{record_delimiter}** as the list delimiter.
 
4. When finished, output {completion_delimiter}
"""
```

This prompt provides clear instructions to the LLM for extracting entities and relationships from text, ensuring consistent and structured output.

## Practical Exercise

Let's create a simple example of how to use the LLM integration in GraphRAG to perform entity extraction:

```python
import asyncio
from graphrag.index.llm import load_llm
from graphrag.config.enums import LLMType
from graphrag.index.graph.extractors.graph import GraphExtractor

async def extract_entities(text: str):
    # Load the LLM
    llm = load_llm("entity_extraction", LLMType.OpenAIChat, None, None, {
        "api_key": "your_api_key_here",
        "model": "gpt-4",
    })

    # Create the extractor
    extractor = GraphExtractor(llm_invoker=llm)

    # Perform extraction
    result = await extractor([text], {
        "entity_types": ["PERSON", "ORGANIZATION", "LOCATION"],
    })

    return result.output

# Example usage
text = "Apple Inc., founded by Steve Jobs and Steve Wozniak, is headquartered in Cupertino, California."
entities = asyncio.run(extract_entities(text))
print(entities.nodes(data=True))
print(entities.edges(data=True))
```

This example demonstrates how to load an LLM, create an extractor, and use it to perform entity extraction on a given text.

## Review Questions

1. What are the main interfaces used for LLM integration in GraphRAG, and what are their purposes?
2. How does GraphRAG handle rate limiting for LLM API calls?
3. What is the purpose of the `OpenAIConfiguration` class, and what key parameters does it manage?
4. How does caching improve LLM performance in GraphRAG?
5. Describe the process of loading an LLM in GraphRAG. What key components are involved?
6. How does GraphRAG handle errors related to LLM operations?
7. What is the role of prompt engineering in GraphRAG's LLM integration?
8. How does GraphRAG ensure consistent output format from LLMs for tasks like entity extraction?

## Conclusion

In this lesson, we've explored the intricate details of LLM integration in GraphRAG. We've seen how the codebase manages LLM configuration, loading, rate limiting, caching, and error handling. We've also looked at the importance of prompt engineering for tasks like entity extraction. Understanding these concepts is crucial for effectively working with and extending GraphRAG's LLM capabilities.

In the next lesson, we'll dive into graph operations in GraphRAG, building on the knowledge we've gained about LLM integration to understand how these powerful language models are used in conjunction with graph data structures.

