# Lesson 7: Vector Stores and Embedding Operations in GraphRAG

## Introduction

In this lesson, we'll explore the implementation and use of vector stores and embedding operations in GraphRAG. These components are crucial for enabling efficient similarity search and semantic understanding of textual data within the system. We'll examine how GraphRAG implements vector stores, performs similarity searches, and utilizes embeddings throughout its workflows.

## File Structure

Before we dive into the details, let's look at the relevant file structure for vector stores and embedding operations in GraphRAG:

```
graphrag/
├── vector_stores/
│   ├── __init__.py
│   ├── azure_ai_search.py
│   ├── base.py
│   ├── lancedb.py
│   └── typing.py
└── query/
    ├── llm/
    │   └── oai/
    │       └── embedding.py
    └── context_builder/
        └── entity_extraction.py
```

This structure shows the main components we'll be discussing in this lesson. The `vector_stores` directory contains implementations for different vector store backends, while the `query` directory includes code for embedding operations and their use in context building.

## Vector Store Implementation

Vector stores are specialized databases designed to efficiently store and query high-dimensional vectors, such as text embeddings. GraphRAG supports multiple vector store backends, including LanceDB and Azure AI Search. Let's examine the core components of the vector store implementation.

### Base Vector Store Interface

GraphRAG defines a base interface for vector stores in the `base.py` file:

```python
# graphrag/vector_stores/base.py

from abc import ABC, abstractmethod
from typing import Any
from .typing import VectorStoreDocument, SearchResult

class BaseVectorStore(ABC):
    @abstractmethod
    def connect(self, **kwargs):
        """Connect to the vector store."""

    @abstractmethod
    def load_documents(
        self, documents: list[VectorStoreDocument], overwrite: bool = False
    ) -> None:
        """Load documents into the vector store."""

    @abstractmethod
    def search(
        self,
        query_vector: list[float],
        k: int = 5,
        filter: str | None = None,
    ) -> list[SearchResult]:
        """Search for similar vectors in the store."""

    @abstractmethod
    def similarity_search_by_text(
        self,
        text: str,
        text_embedder: Any,
        k: int = 5,
        filter: str | None = None,
    ) -> list[SearchResult]:
        """Search for similar documents by text."""
```

This abstract base class defines the core interface for all vector store implementations in GraphRAG. It includes methods for:
- Connecting to the vector store
- Loading documents (with their associated vectors)
- Performing similarity searches using vector queries
- Performing similarity searches using text queries (which are then embedded)

By defining this common interface, GraphRAG ensures that different vector store implementations can be easily swapped or extended without affecting the rest of the system.

### LanceDB Implementation

Let's examine the LanceDB implementation as an example of how GraphRAG implements a specific vector store backend:

```python
# graphrag/vector_stores/lancedb.py

import lancedb
from typing import Any
from .base import BaseVectorStore
from .typing import VectorStoreDocument, SearchResult

class LanceDBVectorStore(BaseVectorStore):
    def __init__(self, collection_name: str):
        self.collection_name = collection_name
        self.db = None
        self.table = None

    def connect(self, **kwargs):
        uri = kwargs.get("uri", "./lancedb")
        self.db = lancedb.connect(uri)
        if self.collection_name not in self.db.table_names():
            self.table = self.db.create_table(
                self.collection_name,
                data=[{
                    "id": "",
                    "text": "",
                    "vector": [0.0] * 1536,
                    "attributes": {},
                }],
                mode="overwrite",
            )
        else:
            self.table = self.db.open_table(self.collection_name)

    def load_documents(
        self, documents: list[VectorStoreDocument], overwrite: bool = False
    ) -> None:
        data = [{
            "id": doc.id,
            "text": doc.text,
            "vector": doc.vector,
            "attributes": json.dumps(doc.attributes),
        } for doc in documents]
        if overwrite:
            self.table.add(data=data, mode="overwrite")
        else:
            self.table.add(data=data)

    def search(
        self,
        query_vector: list[float],
        k: int = 5,
        filter: str | None = None,
    ) -> list[SearchResult]:
        query = self.table.search(query_vector)
        if filter:
            query = query.where(filter)
        results = query.limit(k).to_list()
        return [SearchResult(
            id=result["id"],
            text=result["text"],
            score=result["_distance"],
            attributes=json.loads(result["attributes"]),
        ) for result in results]

    # ... other method implementations ...
```

This implementation showcases several important aspects of vector store integration in GraphRAG:

1. **Flexibility**: The `connect` method allows for specifying a custom URI, enabling use of both local and remote LanceDB instances.

2. **Schema Definition**: The implementation defines a schema for the stored documents, including id, text, vector, and additional attributes.

3. **Efficient Search**: The `search` method leverages LanceDB's built-in similarity search capabilities, with support for additional filtering.

4. **Attribute Handling**: The implementation stores additional attributes as JSON strings, allowing for flexible metadata storage.

## Embedding Operations

Embeddings are dense vector representations of text that capture semantic meaning. GraphRAG uses these embeddings for various purposes, including similarity search and entity mapping. Let's examine how embeddings are generated and used in the system.

### OpenAI Embedding Implementation

GraphRAG includes an implementation for generating embeddings using OpenAI's models:

```python
# graphrag/query/llm/oai/embedding.py

import asyncio
from typing import Any
import numpy as np
import tiktoken
from graphrag.query.llm.base import BaseTextEmbedding
from graphrag.query.llm.text_utils import chunk_text

class OpenAIEmbedding(BaseTextEmbedding, OpenAILLMImpl):
    def __init__(
        self,
        api_key: str | None = None,
        model: str = "text-embedding-3-small",
        encoding_name: str = "cl100k_base",
        max_tokens: int = 8191,
        # ... other parameters ...
    ):
        # ... initialization code ...

    async def aembed(self, text: str, **kwargs: Any) -> list[float]:
        token_chunks = chunk_text(
            text=text, token_encoder=self.token_encoder, max_tokens=self.max_tokens
        )
        chunk_embeddings = []
        chunk_lens = []
        embedding_results = await asyncio.gather(*[
            self._aembed_with_retry(chunk, **kwargs) for chunk in token_chunks
        ])
        embedding_results = [result for result in embedding_results if result[0]]
        chunk_embeddings = [result[0] for result in embedding_results]
        chunk_lens = [result[1] for result in embedding_results]
        chunk_embeddings = np.average(chunk_embeddings, axis=0, weights=chunk_lens)
        chunk_embeddings = chunk_embeddings / np.linalg.norm(chunk_embeddings)
        return chunk_embeddings.tolist()

    # ... other method implementations ...
```

This implementation of the OpenAI embedding model showcases several important features:

1. **Chunking for Long Texts**: The `aembed` method uses the `chunk_text` function to split long texts into smaller chunks. This is crucial for handling texts that exceed the maximum token limit of the embedding model. By chunking the text, GraphRAG ensures that even long documents can be embedded effectively.

2. **Parallel Processing**: The use of `asyncio.gather` allows for parallel processing of chunk embeddings. This significantly improves performance when embedding long texts that have been split into multiple chunks. Each chunk can be processed independently, taking full advantage of asynchronous I/O.

3. **Weighted Averaging**: After obtaining embeddings for individual chunks, the method performs a weighted average based on the length of each chunk. This ensures that longer chunks contribute more to the final embedding, preserving the overall semantic meaning of the original text.

4. **Normalization**: The final step normalizes the averaged embedding vector. This is important for maintaining consistency in the embedding space, as it ensures that all embeddings have unit length. Normalized embeddings are particularly useful for cosine similarity calculations, which are commonly used in vector similarity searches.

### Using Embeddings for Entity Mapping

GraphRAG uses embeddings for various tasks, including mapping user queries to relevant entities. Let's examine how this is implemented in the `entity_extraction.py` file:

```python
# graphrag/query/context_builder/entity_extraction.py

from graphrag.model import Entity
from graphrag.vector_stores import BaseVectorStore
from graphrag.query.llm.base import BaseTextEmbedding

def map_query_to_entities(
    query: str,
    text_embedding_vectorstore: BaseVectorStore,
    text_embedder: BaseTextEmbedding,
    all_entities: list[Entity],
    embedding_vectorstore_key: str = EntityVectorStoreKey.ID,
    include_entity_names: list[str] | None = None,
    exclude_entity_names: list[str] | None = None,
    k: int = 10,
    oversample_scaler: int = 2,
) -> list[Entity]:
    if include_entity_names is None:
        include_entity_names = []
    if exclude_entity_names is None:
        exclude_entity_names = []
    matched_entities = []
    if query != "":
        # get entities with highest semantic similarity to query
        search_results = text_embedding_vectorstore.similarity_search_by_text(
            text=query,
            text_embedder=lambda t: text_embedder.embed(t),
            k=k * oversample_scaler,
        )
        for result in search_results:
            matched = get_entity_by_key(
                entities=all_entities,
                key=embedding_vectorstore_key,
                value=result.document.id,
            )
            if matched:
                matched_entities.append(matched)
    else:
        all_entities.sort(key=lambda x: x.rank if x.rank else 0, reverse=True)
        matched_entities = all_entities[:k]

    # filter out excluded entities
    if exclude_entity_names:
        matched_entities = [
            entity
            for entity in matched_entities
            if entity.title not in exclude_entity_names
        ]

    # add entities in the include_entity list
    included_entities = []
    for entity_name in include_entity_names:
        included_entities.extend(get_entity_by_name(all_entities, entity_name))
    return included_entities + matched_entities
```

This function demonstrates several key aspects of how GraphRAG uses embeddings for entity mapping:

1. **Semantic Similarity Search**: When a query is provided, the function uses the vector store's `similarity_search_by_text` method to find entities with embeddings similar to the query embedding. This allows for semantic matching, going beyond simple keyword matching.

2. **Flexible Entity Selection**: The function allows for both inclusion and exclusion of specific entities by name. This is useful for tailoring the entity selection process to specific use cases or user preferences.

3. **Oversampling**: The `oversample_scaler` parameter allows the function to retrieve more candidates than necessary, which can be useful for subsequent filtering steps.

4. **Fallback to Ranking**: In the absence of a query, the function falls back to selecting entities based on their rank. This ensures that relevant entities are still returned even when no specific query is provided.

5. **Combining Results**: The function combines explicitly included entities with those matched through semantic similarity, providing a comprehensive set of relevant entities.

## Optimizing Vector Operations

Efficient vector operations are crucial for the performance of GraphRAG, especially when dealing with large numbers of embeddings. Here are some strategies employed by GraphRAG to optimize these operations:

### 1. Batched Processing

When generating embeddings for multiple texts, GraphRAG uses batched processing to reduce the number of API calls and improve throughput. This is evident in the `OpenAIEmbedding` class:

```python
embedding_results = await asyncio.gather(*[
    self._aembed_with_retry(chunk, **kwargs) for chunk in token_chunks
])
```

By using `asyncio.gather`, GraphRAG can process multiple chunks in parallel, significantly reducing the total time required for embedding large datasets.

### 2. Caching

GraphRAG implements caching mechanisms to avoid recomputing embeddings for the same input. This is particularly useful in scenarios where the same texts are processed multiple times. While not shown in the provided code snippets, caching is typically implemented at a higher level in the GraphRAG pipeline.

### 3. Efficient Similarity Search

The vector store implementations in GraphRAG are designed to perform efficient similarity searches. For example, the LanceDB implementation leverages the database's built-in similarity search capabilities:

```python
query = self.table.search(query_vector)
if filter:
    query = query.where(filter)
results = query.limit(k).to_list()
```

This allows for fast retrieval of similar vectors, even in large datasets.

### 4. Dimensionality Reduction

While not explicitly shown in the provided code, dimensionality reduction techniques like UMAP (Uniform Manifold Approximation and Projection) can be used to reduce the size of embedding vectors while preserving their semantic relationships. This can significantly improve the performance of vector operations and reduce storage requirements.

## Cross-Platform Considerations

When implementing vector stores and embedding operations, it's important to consider cross-platform compatibility. GraphRAG addresses this in several ways:

1. **Abstraction Layers**: The use of abstract base classes like `BaseVectorStore` and `BaseTextEmbedding` allows for platform-specific optimizations in concrete implementations.

2. **Numpy for Numerical Operations**: GraphRAG uses NumPy for efficient numerical operations on embedding vectors. NumPy provides consistent performance across different platforms and can take advantage of platform-specific optimizations.

3. **Asynchronous Operations**: The use of `asyncio` for parallel processing ensures efficient operation across different Python implementations and operating systems.

4. **Configurable Backends**: By supporting multiple vector store backends (e.g., LanceDB, Azure AI Search), GraphRAG allows users to choose the most appropriate solution for their specific platform and requirements.

## Conclusion

Vector stores and embedding operations are fundamental components of GraphRAG, enabling efficient similarity search and semantic understanding of textual data. The system's design emphasizes flexibility, efficiency, and scalability through the use of abstract interfaces, parallel processing, and optimized vector operations.

Key takeaways from this lesson include:
- The importance of a well-defined vector store interface for supporting multiple backends
- The role of embeddings in enabling semantic similarity search and entity mapping
- Strategies for handling long texts and large datasets in embedding operations
- The significance of optimization techniques like batching, caching, and efficient similarity search
- The importance of cross-platform considerations in implementing vector and embedding operations

As you work with GraphRAG, keep these principles in mind to ensure effective and efficient use of vector stores and embedding operations in your applications.

## Review Questions

1. Explain the purpose of the `BaseVectorStore` abstract base class. How does it contribute to the flexibility of GraphRAG's vector store implementations?

2. Describe the process of embedding long texts in the `OpenAIEmbedding` class. Why is chunking necessary, and how does GraphRAG handle the results?

3. How does GraphRAG use embeddings for entity mapping in the `map_query_to_entities` function? What advantages does this approach offer over simple keyword matching?

4. Explain the role of the `oversample_scaler` parameter in the `map_query_to_entities` function. In what scenarios might this be useful?

5. What optimization strategies does GraphRAG employ for vector operations? How do these contribute to the system's performance?

6. Describe the cross-platform considerations in GraphRAG's implementation of vector stores and embedding operations. How do these considerations impact the design of the system?

7. How does GraphRAG's vector store implementation handle additional attributes for stored documents? Why is this flexibility important?

## Hands-On Exercise

Implement a custom vector store backend for GraphRAG using a simple in-memory storage solution. Your implementation should:

1. Create a new class that inherits from `BaseVectorStore` and implements its abstract methods.
2. Use a Python dictionary to store document vectors and metadata in memory.
3. Implement a basic cosine similarity search for the `search` method.
4. Support filtering in the search method based on document attributes.
5. Implement the `similarity_search_by_text` method using a provided text embedder.
6. Demonstrate how to use your custom vector store in a GraphRAG context building or entity mapping operation.

This exercise will give you hands-on experience with the key concepts of vector stores in GraphRAG, including similarity search, document storage, and integration with the broader GraphRAG system.

