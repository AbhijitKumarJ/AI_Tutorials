# Lesson 1: Introduction to GraphRAG Query Module

## 1. Overview of the GraphRAG Project and Its Query Module

GraphRAG (Graph-based Retrieval-Augmented Generation) is an advanced information retrieval and processing system that combines graph-based data structures with large language models (LLMs) to enhance the capabilities of traditional RAG systems. The primary purpose of GraphRAG is to efficiently process, analyze, and generate insights from large volumes of textual data by leveraging the power of graph representations and natural language processing.

The query module is a critical component of the GraphRAG project, responsible for handling user queries and interfacing with the underlying graph-based knowledge representation. It serves as the bridge between user input and the sophisticated graph processing and language generation capabilities of the system.

Key features of the GraphRAG query module include:
- Efficient query processing and interpretation
- Integration with various LLM providers
- Context building and management for relevant information retrieval
- Structured search implementations for both global and local search strategies
- Vector store integration for similarity-based information retrieval
- Flexible configuration management for easy customization

## 2. File Structure and Organization of the Query Module

The GraphRAG query module follows a well-organized structure to maintain code clarity and separation of concerns. Let's examine the main components of the file structure:

```
graphrag/
└── query/
    ├── cli.py
    ├── factories.py
    ├── indexer_adapters.py
    ├── __init__.py
    ├── __main__.py
    ├── context_builder/
    │   ├── builders.py
    │   ├── community_context.py
    │   ├── conversation_history.py
    │   ├── entity_extraction.py
    │   ├── local_context.py
    │   ├── source_context.py
    │   └── __init__.py
    ├── input/
    │   ├── __init__.py
    │   ├── loaders/
    │   │   ├── dfs.py
    │   │   ├── utils.py
    │   │   └── __init__.py
    │   └── retrieval/
    │       ├── community_reports.py
    │       ├── covariates.py
    │       ├── entities.py
    │       ├── relationships.py
    │       ├── text_units.py
    │       └── __init__.py
    ├── llm/
    │   ├── base.py
    │   ├── text_utils.py
    │   ├── __init__.py
    │   └── oai/
    │       ├── base.py
    │       ├── chat_openai.py
    │       ├── embedding.py
    │       ├── openai.py
    │       ├── typing.py
    │       └── __init__.py
    ├── question_gen/
    │   ├── base.py
    │   ├── local_gen.py
    │   ├── system_prompt.py
    │   └── __init__.py
    └── structured_search/
        ├── base.py
        ├── __init__.py
        ├── global_search/
        │   ├── community_context.py
        │   ├── map_system_prompt.py
        │   ├── reduce_system_prompt.py
        │   ├── search.py
        │   └── __init__.py
        └── local_search/
            ├── mixed_context.py
            ├── search.py
            ├── system_prompt.py
            └── __init__.py
```

This structure allows for clear separation of concerns and makes it easier to maintain and extend the project. Let's break down the main components:

- `cli.py`: Contains the command-line interface implementation for the query module.
- `factories.py`: Implements factory methods for creating various objects used in the query process.
- `indexer_adapters.py`: Provides adapters for interfacing with the indexing engine.
- `context_builder/`: Contains modules for building different types of contexts for query processing.
- `input/`: Handles input data loading and retrieval operations.
- `llm/`: Implements interfaces and utilities for working with Large Language Models.
- `question_gen/`: Manages question generation capabilities.
- `structured_search/`: Implements structured search algorithms for both global and local search strategies.

## 3. Key Components: CLI, Factories, Indexer Adapters, and Submodules

### 3.1 Command Line Interface (CLI)

The `cli.py` file implements the command-line interface for the GraphRAG query module. It provides functions for both global and local search operations. Here's a brief overview of its main components:

- `run_global_search`: Performs a global search with a given query, loading necessary index files and calling the Query API.
- `run_local_search`: Executes a local search with a given query, loading relevant index files and invoking the Query API.
- `_resolve_parquet_files`: A utility function to read parquet files into a dictionary of dataframes.

The CLI uses command-line arguments to control the search behavior, including configuration file path, data directory, root directory, community level, response type, and streaming options.

### 3.2 Factories

The `factories.py` file contains factory methods for creating various objects used in the query process. These factories help manage the complexity of object creation and configuration. Key factory methods include:

- `get_llm`: Creates and configures an LLM client based on the provided configuration.
- `get_text_embedder`: Sets up a text embedding client using the specified configuration.
- `get_local_search_engine`: Constructs a local search engine with the given parameters and data.
- `get_global_search_engine`: Builds a global search engine based on the provided configuration and data.

These factory methods encapsulate the complexity of object creation, making it easier to manage different configurations and implementations.

### 3.3 Indexer Adapters

The `indexer_adapters.py` file provides functions to adapt data from the indexing engine to the query module's data structures. It includes functions like:

- `read_indexer_text_units`: Converts indexed text units into the query module's `TextUnit` objects.
- `read_indexer_covariates`: Transforms indexed covariates into `Covariate` objects.
- `read_indexer_relationships`: Adapts indexed relationships to `Relationship` objects.
- `read_indexer_reports`: Converts indexed community reports to `CommunityReport` objects.
- `read_indexer_entities`: Transforms indexed entities into `Entity` objects.

These adapter functions ensure that the data from the indexing engine is properly formatted and structured for use in the query module.

### 3.4 Submodules

The query module is organized into several submodules, each responsible for specific functionality:

- `context_builder`: Manages the creation of context for query processing, including community context, conversation history, and local context.
- `input`: Handles data loading and retrieval operations, providing interfaces to access various data types like community reports, entities, and relationships.
- `llm`: Implements interfaces and utilities for working with Large Language Models, including base classes and OpenAI-specific implementations.
- `question_gen`: Manages question generation capabilities, useful for generating follow-up questions or clarifications.
- `structured_search`: Implements structured search algorithms for both global and local search strategies, allowing for efficient information retrieval from the graph-based knowledge representation.

Each of these submodules contains multiple files that work together to provide comprehensive functionality for their respective areas.

## 4. Python Basics: Imports, Modules, and Package Structure

The GraphRAG query module makes extensive use of Python's module and package system. Here's an overview of how these concepts are applied in the codebase:

### 4.1 Imports

Python's import system is used throughout the codebase to bring in necessary functions, classes, and modules. For example, in the `cli.py` file, we see imports like:

```python
import asyncio
import sys
from pathlib import Path

import pandas as pd

import graphrag.api as api
from graphrag.config import GraphRagConfig, load_config, resolve_paths
from graphrag.index.create_pipeline_config import create_pipeline_config
from graphrag.logging import PrintProgressReporter
from graphrag.utils.storage import _create_storage, _load_table_from_storage
```

These imports demonstrate several important concepts:
- Standard library imports (`asyncio`, `sys`)
- Third-party library imports (`pandas as pd`)
- Relative imports from the GraphRAG package
- Importing specific functions or classes from modules
- Using aliases to shorten import names

### 4.2 Modules

Each Python file in the structure represents a module. For instance, `cli.py` is a module that contains functions and variables related to the command-line interface. Modules help organize code into logical units and provide namespace separation.

### 4.3 Package Structure

The GraphRAG query module follows a hierarchical package structure. The `query` directory is a package, and its subdirectories (like `context_builder`, `input`, `llm`, etc.) are subpackages. This structure allows for logical organization of related functionality and helps manage complexity in large projects.

The `__init__.py` files in each directory make them Python packages. These files can be used to define what gets imported when the package is imported, and they can also contain package-level code or imports.

## 5. Introduction to Type Hinting and Its Importance in the Codebase

Type hinting is a feature in Python that allows developers to specify the expected types of variables, function parameters, and return values. The GraphRAG query module makes extensive use of type hinting to improve code readability, catch errors early, and provide better IDE support.

Here's an example of type hinting from the `cli.py` file:

```python
def run_global_search(
    config_filepath: str | None,
    data_dir: str | None,
    root_dir: str,
    community_level: int,
    response_type: str,
    streaming: bool,
    query: str,
) -> None:
    # Function implementation...
```

In this function signature:
- `config_filepath: str | None` indicates that `config_filepath` can be either a string or None.
- `community_level: int` specifies that `community_level` should be an integer.
- `streaming: bool` indicates that `streaming` is a boolean value.
- `-> None` at the end specifies that the function doesn't return a value.

Type hinting provides several benefits in the GraphRAG codebase:
1. Improved Code Readability: It makes it easier for developers to understand what kind of data a function expects and returns.
2. Early Error Detection: Static type checkers can catch type-related errors before runtime.
3. Better IDE Support: IDEs can provide more accurate autocompletion and error detection based on type hints.
4. Documentation: Type hints serve as a form of in-code documentation about data types.

## 6. Cross-platform Considerations in File Paths and System Interactions

The GraphRAG query module is designed to work across different operating systems. This requires careful handling of file paths and system interactions. Here are some key considerations and how they're addressed in the codebase:

### 6.1 File Path Handling

The codebase uses the `pathlib` module to handle file paths in a cross-platform manner. For example, in `cli.py`:

```python
from pathlib import Path

root = Path(root_dir).resolve()
```

Using `Path` objects instead of string manipulation ensures that file paths are correctly formatted for the operating system on which the code is running.

### 6.2 Configuration Management

The `load_config` function (imported from `graphrag.config`) is used to load configuration files. This function likely handles path resolution in a cross-platform manner, ensuring that configuration files can be located regardless of the operating system.

### 6.3 Data Storage and Retrieval

The `_create_storage` and `_load_table_from_storage` functions (imported from `graphrag.utils.storage`) abstract away the details of data storage and retrieval. This abstraction allows for different storage backends to be used on different platforms without affecting the main query logic.

### 6.4 Asynchronous Operations

The use of `asyncio` for asynchronous operations helps manage I/O-bound tasks efficiently across different platforms. This is particularly important for operations like loading data or making API calls, which may have different performance characteristics on different systems.

## 7. Setting up a Development Environment for Working with GraphRAG

To set up a development environment for working with the GraphRAG query module, follow these steps:

1. Python Installation: Ensure you have Python 3.7 or later installed on your system. GraphRAG likely requires a recent version of Python to support features like type hinting and asynchronous programming.

2. Virtual Environment: Create a virtual environment to isolate the GraphRAG dependencies:
   ```
   python -m venv graphrag-env
   source graphrag-env/bin/activate  # On Windows, use: graphrag-env\Scripts\activate
   ```

3. Clone the Repository: Clone the GraphRAG repository from its source (GitHub or your organization's version control system).

4. Install Dependencies: Navigate to the project directory and install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

5. Configuration: Set up your configuration files. Look for example configuration files in the project and create your own based on these templates.

6. Environment Variables: Set up any necessary environment variables, such as API keys for LLM services.

7. IDE Setup: If using an IDE like PyCharm or VSCode, configure it to use your virtual environment and enable type checking for better development support.

8. Run Tests: If the project includes tests, run them to ensure your setup is correct:
   ```
   python -m unittest discover tests
   ```

9. Explore the CLI: Try running some basic CLI commands to verify your setup:
   ```
   python -m graphrag.query --help
   ```

By following these steps, you'll have a functional development environment for working with the GraphRAG query module. Remember to consult the project's documentation for any additional setup steps or requirements specific to GraphRAG.

## Review Questions

1. What is the main purpose of the GraphRAG project, and how does the query module fit into this purpose?
2. Describe the high-level structure of the GraphRAG query module. What are the main subdirectories, and what is the purpose of each?
3. Explain the role of the `factories.py` file in the GraphRAG query module. Why is the factory pattern useful in this context?
4. How does the GraphRAG query module use type hinting? Provide an example from the codebase and explain its benefits.
5. What cross-platform considerations are taken into account in the GraphRAG query module, particularly regarding file path handling?
6. Describe the process of setting up a development environment for working with GraphRAG. What are some key steps that ensure a properly configured environment?

## Hands-on Exercise

To gain practical experience with the GraphRAG query module, complete the following exercise:

1. Set up a development environment following the steps outlined in section 7 of this lesson.
2. Explore the `cli.py` file and identify the main functions responsible for global and local search.
3. Create a simple Python script that imports the necessary components from the GraphRAG query module and performs a basic global search using dummy data.
4. Modify your script to use type hinting for all variables and function parameters.
5. Implement error handling for potential issues like missing configuration files or invalid input data.
6. Run your script on different operating systems (if possible) to verify its cross-platform compatibility.
7. Document your script, explaining how it interfaces with the GraphRAG query module and any challenges you encountered during implementation.

This exercise will help you become familiar with the structure of the GraphRAG query module, its CLI implementation, and important Python concepts like imports, type hinting, and cross-platform considerations.

