# Lesson 6: Large Language Model (LLM) Integration in GraphRAG

## Introduction

In this lesson, we'll dive deep into how GraphRAG integrates Large Language Models (LLMs) into its architecture. We'll explore the implementation details, including how GraphRAG works with different LLM providers, handles API interactions, and manages prompts for various tasks. By the end of this lesson, you'll have a comprehensive understanding of how LLMs are leveraged within the GraphRAG codebase.

## File Structure

Before we dive into the details, let's look at the relevant file structure for LLM integration in GraphRAG:

```
graphrag/
├── query/
│   └── llm/
│       ├── __init__.py
│       ├── base.py
│       ├── text_utils.py
│       └── oai/
│           ├── __init__.py
│           ├── base.py
│           ├── chat_openai.py
│           ├── embedding.py
│           ├── openai.py
│           └── typing.py
└── callbacks/
    └── llm_callbacks.py
```

This structure shows the main components we'll be discussing in this lesson. The `llm` directory contains the core LLM integration code, with specific implementations for OpenAI in the `oai` subdirectory.

## LLM Integration Overview

GraphRAG integrates LLMs primarily through two main interfaces: `BaseLLM` for text generation tasks and `BaseTextEmbedding` for text embedding tasks. These interfaces are implemented for different LLM providers, with OpenAI and Azure OpenAI being the primary supported providers.

### Base LLM Interface

Let's start by examining the `BaseLLM` abstract base class:

```python
# graphrag/query/llm/base.py

from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator, Generator
from typing import Any

from graphrag.callbacks.llm_callbacks import BaseLLMCallback

class BaseLLM(ABC):
    @abstractmethod
    def generate(
        self,
        messages: str | list[Any],
        streaming: bool = True,
        callbacks: list[BaseLLMCallback] | None = None,
        **kwargs: Any,
    ) -> str:
        """Generate a response."""

    @abstractmethod
    def stream_generate(
        self,
        messages: str | list[Any],
        callbacks: list[BaseLLMCallback] | None = None,
        **kwargs: Any,
    ) -> Generator[str, None, None]:
        """Generate a response with streaming."""

    @abstractmethod
    async def agenerate(
        self,
        messages: str | list[Any],
        streaming: bool = True,
        callbacks: list[BaseLLMCallback] | None = None,
        **kwargs: Any,
    ) -> str:
        """Generate a response asynchronously."""

    @abstractmethod
    async def astream_generate(
        self,
        messages: str | list[Any],
        callbacks: list[BaseLLMCallback] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[str, None]:
        """Generate a response asynchronously with streaming."""
```

This abstract base class defines the core interface for interacting with LLMs in GraphRAG. It includes both synchronous and asynchronous methods for generating responses, with options for streaming output. The use of abstract methods ensures that all concrete implementations provide these essential functionalities.

Key points to note:
- The interface supports both string and list inputs for messages, allowing flexibility in prompt formatting.
- Callback support is built into the interface, enabling progress tracking and other custom behaviors during generation.
- The use of `**kwargs` allows for provider-specific parameters to be passed through.

### OpenAI Implementation

Now, let's look at how GraphRAG implements this interface for OpenAI models:

```python
# graphrag/query/llm/oai/chat_openai.py

from tenacity import (
    AsyncRetrying,
    RetryError,
    Retrying,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential_jitter,
)

class ChatOpenAI(BaseLLM, OpenAILLMImpl):
    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None,
        azure_ad_token_provider: Callable | None = None,
        deployment_name: str | None = None,
        api_base: str | None = None,
        api_version: str | None = None,
        api_type: OpenaiApiType = OpenaiApiType.OpenAI,
        organization: str | None = None,
        max_retries: int = 10,
        request_timeout: float = 180.0,
        retry_error_types: tuple[type[BaseException]] = OPENAI_RETRY_ERROR_TYPES,
        reporter: StatusLogger | None = None,
    ):
        # ... initialization code ...

    async def agenerate(
        self,
        messages: str | list[Any],
        streaming: bool = True,
        callbacks: list[BaseLLMCallback] | None = None,
        **kwargs: Any,
    ) -> str:
        try:
            retryer = AsyncRetrying(
                stop=stop_after_attempt(self.max_retries),
                wait=wait_exponential_jitter(max=10),
                reraise=True,
                retry=retry_if_exception_type(self.retry_error_types),
            )
            async for attempt in retryer:
                with attempt:
                    return await self._agenerate(
                        messages=messages,
                        streaming=streaming,
                        callbacks=callbacks,
                        **kwargs,
                    )
        except RetryError as e:
            self._reporter.error(f"Error at agenerate(): {e}")
            return ""

    # ... other method implementations ...
```

This implementation showcases several important aspects of LLM integration in GraphRAG:

1. **Flexibility**: The constructor allows for various configuration options, supporting both OpenAI and Azure OpenAI setups.

2. **Retry Mechanism**: The `agenerate` method uses the `tenacity` library to implement a robust retry mechanism. This is crucial for handling transient errors in API calls.

3. **Asynchronous Programming**: The use of `async/await` syntax allows for efficient handling of I/O-bound operations, which is essential when working with external APIs.

4. **Error Handling**: The implementation includes comprehensive error handling, with errors being logged through a reporter system.

### Embedding Implementation

In addition to text generation, GraphRAG also integrates embedding models. Let's examine the OpenAI embedding implementation:

```python
# graphrag/query/llm/oai/embedding.py

import asyncio
from typing import Any
import numpy as np
import tiktoken

class OpenAIEmbedding(BaseTextEmbedding, OpenAILLMImpl):
    def __init__(
        self,
        api_key: str | None = None,
        azure_ad_token_provider: Callable | None = None,
        model: str = "text-embedding-3-small",
        deployment_name: str | None = None,
        api_base: str | None = None,
        api_version: str | None = None,
        api_type: OpenaiApiType = OpenaiApiType.OpenAI,
        organization: str | None = None,
        encoding_name: str = "cl100k_base",
        max_tokens: int = 8191,
        max_retries: int = 10,
        request_timeout: float = 180.0,
        retry_error_types: tuple[type[BaseException]] = OPENAI_RETRY_ERROR_TYPES,
        reporter: StatusLogger | None = None,
    ):
        # ... initialization code ...

    async def aembed(self, text: str, **kwargs: Any) -> list[float]:
        token_chunks = chunk_text(
            text=text, token_encoder=self.token_encoder, max_tokens=self.max_tokens
        )
        chunk_embeddings = []
        chunk_lens = []
        embedding_results = await asyncio.gather(*[
            self._aembed_with_retry(chunk, **kwargs) for chunk in token_chunks
        ])
        embedding_results = [result for result in embedding_results if result[0]]
        chunk_embeddings = [result[0] for result in embedding_results]
        chunk_lens = [result[1] for result in embedding_results]
        chunk_embeddings = np.average(chunk_embeddings, axis=0, weights=chunk_lens)
        chunk_embeddings = chunk_embeddings / np.linalg.norm(chunk_embeddings)
        return chunk_embeddings.tolist()

    # ... other method implementations ...
```

This embedding implementation highlights several key features:

1. **Chunking**: For long texts, the `aembed` method chunks the input to stay within token limits, then combines the chunk embeddings.

2. **Parallel Processing**: The use of `asyncio.gather` allows for parallel processing of chunk embeddings, improving efficiency.

3. **Normalization**: The final embedding is normalized, ensuring consistency in the embedding space.

4. **Flexible Configuration**: Like the chat implementation, this class supports various configuration options for different OpenAI setups.

## Asynchronous Programming in GraphRAG

Asynchronous programming is a key feature of GraphRAG's LLM integration, allowing for efficient handling of I/O-bound operations. Let's delve deeper into how this is implemented:

### Asynchronous Context Management

GraphRAG uses asynchronous context managers to manage resources that require setup and teardown in an asynchronous context. For example, the `aiofiles` library is used for asynchronous file I/O:

```python
# Example usage in GraphRAG

import aiofiles

async with aiofiles.open(file_path, mode='r') as f:
    content = await f.read()
```

This allows for non-blocking file operations, which is particularly useful when processing large datasets or multiple files concurrently.

### Parallel API Calls

For operations that involve multiple independent API calls, GraphRAG uses `asyncio.gather` to run them in parallel:

```python
# Example from embedding implementation

embedding_results = await asyncio.gather(*[
    self._aembed_with_retry(chunk, **kwargs) for chunk in token_chunks
])
```

This pattern allows for significant performance improvements when working with batched operations or processing multiple inputs simultaneously.

## Error Handling and Retry Mechanisms

Error handling is a critical aspect of LLM integration, especially when dealing with external APIs that may experience transient failures. GraphRAG implements robust error handling and retry mechanisms to ensure reliability in LLM operations.

### Custom Exception Classes

GraphRAG defines custom exception classes for LLM-related errors, allowing for more specific error handling:

```python
# graphrag/query/llm/oai/typing.py

import openai

OPENAI_RETRY_ERROR_TYPES = (
    openai.RateLimitError,
    openai.APIConnectionError,
    # Other OpenAI-specific error types...
)
```

These custom exception types allow GraphRAG to distinguish between different types of errors and handle them appropriately. For example, rate limit errors might be handled differently from connection errors.

### Retry Mechanism with Tenacity

GraphRAG uses the `tenacity` library to implement a sophisticated retry mechanism. This is particularly evident in the OpenAI implementation:

```python
# graphrag/query/llm/oai/chat_openai.py

from tenacity import (
    AsyncRetrying,
    RetryError,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential_jitter,
)

class ChatOpenAI(BaseLLM, OpenAILLMImpl):
    # ... other code ...

    async def agenerate(
        self,
        messages: str | list[Any],
        streaming: bool = True,
        callbacks: list[BaseLLMCallback] | None = None,
        **kwargs: Any,
    ) -> str:
        try:
            retryer = AsyncRetrying(
                stop=stop_after_attempt(self.max_retries),
                wait=wait_exponential_jitter(max=10),
                reraise=True,
                retry=retry_if_exception_type(self.retry_error_types),
            )
            async for attempt in retryer:
                with attempt:
                    return await self._agenerate(
                        messages=messages,
                        streaming=streaming,
                        callbacks=callbacks,
                        **kwargs,
                    )
        except RetryError as e:
            self._reporter.error(f"Error at agenerate(): {e}")
            return ""
```

This retry mechanism offers several advantages:
1. **Exponential Backoff**: The `wait_exponential_jitter` strategy implements an exponential backoff with added jitter, which is ideal for avoiding thundering herd problems when recovering from API outages.
2. **Selective Retry**: The `retry_if_exception_type` condition ensures that only specific types of errors (defined in `OPENAI_RETRY_ERROR_TYPES`) trigger a retry, avoiding unnecessary retries for permanent errors.
3. **Maximum Retry Limit**: The `stop_after_attempt` condition prevents infinite retry loops by setting a maximum number of attempts.

### Logging and Reporting

GraphRAG implements a comprehensive logging and reporting system to track errors and provide visibility into LLM operations:

```python
# Example error logging in GraphRAG

self._reporter.error(
    message="Error embedding chunk",
    details={self.__class__.__name__: str(e)},
)
```

This structured logging approach allows for easy debugging and monitoring of LLM-related issues in production environments.

## Streaming Responses

GraphRAG supports streaming responses from LLMs, which is crucial for providing real-time feedback in interactive applications. Let's examine how this is implemented:

```python
# graphrag/query/llm/oai/chat_openai.py

class ChatOpenAI(BaseLLM, OpenAILLMImpl):
    # ... other code ...

    async def _astream_generate(
        self,
        messages: str | list[Any],
        callbacks: list[BaseLLMCallback] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[str, None]:
        model = self.model
        if not model:
            raise ValueError("Model is required")
        response = await self.async_client.chat.completions.create(
            model=model,
            messages=messages,
            stream=True,
            **kwargs,
        )
        async for chunk in response:
            if not chunk or not chunk.choices:
                continue

            delta = (
                chunk.choices[0].delta.content
                if chunk.choices[0].delta and chunk.choices[0].delta.content
                else ""
            )

            yield delta

            if callbacks:
                for callback in callbacks:
                    callback.on_llm_new_token(delta)
```

This implementation of streaming responses offers several benefits:
1. **Real-time Output**: By yielding each chunk of the response as it's received, the system can provide real-time feedback to users.
2. **Callback Integration**: The streaming implementation integrates with the callback system, allowing for custom processing of each token as it's received.
3. **Efficient Resource Usage**: Streaming allows for processing of partial results, which can be beneficial for memory usage when dealing with long responses.

## Cross-Platform Considerations

When integrating LLMs, it's important to consider cross-platform compatibility. GraphRAG addresses this in several ways:

1. **Asynchronous Programming**: The use of `asyncio` ensures that the code can run efficiently on various Python implementations and operating systems.

2. **Abstraction Layers**: By using abstract base classes like `BaseLLM` and `BaseTextEmbedding`, GraphRAG allows for easy integration of different LLM providers across platforms.

3. **Configuration Flexibility**: The LLM implementations allow for various configuration options, including API endpoints and authentication methods, enabling adaptation to different environments.

4. **Error Handling**: The robust error handling and retry mechanisms help mitigate issues that may arise from platform-specific network or resource constraints.

## Conclusion

LLM integration is a core feature of GraphRAG, enabling powerful natural language processing capabilities. The system's design emphasizes flexibility, reliability, and efficiency through the use of asynchronous programming, robust error handling, and streaming responses.

Key takeaways from this lesson include:
- The importance of well-defined interfaces for LLM interactions
- The benefits of asynchronous programming in API-heavy applications
- The necessity of robust error handling and retry mechanisms when working with external services
- The value of streaming responses for real-time applications
- The role of cross-platform considerations in designing LLM integrations

As you work with GraphRAG, keep these principles in mind to ensure effective and reliable LLM integration in your applications.

## Review Questions

1. Explain the purpose of the `BaseLLM` abstract base class. How does it contribute to the flexibility of GraphRAG's LLM integration?

2. Describe the retry mechanism implemented in the `ChatOpenAI` class. Why is this important for reliable LLM integration?

3. How does GraphRAG handle streaming responses from LLMs? What are the benefits of this approach?

4. Explain the role of the `OpenAIEmbedding` class. How does it handle long texts that exceed the maximum token limit?

5. What cross-platform considerations are addressed in GraphRAG's LLM integration? How do these considerations impact the design of the system?

6. How does GraphRAG's error handling system contribute to the robustness of LLM operations? Provide an example from the code.

7. Describe the asynchronous programming patterns used in GraphRAG's LLM integration. How do these patterns improve performance?

## Hands-On Exercise

Implement a custom LLM provider integration for GraphRAG. Your implementation should:

1. Create a new class that inherits from `BaseLLM` and implements its abstract methods.
2. Implement a simple retry mechanism using `tenacity`.
3. Support both streaming and non-streaming response generation.
4. Include basic error handling and logging.
5. Demonstrate how to use the custom LLM provider in a GraphRAG context building or search operation.

This exercise will give you hands-on experience with the key concepts of LLM integration in GraphRAG, including interface implementation, error handling, and asynchronous programming.

