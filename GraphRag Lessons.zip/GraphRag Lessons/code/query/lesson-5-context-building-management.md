# Lesson 5: Context Building and Management in GraphRAG

## Introduction

In this lesson, we'll dive deep into the context building and management components of the GraphRAG query module. Context building is a crucial step in the process of generating relevant and accurate responses using large language models (LLMs). It involves selecting, processing, and organizing the most relevant information from the knowledge graph to provide as input to the LLM.

We'll explore the various context builder modules, examine advanced DataFrame operations for efficient data manipulation, discuss tokenization and text processing techniques, and investigate strategies for managing and optimizing context size for different LLM models.

## File Structure

Before we begin, let's look at the relevant file structure for context building and management in the GraphRAG query module:

```
graphrag/
└── query/
    ├── context_builder/
    │   ├── __init__.py
    │   ├── builders.py
    │   ├── community_context.py
    │   ├── conversation_history.py
    │   ├── entity_extraction.py
    │   ├── local_context.py
    │   └── source_context.py
    └── llm/
        └── text_utils.py
```

This structure shows the main components we'll be discussing in this lesson. The `context_builder` directory contains various modules for building different types of contexts, while the `llm/text_utils.py` file provides utility functions for text processing and tokenization.

## Context Builder Base Classes

Let's start by examining the base classes for context builders, which define the interface for all context building operations in GraphRAG. These classes are defined in the `builders.py` file:

```python
# graphrag/query/context_builder/builders.py

from abc import ABC, abstractmethod
import pandas as pd
from graphrag.query.context_builder.conversation_history import ConversationHistory

class GlobalContextBuilder(ABC):
    @abstractmethod
    def build_context(
        self, conversation_history: ConversationHistory | None = None, **kwargs
    ) -> tuple[str | list[str], dict[str, pd.DataFrame]]:
        """Build the context for the global search mode."""

class LocalContextBuilder(ABC):
    @abstractmethod
    def build_context(
        self,
        query: str,
        conversation_history: ConversationHistory | None = None,
        **kwargs,
    ) -> tuple[str | list[str], dict[str, pd.DataFrame]]:
        """Build the context for the local search mode."""
```

These abstract base classes define the `build_context` method, which is implemented by concrete context builder classes. The method signatures reveal important information about the context building process:

1. Both global and local context builders can optionally use conversation history.
2. The local context builder also requires the current query as input.
3. The methods return a tuple containing the built context (as a string or list of strings) and a dictionary of pandas DataFrames containing the context data.

This design allows for flexibility in implementing different context building strategies while maintaining a consistent interface.

## Community Context Building

One of the key context building strategies in GraphRAG is the community context builder, implemented in the `community_context.py` file. Let's examine its main components:

```python
# graphrag/query/context_builder/community_context.py

from typing import Any
import pandas as pd
import tiktoken
from graphrag.model import CommunityReport, Entity
from graphrag.query.context_builder.conversation_history import ConversationHistory
from graphrag.query.structured_search.base import GlobalContextBuilder

class GlobalCommunityContext(GlobalContextBuilder):
    def __init__(
        self,
        community_reports: list[CommunityReport],
        entities: list[Entity] | None = None,
        token_encoder: tiktoken.Encoding | None = None,
        random_state: int = 86,
    ):
        # ... initialization code ...

    def build_context(
        self,
        conversation_history: ConversationHistory | None = None,
        use_community_summary: bool = True,
        column_delimiter: str = "|",
        shuffle_data: bool = True,
        include_community_rank: bool = False,
        min_community_rank: int = 0,
        community_rank_name: str = "rank",
        include_community_weight: bool = True,
        community_weight_name: str = "occurrence",
        normalize_community_weight: bool = True,
        max_tokens: int = 8000,
        context_name: str = "Reports",
        conversation_history_user_turns_only: bool = True,
        conversation_history_max_turns: int | None = 5,
        **kwargs: Any,
    ) -> tuple[str | list[str], dict[str, pd.DataFrame]]:
        # ... implementation details ...
```

The `GlobalCommunityContext` class is responsible for building context based on community reports and entities. It offers a high degree of customization through various parameters:

1. `use_community_summary`: Determines whether to use full community reports or just summaries.
2. `include_community_rank` and `include_community_weight`: Control the inclusion of ranking and weighting information.
3. `max_tokens`: Limits the context size to fit within model constraints.
4. `conversation_history_max_turns`: Limits the number of previous conversation turns to include.

These parameters allow for fine-tuning the context building process based on the specific requirements of the task and the capabilities of the LLM being used.

## Local Context Building

For more focused queries, GraphRAG implements a local context builder that combines information from entities, relationships, and text units. This is implemented in the `local_context.py` file:

```python
# graphrag/query/context_builder/local_context.py

from typing import Any
import pandas as pd
import tiktoken
from graphrag.model import CommunityReport, Covariate, Entity, Relationship, TextUnit
from graphrag.query.context_builder.conversation_history import ConversationHistory
from graphrag.query.structured_search.base import LocalContextBuilder
from graphrag.vector_stores import BaseVectorStore

class LocalSearchMixedContext(LocalContextBuilder):
    def __init__(
        self,
        entities: list[Entity],
        entity_text_embeddings: BaseVectorStore,
        text_embedder: BaseTextEmbedding,
        text_units: list[TextUnit] | None = None,
        community_reports: list[CommunityReport] | None = None,
        relationships: list[Relationship] | None = None,
        covariates: dict[str, list[Covariate]] | None = None,
        token_encoder: tiktoken.Encoding | None = None,
        embedding_vectorstore_key: str = EntityVectorStoreKey.ID,
    ):
        # ... initialization code ...

    def build_context(
        self,
        query: str,
        conversation_history: ConversationHistory | None = None,
        include_entity_names: list[str] | None = None,
        exclude_entity_names: list[str] | None = None,
        conversation_history_max_turns: int | None = 5,
        conversation_history_user_turns_only: bool = True,
        max_tokens: int = 8000,
        text_unit_prop: float = 0.5,
        community_prop: float = 0.25,
        top_k_mapped_entities: int = 10,
        top_k_relationships: int = 10,
        include_community_rank: bool = False,
        include_entity_rank: bool = False,
        rank_description: str = "number of relationships",
        include_relationship_weight: bool = False,
        relationship_ranking_attribute: str = "rank",
        return_candidate_context: bool = False,
        use_community_summary: bool = False,
        min_community_rank: int = 0,
        community_context_name: str = "Reports",
        column_delimiter: str = "|",
        **kwargs: dict[str, Any],
    ) -> tuple[str | list[str], dict[str, pd.DataFrame]]:
        # ... implementation details ...
```

The `LocalSearchMixedContext` class combines various types of information to build a comprehensive context for local search queries. Some key features of this implementation include:

1. Use of entity text embeddings and a vector store for semantic similarity search.
2. Balancing different types of information through parameters like `text_unit_prop` and `community_prop`.
3. Flexible entity and relationship selection with `top_k_mapped_entities` and `top_k_relationships`.
4. Options to include or exclude specific entities and control the inclusion of ranking and weighting information.

This approach allows for highly targeted context building, which is crucial for accurately answering specific queries about the knowledge graph.

## Advanced DataFrame Operations

Both the global and local context builders make extensive use of pandas DataFrames for efficient data manipulation. Let's examine some of the advanced DataFrame operations used in the context building process:

```python
# Example from graphrag/query/context_builder/community_context.py

def _rank_report_context(
    report_df: pd.DataFrame,
    weight_column: str | None = "occurrence weight",
    rank_column: str | None = "rank",
) -> pd.DataFrame:
    rank_attributes: list[str] = []
    if weight_column:
        rank_attributes.append(weight_column)
        report_df[weight_column] = report_df[weight_column].astype(float)
    if rank_column:
        rank_attributes.append(rank_column)
        report_df[rank_column] = report_df[rank_column].astype(float)
    if len(rank_attributes) > 0:
        report_df.sort_values(by=rank_attributes, ascending=False, inplace=True)
    return report_df
```

This function demonstrates several important DataFrame operations:

1. Conditional column selection based on the presence of weight and rank columns.
2. Type casting of columns to ensure proper sorting.
3. Multi-column sorting with custom ordering.
4. In-place modification of the DataFrame for memory efficiency.

These operations allow for efficient processing and ordering of context data, which is crucial when dealing with large knowledge graphs.

## Tokenization and Text Processing

Tokenization and text processing are essential components of context building, as they help manage the input size for LLMs and ensure consistent text representation. GraphRAG implements these utilities in the `text_utils.py` file:

```python
# graphrag/query/llm/text_utils.py

import tiktoken
from itertools import islice

def num_tokens(text: str, token_encoder: tiktoken.Encoding | None = None) -> int:
    if token_encoder is None:
        token_encoder = tiktoken.get_encoding("cl100k_base")
    return len(token_encoder.encode(text))

def batched(iterable, n):
    it = iter(iterable)
    while batch := tuple(islice(it, n)):
        yield batch

def chunk_text(text: str, max_tokens: int, token_encoder: tiktoken.Encoding | None = None):
    if token_encoder is None:
        token_encoder = tiktoken.get_encoding("cl100k_base")
    tokens = token_encoder.encode(text)
    chunk_iterator = batched(iter(tokens), max_tokens)
    yield from (token_encoder.decode(list(chunk)) for chunk in chunk_iterator)
```

These utilities provide several important functions:

1. `num_tokens`: Calculates the number of tokens in a given text string, which is crucial for managing context size.
2. `batched`: A helper function for creating batches of tokens, used in the chunking process.
3. `chunk_text`: Splits long texts into smaller chunks based on a maximum token count, ensuring that context fits within model constraints.

These functions are used throughout the context building process to manage text length and ensure that the built context adheres to the token limits of the target LLM.

## Context Size Management and Optimization

Managing context size is crucial for effective use of LLMs, as most models have a maximum input token limit. GraphRAG implements several strategies for optimizing context size:

1. **Truncation**: Both global and local context builders use a `max_tokens` parameter to limit the overall context size.

2. **Proportional Allocation**: The local context builder allows for proportional allocation of tokens to different types of information through parameters like `text_unit_prop` and `community_prop`.

3. **Ranking and Filtering**: By using parameters like `top_k_mapped_entities` and `top_k_relationships`, the context builders can prioritize the most relevant information.

4. **Dynamic Adjustment**: The context builders track token counts as they add information, stopping when they reach the specified limit.

Here's an example of how token counting is used in the local context builder:

```python
# From graphrag/query/context_builder/local_context.py

total_tokens = entity_tokens + num_tokens(relationship_context, self.token_encoder)

for covariate in self.covariates:
    covariate_context, covariate_context_data = build_covariates_context(
        selected_entities=added_entities,
        covariates=self.covariates[covariate],
        token_encoder=self.token_encoder,
        max_tokens=max_tokens,
        column_delimiter=column_delimiter,
        context_name=covariate,
    )
    total_tokens += num_tokens(covariate_context, self.token_encoder)
    if total_tokens > max_tokens:
        log.info("Reached token limit - reverting to previous context state")
        break
```

This approach ensures that the built context stays within the specified token limit while prioritizing the most relevant information.

## Cross-Platform Considerations

When implementing context building and management, it's important to consider cross-platform compatibility. GraphRAG addresses this in several ways:

1. **File Path Handling**: The code uses `os.path.join()` and `pathlib.Path` for file path manipulations, ensuring compatibility across different operating systems.

2. **Text Encoding**: The `tiktoken` library is used for consistent tokenization across platforms, and the code allows for specifying custom encodings when necessary.

3. **DataFrame Operations**: Pandas is used for data manipulation, providing a consistent interface across different platforms and Python implementations.

4. **Asynchronous Operations**: The context builders use asynchronous methods, allowing for efficient I/O operations on different platforms and runtime environments.

## Conclusion

Context building and management are critical components of the GraphRAG query module. They enable the system to provide relevant and concise information to the LLM, facilitating accurate and contextually appropriate responses. The modular design of the context builders, combined with flexible configuration options, allows for adaptation to various use cases and LLM requirements.

In this lesson, we've explored the implementation details of global and local context builders, examined advanced DataFrame operations used in data processing, discussed tokenization and text processing techniques, and investigated strategies for managing and optimizing context size. We've also touched on cross-platform considerations in the implementation of these components.

As you work with GraphRAG, remember that effective context building can significantly impact the quality of LLM responses. Experiment with different context building strategies and parameters to find the optimal configuration for your specific use case and target LLM.

## Review Questions

1. Explain the difference between global and local context builders in GraphRAG. How do their implementations differ, and in what scenarios would you use each?

2. Describe the role of the `tiktoken` library in context building and management. How does it help in managing context size?

3. What strategies does GraphRAG employ to optimize context size while maintaining relevance? Provide examples from the code.

4. How does the `LocalSearchMixedContext` class balance different types of information in the context? What parameters control this balance?

5. Explain the purpose of the `_rank_report_context` function in community context building. How does it use advanced DataFrame operations?

6. What cross-platform considerations are addressed in the context building and management code? How are these considerations implemented?

7. How does GraphRAG handle conversation history in context building? What options are available for controlling the inclusion of previous turns?

8. Describe the process of chunking text in GraphRAG. Why is this process important, and how is it implemented?

## Hands-On Exercise

Implement a custom context builder for GraphRAG that combines features from both global and local context builders. This new context builder should:

1. Use entity embeddings to find relevant entities based on the query.
2. Include community reports for the selected entities.
3. Add relationships and text units associated with the selected entities.
4. Implement a dynamic token allocation strategy that adjusts the proportion of different information types based on the query length.

Here's a skeleton to get you started:

```python
import tiktoken
from typing import Any
import pandas as pd
from graphrag.query.context_builder.builders import LocalContextBuilder
from graphrag.query.context_builder.conversation_history import ConversationHistory
from graphrag.model import Entity, CommunityReport, Relationship, TextUnit
from graphrag.vector_stores import BaseVectorStore
from graphrag.query.llm.base import BaseTextEmbedding
from graphrag.query.llm.text_utils import num_tokens

class DynamicMixedContextBuilder(LocalContextBuilder):
    def __init__(
        self,
        entities: list[Entity],
        community_reports: list[CommunityReport],
        relationships: list[Relationship],
        text_units: list[TextUnit],
        entity_embeddings: BaseVectorStore,
        text_embedder: BaseTextEmbedding,
        token_encoder: tiktoken.Encoding | None = None,
    ):
        self.entities = {entity.id: entity for entity in entities}
        self.community_reports = {report.id: report for report in community_reports}
        self.relationships = {rel.id: rel for rel in relationships}
        self.text_units = {unit.id: unit for unit in text_units}
        self.entity_embeddings = entity_embeddings
        self.text_embedder = text_embedder
        self.token_encoder = token_encoder or tiktoken.get_encoding("cl100k_base")

    def build_context(
        self,
        query: str,
        conversation_history: ConversationHistory | None = None,
        max_tokens: int = 8000,
        **kwargs: Any,
    ) -> tuple[str, dict[str, pd.DataFrame]]:
        # 1. Find relevant entities based on query
        relevant_entities = self._find_relevant_entities(query)

        # 2. Allocate tokens dynamically
        token_allocations = self._allocate_tokens(query, max_tokens)

        # 3. Build context components
        community_context = self._build_community_context(relevant_entities, token_allocations['community'])
        relationship_context = self._build_relationship_context(relevant_entities, token_allocations['relationship'])
        text_unit_context = self._build_text_unit_context(relevant_entities, token_allocations['text_unit'])

        # 4. Combine context components
        full_context = f"{community_context}\n\n{relationship_context}\n\n{text_unit_context}"
        
        # 5. Prepare context data for return
        context_data = {
            "community_reports": pd.DataFrame(self.community_reports).T,
            "relationships": pd.DataFrame(self.relationships).T,
            "text_units": pd.DataFrame(self.text_units).T,
        }

        return full_context, context_data

    def _find_relevant_entities(self, query: str, top_k: int = 10) -> list[Entity]:
        # Implement entity retrieval based on query embedding
        pass

    def _allocate_tokens(self, query: str, max_tokens: int) -> dict[str, int]:
        # Implement dynamic token allocation based on query length
        pass

    def _build_community_context(self, entities: list[Entity], max_tokens: int) -> str:
        # Implement community context building
        pass

    def _build_relationship_context(self, entities: list[Entity], max_tokens: int) -> str:
        # Implement relationship context building
        pass

    def _build_text_unit_context(self, entities: list[Entity], max_tokens: int) -> str:
        # Implement text unit context building
        pass
```

Your task is to complete the implementation of this `DynamicMixedContextBuilder` class. Focus on the following aspects:

1. Implement the `_find_relevant_entities` method using the entity embeddings and text embedder to find entities semantically related to the query.

2. Create a dynamic token allocation strategy in the `_allocate_tokens` method. Consider allocating more tokens to text units for longer queries and more tokens to community reports for shorter queries.

3. Implement the context building methods (`_build_community_context`, `_build_relationship_context`, and `_build_text_unit_context`), ensuring they respect the allocated token limits.

4. In the main `build_context` method, add logic to include conversation history if provided, and ensure the total context stays within the `max_tokens` limit.

5. Add error handling and logging throughout the implementation to make the context builder robust and debuggable.

This exercise will give you hands-on experience with the key concepts of context building in GraphRAG, including entity retrieval, token management, and combining different types of information into a coherent context.

