# Lesson 8: Structured Search Implementations in GraphRAG

## Introduction

In this lesson, we'll dive deep into the structured search implementations within the GraphRAG query module. We'll explore how GraphRAG leverages graph-based data structures to perform efficient and context-aware searches. We'll focus on two main search strategies: global search and local search, and examine how these are implemented, their use cases, and the trade-offs between them.

## File Structure

Before we delve into the details, let's take a look at the relevant file structure for the structured search implementations:

```
graphrag/
└── query/
    └── structured_search/
        ├── base.py
        ├── __init__.py
        ├── global_search/
        │   ├── community_context.py
        │   ├── map_system_prompt.py
        │   ├── reduce_system_prompt.py
        │   ├── search.py
        │   └── __init__.py
        └── local_search/
            ├── mixed_context.py
            ├── search.py
            ├── system_prompt.py
            └── __init__.py
```

This structure shows the organization of the structured search components in GraphRAG. The `base.py` file contains the base classes for search implementations, while the `global_search` and `local_search` directories contain the specific implementations for each search strategy.

## Base Search Implementation

Let's start by examining the base search implementation in `base.py`:

```python
from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator
from dataclasses import dataclass
from typing import Any

import pandas as pd
import tiktoken

from graphrag.query.context_builder.builders import (
    GlobalContextBuilder,
    LocalContextBuilder,
)
from graphrag.query.context_builder.conversation_history import (
    ConversationHistory,
)
from graphrag.query.llm.base import BaseLLM

@dataclass
class SearchResult:
    """A Structured Search Result."""
    response: str | dict[str, Any] | list[dict[str, Any]]
    context_data: str | list[pd.DataFrame] | dict[str, pd.DataFrame]
    context_text: str | list[str] | dict[str, str]
    completion_time: float
    llm_calls: int
    prompt_tokens: int

class BaseSearch(ABC):
    """The Base Search implementation."""

    def __init__(
        self,
        llm: BaseLLM,
        context_builder: GlobalContextBuilder | LocalContextBuilder,
        token_encoder: tiktoken.Encoding | None = None,
        llm_params: dict[str, Any] | None = None,
        context_builder_params: dict[str, Any] | None = None,
    ):
        self.llm = llm
        self.context_builder = context_builder
        self.token_encoder = token_encoder
        self.llm_params = llm_params or {}
        self.context_builder_params = context_builder_params or {}

    @abstractmethod
    def search(
        self,
        query: str,
        conversation_history: ConversationHistory | None = None,
        **kwargs,
    ) -> SearchResult:
        """Search for the given query."""

    @abstractmethod
    async def asearch(
        self,
        query: str,
        conversation_history: ConversationHistory | None = None,
        **kwargs,
    ) -> SearchResult:
        """Search for the given query asynchronously."""

    @abstractmethod
    def astream_search(
        self,
        query: str,
        conversation_history: ConversationHistory | None = None,
    ) -> AsyncGenerator[str, None]:
        """Stream search for the given query."""
```

This base implementation defines the common structure and interface for all search strategies in GraphRAG. Let's break down its key components:

1. `SearchResult`: This dataclass represents the result of a search operation. It includes the response, context data, completion time, and other metadata that can be useful for analysis and debugging.

2. `BaseSearch`: This abstract base class defines the interface for all search implementations. It includes:
   - An initializer that sets up common components like the language model (LLM), context builder, and token encoder.
   - Abstract methods for synchronous search (`search`), asynchronous search (`asearch`), and streaming search (`astream_search`).

The use of abstract base classes here allows for a consistent interface across different search implementations while allowing for strategy-specific optimizations and features.

## Global Search Implementation

The global search strategy in GraphRAG is designed to search across the entire knowledge graph to find relevant information. Let's examine its implementation in `global_search/search.py`:

```python
class GlobalSearch(BaseSearch):
    """Search orchestration for global search mode."""

    def __init__(
        self,
        llm: BaseLLM,
        context_builder: GlobalContextBuilder,
        token_encoder: tiktoken.Encoding | None = None,
        map_system_prompt: str = MAP_SYSTEM_PROMPT,
        reduce_system_prompt: str = REDUCE_SYSTEM_PROMPT,
        response_type: str = "multiple paragraphs",
        allow_general_knowledge: bool = False,
        general_knowledge_inclusion_prompt: str = GENERAL_KNOWLEDGE_INSTRUCTION,
        json_mode: bool = True,
        callbacks: list[GlobalSearchLLMCallback] | None = None,
        max_data_tokens: int = 8000,
        map_llm_params: dict[str, Any] = DEFAULT_MAP_LLM_PARAMS,
        reduce_llm_params: dict[str, Any] = DEFAULT_REDUCE_LLM_PARAMS,
        context_builder_params: dict[str, Any] | None = None,
        concurrent_coroutines: int = 32,
    ):
        # ... (initialization code)

    async def astream_search(
        self,
        query: str,
        conversation_history: ConversationHistory | None = None,
    ) -> AsyncGenerator:
        # ... (implementation of streaming search)

    async def asearch(
        self,
        query: str,
        conversation_history: ConversationHistory | None = None,
        **kwargs: Any,
    ) -> GlobalSearchResult:
        # ... (implementation of asynchronous search)

    def search(
        self,
        query: str,
        conversation_history: ConversationHistory | None = None,
        **kwargs: Any,
    ) -> GlobalSearchResult:
        # ... (implementation of synchronous search)

    async def _map_response_single_batch(
        self,
        context_data: str,
        query: str,
        **llm_kwargs,
    ) -> SearchResult:
        # ... (implementation of mapping response for a single batch)

    async def _reduce_response(
        self,
        map_responses: list[SearchResult],
        query: str,
        **llm_kwargs,
    ) -> SearchResult:
        # ... (implementation of reducing responses)

    async def _stream_reduce_response(
        self,
        map_responses: list[SearchResult],
        query: str,
        **llm_kwargs,
    ) -> AsyncGenerator[str, None]:
        # ... (implementation of streaming reduce response)
```

The global search implementation uses a map-reduce approach:

1. **Mapping**: The search query is applied to multiple batches of the knowledge graph in parallel. This is done in the `_map_response_single_batch` method.

2. **Reducing**: The results from the mapping stage are combined and synthesized into a final response. This is handled by the `_reduce_response` method.

This approach allows GraphRAG to efficiently search large knowledge graphs by distributing the workload and then combining the results.

The global search also supports streaming responses, which is particularly useful for generating responses in real-time as they're being computed.

## Local Search Implementation

The local search strategy in GraphRAG focuses on searching a specific subset of the knowledge graph, typically centered around entities relevant to the query. Let's examine its implementation in `local_search/search.py`:

```python
class LocalSearch(BaseSearch):
    """Search orchestration for local search mode."""

    def __init__(
        self,
        llm: BaseLLM,
        context_builder: LocalContextBuilder,
        token_encoder: tiktoken.Encoding | None = None,
        system_prompt: str = LOCAL_SEARCH_SYSTEM_PROMPT,
        response_type: str = "multiple paragraphs",
        callbacks: list[BaseLLMCallback] | None = None,
        llm_params: dict[str, Any] = DEFAULT_LLM_PARAMS,
        context_builder_params: dict | None = None,
    ):
        # ... (initialization code)

    async def asearch(
        self,
        query: str,
        conversation_history: ConversationHistory | None = None,
        **kwargs,
    ) -> SearchResult:
        # ... (implementation of asynchronous search)

    async def astream_search(
        self,
        query: str,
        conversation_history: ConversationHistory | None = None,
    ) -> AsyncGenerator:
        # ... (implementation of streaming search)

    def search(
        self,
        query: str,
        conversation_history: ConversationHistory | None = None,
        **kwargs,
    ) -> SearchResult:
        # ... (implementation of synchronous search)
```

The local search implementation differs from the global search in several key ways:

1. It uses a `LocalContextBuilder` instead of a `GlobalContextBuilder`. This allows it to focus on a specific subset of the knowledge graph.

2. It doesn't use the map-reduce approach. Instead, it builds a single context and generates a response based on that context.

3. The context building process is more focused, typically centering around specific entities or relationships relevant to the query.

## Context Building

Both global and local search strategies rely heavily on context building. Let's examine the `GlobalCommunityContext` class from `global_search/community_context.py` as an example:

```python
class GlobalCommunityContext(GlobalContextBuilder):
    """GlobalSearch community context builder."""

    def __init__(
        self,
        community_reports: list[CommunityReport],
        entities: list[Entity] | None = None,
        token_encoder: tiktoken.Encoding | None = None,
        random_state: int = 86,
    ):
        # ... (initialization code)

    def build_context(
        self,
        conversation_history: ConversationHistory | None = None,
        use_community_summary: bool = True,
        column_delimiter: str = "|",
        shuffle_data: bool = True,
        include_community_rank: bool = False,
        min_community_rank: int = 0,
        community_rank_name: str = "rank",
        include_community_weight: bool = True,
        community_weight_name: str = "occurrence",
        normalize_community_weight: bool = True,
        max_tokens: int = 8000,
        context_name: str = "Reports",
        conversation_history_user_turns_only: bool = True,
        conversation_history_max_turns: int | None = 5,
        **kwargs: Any,
    ) -> tuple[str | list[str], dict[str, pd.DataFrame]]:
        # ... (implementation of context building)
```

This context builder is responsible for creating a context that the global search can use. It takes into account various factors like community reports, entities, conversation history, and more. The context it builds is crucial for the effectiveness of the search, as it provides the foundation for the language model to generate relevant responses.

## System Prompts

Both global and local search strategies use system prompts to guide the language model in generating appropriate responses. Let's look at an excerpt from the global search map prompt in `global_search/map_system_prompt.py`:

```python
MAP_SYSTEM_PROMPT = """
---Role---

You are a helpful assistant responding to questions about data in the tables provided.

---Goal---

Generate a response consisting of a list of key points that responds to the user's question, summarizing all relevant information in the input data tables.

You should use the data provided in the data tables below as the primary context for generating the response.
If you don't know the answer or if the input data tables do not contain sufficient information to provide an answer, just say so. Do not make anything up.

Each key point in the response should have the following element:
- Description: A comprehensive description of the point.
- Importance Score: An integer score between 0-100 that indicates how important the point is in answering the user's question. An 'I don't know' type of response should have a score of 0.

The response should be JSON formatted as follows:
{{
    "points": [
        {{"description": "Description of point 1 [Data: Reports (report ids)]", "score": score_value}},
        {{"description": "Description of point 2 [Data: Reports (report ids)]", "score": score_value}}
    ]
}}

...

---Data tables---

{context_data}

...
"""
```

This prompt guides the language model in how to format its response and what kind of information to include. The use of structured prompts like this allows GraphRAG to generate consistent and useful responses across different queries and contexts.

## Conclusion

The structured search implementations in GraphRAG demonstrate a sophisticated approach to leveraging graph-based knowledge for question answering. By providing both global and local search strategies, GraphRAG can handle a wide range of query types and knowledge graph sizes efficiently.

Key takeaways from this lesson include:

1. The use of abstract base classes to define a consistent interface for different search strategies.
2. The map-reduce approach in global search for handling large-scale knowledge graphs.
3. The focused approach of local search for queries that benefit from a more specific context.
4. The importance of context building in both search strategies.
5. The use of structured system prompts to guide the language model in generating appropriate responses.

In the next lesson, we'll explore advanced topics and optimization techniques to further enhance the performance and capabilities of GraphRAG's search implementations.

## Exercises

1. Implement a new search strategy that combines aspects of both global and local search. How would you decide when to use each approach?

2. Modify the `GlobalSearch` class to include a caching mechanism for map responses. How might this improve performance for similar queries?

3. Implement a new context builder that takes into account the user's previous queries and responses. How might this improve the relevance of search results over a conversation?

4. Analyze the time complexity of the global search's map-reduce approach. Under what circumstances might it perform better or worse than the local search approach?

5. Implement a custom `SearchResult` class that includes metadata about which parts of the knowledge graph were most relevant to the query. How could this be used to improve future searches?

## Review Questions

1. What are the main differences between the global search and local search strategies in GraphRAG? When might you choose one over the other?

2. How does the map-reduce approach in global search help with searching large knowledge graphs? What are potential limitations of this approach?

3. Why is context building crucial for both global and local search strategies? How do the context builders differ between these two approaches?

4. How do the system prompts contribute to the effectiveness of the search strategies? What key elements do they include?

5. How does GraphRAG handle streaming responses in its search implementations? Why might this be beneficial in real-world applications?

6. What role does the `ConversationHistory` play in the search process? How might it be used to improve search results over time?

7. How does GraphRAG balance between using information from the knowledge graph and allowing for general knowledge in its responses?

8. What are some potential optimizations that could be applied to the current search implementations in GraphRAG?

By mastering these concepts and working through the exercises, you'll gain a deep understanding of how GraphRAG implements structured search on graph-based knowledge, and you'll be well-equipped to extend and optimize these search strategies for various use cases.

