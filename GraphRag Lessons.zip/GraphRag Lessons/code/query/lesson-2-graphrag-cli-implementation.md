# Lesson 2: Command Line Interface (CLI) Implementation in GraphRAG

## 1. Deep Dive into the `cli.py` File and Its Structure

The `cli.py` file is a crucial component of the GraphRAG query module, serving as the entry point for command-line interactions. Let's examine its structure and key components in detail.

### 1.1 File Location and Purpose

The `cli.py` file is located in the root of the `query` module:

```
graphrag/
└── query/
    ├── cli.py
    └── ...
```

Its primary purpose is to provide a user-friendly interface for executing GraphRAG queries from the command line. This allows users to leverage the power of GraphRAG without needing to write Python code or interact with the API directly.

### 1.2 Key Functions

The `cli.py` file contains several important functions:

1. `run_global_search`: This function performs a global search across the entire knowledge graph.
2. `run_local_search`: This function executes a local search, focusing on a specific subset of the knowledge graph.
3. `_resolve_parquet_files`: A helper function that reads Parquet files into dataframes.

Let's look at the structure of the `run_global_search` function as an example:

```python
def run_global_search(
    config_filepath: str | None,
    data_dir: str | None,
    root_dir: str,
    community_level: int,
    response_type: str,
    streaming: bool,
    query: str,
):
    # Function implementation...
```

This function signature demonstrates the key parameters that control the global search behavior, including configuration file path, data directory, root directory, community level, response type, streaming option, and the query itself.

### 1.3 Main Execution Flow

The main execution flow in `cli.py` typically follows these steps:

1. Parse command-line arguments
2. Load configuration and resolve paths
3. Read necessary data files (e.g., nodes, entities, community reports)
4. Execute the appropriate search function (global or local)
5. Handle the search results (e.g., print to console or stream)

This structure allows for a clear separation of concerns and makes the code more maintainable and extensible.

## 2. Argument Parsing with `argparse`: Creating a Robust CLI

The GraphRAG CLI uses Python's built-in `argparse` module to handle command-line arguments. This provides a flexible and powerful way to define and parse arguments.

### 2.1 Setting Up the ArgumentParser

Here's an example of how the ArgumentParser might be set up in `cli.py`:

```python
import argparse

parser = argparse.ArgumentParser(
    prog="python -m graphrag.query",
    description="The graphrag query engine",
)

parser.add_argument(
    "--config",
    help="The configuration yaml file to use when running the query",
    required=False,
    type=file_exist,
)
parser.add_argument(
    "--data",
    help="The path with the output data from the pipeline",
    type=dir_exist,
)
parser.add_argument(
    "--root",
    help="The data project root. Default value: the current directory",
    default=".",
    type=dir_exist,
)
parser.add_argument(
    "--method",
    help="The method to run",
    required=True,
    type=SearchType,
    choices=list(SearchType),
)
# ... more arguments ...

args = parser.parse_args()
```

This setup defines various command-line arguments that users can provide when running the GraphRAG query tool. Let's break down some key points:

- The `prog` parameter sets the program name that appears in help messages.
- Each `add_argument` call defines a new command-line option.
- Custom types (like `file_exist`, `dir_exist`, and `SearchType`) are used to validate input and convert it to the appropriate Python type.
- The `choices` parameter for the `--method` argument restricts the allowed values to those defined in the `SearchType` enum.

### 2.2 Custom Argument Types

To enhance input validation, GraphRAG uses custom argument types. These are likely defined elsewhere in the codebase, but here's an example of what they might look like:

```python
def file_exist(path):
    if not os.path.isfile(path):
        raise argparse.ArgumentTypeError(f"{path} is not a valid file")
    return path

def dir_exist(path):
    if not os.path.isdir(path):
        raise argparse.ArgumentTypeError(f"{path} is not a valid directory")
    return path

class SearchType(Enum):
    LOCAL = "local"
    GLOBAL = "global"

    def __str__(self):
        return self.value
```

These custom types provide immediate validation of user input, ensuring that files and directories exist and that only valid search types are accepted.

## 3. Implementing Global and Local Search Functions in Detail

The `run_global_search` and `run_local_search` functions are the core of the CLI's functionality. Let's examine their implementation in more detail.

### 3.1 Global Search Implementation

The `run_global_search` function typically follows these steps:

1. Load and resolve the configuration
2. Load necessary data files (nodes, entities, community reports)
3. Set up the search parameters
4. Execute the search (either streaming or non-streaming)
5. Handle and return the results

Here's a simplified version of what this might look like:

```python
def run_global_search(
    config_filepath: str | None,
    data_dir: str | None,
    root_dir: str,
    community_level: int,
    response_type: str,
    streaming: bool,
    query: str,
):
    root = Path(root_dir).resolve()
    config = load_config(root, config_filepath)
    config.storage.base_dir = data_dir or config.storage.base_dir
    resolve_paths(config)

    dataframe_dict = _resolve_parquet_files(
        root_dir=root_dir,
        config=config,
        parquet_list=[
            "create_final_nodes.parquet",
            "create_final_entities.parquet",
            "create_final_community_reports.parquet",
        ],
        optional_list=[],
    )
    
    if streaming:
        async def run_streaming_search():
            async for stream_chunk in api.global_search_streaming(
                config=config,
                nodes=dataframe_dict["create_final_nodes"],
                entities=dataframe_dict["create_final_entities"],
                community_reports=dataframe_dict["create_final_community_reports"],
                community_level=community_level,
                response_type=response_type,
                query=query,
            ):
                print(stream_chunk, end="")
                sys.stdout.flush()

        return asyncio.run(run_streaming_search())
    else:
        response, _ = asyncio.run(
            api.global_search(
                config=config,
                nodes=dataframe_dict["create_final_nodes"],
                entities=dataframe_dict["create_final_entities"],
                community_reports=dataframe_dict["create_final_community_reports"],
                community_level=community_level,
                response_type=response_type,
                query=query,
            )
        )
        print(f"Global Search Response:\n{response}")
        return response, None
```

This implementation demonstrates several important aspects:
- Asynchronous execution using `asyncio`
- Handling of streaming and non-streaming responses
- Loading and preparation of necessary data
- Integration with the GraphRAG API

### 3.2 Local Search Implementation

The `run_local_search` function follows a similar pattern to the global search, but it may include additional steps for preparing local context. Here's a simplified example:

```python
def run_local_search(
    config_filepath: str | None,
    data_dir: str | None,
    root_dir: str,
    community_level: int,
    response_type: str,
    streaming: bool,
    query: str,
):
    root = Path(root_dir).resolve()
    config = load_config(root, config_filepath)
    config.storage.base_dir = data_dir or config.storage.base_dir
    resolve_paths(config)

    dataframe_dict = _resolve_parquet_files(
        root_dir=root_dir,
        config=config,
        parquet_list=[
            "create_final_nodes.parquet",
            "create_final_community_reports.parquet",
            "create_final_text_units.parquet",
            "create_final_relationships.parquet",
            "create_final_entities.parquet",
        ],
        optional_list=["create_final_covariates.parquet"],
    )

    if streaming:
        async def run_streaming_search():
            async for stream_chunk in api.local_search_streaming(
                config=config,
                nodes=dataframe_dict["create_final_nodes"],
                entities=dataframe_dict["create_final_entities"],
                community_reports=dataframe_dict["create_final_community_reports"],
                text_units=dataframe_dict["create_final_text_units"],
                relationships=dataframe_dict["create_final_relationships"],
                covariates=dataframe_dict.get("create_final_covariates"),
                community_level=community_level,
                response_type=response_type,
                query=query,
            ):
                print(stream_chunk, end="")
                sys.stdout.flush()

        return asyncio.run(run_streaming_search())
    else:
        response, _ = asyncio.run(
            api.local_search(
                config=config,
                nodes=dataframe_dict["create_final_nodes"],
                entities=dataframe_dict["create_final_entities"],
                community_reports=dataframe_dict["create_final_community_reports"],
                text_units=dataframe_dict["create_final_text_units"],
                relationships=dataframe_dict["create_final_relationships"],
                covariates=dataframe_dict.get("create_final_covariates"),
                community_level=community_level,
                response_type=response_type,
                query=query,
            )
        )
        print(f"Local Search Response:\n{response}")
        return response, None
```

The local search implementation includes additional data loading steps for text units, relationships, and covariates, which are necessary for constructing the local context.

## 4. Working with Configuration Files and Data Directories

GraphRAG uses configuration files to manage various settings and parameters. The CLI interface allows users to specify the location of these configuration files and data directories.

### 4.1 Loading Configuration Files

The `load_config` function (imported from `graphrag.config`) is used to load configuration files. This function likely handles tasks such as:

- Reading YAML or JSON configuration files
- Validating the configuration structure
- Setting default values for missing parameters
- Resolving relative paths to absolute paths

### 4.2 Resolving Paths

The `resolve_paths` function is used to ensure that all paths in the configuration are properly resolved relative to the root directory. This is crucial for maintaining consistency across different operating systems and execution environments.

### 4.3 Handling Data Directories

The CLI allows users to specify a data directory using the `--data` argument. If not provided, it falls back to the base directory specified in the configuration. This flexibility allows users to easily switch between different datasets or versions of the data.

## 5. Error Handling and Logging in CLI Applications

Robust error handling and logging are crucial for creating a user-friendly CLI application. GraphRAG implements several strategies for this.

### 5.1 Exception Handling

The CLI implementation uses try-except blocks to catch and handle exceptions. For example:

```python
try:
    # Perform some operation
    result = some_function()
except SomeSpecificError as e:
    print(f"An error occurred: {e}", file=sys.stderr)
    sys.exit(1)
except Exception as e:
    print(f"An unexpected error occurred: {e}", file=sys.stderr)
    sys.exit(1)
```

This approach allows for graceful handling of both expected and unexpected errors, providing informative messages to the user.

### 5.2 Logging

GraphRAG uses Python's built-in `logging` module for more detailed logging. This allows for different levels of logging (e.g., DEBUG, INFO, WARNING, ERROR) and can be configured to write logs to files or other outputs.

```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Later in the code
logger.info("Starting global search")
logger.debug(f"Loaded configuration: {config}")
logger.warning("Some non-critical issue occurred")
logger.error("A critical error occurred", exc_info=True)
```

This structured logging approach helps with debugging and monitoring the application's behavior.

## 6. Cross-platform Command-line Usage and Compatibility

Ensuring cross-platform compatibility is essential for CLI applications. GraphRAG addresses this in several ways:

### 6.1 Path Handling

As mentioned earlier, GraphRAG uses the `pathlib` module for handling file paths. This ensures that paths are correctly formatted for the current operating system:

```python
from pathlib import Path

root = Path(root_dir).resolve()
config_path = root / "config.yaml"
```

### 6.2 Environment Variables

GraphRAG likely uses environment variables for sensitive information like API keys. This approach works across different operating systems and allows for easy configuration in various deployment environments.

### 6.3 File System Operations

When performing file system operations, GraphRAG uses functions that work across different operating systems. For example, using `os.path.join()` instead of hardcoding path separators.

## 7. Best Practices for CLI Design and User Experience

GraphRAG's CLI implementation follows several best practices for creating a good user experience:

### 7.1 Clear Help Messages

The use of `argparse` allows for automatic generation of help messages. GraphRAG enhances this by providing clear, concise descriptions for each argument.

### 7.2 Sensible Defaults

Where possible, GraphRAG provides sensible default values for arguments, reducing the amount of input required from users for common operations.

### 7.3 Input Validation

Custom argument types (like `file_exist` and `dir_exist`) provide immediate feedback on invalid inputs, helping users correct mistakes quickly.

### 7.4 Progressive Disclosure

The CLI is designed with a layered approach, allowing basic usage with minimal arguments while providing additional options for more advanced use cases.

### 7.5 Consistent Output Formatting

GraphRAG likely uses consistent formatting for its output, making it easier for users to parse and understand the results of their queries.

## Review Questions

1. Explain the main purpose of the `cli.py` file in the GraphRAG query module. How does it facilitate user interaction with the system?

2. Describe the key differences between the `run_global_search` and `run_local_search` functions. Why might a user choose one over the other?

3. How does GraphRAG use `argparse` to create a robust command-line interface? Provide an example of how custom argument types enhance input validation.

4. Explain the role of configuration files in the GraphRAG CLI. How does the system handle loading and resolving configurations?

5. Describe the error handling and logging strategies implemented in the GraphRAG CLI. Why are these important for a command-line application?

6. How does GraphRAG ensure cross-platform compatibility in its CLI implementation? Provide examples of specific techniques used.

7. Discuss three best practices for CLI design that are evident in the GraphRAG implementation. How do these improve the user experience?

## Hands-on Exercise

To gain practical experience with the GraphRAG CLI implementation, complete the following exercise:

1. Set up a development environment for GraphRAG if you haven't already done so.

2. Create a new Python script called `custom_cli.py` that implements a simplified version of the GraphRAG CLI. Your script should:
   - Use `argparse` to define at least three command-line arguments (e.g., `--config`, `--query`, `--method`)
   - Implement custom argument types for input validation (e.g., for checking if a file exists)
   - Create dummy functions for `run_global_search` and `run_local_search` that print out the received arguments
   - Use a configuration file (you can create a simple JSON or YAML file) and implement logic to load and use this configuration
   - Implement basic error handling and logging

3. Test your `custom_cli.py` script with various inputs, including:
   - Valid inputs for all arguments
   - Missing required arguments
   - Invalid file paths or non-existent directories
   - Invalid search methods

4. Extend your script to handle a simple streaming output scenario. For example, implement a function that yields results one at a time and use it in your search functions.

5. Document your script, explaining how each part relates to the concepts discussed in this lesson about the GraphRAG CLI implementation.

6. Reflect on the challenges you encountered while implementing this simplified CLI. How might these challenges scale in a more complex system like GraphRAG?

This exercise will give you hands-on experience with the key concepts of CLI implementation in Python, mirroring the approach used in GraphRAG. It will help you understand the practical considerations involved in creating a user-friendly and robust command-line interface.

