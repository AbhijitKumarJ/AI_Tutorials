# Lesson 3: Factory Pattern and Configuration Management in GraphRAG

## 1. Comprehensive Exploration of the `factories.py` File

The `factories.py` file in the GraphRAG query module is a crucial component that implements the factory pattern to create various objects used throughout the system. Let's explore its structure and key components in detail.

### 1.1 File Location and Purpose

The `factories.py` file is located in the root of the `query` module:

```
graphrag/
└── query/
    ├── factories.py
    └── ...
```

Its primary purpose is to centralize the creation of complex objects, particularly those that require configuration and setup. This centralization helps manage the complexity of object creation and promotes a cleaner, more maintainable codebase.

### 1.2 Key Factory Functions

The `factories.py` file typically contains several factory functions, each responsible for creating a specific type of object. Let's examine some of the key factory functions:

#### 1.2.1 LLM Client Factory

The `get_llm` function is responsible for creating and configuring a Language Model (LLM) client:

```python
def get_llm(config: GraphRagConfig) -> ChatOpenAI:
    """Get the LLM client."""
    is_azure_client = (
        config.llm.type == LLMType.AzureOpenAIChat
        or config.llm.type == LLMType.AzureOpenAI
    )
    debug_llm_key = config.llm.api_key or ""
    llm_debug_info = {
        **config.llm.model_dump(),
        "api_key": f"REDACTED,len={len(debug_llm_key)}",
    }
    if config.llm.cognitive_services_endpoint is None:
        cognitive_services_endpoint = "https://cognitiveservices.azure.com/.default"
    else:
        cognitive_services_endpoint = config.llm.cognitive_services_endpoint
    print(f"creating llm client with {llm_debug_info}")
    return ChatOpenAI(
        api_key=config.llm.api_key,
        azure_ad_token_provider=(
            get_bearer_token_provider(
                DefaultAzureCredential(), cognitive_services_endpoint
            )
            if is_azure_client and not config.llm.api_key
            else None
        ),
        api_base=config.llm.api_base,
        organization=config.llm.organization,
        model=config.llm.model,
        api_type=OpenaiApiType.AzureOpenAI if is_azure_client else OpenaiApiType.OpenAI,
        deployment_name=config.llm.deployment_name,
        api_version=config.llm.api_version,
        max_retries=config.llm.max_retries,
        request_timeout=config.llm.request_timeout,
    )
```

This function demonstrates several important aspects of factory methods in GraphRAG:
- It takes a configuration object as input, allowing for flexible setup based on user preferences.
- It handles different client types (OpenAI vs. Azure) based on the configuration.
- It manages sensitive information like API keys, redacting them in debug output.
- It sets up authentication, including Azure AD token providers when necessary.

#### 1.2.2 Text Embedder Factory

The `get_text_embedder` function creates and configures a text embedding client:

```python
def get_text_embedder(config: GraphRagConfig) -> OpenAIEmbedding:
    """Get the LLM client for embeddings."""
    is_azure_client = config.embeddings.llm.type == LLMType.AzureOpenAIEmbedding
    debug_embedding_api_key = config.embeddings.llm.api_key or ""
    llm_debug_info = {
        **config.embeddings.llm.model_dump(),
        "api_key": f"REDACTED,len={len(debug_embedding_api_key)}",
    }
    if config.embeddings.llm.cognitive_services_endpoint is None:
        cognitive_services_endpoint = "https://cognitiveservices.azure.com/.default"
    else:
        cognitive_services_endpoint = config.embeddings.llm.cognitive_services_endpoint
    print(f"creating embedding llm client with {llm_debug_info}")
    return OpenAIEmbedding(
        api_key=config.embeddings.llm.api_key,
        azure_ad_token_provider=(
            get_bearer_token_provider(
                DefaultAzureCredential(), cognitive_services_endpoint
            )
            if is_azure_client and not config.embeddings.llm.api_key
            else None
        ),
        api_base=config.embeddings.llm.api_base,
        organization=config.llm.organization,
        api_type=OpenaiApiType.AzureOpenAI if is_azure_client else OpenaiApiType.OpenAI,
        model=config.embeddings.llm.model,
        deployment_name=config.embeddings.llm.deployment_name,
        api_version=config.embeddings.llm.api_version,
        max_retries=config.embeddings.llm.max_retries,
    )
```

This function follows a similar pattern to the LLM client factory, but it's specifically tailored for text embedding services. It demonstrates how the factory pattern can be applied consistently across different types of objects.

#### 1.2.3 Search Engine Factories

The `factories.py` file also includes functions for creating search engines, such as `get_local_search_engine` and `get_global_search_engine`. These functions encapsulate the complex logic of setting up search engines with the appropriate components and configurations.

For example, the `get_local_search_engine` function might look like this:

```python
def get_local_search_engine(
    config: GraphRagConfig,
    reports: list[CommunityReport],
    text_units: list[TextUnit],
    entities: list[Entity],
    relationships: list[Relationship],
    covariates: dict[str, list[Covariate]],
    response_type: str,
    description_embedding_store: BaseVectorStore,
) -> BaseSearch:
    """Create a local search engine based on data + configuration."""
    llm = get_llm(config)
    text_embedder = get_text_embedder(config)
    token_encoder = tiktoken.get_encoding(config.encoding_model)

    ls_config = config.local_search

    return LocalSearch(
        llm=llm,
        context_builder=LocalSearchMixedContext(
            community_reports=reports,
            text_units=text_units,
            entities=entities,
            relationships=relationships,
            covariates=covariates,
            entity_text_embeddings=description_embedding_store,
            embedding_vectorstore_key=EntityVectorStoreKey.ID,
            text_embedder=text_embedder,
            token_encoder=token_encoder,
        ),
        token_encoder=token_encoder,
        llm_params={
            "max_tokens": ls_config.llm_max_tokens,
            "temperature": ls_config.temperature,
            "top_p": ls_config.top_p,
            "n": ls_config.n,
        },
        context_builder_params={
            "text_unit_prop": ls_config.text_unit_prop,
            "community_prop": ls_config.community_prop,
            "conversation_history_max_turns": ls_config.conversation_history_max_turns,
            "conversation_history_user_turns_only": True,
            "top_k_mapped_entities": ls_config.top_k_entities,
            "top_k_relationships": ls_config.top_k_relationships,
            "include_entity_rank": True,
            "include_relationship_weight": True,
            "include_community_rank": False,
            "return_candidate_context": False,
            "embedding_vectorstore_key": EntityVectorStoreKey.ID,
            "max_tokens": ls_config.max_tokens,
        },
        response_type=response_type,
    )
```

This function demonstrates how the factory pattern can be used to create complex objects with multiple dependencies. It uses other factory functions (like `get_llm` and `get_text_embedder`) to create sub-components, and then assembles these into a complete search engine object.

## 2. Understanding the Factory Pattern in Python and Its Benefits

The factory pattern is a creational design pattern that provides an interface for creating objects in a superclass, but allows subclasses to alter the type of objects that will be created. In Python, this is often implemented using factory functions or factory methods.

### 2.1 Key Concepts of the Factory Pattern

1. **Abstraction**: The factory pattern abstracts the object creation process, allowing the client code to work with generic interfaces rather than specific implementations.

2. **Encapsulation**: The complex logic of object creation is encapsulated within the factory, keeping the client code clean and focused on using the objects rather than creating them.

3. **Flexibility**: Factories can create different types of objects based on input parameters or configuration, allowing for runtime flexibility.

4. **Centralization**: By centralizing object creation in factories, it's easier to manage dependencies and make changes to the creation process across the entire application.

### 2.2 Benefits in the Context of GraphRAG

In GraphRAG, the factory pattern offers several specific benefits:

1. **Configuration Management**: Factories in GraphRAG take configuration objects as input, allowing for flexible setup of components based on user preferences or environmental factors.

2. **Dependency Injection**: The factories manage the creation and injection of dependencies (like LLM clients, embedders, and token encoders) into complex objects like search engines.

3. **Abstraction of Provider-Specific Details**: The factories handle the differences between providers (e.g., OpenAI vs. Azure) internally, presenting a consistent interface to the rest of the application.

4. **Easier Testing**: By centralizing object creation in factories, it's easier to mock or substitute components for testing purposes.

5. **Future Extensibility**: New types of LLMs, embedding services, or search engines can be added by extending the existing factory functions, without requiring changes to the client code.

## 3. Creating LLM (Language Model) and Embedding Clients Step-by-Step

The creation of LLM and embedding clients in GraphRAG involves several steps, carefully managed by the factory functions. Let's break down this process:

### 3.1 LLM Client Creation

1. **Configuration Parsing**: The factory function starts by parsing the configuration object to determine the type of LLM client to create (e.g., OpenAI or Azure).

2. **API Key Management**: The function handles API keys, ensuring they are properly set while also protecting sensitive information in debug output.

3. **Endpoint Configuration**: For Azure clients, the function sets up the appropriate cognitive services endpoint.

4. **Client Instantiation**: The function creates an instance of the appropriate client class (e.g., `ChatOpenAI`), passing in all necessary configuration parameters.

5. **Authentication Setup**: For Azure clients, the function sets up Azure AD token providers if necessary.

6. **Parameter Configuration**: The function sets various parameters like the model name, API version, and timeout settings based on the configuration.

### 3.2 Embedding Client Creation

The process for creating embedding clients follows a similar pattern to LLM client creation, with a few key differences:

1. **Embedding-Specific Configuration**: The function uses embedding-specific configuration settings, which may differ from the main LLM settings.

2. **Model Selection**: Embedding clients often use different models than chat or completion LLMs, so the function ensures the correct model is selected.

3. **Vectorization Setup**: The function may set up additional parameters related to text vectorization and embedding dimensionality.

## 4. Configuration Management Using Pydantic Models: Deep Dive

GraphRAG uses Pydantic models for configuration management, which provides several advantages in terms of data validation, serialization, and IDE support. Let's explore this in more detail:

### 4.1 Pydantic Model Structure

The configuration in GraphRAG is likely structured as a hierarchy of Pydantic models. For example:

```python
from pydantic import BaseModel, Field

class LLMConfig(BaseModel):
    api_key: str
    model: str
    max_tokens: int = Field(default=100)
    temperature: float = Field(default=0.7)

class EmbeddingConfig(BaseModel):
    model: str
    dimension: int = Field(default=1536)

class GraphRagConfig(BaseModel):
    llm: LLMConfig
    embedding: EmbeddingConfig
    max_search_results: int = Field(default=10)
```

This structure allows for nested configuration with type checking and default values.

### 4.2 Advantages of Pydantic Models

1. **Type Checking**: Pydantic performs runtime type checking, catching configuration errors early.

2. **Default Values**: Fields can have default values, making configuration files more concise.

3. **Validation**: Custom validators can be added to ensure configuration values meet specific criteria.

4. **Serialization**: Pydantic models can be easily serialized to and deserialized from JSON, YAML, or other formats.

5. **IDE Support**: IDEs can provide autocomplete and type hints based on the Pydantic model structure.

### 4.3 Usage in Factory Functions

In the factory functions, Pydantic models are used to access configuration values in a type-safe manner:

```python
def get_llm(config: GraphRagConfig) -> ChatOpenAI:
    return ChatOpenAI(
        api_key=config.llm.api_key,
        model=config.llm.model,
        max_tokens=config.llm.max_tokens,
        temperature=config.llm.temperature,
    )
```

This approach ensures that all configuration values are accessed correctly and have the expected types.

## 5. Handling API Keys and Credentials Securely Across Platforms (Continued)

### 5.1 Environment Variables

GraphRAG likely uses environment variables for sensitive information:

```python
import os

api_key = os.environ.get('GRAPHRAG_API_KEY')
```

This approach allows for secure storage of credentials outside of the codebase and easy configuration in different environments.

### 5.2 Configuration Files

For less sensitive information, GraphRAG may use configuration files (e.g., YAML or JSON) that can be easily modified without changing the code. These files should not be included in version control if they contain any sensitive information.

### 5.3 Secure Storage Services

For production environments, GraphRAG might integrate with secure storage services like Azure Key Vault or AWS Secrets Manager. These services provide an additional layer of security and access control.

### 5.4 Credential Providers

For cloud-based deployments, GraphRAG may use credential providers specific to the platform, such as DefaultAzureCredential for Azure services:

```python
from azure.identity import DefaultAzureCredential

credential = DefaultAzureCredential()
```

This approach allows for seamless integration with cloud platform authentication mechanisms.

## 6. Implementing Flexible and Extensible Factory Methods

The factory methods in GraphRAG are designed to be flexible and extensible. Here are some strategies employed:

### 6.1 Configuration-Driven Creation

Factory methods take configuration objects as parameters, allowing for dynamic object creation based on user preferences:

```python
def create_search_engine(config: SearchConfig) -> BaseSearchEngine:
    if config.engine_type == "local":
        return LocalSearchEngine(config)
    elif config.engine_type == "global":
        return GlobalSearchEngine(config)
    else:
        raise ValueError(f"Unknown search engine type: {config.engine_type}")
```

This approach allows new types of search engines to be added by extending the configuration and the factory method, without changing the calling code.

### 6.2 Dependency Injection

Factories manage the creation and injection of dependencies, promoting loose coupling:

```python
def create_search_engine(config: SearchConfig, llm: BaseLLM, embedder: BaseEmbedder) -> BaseSearchEngine:
    engine = get_engine_class(config.engine_type)(config)
    engine.set_llm(llm)
    engine.set_embedder(embedder)
    return engine
```

This allows for easier testing and the ability to swap out components.

### 6.3 Abstract Base Classes

Using abstract base classes for the created objects ensures that all implementations adhere to a common interface:

```python
from abc import ABC, abstractmethod

class BaseSearchEngine(ABC):
    @abstractmethod
    def search(self, query: str) -> List[SearchResult]:
        pass

class LocalSearchEngine(BaseSearchEngine):
    def search(self, query: str) -> List[SearchResult]:
        # Implementation...

class GlobalSearchEngine(BaseSearchEngine):
    def search(self, query: str) -> List[SearchResult]:
        # Implementation...
```

This approach provides a clear contract for new implementations and allows for polymorphic usage of the created objects.

## 7. Cross-platform Considerations in Configuration Management

GraphRAG's configuration management system needs to work across different platforms. Here are some considerations:

### 7.1 Path Handling

Use `pathlib` for cross-platform path handling:

```python
from pathlib import Path

config_path = Path(config_dir) / "config.yaml"
```

This ensures that file paths are correctly formatted for the current operating system.

### 7.2 Environment-Specific Configuration

Implement a mechanism to load different configuration files based on the environment:

```python
def load_config(env: str) -> GraphRagConfig:
    config_path = Path(f"config_{env.lower()}.yaml")
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file for environment '{env}' not found")
    # Load and parse the configuration file...
```

This allows for easy switching between development, testing, and production configurations.

### 7.3 Default Configurations

Provide sensible default configurations that work across platforms, allowing users to override only the necessary values:

```python
class GraphRagConfig(BaseModel):
    temp_dir: str = Field(default_factory=lambda: str(Path.home() / "graphrag_temp"))
    max_threads: int = Field(default_factory=lambda: os.cpu_count() or 1)
    # Other configuration fields...
```

This approach ensures that GraphRAG can run with minimal configuration while still allowing for customization.

## Review Questions

1. Explain the role of the factory pattern in GraphRAG's architecture. How does it contribute to the system's flexibility and maintainability?

2. Describe the process of creating an LLM client using the factory method in GraphRAG. What key steps are involved, and how does the factory handle different LLM providers?

3. How does GraphRAG use Pydantic models for configuration management? What advantages does this approach offer over simple dictionary-based configurations?

4. Discuss the strategies employed by GraphRAG for secure handling of API keys and credentials across different platforms. Why is this important in a configurable system like GraphRAG?

5. Explain how GraphRAG's factory methods are designed to be extensible. How might you add support for a new type of search engine or LLM provider?

6. Describe the cross-platform considerations in GraphRAG's configuration management. How does the system ensure consistent behavior across different operating systems?

7. How does dependency injection, as implemented in GraphRAG's factory methods, contribute to the system's modularity and testability?

## Hands-on Exercise

To gain practical experience with factory patterns and configuration management in the context of GraphRAG, complete the following exercise:

1. Create a simplified version of GraphRAG's configuration system using Pydantic models. Include configurations for LLM settings, embedding settings, and search engine settings.

2. Implement factory functions for creating LLM clients and search engines based on your configuration models.

3. Add support for at least two different LLM providers (e.g., OpenAI and a mock provider) in your factory functions.

4. Implement a mechanism for loading configuration from both YAML files and environment variables, with environment variables taking precedence.

5. Create a simple CLI that uses your configuration and factory systems to set up and run a basic search operation.

6. Write unit tests for your factory functions, including tests for different configuration scenarios and error cases.

7. Document your implementation, explaining how it mirrors GraphRAG's approach to factory patterns and configuration management, and any challenges you encountered.

This exercise will give you hands-on experience with the key concepts of factory patterns and configuration management as used in GraphRAG, helping you understand the practical considerations involved in building a flexible and configurable system.

