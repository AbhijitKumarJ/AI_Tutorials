# Lesson 7: Data Processing Pipelines in GraphRAG

## Introduction

In this lesson, we'll explore the data processing pipelines that form the backbone of GraphRAG's functionality. These pipelines orchestrate the flow of data through various stages of processing, from raw input to refined graph structures and analysis results. We'll delve into how GraphRAG implements these pipelines, the components that make them up, and how they tie together the various operations we've discussed in previous lessons.

## File Structure

Before we dive into the details, let's examine the relevant file structure for data processing pipelines in GraphRAG:

```
graphrag/
├── index/
│   ├── __init__.py
│   ├── config/
│   │   ├── __init__.py
│   │   ├── pipeline.py
│   │   └── workflow.py
│   ├── context.py
│   ├── run/
│   │   ├── __init__.py
│   │   ├── cache.py
│   │   ├── postprocess.py
│   │   ├── profiling.py
│   │   ├── run.py
│   │   ├── utils.py
│   │   └── workflow.py
│   ├── workflows/
│   │   ├── __init__.py
│   │   ├── default_workflows.py
│   │   ├── load.py
│   │   └── typing.py
│   │   └── v1/
│   │       ├── __init__.py
│   │       ├── create_base_documents.py
│   │       ├── create_base_entity_graph.py
│   │       ├── create_base_extracted_entities.py
│   │       ├── create_base_text_units.py
│   │       ├── create_final_communities.py
│   │       ├── create_final_community_reports.py
│   │       ├── create_final_covariates.py
│   │       ├── create_final_documents.py
│   │       ├── create_final_entities.py
│   │       ├── create_final_nodes.py
│   │       ├── create_final_relationships.py
│   │       ├── create_final_text_units.py
│   │       └── create_summarized_entities.py
├── api/
│   ├── __init__.py
│   └── index_api.py
```

This structure shows the organization of pipeline-related code in GraphRAG. The `index/` directory contains the core components of the pipeline system, including configuration, runtime context, and workflow definitions.

## Pipeline Architecture Overview

GraphRAG's pipeline architecture is designed to be flexible, extensible, and efficient. It allows for the definition of complex data processing workflows that can be easily configured and executed. The key components of this architecture include:

1. **Pipeline Configuration**: Defined in `index/config/pipeline.py`, this component specifies the structure and parameters of the pipeline.

2. **Workflows**: Individual processing steps or sub-pipelines, defined in the `index/workflows/` directory.

3. **Runtime Context**: Managed by `index/context.py`, this provides the execution environment for the pipeline.

4. **Execution Engine**: Implemented in `index/run/run.py`, this orchestrates the execution of the pipeline.

Let's explore each of these components in detail.

## Pipeline Configuration

The pipeline configuration is central to defining how data will be processed in GraphRAG. The `PipelineConfig` class in `index/config/pipeline.py` encapsulates this configuration:

```python
from pydantic import BaseModel, Field

class PipelineConfig(BaseModel):
    extends: list[str] | str | None = Field(
        description="Extends another pipeline configuration", default=None
    )
    input: PipelineInputConfigTypes | None = Field(default=None, discriminator="file_type")
    reporting: PipelineReportingConfigTypes | None = Field(default=None, discriminator="type")
    storage: PipelineStorageConfigTypes | None = Field(default=None, discriminator="type")
    cache: PipelineCacheConfigTypes | None = Field(default=None, discriminator="type")
    root_dir: str | None = Field(
        description="The root directory for the pipeline. All other paths will be based on this root_dir.",
        default=None,
    )
    workflows: list[PipelineWorkflowReference] = Field(
        description="The workflows for the pipeline.", default_factory=list
    )
```

This configuration allows for:
- Extending other pipeline configurations, enabling modular and reusable pipeline definitions.
- Specifying input sources, reporting methods, storage backends, and caching strategies.
- Defining a root directory for all pipeline operations.
- Listing the workflows that make up the pipeline.

The use of Pydantic for configuration management ensures type safety and allows for easy validation of configuration parameters.

## Workflows

Workflows are the building blocks of GraphRAG's pipelines. Each workflow represents a specific data processing task or a series of related tasks. Workflows are defined in the `index/workflows/v1/` directory, with each file typically corresponding to a specific stage in the overall pipeline.

Let's examine the structure of a typical workflow, using `create_base_documents.py` as an example:

```python
from datashaper import DEFAULT_INPUT_NAME
from graphrag.index.config import PipelineWorkflowConfig, PipelineWorkflowStep

workflow_name = "create_base_documents"

def build_steps(
    config: PipelineWorkflowConfig,
) -> list[PipelineWorkflowStep]:
    """
    Create the documents table.

    ## Dependencies
    * `workflow:create_final_text_units`
    """
    document_attribute_columns = config.get("document_attribute_columns", [])
    return [
        {
            "verb": "create_base_documents",
            "args": {
                "document_attribute_columns": document_attribute_columns,
            },
            "input": {
                "source": DEFAULT_INPUT_NAME,
                "text_units": "workflow:create_final_text_units",
            },
        },
    ]
```

Key points about workflows:
- Each workflow is defined by a `build_steps` function that returns a list of `PipelineWorkflowStep` objects.
- Workflows can specify dependencies on other workflows, allowing for complex processing chains.
- Workflows are configurable, with parameters passed via the `config` argument.
- The actual processing logic is encapsulated in "verbs" (like `create_base_documents`), which are registered separately and invoked by the workflow.

## Runtime Context

The runtime context, defined in `index/context.py`, provides the execution environment for the pipeline:

```python
from dataclasses import dataclass, field

@dataclass
class PipelineRunStats:
    total_runtime: float = field(default=0)
    num_documents: int = field(default=0)
    input_load_time: float = field(default=0)
    workflows: dict[str, dict[str, float]] = field(default_factory=dict)

@dataclass
class PipelineRunContext:
    stats: PipelineRunStats
    storage: PipelineStorage
    cache: PipelineCache
```

The context includes:
- Runtime statistics for profiling and monitoring.
- References to storage and cache implementations, allowing workflows to persist and retrieve data.

This context is passed to each workflow during execution, ensuring that all parts of the pipeline have access to the necessary resources and can contribute to overall statistics.

## Execution Engine

The heart of GraphRAG's pipeline system is the execution engine, implemented primarily in `index/run/run.py`. The main entry point is the `run_pipeline` function:

```python
async def run_pipeline(
    workflows: list[PipelineWorkflowReference],
    dataset: pd.DataFrame,
    storage: PipelineStorage | None = None,
    cache: PipelineCache | None = None,
    callbacks: WorkflowCallbacks | None = None,
    progress_reporter: ProgressReporter | None = None,
    input_post_process_steps: list[PipelineWorkflowStep] | None = None,
    additional_verbs: VerbDefinitions | None = None,
    additional_workflows: WorkflowDefinitions | None = None,
    emit: list[TableEmitterType] | None = None,
    memory_profile: bool = False,
    is_resume_run: bool = False,
    **_kwargs: dict,
) -> AsyncIterable[PipelineRunResult]:
    # ... (implementation details)
```

Key features of the execution engine:
- Asynchronous execution, allowing for efficient processing of large datasets or complex workflows.
- Support for resuming interrupted runs, enhancing reliability for long-running processes.
- Extensibility through additional verbs and workflows, enabling customization of the pipeline.
- Built-in memory profiling for performance analysis.
- Progress reporting and callback mechanisms for monitoring and logging.

The execution engine performs the following high-level steps:
1. Initialize the runtime context, including storage and cache.
2. Load and prepare the input dataset.
3. Execute each workflow in the defined order, respecting dependencies.
4. Collect and emit results from each workflow.
5. Perform post-processing and cleanup.

## Error Handling and Logging

Robust error handling and logging are crucial for managing complex pipelines. GraphRAG implements these in several layers:

1. **Workflow-level error handling**: Each workflow can define its own error handling logic, allowing for graceful degradation of the pipeline.

2. **Global error callbacks**: The `WorkflowCallbacks` interface, typically implemented by `ConsoleWorkflowCallbacks`, provides methods for logging errors and progress across the entire pipeline.

3. **Structured logging**: GraphRAG uses Python's built-in `logging` module, configured to provide detailed information about each stage of pipeline execution.

Here's an example of how errors are handled in the `run_pipeline` function:

```python
try:
    await _dump_stats(context.stats, context.storage)
    for workflow_to_run in workflows_to_run:
        # ... (workflow execution code)
        result = await _process_workflow(
            workflow_to_run.workflow,
            context,
            callbacks,
            emitters,
            workflow_dependencies,
            dataset,
            start_time,
            is_resume_run,
        )
        if result:
            yield result
except Exception as e:
    log.exception("error running workflow %s", last_workflow)
    cast(WorkflowCallbacks, callbacks).on_error(
        "Error running pipeline!", e, traceback.format_exc()
    )
    yield PipelineRunResult(last_workflow, None, [e])
```

This approach ensures that errors are caught, logged, and propagated appropriately, allowing for graceful failure handling and detailed debugging information.

## Pipeline Customization and Extension

GraphRAG's pipeline architecture is designed for extensibility. There are several ways to customize and extend the pipeline:

1. **Custom Workflows**: New workflows can be defined by creating new files in the `index/workflows/v1/` directory and implementing the `build_steps` function.

2. **Custom Verbs**: The pipeline can be extended with new processing operations by implementing custom verbs and registering them with the system.

3. **Configuration Overrides**: The `PipelineConfig` allows for overriding default settings, enabling fine-tuned control over pipeline behavior without changing the code.

4. **Middleware Injection**: The callback system allows for injecting custom logic at various points in the pipeline execution, enabling features like custom logging or monitoring.

## Practical Exercise

Let's create a practical exercise that demonstrates how to define and run a simple pipeline in GraphRAG:

```python
import asyncio
import pandas as pd
from graphrag.index.config import PipelineConfig, PipelineWorkflowReference
from graphrag.index.run.run import run_pipeline
from graphrag.index.storage import MemoryPipelineStorage
from graphrag.index.cache import InMemoryCache

# Define a simple custom workflow
def custom_workflow(config):
    return [
        {
            "verb": "custom_operation",
            "args": {"multiply_by": config.get("multiply_by", 2)},
            "input": {"source": "input_data"},
        }
    ]

# Register the custom workflow
custom_workflows = {
    "custom_workflow": custom_workflow
}

# Define a custom verb
def custom_operation(input_data, multiply_by):
    return input_data * multiply_by

custom_verbs = {
    "custom_operation": custom_operation
}

# Create a sample dataset
data = pd.DataFrame({"value": [1, 2, 3, 4, 5]})

# Define the pipeline configuration
config = PipelineConfig(
    workflows=[
        PipelineWorkflowReference(name="custom_workflow", config={"multiply_by": 3})
    ]
)

async def run_custom_pipeline():
    results = []
    async for result in run_pipeline(
        config.workflows,
        data,
        storage=MemoryPipelineStorage(),
        cache=InMemoryCache(),
        additional_workflows=custom_workflows,
        additional_verbs=custom_verbs
    ):
        results.append(result)
    
    return results

# Run the pipeline
results = asyncio.run(run_custom_pipeline())

# Print the results
for result in results:
    print(f"Workflow: {result.workflow}")
    print(result.result)
```

This exercise demonstrates:
1. Defining a custom workflow and verb.
2. Creating a pipeline configuration.
3. Running the pipeline with custom components.
4. Processing and displaying the results.

## Review Questions

1. What are the key components of GraphRAG's pipeline architecture, and how do they interact?
2. How does the `PipelineConfig` class contribute to the flexibility of GraphRAG's pipeline system?
3. Describe the structure of a workflow in GraphRAG. How are dependencies between workflows managed?
4. What is the purpose of the runtime context in pipeline execution?
5. How does GraphRAG's execution engine handle asynchronous processing and error management?
6. What methods are available for extending and customizing the pipeline system in GraphRAG?
7. How does GraphRAG handle logging and error reporting throughout the pipeline execution?
8. Describe a real-world scenario where the pipeline architecture of GraphRAG would be particularly beneficial.

## Conclusion

In this lesson, we've explored the sophisticated data processing pipeline architecture of GraphRAG. We've seen how this system combines flexibility, extensibility, and robustness to enable complex data processing workflows.

The pipeline architecture ties together all the components we've discussed in previous lessons - from graph operations to LLM integrations - into a cohesive system for knowledge extraction and analysis. This architecture allows GraphRAG to handle diverse data processing tasks while maintaining modularity and configurability.

Understanding this pipeline system is crucial for effectively using GraphRAG, as it provides the framework within which all other operations occur. In our next lesson, we'll dive deeper into the caching and storage strategies employed by GraphRAG, which play a critical role in optimizing the performance of these pipelines.

