# Lesson 11: Community Detection and Summarization in GraphRAG

## Introduction

In this lesson, we'll dive deep into the community detection and summarization features of GraphRAG. These features are crucial for understanding the structure of large graphs and extracting meaningful insights from them. We'll explore the implementation details, algorithms used, and how to customize these processes for different use cases.

## 1. Community Detection Algorithms in GraphRAG

GraphRAG implements community detection using the Leiden algorithm, which is an improvement over the popular Louvain method. The Leiden algorithm is known for its ability to find high-quality partitions of large networks more efficiently than other methods.

### Implementation Details

The community detection is primarily implemented in the `cluster_graph` function within the `operations/cluster_graph.py` file. Let's examine the file structure and key components:

```
graphrag/
└── index/
    └── operations/
        └── cluster_graph.py
```

The `cluster_graph.py` file contains several important functions:

1. `cluster_graph`: This is the main function that applies the hierarchical clustering algorithm to a graph.
2. `apply_clustering`: This function applies the clustering results to a graph, assigning community labels to nodes.
3. `run_layout`: This function orchestrates the layout process, including the clustering step.
4. `run_leiden`: This function performs the actual Leiden algorithm for community detection.

Let's look at a simplified version of the `run_leiden` function:

```python
def run_leiden(graph: nx.Graph, args: dict[str, Any]) -> dict[int, dict[str, list[str]]]:
    max_cluster_size = args.get("max_cluster_size", 10)
    use_lcc = args.get("use_lcc", True)
    
    if use_lcc:
        graph = stable_largest_connected_component(graph)
    
    node_id_to_community_map = _compute_leiden_communities(
        graph=graph,
        max_cluster_size=max_cluster_size,
        use_lcc=use_lcc,
        seed=args.get("seed", 0xDEADBEEF),
    )
    
    # Process and format the results
    results_by_level = {}
    for level in sorted(node_id_to_community_map.keys()):
        result = {}
        results_by_level[level] = result
        for node_id, raw_community_id in node_id_to_community_map[level].items():
            community_id = str(raw_community_id)
            if community_id not in result:
                result[community_id] = []
            result[community_id].append(node_id)
    
    return results_by_level
```

This function uses the `hierarchical_leiden` algorithm from the `graspologic` library to perform community detection. It then processes the results into a hierarchical structure, where each level represents a different granularity of community division.

### Customization Options

Users can customize the community detection process by adjusting several parameters:

1. `max_cluster_size`: This parameter controls the maximum size of communities. Larger values will result in fewer, larger communities.
2. `use_lcc`: When set to `True`, the algorithm will only consider the largest connected component of the graph.
3. `seed`: This parameter allows for reproducible results by setting a fixed random seed.

## 2. Implementation of Community Reporting

Once communities are detected, GraphRAG generates reports for each community. This process is implemented in the `create_final_community_reports.py` file within the `flows` directory. Let's examine its structure:

```
graphrag/
└── index/
    └── flows/
        └── create_final_community_reports.py
```

The main function in this file is `create_final_community_reports`, which orchestrates the entire process of generating community reports. Here's a simplified version of this function:

```python
async def create_final_community_reports(
    nodes_input: pd.DataFrame,
    edges_input: pd.DataFrame,
    claims_input: pd.DataFrame | None,
    callbacks: VerbCallbacks,
    cache: PipelineCache,
    summarization_strategy: dict,
    async_mode: AsyncType = AsyncType.AsyncIO,
    num_threads: int = 4,
    full_content_text_embed: dict | None = None,
    summary_text_embed: dict | None = None,
    title_text_embed: dict | None = None,
) -> pd.DataFrame:
    nodes = _prep_nodes(nodes_input)
    edges = _prep_edges(edges_input)
    claims = _prep_claims(claims_input) if claims_input is not None else None

    community_hierarchy = restore_community_hierarchy(nodes)

    local_contexts = prepare_community_reports(
        nodes,
        edges,
        claims,
        callbacks,
        summarization_strategy.get("max_input_length", 16_000),
    )

    community_reports = await summarize_communities(
        local_contexts,
        nodes,
        community_hierarchy,
        callbacks,
        cache,
        summarization_strategy,
        async_mode=async_mode,
        num_threads=num_threads,
    )

    community_reports["id"] = community_reports["community"].apply(lambda _x: str(uuid4()))

    # Embed full content, summary, and title if specified
    if full_content_text_embed:
        community_reports["full_content_embedding"] = await embed_text(
            community_reports,
            callbacks,
            cache,
            column="full_content",
            strategy=full_content_text_embed["strategy"],
            embedding_name="community_report_full_content",
        )

    if summary_text_embed:
        community_reports["summary_embedding"] = await embed_text(
            community_reports,
            callbacks,
            cache,
            column="summary",
            strategy=summary_text_embed["strategy"],
            embedding_name="community_report_summary",
        )

    if title_text_embed:
        community_reports["title_embedding"] = await embed_text(
            community_reports,
            callbacks,
            cache,
            column="title",
            strategy=title_text_embed["strategy"],
            embedding_name="community_report_title",
        )

    return community_reports
```

This function performs several key steps:

1. Prepares the input data (nodes, edges, and claims).
2. Restores the community hierarchy.
3. Prepares the local contexts for each community.
4. Summarizes the communities using the provided summarization strategy.
5. Generates unique IDs for each community report.
6. Optionally embeds the full content, summary, and title of each community report.

## 3. Text Summarization Techniques for Entities and Communities

GraphRAG uses advanced text summarization techniques to generate concise and informative summaries for entities and communities. The summarization process is implemented in the `CommunityReportsExtractor` class within the `graph/extractors/community_reports/community_reports_extractor.py` file.

```
graphrag/
└── index/
    └── graph/
        └── extractors/
            └── community_reports/
                └── community_reports_extractor.py
```

The `CommunityReportsExtractor` class uses a Large Language Model (LLM) to generate summaries. Here's a simplified version of the `__call__` method:

```python
async def __call__(self, inputs: dict[str, Any]):
    try:
        response = await self._llm(
            self._extraction_prompt,
            json=True,
            name="create_community_report",
            variables={self._input_text_key: inputs[self._input_text_key]},
            is_response_valid=lambda x: dict_has_keys_with_types(
                x,
                [
                    ("title", str),
                    ("summary", str),
                    ("findings", list),
                    ("rating", float),
                    ("rating_explanation", str),
                ],
                inplace=True,
            ),
            model_parameters={"max_tokens": self._max_report_length},
        )
        output = response.json or {}
    except Exception as e:
        log.exception("error generating community report")
        self._on_error(e, traceback.format_exc(), None)
        output = {}

    text_output = self._get_text_output(output)
    return CommunityReportsResult(
        structured_output=output,
        output=text_output,
    )
```

This method sends a prompt to the LLM, which generates a structured report containing a title, summary, findings, rating, and rating explanation. The method then processes this output into both a structured format and a text format.

## 4. Customizing Summarization Strategies

Users can customize the summarization process by modifying the prompt used for summarization and adjusting various parameters. The prompt is defined in the `COMMUNITY_REPORT_PROMPT` constant within the `graph/extractors/community_reports/prompts.py` file.

```
graphrag/
└── index/
    └── graph/
        └── extractors/
            └── community_reports/
                └── prompts.py
```

Here's a snippet of the prompt:

```python
COMMUNITY_REPORT_PROMPT = """
You are an AI assistant that helps a human analyst to perform general information discovery. Information discovery is the process of identifying and assessing relevant information associated with certain entities (e.g., organizations and individuals) within a network.

# Goal
Write a comprehensive report of a community, given a list of entities that belong to the community as well as their relationships and optional associated claims. The report will be used to inform decision-makers about information associated with the community and their potential impact. The content of this report includes an overview of the community's key entities, their legal compliance, technical capabilities, reputation, and noteworthy claims.

# Report Structure

The report should include the following sections:

- TITLE: community's name that represents its key entities - title should be short but specific. When possible, include representative named entities in the title.
- SUMMARY: An executive summary of the community's overall structure, how its entities are related to each other, and significant information associated with its entities.
- IMPACT SEVERITY RATING: a float score between 0-10 that represents the severity of IMPACT posed by entities within the community.  IMPACT is the scored importance of a community.
- RATING EXPLANATION: Give a single sentence explanation of the IMPACT severity rating.
- DETAILED FINDINGS: A list of 5-10 key insights about the community. Each insight should have a short summary followed by multiple paragraphs of explanatory text grounded according to the grounding rules below. Be comprehensive.

...
"""
```

Users can modify this prompt to change the structure and content of the generated reports. Additionally, they can adjust parameters such as `max_report_length` in the `CommunityReportsExtractor` constructor to control the length of the generated reports.

## Conclusion

In this lesson, we've explored the community detection and summarization features of GraphRAG in depth. We've seen how the Leiden algorithm is used for community detection, how community reports are generated using advanced LLM-based summarization techniques, and how users can customize these processes to suit their specific needs.

These features allow GraphRAG to extract meaningful insights from large, complex graphs, providing users with a powerful tool for network analysis and information discovery. In the next lesson, we'll dive into embedding and vector operations, which play a crucial role in many of GraphRAG's advanced features.

## Exercises

1. Implement a custom community detection algorithm and integrate it into GraphRAG's `cluster_graph.py` file.
2. Modify the `COMMUNITY_REPORT_PROMPT` to generate reports focused on a specific domain (e.g., financial networks, social media analysis).
3. Experiment with different `max_cluster_size` values in the Leiden algorithm and observe how it affects the resulting community structure.
4. Implement a new metric for community importance and integrate it into the community reporting process.
5. Create a visualization tool that displays the hierarchical community structure generated by GraphRAG.

## Review Questions

1. How does the Leiden algorithm improve upon the Louvain method for community detection?
2. What are the key components of a community report generated by GraphRAG?
3. How does GraphRAG handle hierarchical community structures?
4. What role does the LLM play in the community summarization process?
5. How can users customize the community detection and summarization processes in GraphRAG?

By mastering these concepts and techniques, you'll be well-equipped to leverage GraphRAG's powerful community detection and summarization features in your own projects, enabling deep insights into complex network structures.
