# Lesson 17: Advanced Features and Customization in GraphRAG

## Introduction

Welcome to Lesson 17 of our GraphRAG course. In this lesson, we'll dive deep into the advanced features and customization options available in GraphRAG. We'll explore how to extend the functionality of GraphRAG by implementing custom verbs and workflows, extending entity types and relationship detection, integrating additional language models, and developing plugins or extensions. This knowledge will empower you to tailor GraphRAG to your specific needs and use cases.

## Table of Contents

1. Implementing Custom Verbs and Workflows
2. Extending Entity Types and Relationship Detection
3. Integrating Additional LLMs or Embedding Models
4. Developing Plugins or Extensions for GraphRAG

## 1. Implementing Custom Verbs and Workflows

GraphRAG's flexibility allows you to implement custom verbs and workflows to extend its functionality. Let's explore how to do this effectively.

### 1.1 Custom Verbs

Custom verbs are the building blocks of GraphRAG's workflows. They allow you to define new operations that can be used in your data processing pipelines. To implement a custom verb, follow these steps:

1. Create a new Python file in the appropriate directory (e.g., `graphrag/index/operations/custom_verbs.py`).
2. Define your custom verb as a function decorated with the `@verb` decorator.
3. Implement the logic of your custom verb.

Here's an example of a custom verb that performs sentiment analysis on text:

```python
from datashaper import VerbInput, verb
from datashaper.table_store.types import VerbResult, create_verb_result
import pandas as pd
from typing import cast
from textblob import TextBlob

@verb(name="sentiment_analysis", treats_input_tables_as_immutable=True)
def sentiment_analysis(
    input: VerbInput,
    text_column: str,
    **_kwargs: dict
) -> VerbResult:
    """Perform sentiment analysis on the specified text column."""
    df = cast(pd.DataFrame, input.get_input())
    
    def get_sentiment(text):
        return TextBlob(text).sentiment.polarity
    
    df['sentiment'] = df[text_column].apply(get_sentiment)
    
    return create_verb_result(cast(Table, df))
```

This custom verb uses the TextBlob library to perform sentiment analysis on a specified text column and adds a new 'sentiment' column to the DataFrame.

### 1.2 Custom Workflows

Custom workflows allow you to define new sequences of operations that can be used in your GraphRAG pipelines. To implement a custom workflow:

1. Create a new Python file in the `graphrag/index/workflows/` directory (e.g., `graphrag/index/workflows/custom_workflows.py`).
2. Define your custom workflow as a function that returns a list of workflow steps.

Here's an example of a custom workflow that incorporates the sentiment analysis verb we just created:

```python
from graphrag.index.config import PipelineWorkflowConfig, PipelineWorkflowStep

def sentiment_analysis_workflow(
    config: PipelineWorkflowConfig,
) -> list[PipelineWorkflowStep]:
    """
    Custom workflow for sentiment analysis.
    
    Dependencies:
    * `workflow:create_final_text_units`
    """
    text_column = config.get("text_column", "text")
    
    return [
        {
            "verb": "sentiment_analysis",
            "args": {
                "text_column": text_column,
            },
            "input": {"source": "workflow:create_final_text_units"},
        },
    ]
```

To use this custom workflow, you would add it to your GraphRAG configuration:

```yaml
workflows:
  - name: sentiment_analysis_workflow
    config:
      text_column: "text"
```

By implementing custom verbs and workflows, you can extend GraphRAG's capabilities to suit your specific data processing needs.

## 2. Extending Entity Types and Relationship Detection

GraphRAG's entity extraction and relationship detection can be customized to work with domain-specific entity types and relationships. Let's explore how to extend these features.

### 2.1 Extending Entity Types

To add new entity types:

1. Modify the `DEFAULT_ENTITY_TYPES` list in `graphrag/index/operations/extract_entities/extract_entities.py`:

```python
DEFAULT_ENTITY_TYPES = ["organization", "person", "geo", "event", "product", "technology"]
```

2. Update the entity extraction prompt in `graphrag/index/graph/extractors/graph/prompts.py` to include the new entity types:

```python
GRAPH_EXTRACTION_PROMPT = """
...
1. Identify all entities. For each identified entity, extract the following information:
- entity_name: Name of the entity, capitalized
- entity_type: One of the following types: [{entity_types}]
...
"""
```

3. Modify the entity extraction strategy to handle the new entity types. For example, if using the `graph_intelligence` strategy, update the `run_graph_intelligence` function in `graphrag/index/operations/extract_entities/strategies/graph_intelligence.py`:

```python
async def run_graph_intelligence(
    input: list[str],
    entity_types: list[str],
    callbacks: VerbCallbacks,
    cache: PipelineCache,
    args: StrategyConfig,
) -> EntityExtractionResult:
    # ... existing code ...
    
    # Add logic to handle new entity types
    for entity in extracted_entities:
        if entity['type'] in ['product', 'technology']:
            # Add custom processing for new entity types
            pass
    
    # ... rest of the function ...
```

### 2.2 Extending Relationship Detection

To improve relationship detection:

1. Modify the relationship extraction prompt in `graphrag/index/graph/extractors/graph/prompts.py`:

```python
GRAPH_EXTRACTION_PROMPT = """
...
2. From the entities identified in step 1, identify all pairs of (source_entity, target_entity) that are *clearly related* to each other.
For each pair of related entities, extract the following information:
- source_entity: name of the source entity, as identified in step 1
- target_entity: name of the target entity, as identified in step 1
- relationship_type: type of relationship (e.g., "owns", "works_for", "located_in", "uses")
- relationship_description: explanation as to why you think the source entity and the target entity are related to each other
- relationship_strength: a numeric score indicating strength of the relationship between the source entity and target entity
 Format each relationship as ("relationship"{tuple_delimiter}<source_entity>{tuple_delimiter}<target_entity>{tuple_delimiter}<relationship_type>{tuple_delimiter}<relationship_description>{tuple_delimiter}<relationship_strength>)
...
"""
```

2. Update the `GraphExtractor` class in `graphrag/index/graph/extractors/graph/graph_extractor.py` to handle the new relationship information:

```python
class GraphExtractor:
    # ... existing code ...
    
    def _parse_claim_tuples(self, claims: str, prompt_variables: dict) -> list[dict[str, Any]]:
        # ... existing code ...
        
        result.append({
            "source": clean_str(record_attributes[1].upper()),
            "target": clean_str(record_attributes[2].upper()),
            "relationship_type": clean_str(record_attributes[3]),
            "description": clean_str(record_attributes[4]),
            "weight": float(record_attributes[5]),
        })
        
        # ... rest of the method ...
```

By extending entity types and improving relationship detection, you can tailor GraphRAG to better understand and represent domain-specific knowledge graphs.

## 3. Integrating Additional LLMs or Embedding Models

GraphRAG's modular design allows for the integration of different language models and embedding models. Let's explore how to add support for a new LLM or embedding model.

### 3.1 Adding a New Language Model

To integrate a new language model:

1. Create a new file in the `graphrag/llm/` directory (e.g., `graphrag/llm/custom_llm.py`).
2. Implement a new class that inherits from `CompletionLLM` or `EmbeddingLLM`:

```python
from graphrag.llm.base.base_llm import CompletionLLM
from graphrag.llm.types.llm_invocation_result import LLMInvocationResult

class CustomLLM(CompletionLLM):
    def __init__(self, config: dict):
        # Initialize your custom LLM with necessary configuration
        self.model = CustomModel(config)
    
    async def __call__(
        self,
        prompt: str,
        variables: dict | None = None,
        json: bool = False,
        name: str | None = None,
        history: list[dict[str, Any]] | None = None,
        model_parameters: dict[str, Any] | None = None,
        is_response_valid: Callable[[dict], bool] | None = None,
    ) -> LLMInvocationResult:
        # Implement the logic to call your custom LLM
        response = self.model.generate(prompt)
        return LLMInvocationResult(output=response, json={}, history=[])
```

3. Update the `load_llm` function in `graphrag/index/llm/load_llm.py` to include your new LLM:

```python
def load_llm(
    name: str,
    llm_type: LLMType,
    callbacks: VerbCallbacks,
    cache: PipelineCache | None,
    llm_config: dict[str, Any] | None = None,
    chat_only=False,
) -> CompletionLLM:
    # ... existing code ...
    
    if llm_type == LLMType.CustomLLM:
        from graphrag.llm.custom_llm import CustomLLM
        return CustomLLM(llm_config or {})
    
    # ... rest of the function ...
```

### 3.2 Adding a New Embedding Model

To integrate a new embedding model:

1. Create a new file in the `graphrag/index/operations/embed_text/strategies/` directory (e.g., `custom_embedding.py`).
2. Implement a new embedding strategy:

```python
from graphrag.index.operations.embed_text.strategies.typing import TextEmbeddingResult, TextEmbeddingStrategy
from graphrag.index.cache import PipelineCache
from datashaper import VerbCallbacks

async def run_custom_embedding(
    input: list[str],
    callbacks: VerbCallbacks,
    cache: PipelineCache,
    args: dict[str, Any],
) -> TextEmbeddingResult:
    # Implement your custom embedding logic here
    custom_embedder = CustomEmbedder(args)
    embeddings = [custom_embedder.embed(text) for text in input]
    return TextEmbeddingResult(embeddings=embeddings)
```

3. Update the `load_strategy` function in `graphrag/index/operations/embed_text/embed_text.py`:

```python
def load_strategy(strategy: TextEmbedStrategyType) -> TextEmbeddingStrategy:
    """Load strategy method definition."""
    match strategy:
        # ... existing cases ...
        case TextEmbedStrategyType.custom:
            from .strategies.custom_embedding import run_custom_embedding
            return run_custom_embedding
        case _:
            msg = f"Unknown strategy: {strategy}"
            raise ValueError(msg)
```

4. Add your new embedding strategy to the `TextEmbedStrategyType` enum in the same file:

```python
class TextEmbedStrategyType(str, Enum):
    """TextEmbedStrategyType class definition."""
    openai = "openai"
    mock = "mock"
    custom = "custom"
```

By following these steps, you can integrate new language models and embedding models into GraphRAG, allowing for greater flexibility and customization in your NLP tasks.

## 4. Developing Plugins or Extensions for GraphRAG

To further extend GraphRAG's capabilities, you can develop plugins or extensions. This approach allows you to add new functionality without modifying the core codebase. Let's explore how to create a plugin system for GraphRAG.

### 4.1 Creating a Plugin Architecture

First, let's define a basic plugin architecture:

1. Create a new directory `graphrag/plugins/` to store plugins.
2. Create a base plugin class in `graphrag/plugins/base_plugin.py`:

```python
from abc import ABC, abstractmethod

class BasePlugin(ABC):
    @abstractmethod
    def initialize(self, config: dict):
        """Initialize the plugin with the given configuration."""
        pass

    @abstractmethod
    def get_verbs(self) -> dict:
        """Return a dictionary of custom verbs provided by this plugin."""
        pass

    @abstractmethod
    def get_workflows(self) -> dict:
        """Return a dictionary of custom workflows provided by this plugin."""
        pass
```

3. Implement a plugin loader in `graphrag/plugins/plugin_loader.py`:

```python
import importlib
import os
from typing import List
from graphrag.plugins.base_plugin import BasePlugin

def load_plugins(plugin_dir: str) -> List[BasePlugin]:
    plugins = []
    for filename in os.listdir(plugin_dir):
        if filename.endswith('.py') and not filename.startswith('__'):
            module_name = filename[:-3]
            module = importlib.import_module(f"graphrag.plugins.{module_name}")
            for item_name in dir(module):
                item = getattr(module, item_name)
                if isinstance(item, type) and issubclass(item, BasePlugin) and item is not BasePlugin:
                    plugins.append(item())
    return plugins
```

### 4.2 Implementing a Sample Plugin

Let's create a sample plugin that adds a custom verb for text classification:

1. Create a new file `graphrag/plugins/text_classification_plugin.py`:

```python
from graphrag.plugins.base_plugin import BasePlugin
from datashaper import VerbInput, verb
from datashaper.table_store.types import VerbResult, create_verb_result
import pandas as pd
from typing import cast
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

class TextClassificationPlugin(BasePlugin):
    def __init__(self):
        self.model = None

    def initialize(self, config: dict):
        self.model = Pipeline([
            ('tfidf', TfidfVectorizer()),
            ('clf', MultinomialNB()),
        ])

    def get_verbs(self) -> dict:
        return {
            "text_classification": self.text_classification_verb
        }

    def get_workflows(self) -> dict:
        return {
            "text_classification_workflow": self.text_classification_workflow
        }

    @verb(name="text_classification", treats_input_tables_as_immutable=True)
    def text_classification_verb(
        self,
        input: VerbInput,
        text_column: str,
        label_column: str,
        **_kwargs: dict
    ) -> VerbResult:
        df = cast(pd.DataFrame, input.get_input())
        
        # Train the model if it hasn't been trained yet
        if not hasattr(self.model, 'classes_'):
            self.model.fit(df[text_column], df[label_column])
        
        # Predict on the input data
        df['predicted_label'] = self.model.predict(df[text_column])
        
        return create_verb_result(cast(Table, df))

    def text_classification_workflow(self, config: dict) -> list[dict]:
        """
        Custom workflow for text classification.
        
        Dependencies:
        * `workflow:create_final_text_units`
        """
        text_column = config.get("text_column", "text")
        label_column = config.get("label_column", "label")
        
        return [
            {
                "verb": "text_classification",
                "args": {
                    "text_column": text_column,
                    "label_column": label_column,
                },
                "input": {"source": "workflow:create_final_text_units"},
            },
        ]

### 4.3 Integrating Plugins into GraphRAG

To integrate plugins into GraphRAG, we need to modify the main pipeline execution to load and use plugins. Here's how we can do this:

1. Update the `run_pipeline` function in `graphrag/index/run/run.py` to load and initialize plugins:

```python
from graphrag.plugins.plugin_loader import load_plugins

async def run_pipeline(
    workflows: list[PipelineWorkflowReference],
    dataset: pd.DataFrame,
    storage: PipelineStorage | None = None,
    cache: PipelineCache | None = None,
    callbacks: WorkflowCallbacks | None = None,
    progress_reporter: ProgressReporter | None = None,
    input_post_process_steps: list[PipelineWorkflowStep] | None = None,
    additional_verbs: VerbDefinitions | None = None,
    additional_workflows: WorkflowDefinitions | None = None,
    emit: list[TableEmitterType] | None = None,
    memory_profile: bool = False,
    is_resume_run: bool = False,
    plugin_dir: str | None = None,
    **_kwargs: dict,
) -> AsyncIterable[PipelineRunResult]:
    # ... existing code ...

    # Load and initialize plugins
    if plugin_dir:
        plugins = load_plugins(plugin_dir)
        for plugin in plugins:
            plugin.initialize(config)
            if additional_verbs is None:
                additional_verbs = {}
            additional_verbs.update(plugin.get_verbs())
            if additional_workflows is None:
                additional_workflows = {}
            additional_workflows.update(plugin.get_workflows())

    # ... rest of the function ...
```

2. Modify the GraphRAG configuration to include plugin settings:

```yaml
plugins:
  directory: "path/to/plugins"

workflows:
  - name: text_classification_workflow
    config:
      text_column: "text"
      label_column: "category"
```

By implementing this plugin architecture, you can easily extend GraphRAG's functionality without modifying its core codebase. This approach allows for greater modularity and easier maintenance of custom features.

## Conclusion

In this lesson, we've explored advanced features and customization options in GraphRAG. We've learned how to implement custom verbs and workflows, extend entity types and relationship detection, integrate additional language models and embedding models, and develop a plugin system for GraphRAG.

These advanced techniques allow you to tailor GraphRAG to your specific needs, whether you're working with domain-specific data, require custom NLP tasks, or need to integrate with other systems. By mastering these customization options, you can leverage the full power of GraphRAG in your projects.

In the next lesson, we'll dive into scaling and performance optimization techniques for GraphRAG, exploring how to handle large datasets and improve processing speed.
