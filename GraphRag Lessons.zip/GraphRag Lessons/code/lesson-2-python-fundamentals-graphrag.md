# Lesson 2: Python Fundamentals for GraphRAG

## 1. Essential Python Concepts Used in the Codebase

The GraphRAG project leverages several advanced Python features to create a robust, type-safe, and efficient codebase. In this lesson, we'll explore the key Python concepts used throughout the project, including dataclasses, type hints, exception handling, and asynchronous programming.

## 2. Working with Dataclasses and Type Hints

### 2.1 Dataclasses

Dataclasses, introduced in Python 3.7, are a concise way to create classes that primarily store data. They automatically generate several special methods, such as `__init__()`, `__repr__()`, and `__eq__()`, reducing boilerplate code and improving readability.

GraphRAG extensively uses dataclasses to define configuration models, data structures, and API responses. Let's look at an example from the codebase:

```python
# File: graphrag/index/graph/embedding/embedding.py

from dataclasses import dataclass

@dataclass
class NodeEmbeddings:
    """Node embeddings class definition."""

    nodes: list[str]
    embeddings: np.ndarray
```

In this example, `NodeEmbeddings` is a dataclass that stores a list of node names and their corresponding embeddings. The `@dataclass` decorator automatically generates methods like `__init__()` and `__repr__()`, making the code more concise and easier to maintain.

Benefits of using dataclasses in GraphRAG:
1. Reduced boilerplate code for simple data container classes
2. Automatic generation of useful methods like `__init__()` and `__repr__()`
3. Easy integration with type hints for better code clarity and IDE support
4. Compatibility with Pydantic for configuration management and validation

### 2.2 Type Hints

Type hints, introduced in Python 3.5 and expanded in later versions, allow developers to specify the expected types of variables, function parameters, and return values. While Python remains dynamically typed, type hints provide several benefits:

1. Improved code readability and self-documentation
2. Better IDE support for auto-completion and error detection
3. Enhanced static type checking using tools like mypy

GraphRAG makes extensive use of type hints throughout the codebase. Let's examine an example:

```python
# File: graphrag/index/operations/chunk_text/chunk_text.py

from typing import Any, cast

import pandas as pd
from datashaper import VerbCallbacks

def chunk_text(
    input: pd.DataFrame,
    column: str,
    to: str,
    callbacks: VerbCallbacks,
    strategy: dict[str, Any] | None = None,
) -> pd.DataFrame:
    # ... implementation ...
```

In this example, we can see several type hints in use:
- `input: pd.DataFrame`: Specifies that the `input` parameter should be a pandas DataFrame
- `column: str`: Indicates that `column` should be a string
- `callbacks: VerbCallbacks`: Specifies a custom type for the `callbacks` parameter
- `strategy: dict[str, Any] | None`: Indicates that `strategy` can be either a dictionary with string keys and any values, or None
- `-> pd.DataFrame`: Specifies that the function returns a pandas DataFrame

These type hints make the function signature more informative and help catch type-related errors early in the development process.

## 3. Exception Handling in GraphRAG

Proper exception handling is crucial for creating robust and maintainable software. GraphRAG implements a comprehensive exception handling strategy to manage errors gracefully and provide informative feedback to users and developers.

### 3.1 Custom Exceptions

GraphRAG defines custom exceptions to represent specific error conditions within the system. These custom exceptions help in providing more context about the errors and make it easier to handle different error scenarios.

Example of custom exceptions in GraphRAG:

```python
# File: graphrag/index/errors.py

class NoWorkflowsDefinedError(ValueError):
    """Exception for no workflows defined."""

    def __init__(self):
        super().__init__("No workflows defined.")


class UndefinedWorkflowError(ValueError):
    """Exception for invalid verb input."""

    def __init__(self):
        super().__init__("Workflow name is undefined.")


class UnknownWorkflowError(ValueError):
    """Exception for invalid verb input."""

    def __init__(self, name: str):
        super().__init__(f"Unknown workflow: {name}")
```

These custom exceptions provide specific error messages for different scenarios related to workflow definition and execution.

### 3.2 Try-Except Blocks

GraphRAG uses try-except blocks to handle potential exceptions and provide appropriate error handling or fallback behavior. Here's an example from the codebase:

```python
# File: graphrag/index/storage/blob_pipeline_storage.py

async def get(
    self, key: str, as_bytes: bool | None = False, encoding: str | None = None
) -> Any:
    """Get a value from the cache."""
    try:
        key = self._keyname(key)
        container_client = self._blob_service_client.get_container_client(
            self._container_name
        )
        blob_client = container_client.get_blob_client(key)
        blob_data = blob_client.download_blob().readall()
        if not as_bytes:
            coding = encoding or "utf-8"
            blob_data = blob_data.decode(coding)
    except Exception:
        log.exception("Error getting key %s", key)
        return None
    else:
        return blob_data
```

In this example, the `get` method attempts to retrieve data from Azure Blob Storage. If any exception occurs during this process, it's caught, logged, and the method returns `None` instead of propagating the error.

### 3.3 Error Callbacks

GraphRAG implements a callback system for error handling, allowing users to define custom error handling behavior. This is particularly useful for logging errors or providing feedback in user interfaces.

Example of error callback usage:

```python
# File: graphrag/index/graph/extractors/claims/claim_extractor.py

class ClaimExtractor:
    def __init__(
        self,
        llm_invoker: CompletionLLM,
        extraction_prompt: str | None = None,
        on_error: ErrorHandlerFn | None = None,
        # ... other parameters ...
    ):
        # ... other initialization ...
        self._on_error = on_error or (lambda _e, _s, _d: None)

    async def __call__(self, inputs: dict[str, Any]) -> ClaimExtractorResult:
        # ... other code ...
        try:
            # ... extraction logic ...
        except Exception as e:
            log.exception("error extracting claim")
            self._on_error(
                e,
                traceback.format_exc(),
                {"doc_index": doc_index, "text": text},
            )
            continue
        # ... rest of the method ...
```

In this example, the `ClaimExtractor` class accepts an optional `on_error` callback. If an exception occurs during claim extraction, the callback is invoked with the exception, stack trace, and additional context information.

## 4. Asynchronous Programming Basics

GraphRAG makes extensive use of asynchronous programming to improve performance and handle I/O-bound operations efficiently. The project primarily uses Python's `asyncio` library for asynchronous programming.

### 4.1 Async/Await Syntax

The async/await syntax is used throughout GraphRAG to define and work with coroutines. Here's an example from the codebase:

```python
# File: graphrag/index/run/run.py

async def run_pipeline(
    workflows: list[PipelineWorkflowReference],
    dataset: pd.DataFrame,
    storage: PipelineStorage | None = None,
    cache: PipelineCache | None = None,
    callbacks: WorkflowCallbacks | None = None,
    progress_reporter: ProgressReporter | None = None,
    input_post_process_steps: list[PipelineWorkflowStep] | None = None,
    additional_verbs: VerbDefinitions | None = None,
    additional_workflows: WorkflowDefinitions | None = None,
    emit: list[TableEmitterType] | None = None,
    memory_profile: bool = False,
    is_resume_run: bool = False,
    **_kwargs: dict,
) -> AsyncIterable[PipelineRunResult]:
    # ... implementation ...
```

This function is defined with the `async` keyword, indicating that it's a coroutine. It can be called using the `await` keyword and yields results asynchronously.

### 4.2 Asynchronous Context Managers

GraphRAG uses asynchronous context managers to manage resources that require setup and teardown in an asynchronous context. For example, the `aiofiles` library is used for asynchronous file I/O:

```python
# File: graphrag/index/storage/file_pipeline_storage.py

import aiofiles

class FilePipelineStorage(PipelineStorage):
    # ... other methods ...

    async def set(self, key: str, value: Any, encoding: str | None = None) -> None:
        """Set method definition."""
        is_bytes = isinstance(value, bytes)
        write_type = "wb" if is_bytes else "w"
        encoding = None if is_bytes else encoding or self._encoding
        async with aiofiles.open(
            join_path(self._root_dir, key),
            cast(Any, write_type),
            encoding=encoding,
        ) as f:
            await f.write(value)
```

In this example, the `aiofiles.open()` function is used with an async context manager (`async with`) to asynchronously write data to a file.

### 4.3 Asynchronous Iteration

GraphRAG uses asynchronous iteration to process large datasets or perform multiple asynchronous operations efficiently. Here's an example:

```python
# File: graphrag/index/run/run.py

async def run_pipeline_with_config(
    # ... parameters ...
) -> AsyncIterable[PipelineRunResult]:
    # ... other code ...

    try:
        await _dump_stats(context.stats, context.storage)

        for workflow_to_run in workflows_to_run:
            # ... other code ...
            result = await _process_workflow(
                workflow_to_run.workflow,
                context,
                callbacks,
                emitters,
                workflow_dependencies,
                dataset,
                start_time,
                is_resume_run,
            )
            if result:
                yield result

        # ... other code ...
    except Exception as e:
        # ... error handling ...
```

This function uses `async for` to iterate over workflows and `yield` to asynchronously return results as they become available.

## Conclusion

In this lesson, we've explored the essential Python concepts used in the GraphRAG codebase, including dataclasses, type hints, exception handling, and asynchronous programming. These features contribute to creating a robust, efficient, and maintainable codebase for the GraphRAG project.

Understanding these concepts is crucial for working effectively with the GraphRAG codebase and extending its functionality. In the next lesson, we'll dive deeper into the core concepts of GraphRAG, including graph representations, RAG systems, and key data structures used in the project.

## Review Questions

1. What are the benefits of using dataclasses in the GraphRAG project?
2. How do type hints improve code quality and development experience in GraphRAG?
3. Explain the custom exception handling strategy used in GraphRAG and provide an example of a custom exception.
4. How does GraphRAG use error callbacks, and what advantages does this approach offer?
5. Describe the role of asynchronous programming in GraphRAG and provide an example of its usage in the codebase.
6. What is the purpose of asynchronous context managers, and how are they used in GraphRAG?
7. How does asynchronous iteration help in processing large datasets or performing multiple asynchronous operations in GraphRAG?

## Hands-on Exercise

1. Create a new Python file called `graph_rag_utils.py`.

2. In this file, define a dataclass called `GraphNode` with the following attributes:
   - `id: str`
   - `label: str`
   - `attributes: dict[str, Any]`

3. Implement an asynchronous function called `process_nodes` that takes a list of `GraphNode` objects and an async callback function. The function should process each node asynchronously and apply the callback to each node's attributes.

4. Implement proper exception handling in the `process_nodes` function, including a custom exception called `NodeProcessingError`.

5. Use type hints throughout your implementation.

6. In the `if __name__ == "__main__":` block, create a sample list of `GraphNode` objects and an async callback function that adds a "processed" timestamp to the node attributes. Run the `process_nodes` function with these inputs.

This exercise will help you practice using dataclasses, type hints, asynchronous programming, and exception handling in a context similar to the GraphRAG project.

