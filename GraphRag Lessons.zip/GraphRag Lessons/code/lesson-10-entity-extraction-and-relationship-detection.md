# Lesson 10: Entity Extraction and Relationship Detection in GraphRAG

## Introduction

In this lesson, we'll dive into the entity extraction and relationship detection processes in GraphRAG. These are crucial steps in transforming unstructured text data into structured graph representations, which form the backbone of the GraphRAG system.

## File Structure

Before we begin, let's take a look at the relevant file structure for this lesson:

```
graphrag/
├── index/
│   ├── flows/
│   │   ├── create_base_extracted_entities.py
│   │   └── create_final_relationships.py
│   ├── graph/
│   │   └── extractors/
│   │       ├── __init__.py
│   │       ├── graph/
│   │       │   ├── graph_extractor.py
│   │       │   └── prompts.py
│   │       └── claims/
│   │           ├── claim_extractor.py
│   │           └── prompts.py
│   └── operations/
│       ├── extract_entities/
│       │   ├── __init__.py
│       │   ├── extract_entities.py
│       │   └── strategies/
│       │       ├── graph_intelligence.py
│       │       └── nltk.py
│       └── extract_covariates/
│           ├── __init__.py
│           ├── extract_covariates.py
│           └── strategies.py
└── config/
    ├── __init__.py
    ├── defaults.py
    └── models.py
```

This structure shows the main components we'll be discussing in this lesson. The `extractors` directory contains the core entity and relationship extraction logic, while the `operations` directory contains the high-level operations used in the GraphRAG pipeline.

## 1. Entity Extraction Fundamentals

Entity extraction, also known as Named Entity Recognition (NER), is the process of identifying and classifying named entities (such as persons, organizations, locations, etc.) in unstructured text. In GraphRAG, this process is crucial for building the nodes of the graph.

### 1.1 The GraphExtractor Class

At the core of GraphRAG's entity extraction system is the `GraphExtractor` class:

```python
# graphrag/index/graph/extractors/graph/graph_extractor.py

class GraphExtractor:
    def __init__(
        self,
        llm_invoker: CompletionLLM,
        tuple_delimiter_key: str | None = None,
        record_delimiter_key: str | None = None,
        input_text_key: str | None = None,
        entity_types_key: str | None = None,
        completion_delimiter_key: str | None = None,
        prompt: str | None = None,
        join_descriptions=True,
        encoding_model: str | None = None,
        max_gleanings: int | None = None,
        on_error: ErrorHandlerFn | None = None,
    ):
        # Initialization code...

    async def __call__(
        self, texts: list[str], prompt_variables: dict[str, Any] | None = None
    ) -> GraphExtractionResult:
        # Entity extraction logic...
```

This class is responsible for extracting entities and relationships from input text using a language model (LLM). It uses a prompt-based approach, where the LLM is given instructions on how to identify and classify entities and relationships.

### 1.2 Entity Extraction Strategies

GraphRAG supports multiple strategies for entity extraction, defined in the `ExtractEntityStrategyType` enum:

```python
# graphrag/index/operations/extract_entities/extract_entities.py

class ExtractEntityStrategyType(str, Enum):
    graph_intelligence = "graph_intelligence"
    graph_intelligence_json = "graph_intelligence_json"
    nltk = "nltk"
```

Each strategy corresponds to a different method of extracting entities:

1. **Graph Intelligence**: This strategy uses a language model to extract entities and relationships based on a given prompt.

2. **Graph Intelligence JSON**: Similar to the above, but expects the LLM to return results in a structured JSON format.

3. **NLTK**: This strategy uses the Natural Language Toolkit (NLTK) library for entity extraction, which can be faster but less flexible than LLM-based approaches.

### 1.3 Implementing Entity Extraction

The actual implementation of entity extraction is done in the `extract_entities` function:

```python
# graphrag/index/operations/extract_entities/extract_entities.py

async def extract_entities(
    input: pd.DataFrame,
    callbacks: VerbCallbacks,
    cache: PipelineCache,
    column: str,
    id_column: str,
    to: str,
    strategy: dict[str, Any] | None,
    graph_to: str | None = None,
    async_mode: AsyncType = AsyncType.AsyncIO,
    entity_types=DEFAULT_ENTITY_TYPES,
    num_threads: int = 4,
) -> pd.DataFrame:
    # Entity extraction logic...
```

This function applies the chosen entity extraction strategy to a specified column in a DataFrame, creating new columns with the extracted entities and graph representation.

## 2. Relationship Detection

After extracting entities, the next step is to detect relationships between these entities. This process forms the edges of the graph in GraphRAG.

### 2.1 Relationship Extraction in GraphExtractor

The `GraphExtractor` class is also responsible for extracting relationships. It does this as part of the same process as entity extraction, using the LLM to identify both entities and the relationships between them.

### 2.2 Creating Final Relationships

The process of creating the final relationships is implemented in the `create_final_relationships` function:

```python
# graphrag/index/flows/create_final_relationships.py

async def create_final_relationships(
    entity_graph: pd.DataFrame,
    nodes: pd.DataFrame,
    callbacks: VerbCallbacks,
    cache: PipelineCache,
    description_text_embed: dict | None = None,
) -> pd.DataFrame:
    # Relationship creation logic...
```

This function takes the extracted entity graph and creates a DataFrame of relationships, including attributes like source, target, description, and rank.

## 3. Configuration and Usage

Entity extraction and relationship detection in GraphRAG can be configured through the `GraphRagConfig` class:

```python
# graphrag/config/models.py

class EntityExtractionConfig(BaseModel):
    prompt: str | None = None
    entity_types: list[str] = Field(default=defs.ENTITY_EXTRACTION_ENTITY_TYPES)
    max_gleanings: int = Field(default=defs.ENTITY_EXTRACTION_MAX_GLEANINGS)

class GraphRagConfig(BaseModel):
    # Other fields...
    entity_extraction: EntityExtractionConfig = Field(default_factory=EntityExtractionConfig)
    # More fields...
```

Users can specify their desired entity extraction parameters in a YAML configuration file, which is then parsed into this `GraphRagConfig` object.

## 4. Best Practices and Considerations

When working with entity extraction and relationship detection in GraphRAG, consider the following best practices:

1. **Choose the Right Strategy**: Select the extraction strategy that best fits your data and requirements. LLM-based strategies are more flexible but can be slower, while rule-based strategies like NLTK can be faster but less adaptable.

2. **Prompt Engineering**: For LLM-based strategies, carefully design and test your prompts. The quality of your prompts significantly impacts the accuracy of entity and relationship extraction.

3. **Entity Types**: Clearly define the entity types you're interested in. This helps focus the extraction process and improves the quality of the resulting graph.

4. **Relationship Types**: Similarly, define the types of relationships you want to detect. This guides the LLM in identifying relevant connections between entities.

5. **Context Preservation**: Ensure that your chunking strategy (from the previous lesson) preserves enough context for accurate entity and relationship extraction.

6. **Performance Optimization**: For large datasets, consider implementing parallel processing for extraction operations.

7. **Error Handling**: Implement robust error handling and logging. Entity extraction can sometimes produce unexpected results, especially with diverse or noisy input data.

8. **Post-processing**: Consider implementing post-processing steps to clean and normalize extracted entities and relationships.

## 5. Advanced Topics

### 5.1 Custom Entity Extraction Strategies

GraphRAG's modular design allows for easy implementation of custom entity extraction strategies. To create a custom strategy:

1. Define a new strategy type in the `ExtractEntityStrategyType` enum.
2. Implement the strategy function in a new file under `strategies/`.
3. Update the `load_strategy` function to include your new strategy.

Here's an example of how you might implement a simple regex-based entity extraction strategy:

```python
# In extract_entities.py
class ExtractEntityStrategyType(str, Enum):
    # Existing strategies...
    regex = "regex"

# In strategies/regex.py
import re
from typing import List, Dict, Any

def run_regex(text: str, entity_types: List[str], patterns: Dict[str, str]) -> Dict[str, Any]:
    entities = []
    for entity_type in entity_types:
        if entity_type in patterns:
            for match in re.finditer(patterns[entity_type], text):
                entities.append({
                    "type": entity_type,
                    "name": match.group(),
                    "start": match.start(),
                    "end": match.end()
                })
    return {"entities": entities}

# In extract_entities.py
def load_strategy(strategy_type: ExtractEntityStrategyType) -> EntityExtractStrategy:
    match strategy_type:
        case ExtractEntityStrategyType.graph_intelligence:
            from .strategies.graph_intelligence import run_graph_intelligence
            return run_graph_intelligence
        case ExtractEntityStrategyType.nltk:
            from .strategies.nltk import run as run_nltk
            return run_nltk
        case ExtractEntityStrategyType.regex:
            from .strategies.regex import run_regex
            return run_regex
        case _:
            raise ValueError(f"Unknown strategy: {strategy_type}")
```

### 5.2 Handling Ambiguity and Coreference Resolution

Entity extraction and relationship detection can often face challenges with ambiguity and coreference. Here are some strategies to handle these issues:

1. **Entity Disambiguation**: When the same name could refer to multiple entities, use context to disambiguate. This might involve looking at surrounding text or other entities in the document.

```python
def disambiguate_entity(entity_name: str, context: str) -> str:
    # Use surrounding context to disambiguate the entity
    # This could involve looking up in a knowledge base, or using an LLM
    # to make a decision based on the context
    pass
```

2. **Coreference Resolution**: Identify when different mentions in the text refer to the same entity. This is crucial for accurately capturing relationships.

```python
def resolve_coreferences(text: str, entities: List[Dict]) -> List[Dict]:
    # Use a coreference resolution model (e.g., neuralcoref) to identify
    # which mentions refer to the same entity
    pass
```

3. **Confidence Scores**: Include confidence scores with your extracted entities and relationships. This allows downstream processes to make informed decisions about how to use the information.

```python
def extract_entities_with_confidence(text: str) -> List[Dict]:
    # Extract entities and include a confidence score for each
    pass
```

### 5.3 Incremental and Streaming Entity Extraction

For large-scale or real-time applications, you might need to implement incremental or streaming entity extraction:

```python
class StreamingEntityExtractor:
    def __init__(self, strategy: EntityExtractStrategy):
        self.strategy = strategy
        self.entity_cache = {}

    async def process_stream(self, text_stream: AsyncIterable[str]):
        async for chunk in text_stream:
            new_entities = await self.strategy(chunk)
            self.update_entity_cache(new_entities)
            yield self.entity_cache

    def update_entity_cache(self, new_entities: List[Dict]):
        for entity in new_entities:
            if entity['name'] in self.entity_cache:
                # Update existing entity information
                self.entity_cache[entity['name']].update(entity)
            else:
                # Add new entity to cache
                self.entity_cache[entity['name']] = entity
```

This approach allows you to process a stream of text, continuously updating your entity cache as new information becomes available.

### 5.4 Leveraging External Knowledge Bases

To improve the accuracy and richness of your entity extraction and relationship detection, you can leverage external knowledge bases:

```python
class KnowledgeBaseEnhancedExtractor:
    def __init__(self, base_extractor: EntityExtractStrategy, knowledge_base: KnowledgeBase):
        self.base_extractor = base_extractor
        self.knowledge_base = knowledge_base

    async def extract(self, text: str) -> Dict[str, Any]:
        base_results = await self.base_extractor(text)
        enhanced_results = self.enhance_with_knowledge_base(base_results)
        return enhanced_results

    def enhance_with_knowledge_base(self, results: Dict[str, Any]) -> Dict[str, Any]:
        for entity in results['entities']:
            additional_info = self.knowledge_base.lookup(entity['name'], entity['type'])
            entity.update(additional_info)
        return results
```

This approach allows you to enrich your extracted entities with additional information from a knowledge base, potentially improving the quality of your relationship detection as well.

## Conclusion

Entity extraction and relationship detection are crucial components of the GraphRAG system, transforming unstructured text into structured graph representations. By leveraging various strategies, from rule-based approaches to advanced language models, GraphRAG provides a flexible and powerful framework for building knowledge graphs from text data.

Key takeaways from this lesson include:

1. The importance of choosing the right extraction strategy for your specific use case.
2. The role of prompt engineering in LLM-based extraction strategies.
3. The need for careful configuration and tuning of the extraction process.
4. The potential for custom strategies and advanced techniques like coreference resolution and knowledge base integration.

As you work with GraphRAG, remember that the quality of your entity extraction and relationship detection directly impacts the effectiveness of downstream tasks like question answering and summarization. Continual refinement and testing of these processes is key to building robust and accurate graph-based retrieval-augmented generation systems.

In the next lesson, we'll explore how GraphRAG uses the extracted entities and relationships to perform community detection and generate community-level summaries, further enhancing the knowledge representation capabilities of the system.

