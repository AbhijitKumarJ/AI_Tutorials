# Lesson 14: Error Handling and Debugging in GraphRAG

## Introduction

Error handling and debugging are crucial skills for working effectively with GraphRAG. This lesson will cover common error scenarios, debugging techniques, logging and reporting best practices, troubleshooting LLM-related issues, and creating custom error handlers. By the end of this lesson, you'll be equipped with the knowledge and tools to identify, diagnose, and resolve issues in your GraphRAG pipelines.

## Table of Contents

1. Common Error Scenarios in GraphRAG
2. Debugging Techniques for Pipelines
3. Logging and Reporting Best Practices
4. Troubleshooting LLM-related Issues
5. Creating Custom Error Handlers
6. Hands-on Exercise: Debugging a GraphRAG Pipeline

## 1. Common Error Scenarios in GraphRAG

GraphRAG pipelines can encounter various types of errors. Let's explore some common scenarios and how to address them:

### a. Configuration Errors

These errors occur when the pipeline configuration is incorrect or incomplete.

Example:
```python
ConfigurationError: Missing required configuration: 'GRAPHRAG_API_KEY'
```

Solution: Ensure all required environment variables or configuration parameters are set correctly. Double-check your `.env` file or `settings.yaml`.

### b. Input Data Errors

These errors happen when the input data doesn't match the expected format or schema.

Example:
```python
ValueError: Column 'text' not found in input DataFrame
```

Solution: Verify that your input data matches the expected schema. Use `print(df.columns)` to check available columns.

### c. LLM API Errors

These occur when there are issues communicating with the Language Model API.

Example:
```python
OpenAIError: API request failed: API key not valid
```

Solution: Check your API key, ensure you have sufficient credits, and verify your network connection.

### d. Memory or Resource Errors

These happen when the pipeline runs out of system resources.

Example:
```python
MemoryError: Unable to allocate array with shape (1000000, 1000) and data type float64
```

Solution: Reduce batch sizes, use memory-efficient data structures, or increase system resources.

## 2. Debugging Techniques for Pipelines

To effectively debug GraphRAG pipelines, consider the following techniques:

### a. Use Verbose Logging

Enable verbose logging to get detailed information about each step of the pipeline.

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### b. Step-by-Step Execution

Break down your pipeline into smaller steps and execute them individually to isolate issues.

```python
async def debug_pipeline():
    # Step 1: Load input data
    input_data = await load_input(input_config)
    print("Input data loaded:", input_data.shape)

    # Step 2: Entity extraction
    entities = await run_entity_extraction(input_data)
    print("Entities extracted:", len(entities))

    # Continue with other steps...

asyncio.run(debug_pipeline())
```

### c. Use Python Debugger (pdb)

Insert breakpoints in your code to pause execution and inspect variables.

```python
import pdb

def problematic_function():
    # Some code here
    pdb.set_trace()  # Execution will pause here
    # More code
```

### d. Implement Try-Except Blocks

Wrap potentially problematic code in try-except blocks to catch and handle errors gracefully.

```python
try:
    result = await run_pipeline(config)
except Exception as e:
    print(f"An error occurred: {str(e)}")
    # Handle the error or re-raise if necessary
```

## 3. Logging and Reporting Best Practices

Effective logging and reporting are crucial for debugging and monitoring GraphRAG pipelines. Here are some best practices:

### a. Use Structured Logging

Use a structured logging format to make logs easier to parse and analyze.

```python
import structlog

logger = structlog.get_logger()
logger.info("Pipeline started", input_size=len(input_data), config=pipeline_config)
```

### b. Log at Appropriate Levels

Use different log levels (DEBUG, INFO, WARNING, ERROR) appropriately to categorize messages.

```python
logger.debug("Processing entity", entity_id=entity.id)
logger.info("Entity extraction completed", entity_count=len(entities))
logger.warning("LLM API rate limit approaching", current_rate=99, max_rate=100)
logger.error("Failed to connect to database", error=str(e))
```

### c. Implement Custom Reporters

Create custom reporter classes to handle different types of events and errors.

```python
from graphrag.index.reporting import Reporter

class CustomReporter(Reporter):
    def log(self, message: str, details: dict | None = None):
        print(f"LOG: {message}")
        if details:
            print(f"Details: {details}")

    def error(self, message: str, details: dict | None = None):
        print(f"ERROR: {message}")
        if details:
            print(f"Error details: {details}")

# Use the custom reporter in your pipeline
pipeline_result = await run_pipeline_with_config(
    config_path,
    reporter=CustomReporter()
)
```

### d. Use Callbacks for Progress Tracking

Implement callback functions to track the progress of long-running operations.

```python
def progress_callback(current, total):
    print(f"Progress: {current}/{total} ({current/total*100:.2f}%)")

await run_pipeline(config, progress_callback=progress_callback)
```

## 4. Troubleshooting LLM-related Issues

LLM integration is a core part of GraphRAG. Here are some common issues and how to address them:

### a. API Rate Limiting

Problem: Exceeding API rate limits can cause pipeline failures.

Solution: Implement exponential backoff and retry logic.

```python
import time
from tenacity import retry, stop_after_attempt, wait_exponential

@retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=4, max=10))
async def llm_api_call(prompt):
    # Your API call code here
    pass
```

### b. Token Limit Exceeded

Problem: Exceeding maximum token limits for LLM inputs.

Solution: Implement a token counting mechanism and chunk large inputs.

```python
import tiktoken

def count_tokens(text, model="cl100k_base"):
    encoder = tiktoken.get_encoding(model)
    return len(encoder.encode(text))

def chunk_text(text, max_tokens=1000):
    tokens = count_tokens(text)
    if tokens <= max_tokens:
        return [text]
    
    # Implement chunking logic here
    # ...

chunks = chunk_text(long_text)
for chunk in chunks:
    await process_chunk(chunk)
```

### c. Inconsistent LLM Outputs

Problem: LLM outputs may be inconsistent or not in the expected format.

Solution: Implement output parsing and validation, and use structured prompts.

```python
import json

def parse_llm_output(output):
    try:
        return json.loads(output)
    except json.JSONDecodeError:
        raise ValueError("LLM output is not valid JSON")

def validate_output(parsed_output, expected_keys):
    for key in expected_keys:
        if key not in parsed_output:
            raise ValueError(f"Missing expected key: {key}")

# Usage
llm_output = await llm_api_call(structured_prompt)
parsed_output = parse_llm_output(llm_output)
validate_output(parsed_output, ["entities", "relationships"])
```

## 5. Creating Custom Error Handlers

Custom error handlers allow you to manage errors specific to your GraphRAG pipeline. Here's how to create and use them:

### a. Define Custom Exception Classes

Create custom exception classes for specific error types in your pipeline.

```python
# File: custom_exceptions.py

class EntityExtractionError(Exception):
    """Raised when entity extraction fails"""
    pass

class RelationshipExtractionError(Exception):
    """Raised when relationship extraction fails"""
    pass

class GraphEmbeddingError(Exception):
    """Raised when graph embedding fails"""
    pass
```

### b. Implement a Custom Error Handler

Create a custom error handler to manage different types of errors.

```python
# File: error_handler.py

from custom_exceptions import *

class GraphRAGErrorHandler:
    def handle_error(self, error: Exception):
        if isinstance(error, EntityExtractionError):
            print("Entity extraction failed. Retrying with fallback method...")
            # Implement fallback logic
        elif isinstance(error, RelationshipExtractionError):
            print("Relationship extraction failed. Skipping and continuing...")
            # Implement skip logic
        elif isinstance(error, GraphEmbeddingError):
            print("Graph embedding failed. Using default embeddings...")
            # Use default embeddings
        else:
            print(f"Unhandled error: {str(error)}")
            raise error

# Usage
error_handler = GraphRAGErrorHandler()

try:
    # Your pipeline code here
    pass
except Exception as e:
    error_handler.handle_error(e)
```

### c. Integrate Custom Error Handling into Your Pipeline

Modify your pipeline to use the custom error handler.

```python
# File: pipeline.py

from error_handler import GraphRAGErrorHandler

async def run_pipeline(config):
    error_handler = GraphRAGErrorHandler()
    
    try:
        # Step 1: Entity Extraction
        entities = await extract_entities(input_data)
    except Exception as e:
        error_handler.handle_error(EntityExtractionError(str(e)))
    
    try:
        # Step 2: Relationship Extraction
        relationships = await extract_relationships(entities)
    except Exception as e:
        error_handler.handle_error(RelationshipExtractionError(str(e)))
    
    # Continue with other steps...

# Run the pipeline
asyncio.run(run_pipeline(config))
```

## 6. Hands-on Exercise: Debugging a GraphRAG Pipeline

Let's put our error handling and debugging skills to the test with a hands-on exercise. We'll debug a GraphRAG pipeline that's encountering multiple issues.

### Exercise Setup

Create a new directory for this exercise with the following file structure:

```
debug_exercise/
│
├── config/
│   └── pipeline_config.yml
│
├── data/
│   └── input.csv
│
├── custom_exceptions.py
├── error_handler.py
├── pipeline.py
└── requirements.txt
```

#### requirements.txt
```
graphrag
pandas
pyyaml
```

#### config/pipeline_config.yml
```yaml
input:
  file_type: csv
  base_dir: ./data
  file_pattern: .*\.csv$
  source_column: "author"
  text_column: "message"

workflows:
  - name: entity_extraction
    config:
      entity_extract:
        strategy:
          type: nltk

  - name: relationship_extraction
    config:
      relationship_extract:
        strategy:
          type: rule_based

  - name: graph_embedding
    config:
      embed_graph:
        strategy:
          type: node2vec
          num_walks: 10
          walk_length: 40
```

#### custom_exceptions.py
```python
# (Use the custom exception classes defined earlier)
```

#### error_handler.py
```python
# (Use the GraphRAGErrorHandler class defined earlier)
```

#### pipeline.py
```python
import asyncio
import yaml
from graphrag.index import run_pipeline_with_config
from error_handler import GraphRAGErrorHandler

async def main():
    with open("config/pipeline_config.yml", "r") as config_file:
        config = yaml.safe_load(config_file)

    error_handler = GraphRAGErrorHandler()

    try:
        async for result in run_pipeline_with_config(config):
            print(f"Workflow {result.workflow} completed")
    except Exception as e:
        error_handler.handle_error(e)

if __name__ == "__main__":
    asyncio.run(main())
```

### Exercise Tasks

1. Run the pipeline and observe the errors.
2. Use logging to identify the source of each error.
3. Implement error handling for each issue you encounter.
4. Modify the pipeline to use a custom reporter for better error reporting.
5. Add a progress callback to track the pipeline's progress.
6. Use the Python debugger (pdb) to step through the problematic sections of code.
7. Implement input data validation to catch data-related issues early.
8. Add retry logic for the relationship extraction step.

### Solution Walkthrough

We'll go through each task, explaining the problems encountered and how to solve them.

(Note: The actual solution would be quite lengthy, so I'll provide a high-level overview of the steps to solve each task.)

1. Running the pipeline:
   - You might encounter a `FileNotFoundError` for the input CSV file.
   - Solution: Ensure the `data/input.csv` file exists and contains the correct columns.

2. Using logging:
   - Add logging statements throughout the pipeline to track execution.
   - You might discover that the NLTK data is not downloaded for entity extraction.

3. Implementing error handling:
   - Wrap each workflow in a try-except block and use the custom error handler.
   - Handle specific exceptions like `EntityExtractionError` and `RelationshipExtractionError`.

4. Custom reporter:
   - Implement a `CustomReporter` class that inherits from `graphrag.index.reporting.Reporter`.
   - Use this reporter in `run_pipeline_with_config`.

5. Progress callback:
   - Implement a progress callback function and pass it to `run_pipeline_with_config`.

6. Using pdb:
   - Add `import pdb; pdb.set_trace()` before problematic code sections.
   - Use the debugger to inspect variables and step through code.

7. Input data validation:
   - Add a function to validate the input CSV file before processing.
   - Check for required columns and data types.

8. Retry logic:
   - Use the `tenacity` library to add retry decoration to the relationship extraction function.

After completing these tasks, your GraphRAG pipeline should be more robust, easier to debug, and better at handling errors.

## Conclusion

In this lesson, we've covered essential techniques for error handling and debugging in GraphRAG pipelines. We've explored common error scenarios, debugging techniques, logging best practices, LLM-related issues, and how to create custom error handlers. The hands-on exercise provided practical experience in applying these concepts to a real GraphRAG pipeline.

Remember that effective error handling and debugging are ongoing processes. As you work with more complex pipelines and larger datasets, you'll encounter new challenges. Continuously refine your error handling strategies and keep your debugging skills sharp to ensure smooth operation of your GraphRAG pipelines.

## Additional Resources

- [Python Debugging With Pdb](https://realpython.com/python-debugging-pdb/)
- [Structured Logging for Python](https://www.structlog.org/en/stable/)
- [OpenAI API Error Handling](https://platform.openai.com/docs/guides/error-codes)
- [Tenacity: General-purpose retrying library for Python](https://github.com/jd/tenacity)

In the next lesson, we'll explore best practices and real-world applications of GraphRAG, building on the error handling and debugging skills you've learned here.

