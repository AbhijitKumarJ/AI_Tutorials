# Lesson 9: Custom Verbs and Workflows

## Table of Contents
1. Introduction to Custom Verbs and Workflows
2. Creating Custom Verbs
3. Defining Custom Workflows
4. Integrating Custom Components into the Pipeline
5. Best Practices for Extending GraphRAG
6. Workflow Reusability and Modularity
7. Hands-on Exercise
8. Recap and Next Steps

## 1. Introduction to Custom Verbs and Workflows

GraphRAG provides a flexible framework that allows users to extend its functionality through custom verbs and workflows. This enables you to tailor the system to your specific needs and integrate specialized processing steps into your data pipeline.

- Custom Verbs: Individual operations that can be applied to data within a workflow.
- Custom Workflows: Sequences of steps (including custom verbs) that define a complete data processing pipeline.

## 2. Creating Custom Verbs

Custom verbs are the building blocks of GraphRAG workflows. They allow you to define specific operations that can be applied to your data.

### File Layout

```
graphrag/
├── index/
│   └── verbs/
│       ├── __init__.py
│       └── custom_verbs.py
└── examples/
    └── custom_set_of_available_verbs/
        ├── custom_verb_definitions.py
        ├── pipeline.yml
        └── run.py
```

### Defining a Custom Verb

To create a custom verb, you need to define a function that takes specific parameters and returns a `TableContainer`. Here's an example:

```python
# graphrag/index/verbs/custom_verbs.py

from datashaper import TableContainer, VerbInput

def str_append(
    input: VerbInput, source_column: str, target_column: str, string_to_append: str
):
    """A custom verb that appends a string to a column"""
    input_data = input.get_input()
    output_df = input_data.copy()
    output_df[target_column] = output_df[source_column].apply(
        lambda x: f"{x}{string_to_append}"
    )
    return TableContainer(table=output_df)

custom_verbs = {
    "str_append": str_append,
}
```

### Registering Custom Verbs

To make your custom verbs available in the pipeline, you need to register them:

```python
# In your main script or configuration
from graphrag.index.verbs.custom_verbs import custom_verbs
from graphrag.index import run_pipeline

# ... (other setup code)

async for output in run_pipeline(
    dataset=dataset,
    workflows=workflows,
    additional_verbs=custom_verbs,
):
    # Process output
```

## 3. Defining Custom Workflows

Custom workflows allow you to create reusable sequences of operations that can be applied to your data. They can include both built-in and custom verbs.

### File Layout

```
graphrag/
└── examples/
    └── custom_set_of_available_workflows/
        ├── custom_workflow_definitions.py
        ├── pipeline.yml
        └── run.py
```

### Creating a Custom Workflow

Custom workflows are defined as dictionaries of named workflows, where each workflow is a function that returns a list of steps:

```python
# graphrag/examples/custom_set_of_available_workflows/custom_workflow_definitions.py

from graphrag.index.workflows import WorkflowDefinitions

custom_workflows: WorkflowDefinitions = {
    "my_workflow": lambda config: [
        {
            "verb": "derive",
            "args": {
                "column1": "col1",
                "column2": "col2",
                "to": config.get("derive_output_column", "output_column"),
                "operator": "*",
            },
        }
    ],
    "another_workflow": lambda _config: [
        {
            "verb": "filter",
            "args": {
                "column": "col1",
                "operator": ">",
                "value": 10
            },
        }
    ],
}
```

### Using Custom Workflows

To use custom workflows in your pipeline, you need to include them in your configuration:

```yaml
# pipeline.yml
workflows:
  - name: my_workflow
    config:
      derive_output_column: "col_1_multiplied"
```

And then in your Python code:

```python
from graphrag.index import run_pipeline_with_config
from custom_workflow_definitions import custom_workflows

async for output in run_pipeline_with_config(
    config_or_path="pipeline.yml",
    dataset=dataset,
    additional_workflows=custom_workflows,
):
    # Process output
```

## 4. Integrating Custom Components into the Pipeline

Integrating custom verbs and workflows into the GraphRAG pipeline involves a few key steps:

1. Define your custom verbs and workflows in separate Python files.
2. Register custom verbs with the `additional_verbs` parameter in `run_pipeline`.
3. Register custom workflows with the `additional_workflows` parameter in `run_pipeline_with_config`.
4. Reference your custom components in your pipeline configuration (YAML) or workflow definitions.

Example:

```python
# run.py
import asyncio
from graphrag.index import run_pipeline_with_config
from custom_verb_definitions import custom_verbs
from custom_workflow_definitions import custom_workflows

async def main():
    config_path = "pipeline.yml"
    
    async for output in run_pipeline_with_config(
        config_or_path=config_path,
        dataset=dataset,
        additional_verbs=custom_verbs,
        additional_workflows=custom_workflows,
    ):
        # Process output
        print(output)

if __name__ == "__main__":
    asyncio.run(main())
```

## 5. Best Practices for Extending GraphRAG

When creating custom verbs and workflows, follow these best practices:

1. **Modularity**: Keep verbs focused on single, specific tasks.
2. **Reusability**: Design verbs and workflows to be reusable across different pipelines.
3. **Error Handling**: Implement proper error handling and input validation in custom verbs.
4. **Documentation**: Provide clear documentation for custom verbs and workflows, including expected inputs and outputs.
5. **Testing**: Create unit tests for custom verbs to ensure they behave as expected.
6. **Performance**: Consider the performance implications of custom verbs, especially for large datasets.
7. **Consistency**: Follow GraphRAG's naming conventions and coding style for consistency.

## 6. Workflow Reusability and Modularity

To maximize the reusability and modularity of your workflows:

1. **Parameterization**: Use configuration parameters to make workflows flexible.
2. **Composition**: Build complex workflows by combining simpler, reusable workflows.
3. **Abstraction**: Create abstract workflows that can be specialized for different use cases.
4. **Dependency Management**: Clearly define and manage dependencies between workflows.

Example of a modular workflow:

```python
def create_data_processing_workflow(config):
    return [
        {
            "verb": "filter",
            "args": config.get("filter_args", {}),
        },
        {
            "verb": "derive",
            "args": config.get("derive_args", {}),
        },
        {
            "verb": "aggregate",
            "args": config.get("aggregate_args", {}),
        }
    ]

custom_workflows = {
    "data_processing": create_data_processing_workflow,
}
```

This workflow can be easily customized for different scenarios by providing different configurations.

## 7. Hands-on Exercise

Let's create a custom verb and workflow, and integrate them into a GraphRAG pipeline.

1. Create a file `custom_components.py`:

```python
from datashaper import TableContainer, VerbInput

def uppercase_column(
    input: VerbInput, source_column: str, target_column: str
):
    """A custom verb that converts a column to uppercase"""
    input_data = input.get_input()
    output_df = input_data.copy()
    output_df[target_column] = output_df[source_column].str.upper()
    return TableContainer(table=output_df)

custom_verbs = {
    "uppercase": uppercase_column,
}

def create_text_processing_workflow(config):
    return [
        {
            "verb": "uppercase",
            "args": {
                "source_column": config.get("source_column", "text"),
                "target_column": config.get("target_column", "processed_text"),
            },
        },
        {
            "verb": "derive",
            "args": {
                "column1": config.get("target_column", "processed_text"),
                "to": "text_length",
                "operator": "len",
            },
        }
    ]

custom_workflows = {
    "text_processing": create_text_processing_workflow,
}
```

2. Create a file `custom_pipeline.yml`:

```yaml
workflows:
  - name: text_processing
    config:
      source_column: "original_text"
      target_column: "uppercase_text"
```

3. Create a file `run_custom_pipeline.py`:

```python
import asyncio
import pandas as pd
from graphrag.index import run_pipeline_with_config
from custom_components import custom_verbs, custom_workflows

async def main():
    # Sample dataset
    dataset = pd.DataFrame({
        "original_text": ["Hello, World!", "GraphRAG is awesome", "Custom components rock"]
    })

    config_path = "custom_pipeline.yml"
    
    async for output in run_pipeline_with_config(
        config_or_path=config_path,
        dataset=dataset,
        additional_verbs=custom_verbs,
        additional_workflows=custom_workflows,
    ):
        print(output.result)

if __name__ == "__main__":
    asyncio.run(main())
```

4. Run the script:

```bash
python run_custom_pipeline.py
```

This exercise demonstrates how to create and integrate custom verbs and workflows into a GraphRAG pipeline.

## 8. Recap and Next Steps

In this lesson, we covered:
- Creating custom verbs
- Defining custom workflows
- Integrating custom components into the GraphRAG pipeline
- Best practices for extending GraphRAG
- Techniques for improving workflow reusability and modularity

Next steps:
1. Experiment with creating more complex custom verbs and workflows.
2. Explore how to integrate external libraries or APIs into custom components.
3. Develop a suite of reusable custom components for your specific use case.
4. Learn how to optimize custom components for large-scale data processing.

In the next lesson, we'll dive into the Query Engine basics, exploring how GraphRAG processes and answers queries using the knowledge graph we've built.

