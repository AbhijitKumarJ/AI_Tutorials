# Lesson 5: Advanced Indexing Pipeline Concepts

## Table of Contents
1. [Introduction](#introduction)
2. [Multiple Workflows and Their Interdependencies](#multiple-workflows)
3. [Custom Input Handlers](#custom-input-handlers)
4. [Working with CSV and Text Input Data](#csv-and-text-input)
5. [Chunking and Embedding Concepts](#chunking-and-embedding)
6. [Workflow DAGs and Execution Order](#workflow-dags)
7. [Practical Example](#practical-example)
8. [Conclusion and Next Steps](#conclusion)

<a name="introduction"></a>
## 1. Introduction

Welcome to Lesson 5 of our GraphRAG series. In this lesson, we'll dive deeper into advanced concepts of the GraphRAG indexing pipeline. We'll explore how to work with multiple workflows, handle custom inputs, process different data types, and understand the intricacies of workflow execution order. By the end of this lesson, you'll have a solid grasp of these advanced concepts and be able to create more complex and efficient indexing pipelines.

<a name="multiple-workflows"></a>
## 2. Multiple Workflows and Their Interdependencies

In complex data processing scenarios, you often need to break down your pipeline into multiple workflows. GraphRAG allows you to define and manage multiple workflows, including specifying dependencies between them.

### 2.1 Defining Multiple Workflows

You can define multiple workflows in your pipeline configuration file or using the Python API. Here's an example of how you might define multiple workflows in a YAML configuration file:

```yaml
workflows:
  - name: workflow1
    steps:
      - verb: derive
        args:
          column1: "col1"
          column2: "col2"
          to: "derived_column"
          operator: "*"

  - name: workflow2
    steps:
      - verb: aggregate
        args:
          groupby: "category"
          column: "derived_column"
          to: "aggregated_column"
          operation: "sum"
        input:
          source: "workflow:workflow1"
```

In this example, we have two workflows: `workflow1` and `workflow2`. The second workflow depends on the output of the first workflow.

### 2.2 Workflow Dependencies

GraphRAG automatically handles workflow dependencies based on the `input` specification in each workflow or step. In the example above, `workflow2` depends on `workflow1` because it specifies `source: "workflow:workflow1"` in its input.

The indexing engine will automatically determine the correct order of execution based on these dependencies, ensuring that workflows are executed in the proper sequence.

### 2.3 Benefits of Multiple Workflows

Using multiple workflows allows you to:

1. Break down complex pipelines into manageable parts
2. Reuse common processing steps across different pipelines
3. Improve readability and maintainability of your pipeline configurations
4. Enable parallel processing of independent workflows

<a name="custom-input-handlers"></a>
## 3. Custom Input Handlers

While GraphRAG provides built-in input handlers for common scenarios, you may need to create custom input handlers for specific data sources or formats.

### 3.1 Creating a Custom Input Handler

To create a custom input handler, you need to implement the `InputHandler` interface. Here's an example of a custom input handler that reads data from a specific API:

```python
from graphrag.index.input import InputHandler, InputConfig
import pandas as pd
import requests

class APIInputHandler(InputHandler):
    def __init__(self, config: InputConfig):
        super().__init__(config)
        self.api_url = config.get("api_url")
        self.api_key = config.get("api_key")

    async def load(self) -> pd.DataFrame:
        response = requests.get(self.api_url, headers={"Authorization": f"Bearer {self.api_key}"})
        data = response.json()
        return pd.DataFrame(data)
```

### 3.2 Using a Custom Input Handler

To use your custom input handler, you need to register it with the pipeline. You can do this by passing it to the `run_pipeline` function:

```python
from graphrag.index import run_pipeline
from your_module import APIInputHandler

custom_input_handlers = {
    "api": APIInputHandler
}

async for output in run_pipeline(
    config_or_path="your_config.yml",
    additional_input_handlers=custom_input_handlers
):
    # Process output
```

In your configuration file, you can then specify the custom input handler:

```yaml
input:
  type: api
  api_url: "https://api.example.com/data"
  api_key: "your-api-key"
```

<a name="csv-and-text-input"></a>
## 4. Working with CSV and Text Input Data

GraphRAG provides built-in support for CSV and text input data. Let's explore how to work with these data types effectively.

### 4.1 CSV Input

To work with CSV input, you can use the following configuration:

```yaml
input:
  type: file
  file_type: csv
  base_dir: "./data"
  file_pattern: ".*\\.csv$"
  source_column: "author"
  text_column: "content"
  timestamp_column: "created_at"
  timestamp_format: "%Y-%m-%d %H:%M:%S"
```

This configuration tells GraphRAG to:
- Look for CSV files in the "./data" directory
- Use regular expression ".*\\.csv$" to match CSV files
- Map specific columns to GraphRAG's internal schema

### 4.2 Text Input

For text input, you can use a similar configuration:

```yaml
input:
  type: file
  file_type: text
  base_dir: "./data"
  file_pattern: ".*\\.txt$"
```

This configuration will process all .txt files in the "./data" directory as individual documents.

### 4.3 Post-processing Input Data

You can apply post-processing steps to your input data using the `post_process` configuration:

```yaml
input:
  # ... (other input configuration)
  post_process:
    - verb: filter
      args:
        column: "category"
        value: "relevant"
    - verb: sample
      args:
        size: 1000
```

This example filters the input data to include only rows where the "category" is "relevant", and then samples 1000 rows from the result.

<a name="chunking-and-embedding"></a>
## 5. Chunking and Embedding Concepts

Chunking and embedding are crucial concepts in GraphRAG for processing and representing textual data.

### 5.1 Chunking

Chunking involves breaking down large texts into smaller, manageable pieces. This is important for several reasons:
- It allows for more granular analysis of text
- It helps in fitting text within token limits of language models
- It enables more precise retrieval of relevant information

You can configure chunking in GraphRAG like this:

```yaml
chunks:
  size: 1000
  overlap: 100
  encoding_model: "cl100k_base"
```

This configuration creates chunks of 1000 tokens with an overlap of 100 tokens, using the "cl100k_base" encoding model.

### 5.2 Embedding

Embedding is the process of converting text into dense vector representations. These embeddings capture semantic meaning and are used for various downstream tasks like similarity search.

GraphRAG uses embeddings for entities, relationships, and text chunks. You can configure embedding like this:

```yaml
embeddings:
  type: openai_embedding
  model: text-embedding-ada-002
  batch_size: 100
```

This configuration uses OpenAI's text-embedding-ada-002 model to generate embeddings, processing 100 items at a time.

<a name="workflow-dags"></a>
## 6. Workflow DAGs and Execution Order

GraphRAG pipelines can be thought of as Directed Acyclic Graphs (DAGs) of workflows and steps. Understanding this concept is crucial for designing efficient pipelines.

### 6.1 DAG Concept

In a DAG:
- Nodes represent workflows or steps
- Edges represent dependencies between nodes
- There are no cycles (hence "acyclic")

### 6.2 Execution Order

GraphRAG automatically determines the execution order based on the dependencies specified in your configuration. For example:

```yaml
workflows:
  - name: workflow_A
    steps:
      - verb: derive
        args: { /* ... */ }

  - name: workflow_B
    steps:
      - verb: aggregate
        args: { /* ... */ }
        input:
          source: "workflow:workflow_A"

  - name: workflow_C
    steps:
      - verb: filter
        args: { /* ... */ }
        input:
          source: "workflow:workflow_A"
```

In this case, `workflow_A` will execute first, followed by `workflow_B` and `workflow_C` (which can potentially run in parallel).

### 6.3 Parallelization

GraphRAG can parallelize independent workflows and steps. In the example above, `workflow_B` and `workflow_C` could potentially run in parallel if the execution engine determines it's safe and efficient to do so.

<a name="practical-example"></a>
## 7. Practical Example

Let's put all these concepts together in a practical example. We'll create a pipeline that processes a dataset of book reviews, extracts entities, and generates a summary report.

First, let's look at the file structure:

```
project_root/
├── data/
│   ├── book_reviews.csv
│   └── additional_info.txt
├── config/
│   └── pipeline.yml
└── run_pipeline.py
```

Now, let's create the `pipeline.yml` configuration:

```yaml
input:
  type: file
  file_type: csv
  base_dir: "./data"
  file_pattern: "book_reviews\\.csv$"
  source_column: "user"
  text_column: "review"
  timestamp_column: "date"
  timestamp_format: "%Y-%m-%d"

  post_process:
    - verb: filter
      args:
        column: "rating"
        operator: ">="
        value: 4

chunks:
  size: 500
  overlap: 50

embeddings:
  type: openai_embedding
  model: text-embedding-ada-002
  batch_size: 50

workflows:
  - name: entity_extraction
    config:
      entity_extract:
        strategy:
          type: nltk

  - name: sentiment_analysis
    steps:
      - verb: derive
        args:
          column: "review"
          to: "sentiment"
          function: "analyze_sentiment"

  - name: aggregation
    steps:
      - verb: aggregate
        args:
          groupby: "book_title"
          column: "sentiment"
          to: "avg_sentiment"
          operation: "mean"
        input:
          source: "workflow:sentiment_analysis"

  - name: report_generation
    steps:
      - verb: custom.generate_report
        args:
          entities_source: "workflow:entity_extraction"
          sentiment_source: "workflow:aggregation"
        input:
          source: "workflow:aggregation"
```

Now, let's create the `run_pipeline.py` script:

```python
import asyncio
from graphrag.index import run_pipeline_with_config
import pandas as pd
from textblob import TextBlob

def analyze_sentiment(text):
    return TextBlob(text).sentiment.polarity

def generate_report(df, entities_df, sentiment_df):
    # Custom report generation logic
    pass

custom_verbs = {
    "analyze_sentiment": analyze_sentiment,
    "generate_report": generate_report
}

async def main():
    async for result in run_pipeline_with_config(
        config_or_path="./config/pipeline.yml",
        additional_verbs=custom_verbs
    ):
        print(f"Completed workflow: {result.workflow}")
        if result.workflow == "report_generation":
            print("Final report:")
            print(result.result)

if __name__ == "__main__":
    asyncio.run(main())
```

This example demonstrates:
- Custom input handling for CSV files
- Multiple interdependent workflows
- Chunking and embedding configuration
- Custom verb definitions
- Complex workflow DAG with entity extraction, sentiment analysis, and report generation

<a name="conclusion"></a>
## 8. Conclusion and Next Steps

In this lesson, we've covered advanced concepts of the GraphRAG indexing pipeline, including:
- Working with multiple workflows and their interdependencies
- Creating and using custom input handlers
- Processing CSV and text input data
- Understanding chunking and embedding concepts
- Grasping workflow DAGs and execution order

These concepts provide a solid foundation for creating complex, efficient data processing pipelines with GraphRAG. In the next lesson, we'll dive deeper into entity extraction techniques, exploring how GraphRAG can identify and process entities from your data.

To reinforce your learning, try to:
1. Modify the practical example to include additional data sources or processing steps
2. Experiment with different chunking and embedding configurations
3. Create a custom input handler for a specific data format you work with

Remember, the key to mastering these concepts is practice and experimentation. Don't hesitate to consult the GraphRAG documentation and community resources as you work on more advanced pipelines.

