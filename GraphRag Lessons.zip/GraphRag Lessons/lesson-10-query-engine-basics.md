# Lesson 10: Query Engine Basics

## Table of Contents
1. Introduction to the Query Engine
2. Understanding Local Search
3. Implementing Global Search
4. Question Generation Capabilities
5. Query Result Interpretation
6. Hands-on Exercise
7. Recap and Next Steps

## 1. Introduction to the Query Engine

The Query Engine is a crucial component of GraphRAG, responsible for processing user queries and retrieving relevant information from the knowledge graph. It leverages the structured data created by the Indexing Pipeline to provide accurate and context-aware responses.

Key components of the Query Engine:
- Local Search: For entity-specific queries
- Global Search: For dataset-wide queries
- Question Generation: For generating follow-up questions
- Result Interpretation: For presenting query results in a user-friendly format

File Layout:
```
graphrag/
└── query/
    ├── __init__.py
    ├── indexer_adapters.py
    ├── structured_search/
    │   ├── __init__.py
    │   ├── local_search/
    │   │   ├── __init__.py
    │   │   ├── mixed_context.py
    │   │   └── search.py
    │   └── global_search/
    │       ├── __init__.py
    │       ├── community_context.py
    │       └── search.py
    └── question_gen/
        ├── __init__.py
        └── local_gen.py
```

## 2. Understanding Local Search

Local Search is designed to answer queries about specific entities or relationships within the knowledge graph. It combines relevant data from the graph with text chunks from the original documents.

### How Local Search Works

1. Entity Extraction: Identifies entities in the user query.
2. Context Building: Retrieves relevant entities, relationships, and text chunks.
3. LLM Integration: Uses an LLM to generate a response based on the context.

### Implementing Local Search

```python
from graphrag.query.structured_search.local_search.search import LocalSearch
from graphrag.query.structured_search.local_search.mixed_context import LocalSearchMixedContext

# Initialize LocalSearch
local_search = LocalSearch(
    llm=llm,
    context_builder=LocalSearchMixedContext(
        community_reports=reports,
        text_units=text_units,
        entities=entities,
        relationships=relationships,
        entity_text_embeddings=description_embedding_store,
        text_embedder=text_embedder,
        token_encoder=token_encoder,
    ),
    token_encoder=token_encoder,
    llm_params=llm_params,
    context_builder_params=local_context_params,
    response_type="multiple paragraphs"
)

# Perform a local search
result = await local_search.asearch("Tell me about Entity X")
print(result.response)
```

## 3. Implementing Global Search

Global Search is used for queries that require an understanding of the entire dataset. It uses a map-reduce approach to analyze all community reports generated during the indexing phase.

### How Global Search Works

1. Context Preparation: Splits community reports into manageable chunks.
2. Mapping: Generates intermediate responses for each chunk.
3. Reducing: Aggregates and summarizes intermediate responses.
4. Final Response: Generates a comprehensive answer based on the aggregated information.

### Implementing Global Search

```python
from graphrag.query.structured_search.global_search.search import GlobalSearch
from graphrag.query.structured_search.global_search.community_context import GlobalCommunityContext

# Initialize GlobalSearch
global_search = GlobalSearch(
    llm=llm,
    context_builder=GlobalCommunityContext(
        community_reports=reports,
        entities=entities,
        token_encoder=token_encoder,
    ),
    token_encoder=token_encoder,
    max_data_tokens=12000,
    map_llm_params=map_llm_params,
    reduce_llm_params=reduce_llm_params,
    context_builder_params=context_builder_params,
    concurrent_coroutines=32,
    response_type="multiple paragraphs"
)

# Perform a global search
result = await global_search.asearch("What are the main themes in the dataset?")
print(result.response)
```

## 4. Question Generation Capabilities

The Question Generation feature in GraphRAG helps create follow-up questions based on the current context and conversation history. This is useful for guiding users through an exploratory analysis of the dataset.

### How Question Generation Works

1. Context Analysis: Examines the current conversation context and relevant entities.
2. LLM Integration: Uses an LLM to generate potential follow-up questions.
3. Ranking: Prioritizes questions based on relevance and importance.

### Implementing Question Generation

```python
from graphrag.query.question_gen.local_gen import LocalQuestionGen

# Initialize QuestionGenerator
question_generator = LocalQuestionGen(
    llm=llm,
    context_builder=context_builder,
    token_encoder=token_encoder,
    llm_params=llm_params,
    context_builder_params=local_context_params,
)

# Generate questions
question_history = [
    "Tell me about Entity X",
    "What is Entity X's relationship with Entity Y?",
]
candidate_questions = await question_generator.agenerate(
    question_history=question_history, 
    context_data=None, 
    question_count=5
)
print(candidate_questions.response)
```

## 5. Query Result Interpretation

Interpreting query results is crucial for presenting information in a user-friendly manner. GraphRAG provides structures for organizing and displaying query results.

### Components of Query Results

1. Response: The main textual answer to the query.
2. Context Data: Relevant entities, relationships, and text chunks used to generate the response.
3. Metadata: Information about the search process, such as the number of LLM calls and tokens used.

### Analyzing Query Results

```python
# Assuming 'result' is the output from a search operation

# Print the main response
print(result.response)

# Examine context data
if "entities" in result.context_data:
    print("Relevant entities:", result.context_data["entities"].head())

if "relationships" in result.context_data:
    print("Relevant relationships:", result.context_data["relationships"].head())

if "text_units" in result.context_data:
    print("Relevant text chunks:", result.context_data["text_units"].head())

# Check metadata
print(f"LLM calls: {result.llm_calls}")
print(f"Tokens used: {result.prompt_tokens}")
```

## 6. Hands-on Exercise

Let's create a simple script that demonstrates the use of both Local and Global search capabilities of GraphRAG.

1. Create a file named `query_engine_demo.py`:

```python
import asyncio
import os
import pandas as pd
import tiktoken
from graphrag.query.indexer_adapters import (
    read_indexer_entities,
    read_indexer_relationships,
    read_indexer_reports,
    read_indexer_text_units,
)
from graphrag.query.llm.oai.chat_openai import ChatOpenAI
from graphrag.query.llm.oai.embedding import OpenAIEmbedding
from graphrag.query.structured_search.local_search.mixed_context import LocalSearchMixedContext
from graphrag.query.structured_search.local_search.search import LocalSearch
from graphrag.query.structured_search.global_search.community_context import GlobalCommunityContext
from graphrag.query.structured_search.global_search.search import GlobalSearch

# Load your data (replace with actual paths)
entity_df = pd.read_parquet("path/to/entities.parquet")
relationship_df = pd.read_parquet("path/to/relationships.parquet")
report_df = pd.read_parquet("path/to/community_reports.parquet")
text_unit_df = pd.read_parquet("path/to/text_units.parquet")

# Process data
entities = read_indexer_entities(entity_df, entity_df, 2)
relationships = read_indexer_relationships(relationship_df)
reports = read_indexer_reports(report_df, entity_df, 2)
text_units = read_indexer_text_units(text_unit_df)

# Initialize LLM and embedding model
api_key = os.environ["OPENAI_API_KEY"]
llm = ChatOpenAI(api_key=api_key, model="gpt-3.5-turbo")
text_embedder = OpenAIEmbedding(api_key=api_key, model="text-embedding-ada-002")
token_encoder = tiktoken.get_encoding("cl100k_base")

# Initialize Local Search
local_search = LocalSearch(
    llm=llm,
    context_builder=LocalSearchMixedContext(
        community_reports=reports,
        text_units=text_units,
        entities=entities,
        relationships=relationships,
        text_embedder=text_embedder,
        token_encoder=token_encoder,
    ),
    token_encoder=token_encoder,
    llm_params={"max_tokens": 2000, "temperature": 0.0},
    context_builder_params={"max_tokens": 12000},
    response_type="multiple paragraphs"
)

# Initialize Global Search
global_search = GlobalSearch(
    llm=llm,
    context_builder=GlobalCommunityContext(
        community_reports=reports,
        entities=entities,
        token_encoder=token_encoder,
    ),
    token_encoder=token_encoder,
    max_data_tokens=12000,
    map_llm_params={"max_tokens": 500, "temperature": 0.0},
    reduce_llm_params={"max_tokens": 2000, "temperature": 0.0},
    context_builder_params={"max_tokens": 12000},
    concurrent_coroutines=32,
    response_type="multiple paragraphs"
)

async def main():
    # Local Search example
    local_result = await local_search.asearch("Tell me about the main character in the story")
    print("Local Search Result:")
    print(local_result.response)
    print("\n")

    # Global Search example
    global_result = await global_search.asearch("What are the main themes in the story?")
    print("Global Search Result:")
    print(global_result.response)

if __name__ == "__main__":
    asyncio.run(main())
```

2. Run the script:

```bash
python query_engine_demo.py
```

This exercise demonstrates how to use both Local and Global search capabilities of the GraphRAG Query Engine on a dataset.

## 7. Recap and Next Steps

In this lesson, we covered:
- Introduction to the GraphRAG Query Engine
- Understanding and implementing Local Search
- Understanding and implementing Global Search
- Question Generation capabilities
- Interpreting query results
- A hands-on exercise demonstrating the use of the Query Engine

Next steps:
1. Experiment with different types of queries using both Local and Global search.
2. Explore how to customize the context building process for specific use cases.
3. Implement question generation in a conversational AI application.
4. Analyze the performance and accuracy of different search strategies on your dataset.
5. Learn how to optimize query processing for large-scale knowledge graphs.

In the next lesson, we'll dive into advanced Query Engine features, including customizing search strategies and optimizing query performance.

