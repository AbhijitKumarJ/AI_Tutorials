# Lesson 11: Advanced Query Engine Features

## Table of Contents
1. Introduction
2. Customizing Search Strategies
3. Working with Community Reports
4. Optimizing Query Performance
5. Handling Conversation History
6. Entity-Based Reasoning Techniques
7. Practical Examples
8. Conclusion and Next Steps

## 1. Introduction

Welcome to Lesson 11 of our GraphRAG series! In this lesson, we'll dive deeper into the advanced features of the Query Engine. By the end of this lesson, you'll have a comprehensive understanding of how to customize and optimize your queries, work with community reports, handle conversation history, and leverage entity-based reasoning techniques.

Before we begin, ensure you have completed the previous lessons and have a working GraphRAG environment set up.

## 2. Customizing Search Strategies

GraphRAG provides two main search strategies: Local Search and Global Search. In this section, we'll explore how to customize these strategies for more specific use cases.

### 2.1 Local Search Customization

Local search is ideal for questions about specific entities. Let's look at how to customize it:

```python
from graphrag.query.structured_search.local_search import LocalSearch
from graphrag.query.structured_search.local_search.mixed_context import LocalSearchMixedContext

# Customizing Local Search
custom_local_search = LocalSearch(
    llm=your_llm_instance,
    context_builder=LocalSearchMixedContext(
        community_reports=your_reports,
        text_units=your_text_units,
        entities=your_entities,
        relationships=your_relationships,
        covariates=your_covariates,
        entity_text_embeddings=your_embedding_store,
        embedding_vectorstore_key=EntityVectorStoreKey.ID,
        text_embedder=your_text_embedder,
        token_encoder=your_token_encoder,
    ),
    token_encoder=your_token_encoder,
    llm_params={
        "max_tokens": 2000,
        "temperature": 0.1,
    },
    context_builder_params={
        "text_unit_prop": 0.6,
        "community_prop": 0.2,
        "top_k_mapped_entities": 15,
        "top_k_relationships": 12,
        "max_tokens": 10000,
    },
    response_type="detailed analysis",
)
```

In this example, we're customizing various aspects of the local search:
- Adjusting the proportion of text units and community reports used in the context
- Increasing the number of mapped entities and relationships considered
- Modifying LLM parameters for more detailed and slightly more creative responses
- Specifying a custom response type

### 2.2 Global Search Customization

Global search is better for questions about overall themes or patterns. Here's how to customize it:

```python
from graphrag.query.structured_search.global_search import GlobalSearch
from graphrag.query.structured_search.global_search.community_context import GlobalCommunityContext

# Customizing Global Search
custom_global_search = GlobalSearch(
    llm=your_llm_instance,
    context_builder=GlobalCommunityContext(
        community_reports=your_reports,
        entities=your_entities,
        token_encoder=your_token_encoder,
    ),
    token_encoder=your_token_encoder,
    max_data_tokens=15000,
    map_llm_params={
        "max_tokens": 800,
        "temperature": 0.0,
    },
    reduce_llm_params={
        "max_tokens": 2500,
        "temperature": 0.1,
    },
    context_builder_params={
        "use_community_summary": True,
        "include_community_rank": True,
        "include_community_weight": True,
        "max_tokens": 15000,
    },
    concurrent_coroutines=64,
    response_type="comprehensive overview",
)
```

In this global search customization:
- We're increasing the token limits for more comprehensive analysis
- Using community summaries instead of full reports for a higher-level view
- Including community rank and weight for better context
- Increasing concurrency for faster processing
- Specifying a custom response type for more detailed outputs

## 3. Working with Community Reports

Community reports are a powerful feature of GraphRAG, providing summaries of entity clusters. Here's how to leverage them effectively:

```python
# Assuming you have already loaded your community reports
from graphrag.query.indexer_adapters import read_indexer_reports

# Load community reports
community_reports = read_indexer_reports(report_df, entity_df, COMMUNITY_LEVEL)

# Incorporate community reports into your search context
context_builder = LocalSearchMixedContext(
    community_reports=community_reports,
    # ... other parameters ...
)

# Use in your search engine
search_engine = LocalSearch(
    context_builder=context_builder,
    # ... other parameters ...
    context_builder_params={
        "community_prop": 0.3,  # Increase the proportion of community reports
        # ... other parameters ...
    }
)

# Execute a query that leverages community information
result = await search_engine.asearch("What are the main themes across all communities?")
print(result.response)
```

By increasing the `community_prop` parameter, we're telling the search engine to rely more heavily on community reports when formulating responses. This is particularly useful for questions that require a broad understanding of the entire dataset.

## 4. Optimizing Query Performance

To optimize query performance, consider the following strategies:

### 4.1 Caching

Implement caching to store frequently accessed data:

```python
from graphrag.query.cache import InMemoryCache

# Create a cache instance
cache = InMemoryCache()

# Use the cache in your search engine
search_engine = LocalSearch(
    # ... other parameters ...
    cache=cache,
)
```

### 4.2 Parallel Processing

Utilize parallel processing for global searches:

```python
custom_global_search = GlobalSearch(
    # ... other parameters ...
    concurrent_coroutines=128,  # Increase for more parallelism
)
```

### 4.3 Optimizing Token Usage

Carefully manage your token usage to prevent hitting API limits:

```python
search_engine = LocalSearch(
    # ... other parameters ...
    context_builder_params={
        "max_tokens": 8000,  # Adjust based on your model's context window
        "text_unit_prop": 0.4,  # Reduce if you need more space for other context
        "community_prop": 0.1,
    },
    llm_params={
        "max_tokens": 1500,  # Adjust based on desired response length
    }
)
```

## 5. Handling Conversation History

GraphRAG can maintain conversation history for more contextual responses. Here's how to implement it:

```python
# Initialize conversation history
conversation_history = []

# Function to update conversation history
def update_history(question, answer):
    conversation_history.append({"question": question, "answer": answer})
    # Keep only the last 5 interactions
    if len(conversation_history) > 5:
        conversation_history.pop(0)

# Use in your search engine
search_engine = LocalSearch(
    # ... other parameters ...
    context_builder_params={
        "conversation_history_max_turns": 5,
        "conversation_history_user_turns_only": False,
    }
)

# Example usage in a conversation loop
while True:
    question = input("Ask a question (or type 'exit' to quit): ")
    if question.lower() == 'exit':
        break
    
    result = await search_engine.asearch(question, conversation_history=conversation_history)
    print(result.response)
    
    update_history(question, result.response)
```

This implementation allows the search engine to consider previous interactions when formulating responses, leading to more coherent multi-turn conversations.

## 6. Entity-Based Reasoning Techniques

Entity-based reasoning is at the core of GraphRAG's power. Here's how to leverage it effectively:

### 6.1 Entity Extraction

First, ensure your entities are properly extracted:

```python
from graphrag.query.indexer_adapters import read_indexer_entities

entities = read_indexer_entities(entity_df, entity_embedding_df, COMMUNITY_LEVEL)
```

### 6.2 Entity Relationships

Leverage entity relationships for more insightful queries:

```python
from graphrag.query.indexer_adapters import read_indexer_relationships

relationships = read_indexer_relationships(relationship_df)

search_engine = LocalSearch(
    context_builder=LocalSearchMixedContext(
        entities=entities,
        relationships=relationships,
        # ... other parameters ...
    ),
    # ... other parameters ...
)

# Example query leveraging entity relationships
result = await search_engine.asearch("How is Entity A connected to Entity B?")
print(result.response)
```

### 6.3 Entity Embeddings

Utilize entity embeddings for semantic similarity searches:

```python
from graphrag.vector_stores.lancedb import LanceDBVectorStore

# Assuming you have already created your embedding store
embedding_store = LanceDBVectorStore(collection_name="entity_embeddings")

search_engine = LocalSearch(
    context_builder=LocalSearchMixedContext(
        # ... other parameters ...
        entity_text_embeddings=embedding_store,
    ),
    # ... other parameters ...
)

# Example query leveraging entity embeddings
result = await search_engine.asearch("Find entities similar to 'artificial intelligence'")
print(result.response)
```

## 7. Practical Examples

Let's put it all together with some practical examples:

### 7.1 Complex Query with Entity Reasoning

```python
# Assuming all necessary imports and initializations

search_engine = LocalSearch(
    llm=your_llm_instance,
    context_builder=LocalSearchMixedContext(
        community_reports=community_reports,
        text_units=text_units,
        entities=entities,
        relationships=relationships,
        entity_text_embeddings=embedding_store,
        text_embedder=text_embedder,
        token_encoder=token_encoder,
    ),
    token_encoder=token_encoder,
    llm_params={"max_tokens": 2000, "temperature": 0.1},
    context_builder_params={
        "text_unit_prop": 0.5,
        "community_prop": 0.2,
        "top_k_mapped_entities": 15,
        "top_k_relationships": 12,
        "max_tokens": 10000,
        "conversation_history_max_turns": 5,
    },
    response_type="detailed analysis",
)

query = "Analyze the relationship between AI development and ethical considerations across different research communities."

result = await search_engine.asearch(query, conversation_history=conversation_history)
print(result.response)

# Update conversation history
update_history(query, result.response)
```

### 7.2 Global Trend Analysis

```python
global_search = GlobalSearch(
    llm=your_llm_instance,
    context_builder=GlobalCommunityContext(
        community_reports=community_reports,
        entities=entities,
        token_encoder=token_encoder,
    ),
    token_encoder=token_encoder,
    max_data_tokens=15000,
    map_llm_params={"max_tokens": 800, "temperature": 0.0},
    reduce_llm_params={"max_tokens": 2500, "temperature": 0.1},
    context_builder_params={
        "use_community_summary": True,
        "include_community_rank": True,
        "include_community_weight": True,
        "max_tokens": 15000,
    },
    concurrent_coroutines=64,
    response_type="comprehensive overview",
)

query = "What are the top 5 emerging trends across all research communities in the past year?"

result = await global_search.asearch(query)
print(result.response)
```

## 8. Conclusion and Next Steps

In this lesson, we've explored advanced features of the GraphRAG Query Engine, including customizing search strategies, working with community reports, optimizing performance, handling conversation history, and leveraging entity-based reasoning techniques.

To further your understanding:
1. Experiment with different combinations of parameters to see how they affect query results.
2. Try implementing these techniques on your own dataset.
3. Explore how to combine local and global search strategies for more comprehensive analyses.

In the next lesson, we'll dive into data visualization techniques with GraphRAG, learning how to create insightful visual representations of our knowledge graphs and query results.

