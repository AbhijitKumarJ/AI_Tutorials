Ah, the key issue is that the Coder class isn't being properly overridden early enough. Let's fix this by modifying the initialization flow.

1. First, create a new file `custom_aider/monkey_patch.py`:

```python
"""Early monkey-patching of aider classes"""
import sys
from pathlib import Path

def monkey_patch_aider():
    """Monkey patch aider classes before any aider imports"""
    # Add our custom_aider to the Python path
    root_dir = Path(__file__).parent.parent
    if str(root_dir) not in sys.path:
        sys.path.insert(0, str(root_dir))
    
    # First override the Coder class
    import aider.coders as coders
    from custom_aider.custom_coder import CustomCoder
    coders.Coder = CustomCoder
    
    # Also patch the base coder
    from aider.coders.base_coder import Coder
    sys.modules['aider.coders.base_coder'].Coder = CustomCoder
    
    print("Custom aider classes loaded and patched")
```

2. Update `run.py`:

```python
#!/usr/bin/env python3
"""Main entry point for custom aider"""

# Apply patches before any aider imports
from custom_aider.monkey_patch import monkey_patch_aider
monkey_patch_aider()

# Now import the custom main
from custom_aider.custom_aider_main import custom_main
import sys

def main():
    """Main entry point"""
    return custom_main()

if __name__ == "__main__":
    sys.exit(main())
```

3. Update `custom_aider/custom_aider_main.py`:

```python
"""Custom aider main implementation"""
import sys
from pathlib import Path
from aider.main import main as aider_main
from .commands_registry import CommandsRegistry
import importlib
import logging

logger = logging.getLogger(__name__)

def load_command_modules():
    """Dynamically load all command modules"""
    logger.info("Loading command modules...")
    
    commands_dir = Path(__file__).parent / "commands"
    if not commands_dir.exists():
        logger.warning(f"Commands directory not found: {commands_dir}")
        return
        
    command_files = [
        f for f in commands_dir.glob("*.py")
        if not f.name.startswith("_") and f.name != "__init__.py"
    ]
    
    for command_file in command_files:
        module_name = f"custom_aider.commands.{command_file.stem}"
        try:
            importlib.import_module(module_name)
            logger.info(f"Loaded command module: {module_name}")
        except Exception as e:
            logger.error(f"Error loading command module {module_name}: {e}")
            
    logger.info(f"Loaded commands: {', '.join(CommandsRegistry.list_commands())}")

def initialize_custom_aider():
    """Initialize the custom aider environment"""
    # Initialize logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Load command modules
    load_command_modules()

def custom_main():
    """Run custom aider with extensions"""
    try:
        initialize_custom_aider()
        return aider_main()
    except Exception as e:
        logger.exception("Error in custom aider")
        raise
```

4. Update `custom_aider/custom_coder.py`:

```python
"""Custom coder implementation with command registry support"""
import logging
from typing import Optional, ClassVar
from aider.coders.base_coder import Coder as BaseCoder
from .commands_registry import CommandsRegistry

logger = logging.getLogger(__name__)

class CustomCoder(BaseCoder):
    """Enhanced Coder with custom command support"""
    
    _current_coder: ClassVar[Optional['CustomCoder']] = None
    
    @classmethod
    def create(cls, *args, **kwargs):
        """Create a coder instance with custom commands"""
        logger.info("Creating CustomCoder instance")
        
        # Create coder instance
        coder = super().create(*args, **kwargs)
        logger.info(f"Created coder with edit_format: {coder.edit_format}")
        
        # Install custom commands if not already installed
        if hasattr(coder, 'commands'):
            logger.info(f"Installing {len(CommandsRegistry._commands)} custom commands")
            CommandsRegistry.install_commands(coder.commands)
            
        # Store reference
        cls._current_coder = coder
        return coder
```

5. Update `setup.py`:

```python
from setuptools import setup, find_packages

setup(
    name="aider-extension",
    version="0.1.0",
    description="Custom extensions for aider",
    author="Your Name",
    author_email="your.email@example.com",
    packages=find_packages(),
    install_requires=[
        "aider-chat",
    ],
    entry_points={
        "console_scripts": [
            "aider-custom=run:main",
        ],
    },
)
```

6. Make sure your project structure is correct:

```
aider-extension/
├── run.py
├── setup.py
└── custom_aider/
    ├── __init__.py
    ├── monkey_patch.py
    ├── custom_aider_main.py
    ├── custom_coder.py
    ├── commands_registry.py
    └── commands/
        ├── __init__.py
        ├── git_commands.py
        └── utility_commands.py
```

7. To install and run:

```bash
# Uninstall any previous version
pip uninstall -y aider-extension

# Install in development mode
pip install -e .

# Run either via script:
python run.py

# Or via installed command:
aider-custom
```

The key changes:
1. Early monkey-patching of Aider classes before any imports
2. More robust class replacement
3. Better logging throughout
4. Cleaner initialization flow

You should now see the custom commands at startup. Let me know if you're still having issues or if you need any clarification.