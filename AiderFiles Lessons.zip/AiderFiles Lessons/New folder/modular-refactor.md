Here's a refactored modular structure for main.py:

1. config/
   - settings.py - Configuration and settings management
   - arguments.py - Command line argument parsing

2. core/
   - setup.py - Core setup and initialization
   - models.py - Model management and registration
   - analytics.py - Analytics functionality
   - git.py - Git repository management 
   - coder.py - Coder instance management

3. utils/
   - checks.py - Various validation and check functions
   - helpers.py - Helper utility functions
   - messages.py - Message formatting and handling

config/settings.py:
```python
import os
import platform
from pathlib import Path

class Settings:
    """
    Global settings and configuration management.
    Handles environment variables, paths, and configuration state.
    """
    def __init__(self):
        self.root = None
        self.encoding = 'utf-8'
        self.config_files = []
        self.git_root = None
        self.analytics = None
        
    def load_env_files(self, git_root, dotenv_fname):
        """Load environment variables from .env files"""
        dotenv_files = self.generate_search_path_list(
            ".env",
            git_root,
            dotenv_fname,
        )
        loaded = []
        for fname in dotenv_files:
            try:
                if Path(fname).exists():
                    load_dotenv(fname, override=True, encoding=self.encoding)
                    loaded.append(fname)
            except OSError as e:
                print(f"OSError loading {fname}: {e}")
            except Exception as e:
                print(f"Error loading {fname}: {e}")
        return loaded

    def generate_search_path_list(self, default_file, git_root, command_line_file):
        """Generate prioritized list of configuration file paths"""
        files = []
        files.append(Path.home() / default_file) # homedir
        if git_root:
            files.append(Path(git_root) / default_file) # git root
        files.append(default_file) 
        if command_line_file:
            files.append(command_line_file)

        resolved_files = []
        for fn in files:
            try:
                resolved_files.append(Path(fn).resolve())
            except OSError:
                pass

        files = resolved_files
        files.reverse()
        uniq = []
        for fn in files:
            if fn not in uniq:
                uniq.append(fn)
        uniq.reverse()
        files = uniq
        files = list(map(str, files))
        files = list(dict.fromkeys(files))

        return files

config/arguments.py:
```python
import argparse
import os
from pathlib import Path

def get_parser(default_config_files, git_root):
    """
    Configure and return argument parser
    """
    parser = argparse.ArgumentParser(
        description="aider is AI pair programming in your terminal",
        add_config_file_help=True, 
        default_config_files=default_config_files,
        config_file_parser_class=configargparse.YAMLConfigFileParser,
        auto_env_var_prefix="AIDER_",
    )
    
    # Add argument groups and arguments
    add_main_args(parser)
    add_model_args(parser) 
    add_git_args(parser)
    add_io_args(parser)
    add_analytics_args(parser)
    
    return parser

def add_main_args(parser):
    """Add main program arguments"""
    group = parser.add_argument_group("Main")
    group.add_argument(
        "files", metavar="FILE", nargs="*", 
        help="files to edit with an LLM (optional)"
    )
    # Add other main arguments...

def add_model_args(parser):
    """Add model-related arguments""" 
    group = parser.add_argument_group("Model Settings")
    # Add model arguments...

# Additional argument group functions...

core/setup.py:
```python
from pathlib import Path
import sys

from aider.models import Model
from aider.io import InputOutput
from aider.coder import Coder
from aider.git import GitRepo

class Setup:
    """
    Handles application setup and initialization
    """
    def __init__(self, settings):
        self.settings = settings
        
    def initialize(self, args):
        """Initialize all components"""
        self.setup_io(args)
        self.setup_git(args)
        self.setup_models(args)
        self.setup_coder(args)
        
    def setup_io(self, args):
        """Initialize IO handling"""
        self.io = InputOutput(
            pretty=args.pretty,
            yes=args.yes_always,
            input_history_file=args.input_history_file,
            chat_history_file=args.chat_history_file,
            encoding=args.encoding
        )
        
    def setup_git(self, args):
        """Initialize git repository"""
        if args.git:
            try:
                self.repo = GitRepo(self.io, self.settings.files, args.git_dir)
                if args.gitignore:
                    self.check_gitignore()
            except FileNotFoundError:
                pass
                
    def setup_models(self, args):
        """Initialize models"""
        self.main_model = Model(args.model)
        register_models(self.settings.git_root, args.model_settings_file)
        register_litellm_models(self.settings.git_root, args.model_metadata_file)
        
    def setup_coder(self, args):
        """Initialize coder instance"""
        self.coder = Coder.create(
            main_model=self.main_model,
            io=self.io,
            repo=self.repo,
            # Other coder args...
        )

core/models.py:
```python
"""
Model registration and management functionality 
"""

def register_models(git_root, model_settings_fname):
    """Register model settings"""
    model_settings_files = generate_search_path_list(
        ".aider.model.settings.yml", git_root, model_settings_fname
    )

    files_loaded = []
    for fname in model_settings_files:
        try:
            if os.path.exists(fname):
                with open(fname) as f:
                    settings = yaml.safe_load(f)
                    register_model_settings(settings)
                files_loaded.append(fname)
        except Exception as e:
            raise Exception(f"Error loading model settings: {e}")
            
    return files_loaded

# Additional model management functions...
```

core/git.py:
```python
from pathlib import Path
import git

class GitManager:
    """
    Handles Git repository operations
    """
    def __init__(self, io):
        self.io = io
        self.repo = None
        
    def setup_git(self, git_root, io):
        """Initialize git repository"""
        if not git_root:
            return None
            
        try:
            self.repo = git.Repo(git_root)
            self._configure_git()
            return self.repo.working_tree_dir
        except git.InvalidGitRepositoryError:
            if io.confirm_ask("No git repo found, create one?"):
                return self._create_repo(git_root)
                
    def _configure_git(self):
        """Configure git settings"""
        with self.repo.config_writer() as git_config:
            if not git_config.has_option("user", "name"):
                git_config.set_value("user", "name", "Your Name")
            if not git_config.has_option("user", "email"):
                git_config.set_value("user", "email", "you@example.com")
                
    def _create_repo(self, path):
        """Create new git repository"""
        try:
            repo = git.Repo.init(path)
            self._configure_git(repo)
            return repo.working_tree_dir
        except git.GitError as err:
            self.io.tool_error(f"Unable to create git repo: {err}")
            return None

utils/checks.py:
```python
"""
Validation and check functions
"""

def check_config_files(config_files):
    """Check configuration files for issues"""
    found = False
    for config_file in config_files:
        if Path(config_file).exists():
            try:
                with open(config_file, 'r') as f:
                    for line in f:
                        if line.strip().startswith("yes:"):
                            print(f"Configuration error in {config_file}")
                            print("Please replace 'yes:' with 'yes-always:'")
                            found = True
            except Exception:
                pass
    return found

def check_git_root(io, git_root, fnames, git_dir):
    """Validate git root directory"""
    try:
        actual_root = GitRepo(io, fnames, git_dir).root
        if actual_root != git_root:
            return actual_root
    except Exception:
        pass
    return None

# Additional check functions...

utils/helpers.py:
```python
"""
Helper utility functions
"""

def safe_abs_path(path):
    """Get absolute path safely"""
    return str(Path(path).resolve())

def format_tokens(count):
    """Format token count for display"""
    if count < 1000:
        return str(count)
    elif count < 10000:
        return f"{count/1000:.1f}k"
    return f"{int(count/1000)}k"

# Additional helper functions...

utils/messages.py:
```python
"""
Message formatting and handling
"""

def format_content(role, content):
    """Format content with role prefix"""
    formatted_lines = []
    for line in content.splitlines():
        formatted_lines.append(f"{role} {line}")
    return "\n".join(formatted_lines)

def format_messages(messages, title=None):
    """Format message list for display"""
    output = []
    if title:
        output.append(f"{title.upper()} {'*' * 50}")

    for msg in messages:
        output.append("")
        role = msg["role"].upper()
        content = format_content(role, msg.get("content", ""))
        output.append(content)
        
    return "\n".join(output)

# Main application entrypoint
def main(argv=None, input=None, output=None, force_git_root=None):
    """
    Main application entrypoint
    """
    settings = Settings()
    
    # Parse command line arguments
    parser = get_parser(settings.config_files, settings.git_root)
    args = parser.parse_args(argv)
    
    # Load environment
    loaded_dotenvs = settings.load_env_files(settings.git_root, args.env_file)
    
    # Initialize setup
    setup = Setup(settings)
    setup.initialize(args)
    
    # Start application
    if args.gui:
        start_gui(args)
    else:
        start_cli(args, setup)
        
def start_cli(args, setup):
    """Start CLI interface"""
    setup.coder.show_announcements()
    
    if args.message:
        setup.coder.run(with_message=args.message)
    else:
        setup.coder.run()
        
if __name__ == "__main__":
    status = main()
    sys.exit(status)
```

This refactoring creates a cleaner, more modular structure by:

1. Organizing code into logical modules and packages:
   - config/ - Configuration and settings management
   - core/ - Core application functionality 
   - utils/ - Helper utilities and functions

2. Creating distinct classes with single responsibilities:
   - Settings - Configuration management
   - Setup - Application initialization
   - GitManager - Git operations
   
3. Separating concerns:
   - Argument parsing in dedicated module
   - Model management isolated
   - Git functionality encapsulated
   - Helper functions organized by purpose

4. Improving maintainability:
   - Each module has clear purpose
   - Related functionality grouped together
   - Reduced coupling between components
   - Better organized imports

5. Making code more testable:
   - Classes have clear interfaces
   - Dependencies are explicit
   - Functionality is isolated

This structure makes the code:
- More organized and maintainable
- Easier to test
- More extensible
- Clearer in its separation of concerns
- More modular and reusable

The main entry point now orchestrates the components while delegating the actual work to appropriate modules. Each module has a clear responsibility and interfaces with others through well-defined APIs.

