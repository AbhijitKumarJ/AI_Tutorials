# Lesson 1: Project Structure, Entry Point, and Configuration

## 1. Introduction

Welcome to our expanded first lesson on understanding the aider codebase! In this lesson, we'll explore the project structure, the entry point of the application, and dive deeper into the configuration and default settings. This comprehensive overview will give you a solid foundation for understanding how the various components of aider work together and how they can be configured.

## 2. Project Structure

Let's start by examining the overall structure of the project. Here's a more detailed view of the aider directory:

```
aider/
├── __init__.py
├── __main__.py
├── main.py
├── args.py
├── io.py
├── models.py
├── coder/
│   ├── __init__.py
│   ├── base_coder.py
│   ├── editblock_coder.py
│   ├── wholefile_coder.py
│   └── ... (other coder files)
├── commands.py
├── io.py
├── dump.py
├── repomap.py
├── sendchat.py
├── utils.py
├── prompts.py
└── ... (other modules and files)
```

Let's break down the key components and their roles:

- `__init__.py`: Makes the directory a Python package and defines the version.
- `__main__.py`: The entry point for running the package as a script.
- `main.py`: Contains the main application logic and orchestrates other components.
- `args.py`: Handles command-line argument parsing and default configurations.
- `io.py`: Manages input/output operations, including file reading/writing and user interactions.
- `models.py`: Defines the AI models used in the application and their configurations.
- `coder/`: A subdirectory containing different coder implementations for various editing strategies.
- `commands.py`: Implements the various commands available in the CLI.
- `repomap.py`: Handles repository mapping and analysis.
- `sendchat.py`: Manages communication with the AI model.
- `utils.py`: Contains utility functions used throughout the project.
- `prompts.py`: Stores predefined prompts for AI interactions.

## 3. Entry Point: __main__.py

The entry point of aider is the `__main__.py` file. Let's take a closer look:

from .main import main

if __name__ == "__main__":
    main()


This file is simple but crucial. Here's what it does:

1. `from .main import main`: Imports the `main` function from `main.py`.
2. `if __name__ == "__main__":`: Checks if the script is being run directly.
3. `main()`: Calls the `main()` function if run directly.

This structure allows the package to be run as a script using `python -m aider` or by running the aider directory.

## 4. The main() Function and Configuration

Now let's examine the `main()` function in `main.py` in more detail, focusing on configuration and default values:

```python
def main(argv=None, input=None, output=None, force_git_root=None, return_coder=False):
    # Determine git root
    git_root = force_git_root or get_git_root()

    # Get default config files
    default_config_files = generate_search_path_list(".aider.conf.yml", git_root, None)

    # Parse command-line arguments
    parser = get_parser(default_config_files, git_root)
    args = parser.parse_args(argv)

    # Load environment variables
    load_dotenv_files(git_root, args.env_file, args.encoding)

    # Set up model
    if not args.model:
        args.model = "gpt-4o-2024-08-06"  # Default model
        if os.environ.get("ANTHROPIC_API_KEY"):
            args.model = "claude-3-5-sonnet-20240620"  # Default for Anthropic

    main_model = models.Model(
        args.model,
        weak_model=args.weak_model,
        editor_model=args.editor_model,
        editor_edit_format=args.editor_edit_format
    )

    # Set up input/output
    io = InputOutput(
        pretty=args.pretty,
        yes=args.yes_always,
        input_history_file=args.input_history_file,
        chat_history_file=args.chat_history_file,
        user_input_color=args.user_input_color,
        tool_output_color=args.tool_output_color,
        tool_error_color=args.tool_error_color,
        encoding=args.encoding,
        # ... other parameters ...
    )

    # Set up repository
    if args.git:
        repo = GitRepo(
            io,
            fnames,
            git_dname,
            args.aiderignore,
            models=main_model.commit_message_models(),
            attribute_author=args.attribute_author,
            attribute_committer=args.attribute_committer,
            # ... other parameters ...
        )
    else:
        repo = None

    # Create the Coder instance
    coder = Coder.create(
        main_model=main_model,
        edit_format=args.edit_format,
        io=io,
        repo=repo,
        fnames=fnames,
        show_diffs=args.show_diffs,
        auto_commits=args.auto_commits,
        dirty_commits=args.dirty_commits,
        dry_run=args.dry_run,
        map_tokens=args.map_tokens,
        # ... other parameters ...
    )

    # Main application loop
    while True:
        try:
            user_message = coder.get_input()
            coder.run_one(user_message, preproc=True)
            coder.show_undo_hint()
        except KeyboardInterrupt:
            coder.keyboard_interrupt()

```

Let's break down the main steps and highlight the configuration aspects:

1. **Git Root Determination**: 
   - The function first tries to determine the git root directory.
   - This is used for finding configuration files and setting up the repository.

2. **Configuration Files**:
   - The function searches for `.aider.conf.yml` files in multiple locations:
     1. The current working directory
     2. The git root directory (if found)
     3. The user's home directory
   - This allows for project-specific, git-repo-specific, and global configurations.

3. **Argument Parsing**:
   - Command-line arguments are parsed using a parser defined in `args.py`.
   - The parser is initialized with the default config files, allowing for layered configuration.

4. **Environment Variables**:
   - Environment variables are loaded from `.env` files.
   - This allows for sensitive information (like API keys) to be kept out of the codebase.

5. **Model Selection and Initialization**:
   - If no model is specified, it defaults to "gpt-4o-2024-08-06".
   - If an Anthropic API key is present, it defaults to "claude-3-5-sonnet-20240620".
   - The `Model` class in `models.py` is used to initialize the main model, weak model, and editor model.

6. **Input/Output Setup**:
   - An `InputOutput` instance is created with various configuration options.
   - This includes settings for colors, file paths for input and chat history, and encoding.

7. **Repository Setup**:
   - If git is enabled (default), a `GitRepo` instance is created.
   - This sets up git integration with various options like author attribution and commit behavior.

8. **Coder Creation**:
   - A `Coder` instance is created using the `create` class method.
   - This method chooses the appropriate Coder subclass based on the `edit_format` argument.
   - Various options are passed to configure the Coder's behavior.

9. **Main Loop**:
   - The function enters a loop, continuously getting user input and processing it.
   - It handles keyboard interrupts gracefully.

## 5. Key Configuration Points

Let's highlight some important configuration aspects:

- **Command-line Arguments**: Defined in `args.py`, these allow users to customize behavior at runtime.
- **Configuration Files**: The `.aider.conf.yml` files allow for persistent configuration at different levels (project, repo, global).
- **Environment Variables**: Used for sensitive data like API keys.
- **Default Values**: Many arguments have default values (e.g., default model, colors) that can be overridden.
- **Git Integration**: Git functionality can be disabled with the `--no-git` flag.
- **Model Configuration**: The main model, weak model, and editor model can all be configured separately.

## 6. The args.py File

The `args.py` file is crucial for understanding the available configuration options. Let's take a closer look at some key parts:

```python
def get_parser(default_config_files, git_root):
    parser = configargparse.ArgumentParser(
        description="aider is AI pair programming in your terminal",
        add_config_file_help=True,
        default_config_files=default_config_files,
        config_file_parser_class=configargparse.YAMLConfigFileParser,
        auto_env_var_prefix="AIDER_",
    )
    
    # Main group
    group = parser.add_argument_group("Main")
    group.add_argument("files", metavar="FILE", nargs="*", help="files to edit with an LLM (optional)")
    group.add_argument("--openai-api-key", metavar="OPENAI_API_KEY", env_var="OPENAI_API_KEY", help="Specify the OpenAI API key")
    group.add_argument("--anthropic-api-key", metavar="ANTHROPIC_API_KEY", env_var="ANTHROPIC_API_KEY", help="Specify the Anthropic API key")
    group.add_argument("--model", metavar="MODEL", default=None, help="Specify the model to use for the main chat")
    
    # ... many more arguments ...

    return parser

```

This file defines all the command-line arguments that aider accepts. Some key points:

- It uses `configargparse`, which allows for configuration via files, environment variables, and command-line arguments.
- Arguments are grouped for better organization.
- Many arguments have corresponding environment variables (e.g., `AIDER_OPENAI_API_KEY`).
- Default values are often specified here.

## 7. Conclusion

In this expanded lesson, we've covered the overall structure of the aider project, examined how the application starts up, and delved into the configuration options and default values. We've seen how aider uses a combination of command-line arguments, configuration files, and environment variables to allow for flexible setup.

Understanding this configuration system is crucial for effectively using and modifying aider. It allows the application to be customized for different environments and use cases without changing the core code.

## Exercise

To reinforce your understanding, try the following exercises:

1. Clone the aider repository to your local machine.
2. Create a `.aider.conf.yml` file in your home directory and experiment with setting some configuration options.
3. Run aider with different command-line arguments and observe how they override the defaults and your configuration file.
4. Look into the `models.py` file and try to understand how different AI models are configured.
5. Examine the `InputOutput` class in `io.py` to see how the various I/O options are implemented.

Remember, understanding the configuration and startup process of a large project takes time. Don't hesitate to revisit this lesson as you explore the codebase further!

This expanded first lesson provides a more comprehensive introduction to the aider project structure, the application's entry point, and its configuration system. It covers the key components of the project in more detail, explains how the application starts up and configures itself, and introduces some fundamental concepts about the project's flexibility and customization options.

The lesson is structured to be easy to follow, with detailed code examples and explanations. It also includes an expanded exercise section to help the junior developer apply what they've learned about the configuration system.

In the subsequent lessons, we'll continue to dive deeper into specific components of the project, building on this foundational knowledge of the project structure and configuration system.