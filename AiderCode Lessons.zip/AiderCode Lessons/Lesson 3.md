# Lesson 3: AI Model Integration and IO Module

## 1. Introduction

Welcome to Lesson 3 of our aider codebase exploration! In this lesson, we'll dive into two crucial components of aider: the AI model integration and the IO (Input/Output) module. We'll explore how aider interacts with various AI models and manages input/output operations, which are fundamental to its functionality.

## 2. AI Model Integration

Aider is designed to work with various AI models, primarily focusing on OpenAI's GPT models and Anthropic's Claude models. The integration is handled primarily through the `models.py` file and the `sendchat.py` file. Let's examine each of these components.

### 2.1 The Model Class (`models.py`)

The `Model` class in `models.py` is responsible for managing the configuration and behavior of AI models used by aider.

```python
class Model(ModelSettings):
    def __init__(self, model, weak_model=None, editor_model=None, editor_edit_format=None):
        self.name = model
        self.max_chat_history_tokens = 1024
        self.weak_model = None
        self.editor_model = None

        self.info = self.get_model_info(model)

        # Are all needed keys/params available?
        res = self.validate_environment()
        self.missing_keys = res.get("missing_keys")
        self.keys_in_environment = res.get("keys_in_environment")

        max_input_tokens = self.info.get("max_input_tokens") or 0
        if max_input_tokens < 32 * 1024:
            self.max_chat_history_tokens = 1024
        else:
            self.max_chat_history_tokens = 2 * 1024

        self.configure_model_settings(model)
        if weak_model is False:
            self.weak_model_name = None
        else:
            self.get_weak_model(weak_model)

        if editor_model is False:
            self.editor_model_name = None
        else:
            self.get_editor_model(editor_model, editor_edit_format)

    def get_model_info(self, model):
        return get_model_info(model)

    def configure_model_settings(self, model):
        # Configure model-specific settings
        # ...

    def get_weak_model(self, provided_weak_model_name):
        # Set up a weaker model for certain tasks
        # ...

    def get_editor_model(self, provided_editor_model_name, editor_edit_format):
        # Set up a model for editing tasks
        # ...

    def tokenizer(self, text):
        return litellm.encode(model=self.name, text=text)

    def token_count(self, messages):
        # Count tokens in messages
        # ...

    # ... more methods ...
```


Key points about the Model class:

1. It handles model configuration, including main model, weak model, and editor model.
2. It validates the environment to ensure necessary API keys are available.
3. It provides methods for token counting and model-specific settings.

### 2.2 Sending Messages to AI Models (`sendchat.py`)

The `sendchat.py` file contains functions for sending messages to AI models and handling the responses.

```python
import backoff
from aider.llm import litellm

@lazy_litellm_retry_decorator
def simple_send_with_retries(model_name, messages, extra_params=None):
    try:
        kwargs = {
            "model_name": model_name,
            "messages": messages,
            "functions": None,
            "stream": False,
            "extra_params": extra_params,
        }

        _hash, response = send_completion(**kwargs)
        return response.choices[0].message.content
    except (AttributeError, litellm.exceptions.BadRequestError):
        return

def send_completion(
    model_name,
    messages,
    functions,
    stream,
    temperature=0,
    extra_params=None,
):
    from aider.llm import litellm

    kwargs = dict(
        model=model_name,
        messages=messages,
        stream=stream,
    )
    if temperature is not None:
        kwargs["temperature"] = temperature

    if functions is not None:
        function = functions[0]
        kwargs["tools"] = [dict(type="function", function=function)]
        kwargs["tool_choice"] = {"type": "function", "function": {"name": function["name"]}}

    if extra_params is not None:
        kwargs.update(extra_params)

    key = json.dumps(kwargs, sort_keys=True).encode()

    # Generate SHA1 hash of kwargs and append it to chat_completion_call_hashes
    hash_object = hashlib.sha1(key)

    if not stream and CACHE is not None and key in CACHE:
        return hash_object, CACHE[key]

    res = litellm.completion(**kwargs)

    if not stream and CACHE is not None:
        CACHE[key] = res

    return hash_object, res

# ... more functions ...

```

Key points about sendchat.py:

1. It uses the `litellm` library to send messages to AI models.
2. It implements retry logic with backoff for handling transient errors.
3. It supports both streaming and non-streaming responses.
4. It includes a caching mechanism to avoid redundant API calls.

## 3. The IO Module (`io.py`)

The IO module, implemented in `io.py`, is responsible for managing all input and output operations in aider. This includes handling user input, displaying output, and managing file operations.

```python
class InputOutput:
    def __init__(
        self,
        pretty=True,
        yes=None,
        input_history_file=None,
        chat_history_file=None,
        input=None,
        output=None,
        user_input_color="blue",
        tool_output_color=None,
        tool_error_color="red",
        encoding="utf-8",
        # ... other parameters ...
    ):
        self.pretty = pretty
        self.yes = yes
        self.input_history_file = input_history_file
        self.chat_history_file = chat_history_file
        self.encoding = encoding
        # ... more initialization ...

    def get_input(
        self,
        root,
        rel_fnames,
        addable_rel_fnames,
        commands,
        abs_read_only_fnames=None,
        edit_format=None,
    ):
        # Get user input with auto-completion
        # ...

    def tool_output(self, message="", log_only=False, bold=False):
        # Display output to the user
        # ...

    def tool_error(self, message="", strip=True):
        # Display error messages
        # ...

    def read_text(self, filename):
        # Read text from a file
        # ...

    def write_text(self, filename, content):
        # Write text to a file
        # ...

    # ... more methods ...

```

Key points about the InputOutput class:

1. It handles both input (from user and files) and output (to console and files).
2. It supports colorized output for better readability.
3. It manages input and chat history.
4. It provides methods for reading from and writing to files.

## 4. Interaction between Components

Let's examine how these components work together:

1. The `Coder` class (from Lesson 2) holds instances of both `Model` and `InputOutput`:
   ```python
   self.main_model = main_model
   self.io = io
   ```

2. When the Coder needs to interact with the AI model, it uses the `send_message` method, which in turn uses functions from `sendchat.py`:
   ```python
   response = simple_send_with_retries(self.main_model.name, messages, extra_params=self.main_model.extra_params)
   ```

3. User input and output are managed through the `InputOutput` instance:
   ```python
   user_input = self.io.get_input(...)
   self.io.tool_output(message)
   ```

4. File operations, crucial for code editing, are also handled by the `InputOutput` instance:
   ```python
   content = self.io.read_text(filename)
   self.io.write_text(filename, new_content)
   ```

## 5. Customizing AI Model Behavior

To work with a new AI model or modify the behavior of existing ones:

1. Update the `MODEL_SETTINGS` in `models.py` to include the new model's configuration.
2. If necessary, modify the `send_completion` function in `sendchat.py` to handle any model-specific parameters or behaviors.
3. Update the `get_model_info` function in `models.py` if the new model requires different metadata.

## 6. Extending IO Capabilities

To add new IO features or modify existing ones:

1. Add new methods to the `InputOutput` class in `io.py`.
2. Update existing methods if you need to change how input is processed or output is displayed.
3. If adding file operations for new file types, extend the `read_text` and `write_text` methods.

## 7. Conclusion

In this lesson, we've explored how aider integrates with AI models and manages input/output operations. We've seen how the `Model` class configures and manages AI models, how `sendchat.py` handles communication with these models, and how the `InputOutput` class manages all IO operations.

Understanding these components is crucial for working with aider, as they form the bridge between the user, the codebase, and the AI models that power aider's functionality.

## Exercise

To reinforce your understanding, try the following exercises:

1. Examine how token counting is implemented in the `Model` class. How might you modify this to work with a different tokenization scheme?
2. Add a new method to the `InputOutput` class that allows for input with a timeout (hint: you might need to use the `threading` module).
3. Modify the `send_completion` function to log all API calls to a file for debugging purposes.
4. Implement a simple caching mechanism for file reads in the `InputOutput` class to optimize performance for frequently accessed files.
5. Explore how you would add support for a new AI model from a different provider (e.g., Google's PaLM or Cohere).

Remember, these components interact in complex ways. Don't hesitate to use debugging tools or add print statements to better understand the flow of data between them.

This third lesson provides a comprehensive look at how aider integrates with AI models and manages input/output operations. It explains the role of the `Model` class, the functions in `sendchat.py`, and the `InputOutput` class, showing how these components work together to provide aider's core functionality.

The lesson is structured to provide both theoretical understanding and practical insights, with code examples and explanations. The exercise section encourages the junior developer to actively engage with these components and experiment with extending or modifying their functionality.

In the subsequent lessons, we'll continue to explore other important aspects of the aider project, such as:

4. Repository Handling and Git Integration
5. Advanced Topics: Error Handling, Testing, and Project Extension

Each lesson will continue to build upon the knowledge from the previous ones, gradually building a complete understanding of the aider codebase.