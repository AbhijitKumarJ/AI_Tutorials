# Lesson 8: Web GUI Implementation

## 1. Introduction

Welcome to Lesson 8 of our aider codebase exploration! In this lesson, we'll dive into the web GUI functionality of aider. This feature provides a browser-based interface for interacting with aider, offering a more visual and potentially more user-friendly experience compared to the command-line interface.

## 2. Overview of the GUI Implementation

The web GUI is primarily implemented in the `gui.py` file. It uses Streamlit, a Python library for creating web apps, to build the interface. Let's start by examining the main structure of this file:

<antArtifact identifier="gui-overview" type="application/vnd.ant.code" language="python" title="Overview of gui.py">
import os
import random
import sys

import streamlit as st

from aider import urls
from aider.coders import Coder
from aider.dump import dump  # noqa: F401
from aider.io import InputOutput
from aider.main import main as cli_main
from aider.scrape import Scraper, install_playwright

class CaptureIO(InputOutput):
    # Implementation details...

@st.cache_resource
def get_state():
    return State()

@st.cache_resource
def get_coder():
    # Implementation details...

class GUI:
    prompt = None
    prompt_as = "user"
    last_undo_empty = None
    recent_msgs_empty = None
    web_content_empty = None

    def __init__(self):
        # Implementation details...

    def do_sidebar(self):
        # Implementation details...

    def do_messages_container(self):
        # Implementation details...

    def initialize_state(self):
        # Implementation details...

    # More methods...

def gui_main():
    st.set_page_config(
        layout="wide",
        page_title="Aider",
        page_icon=urls.favicon,
        menu_items={
            "Get Help": urls.website,
            "Report a bug": "https://github.com/Aider-AI/aider/issues",
            "About": "# Aider\nAI pair programming in your browser.",
        },
    )

    GUI()

if __name__ == "__main__":
    status = gui_main()
    sys.exit(status)


The GUI implementation centers around the `GUI` class, which manages the state and behavior of the web interface. The `gui_main()` function sets up the Streamlit page configuration and initializes the GUI.

## 3. State Management

Aider's GUI uses Streamlit's state management to maintain the application state across reruns. This is implemented using the `@st.cache_resource` decorator:

```python
class State:
    keys = set()

    def init(self, key, val=None):
        if key in self.keys:
            return

        self.keys.add(key)
        setattr(self, key, val)
        return True

@st.cache_resource
def get_state():
    return State()

@st.cache_resource
def get_coder():
    coder = cli_main(return_coder=True)
    if not isinstance(coder, Coder):
        raise ValueError(coder)
    if not coder.repo:
        raise ValueError("GUI can currently only be used inside a git repo")

    io = CaptureIO(
        pretty=False,
        yes=True,
        dry_run=coder.io.dry_run,
        encoding=coder.io.encoding,
    )
    coder.commands.io = io

    for line in coder.get_announcements():
        coder.io.tool_output(line)

    return coder

```

The `State` class and `get_state()` function provide a way to store and retrieve application state, while `get_coder()` initializes and caches the `Coder` instance used by the GUI.

## 4. Main GUI Class

The `GUI` class is the core of the web interface. It sets up the layout and handles user interactions. Let's look at some key methods:

```python
class GUI:
    def __init__(self):
        self.coder = get_coder()
        self.state = get_state()

        # Force the coder to cooperate, regardless of cmd line args
        self.coder.yield_stream = True
        self.coder.stream = True
        self.coder.pretty = False

        self.initialize_state()

        self.do_messages_container()
        self.do_sidebar()

        user_inp = st.chat_input("Say something")
        if user_inp:
            self.prompt = user_inp

        if self.prompt_pending():
            self.process_chat()

        # More initialization...

    def do_sidebar(self):
        with st.sidebar:
            st.title("Aider")
            self.do_add_to_chat()
            self.do_recent_msgs()
            self.do_clear_chat_history()
            st.warning(
                "This browser version of aider is experimental. Please share feedback in [GitHub"
                " issues](https://github.com/Aider-AI/aider/issues)."
            )

    def do_messages_container(self):
        self.messages = st.container()

        with self.messages:
            for msg in self.state.messages:
                role = msg["role"]

                if role == "edit":
                    self.show_edit_info(msg)
                elif role == "info":
                    st.info(msg["content"])
                elif role == "text":
                    text = msg["content"]
                    line = text.splitlines()[0]
                    with self.messages.expander(line):
                        st.text(text)
                elif role in ("user", "assistant"):
                    with st.chat_message(role):
                        st.write(msg["content"])
                else:
                    st.dict(msg)

    def process_chat(self):
        prompt = self.state.prompt
        self.state.prompt = None

        while prompt:
            with self.messages.chat_message("assistant"):
                res = st.write_stream(self.coder.run_stream(prompt))
                self.state.messages.append({"role": "assistant", "content": res})

            prompt = None
            if self.coder.reflected_message:
                if self.num_reflections < self.max_reflections:
                    self.num_reflections += 1
                    self.info(self.coder.reflected_message)
                    prompt = self.coder.reflected_message

        with self.messages:
            edit = dict(
                role="edit",
                fnames=self.coder.aider_edited_files,
            )
            if self.state.last_aider_commit_hash != self.coder.last_aider_commit_hash:
                edit["commit_hash"] = self.coder.last_aider_commit_hash
                edit["commit_message"] = self.coder.last_aider_commit_message
                commits = f"{self.coder.last_aider_commit_hash}~1"
                diff = self.coder.repo.diff_commits(
                    self.coder.pretty,
                    commits,
                    self.coder.last_aider_commit_hash,
                )
                edit["diff"] = diff
                self.state.last_aider_commit_hash = self.coder.last_aider_commit_hash

            self.state.messages.append(edit)
            self.show_edit_info(edit)

        # re-render the UI for the non-prompt_pending state
        st.rerun()

    # More methods...

```

The `GUI` class sets up the main components of the interface, including the sidebar and message container. It also handles chat processing and updates the UI accordingly.

## 5. Streamlit Components

The GUI makes extensive use of Streamlit components to create the interface. Here are some key components used:

- `st.sidebar`: Creates a sidebar for controls and options.
- `st.container()`: Creates a container for displaying messages.
- `st.chat_input()`: Provides an input field for user messages.
- `st.chat_message()`: Displays chat messages in a conversational format.
- `st.write()` and `st.write_stream()`: Display text and streamed content.
- `st.expander()`: Creates expandable sections for long content.

## 6. Interaction with Coder

The GUI class interacts closely with the `Coder` instance. It uses the coder to process chat messages, make edits, and retrieve information about the current state of the code:

```python
class GUI:
    # ...

    def process_chat(self):
        prompt = self.state.prompt
        self.state.prompt = None

        while prompt:
            with self.messages.chat_message("assistant"):
                res = st.write_stream(self.coder.run_stream(prompt))
                self.state.messages.append({"role": "assistant", "content": res})

            prompt = None
            if self.coder.reflected_message:
                if self.num_reflections < self.max_reflections:
                    self.num_reflections += 1
                    self.info(self.coder.reflected_message)
                    prompt = self.coder.reflected_message

        # Handle edits and commits
        with self.messages:
            edit = dict(
                role="edit",
                fnames=self.coder.aider_edited_files,
            )
            if self.state.last_aider_commit_hash != self.coder.last_aider_commit_hash:
                edit["commit_hash"] = self.coder.last_aider_commit_hash
                edit["commit_message"] = self.coder.last_aider_commit_message
                commits = f"{self.coder.last_aider_commit_hash}~1"
                diff = self.coder.repo.diff_commits(
                    self.coder.pretty,
                    commits,
                    self.coder.last_aider_commit_hash,
                )
                edit["diff"] = diff
                self.state.last_aider_commit_hash = self.coder.last_aider_commit_hash

            self.state.messages.append(edit)
            self.show_edit_info(edit)

    # ...

```

This interaction allows the GUI to leverage the existing aider functionality while providing a web-based interface.

## 7. Launching the GUI

The GUI can be launched using the `--gui` or `--browser` command-line option when starting aider. This is handled in the `main()` function in `main.py`:

```python
def main(argv=None, input=None, output=None, force_git_root=None, return_coder=False):
    # ...

    if args.gui and not return_coder:
        if not check_streamlit_install(io):
            return
        launch_gui(argv)
        return

    # ...

def launch_gui(args):
    from streamlit.web import cli

    from aider import gui

    print()
    print("CONTROL-C to exit...")

    target = gui.__file__

    st_args = ["run", target]

    st_args += [
        "--browser.gatherUsageStats=false",
        "--runner.magicEnabled=false",
        "--server.runOnSave=false",
    ]

    if "-dev" in __version__:
        print("Watching for file changes.")
    else:
        st_args += [
            "--global.developmentMode=false",
            "--server.fileWatcherType=none",
            "--client.toolbarMode=viewer",  # minimal?
        ]

    st_args += ["--"] + args

    cli.main(st_args)

```

This sets up the Streamlit server with appropriate arguments and launches the GUI.

## 8. Conclusion

The web GUI provides an alternative interface for interacting with aider, leveraging the power of Streamlit to create a responsive and user-friendly web application. It maintains most of the functionality of the command-line interface while providing a more visual experience.

Key points to remember about the GUI implementation:

1. It uses Streamlit for creating the web interface.
2. The `GUI` class manages the state and behavior of the interface.
3. It interacts closely with the `Coder` instance to process chats and make edits.
4. State management is handled using Streamlit's caching mechanism.
5. The GUI can be launched using command-line options in the main aider script.

## Exercise

To reinforce your understanding of the GUI implementation, try the following exercises:

1. Add a new feature to the sidebar, such as a dropdown to select different AI models.

2. Implement a way to visualize the repository structure in the GUI, perhaps using a tree-like component.

3. Add a settings page to the GUI where users can modify various aider configuration options.

4. Implement a way to display syntax-highlighted code snippets in the chat messages.

5. Add a feature to allow users to upload files directly through the GUI.

6. Implement a way to visualize the diff of changes in a more user-friendly manner, perhaps using a side-by-side view.

7. Add error handling and display error messages in a user-friendly way in the GUI.

Remember, when working on these exercises, consider the user experience and how your changes integrate with the existing functionality of aider. Always test your changes thoroughly to ensure they work as expected in the web environment.

</antArtifact>

This lesson provides a comprehensive overview of aider's web GUI implementation, covering the main components, state management, interaction with the core aider functionality, and how the GUI is launched. The exercises at the end encourage hands-on experience with extending and improving the GUI.

This additional lesson complements the previous seven by focusing on a specific feature of aider that provides an alternative way of interacting with the tool. Understanding this implementation is crucial for developers who might want to work on or extend the web-based interface of aider.