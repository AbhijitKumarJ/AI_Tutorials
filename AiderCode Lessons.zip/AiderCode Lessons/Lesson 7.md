# Lesson 7: Utilities, Helpers, and Additional Features

## 1. Introduction

Welcome to our final bonus lesson on the aider codebase! In this lesson, we'll explore utilities, helper functions, and additional features that we haven't covered in depth previously. These components, while often working behind the scenes, play crucial roles in making aider efficient, user-friendly, and feature-rich.

## 2. Utility Functions (utils.py)

The `utils.py` file contains various utility functions used throughout the project. Let's examine some key utilities:

<antArtifact identifier="utils-functions" type="application/vnd.ant.code" language="python" title="Excerpt from utils.py">
def safe_abs_path(res):
    "Gives an abs path, which safely returns a full (not 8.3) windows path"
    res = Path(res).resolve()
    return str(res)

def find_common_root(abs_fnames):
    if len(abs_fnames) == 1:
        return safe_abs_path(os.path.dirname(list(abs_fnames)[0]))
    elif abs_fnames:
        return safe_abs_path(os.path.commonpath(list(abs_fnames)))
    else:
        return safe_abs_path(os.getcwd())

def format_tokens(count):
    if count < 1000:
        return f"{count}"
    elif count < 10000:
        return f"{count / 1000:.1f}k"
    else:
        return f"{round(count / 1000)}k"

def touch_file(fname):
    fname = Path(fname)
    try:
        fname.parent.mkdir(parents=True, exist_ok=True)
        fname.touch()
        return True
    except OSError:
        return False

def check_pip_install_extra(io, module, prompt, pip_install_cmd, self_update=False):
    if module:
        try:
            __import__(module)
            return True
        except (ImportError, ModuleNotFoundError, RuntimeError):
            pass

    cmd = get_pip_install(pip_install_cmd)

    if prompt:
        io.tool_warning(prompt)

    if self_update and platform.system() == "Windows":
        io.tool_output("Run this command to update:")
        print()
        print(printable_shell_command(cmd))  # plain print so it doesn't line-wrap
        return

    if not io.confirm_ask("Run pip install?", default="y", subject=printable_shell_command(cmd)):
        return

    success, output = run_install(cmd)
    if success:
        if not module:
            return True
        try:
            __import__(module)
            return True
        except (ImportError, ModuleNotFoundError, RuntimeError) as err:
            io.tool_error(str(err))
            pass

    io.tool_error(output)

    print()
    print("Install failed, try running this command manually:")
    print(printable_shell_command(cmd))

# ... more utility functions ...


These utility functions handle various tasks such as path manipulation, token formatting, file operations, and package installation. They are used throughout the project to simplify common operations and improve code readability.

## 3. Web Scraping (scrape.py)

Aider includes functionality for web scraping, which can be useful for gathering information from web pages. This is implemented in the `scrape.py` file:

```python
class Scraper:
    pandoc_available = None
    playwright_available = None
    playwright_instructions_shown = False

    def __init__(self, print_error=None, playwright_available=None, verify_ssl=True):
        if print_error:
            self.print_error = print_error
        else:
            self.print_error = print

        self.playwright_available = playwright_available
        self.verify_ssl = verify_ssl

    def scrape(self, url):
        """
        Scrape a url and turn it into readable markdown if it's HTML.
        If it's plain text or non-HTML, return it as-is.

        `url` - the URL to scrape.
        """

        if self.playwright_available:
            content, mime_type = self.scrape_with_playwright(url)
        else:
            content, mime_type = self.scrape_with_httpx(url)

        if not content:
            self.print_error(f"Failed to retrieve content from {url}")
            return None

        # Check if the content is HTML based on MIME type or content
        if (mime_type and mime_type.startswith("text/html")) or (
            mime_type is None and self.looks_like_html(content)
        ):
            self.try_pandoc()
            content = self.html_to_markdown(content)

        return content

    # ... more methods ...

```

This scraping functionality allows aider to incorporate web content into its context, which can be particularly useful for tasks that require external information.

## 4. Version Checking (versioncheck.py)

Aider includes functionality to check for updates and install new versions. This is implemented in the `versioncheck.py` file:

```python
def check_version(io, just_check=False, verbose=False):
    if not just_check and VERSION_CHECK_FNAME.exists():
        day = 60 * 60 * 24
        since = time.time() - os.path.getmtime(VERSION_CHECK_FNAME)
        if 0 < since < day:
            if verbose:
                hours = since / 60 / 60
                io.tool_output(f"Too soon to check version: {hours:.1f} hours")
            return

    # To keep startup fast, avoid importing this unless needed
    import requests

    try:
        response = requests.get("https://pypi.org/pypi/aider-chat/json")
        data = response.json()
        latest_version = data["info"]["version"]
        current_version = aider.__version__

        if just_check or verbose:
            io.tool_output(f"Current version: {current_version}")
            io.tool_output(f"Latest version: {latest_version}")

        is_update_available = packaging.version.parse(latest_version) > packaging.version.parse(
            current_version
        )
    except Exception as err:
        io.tool_error(f"Error checking pypi for new version: {err}")
        return False
    finally:
        VERSION_CHECK_FNAME.parent.mkdir(parents=True, exist_ok=True)
        VERSION_CHECK_FNAME.touch()

    # ... rest of the function ...

def install_upgrade(io, latest_version=None):
    """
    Install the latest version of aider from PyPI.
    """

    if latest_version:
        new_ver_text = f"Newer aider version v{latest_version} is available."
    else:
        new_ver_text = "Install latest version of aider?"

    docker_image = os.environ.get("AIDER_DOCKER_IMAGE")
    if docker_image:
        text = f"""
{new_ver_text} To upgrade, run:

    docker pull {docker_image}
"""
        io.tool_warning(text)
        return True

    success = utils.check_pip_install_extra(
        io,
        None,
        new_ver_text,
        ["aider-chat"],
        self_update=True,
    )

    if success:
        io.tool_output("Re-run aider to use new version.")
        sys.exit()

    return

# ... more functions ...

```

This version checking functionality helps ensure that users are running the latest version of aider, which can be crucial for accessing new features and bug fixes.

## 5. Command Line Interface Formatting (args_formatter.py)

Aider uses custom formatters for its command-line interface, which are defined in `args_formatter.py`:

```python
class DotEnvFormatter(argparse.HelpFormatter):
    def start_section(self, heading):
        res = "\n\n"
        res += "#" * (len(heading) + 3)
        res += f"\n# {heading}"
        super().start_section(res)

    def _format_usage(self, usage, actions, groups, prefix):
        return ""

    def _format_text(self, text):
        return f"""
##########################################################
# Sample aider .env file.
# Place at the root of your git repo.
# Or use `aider --env <fname>` to specify.
##########################################################

#################
# LLM parameters:
#
# Include xxx_API_KEY parameters and other params needed for your LLMs.
# See {urls.llms} for details.

## OpenAI
#OPENAI_API_KEY=

## Anthropic
#ANTHROPIC_API_KEY=

##...
"""

    # ... more methods ...

class YamlHelpFormatter(argparse.HelpFormatter):
    def start_section(self, heading):
        res = "\n\n"
        res += "#" * (len(heading) + 3)
        res += f"\n# {heading}"
        super().start_section(res)

    def _format_usage(self, usage, actions, groups, prefix):
        return ""

    def _format_text(self, text):
        return """
##########################################################
# Sample .aider.conf.yml
# This file lists *all* the valid configuration entries.
# Place in your home dir, or at the root of your git repo.
##########################################################

# Note: You can only put OpenAI and Anthropic API keys in the yaml
# config file. Keys for all APIs can be stored in a .env file
# https://aider.chat/docs/config/dotenv.html

"""

    # ... more methods ...

# ... more classes ...

```

These custom formatters help in generating user-friendly help messages and configuration file templates, enhancing the overall user experience of aider.

## 6. Linting (linter.py)

Aider includes a linting system to help maintain code quality. This is implemented in the `linter.py` file:

```python
class Linter:
    def __init__(self, encoding="utf-8", root=None):
        self.encoding = encoding
        self.root = root

        self.languages = dict(
            python=self.py_lint,
        )
        self.all_lint_cmd = None

    def set_linter(self, lang, cmd):
        if lang:
            self.languages[lang] = cmd
            return

        self.all_lint_cmd = cmd

    def get_rel_fname(self, fname):
        if self.root:
            try:
                return os.path.relpath(fname, self.root)
            except ValueError:
                return fname
        else:
            return fname

    def run_cmd(self, cmd, rel_fname, code):
        cmd += " " + rel_fname
        cmd = cmd.split()

        try:
            process = subprocess.Popen(
                cmd,
                cwd=self.root,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                encoding=self.encoding,
                errors="replace",
            )
        except OSError as err:
            print(f"Unable to execute lint command: {err}")
            return
        stdout, _ = process.communicate()
        errors = stdout
        if process.returncode == 0:
            return  # zero exit status

        cmd = " ".join(cmd)
        res = f"## Running: {cmd}\n\n"
        res += errors

        return self.errors_to_lint_result(rel_fname, res)

    # ... more methods ...

```

The linting system helps maintain code quality by checking for potential issues in the code being edited through aider.

## 7. Diffs Generation (diffs.py)

Aider includes functionality for generating and displaying diffs, which is crucial for showing code changes. This is implemented in the `diffs.py` file:

```python
def create_progress_bar(percentage):
    block = "█"
    empty = "░"
    total_blocks = 30
    filled_blocks = int(total_blocks * percentage // 100)
    empty_blocks = total_blocks - filled_blocks
    bar = block * filled_blocks + empty * empty_blocks
    return bar

def diff_partial_update(lines_orig, lines_updated, final=False, fname=None):
    """
    Given only the first part of an updated file, show the diff while
    ignoring the block of "deleted" lines that are past the end of the
    partially complete update.
    """

    num_orig_lines = len(lines_orig)

    if final:
        last_non_deleted = num_orig_lines
    else:
        last_non_deleted = find_last_non_deleted(lines_orig, lines_updated)

    if last_non_deleted is None:
        return ""

    if num_orig_lines:
        pct = last_non_deleted * 100 / num_orig_lines
    else:
        pct = 50
    bar = create_progress_bar(pct)
    bar = f" {last_non_deleted:3d} / {num_orig_lines:3d} lines [{bar}] {pct:3.0f}%\n"

    lines_orig = lines_orig[:last_non_deleted]

    if not final:
        lines_updated = lines_updated[:-1] + [bar]

    diff = difflib.unified_diff(lines_orig, lines_updated, n=5)

    diff = list(diff)[2:]

    diff = "".join(diff)
    if not diff.endswith("\n"):
        diff += "\n"

    for i in range(3, 10):
        backticks = "`" * i
        if backticks not in diff:
            break

    show = f"{backticks}diff\n"
    if fname:
        show += f"--- {fname} original\n"
        show += f"+++ {fname} updated\n"

    show += diff

    show += f"{backticks}\n\n"

    return show

# ... more functions ...

```

This diff generation functionality is crucial for showing users the changes that aider is making to their code.

## 8. Conclusion

In this final lesson, we've explored various utilities, helpers, and additional features that contribute to aider's functionality. These include utility functions, web scraping capabilities, version checking, command-line interface formatting, linting, and diff generation.

While these components might not be as central as those covered in earlier lessons, they play crucial roles in enhancing aider's functionality, maintainability, and user experience. Understanding these components gives you a more complete picture of how aider works and how its various parts interact.

## Exercise

To reinforce your understanding of these components, try the following exercises:

1. Add a new utility function to `utils.py` that could be useful in multiple parts of the project (e.g., a function to calculate the complexity of a piece of code).

2. Extend the web scraping functionality to handle a new type of content (e.g., PDFs or specific types of web applications).

3. Modify the version checking system to also check for compatibility with the user's current Python version.

4. Create a new command-line interface formatter that outputs help messages in a different format (e.g., as HTML that could be viewed in a browser).

5. Add support for a new programming language to the linting system, including integration with a popular linter for that language.

6. Enhance the diff generation functionality to include a summary of the changes (e.g., number of lines added, removed, and modified) along with the diff.

7. Implement a new feature that uses several of these utilities and helpers together. For example, you could create a command that scrapes documentation for a given library, checks if the user's code follows the documented best practices, and suggests improvements.

Remember, when working on these exercises, consider how your changes will interact with the rest of the system. Aider is a complex project with many interconnected parts, so any modifications should be made carefully and with consideration for the overall architecture.

## 9. Final Thoughts on Aider's Architecture

Now that we've covered all major components of aider, let's take a moment to reflect on its overall architecture:

1. **Modular Design**: Aider is built with a modular design, separating concerns into different classes and files. This makes the codebase easier to understand, maintain, and extend.

2. **Extensibility**: Many parts of aider, such as the Coder classes and command system, are designed to be easily extensible. This allows for new features to be added without major changes to the core system.

3. **Configurability**: Aider uses a flexible configuration system that allows users to customize its behavior through command-line arguments, configuration files, and environment variables.

4. **AI Integration**: The core of aider's functionality revolves around its integration with AI models. This integration is designed to be flexible, allowing for different models and providers to be used.

5. **Version Control Integration**: Aider's tight integration with Git allows it to work seamlessly within existing software development workflows.

6. **Helper Utilities**: The various utilities and helpers we've discussed in this lesson provide a strong foundation for the main functionality, enhancing performance, user experience, and maintainability.

7. **Error Handling and Reporting**: Aider includes robust error handling and reporting mechanisms, which are crucial for a tool that interacts with complex systems like AI models and version control.

Understanding this architecture is key to effectively working with, maintaining, and extending aider. As you work with the codebase, always keep in mind how your changes fit into this overall structure.

## 10. Conclusion

Congratulations! You've now completed a comprehensive tour of the aider codebase. Over these seven lessons, we've covered everything from the core functionality of interacting with AI models and managing code edits, to the supporting utilities and features that make aider a robust and user-friendly tool.

As a junior developer, you now have a solid foundation to start contributing to aider. Remember that the best way to deepen your understanding is through hands-on experience. Don't hesitate to experiment with the code, run it in a debugger, or add print statements to better understand the flow of execution.

As you start working on aider, here are some final tips:

1. Always test your changes thoroughly, and add new tests for new functionality.
2. Keep the existing coding style and conventions in mind as you write new code.
3. Document your changes, both in the code (with comments) and in any relevant documentation files.
4. Don't hesitate to ask questions if you're unsure about something. The aider community and maintainers are there to help.

Good luck with your work on aider!



This continuation completes Lesson 7, providing additional exercises that cover the utilities and helpers discussed in the lesson. It also includes a section on final thoughts about aider's architecture, tying together all the concepts covered across the seven lessons.

The lesson concludes with some general advice for junior developers starting to work on the aider project. This comprehensive series of lessons should now provide a thorough understanding of the entire aider codebase, from its core functionality to its supporting utilities and architectural design principles.