# Lesson 4: Repository Handling and Git Integration

## 1. Introduction

Welcome to Lesson 4 of our aider codebase exploration! In this lesson, we'll dive into how aider handles repositories and integrates with Git. We'll explore the `GitRepo` class, which is central to aider's version control capabilities, and how it interacts with other components of the system.

## 2. The GitRepo Class

The `GitRepo` class, defined in `repo.py`, is responsible for managing interactions with the Git repository. It provides methods for committing changes, checking file status, and performing other Git operations.

```python
import os
import time
from pathlib import Path, PurePosixPath

import git
import pathspec

from aider import prompts, utils
from aider.sendchat import simple_send_with_retries

class GitRepo:
    repo = None
    aider_ignore_file = None
    aider_ignore_spec = None
    aider_ignore_ts = 0
    aider_ignore_last_check = 0
    subtree_only = False
    ignore_file_cache = {}
    git_repo_error = None

    def __init__(
        self,
        io,
        fnames,
        git_dname,
        aider_ignore_file=None,
        models=None,
        attribute_author=True,
        attribute_committer=True,
        attribute_commit_message_author=False,
        attribute_commit_message_committer=False,
        commit_prompt=None,
        subtree_only=False,
    ):
        self.io = io
        self.models = models
        self.normalized_path = {}
        self.tree_files = {}
        self.attribute_author = attribute_author
        self.attribute_committer = attribute_committer
        self.attribute_commit_message_author = attribute_commit_message_author
        self.attribute_commit_message_committer = attribute_commit_message_committer
        self.commit_prompt = commit_prompt
        self.subtree_only = subtree_only
        self.ignore_file_cache = {}

        # Initialize the repo
        if git_dname:
            check_fnames = [git_dname]
        elif fnames:
            check_fnames = fnames
        else:
            check_fnames = ["."]

        repo_paths = []
        for fname in check_fnames:
            fname = Path(fname)
            fname = fname.resolve()

            if not fname.exists() and fname.parent.exists():
                fname = fname.parent

            try:
                repo_path = git.Repo(fname, search_parent_directories=True).working_dir
                repo_path = utils.safe_abs_path(repo_path)
                repo_paths.append(repo_path)
            except ANY_GIT_ERROR:
                pass

        num_repos = len(set(repo_paths))

        if num_repos == 0:
            raise FileNotFoundError
        if num_repos > 1:
            self.io.tool_error("Files are in different git repos.")
            raise FileNotFoundError

        self.repo = git.Repo(repo_paths.pop(), odbt=git.GitDB)
        self.root = utils.safe_abs_path(self.repo.working_tree_dir)

        if aider_ignore_file:
            self.aider_ignore_file = Path(aider_ignore_file)

    def commit(self, fnames=None, context=None, message=None, aider_edits=False):
        if not fnames and not self.repo.is_dirty():
            return

        diffs = self.get_diffs(fnames)
        if not diffs:
            return

        if message:
            commit_message = message
        else:
            commit_message = self.get_commit_message(diffs, context)

        if aider_edits and self.attribute_commit_message_author:
            commit_message = "aider: " + commit_message
        elif self.attribute_commit_message_committer:
            commit_message = "aider: " + commit_message

        if not commit_message:
            commit_message = "(no commit message provided)"

        full_commit_message = commit_message

        cmd = ["-m", full_commit_message, "--no-verify"]
        if fnames:
            fnames = [str(self.abs_root_path(fn)) for fn in fnames]
            for fname in fnames:
                try:
                    self.repo.git.add(fname)
                except ANY_GIT_ERROR as err:
                    self.io.tool_error(f"Unable to add {fname}: {err}")
            cmd += ["--"] + fnames
        else:
            cmd += ["-a"]

        original_user_name = self.repo.config_reader().get_value("user", "name")
        original_committer_name_env = os.environ.get("GIT_COMMITTER_NAME")
        committer_name = f"{original_user_name} (aider)"

        if self.attribute_committer:
            os.environ["GIT_COMMITTER_NAME"] = committer_name

        if aider_edits and self.attribute_author:
            original_auther_name_env = os.environ.get("GIT_AUTHOR_NAME")
            os.environ["GIT_AUTHOR_NAME"] = committer_name

        try:
            self.repo.git.commit(cmd)
            commit_hash = self.get_head_commit_sha(short=True)
            self.io.tool_output(f"Commit {commit_hash} {commit_message}", bold=True)
            return commit_hash, commit_message
        except ANY_GIT_ERROR as err:
            self.io.tool_error(f"Unable to commit: {err}")
        finally:
            # Restore the env
            if self.attribute_committer:
                if original_committer_name_env is not None:
                    os.environ["GIT_COMMITTER_NAME"] = original_committer_name_env
                else:
                    del os.environ["GIT_COMMITTER_NAME"]

            if aider_edits and self.attribute_author:
                if original_auther_name_env is not None:
                    os.environ["GIT_AUTHOR_NAME"] = original_auther_name_env
                else:
                    del os.environ["GIT_AUTHOR_NAME"]

    # ... more methods ...
```

Key points about the GitRepo class:

1. It initializes a Git repository object using the `git` library.
2. It provides methods for committing changes, getting diffs, and managing file status.
3. It handles author and committer attribution for commits.
4. It integrates with the IO system for error reporting and output.

## 3. Git Operations in Aider

Let's examine how aider uses Git operations in its workflow:

### 3.1 Committing Changes

The `commit` method in `GitRepo` is central to aider's version control:

1. It checks if there are changes to commit.
2. It generates a commit message (either provided or generated using AI).
3. It handles author and committer attribution.
4. It performs the actual commit using Git commands.

### 3.2 Generating Commit Messages

Aider can generate commit messages using AI:

```python
def get_commit_message(self, diffs, context):
    diffs = "# Diffs:\n" + diffs

    content = ""
    if context:
        content += context + "\n"
    content += diffs

    system_content = self.commit_prompt or prompts.commit_system
    messages = [
        dict(role="system", content=system_content),
        dict(role="user", content=content),
    ]

    commit_message = None
    for model in self.models:
        num_tokens = model.token_count(messages)
        max_tokens = model.info.get("max_input_tokens") or 0
        if max_tokens and num_tokens > max_tokens:
            continue
        commit_message = simple_send_with_retries(
            model.name, messages, extra_params=model.extra_params
        )
        if commit_message:
            break

    if not commit_message:
        self.io.tool_error("Failed to generate commit message!")
        return

    commit_message = commit_message.strip()
    if commit_message and commit_message[0] == '"' and commit_message[-1] == '"':
        commit_message = commit_message[1:-1].strip()

    return commit_message

```

This method uses the AI model to generate a commit message based on the diffs and context.

### 3.3 File Status Management

Aider keeps track of which files are being edited and which are in the repository:

```python
def get_tracked_files(self):
    if not self.repo:
        return []

    try:
        commit = self.repo.head.commit
    except ValueError:
        commit = None
    except ANY_GIT_ERROR as err:
        self.git_repo_error = err
        self.io.tool_error(f"Unable to list files in git repo: {err}")
        self.io.tool_output("Is your git repo corrupted?")
        return []

    files = set()
    if commit:
        if commit in self.tree_files:
            files = self.tree_files[commit]
        else:
            try:
                for blob in commit.tree.traverse():
                    if blob.type == "blob":  # blob is a file
                        files.add(blob.path)
            except ANY_GIT_ERROR as err:
                self.git_repo_error = err
                self.io.tool_error(f"Unable to list files in git repo: {err}")
                self.io.tool_output("Is your git repo corrupted?")
                return []
            files = set(self.normalize_path(path) for path in files)
            self.tree_files[commit] = set(files)

    # Add staged files
    index = self.repo.index
    staged_files = [path for path, _ in index.entries.keys()]
    files.update(self.normalize_path(path) for path in staged_files)

    res = [fname for fname in files if not self.ignored_file(fname)]

    return res

```

This method retrieves all tracked files in the repository, handling potential errors and caching results for efficiency.

## 4. Integration with Aider's Workflow

The `GitRepo` class is primarily used by the `Coder` class to manage version control. Here's how it integrates into aider's workflow:

1. **Initialization**: When aider starts, it initializes a `GitRepo` instance if Git integration is enabled:

   ```python
   if args.git:
       repo = GitRepo(
           io,
           fnames,
           git_dname,
           args.aiderignore,
           models=main_model.commit_message_models(),
           attribute_author=args.attribute_author,
           attribute_committer=args.attribute_committer,
           # ... other parameters ...
       )
   else:
       repo = None
   ```

2. **File Management**: The `Coder` class uses `GitRepo` to keep track of which files are being edited:

   ```python
   def get_all_relative_files(self):
       if self.repo:
           files = self.repo.get_tracked_files()
       else:
           files = self.get_inchat_relative_files()
       return sorted(set(files))
   ```

3. **Committing Changes**: After applying edits, the `Coder` class uses `GitRepo` to commit the changes:

   ```python
   def auto_commit(self, edited, context=None):
       if not self.repo or not self.auto_commits or self.dry_run:
           return

       if not context:
           context = self.get_context_from_history(self.cur_messages)

       try:
           res = self.repo.commit(fnames=edited, context=context, aider_edits=True)
           if res:
               self.show_auto_commit_outcome(res)
               commit_hash, commit_message = res
               return self.gpt_prompts.files_content_gpt_edits.format(
                   hash=commit_hash,
                   message=commit_message,
               )

           return self.gpt_prompts.files_content_gpt_no_edits
       except ANY_GIT_ERROR as err:
           self.io.tool_error(f"Unable to commit: {str(err)}")
           return
   ```

## 5. Customizing Git Integration

To modify or extend aider's Git integration:

1. Add new methods to the `GitRepo` class for additional Git operations.
2. Modify the `commit` method to change how commits are created or attributed.
3. Update the `get_tracked_files` method if you need to change how aider determines which files are part of the repository.
4. Modify the `Coder` class to use new Git functionality you've added.

## 6. Conclusion

In this lesson, we've explored how aider handles repositories and integrates with Git. We've seen how the `GitRepo` class manages Git operations, how commit messages are generated, and how this integrates with aider's overall workflow.

Understanding these components is crucial for working with aider in a version-controlled environment. It allows aider to track changes, maintain a history of modifications, and collaborate effectively with human developers.

## Exercise

To reinforce your understanding, try the following exercises:

1. Implement a new method in `GitRepo` to show the git log for a specific file.
2. Modify the `commit` method to allow for signing commits if a GPG key is available.
3. Implement a feature to allow aider to work with a specific Git branch, including switching branches and merging changes.
4. Add functionality to handle merge conflicts when they occur during aider's operations.
5. Implement a method to generate a "git blame" output for a file, which could be used to provide context to the AI about who wrote specific parts of the code.

Remember, Git operations can be complex and have far-reaching effects. Always be cautious when modifying version control behavior, and make sure to test thoroughly in a safe environment.

</antArtifact>

This fourth lesson provides a comprehensive look at how aider integrates with Git and handles repository operations. It explains the role of the `GitRepo` class, how it's used within the `Coder` class, and how it manages various Git operations like committing changes and tracking files.

The lesson is structured to provide both theoretical understanding and practical insights, with code examples and explanations. The exercise section encourages the junior developer to actively engage with Git integration and experiment with extending or modifying its functionality.

In the final lesson, we'll cover:

5. Advanced Topics: Error Handling, Testing, and Project Extension

This final lesson will tie together all the knowledge from the previous lessons and provide insights into more advanced aspects of the aider project.