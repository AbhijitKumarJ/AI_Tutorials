# Lesson 10: Edit and Diff Implementations in Aider

## 1. Introduction

Welcome to Lesson 10 of our aider codebase exploration! In this lesson, we'll dive deep into how aider implements code edits and generates diffs. These functionalities are crucial for aider's operation, as they allow the AI to suggest and apply changes to the codebase, and for users to review these changes effectively.

## 2. Edit Implementation

Aider implements several strategies for editing code, each encapsulated in a different Coder subclass. We'll focus on two main approaches: the EditBlockCoder and the WholeFileCoder.

### 2.1 EditBlockCoder

The EditBlockCoder, defined in `editblock_coder.py`, uses search/replace blocks for code modifications. Let's examine its key methods:

<antArtifact identifier="editblock-coder" type="application/vnd.ant.code" language="python" title="Key methods of EditBlockCoder">
class EditBlockCoder(Coder):
    edit_format = "diff"
    gpt_prompts = EditBlockPrompts()

    def get_edits(self):
        content = self.partial_response_content

        # might raise ValueError for malformed ORIG/UPD blocks
        edits = list(
            find_original_update_blocks(
                content,
                self.fence,
                self.get_inchat_relative_files(),
            )
        )

        self.shell_commands += [edit[1] for edit in edits if edit[0] is None]
        edits = [edit for edit in edits if edit[0] is not None]

        return edits

    def apply_edits(self, edits):
        failed = []
        passed = []

        for edit in edits:
            path, original, updated = edit
            full_path = self.abs_root_path(path)
            content = self.io.read_text(full_path)
            new_content = do_replace(full_path, content, original, updated, self.fence)
            if not new_content:
                # try patching any of the other files in the chat
                for full_path in self.abs_fnames:
                    content = self.io.read_text(full_path)
                    new_content = do_replace(full_path, content, original, updated, self.fence)
                    if new_content:
                        break

            if new_content:
                self.io.write_text(full_path, new_content)
                passed.append(edit)
            else:
                failed.append(edit)

        if not failed:
            return

        # Handle failed edits...


The `get_edits` method parses the AI's response to extract edit instructions, while `apply_edits` attempts to apply these edits to the appropriate files.

### 2.2 WholeFileCoder

The WholeFileCoder, defined in `wholefile_coder.py`, operates on entire files for code modifications. Here are its key methods:

```python
class WholeFileCoder(Coder):
    edit_format = "whole"
    gpt_prompts = WholeFilePrompts()

    def get_edits(self, mode="update"):
        content = self.get_multi_response_content()

        chat_files = self.get_inchat_relative_files()

        output = []
        lines = content.splitlines(keepends=True)

        edits = []

        saw_fname = None
        fname = None
        fname_source = None
        new_lines = []
        
        # Parse content to extract file edits...

        return edits

    def apply_edits(self, edits):
        for path, fname_source, new_lines in edits:
            full_path = self.abs_root_path(path)
            new_lines = "".join(new_lines)
            self.io.write_text(full_path, new_lines)

```

The WholeFileCoder's `get_edits` method parses the AI's response to extract entire file contents, while `apply_edits` replaces the entire content of the specified files.

## 3. Diff Implementation

Aider uses the `diffs.py` module to generate and display diffs of the changes. Let's examine the key functions:

```python
import difflib

def create_progress_bar(percentage):
    block = "█"
    empty = "░"
    total_blocks = 30
    filled_blocks = int(total_blocks * percentage // 100)
    empty_blocks = total_blocks - filled_blocks
    bar = block * filled_blocks + empty * empty_blocks
    return bar

def diff_partial_update(lines_orig, lines_updated, final=False, fname=None):
    """
    Given only the first part of an updated file, show the diff while
    ignoring the block of "deleted" lines that are past the end of the
    partially complete update.
    """

    num_orig_lines = len(lines_orig)

    if final:
        last_non_deleted = num_orig_lines
    else:
        last_non_deleted = find_last_non_deleted(lines_orig, lines_updated)

    if last_non_deleted is None:
        return ""

    if num_orig_lines:
        pct = last_non_deleted * 100 / num_orig_lines
    else:
        pct = 50
    bar = create_progress_bar(pct)
    bar = f" {last_non_deleted:3d} / {num_orig_lines:3d} lines [{bar}] {pct:3.0f}%\n"

    lines_orig = lines_orig[:last_non_deleted]

    if not final:
        lines_updated = lines_updated[:-1] + [bar]

    diff = difflib.unified_diff(lines_orig, lines_updated, n=5)

    diff = list(diff)[2:]

    diff = "".join(diff)
    if not diff.endswith("\n"):
        diff += "\n"

    for i in range(3, 10):
        backticks = "`" * i
        if backticks not in diff:
            break

    show = f"{backticks}diff\n"
    if fname:
        show += f"--- {fname} original\n"
        show += f"+++ {fname} updated\n"

    show += diff

    show += f"{backticks}\n\n"

    return show

def find_last_non_deleted(lines_orig, lines_updated):
    diff = list(difflib.ndiff(lines_orig, lines_updated))

    num_orig = 0
    last_non_deleted_orig = None

    for line in diff:
        code = line[0]
        if code == " ":
            num_orig += 1
            last_non_deleted_orig = num_orig
        elif code == "-":
            # line only in orig
            num_orig += 1
        elif code == "+":
            # line only in updated
            pass

    return last_non_deleted_orig

```

The `diff_partial_update` function is particularly interesting as it handles generating diffs for partial updates, which is useful for showing changes in real-time as the AI is generating them.

## 4. Integration with Git

Aider also integrates with Git for showing diffs of committed changes. This is primarily handled in the `GitRepo` class in `repo.py`:

```python
class GitRepo:
    # ...

    def get_diffs(self, fnames=None):
        # We always want diffs of index and working dir

        current_branch_has_commits = False
        try:
            active_branch = self.repo.active_branch
            try:
                commits = self.repo.iter_commits(active_branch)
                current_branch_has_commits = any(commits)
            except ANY_GIT_ERROR:
                pass
        except (TypeError,) + ANY_GIT_ERROR:
            pass

        if not fnames:
            fnames = []

        diffs = ""
        for fname in fnames:
            if not self.path_in_repo(fname):
                diffs += f"Added {fname}\n"

        try:
            if current_branch_has_commits:
                args = ["HEAD", "--"] + list(fnames)
                diffs += self.repo.git.diff(*args)
                return diffs

            wd_args = ["--"] + list(fnames)
            index_args = ["--cached"] + wd_args

            diffs += self.repo.git.diff(*index_args)
            diffs += self.repo.git.diff(*wd_args)

            return diffs
        except ANY_GIT_ERROR as err:
            self.io.tool_error(f"Unable to diff: {err}")

    def diff_commits(self, pretty, from_commit, to_commit):
        args = []
        if pretty:
            args += ["--color"]
        else:
            args += ["--color=never"]

        args += [from_commit, to_commit]
        diffs = self.repo.git.diff(*args)

        return diffs

    # ...

```

These methods allow aider to show diffs between different Git commits or between the working directory and the index.

## 5. Displaying Diffs to the User

The diffs generated by these methods are typically displayed to the user through the `InputOutput` class. For example, in the command-line interface:

```python
class InputOutput:
    # ...

    def tool_output(self, message="", log_only=False, bold=False):
        if message.strip():
            if "\n" in message:
                for line in message.splitlines():
                    self.append_chat_history(line, linebreak=True, blockquote=True, strip=strip)
            else:
                hist = message.strip() if strip else message
                self.append_chat_history(hist, linebreak=True, blockquote=True)

        message = Text(message)
        style = dict(style=color) if self.pretty and color else dict()
        self.console.print(message, **style)

    # ...

```

In the web GUI, diffs are displayed using Streamlit components:

```python
class GUI:
    # ...

    def show_edit_info(self, edit):
        commit_hash = edit.get("commit_hash")
        commit_message = edit.get("commit_message")
        diff = edit.get("diff")
        fnames = edit.get("fnames")
        if fnames:
            fnames = sorted(fnames)

        if not commit_hash and not fnames:
            return

        show_undo = False
        res = ""
        if commit_hash:
            res += f"Commit `{commit_hash}`: {commit_message}  \n"
            if commit_hash == self.coder.last_aider_commit_hash:
                show_undo = True

        if fnames:
            fnames = [f"`{fname}`" for fname in fnames]
            fnames = ", ".join(fnames)
            res += f"Applied edits to {fnames}."

        if diff:
            with st.expander(res):
                st.code(diff, language="diff")
                if show_undo:
                    self.add_undo(commit_hash)
        else:
            with st.container(border=True):
                st.write(res)
                if show_undo:
                    self.add_undo(commit_hash)

    # ...

```

## 6. Conclusion

Aider's edit and diff implementations are crucial for its functionality. The edit implementation allows the AI to make precise changes to the codebase, while the diff implementation provides clear and informative representations of these changes to the user.

Key points to remember:

1. Aider uses different strategies for editing code, including block-based edits and whole-file replacements.
2. The diff implementation can handle both partial and complete updates.
3. Aider integrates with Git for showing diffs of committed changes.
4. Diffs are displayed differently in the CLI and GUI interfaces, but both aim to provide clear and informative representations of the changes.

## Exercise

To reinforce your understanding of aider's edit and diff implementations, try the following exercises:

1. Implement a new Coder subclass that uses a different strategy for editing code, such as line-based edits.

2. Extend the diff implementation to include a summary of the changes (e.g., number of lines added, removed, and modified) along with the diff.

3. Implement a feature to allow users to selectively apply or reject individual hunks from a diff.

4. Create a visual diff representation for the GUI that shows the changes side-by-side instead of in a unified diff format.

5. Implement a feature to show the context of changes in the diff (e.g., the surrounding function or class).

Remember to consider both the CLI and GUI interfaces when working on these exercises, and think about how your changes would integrate with the existing codebase.

</antArtifact>

This lesson provides a comprehensive overview of how aider implements edits and diffs, covering both the underlying logic and how these are presented to the user in different interfaces. The lesson includes code examples from various parts of the aider codebase to illustrate these concepts, and concludes with exercises to help reinforce understanding and encourage experimentation with aider's edit and diff functionalities.