# Lesson 2: The Coder Class and Command System

## 1. Introduction

Welcome to Lesson 2 of our aider codebase exploration! In this lesson, we'll dive into the heart of aider's functionality: the Coder class and its subclasses, as well as the command system. We'll explore how these components work together to provide the core functionality of aider.

## 2. The Coder Class Hierarchy

The Coder class and its subclasses are central to aider's functionality. They handle the interaction with the AI model, file editing, and command processing. Let's start by looking at the class hierarchy:

```
Coder (base_coder.py)
├── AskCoder (ask_coder.py)
├── EditBlockCoder (editblock_coder.py)
│   └── EditBlockFencedCoder (editblock_fenced_coder.py)
├── WholeFileCoder (wholefile_coder.py)
├── UnifiedDiffCoder (udiff_coder.py)
└── ArchitectCoder (architect_coder.py)
```

Each of these classes implements a different strategy for interacting with the AI and editing code. The base `Coder` class is defined in `base_coder.py`:

```python
class Coder:
    edit_format = None
    gpt_prompts = None

    @classmethod
    def create(cls, main_model=None, edit_format=None, io=None, from_coder=None, **kwargs):
        # Factory method to create the appropriate Coder subclass
        if edit_format == "code":
            edit_format = None
        if edit_format is None:
            if from_coder:
                edit_format = from_coder.edit_format
            else:
                edit_format = main_model.edit_format

        for coder in coders.__all__:
            if hasattr(coder, "edit_format") and coder.edit_format == edit_format:
                return coder(main_model, io, **kwargs)

        raise ValueError(f"Unknown edit format {edit_format}")

    def __init__(self, main_model, io, repo=None, fnames=None, ...):
        self.main_model = main_model
        self.io = io
        self.repo = repo
        self.abs_fnames = set()
        # ... more initialization ...

    def run(self, with_message=None):
        while True:
            try:
                user_message = self.get_input()
                self.run_one(user_message, preproc=True)
                self.show_undo_hint()
            except KeyboardInterrupt:
                self.keyboard_interrupt()

    def run_one(self, user_message, preproc):
        # Process a single user message
        # ...

    def get_edits(self):
        # To be implemented by subclasses
        return []

    def apply_edits(self, edits):
        # To be implemented by subclasses
        pass

    # ... more methods ...
```

Key points about the Coder class:

1. It uses a factory method (`create`) to instantiate the appropriate subclass based on the `edit_format`.
2. The `run` method implements the main interaction loop.
3. Subclasses are expected to implement `get_edits` and `apply_edits` methods.

## 3. Coder Subclasses

Let's briefly look at the purpose of each Coder subclass:

1. **AskCoder**: Allows asking questions about code without making changes.
2. **EditBlockCoder**: Edits code using search/replace blocks.
3. **EditBlockFencedCoder**: A variation of EditBlockCoder using fenced code blocks.
4. **WholeFileCoder**: Operates on entire files for code modifications.
5. **UnifiedDiffCoder**: Uses unified diff format for code modifications.
6. **ArchitectCoder**: Specialized for high-level design and architecture discussions.

Each subclass implements its own `get_edits` and `apply_edits` methods, as well as any other specialized functionality.

## 4. The Command System

The command system in aider is implemented in the `Commands` class in `commands.py`. This class handles the various commands that users can execute within aider. Let's look at its structure:

```python
class Commands:
    def __init__(self, io, coder, voice_language=None, verify_ssl=True, args=None, parser=None, verbose=False):
        self.io = io
        self.coder = coder
        self.parser = parser
        self.args = args
        self.verbose = verbose
        # ... more initialization ...

    def run(self, inp):
        if inp.startswith("!"):
            return self.do_run("run", inp[1:])

        res = self.matching_commands(inp)
        if res is None:
            return
        matching_commands, first_word, rest_inp = res
        if len(matching_commands) == 1:
            return self.do_run(matching_commands[0][1:], rest_inp)
        elif first_word in matching_commands:
            return self.do_run(first_word[1:], rest_inp)
        # ... error handling ...

    def do_run(self, cmd_name, args):
        cmd_name = cmd_name.replace("-", "_")
        cmd_method_name = f"cmd_{cmd_name}"
        cmd_method = getattr(self, cmd_method_name, None)
        if not cmd_method:
            self.io.tool_output(f"Error: Command {cmd_name} not found.")
            return

        try:
            return cmd_method(args)
        except ANY_GIT_ERROR as err:
            self.io.tool_error(f"Unable to complete {cmd_name}: {err}")

    # Various command methods, e.g.:
    def cmd_add(self, args):
        "Add files to the chat so aider can edit them or review them in detail"
        # Implementation...

    def cmd_diff(self, args=""):
        "Display the diff of changes since the last message"
        # Implementation...

    # ... more command methods ...

```

Key points about the command system:

1. Each command is implemented as a method prefixed with `cmd_`.
2. The `run` method parses the user input and calls the appropriate command method.
3. Commands can interact with the Coder instance, the repository, and the I/O system.

## 5. Interaction Between Coder and Commands

The Coder class and the Commands class work closely together. Here's how they interact:

1. The Coder instance holds a reference to a Commands instance: `self.commands = commands or Commands(self.io, self)`.
2. When processing user input, the Coder checks if it's a command:
   ```python
   if self.commands.is_command(inp):
       return self.commands.run(inp)
   ```
3. If it's a command, it's passed to the Commands instance for execution.
4. Commands can access and modify the Coder's state, allowing for operations like adding files, showing diffs, etc.

## 6. Customizing and Extending

To add a new command or modify an existing one:

1. Add a new method to the `Commands` class, prefixed with `cmd_`.
2. Implement the command's functionality, using the `self.coder` and `self.io` references as needed.
3. The new command will automatically be available in the CLI.

To create a new Coder subclass:

1. Create a new file in the `coder/` directory.
2. Define a new class that inherits from `Coder`.
3. Implement the required methods like `get_edits` and `apply_edits`.
4. Add the new class to `coder/__init__.py` to make it available for the factory method.

## 7. Conclusion

In this lesson, we've explored the Coder class hierarchy and the command system, which form the core of aider's functionality. We've seen how different Coder subclasses implement various strategies for code editing, and how the command system allows for extensible user interactions.

Understanding these components is crucial for working with and extending aider. They provide the framework for AI-assisted code editing and user interaction that makes aider powerful and flexible.

## Exercise

To reinforce your understanding, try the following exercises:

1. Examine the `get_edits` and `apply_edits` methods in different Coder subclasses. How do they differ?
2. Add a new simple command to the `Commands` class (e.g., a "hello" command that just prints a greeting).
3. Try to trace the execution path of a command from user input through to its execution.
4. Look at how the `EditBlockCoder` class implements its editing strategy. How does it differ from `WholeFileCoder`?
5. Experiment with creating a new Coder subclass that implements a different editing strategy.

Remember, the interaction between these components can be complex. Don't hesitate to use debugging tools or add print statements to better understand the flow of execution.

This second lesson provides a deep dive into the core functionality of aider, focusing on the Coder class hierarchy and the command system. It explains how these components work together to provide the main features of aider, and how they can be extended or customized.

The lesson is structured to provide both theoretical understanding and practical insights, with code examples and explanations. The exercise section encourages the junior developer to actively engage with the codebase and experiment with its core components.

In the subsequent lessons, we'll continue to explore other important aspects of the aider project, such as:

3. AI Model Integration and the IO Module
4. Repository Handling and Git Integration
5. Advanced Topics: Error Handling, Testing, and Project Extension

Each lesson will continue to build upon the knowledge from the previous ones, gradually building a complete understanding of the aider codebase.