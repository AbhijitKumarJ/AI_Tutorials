# Supplementary Lesson 2: PDL Architecture and System Components

## Lesson Overview

This supplementary lesson dives deep into PDL's architecture, system design, and internal workings that were implicitly assumed in previous lessons. Understanding these concepts is crucial for advanced PDL development and system integration.

Duration: 3 hours (180 minutes)

## Core Architectural Components

### 1. PDL Interpreter Architecture (45 minutes)

#### 1.1 Component Overview

PDL's interpreter follows a layered architecture:

```
/pdl_interpreter
    ├── core/
    │   ├── parser/           # YAML and PDL parsing
    │   ├── validator/        # Schema validation
    │   ├── executor/         # Block execution
    │   └── context/          # State management
    ├── providers/            # LLM provider integration
    ├── tools/                # External tool integration
    └── runtime/              # Execution environment
```

#### 1.2 Execution Pipeline

Understanding the flow of PDL execution:

```python
# Simplified execution pipeline
class PDLInterpreter:
    def __init__(self):
        self.parser = PDLParser()
        self.validator = SchemaValidator()
        self.executor = BlockExecutor()
        self.context = ExecutionContext()
        
    async def execute_program(self, 
                            source: str) -> ExecutionResult:
        # 1. Parse PDL source
        ast = self.parser.parse(source)
        
        # 2. Validate against schema
        self.validator.validate(ast)
        
        # 3. Create execution context
        context = self.context.create_context()
        
        # 4. Execute blocks
        try:
            result = await self.executor.execute(ast, context)
            return ExecutionResult(
                success=True,
                output=result
            )
        except PDLExecutionError as e:
            return ExecutionResult(
                success=False,
                error=e
            )
```

### 2. Block Execution System (45 minutes)

#### 2.1 Block Execution Pipeline

The internal workings of block execution:

```python
# Core block executor
class BlockExecutor:
    def __init__(self):
        self.handlers = {
            'model': ModelBlockHandler(),
            'code': CodeBlockHandler(),
            'text': TextBlockHandler(),
            # ... other handlers
        }
        
    async def execute_block(self, 
                          block: Block, 
                          context: Context) -> Any:
        # 1. Pre-execution hooks
        await self.run_pre_execution_hooks(block, context)
        
        # 2. Get appropriate handler
        handler = self.handlers[block.kind]
        
        # 3. Execute block
        result = await handler.execute(block, context)
        
        # 4. Post-execution hooks
        await self.run_post_execution_hooks(block, result, context)
        
        return result

# Example block handler
class ModelBlockHandler:
    async def execute(self, 
                     block: ModelBlock, 
                     context: Context) -> str:
        # 1. Prepare model input
        prompt = self.prepare_prompt(block, context)
        
        # 2. Get provider
        provider = self.get_provider(block.model)
        
        # 3. Execute model call
        response = await provider.generate(
            prompt=prompt,
            parameters=block.parameters
        )
        
        # 4. Process response
        return self.process_response(response)
```

#### 2.2 State Management

PDL's state management system:

```python
# State management components
class ExecutionState:
    def __init__(self):
        self.variables = {}
        self.context = []
        self.result_document = Document()
        
    def update_variable(self, name: str, value: Any):
        self.variables[name] = value
        
    def add_to_context(self, role: str, content: str):
        self.context.append({
            "role": role,
            "content": content,
            "timestamp": datetime.now()
        })
        
    def update_document(self, content: Any):
        self.result_document.append(content)
```

### 3. Provider Integration Architecture (45 minutes)

#### 3.1 Provider Interface

PDL's provider abstraction layer:

```python
# Base provider interface
from abc import ABC, abstractmethod
from dataclasses import dataclass

@dataclass
class ProviderConfig:
    api_key: str
    base_url: str
    timeout: int = 30
    max_retries: int = 3

class LLMProvider(ABC):
    def __init__(self, config: ProviderConfig):
        self.config = config
        self._client = self._initialize_client()
    
    @abstractmethod
    async def generate(self, 
                      prompt: str, 
                      parameters: dict) -> str:
        pass
    
    @abstractmethod
    async def stream(self, 
                    prompt: str, 
                    parameters: dict) -> AsyncIterator[str]:
        pass
    
    @abstractmethod
    def _initialize_client(self):
        pass

# Concrete provider implementation
class ReplicateProvider(LLMProvider):
    async def generate(self, 
                      prompt: str, 
                      parameters: dict) -> str:
        async with aiohttp.ClientSession() as session:
            headers = self._prepare_headers()
            data = self._prepare_request(prompt, parameters)
            
            async with session.post(
                f"{self.config.base_url}/predictions",
                headers=headers,
                json=data
            ) as response:
                return await self._handle_response(response)
```

#### 3.2 Template System

PDL's template processing system:

```python
# Template processor
class TemplateProcessor:
    def __init__(self):
        self.environment = Environment(
            loader=FileSystemLoader("templates/")
        )
        
    def process_template(self, 
                        template_name: str, 
                        variables: dict) -> str:
        template = self.environment.get_template(template_name)
        return template.render(**variables)

# Provider-specific template handling
class ChatTemplateManager:
    def __init__(self):
        self.templates = {
            "replicate": {
                "user": "<|user|>{{ content }}</|user|>",
                "assistant": "<|assistant|>{{ content }}</|assistant|>",
                "system": "<|system|>{{ content }}</|system|>"
            },
            "watsonx": {
                "user": "[USER] {{ content }} [/USER]",
                "assistant": "[ASSISTANT] {{ content }} [/ASSISTANT]",
                "system": "[SYSTEM] {{ content }} [/SYSTEM]"
            }
        }
    
    def apply_template(self, 
                      provider: str, 
                      role: str, 
                      content: str) -> str:
        template = self.templates[provider][role]
        return template.replace("{{ content }}", content)
```

### 4. Runtime Internals (45 minutes)

#### 4.1 Scope Resolution

PDL's scope resolution system:

```python
# Scope manager
class ScopeManager:
    def __init__(self):
        self.scopes = []
        
    def push_scope(self, scope: dict):
        self.scopes.append(scope)
        
    def pop_scope(self):
        return self.scopes.pop()
        
    def resolve_variable(self, name: str) -> Any:
        # Search scopes from innermost to outermost
        for scope in reversed(self.scopes):
            if name in scope:
                return scope[name]
        raise VariableNotFoundError(name)

# Expression evaluator
class ExpressionEvaluator:
    def __init__(self, scope_manager: ScopeManager):
        self.scope_manager = scope_manager
        
    def evaluate(self, expression: str) -> Any:
        # Parse and evaluate expressions like ${var.field}
        return self._evaluate_expression(
            self._parse_expression(expression)
        )
```

#### 4.2 Error Handling

PDL's error handling system:

```python
# Error hierarchy
class PDLError(Exception):
    """Base class for PDL errors"""
    pass

class ParseError(PDLError):
    """Raised for YAML/PDL parsing errors"""
    pass

class ValidationError(PDLError):
    """Raised for schema validation errors"""
    pass

class ExecutionError(PDLError):
    """Raised for runtime execution errors"""
    pass

# Error handler
class ErrorHandler:
    def __init__(self):
        self.handlers = {
            ParseError: self._handle_parse_error,
            ValidationError: self._handle_validation_error,
            ExecutionError: self._handle_execution_error
        }
        
    async def handle_error(self, 
                          error: Exception,
                          context: Context) -> None:
        handler = self.handlers.get(
            type(error), 
            self._handle_unknown_error
        )
        await handler(error, context)
```

## Implementation Details

### 1. Async Processing

Example of PDL's asynchronous execution:

```python
# Async block processor
class AsyncBlockProcessor:
    async def process_blocks(self, 
                           blocks: List[Block],
                           context: Context) -> List[Any]:
        results = []
        for block in blocks:
            if self._can_parallel_execute(block):
                # Execute blocks in parallel when possible
                tasks = [
                    self._process_block(b, context) 
                    for b in block.children
                ]
                results.extend(
                    await asyncio.gather(*tasks)
                )
            else:
                # Sequential execution when required
                result = await self._process_block(
                    block, 
                    context
                )
                results.append(result)
        return results
```

### 2. Memory Management

PDL's memory management system:

```python
# Memory manager
class MemoryManager:
    def __init__(self, max_memory_mb: int = 1024):
        self.max_memory = max_memory_mb * 1024 * 1024
        self.allocated = {}
        
    def allocate(self, key: str, size: int) -> bool:
        if self.get_total_allocated() + size > self.max_memory:
            self._cleanup()
        if self.can_allocate(size):
            self.allocated[key] = size
            return True
        return False
        
    def _cleanup(self):
        # Memory cleanup strategy
        pass
```

## Practical Exercises

### Exercise 1: Custom Provider
Implement a custom LLM provider:
1. Define provider interface
2. Implement API integration
3. Add template support
4. Handle errors appropriately

### Exercise 2: Block Handler
Create a new block handler:
1. Define block type
2. Implement execution logic
3. Add state management
4. Implement error handling

### Exercise 3: Template System
Extend the template system:
1. Create new template type
2. Add provider support
3. Implement variables
4. Add validation

## Additional Resources

### Documentation
- PDL Architecture Guide
- Provider Integration Guide
- Block Handler Development
- Template System Reference

### Tools
- PDL Development Kit
- Provider Testing Tools
- Template Debugger
- Performance Profiler

### Further Reading
- "PDL Internals Deep Dive"
- "Asynchronous Execution in PDL"
- "PDL State Management"
- "Error Handling Best Practices"

This supplementary lesson provides deep insights into PDL's architecture and system components, filling in knowledge gaps about the internal workings of the system. Students should reference this material when working on advanced PDL development or system integration tasks.
