# Lesson 3: Variables and Control Flow

## Lesson Overview
This lesson focuses on PDL's variable system and control flow mechanisms. Students will learn how to effectively manage program state through variables, implement complex control flows, and create dynamic templates. The lesson emphasizes practical applications while building a strong theoretical foundation for these core concepts.

## Learning Objectives
After completing this lesson, students will be able to:
1. Implement and manage variables effectively in PDL
2. Understand and use different variable scopes
3. Create and control program flow using conditionals and loops
4. Build dynamic templates using variables
5. Manage block contributions to output
6. Debug variable and control flow issues

## Project Structure
Extend your course directory with:
```
pdl-course/
├── lessons/
│   ├── lesson1/
│   ├── lesson2/
│   └── lesson3/
│       ├── variables/
│       │   ├── basic.pdl
│       │   ├── scoping.pdl
│       │   └── templating.pdl
│       ├── control/
│       │   ├── conditionals.pdl
│       │   ├── loops.pdl
│       │   └── repeat.pdl
│       └── examples/
│           ├── chatbot.pdl
│           ├── calculator.pdl
│           └── document_processor.pdl
```

## Variables and Scoping (45 minutes)

### Basic Variable Usage
Create `lessons/lesson3/variables/basic.pdl`:
```yaml
description: Basic variable demonstration
defs:
  # Simple variable definition
  GREETING: "Hello"
  # Complex variable with template
  MESSAGE: "${GREETING}, PDL Learner!"
  # Variable with model output
  AI_RESPONSE:
    model: replicate/ibm-granite/granite-3.0-8b-instruct
    input: "Generate a friendly greeting"
text:
- "Basic greeting: ${GREETING}\n"
- "Complete message: ${MESSAGE}\n"
- "AI greeting: ${AI_RESPONSE}"
```

### Variable Scoping
Create `lessons/lesson3/variables/scoping.pdl`:
```yaml
description: Variable scope demonstration
defs:
  GLOBAL_VAR: "I am global"
text:
- "Global scope: ${GLOBAL_VAR}\n"
- lastOf:
    - def: LOCAL_VAR
      data: "I am local"
    - "Local scope: ${LOCAL_VAR}\n"
- if: ${true}
  then:
    text:
    - def: CONDITION_VAR
      data: "I am in a condition"
    - "Conditional scope: ${CONDITION_VAR}\n"
- repeat:
    text:
    - def: LOOP_VAR
      data: "I am in iteration ${i}"
    - "Loop scope: ${LOOP_VAR}\n"
  num_iterations: 2
```

### Template Expressions
Create `lessons/lesson3/variables/templating.pdl`:
```yaml
description: Template expression examples
defs:
  NUMBER: 42
  TEXT: "sample"
  LIST: [1, 2, 3, 4, 5]
text:
- "Basic insertion: ${TEXT}\n"
- "Math expression: ${NUMBER * 2}\n"
- "String operation: ${TEXT | upper}\n"
- "List operation: ${LIST | length}\n"
- "Conditional: ${NUMBER > 20 ? 'Large' : 'Small'}\n"
- "Filter example: ${LIST | select('> 3') | join(', ')}\n"
```

## Control Structures (45 minutes)

### Conditional Statements
Create `lessons/lesson3/control/conditionals.pdl`:
```yaml
description: Conditional control demonstration
defs:
  SCORE: 85
text:
- if: ${SCORE >= 90}
  then: "Grade: A\n"
  else:
    if: ${SCORE >= 80}
    then: "Grade: B\n"
    else:
      if: ${SCORE >= 70}
      then: "Grade: C\n"
      else: "Grade: F\n"

- "Nested condition example:\n"
- if: ${SCORE > 60}
  then:
    text:
    - "Passing score "
    - if: ${SCORE > 80}
      then: "with distinction!"
      else: "achieved."
  else: "Need improvement."
```

### Loop Operations
Create `lessons/lesson3/control/loops.pdl`:
```yaml
description: Loop control demonstration
defs:
  ITEMS: ["apple", "banana", "orange"]
text:
# For loop with array
- "For loop example:\n"
- for:
    item: ${ITEMS}
  repeat:
    "Processing ${item}...\n"
  join:
    with: ""

# Numeric repeat
- "\nNumeric repeat example:\n"
- repeat:
    "Iteration ${i}\n"
  num_iterations: 3

# Conditional repeat
- "\nConditional repeat example:\n"
- def: counter
  data: 0
- repeat:
    text:
    - def: counter
      data: ${counter + 1}
    - "Count: ${counter}\n"
  until: ${counter >= 3}
```

### Complex Loop Control
Create `lessons/lesson3/control/repeat.pdl`:
```yaml
description: Advanced loop control
defs:
  MAX_ATTEMPTS: 3
text:
- def: attempt
  data: 0
- repeat:
    text:
    - def: attempt
      data: ${attempt + 1}
    - "Attempt ${attempt} of ${MAX_ATTEMPTS}\n"
    - model: replicate/ibm-granite/granite-3.0-8b-instruct
      def: response
      input: "Generate a random number between 1 and 10"
    - if: ${response | int < 5}
      then: 
        def: success
        data: true
    - if: ${success}
      then: "Success! Got number < 5"
      else: "Trying again..."
  until: ${success or attempt >= MAX_ATTEMPTS}
```

## Practical Applications (45 minutes)

### Interactive Chatbot
Create `lessons/lesson3/examples/chatbot.pdl`:
```yaml
description: Interactive chatbot with memory
defs:
  MAX_TURNS: 5
  SYSTEM_PROMPT: |
    You are a helpful assistant that remembers
    previous conversation context.
text:
- role: system
  content: ${SYSTEM_PROMPT}
- def: turn_count
  data: 0
- repeat:
    text:
    - def: turn_count
      data: ${turn_count + 1}
    - "\nTurn ${turn_count}:\n"
    - read:
      def: user_input
      message: "You: "
      contribute: [context]
    - if: ${user_input | lower == 'quit'}
      then:
        def: should_exit
        data: true
    - if: ${not should_exit}
      then:
        model: replicate/ibm-granite/granite-3.0-8b-instruct
        role: assistant
  until: ${should_exit or turn_count >= MAX_TURNS}
```

### Calculator Application
Create `lessons/lesson3/examples/calculator.pdl`:
```yaml
description: Calculator with memory
defs:
  OPERATIONS: ["+", "-", "*", "/"]
text:
- def: memory
  data: 0
- repeat:
    text:
    - "\nCurrent value: ${memory}\n"
    - read:
      def: operation
      message: "Operation (+,-,*,/ or quit): "
    - if: ${operation == 'quit'}
      then:
        def: should_exit
        data: true
    - if: ${not should_exit}
      then:
        text:
        - read:
          def: number
          message: "Number: "
        - def: memory
          lang: python
          code: |
            op = """${operation}"""
            num = float("""${number}""")
            mem = float("""${memory}""")
            if op == "+":
                result = mem + num
            elif op == "-":
                result = mem - num
            elif op == "*":
                result = mem * num
            elif op == "/":
                result = mem / num if num != 0 else "Error: Division by zero"
  until: ${should_exit}
```

### Document Processor
Create `lessons/lesson3/examples/document_processor.pdl`:
```yaml
description: Document processing pipeline
defs:
  OPERATIONS:
    data:
      - name: "Summarize"
        prompt: "Summarize the following text:"
      - name: "Analyze"
        prompt: "Analyze the main themes in this text:"
      - name: "Translate"
        prompt: "Translate this text to French:"
text:
- "Enter your document:\n"
- read:
  def: document
  multiline: true
- "\nProcessing document...\n"
- for:
    operation: ${OPERATIONS}
  repeat:
    text:
    - "\n${operation.name}:\n"
    - model: replicate/ibm-granite/granite-3.0-8b-instruct
      parameters:
        temperature: 0.3
      input: |
        ${operation.prompt}
        
        ${document}
  join:
    with: "\n"
```

## Exercises (25 minutes)

### Exercise 1: Variable Manipulation
Create a PDL program that:
1. Defines variables of different types (string, number, list)
2. Performs template operations
3. Demonstrates scope management
4. Implements error handling for undefined variables

### Exercise 2: Control Flow Patterns
Create a program demonstrating:
1. Nested conditionals
2. Different loop types
3. Break conditions
4. Loop result aggregation

### Exercise 3: Integration Challenge
Build a system that:
1. Uses variables for state management
2. Implements multiple control flows
3. Handles user input
4. Processes results iteratively

## Common Pitfalls and Solutions

### Variable Scoping Issues
1. Problem: Variable not accessible
   Solution: Move definition to appropriate scope

2. Problem: Variable value unexpected
   Solution: Track variable modifications

3. Problem: Template syntax error
   Solution: Verify expression syntax

### Control Flow Challenges
1. Problem: Infinite loops
   Solution: Implement proper exit conditions

2. Problem: Unexpected loop results
   Solution: Use appropriate join strategy

3. Problem: Conditional logic errors
   Solution: Verify boolean expressions

## Assessment Questions

1. Explain how variable scoping works in PDL.

2. Describe the different types of loops available in PDL.

3. How does PDL handle template expressions?

4. What are the best practices for managing state in PDL?

5. Explain block contribution in PDL.

## Additional Resources

1. Variable Documentation
   - [PDL Variable Guide](https://ibm.github.io/prompt-declaration-language/tutorial)
   - [Template Expression Reference](https://github.com/IBM/prompt-declaration-language/examples)

2. Control Flow Examples
   - [Loop Patterns](https://github.com/IBM/prompt-declaration-language/examples)
   - [Conditional Logic](https://github.com/IBM/prompt-declaration-language/examples)

3. Best Practices
   - [State Management](https://github.com/IBM/prompt-declaration-language/examples)
   - [Control Flow Patterns](https://github.com/IBM/prompt-declaration-language/examples)

## Homework Assignment

### Task 1: State Management System
Create a PDL program that:
1. Manages complex state
2. Uses multiple variable scopes
3. Implements error handling
4. Documents state transitions

### Task 2: Control Flow Implementation
Build a system that:
1. Uses all loop types
2. Implements nested conditions
3. Handles edge cases
4. Provides clear output

### Task 3: Integration Project
Develop an application that:
1. Combines variables and control flow
2. Processes user input
3. Maintains state
4. Produces structured output

## Next Steps
Prepare for Lesson 4 by:
1. Reviewing data structures
2. Understanding type systems
3. Studying validation approaches
4. Exploring parser configurations

## Debug Tips
When working with variables and control flow:
1. Use logging for variable values
2. Verify scope boundaries
3. Test loop conditions
4. Validate template expressions
5. Check control flow paths
6. Monitor state changes
7. Verify block contributions
