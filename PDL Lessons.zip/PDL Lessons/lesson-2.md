# Lesson 2: Working with Models and Basic Syntax

## Lesson Overview
This lesson delves deeper into PDL's model interaction capabilities and syntax fundamentals. Students will learn how to work with different model providers, manage parameters effectively, and implement chat templates for sophisticated interactions. The lesson builds on the basic concepts from Lesson 1 to create more complex and controlled model interactions.

## Learning Objectives
After completing this lesson, students will be able to:
1. Configure and use multiple LLM providers through PDL
2. Implement and customize chat templates
3. Control model behavior through parameters
4. Manage roles and conversation flow
5. Handle model responses effectively
6. Implement proper error handling for model interactions

## Required Materials
- Completed Lesson 1 setup
- Access to multiple LLM providers (Replicate, WatsonX)
- Updated PDL installation
- Text editor with PDL schema support

## Project Structure
Add the following to your existing course directory:
```
pdl-course/
├── lessons/
│   ├── lesson1/
│   └── lesson2/
│       ├── providers/
│       │   ├── replicate.pdl
│       │   └── watsonx.pdl
│       ├── chat/
│       │   ├── basic_chat.pdl
│       │   ├── roles.pdl
│       │   └── templates.pdl
│       └── parameters/
│           ├── temperature.pdl
│           ├── sequences.pdl
│           └── tokens.pdl
```

## Model Providers and Configuration (40 minutes)

### Provider Setup
Let's examine how to work with different providers in PDL.

1. Replicate Configuration
Create `lessons/lesson2/providers/replicate.pdl`:
```yaml
description: Replicate model configuration
text:
- "Demonstrate provider capabilities:\n"
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  parameters:
    temperature: 0
    stop_sequences: "!"
    max_new_tokens: 100
  input: |
    List three capabilities of large language models:
    1.
```

2. WatsonX Configuration
Create `lessons/lesson2/providers/watsonx.pdl`:
```yaml
description: WatsonX model configuration
text:
- "Demonstrate WatsonX capabilities:\n"
- model: watsonx/ibm/granite-34b-code-instruct
  parameters:
    decoding_method: greedy
    stop:
    - "!"
    min_new_tokens: 1
    max_new_tokens: 100
  input: |
    List three capabilities of large language models:
    1.
```

### Provider Differences
Key differences between providers:
1. Model Identifiers:
   - Replicate: `replicate/vendor/model`
   - WatsonX: `watsonx/vendor/model`

2. Parameter Naming:
   - Replicate uses `temperature`
   - WatsonX uses `decoding_method`

3. Stop Sequences:
   - Replicate: `stop_sequences` as string
   - WatsonX: `stop` as list

## Chat Templates and Roles (40 minutes)

### Basic Chat Implementation
Create `lessons/lesson2/chat/basic_chat.pdl`:
```yaml
description: Basic chat implementation
text:
- role: system
  content: |
    You are a helpful AI assistant specializing in 
    explaining technical concepts clearly and concisely.
- role: user
  content: "What is a neural network?"
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  role: assistant
- role: user
  content: "Can you explain it using an analogy?"
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  role: assistant
```

### Role Management
Create `lessons/lesson2/chat/roles.pdl`:
```yaml
description: Role management example
defs:
  SYSTEM_PROMPT: |
    You are an expert mathematician who explains
    concepts step by step with clear reasoning.
text:
- role: system
  content: ${SYSTEM_PROMPT}
- repeat:
    text:
    - read:
      message: "Your question: "
      role: user
    - model: replicate/ibm-granite/granite-3.0-8b-instruct
      role: assistant
    - read:
      message: "Follow-up (or 'quit'): "
      def: follow_up
      role: user
  until: ${follow_up == 'quit'}
```

### Custom Templates
Create `lessons/lesson2/chat/templates.pdl`:
```yaml
description: Custom chat template example
defs:
  CUSTOM_TEMPLATE:
    pre_message: "### "
    post_message: " ###\n"
text:
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  parameters:
    roles:
      system:
        pre_message: "[System Instruction]\n"
        post_message: "\n[End Instruction]\n"
      user:
        pre_message: "[User Query]\n"
        post_message: "\n[End Query]\n"
      assistant:
        pre_message: "[Assistant Response]\n"
        post_message: "\n[End Response]\n"
  input:
    array:
    - role: system
      content: "You are a helpful coding assistant."
    - role: user
      content: "Write a Python function to calculate fibonacci numbers."
```

## Parameter Control (40 minutes)

### Temperature Control
Create `lessons/lesson2/parameters/temperature.pdl`:
```yaml
description: Temperature effect demonstration
defs:
  PROMPT: |
    Write a creative story about a robot who discovers emotions.
    Keep it under 100 words.
text:
- "Temperature 0.0 (Deterministic):\n"
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  parameters:
    temperature: 0.0
  input: ${PROMPT}
- "\nTemperature 0.7 (Balanced):\n"
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  parameters:
    temperature: 0.7
  input: ${PROMPT}
- "\nTemperature 1.0 (Creative):\n"
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  parameters:
    temperature: 1.0
  input: ${PROMPT}
```

### Stop Sequence Management
Create `lessons/lesson2/parameters/sequences.pdl`:
```yaml
description: Stop sequence control
text:
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  parameters:
    stop_sequences: ".\n"
  input: |
    Complete this sentence: The quick brown fox
```

### Token Control
Create `lessons/lesson2/parameters/tokens.pdl`:
```yaml
description: Token limit demonstration
text:
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  parameters:
    max_new_tokens: 50
    min_new_tokens: 20
  input: |
    Write a summary of artificial intelligence
```

## Advanced Concepts (20 minutes)

### Error Handling
```yaml
description: Error handling example
text:
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  fallback: |
    Unable to get model response. 
    Using fallback content.
  parameters:
    temperature: 0
  input: "What is quantum computing?"
```

### Context Management
```yaml
description: Context management
text:
- def: CONTEXT
  data: |
    Previous conversation about 
    machine learning basics
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  contribute: [context]
  input: |
    Given this context: ${CONTEXT}
    Explain neural networks.
```

## Exercises (20 minutes)

### Exercise 1: Provider Comparison
Create a PDL program that:
1. Sends the same prompt to different providers
2. Compares their responses
3. Handles provider-specific parameters
4. Implements proper error handling

### Exercise 2: Chat System
Build a chat system that:
1. Uses custom roles
2. Implements session management
3. Handles multi-turn conversation
4. Uses appropriate temperature settings

### Exercise 3: Parameter Experimentation
Create experiments to:
1. Test different temperature settings
2. Compare stop sequence strategies
3. Optimize token limits
4. Document the effects

## Common Challenges and Solutions

1. Model Response Consistency
   - Use temperature 0 for deterministic outputs
   - Implement proper seed values
   - Cache responses when needed
   - Validate outputs against expected format

2. Context Length Management
   - Monitor token usage
   - Implement windowing strategies
   - Prune unnecessary context
   - Use appropriate max_tokens

3. Error Recovery
   - Implement fallbacks
   - Add retry logic
   - Log failures
   - Handle timeouts

## Assessment Questions

1. How do provider-specific parameters affect model behavior?

2. Explain the relationship between temperature and response creativity.

3. What are the key considerations when designing chat templates?

4. How does PDL handle conversation context across multiple turns?

5. Describe strategies for managing model response length.

## Additional Resources

1. Model Documentation
   - [Granite Model Documentation](https://github.com/IBM/granite)
   - [LiteLLM Provider Guide](https://docs.litellm.ai/docs/)

2. Chat Templates
   - [PDL Chat Template Guide](https://ibm.github.io/prompt-declaration-language/tutorial)
   - [Role Management Examples](https://github.com/IBM/prompt-declaration-language/tree/main/examples/chatbot)

3. Parameter Optimization
   - [Temperature Best Practices](https://platform.openai.com/docs/api-reference/completions/create#completions/create-temperature)
   - [Token Management Guide](https://github.com/IBM/prompt-declaration-language/tree/main/examples/tutorial)

## Homework Assignment

1. Create a Multi-Provider Chat System
   - Support at least two providers
   - Implement custom templates
   - Handle errors gracefully
   - Document parameter choices

2. Experiment with Parameters
   - Test different temperatures
   - Compare stop sequences
   - Optimize token usage
   - Report findings

3. Submit Documentation
   - Source code
   - Test results
   - Parameter analysis
   - Performance comparison

## Next Steps
Prepare for Lesson 3 by:
1. Understanding variable scope
2. Reading about control structures
3. Practicing template expressions
4. Reviewing error handling

## Debug Checklist
When working with models, verify:
1. API keys and environment variables
2. Parameter compatibility
3. Template syntax
4. Role assignments
5. Context management
6. Error handling
7. Response validation
