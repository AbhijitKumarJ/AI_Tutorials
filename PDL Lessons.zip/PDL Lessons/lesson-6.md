# Lesson 6: Advanced Document Management in PDL
Duration: 3 hours (180 minutes)

## Lesson Overview
This lesson delves into PDL's advanced document management capabilities, exploring document composition, template systems, context handling, and role inheritance. Students will learn to build sophisticated document processing systems while maintaining clean, maintainable code structures.

## Required Setup

### Project Structure
```
lesson6/
├── templates/
│   ├── base.pdl
│   ├── components/
│   │   ├── header.pdl
│   │   ├── footer.pdl
│   │   └── navigation.pdl
│   └── layouts/
│       ├── single_column.pdl
│       └── two_column.pdl
├── documents/
│   ├── sample1.md
│   ├── sample2.json
│   └── sample3.yaml
├── context/
│   ├── system_prompts.yaml
│   ├── user_roles.yaml
│   └── settings.yaml
├── exercises/
│   ├── document_composition.pdl
│   ├── template_management.pdl
│   ├── context_handling.pdl
│   └── role_inheritance.pdl
├── lib/
│   ├── document_processor.py
│   ├── context_manager.py
│   └── template_engine.py
└── README.md
```

### Prerequisites
1. PDL environment from previous lessons
2. Additional Python packages:
   ```bash
   pip install jinja2 markdown pyyaml python-frontmatter
   ```
3. VSCode extensions:
   - YAML
   - Markdown Preview
   - JSON Tools

## Detailed Lesson Content

### Part 1: Document Composition (45 minutes)

#### 1.1 Building Composable Documents
Understanding PDL's document composition model through practical examples:

```yaml
description: Document Composition Example
defs:
  base_template:
    read: ./templates/base.pdl
    parser: yaml
  
  create_document:
    function:
      content: str
      metadata: dict
    return:
      text:
      - include: ${base_template}
      - def: processed_content
        lang: python
        code: |
          import markdown
          result = markdown.markdown(${content})
      - object:
          metadata: ${metadata}
          content: ${processed_content}
          timestamp: ${NOW}

text:
# Example usage
- def: document
  call: create_document
  args:
    content: |
      # Sample Document
      This is a sample document with **markdown** formatting.
    metadata:
      author: "John Doe"
      version: "1.0"
      tags: ["sample", "documentation"]
```

#### 1.2 External File Management
Implementing robust external file handling:

```yaml
description: External File Management
defs:
  file_processor:
    function:
      file_path: str
    return:
      text:
      - def: file_content
        read: ${file_path}
      - def: processed_content
        lang: python
        code: |
          import os
          import frontmatter
          
          file_ext = os.path.splitext(${file_path})[1]
          content = ${file_content}
          
          if file_ext == '.md':
              post = frontmatter.loads(content)
              result = {
                  'metadata': post.metadata,
                  'content': post.content
              }
          else:
              result = {
                  'metadata': {},
                  'content': content
              }

text:
- for:
    file: ["sample1.md", "sample2.json"]
  repeat:
    call: file_processor
    args:
      file_path: ${file}
```

### Part 2: Template Management (45 minutes)

#### 2.1 Template System Architecture
Creating a flexible template system:

```yaml
description: Template System Example
defs:
  template_engine:
    function:
      template_name: str
      context: dict
    return:
      text:
      - def: template
        read: ./templates/${template_name}.pdl
        parser: yaml
      - def: rendered_template
        lang: python
        code: |
          from jinja2 import Template
          import yaml
          
          template_data = yaml.safe_load(${template})
          template_str = yaml.dump(template_data)
          
          # Create Jinja template
          jinja_template = Template(template_str)
          
          # Render with context
          rendered = jinja_template.render(${context})
          result = yaml.safe_load(rendered)
      - include: ${rendered_template}

text:
- call: template_engine
  args:
    template_name: "layouts/single_column"
    context:
      title: "Welcome Page"
      content: "Welcome to our site!"
```

#### 2.2 Component Composition
Building reusable template components:

```yaml
description: Component Composition
defs:
  render_component:
    function:
      component_name: str
      props: dict
    return:
      text:
      - include: ./templates/components/${component_name}.pdl
      - data: ${props}

  page_builder:
    function:
      layout: str
      components: list
    return:
      text:
      - for:
          component: ${components}
        repeat:
          call: render_component
          args:
            component_name: ${component.name}
            props: ${component.props}
        join:
          as: text
          with: "\n"
```

### Part 3: Context Handling (45 minutes)

#### 3.1 Context Management System
Implementing sophisticated context management:

```yaml
description: Context Management Example
defs:
  context_manager:
    function:
      initial_context: dict
    return:
      text:
      - def: system_context
        read: ./context/system_prompts.yaml
        parser: yaml
      - def: user_context
        read: ./context/user_roles.yaml
        parser: yaml
      - def: merged_context
        lang: python
        code: |
          def deep_merge(dict1, dict2):
              """Recursively merge dictionaries"""
              result = dict1.copy()
              for key, value in dict2.items():
                  if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                      result[key] = deep_merge(result[key], value)
                  else:
                      result[key] = value
              return result
          
          result = deep_merge(${system_context}, ${user_context})
          result = deep_merge(result, ${initial_context})
      - data: ${merged_context}

text:
- def: context
  call: context_manager
  args:
    initial_context:
      user_name: "John"
      preferences:
        theme: "dark"
```

#### 3.2 Context Inheritance
Managing context inheritance in document chains:

```yaml
description: Context Inheritance Example
defs:
  inherit_context:
    function:
      parent_context: dict
      child_context: dict
    return:
      lang: python
      code: |
        def merge_with_inheritance(parent, child):
            """Merge contexts with inheritance rules"""
            result = parent.copy()
            for key, value in child.items():
                if key.startswith('override_'):
                    # Override parent value
                    base_key = key[9:]  # Remove 'override_'
                    result[base_key] = value
                elif key.startswith('extend_'):
                    # Extend parent value if it's a list
                    base_key = key[7:]  # Remove 'extend_'
                    if base_key in result and isinstance(result[base_key], list):
                        result[base_key].extend(value)
                else:
                    # Normal merge
                    result[key] = value
            return result
        
        result = merge_with_inheritance(${parent_context}, ${child_context})
```

### Part 4: Role Management and Inheritance (45 minutes)

#### 4.1 Role System Implementation
Creating a flexible role management system:

```yaml
description: Role Management Example
defs:
  role_manager:
    function:
      role_name: str
      permissions: list
    return:
      text:
      - def: base_roles
        read: ./context/roles.yaml
        parser: yaml
      - def: processed_role
        lang: python
        code: |
          def process_role(role_name, base_roles, permissions):
              """Process role with inheritance"""
              role_data = base_roles.get(role_name, {})
              inherited_roles = role_data.get('inherits', [])
              
              # Collect permissions from inherited roles
              all_permissions = set()
              for inherited in inherited_roles:
                  inherited_perms = base_roles.get(inherited, {}).get('permissions', [])
                  all_permissions.update(inherited_perms)
              
              # Add specific permissions
              all_permissions.update(permissions)
              
              return {
                  'name': role_name,
                  'inherited_from': inherited_roles,
                  'permissions': list(all_permissions)
              }
          
          result = process_role(${role_name}, ${base_roles}, ${permissions})
```

#### 4.2 Role-Based Context Management
Implementing role-based context handling:

```yaml
description: Role-Based Context Example
defs:
  create_context:
    function:
      user_role: str
      user_data: dict
    return:
      text:
      - def: role_context
        call: role_manager
        args:
          role_name: ${user_role}
          permissions: []
      - def: final_context
        lang: python
        code: |
          def apply_role_context(role_data, user_data):
              """Apply role-based context modifications"""
              context = {
                  'user': user_data,
                  'role': role_data['name'],
                  'permissions': role_data['permissions'],
                  'can_access': lambda permission: permission in role_data['permissions']
              }
              return context
          
          result = apply_role_context(${role_context}, ${user_data})
```

## Hands-on Exercises

### Exercise 1: Document System
Build a document management system that:
1. Handles multiple document formats
2. Implements template inheritance
3. Manages document metadata
4. Processes document transformations

### Exercise 2: Template Engine
Create a template engine that:
1. Supports component composition
2. Implements inheritance
3. Handles dynamic content
4. Manages template caching

### Exercise 3: Context System
Develop a context management system that:
1. Implements context inheritance
2. Handles role-based modifications
3. Manages state across document chains
4. Provides context validation

## Assessment Criteria

### Knowledge Check (30%)
- Understanding of document composition
- Template system concepts
- Context management principles
- Role inheritance patterns

### Practical Implementation (40%)
- System architecture
- Code organization
- Error handling
- Performance considerations

### Project Work (30%)
- Exercise completion
- Solution efficiency
- System scalability
- Documentation quality

## Additional Resources

### Documentation
- PDL Document Management Guide
- Template System Reference
- Context Management Patterns
- Role System Design

### Code Examples
- Document Processors
- Template Engines
- Context Managers
- Role Systems

### External References
- YAML Best Practices
- Template Engine Design
- Context Management Patterns
- Role-Based Access Control

## Next Steps
1. Review implementation patterns
2. Explore advanced template features
3. Study context optimization
4. Practice role system design

## Support Materials
- Detailed documentation
- Example repositories
- Exercise templates
- Solution guides

## Homework Assignment
1. Build a complete document processing system
2. Implement a custom template engine
3. Create a context management solution
4. Develop a role inheritance system

## Additional Notes
- Focus on code organization
- Implement proper error handling
- Consider performance implications
- Document all systems thoroughly
- Write comprehensive tests
- Consider edge cases
