# Lesson 1: Foundations and Basic Concepts

## Lesson Overview
This introductory lesson establishes the fundamental concepts of the Prompt Declaration Language (PDL) and prepares students for developing LLM-powered applications. Over the course of 160 minutes, we'll explore PDL's role in the modern AI ecosystem, set up a development environment, and create our first PDL programs.

## Learning Objectives
After completing this lesson, students will be able to:
1. Explain PDL's purpose and its relationship to LLM programming
2. Set up and configure a complete PDL development environment  
3. Write basic PDL programs using proper YAML syntax
4. Execute simple model interactions using PDL
5. Understand PDL's document-oriented programming model

## Required Materials
- Python 3.11+ installed
- Visual Studio Code with YAML extension
- Git for version control
- Active Replicate or WatsonX account
- Terminal/command line access

## Environment Setup (30 minutes)

### 1. Python Environment 
Create a new Python virtual environment and install PDL:
```bash
# Create and activate virtual environment
python -m venv pdl-course
source pdl-course/bin/activate  # On Windows: pdl-course\Scripts\activate

# Install PDL with examples
pip install 'prompt-declaration-language[examples]'
```

### 2. VS Code Configuration
Create a new project directory with the following structure:
```
pdl-course/
├── .vscode/
│   └── settings.json
├── lessons/
│   └── lesson1/
│       ├── hello.pdl
│       ├── model.pdl  
│       └── document.pdl
└── README.md
```

Add the following to `.vscode/settings.json`:
```json
{
    "yaml.schemas": {
        "https://ibm.github.io/prompt-declaration-language/dist/pdl-schema.json": "*.pdl"
    },
    "files.associations": {
        "*.pdl": "yaml"
    }
}
```

### 3. Environment Variables
Set up required environment variables for your chosen provider:

For Replicate:
```bash
export REPLICATE_API_TOKEN="your_token_here"
```

For WatsonX:
```bash
export WATSONX_URL="https://region.ml.cloud.ibm.com"
export WATSONX_APIKEY="your_api_key"  
export WATSONX_PROJECT_ID="your_project_id"
```

## Theoretical Foundations (40 minutes)

### Document-Oriented Programming
PDL approaches LLM programming through the lens of document transformation. Instead of thinking in terms of functions and procedures, we think about how to progressively build and transform documents. This paradigm has several key advantages:

1. Natural Expression: Document transformation aligns naturally with how LLMs process text
2. Composability: Document fragments can be easily combined and reused
3. Visibility: The document state is always clear and inspectable
4. Portability: Documents are language and platform agnostic

### PDL's Architecture
PDL operates on three key concepts:

1. Blocks: Fundamental units of computation that can be:
   - Text strings
   - Model calls
   - Code execution
   - Control structures
   - Data operations

2. Variables: Named storage for results that can be:
   - Defined with 'def'
   - Referenced with ${var_name}
   - Scoped to specific blocks
   - Used in templates

3. Context: Background information that:
   - Accumulates as blocks execute
   - Provides history for model calls
   - Can be explicitly managed
   - Supports conversation-like flows

## Practical Application (60 minutes)

### Example 1: Hello World
Create `lessons/lesson1/hello.pdl`:
```yaml
description: Our first PDL program
text: 
  - "Hello, PDL World!\n"
  - "This is my first program."
```

Run with:
```bash
pdl lessons/lesson1/hello.pdl
```

This introduces:
- Basic YAML syntax
- Text block structure
- PDL description field
- Multi-line documents

### Example 2: Model Interaction
Create `lessons/lesson1/model.pdl`:
```yaml
description: Basic model interaction
text:
- "What is the capital of France?\n"
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  parameters:
    temperature: 0
    stop_sequences: "?"
```

This demonstrates:
- Model block syntax
- Basic parameters
- Input/output flow
- Temperature control
- Stop sequence usage

### Example 3: Document Building
Create `lessons/lesson1/document.pdl`:
```yaml
description: Document manipulation example
defs:
  GREETING: "Hello"
  TARGET: "World"
text:
- "${GREETING}, ${TARGET}!\n"
- "The greeting was: ${GREETING}\n"
- "The target was: ${TARGET}"
```

This shows:
- Variable definition
- Template substitution
- Document composition
- Multi-line handling

## Exercises (20 minutes)

### Exercise 1: Greeting Variations
Modify hello.pdl to create three different greeting variations using different text combinations.

### Exercise 2: Temperature Exploration
Modify model.pdl to experiment with different temperature settings (0.0, 0.5, 1.0) and observe the variations in model output.

### Exercise 3: Variable Practice
Create a new PDL file that defines and uses at least three variables in different combinations.

## Common Pitfalls and Solutions

1. YAML Syntax Errors
   - Always maintain consistent indentation
   - Use spaces, not tabs
   - Be careful with special characters
   - Use the VSCode schema validation

2. Model Errors
   - Verify API keys are set correctly
   - Check model names for accuracy
   - Ensure parameters are valid
   - Monitor rate limits

3. Variable Reference Issues
   - Use correct ${var} syntax
   - Define variables before use
   - Check scope boundaries
   - Watch for typos

## Assessment Questions

1. Explain the relationship between PDL blocks and document transformation.

2. What are the advantages of PDL's document-oriented approach compared to traditional programming?

3. How does PDL handle model interactions differently from direct API calls?

4. Describe the role of the context in PDL programming.

5. What is the significance of the `description` field in PDL programs?

## Additional Resources

1. PDL Documentation
   - [Official PDL Repository](https://github.com/IBM/prompt-declaration-language)
   - [PDL Schema Documentation](https://ibm.github.io/prompt-declaration-language/dist/pdl-schema.json)

2. YAML Resources
   - [YAML Syntax Guide](https://yaml.org/spec/1.2.2/)
   - [Online YAML Validator](https://www.yamllint.com/)

3. LLM Resources
   - [Replicate Documentation](https://replicate.com/docs)
   - [WatsonX Documentation](https://www.ibm.com/docs/en/watsonx-as-a-service)

## Homework Assignment

1. Create a PDL program that:
   - Takes user input using the read block
   - Passes that input to a model
   - Processes the model's response
   - Formats the final output

2. Document your program with:
   - Clear description
   - Appropriate comments
   - Error handling
   - Variable documentation

3. Submit your program with:
   - Source code
   - Example outputs
   - Brief explanation
   - Challenges faced

## Next Steps
Prepare for Lesson 2 by:
1. Reviewing all example code
2. Completing exercises
3. Reading about model parameters
4. Setting up additional API access
