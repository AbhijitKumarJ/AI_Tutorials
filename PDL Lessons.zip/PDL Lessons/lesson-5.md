# Lesson 5: Functions and Code Integration in PDL
Duration: 3 hours (180 minutes)

## Lesson Overview
This lesson explores PDL's function capabilities and code integration features. Students will learn how to create reusable functions, integrate external code, and build complex tool chains. The focus is on practical implementation while understanding the underlying concepts of code integration and function composition.

## Required Setup

### Project Structure
```
lesson5/
├── lib/
│   ├── utils.py
│   ├── api_client.py
│   └── validators.py
├── functions/
│   ├── translation.pdl
│   ├── math_ops.pdl
│   └── text_processing.pdl
├── examples/
│   ├── weather_api.pdl
│   ├── database_integration.pdl
│   └── tool_chain.pdl
├── exercises/
│   ├── function_basics.pdl
│   ├── code_integration.pdl
│   ├── api_wrapper.pdl
│   └── tool_composition.pdl
├── tests/
│   ├── test_functions.pdl
│   └── test_integration.pdl
└── README.md
```

### Prerequisites
1. PDL environment from previous lessons
2. Additional Python packages:
   ```bash
   pip install requests sqlalchemy pandas numpy beautifulsoup4
   ```
3. Environment variables for API access:
   ```bash
   export WEATHER_API_KEY=your_key_here
   export DB_CONNECTION_STRING=your_connection_string
   ```

## Detailed Lesson Content

### Part 1: Function Definition and Structure (45 minutes)

#### 1.1 Basic Function Creation
PDL functions are defined using the `function` construct and can include parameters, type specifications, and return values:

```yaml
description: Basic Function Example
defs:
  translate:
    function:
      sentence: str
      target_language: str
    spec: {translated: str, confidence: float}
    return:
      text:
      - model: replicate/ibm-granite/granite-3.0-8b-instruct
        input: |
          Translate the following sentence to ${target_language}:
          "${sentence}"
      - def: response
        lang: python
        code: |
          import json
          parts = result.split('\n')
          translated = parts[0]
          confidence = 0.95 if len(translated) > 0 else 0.0
          result = {
              'translated': translated,
              'confidence': confidence
          }

text:
- call: translate
  args:
    sentence: "Hello, world!"
    target_language: "French"
```

#### 1.2 Function Composition
Functions can be composed to create more complex operations:

```yaml
description: Function Composition Example
defs:
  analyze_sentiment:
    function:
      text: str
    return:
      model: replicate/ibm-granite/granite-3.0-8b-instruct
      input: |
        Analyze the sentiment of this text (return positive, negative, or neutral):
        "${text}"

  translate_and_analyze:
    function:
      original_text: str
      target_language: str
    return:
      text:
      - def: translation
        call: translate
        args:
          sentence: ${original_text}
          target_language: ${target_language}
      - def: sentiment
        call: analyze_sentiment
        args:
          text: ${translation.translated}
      - data:
          original: ${original_text}
          translation: ${translation.translated}
          sentiment: ${sentiment}
          confidence: ${translation.confidence}
```

### Part 2: Code Integration Patterns (45 minutes)

#### 2.1 Python Code Integration
PDL allows seamless integration with Python code:

```yaml
description: Python Integration Example
defs:
  process_data:
    function:
      input_data: list
    return:
      lang: python
      code: |
        import pandas as pd
        import numpy as np

        def calculate_statistics(data):
            df = pd.DataFrame(data)
            stats = {
                'mean': df.mean().to_dict(),
                'median': df.median().to_dict(),
                'std': df.std().to_dict()
            }
            return stats

        result = calculate_statistics(${input_data})

text:
- def: stats_result
  call: process_data
  args:
    input_data: [
      {'value': 10, 'category': 'A'},
      {'value': 20, 'category': 'B'},
      {'value': 30, 'category': 'A'}
    ]
```

#### 2.2 External Module Integration
Integrating external Python modules within PDL:

```yaml
description: External Module Integration
defs:
  weather_service:
    function:
      city: str
    return:
      lang: python
      code: |
        import sys
        import os
        sys.path.append('./lib')
        
        from utils import format_weather
        from api_client import WeatherAPI
        
        api = WeatherAPI(os.environ['WEATHER_API_KEY'])
        weather_data = api.get_weather(${city})
        result = format_weather(weather_data)

text:
- call: weather_service
  args:
    city: "New York"
```

### Part 3: Tool Integration and API Wrappers (45 minutes)

#### 3.1 API Integration
Creating reusable API wrappers in PDL:

```yaml
description: API Wrapper Example
defs:
  api_config:
    data:
      base_url: "https://api.example.com/v1"
      headers:
        Authorization: "Bearer ${API_TOKEN}"
        Content-Type: "application/json"

  make_request:
    function:
      endpoint: str
      method: str
      payload: {optional: dict}
    return:
      lang: python
      code: |
        import requests
        import json
        
        url = f"${api_config.base_url}/{endpoint}"
        headers = ${api_config.headers}
        
        try:
            if ${method} == "GET":
                response = requests.get(url, headers=headers)
            elif ${method} == "POST":
                response = requests.post(url, headers=headers, json=${payload})
            
            response.raise_for_status()
            result = response.json()
        except Exception as e:
            result = {"error": str(e)}

text:
- call: make_request
  args:
    endpoint: "users"
    method: "GET"
```

#### 3.2 Tool Chain Creation
Building complex tool chains with PDL:

```yaml
description: Tool Chain Example
defs:
  data_pipeline:
    function:
      input_file: str
      operations: list
    return:
      lang: python
      code: |
        import pandas as pd
        from lib.utils import load_operations
        
        def apply_operations(df, ops):
            for op in ops:
                df = ops[op['name']](df, **op['params'])
            return df
        
        data = pd.read_csv(${input_file})
        operations = load_operations(${operations})
        result = apply_operations(data, operations)

text:
- call: data_pipeline
  args:
    input_file: "./data/sample.csv"
    operations:
      - name: "filter"
        params:
          column: "age"
          condition: "greater_than"
          value: 18
      - name: "sort"
        params:
          column: "name"
          ascending: true
```

### Part 4: Advanced Function Patterns (45 minutes)

#### 4.1 Error Handling in Functions
Implementing robust error handling:

```yaml
description: Function Error Handling
defs:
  safe_operation:
    function:
      input_data: dict
    return:
      text:
      - def: validation_result
        lang: python
        code: |
          try:
              # Validate input
              assert 'id' in ${input_data}, "Missing ID"
              assert 'value' in ${input_data}, "Missing value"
              result = {"valid": True}
          except Exception as e:
              result = {"valid": False, "error": str(e)}
      - if: ${validation_result.valid}
        then:
          lang: python
          code: |
            try:
                # Process data
                result = process_data(${input_data})
            except Exception as e:
                result = {"error": str(e)}
        else:
          data: ${validation_result}
```

#### 4.2 Function Testing
Testing PDL functions:

```yaml
description: Function Testing Example
defs:
  test_translation:
    function:
      test_cases: list
    return:
      text:
      - def: results
        array:
        - for:
            case: ${test_cases}
          repeat:
            - def: translation_result
              call: translate
              args:
                sentence: ${case.input}
                target_language: ${case.target_lang}
            - data:
                test_case: ${case}
                result: ${translation_result}
                passed: ${translation_result.translated == case.expected}
      - lang: python
        code: |
          successes = sum(1 for r in ${results} if r['passed'])
          total = len(${results})
          result = {
              'total_tests': total,
              'passed_tests': successes,
              'success_rate': successes / total if total > 0 else 0
          }
```

## Hands-on Exercises

### Exercise 1: Function Library
Create a library of utility functions that:
1. Process text (word count, sentiment analysis, etc.)
2. Handle data transformation
3. Implement input validation
4. Include proper error handling

### Exercise 2: API Integration
Build an API integration that:
1. Handles authentication
2. Makes requests to multiple endpoints
3. Processes responses
4. Implements rate limiting
5. Handles errors gracefully

### Exercise 3: Tool Chain
Develop a tool chain that:
1. Reads data from multiple sources
2. Applies transformations
3. Integrates with external services
4. Produces formatted output

## Assessment Criteria

### Knowledge Check (30%)
- Understanding of PDL functions
- Code integration patterns
- API integration concepts
- Error handling strategies

### Practical Implementation (40%)
- Function implementation
- Code organization
- Error handling
- Documentation quality

### Project Work (30%)
- Exercise completion
- Solution efficiency
- Integration patterns
- Testing coverage

## Additional Resources

### Documentation
- PDL Function Reference
- Code Integration Guide
- API Integration Best Practices
- Testing Strategies

### Sample Code
- Function Library Examples
- API Integration Templates
- Tool Chain Patterns
- Testing Framework

### External References
- Python Package Integration
- API Design Patterns
- Error Handling Best Practices
- Testing Methodologies

## Next Steps
1. Review and refine function implementations
2. Explore advanced integration patterns
3. Build larger tool chains
4. Contribute to function libraries

## Support Materials
- Comprehensive documentation
- Sample code repository
- Exercise templates
- Solution guidelines

## Homework Assignment
1. Extend the translation function to handle multiple languages
2. Create an API wrapper for a public service
3. Build a data processing pipeline
4. Write tests for all implementations

## Additional Notes
- Keep functions focused and single-purpose
- Document all function parameters and return values
- Implement proper error handling
- Write tests for critical functions
- Consider performance implications
- Use type hints and validation
