# PDL Lesson 2: Core Concepts and Data Structures

## 1. PDL's Type System (40%)

### 1.1 Overview of Type System Architecture

PDL implements a sophisticated type system that provides strong guarantees about program behavior while maintaining flexibility. The type system is implemented primarily through Pydantic models, providing both runtime validation and static type checking capabilities.

### 1.2 Block Hierarchy

The core of PDL's type system is built around the concept of blocks. Here's the detailed block hierarchy:

```python
BlockType: TypeAlias = None | bool | int | float | str | AdvancedBlockType

AdvancedBlockType: TypeAlias = (
    FunctionBlock
    | CallBlock
    | LitellmModelBlock
    | BamModelBlock
    | CodeBlock
    | GetBlock
    | DataBlock
    | IfBlock
    | RepeatBlock
    | RepeatUntilBlock
    | ForBlock
    | TextBlock
    | LastOfBlock
    | ArrayBlock
    | ObjectBlock
    | MessageBlock
    | ReadBlock
    | IncludeBlock
    | ErrorBlock
    | EmptyBlock
)
```

Let's examine each major block type in detail:

1. **Basic Block Structure**:
```python
class Block(BaseModel):
    """Common fields for all PDL blocks."""
    description: Optional[str] = None
    spec: Any = None
    defs: dict[str, "BlocksType"] = {}
    assign: Optional[str] = Field(default=None, alias="def")
    contribute: list[ContributeTarget] = [
        ContributeTarget.RESULT,
        ContributeTarget.CONTEXT,
    ]
    parser: Optional[ParserType] = None
    fallback: Optional["BlocksType"] = None
    role: RoleType = None
```

2. **Model Blocks**:
```python
class ModelBlock(Block):
    kind: Literal[BlockKind.MODEL] = BlockKind.MODEL
    model: str | ExpressionType
    input: Optional["BlocksType"] = None
    trace: Optional["BlockType"] = None
    modelResponse: Optional[str] = None

class BamModelBlock(ModelBlock):
    """IBM WatsonX specific model block"""
    platform: Literal[ModelPlatform.BAM]
    prompt_id: Optional[str] = None
    parameters: Optional[BamTextGenerationParameters | dict] = None
    moderations: Optional[ModerationParameters] = None
    data: Optional[PromptTemplateData] = None
    constraints: Any = None
```

3. **Control Flow Blocks**:
```python
class IfBlock(Block):
    """Conditional control structure."""
    kind: Literal[BlockKind.IF] = BlockKind.IF
    condition: ExpressionType = Field(alias="if")
    then: "BlocksType"
    elses: Optional["BlocksType"] = Field(default=None, alias="else")
    if_result: Optional[bool] = None

class ForBlock(Block):
    """Iteration over arrays."""
    kind: Literal[BlockKind.FOR] = BlockKind.FOR
    fors: dict[str, ExpressionType] = Field(alias="for")
    repeat: "BlocksType"
    join: JoinType = JoinText()
```

### 1.3 Type Validation and Error Handling

PDL implements comprehensive type validation at multiple levels:

1. **Schema Validation**:
```python
def type_check_spec(result: Any, spec: str | dict[str, Any] | list, loc) -> list[str]:
    schema = pdltype_to_jsonschema(spec, False)
    if schema is None:
        return ["Error obtaining a valid schema from spec"]
    return type_check(result, schema, loc)

def type_check(result: Any, schema: dict[str, Any], loc) -> list[str]:
    try:
        validate(instance=result, schema=schema)
    except ValidationError as e:
        errors = analyze_errors({}, schema, result, loc)
        if len(errors) == 0:
            errors = [get_loc_string(loc) + e.message]
        return errors
    return []
```

2. **Runtime Type Checking**:
```python
def analyze_errors(defs, schema, data, loc: LocationType) -> list[str]:
    """Deep validation of data against schema with detailed error reporting"""
    ret = []
    if schema == {}:
        return []  # anything matches type Any

    if is_base_type(schema):
        if "type" in schema:
            the_type = json_types_convert[schema["type"]]
            if not isinstance(data, the_type):
                ret.append(
                    get_loc_string(loc)
                    + str(data)
                    + " should be of type "
                    + str(the_type)
                )
```

## 2. Abstract Syntax Tree (AST) (30%)

### 2.1 AST Structure

PDL's AST is implemented as a hierarchy of Pydantic models, providing both structure and validation:

1. **Node Types**:
```python
class Program(RootModel):
    """Prompt Declaration Language program (PDL)"""
    root: BlocksType
```

2. **Location Tracking**:
```python
class LocationType(BaseModel):
    model_config = ConfigDict(extra="forbid")
    path: list[str]
    file: str
    table: dict[str, int]
```

### 2.2 AST Manipulation

The AST can be manipulated through various utility functions:

1. **Tree Traversal**:
```python
def iter_block_children(f: Callable[[BlocksType], None], block: BlockType) -> None:
    """Traverse all children of a block, applying function f"""
    if not isinstance(block, Block):
        return
    for blocks in block.defs.values():
        f(blocks)
    match block:
        case FunctionBlock():
            if block.returns is not None:
                f(block.returns)
        case CallBlock():
            if block.trace is not None:
                f(block.trace)
        # ... handling for other block types
```

2. **Tree Transformation**:
```python
def map_block_children(f: MappedFunctions, block: BlockType) -> BlockType:
    """Transform a block and all its children"""
    if not isinstance(block, Block):
        return block
    defs = {x: map_blocks(f, blocks) for x, blocks in block.defs.items()}
    if block.fallback is not None:
        fallback = map_blocks(f, block.fallback)
    else:
        fallback = None
    block = block.model_copy(update={"defs": defs, "fallback": fallback})
    # ... handle specific block types
    return block
```

## 3. Runtime Environment (30%)

### 3.1 Interpreter State

The PDL interpreter maintains state through several key structures:

1. **Interpreter Configuration**:
```python
class InterpreterState(BaseModel):
    yield_result: bool = False
    yield_background: bool = False
    batch: int = 1
    role: RoleType = "user"
    cwd: Path = Path.cwd()
```

2. **Scope Management**:
```python
ScopeType: TypeAlias = dict[str, Any]
empty_scope: ScopeType = {"pdl_context": []}
```

### 3.2 Expression Evaluation

PDL uses a sophisticated expression evaluation system based on Jinja2:

```python
def process_expr(scope: ScopeType, expr: Any, loc: LocationType) -> Any:
    if isinstance(expr, str):
        try:
            if expr.startswith(EXPR_START_STRING) and expr.endswith(EXPR_END_STRING):
                env = Environment(
                    block_start_string="{%%%%%PDL%%%%%%%%%%",
                    block_end_string="%%%%%PDL%%%%%%%%%%}",
                    variable_start_string=EXPR_START_STRING,
                    variable_end_string=EXPR_END_STRING,
                    undefined=StrictUndefined,
                )
                expr_ast = env.parse(expr)
                # ... expression parsing logic
```

### 3.3 Runtime Features

1. **Model Integration**:
```python
class LitellmModel:
    @staticmethod
    def generate_text(
        model_id: str,
        messages: list[Message],
        spec: Any,
        parameters: dict[str, Any],
    ) -> tuple[Message, Any]:
        if "granite" in model_id:
            parameters = set_default_granite_model_parameters(
                model_id, spec, parameters
            )
        response = completion(
            model=model_id, messages=messages, stream=False, **parameters
        )
        msg = response.choices[0].message
        return {
            "role": msg.role,
            "content": msg.content,
        }, response.json()
```

2. **Stream Processing**:
```python
def generate_text_stream(
    model_id: str,
    messages: list[Message],
    spec: Any,
    parameters: dict[str, Any],
) -> Generator[Message, Any, Any]:
    response = completion(
        model=model_id,
        messages=messages,
        stream=True,
        **parameters,
    )
    result = []
    for chunk in response:
        result.append(chunk.json())
        msg = chunk.choices[0].delta
        if msg.content is None:
            break
        yield {"role": msg.role, "content": msg.content}
    return result
```

### 3.4 Error Handling

PDL implements comprehensive error handling:

```python
class PDLRuntimeError(PDLException):
    def __init__(
        self,
        message: str,
        loc: Optional[LocationType] = None,
        trace: Optional[BlocksType] = None,
        fallback: Optional[Any] = None,
    ):
        super().__init__(message)
        self.loc = loc
        self.trace = trace
        self.fallback = fallback
        self.message = message
```

## Practice Examples

Let's look at some practical examples of using PDL's type system and runtime features:

1. **Defining a Custom Block**:
```python
class CustomBlock(Block):
    kind: Literal["custom"] = "custom"
    data: dict[str, Any]
    transform: Optional[str] = None
    
    def process(self, scope: ScopeType) -> Any:
        result = process_expr(scope, self.data, self.location)
        if self.transform:
            transform_func = get_var(self.transform, scope, self.location)
            result = transform_func(result)
        return result
```

2. **Type Validation Example**:
```yaml
description: Example with type validation
text:
- model: replicate/ibm-granite/granite-20b-code-instruct-8k
  spec:
    obj:
      name: str
      age: 
        int:
          minimum: 0
          maximum: 150
  parameters:
    temperature: 0
```

This completes Lesson 2, providing a deep understanding of PDL's core concepts and data structures. The next lesson will focus on PDL Language Features, including syntax, grammar, and advanced language capabilities.

