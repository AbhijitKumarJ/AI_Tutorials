# Lesson 4: Model Integration and Processing

## Introduction (15 minutes)
Before diving into the technical details, let's understand why model integration and processing is a crucial component of PDL. When working with Language Models (LLMs), we need a robust and flexible system to handle different model providers, manage their unique parameters, process responses, and handle errors gracefully. This lesson will explore how PDL accomplishes these tasks through its well-structured architecture.

### Learning Objectives
By the end of this lesson, you will understand:
1. How PDL abstracts different LLM providers and manages their integration
2. The complete processing pipeline from input preparation to result validation
3. Advanced features for handling multiple models and implementing fallback strategies

## Part 1: LLM Integration Architecture (35 minutes)

### Provider Abstraction Layer
PDL implements a sophisticated abstraction layer for different LLM providers in `pdl_llms.py`. Let's examine its key components:

```plaintext
pdl/
├── pdl_llms.py           # Core LLM integration 
├── pdl_ast.py           # Model-related types and classes
└── pdl_interpreter.py   # Model execution logic
```

PDL currently supports two main model providers:
1. BamModel: IBM WatsonX platform
2. LitellmModel: A unified interface for various providers through LiteLLM

The abstraction is achieved through two main classes that share similar interfaces:

```python
class BamModel:
    @staticmethod
    def generate_text(...)
    @staticmethod
    def generate_text_stream(...)

class LitellmModel:
    @staticmethod
    def generate_text(...)
    @staticmethod
    def generate_text_stream(...)
```

This consistent interface allows PDL to work with different providers while maintaining a uniform API internally.

### Model Parameter Management
PDL handles model parameters through structured classes defined in `pdl_ast.py`:

1. `BamTextGenerationParameters`: Parameters specific to BAM models
2. `LitellmParameters`: Parameters for models accessed through LiteLLM

The system provides intelligent parameter defaults and validation:
- Temperature control
- Token limits
- Sampling parameters
- Response formatting
- Stop sequences

For example, when using Granite models with LiteLLM:
```python
def set_default_granite_model_parameters(
    model_id: str,
    spec: Any,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    if parameters is None:
        parameters = {}

    # Add guided decoding if spec is provided
    if spec is not None:
        schema = pdltype_to_jsonschema(spec, True)
        parameters["guided_decoding_backend"] = "lm-format-enforcer"
        parameters["guided_json"] = schema

    # Set default temperature for Granite 3.0
    if "granite-3.0" in model_id:
        if "temperature" not in parameters:
            parameters["temperature"] = 0
```

### Response Parsing and Validation
PDL implements robust response handling:

1. **Streaming Support**: Both providers support streaming responses through generator functions:
```python
def generate_text_stream(
    model_id: str,
    messages: list[Message],
    spec: Any,
    parameters: dict[str, Any],
) -> Generator[Message, Any, Any]:
```

2. **Response Structure**: Responses are normalized into a consistent Message format:
```python
Message = TypedDict('Message', {
    'role': Optional[str],
    'content': str
})
```

3. **Error Handling**: The system implements comprehensive error handling:
- Connection issues
- Rate limits
- Invalid responses
- Timeout handling

## Part 2: Processing Pipeline (30 minutes)

### Input Preprocessing
PDL's input processing happens primarily in `pdl_interpreter.py` and involves several stages:

1. **Context Management**
The system maintains a conversation context through the `InterpreterState` class:
```python
class InterpreterState(BaseModel):
    yield_result: bool = False
    yield_background: bool = False
    batch: int = 1
    role: RoleType = "user"
    cwd: Path = Path.cwd()
```

2. **Model Execution Orchestration**
The execution flow is managed through a sophisticated generator-based system:
```python
def generate_client_response(
    state: InterpreterState,
    block: BamModelBlock | LitellmModelBlock,
    model_input: Messages,
) -> Generator[YieldMessage, Any, tuple[Message, Any]]:
    match state.batch:
        case 0:  # Streaming mode
            model_output, raw_result = yield from generate_client_response_streaming(...)
        case 1:  # Single response mode
            model_output, raw_result = yield from generate_client_response_single(...)
```

3. **Response Post-processing**
PDL implements thorough response processing:
- Role assignment and management
- Content extraction and formatting
- Error detection and handling
- Response validation against schemas

### Result Validation
The system provides comprehensive validation through:

1. **Schema Validation**:
```python
def type_check_spec(result: Any, spec: str | dict[str, Any] | list, loc) -> list[str]:
    schema = pdltype_to_jsonschema(spec, False)
    return type_check(result, schema, loc)
```

2. **Error Collection and Reporting**:
```python
def type_check(result: Any, schema: dict[str, Any], loc) -> list[str]:
    try:
        validate(instance=result, schema=schema)
    except ValidationError as e:
        errors = analyze_errors({}, schema, result, loc)
        if len(errors) == 0:
            errors = [get_loc_string(loc) + e.message]
        return errors
    return []
```

## Part 3: Advanced Integration Features (25 minutes)

### Multi-model Orchestration
PDL supports sophisticated model orchestration through:

1. **Model Selection**: Dynamic model selection based on:
- Task requirements
- Model capabilities
- Performance characteristics
- Cost considerations

2. **Fallback Strategies**: Implemented through the fallback block attribute:
```python
fallback: Optional[BlocksType] = None
```

This allows graceful degradation when primary models fail.

### Rate Limiting and Quotas
The system handles rate limiting through:

1. **Provider-specific Limits**: Each provider implementation respects API limits
2. **Batch Processing**: Support for batched requests through the batch parameter
3. **Error Recovery**: Automatic retry with exponential backoff

### Caching Mechanisms
PDL implements caching at multiple levels:

1. **Response Caching**: For reproducible results
2. **Context Caching**: To maintain conversation state
3. **Parameter Caching**: For frequently used configurations

### Performance Monitoring
The system provides comprehensive monitoring through:

1. **Logging**: Detailed logging of:
- API calls
- Response times
- Error rates
- Resource usage

2. **Metrics Collection**: Important metrics including:
- Token usage
- Response latency
- Error rates
- Cache hit rates

## Review and Q&A (15 minutes)

### Key Takeaways
1. PDL provides a robust abstraction layer for multiple LLM providers
2. The processing pipeline handles all aspects from input to validation
3. Advanced features support production deployment needs

### Common Questions
1. How do I add support for a new model provider?
2. What's the best way to implement custom validation?
3. How can I optimize performance for my use case?

### Additional Resources
1. PDL Documentation: https://ibm.github.io/prompt-declaration-language/
2. LiteLLM Documentation: https://docs.litellm.ai/
3. JSON Schema Documentation: https://json-schema.org/

## Practice Exercises
1. Implement a custom model provider
2. Create a fallback strategy for multiple models
3. Add custom validation rules for responses

## Next Steps
The next lesson will cover Advanced Features and Extensions, where we'll explore the parser architecture, code generation capabilities, and the visualization system in detail.
