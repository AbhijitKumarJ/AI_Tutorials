# PDL Lesson 3: PDL Language Features

## 1. PDL Syntax and Grammar (40%)

### 1.1 YAML Structure

PDL uses YAML as its base syntax, providing a human-readable format while enabling complex structures. Let's examine the key aspects:

1. **Basic Document Structure**:
```yaml
description: "A sample PDL program"
text:
  - "Initial text"
  - model: replicate/ibm-granite/granite-20b-code-instruct-8k
    parameters:
      temperature: 0
      max_tokens: 1024
  - "More text"
```

2. **Variable Definitions**:
```yaml
defs:
  SYSTEM_PROMPT: |
    You are an AI assistant focused on helping with programming tasks.
    Please provide clear, concise responses with code examples when appropriate.
  
  INPUT_DATA:
    read: "./data.yaml"
    parser: yaml

text:
  - "${SYSTEM_PROMPT}"
  - model: replicate/ibm-granite/granite-20b-code-instruct-8k
    input: "${INPUT_DATA}"
```

### 1.2 Expression System

PDL implements a sophisticated expression system using Jinja2 templates. Here's how it works:

1. **Expression Parsing**:
```python
def process_expr(scope: ScopeType, expr: Any, loc: LocationType) -> Any:
    """Process expressions in PDL, handling both simple variables and complex templates"""
    if isinstance(expr, str):
        try:
            if expr.startswith(EXPR_START_STRING) and expr.endswith(EXPR_END_STRING):
                env = Environment(
                    block_start_string="{%%%%%PDL%%%%%%%%%%",
                    block_end_string="%%%%%PDL%%%%%%%%%%}",
                    variable_start_string=EXPR_START_STRING,
                    variable_end_string=EXPR_END_STRING,
                    undefined=StrictUndefined,
                )
                expr_ast = env.parse(expr)
                # Single expression handling
                if len(expr_ast.body) == 1:
                    expr_ast_nodes = getattr(expr_ast.body[0], "nodes", [])
                    if len(expr_ast_nodes) == 1:
                        if isinstance(expr_ast_nodes[0], TemplateData):
                            return expr
                        result = env.compile_expression(
                            expr[2:-1], undefined_to_none=False
                        )(scope)
                        return result
```

2. **Complex Expressions**:
```yaml
description: "Complex expression example"
defs:
  data:
    users:
      - name: "John"
        age: 30
      - name: "Jane"
        age: 25
text:
  - "Users over 25: ${[user.name for user in data.users if user.age > 25]}"
  - "Average age: ${sum([user.age for user in data.users]) / len(data.users)}"
```

### 1.3 Control Structures

PDL provides several control structures for program flow:

1. **Conditional Execution**:
```yaml
text:
  - if: "${data.condition == True}"
    then:
      - "Condition is true"
      - model: replicate/ibm-granite/granite-20b-code-instruct-8k
        input: "Process for true condition"
    else:
      - "Condition is false"
      - model: replicate/ibm-granite/granite-20b-code-instruct-8k
        input: "Process for false condition"
```

2. **Loops and Iteration**:
```yaml
text:
  - repeat:
      - "Iteration ${_index}"
      - model: replicate/ibm-granite/granite-20b-code-instruct-8k
        input: "Process iteration ${_index}"
    num_iterations: 3
    join:
      as: text
      with: "\n"

  - for:
      item: "${data.items}"
    repeat:
      - "Processing ${item.name}"
      - model: replicate/ibm-granite/granite-20b-code-instruct-8k
        input: "Process ${item.content}"
```

## 2. Block System Implementation (30%)

### 2.1 Block Lifecycle

Each block in PDL goes through several stages during execution:

1. **Initialization and Validation**:
```python
def step_block(
    state: InterpreterState,
    scope: ScopeType,
    block: BlockType,
    loc: LocationType
) -> Generator[YieldMessage, Any, tuple[Any, Messages, ScopeType, BlockType]]:
    """Execute a single block, handling both simple and complex blocks"""
    if not isinstance(block, Block):
        try:
            result = process_expr(scope, block, loc)
        except PDLRuntimeExpressionError as exc:
            raise PDLRuntimeError(
                exc.message,
                loc=exc.loc or loc,
                trace=ErrorBlock(msg=exc.message, location=loc, program=block),
            ) from exc
        background = [{"role": state.role, "content": stringify(result)}]
        trace = stringify(result)
        if state.yield_background:
            yield YieldBackgroundMessage(background)
        if state.yield_result:
            yield YieldResultMessage(result)
        append_log(state, "pdl_context", background)
```

2. **State Management**:
```python
def step_advanced_block(
    state: InterpreterState,
    scope: ScopeType,
    block: AdvancedBlockType,
    loc: LocationType,
) -> Generator[YieldMessage, Any, tuple[Any, Messages, ScopeType, BlockType]]:
    """Execute an advanced block with full lifecycle handling"""
    if block.role is not None:
        state = state.with_role(block.role)
    if len(block.defs) > 0:
        scope, defs_trace = yield from step_defs(state, scope, block.defs, loc)
        block = block.model_copy(update={"defs": defs_trace})
    state = state.with_yield_result(
        state.yield_result and ContributeTarget.RESULT in block.contribute
    )
    state = state.with_yield_background(
        state.yield_background and ContributeTarget.CONTEXT in block.contribute
    )
```

### 2.2 Block Communication

Blocks can communicate through several mechanisms:

1. **Variable Scoping**:
```yaml
defs:
  SHARED_DATA: 
    data: 
      value: "Initial value"
  
text:
  - def: RESULT_1
    model: replicate/ibm-granite/granite-20b-code-instruct-8k
    input: "Process ${SHARED_DATA.value}"
  
  - def: RESULT_2
    model: replicate/ibm-granite/granite-20b-code-instruct-8k
    input: "Further process ${RESULT_1}"
```

2. **Background Context**:
```yaml
text:
  - role: system
    content: "System instructions"
  
  - role: user
    content: "User query"
  
  - role: assistant
    model: replicate/ibm-granite/granite-20b-code-instruct-8k
    # Will have access to previous system and user messages
```

## 3. Advanced Language Features (30%)

### 3.1 Custom Functions

PDL allows definition and use of custom functions:

```yaml
defs:
  process_data:
    function:
      input: str
      options:
        optional: 
          obj:
            format: str
            validate: bool
    return:
      text:
        - "Processing input: ${input}"
        - code:
            lang: python
            code: |
              import json
              result = {
                  "processed": input,
                  "options": options
              }

text:
  - call: process_data
    args:
      input: "Test data"
      options:
        format: "json"
        validate: true
```

### 3.2 Template Compilation

PDL provides powerful template compilation features:

1. **Dynamic Templates**:
```yaml
defs:
  TEMPLATE:
    data: |
      Given the following information:
      - Context: ${context}
      - Requirements: ${requirements}
      
      Please provide a response that:
      ${"\n".join([f"- {req}" for req in response_requirements])}

text:
  - model: replicate/ibm-granite/granite-20b-code-instruct-8k
    input:
      data:
        context: "Software development"
        requirements: "Code review"
        response_requirements:
          - "Identifies key issues"
          - "Suggests improvements"
          - "Provides examples"
```

2. **Template Reuse**:
```yaml
defs:
  make_prompt:
    function:
      template: str
      values:
        obj:
          context: str
          query: str
    return:
      text:
        - "${template.format(context=values.context, query=values.query)}"

text:
  - call: make_prompt
    args:
      template: |
        Context: {context}
        Query: {query}
      values:
        context: "Programming"
        query: "How to implement a binary search?"
```

### 3.3 Security and Sandboxing

PDL implements several security features:

1. **Code Execution Sandboxing**:
```python
def call_python(code: str, scope: dict) -> Any:
    """Execute Python code in a controlled environment"""
    my_namespace = types.SimpleNamespace(PDL_SESSION=__PDL_SESSION, **scope)
    exec(code, my_namespace.__dict__)
    result = my_namespace.result
    return result
```

2. **Input Validation**:
```python
def type_check_spec(result: Any, spec: str | dict[str, Any] | list, loc) -> list[str]:
    """Validate inputs against specifications"""
    schema = pdltype_to_jsonschema(spec, False)
    if schema is None:
        return ["Error obtaining a valid schema from spec"]
    return type_check(result, schema, loc)
```

## Practice Examples

Let's look at some complete examples that combine these features:

1. **Data Processing Pipeline**:
```yaml
description: "Data processing pipeline example"
defs:
  # Define data loading function
  load_data:
    function:
      file_path: str
    return:
      read: "${file_path}"
      parser: yaml
  
  # Define processing function
  process_data:
    function:
      data: "obj"
    return:
      code:
        lang: python
        code: |
          import pandas as pd
          df = pd.DataFrame(data)
          result = df.describe().to_dict()

text:
  # Load and process data
  - def: RAW_DATA
    call: load_data
    args:
      file_path: "./data.yaml"
  
  - def: PROCESSED_DATA
    call: process_data
    args:
      data: "${RAW_DATA}"
  
  # Generate analysis
  - model: replicate/ibm-granite/granite-20b-code-instruct-8k
    input: |
      Given the following data statistics:
      ${PROCESSED_DATA}
      
      Provide a detailed analysis of the key patterns and insights.
```

2. **Interactive Chat System**:
```yaml
description: "Interactive chat system example"
defs:
  SYSTEM_PROMPT: |
    You are an AI assistant specializing in code review.
    Focus on:
    - Code quality
    - Best practices
    - Performance improvements
    - Security considerations

text:
  - role: system
    content: "${SYSTEM_PROMPT}"
  
  - role: user
    content: |
      Please review this code:
      ```python
      def process(data):
          result = []
          for i in range(len(data)):
              result.append(data[i] * 2)
          return result
      ```
  
  - role: assistant
    model: replicate/ibm-granite/granite-20b-code-instruct-8k
  
  - if: "${_last_response.contains_suggestions}"
    then:
      - role: user
        content: "Can you provide example implementations for your suggestions?"
      
      - role: assistant
        model: replicate/ibm-granite/granite-20b-code-instruct-8k
```

This completes Lesson 3, providing a comprehensive understanding of PDL's language features. The next lesson will focus on Model Integration and Processing, including detailed coverage of how PDL interacts with various LLM providers.

