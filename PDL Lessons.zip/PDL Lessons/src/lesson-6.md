# Lesson 6: Testing and Development

## Introduction (15 minutes)
Testing and development practices are crucial for maintaining a robust and reliable PDL system. In this lesson, we'll explore the comprehensive testing infrastructure, development best practices, and quality assurance processes that ensure PDL's reliability and maintainability.

### Learning Objectives
By the end of this lesson, you will understand:
1. How to implement comprehensive testing strategies for PDL components
2. Best practices for PDL development and code organization
3. Quality assurance processes and metrics for PDL projects

## Part 1: Comprehensive Testing (40 minutes)

### Testing Directory Structure
Let's first understand how tests are organized in the PDL codebase:

```plaintext
tests/
├── unit/                     # Unit tests directory
│   ├── test_parser.py       # Parser tests
│   ├── test_interpreter.py  # Interpreter tests
│   ├── test_llms.py        # LLM integration tests
│   └── test_utils.py       # Utility function tests
├── integration/             # Integration tests
│   ├── test_e2e.py        # End-to-end tests
│   └── test_workflows.py  # Workflow tests
├── performance/            # Performance tests
│   ├── test_latency.py    # Latency tests
│   └── test_memory.py     # Memory usage tests
└── data/                  # Test data directory
    ├── samples/          # Sample PDL programs
    └── expected/        # Expected outputs
```

### Unit Test Structure
PDL uses PyTest for testing. Here's a detailed look at unit test implementation:

1. **Parser Tests**
```python
def test_parse_basic_block():
    """Test parsing of basic PDL blocks."""
    input_yaml = """
    description: Test block
    text:
    - "Hello"
    - model: replicate/ibm-granite/granite-20b-code-instruct-8k
      parameters:
        temperature: 0
    """
    
    # Parse the YAML
    prog, loc = parse_str(input_yaml)
    
    # Verify program structure
    assert isinstance(prog.root, list)
    assert len(prog.root) == 2
    assert isinstance(prog.root[0], str)
    assert isinstance(prog.root[1], ModelBlock)
```

2. **Interpreter Tests**
```python
def test_interpreter_variable_scope():
    """Test variable scope handling in interpreter."""
    input_yaml = """
    defs:
      VAR: "test value"
    text:
    - "${VAR}"
    """
    
    result = exec_str(
        input_yaml,
        config=InterpreterConfig(yield_result=True),
        scope={},
    )
    
    assert result == "test value"
```

3. **Mock Support**
PDL provides robust mocking capabilities for testing:

```python
class MockLLMResponse:
    def __init__(self, content: str):
        self.content = content
        self.role = "assistant"

@pytest.fixture
def mock_llm():
    """Provide a mock LLM for testing."""
    def mock_generate(*args, **kwargs):
        return MockLLMResponse("Test response")
    
    with patch('pdl.pdl_llms.LitellmModel.generate_text') as mock:
        mock.side_effect = mock_generate
        yield mock
```

### Integration Testing
Integration tests verify the interaction between components:

1. **End-to-End Tests**
```python
def test_complete_workflow():
    """Test a complete PDL workflow."""
    # Load test program
    with open("tests/data/samples/complete_workflow.pdl") as f:
        program = f.read()
    
    # Execute program
    result = exec_str(
        program,
        config=InterpreterConfig(
            yield_result=True,
            batch=1
        ),
        scope={"input_data": test_data}
    )
    
    # Verify results
    verify_workflow_output(result)
```

2. **Cross-Platform Testing**
```python
@pytest.mark.parametrize("platform", ["linux", "darwin", "win32"])
def test_platform_compatibility(platform):
    """Test PDL functionality across different platforms."""
    with patch("sys.platform", platform):
        # Test platform-specific functionality
        result = exec_platform_specific_program()
        assert_platform_compatibility(result)
```

### Performance Testing
PDL includes comprehensive performance testing:

1. **Latency Measurements**
```python
def test_model_call_latency():
    """Measure model call latency."""
    start_time = time.time()
    
    result = exec_str(
        model_test_program,
        config=InterpreterConfig(batch=1)
    )
    
    duration = time.time() - start_time
    assert duration < LATENCY_THRESHOLD
```

2. **Memory Profiling**
```python
@pytest.mark.performance
def test_memory_usage():
    """Monitor memory usage during execution."""
    import memory_profiler
    
    @memory_profiler.profile
    def execute_program():
        return exec_str(large_program)
    
    mem_usage = execute_program()
    assert max(mem_usage) < MEMORY_THRESHOLD
```

## Part 2: Development Best Practices (35 minutes)

### Code Organization
PDL follows strict code organization principles:

1. **Module Structure**
```python
# module.py
"""Module docstring explaining purpose and usage."""

# Standard library imports
import json
import typing

# Third-party imports
import yaml
from pydantic import BaseModel

# Local imports
from .pdl_ast import Block
from .pdl_utils import stringify

# Constants
MAX_RECURSION_DEPTH = 100
DEFAULT_TIMEOUT = 30

# Class definitions
class MyClass:
    """Class docstring with full documentation."""
```

2. **Error Handling Patterns**
PDL implements comprehensive error handling:

```python
class PDLException(Exception):
    """Base exception for all PDL errors."""
    def __init__(self, message):
        super().__init__(message)
        self.message = message

class PDLRuntimeError(PDLException):
    """Runtime execution errors."""
    def __init__(
        self,
        message: str,
        loc: Optional[LocationType] = None,
        trace: Optional[BlocksType] = None,
        fallback: Optional[Any] = None,
    ):
        super().__init__(message)
        self.loc = loc
        self.trace = trace
        self.fallback = fallback
```

3. **Logging System**
```python
def setup_logging():
    """Configure PDL logging system."""
    logging.basicConfig(
        filename="pdl.log",
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def append_log(state: InterpreterState, title, content):
    """Log execution events with context."""
    logger.warning("**********  %s  **********", title)
    logger.warning(str(content))
```

## Part 3: Quality Assurance (25 minutes)

### Code Quality Metrics
PDL maintains high code quality through various metrics:

1. **Type Checking**
```python
def type_check_spec(
    result: Any,
    spec: str | dict[str, Any] | list,
    loc
) -> list[str]:
    """Validate result against type specification."""
    schema = pdltype_to_jsonschema(spec, False)
    if schema is None:
        return ["Error obtaining a valid schema from spec"]
    return type_check(result, schema, loc)
```

2. **Code Coverage**
```python
# pytest.ini
[pytest]
addopts = --cov=pdl --cov-report=html --cov-report=term-missing

# Minimum coverage requirements
coverage_minimum = 85
```

3. **Style Checking**
```ini
# setup.cfg
[flake8]
max-line-length = 88
extend-ignore = E203
exclude = .git,__pycache__,build,dist

[mypy]
python_version = 3.8
warn_return_any = True
warn_unused_configs = True
disallow_untyped_defs = True
```

### Security Auditing
PDL implements security best practices:

1. **Input Validation**
```python
def validate_user_input(
    input_data: Any,
    expected_type: type,
    sanitize: bool = True
) -> tuple[bool, str]:
    """Validate and sanitize user input."""
    if not isinstance(input_data, expected_type):
        return False, f"Expected {expected_type.__name__}, got {type(input_data).__name__}"
    
    if sanitize:
        input_data = sanitize_input(input_data)
    
    return True, input_data
```

2. **Dependency Scanning**
```yaml
# .github/workflows/security.yml
name: Security Scan
on: [push, pull_request]

jobs:
  security:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Run Bandit
      run: |
        pip install bandit
        bandit -r ./pdl -ll
    - name: Check Dependencies
      run: |
        pip install safety
        safety check
```

## Review and Q&A (15 minutes)

### Key Takeaways
1. Comprehensive testing is crucial for PDL reliability
2. Well-organized code improves maintainability
3. Quality metrics ensure consistent standards

### Common Questions
1. How do I set up a test environment?
2. What are best practices for writing tests?
3. How can I contribute to PDL testing?

### Additional Resources
1. PyTest Documentation: https://docs.pytest.org/
2. Python Type Hints: https://docs.python.org/3/library/typing.html
3. Code Coverage Tools: https://coverage.readthedocs.io/

## Practice Exercises
1. Write unit tests for a custom block
2. Implement integration tests for a workflow
3. Set up performance monitoring

## Next Steps
In the next lesson, we'll explore Advanced Use Cases and Best Practices, focusing on complex prompt engineering patterns and system integration strategies.

## Further Reading
- Test-Driven Development in Python
- Performance Testing Strategies
- Code Quality Metrics and Tools
- Security Best Practices

This lesson has covered the comprehensive testing and development practices that ensure PDL's reliability and maintainability. The combination of thorough testing, well-organized code, and strict quality assurance processes makes PDL a robust platform for LLM application development.
