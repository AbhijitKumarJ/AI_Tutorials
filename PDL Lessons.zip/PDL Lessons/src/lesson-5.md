# Lesson 5: Advanced Features and Extensions

## Introduction (15 minutes)
In this lesson, we'll explore PDL's advanced features that enable sophisticated prompt engineering and language processing. PDL's parser architecture, code generation capabilities, and visualization system work together to provide a robust development environment for LLM applications. Understanding these components is crucial for building complex applications and extending PDL's functionality.

### Learning Objectives
By the end of this lesson, you will understand:
1. The detailed architecture of PDL's parser and how it processes PDL programs
2. The code generation system and its security considerations
3. The visualization system for debugging and understanding PDL programs

## Part 1: Parser Architecture (40 minutes)

### Directory Structure
Let's first understand where the parser-related code lives in the PDL codebase:

```plaintext
pdl/
├── pdl_parser.py              # Main parser implementation
├── pdl_ast.py                # AST definitions
├── pdl_schema_utils.py       # Schema utilities
├── pdl_schema_validator.py   # Schema validation
├── pdl_schema_error_analyzer.py  # Error analysis
└── pdl_location_utils.py     # Source location tracking
```

### Parser Implementation
PDL's parser is designed to handle YAML-based PDL programs with robust error handling and validation. Let's examine its key components:

1. **Entry Points**
```python
def parse_file(pdl_file: str | Path) -> tuple[Program, LocationType]:
    with open(pdl_file, "r", encoding="utf-8") as pdl_fp:
        prog_str = pdl_fp.read()
    return parse_str(prog_str, file_name=str(pdl_file))

def parse_str(pdl_str: str, file_name: str = "") -> tuple[Program, LocationType]:
    prog_yaml = yaml.safe_load(pdl_str)
    line_table = get_line_map(pdl_str)
    loc = LocationType(path=[], file=file_name, table=line_table)
```

2. **Error Recovery Strategy**
PDL implements sophisticated error recovery through a combination of:
- Schema validation
- Error analysis
- Location tracking

```python
try:
    prog = Program.model_validate(prog_yaml)
    unused_program(prog)
except ValidationError as exc:
    pdl_schema_file = Path(__file__).parent / "pdl-schema.json"
    with open(pdl_schema_file, "r", encoding="utf-8") as schema_fp:
        schema = json.load(schema_fp)
    defs = schema["$defs"]
    errors = analyze_errors(defs, defs["Program"], prog_yaml, loc)
    if errors == []:
        errors = ["The file do not respect the schema."]
    raise PDLParseError(errors) from exc
```

3. **Location Tracking**
The system maintains precise source locations for error reporting:

```python
class LocationType(BaseModel):
    path: list[str]
    file: str
    table: dict[str, int]

def get_loc_string(loc: LocationType) -> str:
    if loc.file == "":
        msg = "line " + str(get_line(loc.table, loc.path)) + " - "
    else:
        msg = loc.file + ":" + str(get_line(loc.table, loc.path)) + " - "
    return msg
```

### AST Generation
The Abstract Syntax Tree is defined through Pydantic models in `pdl_ast.py`:

1. **Block Types**
```python
class Block(BaseModel):
    """Common fields for all PDL blocks."""
    description: Optional[str] = None
    spec: Any = None
    defs: dict[str, "BlocksType"] = {}
    assign: Optional[str] = Field(default=None, alias="def")
    contribute: list[ContributeTarget] = [
        ContributeTarget.RESULT,
        ContributeTarget.CONTEXT,
    ]
```

2. **Specialized Blocks**
PDL provides specialized blocks for different purposes:
```python
class ModelBlock(Block):
    kind: Literal[BlockKind.MODEL] = BlockKind.MODEL
    model: str | ExpressionType
    input: Optional["BlocksType"] = None
    trace: Optional["BlockType"] = None
    modelResponse: Optional[str] = None

class CodeBlock(Block):
    """Execute a piece of code."""
    kind: Literal[BlockKind.CODE] = BlockKind.CODE
    lang: Literal["python", "command"]
    code: "BlocksType"
```

## Part 2: Code Generation (35 minutes)

### Template Compilation
PDL uses Jinja2 for template compilation with enhanced security features:

```python
def process_expr(scope: ScopeType, expr: Any, loc: LocationType) -> Any:
    if isinstance(expr, str):
        try:
            if expr.startswith(EXPR_START_STRING) and expr.endswith(EXPR_END_STRING):
                env = Environment(
                    block_start_string="{%%%%%PDL%%%%%%%%%%",
                    block_end_string="%%%%%PDL%%%%%%%%%%}",
                    variable_start_string=EXPR_START_STRING,
                    variable_end_string=EXPR_END_STRING,
                    undefined=StrictUndefined,
                )
```

### Code Block Isolation
PDL implements secure code execution through:

1. **Sandboxing**
```python
def call_python(code: str, scope: dict) -> Any:
    my_namespace = types.SimpleNamespace(PDL_SESSION=__PDL_SESSION, **scope)
    exec(code, my_namespace.__dict__)  
    result = my_namespace.result
    return result
```

2. **Docker Integration**
```python
def exec_docker(*args):
    try:
        docker = which("docker")
        if docker is None:
            print("Error: unable to find the docker command", file=sys.stderr)
            sys.exit(1)

        subprocess.run(
            [
                docker,
                "run",
                "-v",
                local_dir,
                "-w",
                "/local",
                "-e",
                watsonx_apikey,
                "-e",
                watsonx_url,
                "-e",
                watsonx_project_id,
                "-e",
                replicate_api_token,
                "--rm",
                "-it",
                "quay.io/project_pdl/pdl",
                *args,
            ],
            check=True,
        )
```

### Security Considerations
PDL implements several security measures:

1. **Input Validation**
- Schema validation for all inputs
- Type checking
- Path validation

2. **Resource Limits**
- Memory limits
- Execution timeouts
- API rate limiting

3. **Environment Isolation**
- Docker containerization
- Namespace separation
- Environment variable protection

## Part 3: Visualization System (25 minutes)

### Trace Data Structure
PDL's visualization system relies on a comprehensive trace:

```python
def write_trace(
    trace_file: str | Path,
    trace: BlocksType,
):
    """Write the execution trace into a file.

    Args:
        trace_file:  File to save the execution trace.
        trace: Execution trace.
    """
    try:
        with open(trace_file, "w", encoding="utf-8") as fp:
            json.dump(blocks_to_dict(trace, json_compatible=True), fp)
    except Exception:
        print("Fail to generate the trace", file=sys.stderr)
```

### Rendering Pipeline
The visualization system includes:

1. **HTML Generation**
```python
def pdl_viewer(self, trace):
    trace_str = json.dumps(trace)
    index = Template(
        """
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <style>
    .pdl_block {
      border-radius: 3px;
      margin: 3px;
      padding: 5px;
      margin: 2px;
      vertical-align: middle;
      display: inline-block;
    }
    ...
  </style>
"""
```

2. **Interactive Features**
- Block highlighting
- Code inspection
- Error visualization
- Execution flow tracking

3. **Debug Information**
The system provides detailed debugging information:
- Variable values
- Execution path
- Error contexts
- Performance metrics

## Review and Q&A (15 minutes)

### Key Takeaways
1. PDL's parser provides robust error handling and location tracking
2. Code generation is secure and flexible
3. The visualization system aids in debugging and understanding

### Common Questions
1. How can I extend the parser for custom syntax?
2. What security considerations should I keep in mind?
3. How can I customize the visualization system?

### Additional Resources
1. JSONSchema Documentation: https://json-schema.org/
2. Pydantic Documentation: https://docs.pydantic.dev/
3. Jinja2 Documentation: https://jinja.palletsprojects.com/

## Practice Exercises
1. Add a custom block type to the parser
2. Implement a new code generation template
3. Create a custom visualization view

## Next Steps
In the next lesson, we'll cover Testing and Development, where we'll explore PDL's testing framework, development best practices, and quality assurance processes in detail.

## Further Reading
- Understanding AST Manipulation
- Secure Code Generation Patterns
- Visualization Systems Design
- Error Handling Best Practices

This lesson has covered the advanced features of PDL that enable sophisticated prompt engineering and language processing. The combination of a robust parser, secure code generation, and powerful visualization tools makes PDL a comprehensive platform for LLM application development.
