# PDL Lesson 1: Foundation and Project Overview

## 1. Introduction (20%)

### 1.1 Purpose and Philosophy of PDL

The Prompt Declaration Language (PDL) represents a paradigm shift in how we approach prompt engineering for Large Language Models (LLMs). Traditional approaches to prompt engineering often involve writing prompts directly in string format, which can become unwieldy and difficult to maintain as applications grow in complexity. PDL addresses these challenges by providing a declarative approach to prompt engineering.

Unlike imperative programming where you specify exactly how to achieve a result, PDL's declarative nature allows developers to focus on what they want to achieve, letting the framework handle the implementation details. This approach brings several key advantages:

1. **Structured Prompt Management**: Instead of managing prompts as raw strings, PDL provides a structured YAML-based format that makes prompts easier to organize, maintain, and version control.

2. **Composition and Reuse**: PDL enables developers to compose complex prompts from simpler components, promoting code reuse and reducing duplication. This is achieved through its powerful template system and variable scoping mechanisms.

3. **Type Safety and Validation**: The framework includes built-in type checking and validation, helping catch errors early in the development process rather than at runtime.

4. **Integration Flexibility**: PDL is designed to work with various LLM providers through a unified interface, making it easier to switch between different models or use multiple models in the same application.

### 1.2 Core Design Principles

PDL is built on several fundamental design principles that shape its architecture and usage:

1. **Document-Oriented Nature**: 
   - All interactions in PDL form a document, whether it's a conversation with a chatbot or a chain of model calls
   - This document-oriented approach provides a natural way to track context and maintain state
   - Documents can be easily serialized, stored, and analyzed

2. **Declarative Specification**:
   - Programs are written in YAML format, focusing on what needs to be done rather than how
   - This makes programs easier to understand and modify
   - Reduces cognitive load by separating logic from implementation

3. **Strong Type System**:
   - Comprehensive type checking for both inputs and outputs
   - Helps catch errors early in the development process
   - Makes programs more maintainable and self-documenting

4. **Composability**:
   - Programs can be built from smaller, reusable components
   - Supports both vertical (chaining) and horizontal (parallel) composition
   - Promotes code reuse and maintainability

## 2. Project Structure and Architecture (40%)

### 2.1 File Organization

The PDL project follows a well-organized structure that separates concerns and promotes maintainability. Here's the detailed layout:

```
pdl/
├── pdl/
│   ├── __init__.py                 # Package initialization
│   ├── pdl.py                      # Main entry point and CLI
│   ├── pdl_analysis.py             # Static analysis utilities
│   ├── pdl_ast.py                  # Abstract Syntax Tree definitions
│   ├── pdl_ast_utils.py            # AST manipulation utilities
│   ├── pdl_dumper.py               # Serialization utilities
│   ├── pdl_interpreter.py          # Core interpreter implementation
│   ├── pdl_llms.py                 # LLM integration layer
│   ├── pdl_location_utils.py       # Source location tracking
│   ├── pdl_notebook_ext.py         # Jupyter notebook integration
│   ├── pdl_parser.py               # YAML parsing and validation
│   ├── pdl_runner.py               # Execution environment
│   ├── pdl_scheduler.py            # Task scheduling
│   ├── pdl_schema_error_analyzer.py # Schema validation
│   ├── pdl_schema_utils.py         # Schema utilities
│   ├── pdl_schema_validator.py     # Type checking
│   ├── pdl_utils.py                # General utilities
│   └── pdl_compilers/              # Code generation components
│       ├── to_regex.py             # Regex compilation
│       └── __init__.py
```

### 2.2 Core Components

Let's examine each major component in detail:

1. **Main Entry Point (pdl.py)**:
   - Provides the command-line interface
   - Handles configuration and environment setup
   - Coordinates the overall execution flow
   - Manages file I/O and logging

2. **Abstract Syntax Tree (pdl_ast.py)**:
   - Defines the core data structures that represent PDL programs
   - Implements the type system through Pydantic models
   - Provides base classes for all PDL constructs
   - Handles type validation and conversion

3. **Parser (pdl_parser.py)**:
   - Converts YAML input into AST structures
   - Performs initial validation of program structure
   - Handles error reporting and recovery
   - Manages source location tracking

4. **Interpreter (pdl_interpreter.py)**:
   - Executes PDL programs by traversing the AST
   - Manages program state and variable scope
   - Handles control flow and error recovery
   - Coordinates with LLM providers

5. **LLM Integration (pdl_llms.py)**:
   - Provides abstractions for different LLM providers
   - Handles authentication and API communication
   - Manages response streaming and error handling
   - Implements provider-specific optimizations

6. **Schema Validation (pdl_schema_*.py)**:
   - Implements comprehensive type checking
   - Validates program structure against schemas
   - Provides detailed error reporting
   - Handles custom type definitions

### 2.3 Cross-Component Interactions

Understanding how components interact is crucial for working with PDL:

1. **Execution Flow**:
   ```
   CLI Input -> Parser -> AST -> Interpreter -> LLM Providers -> Results
                 ↑          ↑          ↑
                 |          |          |
              Schema     Type       Runtime
             Validation Checking   Validation
   ```

2. **Data Flow**:
   - Input files are first parsed into AST structures
   - The AST is validated against schemas
   - The interpreter executes the program
   - Results are collected and formatted
   - Output is generated according to specifications

3. **Error Handling**:
   - Each component has its own error handling mechanisms
   - Errors are propagated up the stack with context
   - Source locations are tracked for error reporting
   - Fallback mechanisms are available for recovery

## 3. Development Environment Setup (25%)

### 3.1 Python Environment

PDL requires Python 3.11 or later due to its use of modern language features. Here's how to set up your development environment:

1. **Virtual Environment Creation**:
   ```bash
   python -m venv pdl-env
   source pdl-env/bin/activate  # On Unix
   pdl-env\Scripts\activate     # On Windows
   ```

2. **Installation**:
   ```bash
   pip install prompt-declaration-language        # Basic installation
   pip install 'prompt-declaration-language[examples]'  # With examples
   ```

3. **Development Dependencies**:
   - PyYAML for YAML parsing
   - Pydantic for data validation
   - LiteLLM for model integration
   - Jinja2 for templating

### 3.2 Environment Configuration

PDL requires several environment variables for LLM provider integration:

1. **WatsonX Configuration**:
   ```bash
   export WATSONX_URL="https://{region}.ml.cloud.ibm.com"
   export WATSONX_APIKEY="your-api-key"
   export WATSONX_PROJECT_ID="your-project-id"
   ```

2. **Replicate Configuration**:
   ```bash
   export REPLICATE_API_TOKEN="your-token"
   ```

### 3.3 IDE Setup

For optimal development experience:

1. **VSCode Configuration**:
   ```json
   {
       "yaml.schemas": {
           "https://ibm.github.io/prompt-declaration-language/dist/pdl-schema.json": "*.pdl"
       },
       "files.associations": {
           "*.pdl": "yaml"
       }
   }
   ```

2. **Editor Features**:
   - YAML syntax highlighting
   - Schema validation
   - Code completion
   - Error highlighting

## 4. Integration Understanding (15%)

### 4.1 System-Wide Considerations

When working with PDL, consider these architectural aspects:

1. **Performance Optimization**:
   - Use appropriate batch sizes for model calls
   - Implement caching where appropriate
   - Consider streaming for large outputs
   - Monitor resource usage

2. **Security Considerations**:
   - Protect API keys and credentials
   - Validate all inputs
   - Use sandbox mode for untrusted code
   - Implement rate limiting

3. **Scalability**:
   - Design for concurrent execution
   - Handle resource constraints
   - Implement proper error handling
   - Consider distributed deployment

### 4.2 Best Practices

Follow these guidelines for successful PDL development:

1. **Code Organization**:
   - Keep PDL files focused and modular
   - Use clear naming conventions
   - Document complex prompts
   - Implement proper error handling

2. **Testing**:
   - Write unit tests for components
   - Test with different model providers
   - Validate error conditions
   - Monitor performance

3. **Documentation**:
   - Maintain clear documentation
   - Include examples
   - Document error cases
   - Keep API documentation current

This concludes Lesson 1, providing a comprehensive foundation for working with PDL. In the next lesson, we'll dive deeper into PDL's type system and AST implementation.

