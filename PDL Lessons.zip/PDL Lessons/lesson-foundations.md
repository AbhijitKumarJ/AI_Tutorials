# Supplementary Lesson: PDL Core Concepts & Essential Prerequisites

## Lesson Overview

This supplementary lesson covers fundamental concepts that are essential for understanding PDL but may have been assumed or not fully explained in previous lessons. It bridges knowledge gaps and provides deeper context for PDL's design principles and implementation details.

Duration: 3 hours (180 minutes)

## Core Concepts

### 1. Understanding the Document Model (45 minutes)

#### 1.1 Document-Oriented Programming

PDL's fundamental paradigm is document-oriented programming. This means:

- Documents are first-class citizens
- Program execution produces a document
- Everything is treated as part of a document's evolution

Example of document evolution:
```yaml
# Initial document state
text:
- "What is 2+2?\n"   # Document starts with a question

# After first model call
text:
- "What is 2+2?\n"
- model: replicate/ibm-granite/granite-13b-instruct-v2
  result: "Let me solve this step by step:\n1) 2+2 = 4\n"  # Document grows

# After adding Python calculation
text:
- "What is 2+2?\n"
- model: replicate/ibm-granite/granite-13b-instruct-v2
  result: "Let me solve this step by step:\n1) 2+2 = 4\n"
- lang: python
  code: |
    result = 2 + 2
  result: "4"  # Document includes computation result
```

#### 1.2 Conversational Context Management

PDL maintains two parallel structures:
1. Result Document: The final output document
2. Background Context: The conversational history

Example of context management:
```yaml
text:
- role: system  # Sets up system context
  content: "You are a helpful math tutor."
  contribute: [context]  # Only adds to background context
  
- role: user    # User's question
  content: "What is 2+2?"
  
- model: replicate/ibm-granite/granite-13b-instruct-v2  # Assistant's response
  # Model sees full context but only latest response added to result
```

### 2. YAML Essentials for PDL (45 minutes)

#### 2.1 YAML Syntax Foundations

PDL uses YAML for its readable structure. Key YAML concepts include:

**Scalars (Simple Values)**:
```yaml
# String (multiple ways)
simple: just a string
quoted: "string with special chars: []"
multiline: |
  This is a multiline
  string that preserves
  newlines
folded: >
  This is a multiline string
  that folds newlines into
  spaces

# Numbers
integer: 42
float: 3.14

# Boolean
flag: true
negative: false

# Null
empty: null
```

**Collections**:
```yaml
# Lists
simple_list:
  - item1
  - item2
  - item3

# Maps (Dictionaries)
mapping:
  key1: value1
  key2: value2
  
# Nested Structures
complex:
  lists:
    - name: first
      values:
        - 1
        - 2
    - name: second
      values:
        - 3
        - 4
```

#### 2.2 PDL-Specific YAML Usage

PDL extends YAML with specific conventions:

```yaml
# Variable Definition and Use
defs:
  my_var: "some value"
  computed:
    lang: python
    code: |
      result = 40 + 2

# Variable Reference
text:
  - "The value is ${my_var}"
  - "Computed value: ${computed}"

# Block Structure
- model: replicate/ibm-granite/granite-13b-instruct-v2
  parameters:
    temperature: 0.7
  contribute: [context, result]
```

### 3. Type System Deep Dive (45 minutes)

#### 3.1 PDL's Type System Components

PDL uses a sophisticated type system based on JSON Schema:

```yaml
# Basic Type Definitions
spec:
  # Simple types
  string_field: str
  number_field: int
  float_field: float
  boolean_field: bool

  # Complex types
  list_type: [str]  # List of strings
  object_type:
    name: str
    age: int
    optional_field: {optional: str}

  # Constrained types
  constrained_number:
    int:
      minimum: 0
      maximum: 100
      
  pattern_string:
    str:
      pattern: "^[A-Z][a-z]+$"
```

#### 3.2 Runtime Type Checking

Understanding how PDL performs type checking:

```yaml
defs:
  validate_input:
    function:
      user_data: obj  # Input type
    spec:             # Output type
      status: str
      errors: [str]
    return:
      lang: python
      code: |
        def validate(data):
            errors = []
            # Validation logic
            return {
                "status": "valid" if not errors else "invalid",
                "errors": errors
            }
        result = validate(${user_data})
```

### 4. Integration Patterns (45 minutes)

#### 4.1 Tool Integration Architecture

PDL's tool integration framework:

```
/tools
    ├── core/
    │   ├── base_tool.py
    │   └── tool_registry.py
    ├── implementations/
    │   ├── calculator.py
    │   ├── web_search.py
    │   └── database.py
    └── schemas/
        └── tool_schema.json
```

Example tool implementation:
```python
# tools/implementations/calculator.py
from ..core.base_tool import BaseTool

class Calculator(BaseTool):
    def __init__(self):
        super().__init__(name="calculator")
        
    def execute(self, expression: str) -> float:
        # Safe evaluation of mathematical expressions
        return eval(expression, {"__builtins__": None}, {})
```

PDL usage:
```yaml
text:
- "Calculate: 23 * 45"
- lang: python
  code: |
    from tools.implementations.calculator import Calculator
    calc = Calculator()
    result = calc.execute("23 * 45")
```

#### 4.2 LLM Provider Integration

Understanding PDL's provider abstraction:

```yaml
# Provider configuration
defs:
  provider_config:
    data:
      replicate:
        api_base: "https://api.replicate.com/v1"
        models:
          - granite-13b-instruct-v2
          - granite-20b-code-instruct-v2
      watsonx:
        api_base: ${WATSONX_URL}
        models:
          - ibm/granite-13b-chat-v2
          - ibm/granite-20b-code-instruct

# Provider-specific parameters
text:
- model: replicate/ibm-granite/granite-13b-instruct-v2
  parameters:
    # Replicate-specific
    temperature: 0.7
    max_tokens: 1000

- model: watsonx/ibm/granite-13b-chat-v2
  parameters:
    # WatsonX-specific
    decoding_method: greedy
    min_new_tokens: 1
```

## Essential Prerequisites Deep Dive

### 1. Python Programming Concepts

Key Python concepts used in PDL:

```python
# Async/Await Pattern
async def process_model_call(prompt: str) -> str:
    async with aiohttp.ClientSession() as session:
        response = await session.post(
            url="model_endpoint",
            json={"prompt": prompt}
        )
        return await response.text()

# Type Hints
from typing import List, Dict, Optional

class ModelResponse:
    def __init__(
        self,
        text: str,
        metadata: Optional[Dict[str, any]] = None
    ) -> None:
        self.text = text
        self.metadata = metadata or {}

# Context Managers
class PDLContext:
    def __init__(self, scope: dict):
        self.scope = scope
        
    def __enter__(self):
        # Setup context
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        # Cleanup
        pass
```

### 2. LLM Concepts

Essential LLM concepts for PDL:

```yaml
# Temperature and Sampling
model_call:
  temperature: 0.7    # Higher = more creative
  top_p: 0.95        # Nucleus sampling threshold
  top_k: 50          # Top-k sampling limit

# Context Window Management
text:
- def: long_context
  lang: python
  code: |
    def manage_context(text, max_tokens=2048):
        # Context window management logic
        tokens = count_tokens(text)
        if tokens > max_tokens:
            return truncate_context(text, max_tokens)
        return text
```

### 3. Software Design Patterns

Key patterns used in PDL:

```python
# Observer Pattern for Document Updates
class DocumentObserver:
    def update(self, document: dict) -> None:
        pass

class PDLDocument:
    def __init__(self):
        self._observers: List[DocumentObserver] = []
        
    def attach(self, observer: DocumentObserver) -> None:
        self._observers.append(observer)
        
    def notify(self) -> None:
        for observer in self._observers:
            observer.update(self._document)

# Factory Pattern for Block Creation
class BlockFactory:
    @staticmethod
    def create_block(block_type: str, **kwargs) -> Block:
        if block_type == "model":
            return ModelBlock(**kwargs)
        elif block_type == "code":
            return CodeBlock(**kwargs)
        # etc.
```

## Practical Exercises

### Exercise 1: Document Evolution
Create a PDL program that demonstrates document evolution through multiple stages:
1. Initial text input
2. Model augmentation
3. Code computation
4. Final aggregation

### Exercise 2: Type System
Implement a custom type validator for specialized data structures:
1. Define schema
2. Implement validation
3. Test with various inputs

### Exercise 3: Tool Integration
Create a new tool integration:
1. Define tool interface
2. Implement core functionality
3. Add PDL integration
4. Test in various scenarios

## Additional Resources

### Documentation
- YAML Specification
- JSON Schema Documentation
- Python Type Hints Guide
- Async Python Programming Guide

### Tools
- YAML Validators
- JSON Schema Validators
- Python Type Checkers
- PDL Development Tools

### Further Reading
- "Understanding Document-Oriented Programming"
- "Type Systems in Domain-Specific Languages"
- "LLM Integration Patterns"
- "Asynchronous Programming with Python"

This supplementary lesson fills in the foundational knowledge gaps and provides deeper understanding of PDL's core concepts and prerequisites. Students should review this material as needed while progressing through the main course modules.
