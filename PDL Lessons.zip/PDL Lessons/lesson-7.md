# Lesson 7: Tools and Integration Patterns

## Overview and Objectives

This comprehensive lesson focuses on advanced integration patterns in PDL, particularly focusing on how PDL can be used to orchestrate complex workflows involving multiple tools and external services. By the end of this session, students will understand how to implement sophisticated patterns like ReAct (Reasoning and Acting) and RAG (Retrieval Augmented Generation), while also learning to create and integrate custom tools into their PDL workflows.

Duration: 3 hours (180 minutes)

## Project Structure
```
lesson-7/
├── examples/
│   ├── react/
│   │   ├── react_basic.pdl        # Basic ReAct pattern implementation
│   │   ├── react_advanced.pdl     # Advanced ReAct with multiple tools
│   │   └── react_functions.pdl    # Reusable ReAct functions
│   ├── rag/
│   │   ├── document_store.py      # Vector store implementation
│   │   ├── rag_basic.pdl         # Simple RAG implementation
│   │   └── rag_advanced.pdl      # Advanced RAG with filtering
│   └── tools/
│       ├── calculator.pdl        # Custom calculator tool
│       ├── weather_api.pdl      # Weather API integration
│       └── wikipedia_tool.pdl   # Wikipedia search integration
├── exercises/
│   ├── react_exercises.pdl
│   ├── rag_exercises.pdl
│   └── tool_integration_exercises.pdl
└── solutions/
    ├── react_solutions.pdl
    ├── rag_solutions.pdl
    └── tool_solutions.pdl
```

## Detailed Content Plan

### 1. ReAct Pattern Implementation (60 minutes)

The ReAct pattern combines reasoning and acting in an iterative process. We'll examine its implementation in PDL through three main components:

a) Basic ReAct Structure:
```yaml
description: Basic ReAct Pattern
text:
- def: question
  read:
    message: "Enter your question: "
- repeat:
    text:
    - def: thought
      model: replicate/ibm-granite/granite-3.0-8b-instruct
      parameters:
        stop_sequences: "Act:"
    - def: action
      model: replicate/ibm-granite/granite-3.0-8b-instruct
      parser: json
      spec: {name: str, arguments: obj}
    - def: observation
      if: ${ action.name == "Search" }
      then:
        lang: python
        code: |
          import wikipedia
          result = wikipedia.summary("${ action.arguments.topic }")
  until: ${ action.name == "Finish" }
```

This implementation demonstrates the core ReAct loop where the system:
1. Thinks about the current state (thought)
2. Decides on an action (action)
3. Observes the result (observation)
4. Continues until reaching a conclusion

### 2. RAG Implementation (60 minutes)

RAG enhances LLM responses by incorporating relevant external knowledge. Our implementation includes:

a) Document Store Setup:
```python
# document_store.py
import faiss
import numpy as np

class DocumentStore:
    def __init__(self):
        self.index = faiss.IndexFlatL2(384)
        self.documents = []
        
    def add_document(self, doc, embedding):
        self.index.add(np.array([embedding]))
        self.documents.append(doc)
        
    def search(self, query_embedding, k=3):
        distances, indices = self.index.search(
            np.array([query_embedding]), k
        )
        return [self.documents[i] for i in indices[0]]
```

b) RAG Integration in PDL:
```yaml
description: RAG Implementation
defs:
  setup:
    lang: python
    code: |
      import document_store
      PDL_SESSION.doc_store = document_store.DocumentStore()
text:
- def: query
  read:
    message: "Enter your question: "
- lang: python
  code: |
    query_embedding = compute_embedding("${ query }")
    relevant_docs = PDL_SESSION.doc_store.search(query_embedding)
    result = "\n".join(relevant_docs)
- model: replicate/ibm-granite/granite-3.0-8b-instruct
  input: |
    Given the following context:
    ${ result }
    
    Answer this question:
    ${ query }
```

### 3. Custom Tool Integration (60 minutes)

Creating and integrating custom tools involves:

a) Tool Definition:
```yaml
# calculator.pdl
defs:
  calculator:
    function:
      expression: str
    return:
      lang: python
      code: |
        import ast
        def safe_eval(expr):
            return eval(compile(ast.parse(expr, mode='eval'), '<string>', 'eval'))
        result = safe_eval("${ expression }")
```

b) Tool Integration:
```yaml
description: Tool Integration Example
text:
- def: math_problem
  read:
    message: "Enter a math problem: "
- call: calculator
  args:
    expression: ${ math_problem }
```

## Practical Exercises

1. ReAct Implementation Exercise:
   Create a ReAct system that can solve multi-step math problems using both calculation and external knowledge.

2. RAG System Development:
   Build a RAG system for a specific domain (e.g., medical questions) with custom document preprocessing.

3. Custom Tool Creation:
   Develop a custom tool that integrates with an external API and handles rate limiting and error cases.

## Assessment Criteria

Student work will be evaluated based on:

1. Implementation Quality (40%)
   - Code organization and structure
   - Error handling
   - Documentation quality
   - Performance considerations

2. Pattern Understanding (30%)
   - Correct implementation of ReAct/RAG patterns
   - Appropriate tool integration
   - Pattern adaptation for specific use cases

3. Problem Solving (30%)
   - Solution effectiveness
   - Innovation in approach
   - Scale considerations
   - Edge case handling

## Additional Resources

1. Code Examples Repository:
   - Complete working examples of all patterns
   - Performance optimization guidelines
   - Best practices documentation

2. Integration References:
   - API documentation for common services
   - Authentication handling examples
   - Rate limiting strategies

3. Testing Framework:
   - Unit test templates
   - Integration test examples
   - Performance benchmark tools

## Homework Assignment

Students will create a complete system that combines all three main components:

1. Implement a ReAct system that uses:
   - Custom-built tools
   - RAG for knowledge retrieval
   - External API integration

2. Requirements:
   - Must handle at least three different types of queries
   - Must include proper error handling
   - Must be well-documented
   - Must include tests

3. Deliverables:
   - Complete code repository
   - Documentation
   - Test suite
   - Performance analysis

## Further Exploration

Students are encouraged to explore:

1. Advanced Patterns:
   - Multi-agent systems using ReAct
   - Hybrid RAG implementations
   - Custom tool chains

2. Performance Optimization:
   - Caching strategies
   - Parallel execution
   - Resource management

3. Integration Patterns:
   - Service mesh integration
   - Event-driven architectures
   - Microservice deployment

## Next Steps

1. Review the provided code examples
2. Set up the development environment
3. Complete the initial exercises
4. Begin work on the homework assignment
5. Schedule a review session for questions

This lesson provides a foundation for building complex, integrated PDL applications. The next lesson will build upon these concepts to explore testing and debugging strategies.