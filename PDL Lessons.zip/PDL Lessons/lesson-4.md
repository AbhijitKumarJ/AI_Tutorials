# Lesson 4: Data Handling and Type System in PDL
Duration: 3 hours (180 minutes)

## Lesson Overview
This lesson focuses on PDL's robust data handling capabilities and type system. Students will learn how to work with various data formats, implement type checking, and build reliable data processing pipelines. The lesson emphasizes practical applications while building a strong theoretical foundation.

## Required Setup

### Project Structure
```
lesson4/
├── data/
│   ├── sample.json
│   ├── config.yaml
│   └── records.csv
├── exercises/
│   ├── basic_types.pdl
│   ├── data_validation.pdl
│   ├── custom_parser.pdl
│   └── error_handling.pdl
├── solutions/
│   ├── basic_types_solution.pdl
│   ├── data_validation_solution.pdl
│   ├── custom_parser_solution.pdl
│   └── error_handling_solution.pdl
└── README.md
```

### Prerequisites
1. PDL installed via pip:
   ```bash
   pip install prompt-declaration-language
   ```
2. VSCode with YAML extension configured for PDL schema:
   ```json
   {
       "yaml.schemas": {
           "https://ibm.github.io/prompt-declaration-language/dist/pdl-schema.json": "*.pdl"
       }
   }
   ```
3. Python packages for data handling:
   ```bash
   pip install pandas numpy pyyaml jsonschema
   ```

## Detailed Lesson Content

### Part 1: Understanding PDL Data Structures (45 minutes)

#### 1.1 Native Data Types
PDL supports several fundamental data types that are crucial for building robust applications:

- Strings: Text data with support for multiple YAML formats
- Numbers: Both integers and floating-point numbers
- Booleans: True/False values
- Arrays: Ordered collections
- Objects: Key-value mappings
- Null: Representing absence of value

Example demonstrating various data types:
```yaml
description: Data Types Demo
text:
- def: sample_data
  data:
    string_value: "Hello, PDL!"
    number_value: 42
    float_value: 3.14
    boolean_value: true
    array_value: [1, 2, 3]
    object_value:
      key1: value1
      key2: value2
    null_value: null
```

#### 1.2 Data Block Usage
The data block in PDL is a powerful construct for creating structured data:

```yaml
description: Data Block Example
defs:
  user_info:
    data:
      name: "Alice Johnson"
      age: 28
      roles: ["admin", "developer"]
text:
- data:
    user: ${user_info}
    timestamp: ${NOW}
    status: "active"
```

### Part 2: File Operations and Data Loading (45 minutes)

#### 2.1 Reading External Data
PDL provides flexible mechanisms for reading data from various sources:

```yaml
description: File Reading Examples
defs:
  config:
    read: ./data/config.yaml
    parser: yaml
  records:
    read: ./data/records.csv
    parser: csv
text:
- "Configuration loaded: ${config}\n"
- "Records processed: ${records}\n"
```

#### 2.2 Parser Configuration
PDL supports multiple parser types with customizable options:

- YAML Parser
- JSON Parser
- CSV Parser
- Custom Parsers

Example of custom parser implementation:
```yaml
description: Custom Parser Example
defs:
  log_data:
    read: ./data/app.log
    parser:
      regex: '^(?P<timestamp>\d{4}-\d{2}-\d{2})\s+(?P<level>\w+)\s+(?P<message>.*)$'
      mode: findall
```

### Part 3: Type System and Validation (45 minutes)

#### 3.1 Type Specifications
PDL's type system allows for precise specification of data structures:

```yaml
description: Type System Example
defs:
  user_schema:
    spec:
      name: str
      age: 
        int:
          minimum: 0
          maximum: 150
      email:
        str:
          pattern: '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
text:
- def: valid_user
  data:
    name: "John Doe"
    age: 30
    email: "john@example.com"
```

#### 3.2 Validation System
Implementing comprehensive validation:

```yaml
description: Validation Example
defs:
  validation_rules:
    spec:
      required: [name, email]
      properties:
        name:
          type: string
          minLength: 2
        email:
          type: string
          format: email
text:
- def: validation_result
  lang: python
  code: |
    import jsonschema
    try:
        jsonschema.validate(
            instance=${valid_user},
            schema=${validation_rules}
        )
        result = "Validation successful"
    except jsonschema.exceptions.ValidationError as e:
        result = f"Validation failed: {str(e)}"
```

### Part 4: Error Handling and Recovery (45 minutes)

#### 4.1 Error Handling Patterns
Implementing robust error handling in PDL:

```yaml
description: Error Handling Example
text:
- def: processed_data
  fallback:
    data:
      status: "error"
      message: "Failed to process data"
  lang: python
  code: |
    try:
        # Potentially risky operation
        result = process_data()
    except Exception as e:
        result = {"error": str(e)}
```

#### 4.2 Recovery Strategies
Building resilient data processing pipelines:

```yaml
description: Recovery Strategy Example
defs:
  retry_config:
    data:
      max_attempts: 3
      delay_seconds: 2
text:
- def: robust_operation
  lang: python
  code: |
    import time
    attempts = 0
    while attempts < ${retry_config.max_attempts}:
        try:
            result = perform_operation()
            break
        except Exception:
            attempts += 1
            if attempts < ${retry_config.max_attempts}:
                time.sleep(${retry_config.delay_seconds})
            else:
                result = "Operation failed after max attempts"
```

## Hands-on Exercises

### Exercise 1: Basic Type Implementation
Create a PDL program that:
1. Defines a complex data structure with multiple types
2. Implements type checking
3. Handles type conversion
4. Validates data against a schema

### Exercise 2: Data Processing Pipeline
Build a PDL pipeline that:
1. Reads data from multiple sources
2. Validates input data
3. Transforms data using Python
4. Outputs processed data in specific format

### Exercise 3: Custom Parser Development
Develop a custom parser that:
1. Handles a specific log format
2. Extracts structured data
3. Implements error handling
4. Provides validation

## Assessment Criteria

### Knowledge Check (30%)
- Understanding of PDL data types
- Familiarity with type system concepts
- Knowledge of parsing mechanisms
- Error handling principles

### Practical Implementation (40%)
- Code quality and organization
- Error handling robustness
- Type system implementation
- Parser configuration

### Project Completion (30%)
- Exercise completion
- Solution efficiency
- Documentation quality
- Error handling coverage

## Additional Resources

### Documentation
- PDL Type System Reference
- Data Handling Best Practices
- Error Handling Patterns
- Parser Implementation Guide

### Code Samples
- Type System Examples
- Parser Implementations
- Error Handling Patterns
- Data Processing Pipelines

### External References
- JSON Schema Documentation
- YAML Specification
- Python Type Hints Guide
- Error Handling Best Practices

## Next Steps
1. Review exercise solutions
2. Practice with real-world data
3. Explore advanced type patterns
4. Build custom validation rules

## Support Materials
- Slide deck covering theoretical concepts
- Sample code repository
- Exercise templates
- Solution guides
