# Lesson 8: Decoding and Inference in Whisper

## Introduction

Welcome to Lesson 8 of our in-depth exploration of the Whisper codebase. In this lesson, we'll focus on the decoding and inference process, which is crucial for using the trained Whisper model to generate transcriptions and translations. We'll examine how Whisper takes the output of the model and converts it into meaningful text, including how it handles different decoding strategies, sampling techniques, and timestamp generation. Understanding this process is essential for effectively using Whisper and potentially customizing its output for specific applications.

## 1. Examining the decoding.py Module in Detail

The decoding.py file contains the core logic for converting the model's raw outputs into final transcriptions or translations. Let's start by examining the structure of this file.

File layout:
```
whisper/
└── decoding.py
```

Key components of decoding.py:

a) Classes:
   - DecodingOptions: Defines options for the decoding process.
   - DecodingResult: Represents the result of a decoding operation.
   - Inference: Abstract base class for inference implementations.
   - GreedyDecoder: Implements greedy decoding.
   - BeamSearchDecoder: Implements beam search decoding.
   - SequenceRanker: Abstract base class for ranking decoded sequences.
   - MaximumLikelihoodRanker: Implements ranking based on maximum likelihood.
   - TokenDecoder: Abstract base class for token-level decoding.

b) Functions:
   - detect_language: Detects the language of the input audio.
   - decode: Main function for performing decoding and inference.

Let's examine these components in more detail.

### The DecodingOptions Class

The DecodingOptions class is a dataclass that encapsulates all the parameters that control the decoding process. Here's a simplified view:

```python
@dataclass(frozen=True)
class DecodingOptions:
    task: str = "transcribe"
    language: Optional[str] = None
    temperature: float = 0.0
    sample_len: Optional[int] = None
    best_of: Optional[int] = None
    beam_size: Optional[int] = None
    patience: Optional[float] = None
    length_penalty: Optional[float] = None
    prompt: Optional[Union[str, List[int]]] = None
    prefix: Optional[Union[str, List[int]]] = None
    suppress_tokens: Optional[Union[str, Iterable[int]]] = "-1"
    suppress_blank: bool = True
    without_timestamps: bool = False
    max_initial_timestamp: Optional[float] = 1.0
    # ... more options ...
```

This class allows users to customize various aspects of the decoding process, such as:
- The task (transcription or translation)
- The target language
- The decoding algorithm (greedy or beam search)
- The sampling temperature
- Token suppression
- Timestamp handling

Understanding these options is crucial for fine-tuning the decoding process for specific use cases.

## 2. Understanding Beam Search and Greedy Decoding

Whisper implements two main decoding strategies: greedy decoding and beam search. Let's examine each of these in detail.

### Greedy Decoding

Greedy decoding is the simpler of the two strategies. At each step of the decoding process, it selects the token with the highest probability. This is implemented in the GreedyDecoder class:

```python
class GreedyDecoder(TokenDecoder):
    def __init__(self, temperature: float, eot: int):
        self.temperature = temperature
        self.eot = eot

    def update(self, tokens: Tensor, logits: Tensor, sum_logprobs: Tensor) -> Tuple[Tensor, bool]:
        if self.temperature == 0:
            next_tokens = logits.argmax(dim=-1)
        else:
            next_tokens = Categorical(logits=logits / self.temperature).sample()

        logprobs = F.log_softmax(logits.float(), dim=-1)
        current_logprobs = logprobs[torch.arange(logprobs.shape[0]), next_tokens]
        sum_logprobs += current_logprobs * (tokens[:, -1] != self.eot)

        next_tokens[tokens[:, -1] == self.eot] = self.eot
        tokens = torch.cat([tokens, next_tokens[:, None]], dim=-1)

        completed = (tokens[:, -1] == self.eot).all()
        return tokens, completed
```

Greedy decoding is fast but can sometimes lead to suboptimal results, especially for tasks with multiple valid outputs.

### Beam Search

Beam search is a more sophisticated decoding strategy that maintains multiple candidate sequences at each step. This is implemented in the BeamSearchDecoder class:

```python
class BeamSearchDecoder(TokenDecoder):
    def __init__(self, beam_size: int, eot: int, inference: Inference, patience: Optional[float] = None):
        self.beam_size = beam_size
        self.eot = eot
        self.inference = inference
        self.patience = patience or 1.0
        self.max_candidates: int = round(beam_size * self.patience)
        self.finished_sequences = None

    def update(self, tokens: Tensor, logits: Tensor, sum_logprobs: Tensor) -> Tuple[Tensor, bool]:
        # Implementation details...
```

Beam search explores multiple possible sequences in parallel, which can lead to better results but is computationally more expensive. The 'beam size' parameter controls the number of candidates maintained at each step.

## 3. Exploring Temperature and Sampling Techniques

The temperature parameter in the DecodingOptions class plays a crucial role in controlling the randomness of the decoding process. Here's how it works:

- When temperature = 0, the decoding is deterministic, always choosing the most likely token.
- As temperature increases, the distribution of probabilities becomes more uniform, introducing more randomness into the selection process.

This is implemented in the GreedyDecoder class:

```python
if self.temperature == 0:
    next_tokens = logits.argmax(dim=-1)
else:
    next_tokens = Categorical(logits=logits / self.temperature).sample()
```

By adjusting the temperature, users can control the trade-off between diversity and quality in the generated output. Higher temperatures can lead to more diverse outputs but may also introduce more errors.

## 4. Handling Timestamp Generation

One of Whisper's unique features is its ability to generate timestamps for the transcribed text. This is handled through special timestamp tokens in the model's vocabulary.

The ApplyTimestampRules class in decoding.py is responsible for enforcing rules about timestamp tokens:

```python
class ApplyTimestampRules(LogitFilter):
    def __init__(self, tokenizer: Tokenizer, sample_begin: int, max_initial_timestamp_index: Optional[int]):
        self.tokenizer = tokenizer
        self.sample_begin = sample_begin
        self.max_initial_timestamp_index = max_initial_timestamp_index

    def apply(self, logits: Tensor, tokens: Tensor):
        # Implementation details...
```

This class ensures that:
- Timestamp tokens appear in pairs (start and end times for each segment)
- Timestamps don't decrease as the sequence progresses
- The first timestamp is within a reasonable range

Understanding this process is crucial for applications that require precise timing information for the transcribed text.

## 5. Implementing Custom Decoding Strategies

Whisper's modular design allows for the implementation of custom decoding strategies. This can be done by subclassing the TokenDecoder class:

```python
class TokenDecoder:
    def reset(self):
        """Initialize any stateful variables for decoding a new sequence"""

    def update(self, tokens: Tensor, logits: Tensor, sum_logprobs: Tensor) -> Tuple[Tensor, bool]:
        """Specify how to select the next token, based on the current trace and logits"""
        raise NotImplementedError

    def finalize(self, tokens: Tensor, sum_logprobs: Tensor) -> Tuple[Sequence[Sequence[Tensor]], List[List[float]]]:
        """Finalize search and return the final candidate sequences"""
        raise NotImplementedError
```

To implement a custom decoding strategy:
1. Subclass TokenDecoder
2. Implement the update method to define how the next token is selected
3. Implement the finalize method to process the final set of candidate sequences
4. Use your custom decoder by passing it to the DecodingTask constructor

This flexibility allows for the implementation of specialized decoding strategies tailored to specific use cases or languages.

## Practical Exercise

To reinforce your understanding of the decoding process in Whisper, try the following exercise:

1. Load a pre-trained Whisper model.
2. Transcribe an audio file using different decoding options.
3. Compare the results of greedy decoding vs. beam search.
4. Experiment with different temperature values and observe the effect on the output.

Here's a code snippet to get you started:

```python
import whisper

# Load the model
model = whisper.load_model("base")

# Define different decoding options
greedy_options = whisper.DecodingOptions(beam_size=None, temperature=0.0)
beam_search_options = whisper.DecodingOptions(beam_size=5, temperature=0.0)
high_temp_options = whisper.DecodingOptions(beam_size=None, temperature=0.8)

# Load an audio file
audio = whisper.load_audio("path/to/your/audio/file.wav")
mel = whisper.log_mel_spectrogram(audio).to(model.device)

# Perform transcription with different options
greedy_result = whisper.decode(model, mel, greedy_options)
beam_search_result = whisper.decode(model, mel, beam_search_options)
high_temp_result = whisper.decode(model, mel, high_temp_options)

# Print results
print("Greedy Decoding Result:", greedy_result.text)
print("Beam Search Result:", beam_search_result.text)
print("High Temperature Result:", high_temp_result.text)
```

## Conclusion

In this lesson, we've explored the decoding and inference process in Whisper. We've examined the different decoding strategies implemented in the codebase, including greedy decoding and beam search. We've also looked at how temperature affects the sampling process, how timestamps are generated, and how custom decoding strategies can be implemented.

Understanding these concepts is crucial for effectively using Whisper in various applications and for potentially extending its capabilities. In the next lesson, we'll dive into the transcription and translation process, examining how Whisper handles different languages and tasks.

