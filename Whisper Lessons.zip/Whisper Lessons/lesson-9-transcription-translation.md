# Lesson 9: Transcription and Translation

## Introduction

In this lesson, we'll take a deep dive into the transcription and translation functionalities of the Whisper model. We'll focus on the `transcribe.py` module, which is the heart of Whisper's speech-to-text capabilities. By the end of this lesson, you'll have a comprehensive understanding of how Whisper processes audio input, generates transcriptions, and performs translations.

## 1. Deep dive into the transcribe.py module

The `transcribe.py` module is one of the most important components of the Whisper codebase. It contains the main logic for transcribing audio files and translating speech into English. Let's examine its structure and key components.

### File Structure

First, let's look at where `transcribe.py` fits within the Whisper project structure:

```
whisper/
├── __init__.py
├── audio.py
├── decoding.py
├── model.py
├── transcribe.py  # We'll focus on this file
├── utils.py
└── ...
```

### Key Components of transcribe.py

The `transcribe.py` file contains several important functions and classes:

1. `transcribe()`: The main function that handles the transcription process.
2. `cli()`: A function that implements the command-line interface for Whisper.
3. Various helper functions for processing audio and handling output formats.

Let's examine each of these components in detail.

#### The transcribe() function

The `transcribe()` function is the core of Whisper's transcription capabilities. It takes an audio input and a set of options, and returns a dictionary containing the transcription results. Here's a breakdown of its key steps:

1. **Input Processing**: The function starts by processing the input audio, converting it to a log-mel spectrogram using functions from the `audio.py` module.

2. **Language Detection**: If the language is not specified, Whisper attempts to detect the language automatically using the first 30 seconds of audio.

3. **Tokenization**: The function prepares the input for the model by tokenizing it using the appropriate tokenizer (multilingual or English-only).

4. **Transcription Loop**: The audio is processed in chunks, typically 30 seconds each. For each chunk:
   - The audio is fed through the Whisper model.
   - The model generates text tokens.
   - These tokens are decoded into text.
   - Timestamps are generated if requested.

5. **Result Compilation**: The results from all chunks are compiled into a single output, including the full text, segment-level details, and detected language.

#### The cli() function

The `cli()` function provides a command-line interface for Whisper, allowing users to transcribe audio files directly from the terminal. It uses the `argparse` module to parse command-line arguments and options. Some key features include:

- Selecting the model size and type
- Specifying input audio files
- Choosing output formats
- Setting transcription options (e.g., language, task, temperature)

This function is particularly useful for users who want to quickly transcribe audio without writing Python code.

## 2. Understanding the transcription process step-by-step

Now that we've looked at the structure of `transcribe.py`, let's walk through the transcription process step-by-step:

1. **Audio Loading**: The audio file is loaded using functions from `audio.py`. This involves reading the file, resampling to 16 kHz if necessary, and converting to a mono channel.

2. **Mel Spectrogram Generation**: The audio is converted into a log-mel spectrogram, which is a time-frequency representation of the audio that the model can process.

3. **Language Detection** (if necessary): If the language isn't specified, Whisper uses the first 30 seconds of audio to detect the language.

4. **Model Initialization**: The appropriate Whisper model is loaded based on the specified size and type.

5. **Tokenization**: The input is tokenized using the appropriate tokenizer for the detected or specified language.

6. **Chunking**: For long audio files, the input is divided into 30-second chunks to be processed sequentially.

7. **Inference**: Each chunk is passed through the Whisper model, which generates output tokens.

8. **Decoding**: The output tokens are decoded into text using the tokenizer.

9. **Timestamp Generation** (if requested): Whisper can generate word-level or segment-level timestamps.

10. **Result Compilation**: The results from all chunks are combined into a single output structure.

11. **Post-processing**: Any necessary post-processing is applied, such as formatting the output or applying filters.

## 3. Exploring translation functionality

Whisper not only transcribes speech but can also translate it into English. This is controlled by the `task` parameter in the `transcribe()` function. When set to "translate", Whisper will attempt to translate the speech into English, regardless of the source language.

The translation process follows a similar flow to transcription, with a few key differences:

1. The model is instructed to generate English text, regardless of the input language.
2. The tokenizer is set to use English as the target language.
3. The output is always in English, even if the input audio is in another language.

It's important to note that the translation quality can vary depending on the source language and the model size. Larger models generally produce better translations.

## 4. Handling different output formats (txt, vtt, srt, tsv, json)

Whisper supports multiple output formats to cater to different use cases. These are implemented in the `utils.py` file, which contains classes for each output format. Let's look at each format:

1. **TXT**: Plain text output, containing only the transcribed or translated text.
2. **VTT**: WebVTT format, which includes timestamps and is commonly used for web-based video subtitles.
3. **SRT**: SubRip Subtitle format, another popular subtitle format used in video players.
4. **TSV**: Tab-Separated Values, useful for importing into spreadsheets or databases.
5. **JSON**: A structured format that includes all available information, including segment-level details and confidence scores.

Each format is implemented as a subclass of the `ResultWriter` class. The appropriate writer is selected based on the user's choice of output format.

## 5. Implementing the command-line interface

The command-line interface is implemented in the `cli()` function. It uses Python's `argparse` module to define and parse command-line arguments. Here are some key aspects of the CLI implementation:

1. **Argument Parsing**: The function defines a wide range of arguments, including model selection, input/output options, and transcription parameters.

2. **Model Loading**: Based on the specified model name, the appropriate Whisper model is loaded.

3. **File Processing**: The CLI can handle multiple input files, processing them sequentially.

4. **Output Writing**: Results are written to files using the appropriate `ResultWriter` based on the chosen output format.

5. **Error Handling**: The CLI includes basic error handling to catch and report issues during transcription.

## Practical Exercise

To reinforce your understanding, try the following exercise:

1. Use the Whisper CLI to transcribe an audio file in a language of your choice.
2. Then, modify the `transcribe.py` file to add a new output format (e.g., a simple HTML format).
3. Update the CLI to include your new output format as an option.

This exercise will give you hands-on experience with both using and modifying the Whisper transcription process.

## Conclusion

In this lesson, we've taken a deep dive into the transcription and translation capabilities of Whisper, focusing on the `transcribe.py` module. We've explored the step-by-step process of transcription, examined the translation functionality, and looked at how Whisper handles different output formats. We've also seen how the command-line interface is implemented, providing an easy-to-use tool for transcription tasks.

Understanding this module is crucial for working with Whisper, whether you're using it as-is or planning to modify it for specific use cases. In the next lesson, we'll look at performance optimization and cross-platform considerations, which will help you get the most out of Whisper in various environments.

