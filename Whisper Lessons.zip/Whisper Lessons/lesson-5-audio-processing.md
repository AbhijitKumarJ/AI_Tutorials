# Lesson 5: Audio Processing in Whisper

## Introduction

Welcome to Lesson 5 of our deep dive into the Whisper codebase. In this lesson, we'll focus on audio processing, a crucial component of any speech recognition system. We'll explore how Whisper handles audio input, processes it, and prepares it for the model. This lesson will provide you with a comprehensive understanding of the audio.py module and its related functions.

## 1. Understanding Audio Representation in Whisper

Before we dive into the code, it's essential to understand how audio is represented in digital systems and specifically in Whisper.

Digital audio is typically represented as a series of numerical samples, each representing the amplitude of the sound wave at a particular point in time. The number of samples taken per second is called the sampling rate, usually measured in Hertz (Hz). Common sampling rates include 16,000 Hz (16 kHz) for speech and 44,100 Hz for CD-quality audio.

In Whisper, audio is primarily handled as mono (single-channel) waveforms with a sampling rate of 16,000 Hz. This choice is optimized for speech recognition tasks, as it provides a good balance between audio quality and computational efficiency.

## 2. Exploring the audio.py Module

Let's take a closer look at the audio.py module in the Whisper codebase. This module contains functions for loading, preprocessing, and transforming audio data.

File layout:
```
whisper/
└── audio.py
```

Key components of audio.py:

a) Constants:
   - SAMPLE_RATE: 16000 (the target sampling rate for all audio)
   - N_FFT: 400 (number of FFT points)
   - HOP_LENGTH: 160 (number of samples between successive frames)
   - CHUNK_LENGTH: 30 (length of audio chunks in seconds)
   - N_SAMPLES: 480000 (number of samples in a 30-second chunk)
   - N_FRAMES: 3000 (number of frames in a mel spectrogram input)

b) Main functions:
   - load_audio()
   - pad_or_trim()
   - log_mel_spectrogram()

Let's examine each of these components in detail.

## 3. Loading and Preprocessing Audio Files

The `load_audio()` function is responsible for opening audio files and converting them into a format suitable for Whisper. Here's a detailed look at this function:

```python
def load_audio(file: str, sr: int = SAMPLE_RATE):
    """
    Open an audio file and read as mono waveform, resampling as necessary

    Parameters
    ----------
    file: str
        The audio file to open

    sr: int
        The sample rate to resample the audio if necessary

    Returns
    -------
    A NumPy array containing the audio waveform, in float32 dtype.
    """
    # Implementation details...
```

This function uses FFmpeg, a powerful multimedia framework, to handle various audio formats. It performs the following steps:
1. Opens the audio file
2. Converts it to mono (if it's not already)
3. Resamples the audio to 16 kHz (if necessary)
4. Returns the audio as a NumPy array of 32-bit floating-point numbers

The use of FFmpeg allows Whisper to support a wide range of audio formats without needing to implement file parsing for each format separately.

## 4. Mel Spectrogram Generation and Its Importance

One of the most critical steps in audio processing for speech recognition is the generation of mel spectrograms. A mel spectrogram is a visual representation of the frequencies present in a sound over time, adjusted to better match human hearing perception.

The `log_mel_spectrogram()` function in audio.py is responsible for creating these spectrograms:

```python
def log_mel_spectrogram(
    audio: Union[str, np.ndarray, torch.Tensor],
    n_mels: int = 80,
    padding: int = 0,
    device: Optional[Union[str, torch.device]] = None,
):
    """
    Compute the log-Mel spectrogram of

    Parameters
    ----------
    audio: Union[str, np.ndarray, torch.Tensor], shape = (*)
        The path to audio or either a NumPy array or Tensor containing the audio waveform in 16 kHz

    n_mels: int
        The number of Mel-frequency filters, only 80 is supported

    padding: int
        Number of zero samples to pad to the right

    device: Optional[Union[str, torch.device]]
        If given, the audio tensor is moved to this device before STFT

    Returns
    -------
    torch.Tensor, shape = (80, n_frames)
        A Tensor that contains the Mel spectrogram
    """
    # Implementation details...
```

This function performs the following steps:
1. Loads the audio if a file path is provided
2. Applies padding if specified
3. Computes the Short-Time Fourier Transform (STFT)
4. Converts the power spectrogram to mel scale
5. Applies logarithmic scaling
6. Normalizes the spectrogram

The resulting mel spectrogram is a 2D tensor where each column represents a short time frame, and each row represents a mel frequency band. This representation captures the time-frequency characteristics of the audio, making it easier for the neural network to learn speech patterns.

## 5. Handling Different Audio Formats and Sampling Rates

Whisper is designed to work with various audio formats and sampling rates, thanks to its use of FFmpeg for audio loading. However, it's important to note that all audio is internally converted to a standard format:

- Mono channel
- 16 kHz sampling rate
- 32-bit floating-point samples

The `load_audio()` function handles this conversion automatically. If you're working with audio in a different format, you don't need to preprocess it manually - Whisper will take care of the conversion for you.

## 6. Understanding the STFT (Short-Time Fourier Transform) Process

The Short-Time Fourier Transform (STFT) is a fundamental operation in audio processing, used to convert a time-domain signal into a time-frequency representation. In Whisper, this is part of the process of generating mel spectrograms.

Here's a brief overview of the STFT process:

1. The audio signal is divided into short, overlapping segments.
2. Each segment is multiplied by a window function (Whisper uses a Hann window).
3. The Fourier Transform is applied to each windowed segment.
4. The results are arranged in a 2D array, with time on one axis and frequency on the other.

In the Whisper codebase, the STFT is computed using PyTorch's `torch.stft()` function:

```python
stft = torch.stft(audio, N_FFT, HOP_LENGTH, window=window, return_complex=True)
```

The parameters N_FFT (400) and HOP_LENGTH (160) determine the time-frequency resolution of the spectrogram. These values are chosen to provide a good balance between time and frequency resolution for speech recognition tasks.

## Practical Exercise

To reinforce your understanding of audio processing in Whisper, try the following exercise:

1. Load an audio file using the `load_audio()` function.
2. Generate a mel spectrogram using the `log_mel_spectrogram()` function.
3. Visualize the mel spectrogram using a library like matplotlib.
4. Experiment with different audio files and observe how the spectrograms change.

Here's a code snippet to get you started:

```python
import matplotlib.pyplot as plt
from whisper import audio

# Load an audio file
audio_data = audio.load_audio("path/to/your/audio/file.wav")

# Generate mel spectrogram
mel_spec = audio.log_mel_spectrogram(audio_data)

# Visualize the mel spectrogram
plt.figure(figsize=(10, 4))
plt.imshow(mel_spec.numpy(), aspect='auto', origin='lower')
plt.colorbar(format='%+2.0f dB')
plt.title('Mel Spectrogram')
plt.xlabel('Frame')
plt.ylabel('Mel Filter')
plt.tight_layout()
plt.show()
```

## Conclusion

In this lesson, we've explored the audio processing techniques used in the Whisper codebase. We've seen how audio is loaded, preprocessed, and transformed into mel spectrograms, which serve as the input to the Whisper model. Understanding these processes is crucial for working with Whisper effectively and for potentially extending or customizing its functionality.

In the next lesson, we'll dive into tokenization and language handling, which are essential components for processing the textual output of the speech recognition system.

