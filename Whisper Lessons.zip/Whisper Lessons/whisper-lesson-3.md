# Lesson 3: Python Fundamentals for Whisper

## 1. Review of Python Basics (Variables, Data Types, Functions)

Before diving into the complexities of the Whisper codebase, it's crucial to have a solid understanding of Python basics. Let's review some fundamental concepts that are frequently used in the Whisper project.

### Variables and Data Types

In Python, variables are used to store data. The Whisper codebase uses various data types, including:

- Integers (`int`): Whole numbers, used for counters, indices, and numeric parameters.
  Example: `n_mels = 80`

- Floating-point numbers (`float`): Used for decimal numbers, often in audio processing and model parameters.
  Example: `sample_rate = 16000.0`

- Strings (`str`): Used for text data, file paths, and configuration options.
  Example: `model_name = "base"`

- Booleans (`bool`): Used for true/false flags and condition checks.
  Example: `fp16 = True`

- Lists: Ordered collections, often used for sequences of data or parameters.
  Example: `supported_languages = ["en", "es", "fr", "de", ...]`

- Dictionaries: Key-value pairs, used for structured data and configuration options.
  Example: 
  ```python
  options = {
      "language": "en",
      "task": "transcribe",
      "beam_size": 5
  }
  ```

- None: Represents the absence of a value, often used as a default parameter.
  Example: `def transcribe(audio, language=None):`

### Functions

Functions are blocks of reusable code. In the Whisper project, functions are used extensively to organize code and perform specific tasks. Here's a basic structure of a function:

```python
def function_name(parameter1: type, parameter2: type) -> return_type:
    """
    Docstring describing what the function does.
    """
    # Function body
    return result
```

For example, here's a simplified version of a function you might find in the Whisper codebase:

```python
def load_audio(file: str, sr: int = SAMPLE_RATE) -> np.ndarray:
    """
    Load an audio file and resample it to the given sample rate.
    """
    # Function implementation
    return audio_array
```

Understanding how to read and write functions is crucial for navigating the Whisper codebase.

## 2. Object-Oriented Programming in Python

Object-Oriented Programming (OOP) is a programming paradigm that uses objects to structure code. The Whisper project extensively uses OOP principles. Let's explore the key concepts:

### Classes and Objects

A class is a blueprint for creating objects. Objects are instances of a class. In the Whisper codebase, you'll find classes representing various components of the system. Here's a simplified example:

```python
class Tokenizer:
    def __init__(self, vocabulary: List[str]):
        self.vocabulary = vocabulary
        self.token_to_id = {token: i for i, token in enumerate(vocabulary)}

    def encode(self, text: str) -> List[int]:
        # Implementation of encoding logic
        pass

    def decode(self, ids: List[int]) -> str:
        # Implementation of decoding logic
        pass
```

In this example, `Tokenizer` is a class that might be used to convert text to token IDs and vice versa. You would create an instance of this class (an object) to use its functionality:

```python
tokenizer = Tokenizer(["<s>", "</s>", "hello", "world"])
encoded = tokenizer.encode("hello world")
```

### Inheritance

Inheritance allows a class to inherit attributes and methods from another class. This is used in Whisper to create specialized versions of more general classes. For example:

```python
class WhisperTokenizer(Tokenizer):
    def __init__(self):
        super().__init__(WHISPER_VOCABULARY)

    def add_special_tokens(self, special_tokens: List[str]):
        # Add Whisper-specific special tokens
        pass
```

Here, `WhisperTokenizer` inherits from `Tokenizer` but adds Whisper-specific functionality.

### Methods

Methods are functions that belong to a class. In the Whisper codebase, you'll see various types of methods:

- Instance methods: Regular methods that operate on instance data.
- Class methods: Methods that operate on class-level data, defined using the `@classmethod` decorator.
- Static methods: Methods that don't depend on instance or class data, defined using the `@staticmethod` decorator.

Understanding these OOP concepts is crucial for navigating and understanding the structure of the Whisper codebase.

## 3. Working with Modules and Packages

The Whisper project is organized into multiple Python files (modules) and directories (packages). Understanding how to work with modules and packages is essential for navigating the codebase.

### Modules

A module is a Python file containing definitions and statements. In the Whisper project, each `.py` file is a module. For example, `audio.py` is a module containing audio processing functions.

To use functions from a module, you import them:

```python
from whisper.audio import log_mel_spectrogram

mel = log_mel_spectrogram(audio)
```

### Packages

A package is a directory containing Python modules and a special `__init__.py` file. The Whisper project itself is a package, with submodules for different functionalities.

The `__init__.py` file can be used to define what should be imported when the package is imported. For example, in Whisper's `__init__.py`, you might find something like:

```python
from .model import Whisper
from .transcribe import transcribe
```

This allows users to import directly from the whisper package:

```python
from whisper import Whisper, transcribe
```

Understanding how modules and packages are structured and imported is crucial for navigating the Whisper codebase efficiently.

## 4. Understanding Decorators and Context Managers

Decorators and context managers are advanced Python features that are used in the Whisper codebase to modify or enhance the behavior of functions and manage resources.

### Decorators

Decorators are functions that modify other functions. They are denoted by the `@` symbol followed by the decorator name. In the Whisper codebase, you might see decorators used for various purposes, such as caching results or timing function execution.

Here's a simple example of a decorator that might be used in Whisper:

```python
import functools

def cache_result(func):
    cache = {}
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        key = str(args) + str(kwargs)
        if key not in cache:
            cache[key] = func(*args, **kwargs)
        return cache[key]
    return wrapper

@cache_result
def expensive_computation(x):
    # Some time-consuming computation
    return result
```

This decorator caches the results of the function, so if it's called again with the same arguments, it returns the cached result instead of recomputing.

### Context Managers

Context managers are used for resource management, ensuring that resources are properly acquired and released. They are typically used with the `with` statement. In Whisper, context managers might be used for managing file handles, network connections, or temporary changes to the model state.

Here's an example of a context manager that might be used in Whisper:

```python
from contextlib import contextmanager

@contextmanager
def temporary_model_state(model, **kwargs):
    original_state = {k: getattr(model, k) for k in kwargs}
    try:
        for k, v in kwargs.items():
            setattr(model, k, v)
        yield
    finally:
        for k, v in original_state.items():
            setattr(model, k, v)

# Usage
with temporary_model_state(model, temperature=0.5):
    # Do something with the model in this temporary state
    pass
# Model state is restored after the with block
```

This context manager temporarily changes some attributes of a model, ensures the computation is done with these changes, and then restores the original state.

Understanding decorators and context managers will help you grasp some of the more advanced patterns used in the Whisper codebase.

## 5. Error Handling and Exceptions

Proper error handling is crucial in any robust software project, and Whisper is no exception. Python uses a try-except mechanism for handling exceptions.

Here's a typical pattern you might see in the Whisper codebase:

```python
try:
    audio = load_audio(file_path)
except FileNotFoundError:
    print(f"Audio file not found: {file_path}")
    return None
except Exception as e:
    print(f"An error occurred while loading audio: {str(e)}")
    return None

try:
    result = model.transcribe(audio)
except RuntimeError as e:
    print(f"An error occurred during transcription: {str(e)}")
    return None

return result
```

This code attempts to load an audio file and transcribe it, handling potential errors at each step. Understanding this pattern will help you navigate error handling in the Whisper codebase and implement robust error handling in your own contributions.

## 6. Working with NumPy and PyTorch Tensors

Whisper heavily relies on NumPy and PyTorch for numerical computations and deep learning operations. Understanding how to work with NumPy arrays and PyTorch tensors is crucial.

### NumPy

NumPy is used for efficient array operations. Here's an example of NumPy usage you might see in Whisper:

```python
import numpy as np

def pad_or_trim(array, length: int):
    """Pad or trim the audio array to a fixed length."""
    if len(array) > length:
        return array[:length]
    return np.pad(array, (0, length - len(array)))
```

This function ensures an audio array is exactly a specified length, either by trimming it or padding it with zeros.

### PyTorch Tensors

PyTorch is the deep learning framework used by Whisper. PyTorch tensors are similar to NumPy arrays but can utilize GPU acceleration. Here's an example of PyTorch tensor usage:

```python
import torch

def log_mel_spectrogram(audio: np.ndarray):
    """Convert audio to log-mel spectrogram."""
    # Convert to PyTorch tensor
    audio = torch.from_numpy(audio).float()
    
    # Compute spectrogram
    spec = torch.stft(audio, n_fft=400, hop_length=160, win_length=400)
    spec = torch.norm(spec, p=2, dim=-1)
    
    # Apply mel scaling and log
    mel_spec = torch.matmul(mel_filters, spec)
    log_spec = torch.clamp(mel_spec, min=1e-10).log10()
    
    return log_spec
```

This function converts an audio signal to a log-mel spectrogram, a common input representation for speech recognition models.

Understanding how to work with NumPy arrays and PyTorch tensors, including how to convert between them and perform operations, is essential for understanding and potentially modifying the core functionality of Whisper.

## Conclusion

In this lesson, we've covered fundamental Python concepts that are crucial for understanding and working with the Whisper codebase. We've reviewed basic Python syntax and data types, explored object-oriented programming concepts, discussed modules and packages, introduced decorators and context managers, covered error handling, and touched on working with NumPy and PyTorch.

These concepts form the foundation upon which the Whisper project is built. In the next lesson, we'll start diving into the specific structure and components of the Whisper codebase, applying these Python fundamentals to understand how Whisper implements its speech recognition functionality.

