# Lesson 2: Setting Up the Development Environment

## 1. Installing Python (Cross-Platform Considerations: Windows, macOS, Linux)

Python is the primary programming language used for the Whisper project. It's crucial to have the correct version installed to ensure compatibility with all dependencies. Whisper is compatible with Python versions 3.8 to 3.11.

### Windows Installation:
1. Visit the official Python website (https://www.python.org/downloads/windows/).
2. Download the latest Python 3.9.x installer (as this version is known to work well with Whisper).
3. Run the installer, ensuring you check the box that says "Add Python 3.x to PATH".
4. Complete the installation process.

### macOS Installation:
macOS often comes with Python pre-installed, but it's usually an older version. To install a newer version:
1. Install Homebrew if you haven't already (https://brew.sh/).
2. Open Terminal and run: `brew install python@3.9`
3. Add the new Python to your PATH by adding this line to your `~/.zshrc` or `~/.bash_profile`:
   `export PATH="/usr/local/opt/python@3.9/bin:$PATH"`

### Linux Installation:
Most Linux distributions come with Python pre-installed. To ensure you have the correct version:
1. Open a terminal.
2. For Ubuntu or Debian-based systems, run:
   ```
   sudo apt update
   sudo apt install python3.9 python3.9-venv
   ```
3. For Fedora or RHEL-based systems, run:
   ```
   sudo dnf install python39
   ```

After installation, verify your Python version by opening a terminal or command prompt and running:
```
python --version
```

## 2. Setting Up a Virtual Environment

Virtual environments in Python are isolated spaces where you can install packages and dependencies without affecting your global Python installation. This is crucial for maintaining clean, project-specific environments.

To create and activate a virtual environment:

1. Open a terminal or command prompt.
2. Navigate to your project directory:
   ```
   cd path/to/your/project
   ```
3. Create a new virtual environment:
   - On Windows:
     ```
     python -m venv whisper-env
     ```
   - On macOS and Linux:
     ```
     python3 -m venv whisper-env
     ```
4. Activate the virtual environment:
   - On Windows:
     ```
     whisper-env\Scripts\activate
     ```
   - On macOS and Linux:
     ```
     source whisper-env/bin/activate
     ```

When activated, you should see `(whisper-env)` at the beginning of your command prompt, indicating that you're working within the virtual environment.

## 3. Installing Required Dependencies (PyTorch, FFmpeg, etc.)

Whisper relies on several key dependencies, including PyTorch for deep learning operations and FFmpeg for audio processing. Here's how to install them:

### PyTorch:
PyTorch is the primary deep learning framework used by Whisper. To install it:

1. With your virtual environment activated, run:
   ```
   pip install torch
   ```
   This will install the CPU version of PyTorch. For GPU support, refer to the official PyTorch website for specific installation instructions based on your system and CUDA version.

### FFmpeg:
FFmpeg is crucial for audio file handling in Whisper. Installation varies by platform:

- Windows:
  1. Download the FFmpeg build from https://ffmpeg.org/download.html
  2. Extract the archive and add the `bin` folder to your system PATH.

- macOS (using Homebrew):
  ```
  brew install ffmpeg
  ```

- Linux (Ubuntu/Debian):
  ```
  sudo apt update
  sudo apt install ffmpeg
  ```

### Other Python Dependencies:
Install the remaining Python dependencies using pip:
```
pip install numpy tqdm more-itertools tiktoken
```

## 4. Cloning the Whisper Repository

To work with the Whisper codebase directly, you'll need to clone the repository from GitHub:

1. Ensure you have Git installed on your system.
2. Open a terminal or command prompt.
3. Navigate to the directory where you want to clone the repository.
4. Run the following command:
   ```
   git clone https://github.com/openai/whisper.git
   ```
5. Navigate into the cloned directory:
   ```
   cd whisper
   ```

## 5. Understanding the Project Structure

After cloning, you'll have a local copy of the Whisper project. Let's examine its structure:

```
whisper/
├── whisper/
│   ├── __init__.py
│   ├── audio.py
│   ├── decoding.py
│   ├── model.py
│   ├── timing.py
│   ├── tokenizer.py
│   ├── transcribe.py
│   ├── utils.py
│   └── ...
├── tests/
│   └── ...
├── setup.py
├── README.md
└── ...
```

Key components:
- `whisper/`: The main package directory containing the core functionality.
  - `__init__.py`: Initializes the package and defines top-level imports.
  - `audio.py`: Handles audio processing and feature extraction.
  - `decoding.py`: Implements the decoding logic for speech recognition.
  - `model.py`: Defines the Whisper model architecture.
  - `timing.py`: Manages timestamp generation and alignment.
  - `tokenizer.py`: Implements text tokenization for various languages.
  - `transcribe.py`: Provides the main transcription functionality.
  - `utils.py`: Contains utility functions used across the project.
- `tests/`: Contains unit tests for the project.
- `setup.py`: Defines the package and its dependencies for installation.
- `README.md`: Provides an overview and usage instructions for the project.

Understanding this structure is crucial for navigating the codebase and locating specific functionality as we delve deeper into the project in future lessons.

## 6. Running Basic Whisper Commands

Now that we have set up our environment and cloned the repository, let's try running some basic Whisper commands to ensure everything is working correctly.

First, install Whisper in your virtual environment:
```
pip install -e .
```
This command installs Whisper in "editable" mode, allowing you to make changes to the code and immediately see the effects.

Now, let's try some basic commands:

1. Transcribe an audio file:
   ```
   whisper audio.mp3
   ```
   Replace `audio.mp3` with the path to your audio file. This command will transcribe the audio using the default settings.

2. Specify a model size:
   ```
   whisper audio.mp3 --model base
   ```
   This uses the "base" model for transcription. You can replace "base" with other model sizes like "tiny", "small", "medium", or "large".

3. Transcribe in a specific language:
   ```
   whisper audio.mp3 --language Japanese
   ```
   This tells Whisper to expect Japanese speech in the audio.

4. Translate to English:
   ```
   whisper audio.mp3 --task translate
   ```
   This will transcribe the audio and translate it to English.

5. Output formats:
   ```
   whisper audio.mp3 --output_format txt
   ```
   This outputs the transcription as a text file. Other options include "vtt", "srt", "tsv", or "json".

If these commands run successfully, congratulations! You have a working Whisper environment set up on your system.

## Conclusion

In this lesson, we've covered the essential steps for setting up a development environment for working with the Whisper project. We've installed Python, set up a virtual environment, installed necessary dependencies, cloned the Whisper repository, examined the project structure, and run some basic Whisper commands.

This setup provides the foundation for diving deeper into the Whisper codebase in future lessons. In the next lesson, we'll explore Python fundamentals that are particularly relevant to understanding and working with the Whisper project.

