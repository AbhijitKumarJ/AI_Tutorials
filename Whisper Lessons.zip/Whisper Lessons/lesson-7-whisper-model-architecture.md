# Lesson 7: The Whisper Model Architecture

## Introduction

Welcome to Lesson 7 of our comprehensive exploration of the Whisper codebase. In this lesson, we'll delve deep into the architecture of the Whisper model itself. We'll examine the model.py module, explore the Transformer architecture that forms the backbone of Whisper, and investigate the specific components that make Whisper unique and powerful. Understanding the model architecture is crucial for anyone looking to work with, modify, or extend Whisper's capabilities.

## 1. Deep Dive into the model.py Module

The model.py file is the heart of the Whisper codebase, containing the definition of the Whisper model and its components. Let's start by examining the structure of this file.

File layout:
```
whisper/
└── model.py
```

Key components of model.py:

a) Classes:
   - ModelDimensions: Defines the dimensions of the model.
   - LayerNorm, Linear, Conv1d: Custom implementations of PyTorch layers.
   - MultiHeadAttention: Implements multi-head attention mechanism.
   - ResidualAttentionBlock: Builds a residual attention block.
   - AudioEncoder: Implements the audio encoder part of the model.
   - TextDecoder: Implements the text decoder part of the model.
   - Whisper: The main class that brings together all components.

b) Functions:
   - sinusoids: Generates sinusoidal positional embeddings.
   - load_model: Loads a pre-trained Whisper model.

Let's examine these components in more detail.

### The ModelDimensions Class

The ModelDimensions class is a dataclass that defines the dimensions and hyperparameters of the Whisper model:

```python
@dataclass
class ModelDimensions:
    n_mels: int
    n_audio_ctx: int
    n_audio_state: int
    n_audio_head: int
    n_audio_layer: int
    n_vocab: int
    n_text_ctx: int
    n_text_state: int
    n_text_head: int
    n_text_layer: int
```

This class encapsulates all the key dimensions of the model, such as the number of mel frequency bands (n_mels), the size of the audio context (n_audio_ctx), the number of attention heads in the audio encoder (n_audio_head), and so on. These dimensions vary for different model sizes (tiny, base, small, medium, large), allowing for a range of trade-offs between model size and performance.

## 2. Understanding the Transformer Architecture

Before we dive deeper into Whisper's specific implementation, it's crucial to understand the Transformer architecture upon which Whisper is built. The Transformer, introduced in the paper "Attention Is All You Need" by Vaswani et al., has become the foundation for many state-of-the-art models in natural language processing and beyond.

Key components of the Transformer architecture include:

1. Self-Attention Mechanism: Allows the model to weigh the importance of different parts of the input when processing each part.

2. Multi-Head Attention: Applies the self-attention mechanism multiple times in parallel, allowing the model to capture different types of relationships in the data.

3. Feed-Forward Neural Networks: Applied after the attention mechanism to further process the data.

4. Residual Connections: Allow information to flow directly from earlier layers to later layers.

5. Layer Normalization: Normalizes the activations of the previous layer for each example to improve training stability.

6. Positional Encoding: Provides information about the position of tokens in the sequence.

Whisper implements these components with some modifications tailored for the speech recognition task. Let's examine how these are implemented in the Whisper codebase.

## 3. Exploring the Encoder and Decoder Components

Whisper follows the encoder-decoder architecture common to many sequence-to-sequence models. Let's look at each component in detail.

### The AudioEncoder Class

The AudioEncoder class implements the encoder part of the Whisper model. It's responsible for processing the input audio and creating a high-dimensional representation that captures the acoustic features of the speech.

Here's a simplified view of the AudioEncoder class:

```python
class AudioEncoder(nn.Module):
    def __init__(self, n_mels: int, n_ctx: int, n_state: int, n_head: int, n_layer: int):
        super().__init__()
        self.conv1 = Conv1d(n_mels, n_state, kernel_size=3, padding=1)
        self.conv2 = Conv1d(n_state, n_state, kernel_size=3, stride=2, padding=1)
        self.register_buffer("positional_embedding", sinusoids(n_ctx, n_state))

        self.blocks: Iterable[ResidualAttentionBlock] = nn.ModuleList(
            [ResidualAttentionBlock(n_state, n_head) for _ in range(n_layer)]
        )
        self.ln_post = LayerNorm(n_state)

    def forward(self, x: Tensor):
        # Implementation details...
```

The AudioEncoder starts with two convolutional layers (conv1 and conv2) that process the mel spectrogram input. These are followed by a series of ResidualAttentionBlocks, which implement the core of the Transformer architecture. The positional_embedding provides information about the temporal position of each frame in the input sequence.

### The TextDecoder Class

The TextDecoder class implements the decoder part of the model. It's responsible for generating the output text based on the encoded audio and the previous outputs.

Here's a simplified view of the TextDecoder class:

```python
class TextDecoder(nn.Module):
    def __init__(self, n_vocab: int, n_ctx: int, n_state: int, n_head: int, n_layer: int):
        super().__init__()

        self.token_embedding = nn.Embedding(n_vocab, n_state)
        self.positional_embedding = nn.Parameter(torch.empty(n_ctx, n_state))

        self.blocks: Iterable[ResidualAttentionBlock] = nn.ModuleList(
            [ResidualAttentionBlock(n_state, n_head, cross_attention=True) for _ in range(n_layer)]
        )
        self.ln = LayerNorm(n_state)

        mask = torch.empty(n_ctx, n_ctx).fill_(-np.inf).triu_(1)
        self.register_buffer("mask", mask, persistent=False)

    def forward(self, x: Tensor, xa: Tensor, kv_cache: Optional[dict] = None):
        # Implementation details...
```

The TextDecoder uses token embeddings and positional embeddings to represent the input sequence. It then applies a series of ResidualAttentionBlocks, similar to the encoder. However, these blocks include cross-attention layers that allow the decoder to attend to the encoder's output. The mask ensures that the model can only attend to previous tokens during generation, maintaining the auto-regressive property.

## 4. Attention Mechanisms in Whisper

Attention mechanisms are a key component of the Transformer architecture and play a crucial role in Whisper. Let's examine how attention is implemented in Whisper.

The MultiHeadAttention class implements the multi-head attention mechanism:

```python
class MultiHeadAttention(nn.Module):
    def __init__(self, n_state: int, n_head: int):
        super().__init__()
        self.n_head = n_head
        self.query = Linear(n_state, n_state)
        self.key = Linear(n_state, n_state, bias=False)
        self.value = Linear(n_state, n_state)
        self.out = Linear(n_state, n_state)

    def forward(self, x: Tensor, xa: Optional[Tensor] = None, mask: Optional[Tensor] = None,
                kv_cache: Optional[dict] = None):
        # Implementation details...
```

This class implements both self-attention (when xa is None) and cross-attention (when xa is provided). The attention mechanism works as follows:

1. The input is projected into query, key, and value representations.
2. The attention weights are computed by comparing the query with the keys.
3. These weights are used to compute a weighted sum of the values.
4. The result is projected back to the original dimension.

The "multi-head" aspect comes from performing this attention computation multiple times in parallel and concatenating the results.

## 5. Understanding the ModelDimensions Class and Its Role

The ModelDimensions class, which we introduced earlier, plays a crucial role in defining the structure of the Whisper model. Let's examine it in more detail:

```python
@dataclass
class ModelDimensions:
    n_mels: int
    n_audio_ctx: int
    n_audio_state: int
    n_audio_head: int
    n_audio_layer: int
    n_vocab: int
    n_text_ctx: int
    n_text_state: int
    n_text_head: int
    n_text_layer: int
```

Each of these parameters defines a key aspect of the model:

- n_mels: The number of mel frequency bands in the input spectrogram.
- n_audio_ctx: The maximum number of frames in the audio input.
- n_audio_state: The dimensionality of the audio encoder's hidden state.
- n_audio_head: The number of attention heads in the audio encoder.
- n_audio_layer: The number of layers in the audio encoder.
- n_vocab: The size of the vocabulary (number of possible tokens).
- n_text_ctx: The maximum number of tokens in the text input/output.
- n_text_state: The dimensionality of the text decoder's hidden state.
- n_text_head: The number of attention heads in the text decoder.
- n_text_layer: The number of layers in the text decoder.

These dimensions are used to initialize the various components of the model, ensuring that all parts are compatible and properly sized.

## Practical Exercise

To reinforce your understanding of the Whisper model architecture, try the following exercise:

1. Load a pre-trained Whisper model.
2. Examine the model's architecture by printing out its components.
3. Compute the total number of parameters in the model.
4. Try running a simple forward pass with dummy input data.

Here's a code snippet to get you started:

```python
import torch
import whisper

# Load a pre-trained model
model = whisper.load_model("base")

# Print model architecture
print(model)

# Compute total number of parameters
total_params = sum(p.numel() for p in model.parameters())
print(f"Total parameters: {total_params}")

# Create dummy input
dummy_audio = torch.randn(1, 80, 3000)  # (batch_size, n_mels, n_audio_ctx)
dummy_tokens = torch.randint(0, model.dims.n_vocab, (1, 100))  # (batch_size, n_text_ctx)

# Run a forward pass
with torch.no_grad():
    output = model(dummy_audio, dummy_tokens)

print(f"Output shape: {output.shape}")
```

## Conclusion

In this lesson, we've taken a deep dive into the architecture of the Whisper model. We've examined the encoder-decoder structure, explored the attention mechanisms, and looked at how the various components work together to perform speech recognition and translation tasks.

Understanding this architecture is crucial for working with Whisper effectively, whether you're using it as-is, fine-tuning it for specific tasks, or extending it in new ways. In the next lesson, we'll explore the decoding and inference process, which is how we actually use the trained model to generate transcriptions and translations.

