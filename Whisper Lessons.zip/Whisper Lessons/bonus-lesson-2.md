# Bonus Lesson 2: Deep Dive into Whisper Model Architecture

## Introduction

In this bonus lesson, we'll take a deep dive into the architecture of the Whisper model. We'll explore the intricacies of the encoder-decoder structure, the attention mechanisms, and how different components work together to perform speech recognition and translation tasks.

## Lesson Objectives

By the end of this lesson, you will:
1. Understand the overall architecture of the Whisper model
2. Gain insight into the encoder and decoder components
3. Explore the multi-head attention mechanism in detail
4. Understand how the model handles different tasks (transcription vs. translation)
5. Learn about the model's dimensionality and how it affects performance

## Detailed Lesson Content

### 1. Whisper Model Overview

The Whisper model is based on the Transformer architecture, specifically an encoder-decoder structure. Let's start by examining the main `Whisper` class:

```python
class Whisper(nn.Module):
    def __init__(self, dims: ModelDimensions):
        super().__init__()
        self.dims = dims
        self.encoder = AudioEncoder(
            self.dims.n_mels,
            self.dims.n_audio_ctx,
            self.dims.n_audio_state,
            self.dims.n_audio_head,
            self.dims.n_audio_layer,
        )
        self.decoder = TextDecoder(
            self.dims.n_vocab,
            self.dims.n_text_ctx,
            self.dims.n_text_state,
            self.dims.n_text_head,
            self.dims.n_text_layer,
        )
        # ... (other initializations)

    def forward(self, mel: torch.Tensor, tokens: torch.Tensor) -> Dict[str, torch.Tensor]:
        return self.decoder(tokens, self.encoder(mel))
```

This class defines the overall structure of the Whisper model, consisting of an `AudioEncoder` and a `TextDecoder`.

### 2. The Audio Encoder

The `AudioEncoder` processes the input mel spectrogram:

```python
class AudioEncoder(nn.Module):
    def __init__(self, n_mels: int, n_ctx: int, n_state: int, n_head: int, n_layer: int):
        super().__init__()
        self.conv1 = Conv1d(n_mels, n_state, kernel_size=3, padding=1)
        self.conv2 = Conv1d(n_state, n_state, kernel_size=3, stride=2, padding=1)
        self.register_buffer("positional_embedding", sinusoids(n_ctx, n_state))

        self.blocks: Iterable[ResidualAttentionBlock] = nn.ModuleList(
            [ResidualAttentionBlock(n_state, n_head) for _ in range(n_layer)]
        )
        self.ln_post = LayerNorm(n_state)

    def forward(self, x: Tensor):
        x = F.gelu(self.conv1(x))
        x = F.gelu(self.conv2(x))
        x = x.permute(0, 2, 1)

        assert x.shape[1:] == self.positional_embedding.shape, "incorrect audio shape"
        x = (x + self.positional_embedding).to(x.dtype)

        for block in self.blocks:
            x = block(x)

        x = self.ln_post(x)
        return x
```

Key points about the `AudioEncoder`:
- It starts with two convolutional layers to process the mel spectrogram.
- Positional embeddings are added to provide temporal information.
- The bulk of the processing happens in a series of `ResidualAttentionBlock`s.
- A final layer normalization is applied to the output.

### 3. The Text Decoder

The `TextDecoder` generates the output text:

```python
class TextDecoder(nn.Module):
    def __init__(self, n_vocab: int, n_ctx: int, n_state: int, n_head: int, n_layer: int):
        super().__init__()

        self.token_embedding = nn.Embedding(n_vocab, n_state)
        self.positional_embedding = nn.Parameter(torch.empty(n_ctx, n_state))

        self.blocks: Iterable[ResidualAttentionBlock] = nn.ModuleList(
            [ResidualAttentionBlock(n_state, n_head, cross_attention=True) for _ in range(n_layer)]
        )
        self.ln = LayerNorm(n_state)

        mask = torch.empty(n_ctx, n_ctx).fill_(-np.inf).triu_(1)
        self.register_buffer("mask", mask, persistent=False)

    def forward(self, x: Tensor, xa: Tensor, kv_cache: Optional[dict] = None):
        offset = next(iter(kv_cache.values())).shape[1] if kv_cache else 0
        x = self.token_embedding(x) + self.positional_embedding[offset : offset + x.shape[-1]]
        x = x.to(xa.dtype)

        for block in self.blocks:
            x = block(x, xa, mask=self.mask, kv_cache=kv_cache)

        x = self.ln(x)
        logits = (x @ torch.transpose(self.token_embedding.weight.to(x.dtype), 0, 1)).float()

        return logits
```

Key points about the `TextDecoder`:
- It uses token embeddings and positional embeddings for the input tokens.
- The decoder blocks include cross-attention to the encoder output.
- A causal mask is used to prevent attending to future tokens during training.
- The output logits are produced by projecting the final hidden states onto the token embedding space.

### 4. Residual Attention Blocks

Both the encoder and decoder use `ResidualAttentionBlock`s:

```python
class ResidualAttentionBlock(nn.Module):
    def __init__(self, n_state: int, n_head: int, cross_attention: bool = False):
        super().__init__()

        self.attn = MultiHeadAttention(n_state, n_head)
        self.attn_ln = LayerNorm(n_state)

        self.cross_attn = MultiHeadAttention(n_state, n_head) if cross_attention else None
        self.cross_attn_ln = LayerNorm(n_state) if cross_attention else None

        n_mlp = n_state * 4
        self.mlp = nn.Sequential(Linear(n_state, n_mlp), nn.GELU(), Linear(n_mlp, n_state))
        self.mlp_ln = LayerNorm(n_state)

    def forward(self, x: Tensor, xa: Optional[Tensor] = None, mask: Optional[Tensor] = None, kv_cache: Optional[dict] = None):
        x = x + self.attn(self.attn_ln(x), mask=mask, kv_cache=kv_cache)[0]
        if self.cross_attn:
            x = x + self.cross_attn(self.cross_attn_ln(x), xa, kv_cache=kv_cache)[0]
        x = x + self.mlp(self.mlp_ln(x))
        return x
```

These blocks contain:
- Self-attention mechanism
- Optional cross-attention (used in the decoder)
- A feedforward neural network
- Layer normalization and residual connections

### 5. Multi-Head Attention

The core of the Transformer architecture is the multi-head attention mechanism:

```python
class MultiHeadAttention(nn.Module):
    def __init__(self, n_state: int, n_head: int):
        super().__init__()
        self.n_head = n_head
        self.query = Linear(n_state, n_state)
        self.key = Linear(n_state, n_state, bias=False)
        self.value = Linear(n_state, n_state)
        self.out = Linear(n_state, n_state)

    def forward(self, x: Tensor, xa: Optional[Tensor] = None, mask: Optional[Tensor] = None, kv_cache: Optional[dict] = None):
        q = self.query(x)

        if kv_cache is None or xa is None or self.key not in kv_cache:
            k = self.key(x if xa is None else xa)
            v = self.value(x if xa is None else xa)
        else:
            k = kv_cache[self.key]
            v = kv_cache[self.value]

        wv, qk = self.qkv_attention(q, k, v, mask)
        return self.out(wv), qk

    def qkv_attention(self, q: Tensor, k: Tensor, v: Tensor, mask: Optional[Tensor] = None):
        n_batch, n_ctx, n_state = q.shape
        scale = (n_state // self.n_head) ** -0.25
        q = q.view(*q.shape[:2], self.n_head, -1).permute(0, 2, 1, 3) * scale
        k = k.view(*k.shape[:2], self.n_head, -1).permute(0, 2, 3, 1) * scale
        v = v.view(*v.shape[:2], self.n_head, -1).permute(0, 2, 1, 3)

        qk = q @ k
        if mask is not None:
            qk = qk + mask[:n_ctx, :n_ctx]
        qk = qk.float()

        w = F.softmax(qk, dim=-1).to(q.dtype)
        return (w @ v).permute(0, 2, 1, 3).flatten(start_dim=2), qk
```

The multi-head attention mechanism is a crucial component of the Transformer architecture. Here's a detailed breakdown of its functionality:

- **Initialization**: The attention mechanism is initialized with separate linear transformations for query, key, and value. These transformations project the input into different subspaces, allowing the model to attend to different aspects of the input simultaneously.

- **Forward Pass**: 
  - The input is first transformed into query (q), key (k), and value (v) representations.
  - If a key-value cache is provided and contains pre-computed keys and values, these are used instead of computing new ones. This optimization is particularly useful for autoregressive decoding.

- **QKV Attention**:
  - The input is reshaped to separate the heads, allowing each head to focus on different parts of the input.
  - The attention scores are computed by taking the dot product of queries and keys, scaled to prevent excessive values in high-dimensional spaces.
  - If a mask is provided (e.g., for causal attention in the decoder), it's applied to the attention scores.
  - The attention weights are computed using softmax, and then used to aggregate the values.

- **Output**: The results from all heads are concatenated and passed through a final linear transformation.

This multi-head attention mechanism allows the model to jointly attend to information from different representation subspaces at different positions, greatly enhancing its ability to capture complex patterns in the input.

### 6. Model Dimensions and Scaling

The Whisper model comes in different sizes, controlled by the `ModelDimensions` class:

```python
@dataclass
class ModelDimensions:
    n_mels: int
    n_audio_ctx: int
    n_audio_state: int
    n_audio_head: int
    n_audio_layer: int
    n_vocab: int
    n_text_ctx: int
    n_text_state: int
    n_text_head: int
    n_text_layer: int
```

These dimensions define the size and complexity of the model. Larger models (more layers, more heads, larger state dimensions) can capture more complex patterns but require more computational resources and may be prone to overfitting on smaller datasets.

### 7. Task-Specific Behavior

Whisper can perform both transcription and translation tasks. This is achieved through the use of task-specific tokens at the beginning of the decoder input sequence. The model learns to generate different outputs based on these tokens during training.

For example, in the `transcribe` function:

```python
if task == "translate":
    task_tokens = [tokenizer.translate]
elif task == "transcribe":
    task_tokens = [tokenizer.transcribe]
else:
    raise ValueError(f"Unknown task {task}")

tokens = [tokenizer.sot, tokenizer.sot_prev, tokenizer.sot_lm] + task_tokens + lang_tokens
```

These task tokens guide the model's behavior during inference, allowing it to switch between transcription and translation using the same set of weights.

## Practical Exercise

To deepen your understanding of the Whisper architecture, try implementing a simplified version of the `ResidualAttentionBlock`. This block is a key component of both the encoder and decoder. Your implementation should include self-attention, layer normalization, and a feedforward network with residual connections.

## Conclusion

The Whisper model's architecture is a sophisticated adaptation of the Transformer for speech recognition and translation tasks. By understanding its components - from the audio encoder to the text decoder, and the attention mechanisms that tie them together - you gain insight into how the model processes audio input and generates textual output. This knowledge is crucial for effectively using, fine-tuning, or extending the Whisper model for various applications.

In the next lesson, we'll explore how to use the Whisper model for inference, including techniques for handling long audio inputs and optimizing performance.

