# Bonus Lesson 3: Advanced Inference Techniques and Optimizations for Whisper

## Introduction

In this bonus lesson, we'll explore advanced techniques for running inference with the Whisper model, as well as various optimizations to improve performance and efficiency. We'll cover topics such as handling long audio inputs, batch processing, and leveraging hardware acceleration.

## Lesson Objectives

By the end of this lesson, you will:
1. Understand how to process long audio files efficiently
2. Learn techniques for batch processing multiple audio files
3. Explore methods for leveraging GPU acceleration
4. Understand the key-value cache mechanism for faster inference
5. Learn about quantization and its impact on model performance

## Detailed Lesson Content

### 1. Processing Long Audio Files

Whisper is designed to handle 30-second audio segments. For longer audio files, we need to implement a windowing strategy. Let's examine the relevant code from the `transcribe` function:

```python
def transcribe(
    model: Whisper,
    audio: Union[str, np.ndarray, torch.Tensor],
    *,
    verbose: Optional[bool] = None,
    temperature: Union[float, Tuple[float, ...]] = (0.0, 0.2, 0.4, 0.6, 0.8, 1.0),
    compression_ratio_threshold: Optional[float] = 2.4,
    logprob_threshold: Optional[float] = -1.0,
    no_speech_threshold: Optional[float] = 0.6,
    condition_on_previous_text: bool = True,
    **decode_options,
):
    # ... (other code)

    mel = log_mel_spectrogram(audio, model.dims.n_mels, padding=N_SAMPLES)
    content_frames = mel.shape[-1] - N_FRAMES

    seek = 0
    input_stride = exact_div(
        N_FRAMES, model.dims.n_audio_ctx
    )  # mel frames per output token: 2
    time_precision = (
        input_stride * HOP_LENGTH / SAMPLE_RATE
    )  # time per output token: 0.02 (seconds)

    all_tokens = []
    all_segments = []
    prompt_reset_since = 0

    if initial_prompt is not None:
        initial_prompt_tokens = tokenizer.encode(" " + initial_prompt.strip())
        all_tokens.extend(initial_prompt_tokens)
    else:
        initial_prompt_tokens = []

    def new_segment(
        *, start: float, end: float, tokens: torch.Tensor, result: DecodingResult
    ):
        tokens = tokens.tolist()
        text_tokens = [token for token in tokens if token < tokenizer.eot]
        return {
            "seek": seek,
            "start": start,
            "end": end,
            "text": tokenizer.decode(text_tokens),
            "tokens": tokens,
            "temperature": result.temperature,
            "avg_logprob": result.avg_logprob,
            "compression_ratio": result.compression_ratio,
            "no_speech_prob": result.no_speech_prob,
        }

    # show the progress bar when verbose is False (if True, transcribed text will be printed)
    with tqdm.tqdm(
        total=content_frames, unit="frames", disable=verbose is not False
    ) as pbar:
        while seek < content_frames:
            time_offset = float(seek * HOP_LENGTH / SAMPLE_RATE)
            mel_segment = mel[:, seek : seek + N_FRAMES]
            segment_size = min(N_FRAMES, content_frames - seek)
            segment_duration = segment_size * HOP_LENGTH / SAMPLE_RATE
            mel_segment = pad_or_trim(mel_segment, N_FRAMES).to(model.device).to(dtype)

            decode_options["prompt"] = all_tokens[prompt_reset_since:]
            result: DecodingResult = decode_with_fallback(mel_segment, **decode_options)
            tokens = torch.tensor(result.tokens)

            if no_speech_threshold is not None:
                # no voice activity check
                should_skip = result.no_speech_prob > no_speech_threshold
                if logprob_threshold is not None and result.avg_logprob > logprob_threshold:
                    # don't skip if the logprob is high enough, despite the no_speech_prob
                    should_skip = False

                if should_skip:
                    seek += segment_size  # fast-forward to the next segment boundary
                    continue

            current_segments = []

            timestamp_tokens: torch.Tensor = tokens.ge(tokenizer.timestamp_begin)
            single_timestamp_ending = timestamp_tokens[-2:].tolist() == [False, True]

            consecutive = torch.where(timestamp_tokens[:-1] & timestamp_tokens[1:])[0]
            consecutive.add_(1)
            if len(consecutive) > 0:
                # if the output contains two consecutive timestamp tokens
                slices = consecutive.tolist()
                if single_timestamp_ending:
                    slices.append(len(tokens))

                last_slice = 0
                for current_slice in slices:
                    sliced_tokens = tokens[last_slice:current_slice]
                    start_timestamp_pos = sliced_tokens[0].item() - tokenizer.timestamp_begin
                    end_timestamp_pos = sliced_tokens[-1].item() - tokenizer.timestamp_begin
                    current_segments.append(
                        new_segment(
                            start=time_offset + start_timestamp_pos * time_precision,
                            end=time_offset + end_timestamp_pos * time_precision,
                            tokens=sliced_tokens,
                            result=result,
                        )
                    )
                    last_slice = current_slice

                if single_timestamp_ending:
                    # single timestamp at the end means no speech after the last timestamp.
                    seek += segment_size
                else:
                    # otherwise, ignore the unfinished segment and seek to the last timestamp
                    last_timestamp_pos = (
                        tokens[last_slice - 1].item() - tokenizer.timestamp_begin
                    )
                    seek += last_timestamp_pos * input_stride
            else:
                duration = segment_duration
                timestamps = tokens[timestamp_tokens.nonzero().flatten()]
                if len(timestamps) > 0 and timestamps[-1].item() != tokenizer.timestamp_begin:
                    # no consecutive timestamps but it has a timestamp; use the last one.
                    last_timestamp_pos = timestamps[-1].item() - tokenizer.timestamp_begin
                    duration = last_timestamp_pos * time_precision

                current_segments.append(
                    new_segment(
                        start=time_offset,
                        end=time_offset + duration,
                        tokens=tokens,
                        result=result,
                    )
                )
                seek += segment_size

            # ... (rest of the function)
```

This function implements a sliding window approach:
- It processes the audio in 30-second chunks (defined by `N_FRAMES`).
- Each chunk is decoded separately, but with the option to condition on previous text.
- The function handles overlapping segments and merges them based on timestamp tokens.
- It also implements various heuristics to handle silence and improve transcript consistency.

### 2. Batch Processing

For processing multiple audio files efficiently, we can leverage batch processing. Here's an example of how to implement batch processing:

```python
def batch_process_audio(model: Whisper, audio_files: List[str], batch_size: int = 16, **decode_options):
    results = []
    for i in range(0, len(audio_files), batch_size):
        batch = audio_files[i:i+batch_size]
        audios = [log_mel_spectrogram(audio) for audio in batch]
        mels = torch.stack(audios).to(model.device)
        
        with torch.no_grad():
            batch_results = model.decode(mels, **decode_options)
        
        results.extend(batch_results)
    
    return results
```

This function processes audio files in batches, which can significantly speed up inference when dealing with multiple files.

### 3. GPU Acceleration

Whisper can leverage GPU acceleration for faster inference. Here's how to ensure the model and inputs are on the GPU:

```python
device = "cuda" if torch.cuda.is_available() else "cpu"
model = model.to(device)
mel = mel.to(device)
```

### 4. Key-Value Cache Mechanism

Whisper uses a key-value cache to speed up autoregressive decoding. Let's examine the relevant code:

```python
class PyTorchInference(Inference):
    def __init__(self, model: "Whisper", initial_token_length: int):
        self.model: "Whisper" = model
        self.initial_token_length = initial_token_length
        self.kv_cache = {}
        self.hooks = []

    def logits(self, tokens: Tensor, audio_features: Tensor) -> Tensor:
        if not self.kv_cache:
            self.kv_cache, self.hooks = self.model.install_kv_cache_hooks()

        if tokens.shape[-1] > self.initial_token_length:
            # only need to use the last token except in the first forward pass
            tokens = tokens[:, -1:]

        return self.model.decoder(tokens, audio_features, kv_cache=self.kv_cache)

    def cleanup_caching(self):
        for hook in self.hooks:
            hook.remove()

        self.kv_cache = {}
        self.hooks = []

    def rearrange_kv_cache(self, source_indices):
        for module in self.model.decoder.blocks:
            if source_indices != list(range(len(source_indices))):
                # update the key/value cache to contain the selected sequences
                self.kv_cache[module.attn.key] = self.kv_cache[module.attn.key][source_indices].detach()
                self.kv_cache[module.attn.value] = self.kv_cache[module.attn.value][source_indices].detach()
```

The key-value cache mechanism works as follows:
- During the first forward pass, the cache is initialized and hooks are installed to capture key and value tensors.
- In subsequent passes, only the last token is processed, and the cached keys and values are used for the previous tokens.
- This significantly reduces computation time for autoregressive decoding.
- The `rearrange_kv_cache` method is used to update the cache when beam search is performed, ensuring that the cache always corresponds to the current beam states.

### 5. Quantization

Quantization is a technique to reduce model size and improve inference speed, especially on CPU. While Whisper doesn't include built-in quantization, you can implement it using PyTorch's quantization features. Here's an example of how you might quantize a Whisper model:

```python
import torch.quantization

def quantize_whisper(model: Whisper):
    # Set the model to evaluation mode
    model.eval()

    # Specify quantization configuration
    model.qconfig = torch.quantization.get_default_qconfig('fbgemm')

    # Prepare for quantization
    model_prepared = torch.quantization.prepare(model)

    # Calibrate the model (you would need to run some sample data through the model here)
    # For example:
    # sample_input = torch.randn(1, 80, 3000)
    # model_prepared(sample_input)

    # Convert to quantized model
    model_quantized = torch.quantization.convert(model_prepared)

    return model_quantized
```

Quantization can significantly reduce model size and improve CPU inference speed, but it may come at the cost of a small decrease in accuracy. It's important to evaluate the quantized model to ensure it still meets your performance requirements.

### 6. Optimizing Decoder Speed

The decoder is often the bottleneck in inference speed. Here are some techniques to optimize it:

a. Use a smaller temperature for faster convergence:
```python
temperature = 0.0  # or a small value like 0.1
```

b. Reduce the number of beams in beam search:
```python
beam_size = 1  # or a small number like 3
```

c. Use a shorter maximum output length:
```python
max_length = 200  # adjust based on your use case
```

### 7. Caching Mel Spectrograms

If you're processing the same audio multiple times (e.g., for different tasks or languages), you can cache the mel spectrogram:

```python
import functools

@functools.lru_cache(maxsize=100)
def cached_log_mel_spectrogram(audio_path: str):
    audio = whisper.load_audio(audio_path)
    mel = whisper.log_mel_spectrogram(audio)
    return mel

# Usage
mel = cached_log_mel_spectrogram(audio_path)
result = model.transcribe(mel)
```

This can save significant time when repeatedly processing the same audio files.

## Practical Exercise

Implement a script that transcribes a long audio file (>10 minutes) using the windowing technique discussed in this lesson. Compare the performance (speed and accuracy) of running this script on CPU vs. GPU, and with different batch sizes.

## Conclusion

Optimizing Whisper for inference involves a combination of techniques, from efficient audio processing to leveraging GPU acceleration and using advanced features like the key-value cache. By understanding and applying these techniques, you can significantly improve the performance of Whisper in real-world applications, enabling faster and more efficient speech recognition and translation tasks.

In the next lesson, we'll explore how to fine-tune Whisper for specific domains or languages, further enhancing its capabilities for specialized use cases.

