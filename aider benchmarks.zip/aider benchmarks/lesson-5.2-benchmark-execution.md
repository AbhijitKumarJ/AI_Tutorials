# Lesson 5.2: Running and Analyzing Benchmarks

## Executing Benchmark Suites

This section provides a comprehensive guide to running benchmarks and analyzing their results effectively. Understanding the execution process and interpretation of results is crucial for meaningful evaluation of Aider's performance.

## Command-Line Interface

The benchmark system provides a rich command-line interface through `benchmark.py`. Let's explore the available options and their usage in detail:

### Basic Command Structure
```bash
./benchmark/benchmark.py [options] dirname
```

### Essential Command-Line Options

1. Model Selection:
   ```bash
   --model MODEL_NAME
   ```
   Specifies the LLM model to use for testing. Common values include:
   - gpt-3.5-turbo
   - gpt-4
   - claude-3-sonnet
   The model selection significantly impacts performance and cost.

2. Edit Format:
   ```bash
   --edit-format FORMAT
   ```
   Determines how code changes are formatted:
   - whole: Complete file replacement
   - diff: Search/replace style edits
   - udiff: Unified diff format
   Each format has different strengths and may perform better for certain types of edits.

3. Parallel Execution:
   ```bash
   --threads NUM_THREADS
   ```
   Controls concurrent test execution:
   - Default is 1 (sequential)
   - Higher values improve throughput
   - Consider API rate limits when setting
   - Recommended range: 5-10 for most APIs

4. Test Selection:
   ```bash
   --keywords KEYWORDS
   ```
   Filters test cases by name:
   - Comma-separated list
   - Case-sensitive matching
   - Supports partial matches
   Example: `--keywords calculator,sort` runs only tests containing these terms.

5. Execution Control:
   ```bash
   --num-tests NUM
   ```
   Limits the number of tests to run:
   - Useful for initial validation
   - Random selection if less than total
   
   ```bash
   --tries NUM_TRIES
   ```
   Number of attempts per test:
   - Default is 2
   - Higher values provide better success rates
   - Increases total execution time

### Advanced Options

1. Error Handling:
   ```bash
   --max-apply-update-errors NUM
   ```
   Controls retry behavior for failed updates:
   - Default is 3
   - Higher values increase resilience
   - Lower values fail faster

2. Directory Management:
   ```bash
   --clean
   ```
   Resets test directory to original state:
   - Removes previous modifications
   - Ensures clean starting point
   
   ```bash
   --cont
   ```
   Continues previous run:
   - Skips completed tests
   - Preserves existing results

3. Debugging Options:
   ```bash
   --verbose
   ```
   Enables detailed output:
   - Shows API interactions
   - Logs intermediate steps
   - Useful for troubleshooting

## Running Benchmarks Effectively

### Example Workflow

1. Initial Testing:
   ```bash
   ./benchmark/benchmark.py test-run \
       --model gpt-4 \
       --edit-format whole \
       --num-tests 5 \
       --verbose
   ```
   This command:
   - Creates a new benchmark directory
   - Runs 5 random tests
   - Uses verbose output for validation

2. Full Benchmark Run:
   ```bash
   ./benchmark/benchmark.py full-benchmark \
       --model gpt-4 \
       --edit-format whole \
       --threads 10 \
       --tries 2
   ```
   This executes:
   - All test cases
   - In parallel with 10 threads
   - With 2 attempts per test

3. Continuing Interrupted Run:
   ```bash
   ./benchmark/benchmark.py 2024-03-14-benchmark \
       --cont \
       --model gpt-4 \
       --edit-format whole
   ```
   This resumes:
   - Previously started benchmark
   - Maintains consistent settings
   - Skips completed tests

## Analyzing Results

### Results Structure

Results are stored in `.aider.results.json` files:
```json
{
    "testcase": "exercise-name",
    "model": "gpt-4",
    "edit_format": "whole",
    "tests_outcomes": [false, true],
    "cost": 0.1234,
    "duration": 45.67,
    "test_timeouts": 0,
    "num_error_outputs": 1,
    "num_user_asks": 0,
    "syntax_errors": 0,
    "indentation_errors": 0
}
```

### Generating Statistics

1. Basic Stats:
   ```bash
   ./benchmark/benchmark.py --stats dirname
   ```
   Provides:
   - Overall success rate
   - Average completion time
   - Cost analysis
   - Error statistics

2. Detailed Analysis:
   ```bash
   ./benchmark/benchmark.py --stats dirname --verbose
   ```
   Includes:
   - Per-test breakdowns
   - Failure analysis
   - Performance metrics
   - Token usage details

### Visualization

The benchmark system includes plotting capabilities:

1. Timing Analysis:
   - Shows response times
   - Compares model performance
   - Identifies bottlenecks

2. Success Rate Visualization:
   - First vs. second attempt rates
   - Model comparisons
   - Edit format effectiveness

3. Custom Plots:
   The `plots.py` module supports:
   - Custom metric visualization
   - Performance comparisons
   - Trend analysis
   - Export to various formats

## Troubleshooting Common Issues

1. API Rate Limits:
   - Reduce thread count
   - Implement exponential backoff
   - Monitor API usage

2. Test Failures:
   - Check error messages
   - Verify test requirements
   - Review model responses
   - Validate edit formats

3. Performance Issues:
   - Monitor system resources
   - Check network connectivity
   - Optimize thread count
   - Consider API endpoints

4. Data Collection:
   - Verify result files
   - Check permissions
   - Ensure proper paths
   - Monitor disk space

This comprehensive guide to running and analyzing benchmarks provides the foundation for effective evaluation of Aider's performance across different models and configurations. The next section will cover advanced topics in benchmark customization and extension.