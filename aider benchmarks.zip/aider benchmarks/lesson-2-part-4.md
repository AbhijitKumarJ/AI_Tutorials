# Lesson 2.4: Results Processing and Storage

## Overview
The results processing and storage system in Aider's benchmarking framework is crucial for analyzing performance, tracking improvements, and making data-driven decisions. This section explores how test results are collected, processed, stored, and analyzed.

## Results Directory Structure

The benchmark results are organized in a hierarchical structure:

```
tmp.benchmarks/
├── YYYY-MM-DD-HH-MM-SS--run-name/
│   ├── test_case_1/
│   │   ├── .aider.results.json    # Test results
│   │   ├── .aider.chat.history.md # Interaction log
│   │   └── modified_files/        # Final state
│   ├── test_case_2/
│   │   └── ...
│   └── summary.json               # Run summary
└── analytics/
    ├── historical_data.json
    ├── performance_metrics.json
    └── trend_analysis.json
```

## Results Collection System

### 1. Individual Test Results

The system collects detailed metrics for each test:

```python
def collect_test_results(testdir, coder, duration, outcomes):
    """
    Collect and format comprehensive test results.
    """
    results = {
        # Test identification
        "testcase": testdir.name,
        "timestamp": datetime.now().isoformat(),
        
        # Model information
        "model": coder.main_model.name,
        "edit_format": coder.edit_format,
        "model_version": coder.main_model.version,
        
        # Performance metrics
        "duration": duration,
        "total_cost": coder.total_cost,
        "token_usage": {
            "prompt": coder.prompt_tokens,
            "completion": coder.completion_tokens,
            "total": coder.total_tokens
        },
        
        # Outcomes
        "tests_outcomes": outcomes,
        "final_status": "passed" if any(outcomes) else "failed",
        
        # Error metrics
        "error_outputs": coder.num_error_outputs,
        "syntax_errors": coder.syntax_errors,
        "timeouts": coder.timeouts,
        
        # Quality metrics
        "num_malformed_responses": coder.num_malformed_responses,
        "context_window_exhaustions": coder.num_exhausted_context_windows,
        
        # Detailed timing
        "api_latency": coder.api_latency,
        "processing_time": coder.processing_time
    }
    
    return results
```

### 2. Run Summary Generation

Creating comprehensive run summaries:

```python
def generate_run_summary(dirname, all_results):
    """
    Generate summary statistics for an entire benchmark run.
    """
    summary = {
        "run_id": dirname.name,
        "timestamp": datetime.now().isoformat(),
        "commit_hash": get_git_commit_hash(),
        
        # Overall statistics
        "total_tests": len(all_results),
        "passed_tests": sum(1 for r in all_results 
                          if r["final_status"] == "passed"),
        
        # Aggregated metrics
        "total_duration": sum(r["duration"] for r in all_results),
        "total_cost": sum(r["total_cost"] for r in all_results),
        
        # Error statistics
        "error_counts": aggregate_error_counts(all_results),
        
        # Performance analysis
        "average_latency": calculate_average_latency(all_results),
        "token_usage_stats": calculate_token_stats(all_results),
        
        # Model-specific stats
        "model_performance": group_by_model(all_results)
    }
    
    return summary
```

## Results Storage System

### 1. JSON Storage Format

Results are stored in a structured JSON format:

```python
def save_test_results(results, testdir):
    """
    Save test results in a structured format.
    """
    results_file = testdir / ".aider.results.json"
    
    # Ensure directory exists
    results_file.parent.mkdir(parents=True, exist_ok=True)
    
    # Add metadata
    results["storage_version"] = "2.0"
    results["save_timestamp"] = datetime.now().isoformat()
    
    # Save with proper formatting
    with results_file.open('w') as f:
        json.dump(results, f, indent=2, sort_keys=True)
```

### 2. History File Management

Managing test interaction history:

```python
def manage_history_file(history_fname, content):
    """
    Manage the chat history markdown file.
    """
    def format_history_entry(entry):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return f"### {timestamp}\n\n{entry}\n\n"
    
    # Append new content
    with history_fname.open('a') as f:
        f.write(format_history_entry(content))
```

## Results Analysis System

### 1. Performance Metrics Calculation

```python
def calculate_performance_metrics(results):
    """
    Calculate comprehensive performance metrics.
    """
    metrics = {
        # Success rates
        "pass_rates": {
            "first_attempt": calculate_first_attempt_rate(results),
            "overall": calculate_overall_pass_rate(results),
            "by_model": group_results_by_model(results)
        },
        
        # Cost analysis
        "cost_metrics": {
            "average_cost_per_test": mean([r["total_cost"] 
                                         for r in results]),
            "cost_per_success": calculate_cost_per_success(results),
            "projected_costs": estimate_projected_costs(results)
        },
        
        # Time analysis
        "timing_metrics": {
            "average_duration": mean([r["duration"] 
                                    for r in results]),
            "latency_distribution": calculate_latency_distribution(results)
        },
        
        # Error analysis
        "error_metrics": analyze_error_patterns(results)
    }
    
    return metrics
```

### 2. Trend Analysis

```python
def analyze_trends(historical_results):
    """
    Analyze performance trends over time.
    """
    trends = {
        # Performance trends
        "success_rate_trend": calculate_success_trend(historical_results),
        "cost_efficiency_trend": analyze_cost_efficiency(historical_results),
        
        # Error trends
        "error_patterns": identify_error_patterns(historical_results),
        
        # Model comparison
        "model_performance_trends": compare_model_trends(historical_results)
    }
    
    return trends
```

## Results Export System

### 1. CSV Export

```python
def export_to_csv(results, output_file):
    """
    Export results to CSV format for external analysis.
    """
    # Flatten nested structures
    flat_results = []
    for result in results:
        flat_result = flatten_result_structure(result)
        flat_results.append(flat_result)
    
    # Write to CSV
    df = pd.DataFrame(flat_results)
    df.to_csv(output_file, index=False)
```

### 2. Report Generation

```python
def generate_markdown_report(results, template_file):
    """
    Generate a markdown report from results.
    """
    env = jinja2.Environment(
        loader=jinja2.FileSystemLoader("templates")
    )
    template = env.get_template(template_file)
    
    # Calculate report metrics
    metrics = calculate_performance_metrics(results)
    
    # Generate report
    report = template.render(
        results=results,
        metrics=metrics,
        timestamp=datetime.now().isoformat()
    )
    
    return report
```

## Usage Examples

1. Basic Results Collection:
```bash
# Run tests and collect results
./benchmark/benchmark.py test_suite --collect-results

# Generate summary report
./benchmark/benchmark.py --stats results_directory
```

2. Detailed Analysis:
```bash
# Export results to CSV
./benchmark/benchmark.py --export-csv results.csv

# Generate markdown report
./benchmark/benchmark.py --generate-report report.md
```

## Best Practices

1. Data Management:
   - Regular backups of result data
   - Version control of result formats
   - Proper error handling in data processing

2. Analysis:
   - Consistent metric calculations
   - Statistical significance testing
   - Regular trend analysis

3. Storage:
   - Efficient storage formats
   - Data compression for historical data
   - Regular cleanup of temporary files

## Next Steps
This completes our detailed exploration of the core benchmarking components and workflow. The next lesson will focus on Performance Metrics and Visualization, where we'll learn how to interpret and visualize the results we've collected and processed.
