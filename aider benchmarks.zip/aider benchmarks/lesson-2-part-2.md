# Lesson 2.2: Test Case Processing

## Overview
Test case processing is a crucial component of Aider's benchmarking system. It involves managing individual test cases, processing their execution, and analyzing the results. The system is designed to handle both the original source files and their corresponding test files while maintaining isolation and reproducibility.

## Test Case Structure

### Directory Layout
Each test case follows a specific directory structure:

```
tmp.benchmarks/
└── test-suite-name/
    ├── test_case_1/
    │   ├── source_file.py           # File to be modified
    │   ├── test_source_file.py      # Unit tests
    │   └── .docs/
    │       ├── introduction.md      # Optional context
    │       ├── instructions.md      # Main task description
    │       └── instructions.append.md # Additional instructions
    └── test_case_2/
        └── ...
```

### Test Case Components

The test case processing system handles several key components:

1. Source Files:
   - Original implementation files that need modification
   - Must not contain test-related code
   - Can include multiple files for complex scenarios

2. Test Files:
   - Unit tests that verify the implementation
   - Named with `_test.py` or `test_*.py` pattern
   - Use Python's unittest framework

3. Documentation:
   - Introduction: Optional context about the problem
   - Instructions: Clear description of required changes
   - Append: Additional requirements or constraints

## Test Execution Flow

### 1. Test Case Loading

The system carefully manages the loading of test cases:

```python
def run_test(original_dname, testdir, *args, **kwargs):
    try:
        # Prepare test environment
        testdir = Path(testdir)
        history_fname = testdir / ".aider.chat.history.md"
        
        # Load source files
        fnames = []
        for fname in testdir.glob("*"):
            if ("test" not in fname.name 
                and fname.is_file()
                and fname.name[0] != "."
                and fname.suffix == ".py"):
                fnames.append(fname)
                
                # Restore original file
                original_fname = original_dname / testdir.name / fname.name
                shutil.copy(original_fname, fname)
```

### 2. Instruction Processing

The system combines instructions from multiple sources:

```python
def get_instructions(testdir):
    instructions = ""
    
    # Load optional introduction
    introduction = testdir / ".docs/introduction.md"
    if introduction.exists():
        instructions += introduction.read_text()
        
    # Add main instructions
    instructions += (testdir / ".docs/instructions.md").read_text()
    
    # Add optional appendix
    instructions_append = testdir / ".docs/instructions.append.md"
    if instructions_append.exists():
        instructions += instructions_append.read_text()
```

### 3. Test Execution Environment

The system creates an isolated environment for each test:

1. File System Setup:
   - Creates clean copies of all required files
   - Maintains test isolation
   - Preserves original files

2. Model Interaction:
   - Configures the AI model with test parameters
   - Manages conversation history
   - Handles response processing

Example test environment setup:
```python
def setup_test_environment(io, fnames, model_name, edit_format):
    coder = Coder.create(
        main_model=models.Model(model_name),
        edit_format=edit_format,
        io=io,
        fnames=fnames,
        use_git=False,
        stream=False,
        verbose=verbose,
        cache_prompts=True,
        suggest_shell_commands=False,
    )
    return coder
```

### 4. Result Collection

The system collects and processes test results comprehensively:

```python
def process_test_results(testdir, results):
    results_fname = testdir / ".aider.results.json"
    
    test_results = {
        "testdir": str(testdir),
        "testcase": testdir.name,
        "model": main_model.name,
        "edit_format": edit_format,
        "tests_outcomes": test_outcomes,
        "cost": coder.total_cost,
        "duration": duration,
        "test_timeouts": timeouts,
        "num_error_outputs": io.num_error_outputs,
        "num_user_asks": io.num_user_asks,
        "num_exhausted_context_windows": coder.num_exhausted_context_windows,
        "num_malformed_responses": coder.num_malformed_responses,
    }
    
    results_fname.write_text(json.dumps(test_results, indent=4))
```

## Test Output Processing

### 1. Test Output Cleaning

The system standardizes test output for consistent analysis:

```python
def cleanup_test_output(output, testdir):
    # Remove timing information
    res = re.sub(
        r"^Ran \d+ tests in \d+\.\d+s$",
        "",
        output,
        flags=re.MULTILINE,
    )
    
    # Standardize separator lines
    res = re.sub(
        r"^====*$",
        "====",
        res,
        flags=re.MULTILINE,
    )
    
    # Normalize paths
    res = res.replace(str(testdir), str(testdir.name))
    return res
```

### 2. Error Analysis

The system categorizes and analyzes different types of test failures:

1. Syntax Errors: Issues with code structure
2. Runtime Errors: Execution failures
3. Assertion Errors: Test case failures
4. Timeout Errors: Execution time limits

### 3. Results Storage

Test results are stored in a structured format for later analysis:

1. JSON Results: Detailed test execution data
2. History Files: Complete interaction logs
3. Modified Files: Final state of changed files

## Usage Examples

Running specific test cases:
```bash
# Run a single test case
./benchmark/benchmark.py test_case_directory --model gpt-4

# Run with multiple retries
./benchmark/benchmark.py tests --tries 3 --threads 1

# Filter test cases by keyword
./benchmark/benchmark.py all_tests --keywords "array,sort"
```

## Best Practices

1. Regular Cleanup: Remove old test artifacts regularly
2. Version Control: Track test case modifications
3. Documentation: Maintain clear test requirements
4. Error Handling: Implement comprehensive error checking
5. Resource Management: Monitor system resources

## Next Steps
With understanding of both the main benchmarking process and test case processing, we can move on to analyzing and visualizing the results, which we'll cover in the next lesson about Performance Metrics and Visualization.
