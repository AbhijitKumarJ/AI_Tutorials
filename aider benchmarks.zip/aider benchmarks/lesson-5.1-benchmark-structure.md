# Lesson 5.1: Creating Custom Benchmarks - Structure and Organization

## Introduction to Custom Benchmark Creation

Understanding how to create and structure custom benchmarks is essential for extending Aider's testing capabilities and ensuring comprehensive evaluation of new features or specific use cases. This lesson provides a detailed exploration of benchmark creation, focusing on proper organization and best practices.

## Benchmark Directory Structure

The benchmark system follows a specific directory structure that must be maintained for proper operation. Here's a detailed breakdown of the standard layout:

```
tmp.benchmarks/                           # Root benchmark directory
├── exercism-python/                      # Main test suite directory
│   ├── test-case-1/                      # Individual test case
│   │   ├── source_file.py               # Source file to be modified
│   │   ├── test_source.py               # Unit tests
│   │   ├── .docs/                       # Documentation directory
│   │   │   ├── introduction.md          # Context and setup
│   │   │   ├── instructions.md          # Main task description
│   │   │   └── instructions.append.md    # Additional instructions
│   │   └── .aider.results.json          # Test results and metrics
│   └── test-case-2/
│       └── ...
└── YYYY-MM-DD-HH-MM-SS--benchmark-name/  # Timestamped benchmark runs
```

## Creating Individual Test Cases

Each test case should be structured as a self-contained unit with all necessary files. Let's examine each component in detail:

### Source Files
The source file (e.g., `source_file.py`) represents the initial state of the code that Aider will modify. This file should:
- Contain the base implementation or skeleton code
- Be syntactically valid Python code
- Include any necessary imports and dependencies
- Avoid external dependencies beyond standard library

### Test Files
The test file (e.g., `test_source.py`) contains the unit tests that verify the correctness of Aider's modifications:
- Must use Python's unittest framework
- Should include comprehensive test cases
- Must be named with the pattern `*_test.py` or `test_*.py`
- Should provide clear failure messages for debugging

### Documentation Structure
The `.docs` directory contains three key files that guide Aider's understanding and execution of the task:

1. `introduction.md`:
   - Provides context and background information
   - Explains any domain-specific concepts
   - Sets up the scenario for the task

2. `instructions.md`:
   - Contains the main task description
   - Specifies requirements and constraints
   - Details expected behavior and outcomes
   - Uses clear, unambiguous language

3. `instructions.append.md` (optional):
   - Provides additional context or requirements
   - Includes edge cases or special considerations
   - Can be used for hints or supplementary information

## Best Practices for Custom Benchmarks

### Test Case Design
When designing test cases, follow these principles:

1. Isolation: Each test case should be completely independent and self-contained. Avoid dependencies between test cases or external resources.

2. Clarity: Instructions should be clear and unambiguous. Use specific examples where appropriate to illustrate expected behavior.

3. Completeness: Include both common and edge cases in your test suite. Consider boundary conditions and error scenarios.

4. Reproducibility: Ensure that test results are deterministic and not affected by external factors like system time or random number generation.

### Documentation Guidelines
When writing documentation for test cases:

1. Use consistent formatting and style across all documentation files.

2. Provide clear examples of inputs and expected outputs.

3. Include explanation of any domain-specific terms or concepts.

4. Structure information logically, moving from general to specific details.

### File Organization
Maintain a clean and consistent file structure:

1. Use descriptive names for directories and files that reflect their purpose.

2. Keep related files together within the test case directory.

3. Maintain a clear separation between source code, tests, and documentation.

4. Use consistent file naming conventions across all test cases.

## Example Test Case Structure

Here's a concrete example of a well-structured test case:

```
exercise-name/
├── calculator.py                # Source file to be modified
├── calculator_test.py          # Unit tests
└── .docs/
    ├── introduction.md
    │   # Calculator Implementation Exercise
    │   # This exercise focuses on implementing basic arithmetic operations
    │   # in a calculator class...
    │
    ├── instructions.md
    │   # Implement the following operations in the Calculator class:
    │   # 1. Addition
    │   # 2. Subtraction
    │   # 3. Multiplication
    │   # 4. Division
    │   # Each operation should handle floating-point numbers...
    │
    └── instructions.append.md
        # Additional Requirements:
        # - Handle division by zero gracefully
        # - Round results to 2 decimal places
        # - Implement input validation...
```

## Common Pitfalls to Avoid

1. Overcomplicating Test Cases:
   Keep test cases focused and specific. Avoid combining multiple unrelated concepts in a single test case.

2. Insufficient Documentation:
   Provide thorough documentation that clearly explains the task and requirements. Don't assume implicit knowledge.

3. External Dependencies:
   Avoid relying on external services or resources. All necessary code should be contained within the test case directory.

4. Ambiguous Instructions:
   Use precise language and provide specific examples to avoid confusion about requirements.

This structured approach to creating custom benchmarks ensures consistency, maintainability, and effective evaluation of Aider's capabilities. The next section will cover how to execute and analyze these benchmarks effectively.