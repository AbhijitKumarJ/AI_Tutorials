# AIChat Lesson 1: Foundation and Core Structure (Part 2)

## Configuration System Deep Dive

### Config File Locations

The configuration file location follows platform-specific conventions:

- Windows: `C:\Users\Alice\AppData\Roaming\aichat\config.yaml`
- macOS: `/Users/Alice/Library/Application Support/aichat/config.yaml`  
- Linux: `/home/alice/.config/aichat/config.yaml`

### Configuration File Structure

The configuration file uses YAML format and supports extensive customization:

```yaml
# LLM settings
model: openai:gpt-4o
temperature: null
top_p: null

# Behavior settings
stream: true
save: true
keybindings: emacs
editor: null
wrap: no
wrap_code: false

# Function calling settings
function_calling: true
mapping_tools:
  fs: 'fs_cat,fs_ls,fs_mkdir,fs_rm,fs_write'
use_tools: null

# Session settings  
save_session: null
compress_threshold: 4000

# RAG settings
rag_embedding_model: null
rag_reranker_model: null
rag_top_k: 4
```

### Environment Variables System

The environment variable system provides runtime configuration through standardized variable names:

```rust
pub fn load_envs(&mut self) {
    if let Ok(v) = env::var(get_env_name("model")) {
        self.model_id = v;
    }
    if let Some(v) = read_env_value::<f64>(&get_env_name("temperature")) {
        self.temperature = v;
    }
    // Additional environment variable loading
}
```

Environment variables can override most configuration settings:
```bash
AICHAT_MODEL=gpt-4               # Override model
AICHAT_TEMPERATURE=0.7          # Override temperature
AICHAT_STREAM=false             # Disable streaming
```

### Cross-Platform Path Handling

The system implements careful path handling for different operating systems:

```rust
pub fn config_dir() -> PathBuf {
    if let Ok(v) = env::var(get_env_name("config_dir")) {
        PathBuf::from(v)
    } else if let Ok(v) = env::var("XDG_CONFIG_HOME") {
        PathBuf::from(v).join(env!("CARGO_CRATE_NAME"))
    } else {
        let dir = dirs::config_dir().expect("No user's config directory");
        dir.join(env!("CARGO_CRATE_NAME"))
    }
}
```

Platform-specific considerations include:
1. Windows paths handling
2. Unix-style permissions
3. XDG base directory support
4. Home directory resolution

### Session Persistence

Sessions implement a sophisticated persistence mechanism:

```rust
pub fn save(&mut self, session_name: &str, session_path: &Path, is_repl: bool) -> Result<()> {
    ensure_parent_exists(session_path)?;

    self.path = Some(session_path.display().to_string());

    let content = serde_yaml::to_string(&self)
        .with_context(|| format!("Failed to serde session '{}'", self.name))?;
    write(session_path, content).with_context(|| {
        format!(
            "Failed to write session '{}' to '{}'",
            self.name,
            session_path.display()
        )
    })?;

    if is_repl {
        println!("✓ Saved session to '{}'.", session_path.display());
    }

    self.dirty = false;
    Ok(())
}
```

Session persistence includes:
1. Conversation history
2. Model parameters
3. Tool configurations
4. Variable states
5. Data URL mappings

### Role and Agent State Management

The system implements different state management strategies for roles and agents:

1. Role State:
```rust
pub fn save_role(&mut self, name: Option<&str>) -> Result<()> {
    let mut role_name = match &self.role {
        Some(role) => {
            if role.has_args() {
                bail!("Unable to save the role with arguments (whose name contains '#')")
            }
            match name {
                Some(v) => v.to_string(),
                None => role.name().to_string(),
            }
        }
        None => bail!("No role"),
    };
    // Role saving logic
}
```

2. Agent State:
```rust
pub fn exit_agent(&mut self) -> Result<()> {
    self.exit_session()?;
    if self.agent.take().is_some() {
        self.rag.take();
        self.last_message = None;
    }
    Ok(())
}
```

### Practical Examples

1. Setting up a new configuration:
```rust
let config = Config::init(WorkingMode::Repl)?;
let global_config = Arc::new(RwLock::new(config));
```

2. Updating configuration values:
```rust
let mut config = global_config.write();
config.set_model("gpt-4")?;
config.set_temperature(Some(0.7));
```

3. Managing sessions:
```rust
let mut session = Session::new(&config, "my-session");
session.add_message(&input, "Hello, world!")?;
session.save()?;
```

### Best Practices

1. Configuration Access:
- Always use the `GlobalConfig` type for shared state
- Implement proper error handling for configuration operations
- Use environment variables for runtime configuration
- Keep configuration files human-readable and well-documented

2. State Management:
- Maintain clear state boundaries
- Implement proper validation for all configuration values
- Handle cross-platform differences explicitly
- Use atomic operations for state updates

3. Error Handling:
- Provide clear error messages
- Implement proper cleanup in error cases
- Handle cross-platform error scenarios
- Maintain audit trail for configuration changes

