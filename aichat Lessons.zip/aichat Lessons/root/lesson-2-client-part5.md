# AIChat Lesson 2: Client Abstraction Layer
## Part 5: End-User Guide and Usage Patterns

### Initial Setup and Configuration

#### First-Time Setup

When you first run AIChat, it guides you through configuration:

```bash
$ aichat
> No config file, create a new one? Yes
> Platform: openai
? API Key: ***
✨ Saved config file to '/home/alice/.config/aichat/config.yaml'
```

Configuration files are located at platform-specific paths:
- Windows: `C:\Users\Alice\AppData\Roaming\aichat\config.yaml`
- macOS: `/Users/Alice/Library/Application Support/aichat/config.yaml`
- Linux: `/home/alice/.config/aichat/config.yaml`

#### Basic Configuration File Structure

```yaml
# Basic LLM settings
model: openai:gpt-4o             # Default model
temperature: null                # Temperature parameter
top_p: null                      # Top-p parameter

# Client-specific settings
clients:
  - type: openai
    api_base: https://api.openai.com/v1
    api_key: xxx

  - type: openai-compatible
    name: local
    api_base: http://localhost:8080/v1
    api_key: xxx
    models:
      - name: llama3.1
        max_input_tokens: 128000
        supports_function_calling: true
```

### Using Different LLM Platforms

#### Platform Selection
Choose between supported platforms:

1. Direct Platforms:
```bash
# Use OpenAI
aichat -m openai:gpt-4 "Hello"

# Use Claude
aichat -m claude:claude-3-opus "Hello"

# Use Google's Gemini
aichat -m gemini:gemini-pro "Hello"
```

2. OpenAI-Compatible Platforms:
```bash
# Use local Ollama
aichat -m ollama:llama3.1 "Hello"

# Use Mistral
aichat -m mistral:mistral-large "Hello"
```

### Common Usage Patterns

#### Basic Chat Usage

1. Simple Queries:
```bash
aichat "What is the capital of France?"
```

2. Multi-line Input:
```bash
aichat "Write a Python function that:
1. Takes a list of numbers
2. Returns the sum of even numbers
3. Includes error handling"
```

3. Code Generation:
```bash
# Generate code only
aichat -c "fibonacci sequence in Python"

# With explanation
aichat "Explain how to implement merge sort in Python"
```

#### Advanced Features

1. File Input:
```bash
# Analyze a single file
aichat -f data.txt "Summarize this"

# Multiple files
aichat -f file1.txt -f file2.txt "Compare these files"

# Directory analysis
aichat -f ./src/ "Analyze this codebase"
```

2. Image Analysis (for supported models):
```bash
# Analyze an image
aichat -f image.png "Describe this image"

# Multiple images
aichat -f img1.jpg -f img2.jpg "Compare these images"
```

### Session Management

1. Starting a Session:
```bash
# Start a temporary session
aichat -s

# Named session
aichat -s coding_session

# Empty session
aichat -s coding_session --empty-session
```

2. Session Commands:
```bash
# In REPL mode
.session                 # Begin a session
.empty session          # Erase messages
.compress session       # Compress messages
.info session          # View session info
.save session          # Save session
.exit session          # End session
```

### Role Usage

1. Using Predefined Roles:
```bash
# Use a role
aichat -r python_expert "How to handle exceptions?"

# Combine with session
aichat -s coding -r python_expert
```

2. Role Commands:
```bash
.role                    # Create/switch role
.info role              # View role info
.edit role              # Edit current role
.save role              # Save role
.exit role              # Leave role
```

### Environment Variables

Important environment variables:
```bash
# API Keys
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-..."
export GEMINI_API_KEY="..."

# Configuration
export AICHAT_MODEL="openai:gpt-4"
export AICHAT_TEMPERATURE="0.7"
export AICHAT_STREAM="false"

# Proxy Settings
export HTTPS_PROXY="http://proxy:8080"
export ALL_PROXY="socks5://proxy:1080"
```

### Troubleshooting Guide

#### Common Issues and Solutions

1. API Connection Issues:
```bash
# Enable debug logging
export AICHAT_LOG_LEVEL=debug

# Check logs
tail -f ~/.config/aichat/aichat.log
```

2. Model Availability:
```bash
# List available models
aichat --list-models

# Check model capabilities
aichat --info
```

3. Configuration Problems:
```bash
# View configuration
cat ~/.config/aichat/config.yaml

# Test configuration
aichat --dry-run "test message"
```

### Performance Tips

1. Token Management:
```yaml
# Set compression threshold in config
compress_threshold: 4000  # Compress when exceeding tokens

# Use appropriate models for tasks
model: openai:gpt-3.5-turbo  # For simple tasks
model: openai:gpt-4          # For complex tasks
```

2. Stream Control:
```bash
# Disable streaming for short responses
aichat -S "Quick question"

# Enable for long responses
aichat "Write a detailed essay"
```

### Security Best Practices

1. API Key Management:
```bash
# Use environment file
echo "OPENAI_API_KEY=sk-..." > ~/.config/aichat/.env

# Use environment variables
export OPENAI_API_KEY="sk-..."
```

2. File Permissions:
```bash
# Secure config directory
chmod 700 ~/.config/aichat
chmod 600 ~/.config/aichat/config.yaml
chmod 600 ~/.config/aichat/.env
```

### Advanced Configuration Examples

1. Client-Specific Settings:
```yaml
clients:
  - type: openai
    api_base: https://api.openai.com/v1
    api_key: xxx
    patch:
      chat_completions:
        'gpt-4':
          body:
            temperature: 0.7
            max_tokens: 2000
```

2. Custom Document Loaders:
```yaml
document_loaders:
  pdf: 'pdftotext $1 -'       # PDF loader
  docx: 'pandoc --to plain $1' # DOCX loader
```

### Additional Usage Tips

1. Shell Integration:
```bash
# Bash integration
source /path/to/aichat/scripts/shell-integration/integration.bash

# Use Alt+E to get shell command suggestions
$ ls -l  # Press Alt+E for suggestions
```

2. Completion Scripts:
```bash
# Add to .bashrc or .zshrc
source /path/to/aichat/scripts/completions/aichat.bash
```

3. HTTP Server Mode:
```bash
# Start server
aichat --serve

# Access endpoints
curl http://localhost:8000/v1/chat/completions
curl http://localhost:8000/v1/embeddings
```

Understanding these usage patterns and configurations helps users make the most of AIChat's capabilities across different platforms and use cases. The system's flexibility allows it to be adapted to various workflows while maintaining security and performance.

For more details, users can always access:
- Help command: `aichat --help`
- Documentation: `https://github.com/sigoden/aichat/wiki`
- Model list: `aichat --list-models`
- Role list: `aichat --list-roles`