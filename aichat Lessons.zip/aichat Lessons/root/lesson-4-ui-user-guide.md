# AIChat UI Features: A User's Guide

## Basic Terminal Interface

### Color and Styling Support

AIChat automatically detects your terminal's capabilities and provides appropriate styling:

1. **Color Support Levels**:
```
- Full Color (24-bit): Rich, detailed color output
- 256 Colors: Good color variety
- Basic Color (16 colors): Simple color highlighting
- No Color: Falls back to plain text
```

You can control color output using:
```bash
# Disable colors
export NO_COLOR=1
aichat

# Force light theme
export AICHAT_LIGHT_THEME=1
aichat
```

### Text Layout

1. **Text Wrapping**:
```bash
# Control wrapping behavior
aichat --wrap auto       # Automatic wrapping
aichat --wrap no        # No wrapping
aichat --wrap 80        # Wrap at specific width
```

2. **Code Block Wrapping**:
```yaml
# In config.yaml
wrap_code: true  # Enable code block wrapping
wrap_code: false # Disable code block wrapping
```

## Message Display

### Text Formatting

AIChat supports rich text formatting in messages:

1. **Markdown Support**:
```markdown
- **Bold text** appears bold
- *Italic text* appears italicized
- `Code snippets` are highlighted
- Lists appear properly formatted
- [Links] are highlighted
```

2. **Code Blocks**:
   ```python
   # Code blocks support syntax highlighting
   def example():
       print("Language is automatically detected")
   ```

### Progress Indicators

AIChat provides various progress indicators:

1. **Spinner Types**:
```
⠋ Processing request...
⠙ Loading data...
⠹ Computing response...
```

2. **Status Messages**:
```
✓ Operation completed successfully
✗ Operation failed
⚠ Warning: proceeding with caution
```

## Custom Themes

### Theme Selection

You can choose between light and dark themes:

1. **Configure in Settings**:
```yaml
# config.yaml
light_theme: false  # Use dark theme
light_theme: true   # Use light theme
```

2. **Custom Theme Files**:
```
Place theme files in your config directory:
- dark.tmTheme  - Custom dark theme
- light.tmTheme - Custom light theme
```

### Available Themes

AIChat includes several built-in themes:
```
- Dracula
- Gruvbox
- Solarized (Dark/Light)
- GitHub (Dark/Light)
- OneHalf (Dark/Light)
```

To use a theme:
```bash
# Download theme file
cd ~/.config/aichat  # Or your config directory
wget -O dark.tmTheme 'https://raw.githubusercontent.com/...'
```

## Custom REPL Prompt

### Prompt Customization

The REPL prompt can display various information:

1. **Basic Format**:
```
{role}> Command      # Basic prompt
temp/coding> Command # Session with name
coding@rag> Command  # Role with RAG
```

2. **Custom Format**:
```yaml
# config.yaml
left_prompt: '{color.green}{role}{color.cyan}> {color.reset}'
right_prompt: '{color.purple}{tokens}{color.reset}'
```

### Available Variables

The prompt can show:
```
{role}          - Current role
{session}       - Session name
{rag}           - RAG status
{agent}         - Agent name
{tokens}        - Token usage
{consume_tokens} - Used tokens
{consume_percent} - Token usage percentage
```

## Function Calling Display

### Output Formatting

When functions are called, output is formatted:

1. **Function Calls**:
```
Calling: web_search
Parameters: {"query": "example search"}
Result: Search results appear here...
```

2. **Error Display**:
```
Error: Function call failed
Details: Rate limit exceeded
Solution: Try again in 60 seconds
```

## Session Management

### Session Display

Sessions show contextual information:

1. **Session Header**:
```
=== Session: coding ===
Model: gpt-4
Role: python-expert
Messages: 12
```

2. **Message History**:
```
User> What is Python?
Assistant> Python is a programming language...
User> Show an example
Assistant> Here's a simple example:
```

### Token Management

Token usage is displayed:
```
Used: 1250 tokens (25%)
Remaining: 3750 tokens
Compressed: 2 messages
```

## RAG Integration Display

### Source Display

When using RAG, sources are shown:

1. **Source References**:
```
Sources:
1. documentation.md (85% match)
2. examples/code.py (72% match)
3. tutorial/basics.md (65% match)
```

2. **Context Usage**:
```
Using context from:
- Section: "Getting Started"
- Relevance: High
- Characters: 1250
```

## Error Handling

### Error Display Types

Errors are displayed with context:

1. **Simple Errors**:
```
Error: Unable to complete request
Reason: Network timeout
Action: Please try again
```

2. **Detailed Errors**:
```
Error: Model API error
Details:
  - Status: 429
  - Message: Rate limit exceeded
  - Retry after: 60 seconds
Stack trace available with --debug
```

## Terminal Features

### Key Bindings

Default key bindings:
```
Ctrl+C    - Cancel current operation
Ctrl+D    - Exit AIChat
Ctrl+R    - Search history
Ctrl+O    - Open external editor
Alt+B     - Move backward one word
Alt+F     - Move forward one word
```

### Multi-line Input

Multiple ways to input multi-line text:
```
1. Type ::: to start multi-line mode
2. End with another ::: to finish
3. Use Ctrl+O to open in external editor
4. Paste multi-line text directly
```

## Command History

### History Navigation

Navigate through command history:
```
Up Arrow     - Previous command
Down Arrow   - Next command
Ctrl+R      - Search history
Ctrl+G      - Cancel history search
```

## Performance Features

### Response Streaming

Responses stream in real-time:
```
Assistant> Let me explain...▌
            (text appears progressively)
```

### Progress Tracking

Long operations show progress:
```
Compressing session... ⠋
Loading documents... 45%
Processing images... Done!
```

## Accessibility Features

### Screen Reader Support

Screen reader considerations:
```
- Progress indicators have aria labels
- Error messages are properly tagged
- Code blocks have language indicators
- Images have alt text
```

## Best Practices

### For Best Results

1. **Terminal Setup**:
```
- Use a terminal with UTF-8 support
- Enable true color if available
- Use a monospace font
- Set adequate terminal width (80+ chars)
```

2. **Input Methods**:
```
- Use multi-line mode for long input
- Leverage external editor for complex text
- Use command history efficiently
```

3. **Session Management**:
```
- Start new sessions for new contexts
- Use roles appropriately
- Monitor token usage
- Allow compression when prompted
```

These features make AIChat's interface powerful and flexible while maintaining usability across different terminal environments and use cases.