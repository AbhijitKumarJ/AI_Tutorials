# AIChat Lesson 2: Client Abstraction Layer
## Part 4: Foundational Concepts and Additional Implementation Details

### LLM Integration Concepts

#### Model Types and Capabilities

AIChat works with different types of Large Language Models (LLMs) which have distinct capabilities:

1. Chat Models - Used for conversation and text generation:

```rust
pub struct Model {
    client_name: String,
    data: ModelData,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModelData {
    pub name: String,
    pub model_type: String,
    pub max_input_tokens: Option<usize>,
    pub input_price: Option<f64>,
    pub output_price: Option<f64>,
    pub supports_vision: bool,
    pub supports_function_calling: bool,
}
```

2. Embedding Models - Used for RAG and semantic search:

```yaml
- name: text-embedding-3-large
  type: embedding
  input_price: 0.13
  max_tokens_per_chunk: 8191
  default_chunk_size: 2000
  max_batch_size: 100
```

3. Reranker Models - Used for improving search relevance:

```yaml
- name: cohere-rerank-v2-0
  type: reranker
  max_input_tokens: 2048
```

Each model type serves different purposes and requires specific handling in the client layer.

#### Token Management Concepts

Detailed explanation of token management:

```rust
impl Model {
    pub fn total_tokens(&self, messages: &[Message]) -> usize {
        let mut total = 0;
        for msg in messages {
            total += self.count_tokens(&msg.content);
        }
        total
    }

    pub fn guard_max_input_tokens(&self, messages: &[Message]) -> Result<()> {
        if let Some(max_tokens) = self.max_input_tokens() {
            let total = self.total_tokens(messages);
            if total > max_tokens {
                bail!(
                    "Input too long: {} tokens. Maximum is {} tokens.",
                    total,
                    max_tokens
                );
            }
        }
        Ok(())
    }
}
```

Key concepts include:
1. Input/Output Tokens - Different models have different limits
2. Token Estimation - Different tokenizers produce different counts
3. Cost Calculation - Based on token usage
4. Compression - When token limits are approached

### Message Handling System

Deeper look at message handling:

```rust
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Message {
    pub role: MessageRole,
    pub content: MessageContent,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum MessageRole {
    System,
    User,
    Assistant,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(untagged)]
pub enum MessageContent {
    Text(String),
    Array(Vec<MessageContentPart>),
    ToolResults(ToolResults),
}
```

Message roles and their purposes:
1. System - Sets context and behavior
2. User - Contains queries or commands
3. Assistant - Contains responses
4. Tool Results - Contains function execution outputs

### Role and Session Management

#### Role System
```rust
pub struct Role {
    name: String,
    prompt: String,
    model_id: Option<String>,
    temperature: Option<f64>,
    top_p: Option<f64>,
    use_tools: Option<String>,
    model: Model,
}
```

Built-in roles include:
- `%shell%` - Generates shell commands
- `%explain-shell%` - Explains shell commands
- `%code%` - Generates code
- `%functions%` - Attaches function declarations

#### Session Management
```rust
pub struct Session {
    model_id: String,
    temperature: Option<f64>,
    top_p: Option<f64>,
    use_tools: Option<String>,
    save_session: Option<bool>,
    compress_threshold: Option<usize>,
    role_name: Option<String>,
    messages: Vec<Message>,
    compressed_messages: Vec<Message>,
}
```

Sessions maintain:
- Conversation history
- Model configuration
- Tool settings
- Compression state

### Stream Handling and Async Operations

Deeper look at stream handling:

```rust
pub struct StreamHandler {
    sender: UnboundedSender<SseEvent>,
    abort_signal: AbortSignal,
    buffer: String,
    tool_calls: Vec<ToolCall>,
}

impl StreamHandler {
    pub async fn process_chunk(&mut self, chunk: &str) -> Result<()> {
        self.buffer.push_str(chunk);
        if let Some(message) = self.parse_buffer()? {
            self.sender.send(message)?;
        }
        Ok(())
    }

    fn parse_buffer(&mut self) -> Result<Option<SseEvent>> {
        // Buffer parsing logic
        while let Some(line) = self.get_line()? {
            if line.starts_with("data: ") {
                let data = line["data: ".len()..].trim();
                if data == "[DONE]" {
                    return Ok(Some(SseEvent::Done));
                }
                // Process JSON data
            }
        }
        Ok(None)
    }
}
```

Key streaming concepts:
1. Buffer Management - Handling partial messages
2. Event Types - Different kinds of events in the stream
3. Error Handling - Dealing with stream interruptions
4. Backpressure - Managing flow control

### Function Calling Architecture

Detailed look at function calling:

```rust
pub struct Functions {
    functions: Vec<FunctionDeclaration>,
    bin_dir: PathBuf,
}

impl Functions {
    pub async fn eval_tool_calls(
        config: &GlobalConfig,
        calls: Vec<ToolCall>,
    ) -> Result<Vec<ToolResult>> {
        let mut results = vec![];
        for call in calls {
            let output = self.execute_tool(&call.name, &call.arguments).await?;
            results.push(ToolResult {
                name: call.name,
                output,
            });
        }
        Ok(results)
    }
}
```

Function calling enables:
1. Tool Integration - Connecting to external tools
2. Agent Capabilities - Complex task execution
3. State Management - Maintaining context
4. Safety - Secure execution boundaries

### Security Considerations

1. Path Safety:
```rust
fn safe_join_path<T1: AsRef<Path>, T2: AsRef<Path>>(
    base_path: T1,
    sub_path: T2,
) -> Option<PathBuf> {
    let base_path = base_path.as_ref();
    let sub_path = sub_path.as_ref();
    
    let joined_path = base_path.join(sub_path);
    if !joined_path.starts_with(base_path) {
        return None;
    }
    Some(joined_path)
}
```

2. File Permissions:
```rust
#[cfg(unix)]
fn set_secure_permissions(path: &Path) -> Result<()> {
    use std::os::unix::fs::PermissionsExt;
    let perms = std::fs::Permissions::from_mode(0o600);
    std::fs::set_permissions(path, perms)?;
    Ok(())
}
```

3. API Key Management:
```rust
fn load_api_keys() -> Result<()> {
    let env_file = Config::env_file();
    if !env_file.exists() {
        return Ok(());
    }
    
    let contents = read_to_string(&env_file)?;
    for line in contents.lines() {
        if let Some((key, value)) = line.split_once('=') {
            env::set_var(key.trim(), value.trim());
        }
    }
    Ok(())
}
```

### Additional Resources 

1. Documentation Standards:
- Inline documentation practices
- API documentation guidelines
- Example-driven documentation

2. Development Environment Setup:
- IDE configuration 
- Debug configuration
- Testing environment

3. Contribution Guidelines:
- Code style guide
- Pull request process
- Issue reporting

4. Performance Optimization:
- Token counting optimization
- Memory usage patterns
- Async execution strategies



Understanding these concepts is crucial for both using and extending AIChat's client abstraction layer. The system builds upon these fundamentals to provide a robust, extensible interface for interacting with various LLM providers while maintaining consistency and reliability across different platforms and environments.



This deeper understanding enables:
1. Effective debugging of client issues
2. Implementation of new features
3. Performance optimization
4. Cross-platform compatibility
5. Security maintenance