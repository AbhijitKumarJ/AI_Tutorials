# AIChat Lesson 3: Configuration and State Management - Part 6
## Advanced Usage Patterns and Real-World Scenarios 

### Custom Theme Configuration

Users can customize their AIChat experience with themes:

1. Setting Up Themes:
```bash
# Go to config directory
cd "$(dirname "$(aichat --info | grep config_file | awk '{print $2}')")"

# Download theme files
# For dark theme:
wget -O dark.tmTheme 'https://raw.githubusercontent.com/braver/Solarized/main/Solarized%20(dark).tmTheme'

# For light theme:
wget -O light.tmTheme 'https://raw.githubusercontent.com/braver/Solarized/main/Solarized%20(light).tmTheme'
```

2. Theme Configuration:
```yaml
# In config.yaml
highlight: true                  # Enable syntax highlighting
light_theme: false              # Use dark theme by default
```

### Advanced Role Usage

1. Creating Complex Roles:
```yaml
# roles/code-reviewer.md
---
model: openai:gpt-4o
temperature: 0.3
top_p: 0.9
use_tools: git,fs
---
You are an expert code reviewer who specializes in:
1. Security best practices
2. Performance optimization
3. Code maintainability
...
```

2. Role Arguments:
```bash
# Role with arguments
aichat -r convert#json#yaml 'data: value'

# Multiple transformations
aichat -r convert#yaml#toml 'key: value'
```

3. Chaining Roles:
```bash
# First convert then review
aichat -r convert#json#yaml 'data' | aichat -r code-reviewer
```

### Session Management Strategies

1. Project-Based Sessions:
```bash
# Create project session
aichat -s myproject -r python-expert

# Add documentation context
> .file docs/*.md

# Save session state
> .save session
```

2. Session Compression Strategies:
```yaml
# In config.yaml
compress_threshold: 4000
summarize_prompt: |
  Create a concise summary of the discussion 
  focusing on:
  1. Key decisions made
  2. Important code snippets
  3. Open questions
```

3. Session Backup:
```bash
# Export session
> .save session mysession
# Sessions are saved to ~/.config/aichat/sessions/

# Backup sessions directory
cp -r ~/.config/aichat/sessions/ ~/backups/aichat/
```

### Advanced Configuration Scenarios

1. Multi-Platform Setup:
```yaml
# Windows-specific
editor: 'C:\\Program Files\\Notepad++\\notepad++.exe'

# Unix-specific
editor: /usr/bin/vim
```

2. Custom Tool Mapping:
```yaml
mapping_tools:
  dev: 'git,fs,web_search'
  ops: 'docker,kubernetes,aws'
  security: 'nmap,metasploit,burp'

# Use in roles
---
use_tools: dev,security
---
```

3. Environment-Specific Settings:
```bash
# Development
export AICHAT_MODEL=openai:gpt-3.5-turbo
export AICHAT_TEMPERATURE=0.7

# Production
export AICHAT_MODEL=openai:gpt-4o
export AICHAT_TEMPERATURE=0.3
```

### Real-World Use Cases

1. Code Development Workflow:
```bash
# Start development session
aichat -s dev -r coder

# Add project context
> .file src/**/*.py

# Get code suggestions
> How can I optimize this code?

# Generate tests
> Generate unit tests for this module
```

2. Documentation Management:
```bash
# Start documentation session
aichat -s docs -r technical-writer

# Add existing docs
> .file current-docs/*.md

# Generate new documentation
> Create API documentation for this endpoint

# Review and improve
> Review and suggest improvements for this documentation
```

3. System Administration:
```bash
# Debug system issues
aichat -r system-admin "High CPU usage troubleshooting"

# Generate complex commands
aichat -e "find all log files older than 7 days and compress them"

# Security audit
aichat -r security-auditor -f audit-logs.txt "Analyze for suspicious patterns"
```

### Integration with Development Tools

1. Git Integration:
```bash
# Review changes
git diff | aichat -r code-reviewer "Review these changes"

# Generate commit messages
git diff --staged | aichat -r git-expert "Generate commit message"
```

2. CI/CD Usage:
```bash
# In CI pipeline
export AICHAT_NO_STREAM=true
export AICHAT_SAVE=false

# Automated code review
git diff origin/main | aichat -r ci-reviewer > review.md
```

3. Editor Integration:
```bash
# VS Code settings.json
{
    "terminal.integrated.env.linux": {
        "AICHAT_EDITOR": "code --wait"
    }
}
```

### Customization and Extension

1. Custom REPL Prompt:
```yaml
# In config.yaml
left_prompt: |
  {color.green}{?session {session}}{?role /{role}}{color.cyan}> {color.reset}

right_prompt: |
  {color.purple}{?session {consume_tokens}}{color.reset}
```

2. Custom Function Handlers:
```yaml
# Document loaders
document_loaders:
  pdf: 'pdftotext $1 -'
  docx: 'pandoc --to plain $1'
  xlsx: 'xlsx2csv $1'
```

3. Custom Keybindings:
```yaml
keybindings: emacs  # or vi
editor: vim        # or any preferred editor
```

### Advanced Troubleshooting

1. Session Debugging:
```bash
# View session details
> .info session

# Examine token usage
> .set max_tokens 4096
> .info

# Check compression status
> .compress session
```

2. Configuration Verification:
```bash
# Check current settings
aichat --info

# Test configuration
aichat --dry-run "Test message"

# Debug mode
AICHAT_LOG_LEVEL=debug aichat
```

3. Performance Optimization:
```yaml
# Optimize for speed
stream: false
save: false
compress_threshold: 2000

# Optimize for quality
temperature: 0.3
top_p: 0.9
```

### Best Practices for Teams

1. Shared Configuration:
```bash
# Create team config template
aichat --info > team-config-template.yaml

# Document custom settings
# team-config.yaml
---
# Team-specific settings
model: openai:gpt-4o
save_session: true
compress_threshold: 3000
```

2. Role Management:
```bash
# Share roles
cp -r ~/.config/aichat/roles/* ./team-roles/

# Document role usage
cat > ROLES.md << EOF
# Team Roles
- code-reviewer: For code review tasks
- security-audit: For security reviews
- doc-writer: For documentation
EOF
```

3. Session Guidelines:
```markdown
# Session Best Practices
1. Use project-specific sessions
2. Enable compression for long sessions
3. Save important sessions
4. Use consistent naming conventions
   - project-dev
   - project-docs
   - project-security
```

These advanced usage patterns and real-world scenarios complement the previous parts by providing concrete examples of how to effectively use AIChat's configuration and state management features in production environments.