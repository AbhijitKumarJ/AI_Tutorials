# AIChat Lesson 3: Configuration and State Management - Part 5
## End-User Perspective and Usage Guide

### Initial Setup and Configuration

When a user first runs AIChat, they'll encounter the initial setup process:

```bash
$ aichat
> No config file, create a new one? Yes
> Platform: openai
? API Key: ***
✨ Saved config file to '/home/user/.config/aichat/config.yaml'
```

The configuration file locations vary by platform:
- Windows: `C:\Users\<User>\AppData\Roaming\aichat\config.yaml`
- macOS: `/Users/<User>/Library/Application Support/aichat/config.yaml`
- Linux: `/home/<user>/.config/aichat/config.yaml`

### Basic Command Line Usage

1. Starting AIChat with Different Modes:
```bash
aichat                                          # Enter REPL mode
aichat "What is the weather like?"              # Direct query mode
aichat -e "create a new directory named src"    # Execute shell command
aichat -c "fibonacci sequence in python"        # Generate code
```

2. Using Models and Roles:
```bash
# Select specific model
aichat -m openai:gpt-4o "Hello"

# Use a role
aichat -r python-expert "Explain generators"

# Combine model and role
aichat -m openai:gpt-4o -r coder "Write a web server"
```

3. Managing Sessions:
```bash
# Start a new session
aichat -s my_session

# Use empty session
aichat -s my_session --empty-session

# Force session save
aichat -s my_session --save-session
```

### REPL Command System

The REPL interface provides several important commands for configuration:

1. Model Management:
```
> .model gpt-4                   # Change model
> .info                         # View current model info
```

2. Role Management:
```
> .role python-expert           # Switch to role
> .save role                    # Save current role
> .info role                    # View role info
> .exit role                    # Exit role
```

3. Session Commands:
```
> .session coding              # Start/switch session
> .empty session              # Clear session
> .compress session           # Compress history
> .save session              # Save session
> .exit session             # End session
```

4. Configuration Settings:
```
> .set temperature 0.7        # Set temperature
> .set top_p 0.9             # Set top_p value
> .set stream false          # Disable streaming
```

### Working with Variables

Users can manage variables in different ways:

1. Environment Variables:
```bash
# Set model
export AICHAT_MODEL="openai:gpt-4"

# Set behavior
export AICHAT_STREAM=false
export AICHAT_SAVE=true

# Set API keys
export OPENAI_API_KEY="sk-..."
```

2. Agent Variables:
```
> .variable set API_KEY your_key_here
> .variable set WORKSPACE /path/to/workspace
```

### Session Management

Sessions provide persistent conversation context:

1. Creating Sessions:
```
> .session my_project
Creating new session 'my_project'...
```

2. Session Operations:
```
> .empty session              # Clear history
> .compress session          # Reduce token usage
> .info session             # View status
```

3. Multiple Sessions:
```bash
# Switch between sessions
aichat -s project1 "Task 1"
aichat -s project2 "Task 2"
```

### Role System

Roles help customize AI behavior:

1. Built-in Roles:
```bash
# Code generation
aichat -r %code% "Write a web server"

# Shell commands
aichat -r %shell% "Create new directory"
```

2. Custom Roles:
```yaml
# roles/python-expert.md
---
model: openai:gpt-4o
temperature: 0.3
---
You are an expert Python developer...
```

### Configuration File Examples

1. Basic Configuration:
```yaml
# Basic settings
model: openai:gpt-4o
temperature: 0.7
stream: true
save: true

# Interface settings
keybindings: emacs
editor: vim
wrap: no
```

2. Function Configuration:
```yaml
# Function calling settings
function_calling: true
mapping_tools:
  fs: 'fs_cat,fs_ls,fs_mkdir,fs_rm'
use_tools: 'fs,web_search'
```

3. Session Configuration:
```yaml
# Session management
save_session: true
compress_threshold: 4000
summarize_prompt: 'Summarize the discussion...'
```

### Common Usage Patterns

1. Interactive Development:
```bash
# Start session with role
aichat -s coding -r python-expert

# Continue conversation
> Tell me about Python generators
> Show me an example
> How do I handle errors?
```

2. Shell Integration:
```bash
# Generate and execute commands
aichat -e "create a new python project"

# Explain commands
aichat -r %explain-shell% "ls -la | grep .py"
```

3. Code Generation:
```bash
# Direct code output
aichat -c "write a REST API in Python"

# With specific model
aichat -m openai:gpt-4o -c "implement binary search"
```

### Troubleshooting Guide

1. Configuration Issues:
```bash
# Check configuration
aichat --info

# List available models
aichat --list-models

# List roles
aichat --list-roles
```

2. Debug Mode:
```bash
# Enable debug logging
export AICHAT_LOG_LEVEL=debug

# Check logs
tail -f ~/.config/aichat/aichat.log
```

3. Common Problems:
- Token limits: Use session compression
- API errors: Check API keys and quotas
- Path issues: Verify configuration paths

### Best Practices

1. Session Management:
- Use descriptive session names
- Regularly compress long sessions
- Save important sessions

2. Role Usage:
- Create focused, specific roles
- Use appropriate temperature settings
- Document role purposes

3. Configuration:
- Keep sensitive data in environment variables
- Use version control for configurations
- Document custom settings

### Additional Features

1. RAG Integration:
```bash
# Start with RAG
aichat -R my_knowledge_base

# Add documents
> .rag add documents/*.md
```

2. Agent System:
```bash
# Use agent
aichat -a dev_assistant

# Set variables
> .variable set PROJECT_DIR ./myproject
```

3. Web Interface:
```bash
# Start web server
aichat --serve

# Access interfaces:
# - http://localhost:8000/playground
# - http://localhost:8000/arena
```

This user-focused guide should help bridge the gap between the technical implementation details covered in previous parts and practical day-to-day usage of AIChat's configuration and state management features.