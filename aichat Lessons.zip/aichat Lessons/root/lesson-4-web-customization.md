# Customizing and Extending AIChat Web Interfaces

## Theme Customization

### CSS Variables System

AIChat uses CSS variables for easy theme customization. You can override these in your own stylesheet:

```css
/* Custom theme example */
:root {
    /* Core Colors */
    --fg-primary: #1652f1;
    --fg-default: black;
    --bg-primary: white;
    --bg-default: #f9f9f9;
    --border-primary: #c3c3c3;
    
    /* Component-specific colors */
    --message-bg: var(--bg-primary);
    --code-block-bg: #f6f8fa;
    --input-bg: var(--bg-primary);
    
    /* Spacing */
    --spacing-base: 1rem;
    --spacing-sm: 0.5rem;
    --spacing-lg: 1.5rem;
    
    /* Typography */
    --font-family-base: "Noto Sans", system-ui, -apple-system, sans-serif;
    --font-size-base: 1rem;
    --line-height-base: 1.5;
}

/* Dark theme overrides */
@media (prefers-color-scheme: dark) {
    :root {
        --fg-default: white;
        --bg-primary: black;
        --bg-default: #121212;
        --border-primary: #3c3c3c;
        --code-block-bg: #1e1e1e;
    }
}
```

### Custom Theme Files

Create a custom theme by placing a `.tmTheme` file in your configuration directory:

```yaml
# Location: <config-dir>/dark.tmTheme or light.tmTheme

# Example theme structure
name: Custom Theme
settings:
  - settings:
      background: '#282c34'
      foreground: '#abb2bf'
      caret: '#528bff'
      selection: '#3e4451'
      gutterForeground: '#636d83'
      
  - name: Comment
    scope: comment
    settings:
      foreground: '#5c6370'
      
  - name: String
    scope: string
    settings:
      foreground: '#98c379'
```

## Extending Components

### Custom Message Components

Create custom message renderers by extending the base components:

```javascript
// Custom message renderer
function renderCustomMessage(message) {
    const baseClasses = 'chat-message-content markdown-body';
    const customClasses = message.type === 'special' ? 'special-message' : '';
    
    return `
        <div class="${baseClasses} ${customClasses}">
            ${renderCustomContent(message)}
            ${renderCustomToolbox(message)}
        </div>
    `;
}

// Implementation
Alpine.data('customMessage', () => ({
    init() {
        this.renderer = renderCustomMessage;
    },
    
    handleSpecialAction() {
        // Custom action handling
    }
}));
```

### Custom Input Handlers

Add support for new input types:

```javascript
// Custom file handler
async function handleCustomFileType(file) {
    if (file.type === 'application/custom') {
        try {
            const content = await processCustomFile(file);
            return {
                type: 'custom',
                content: content,
                metadata: {
                    filename: file.name,
                    size: file.size
                }
            };
        } catch (err) {
            console.error('Custom file processing failed:', err);
            throw new Error('Unable to process custom file');
        }
    }
    return null;
}

// Register handler
registerFileHandler('custom', handleCustomFileType);
```

## Adding New Features

### Custom API Integration

Integrate additional API endpoints:

```javascript
// Custom API client
class CustomApiClient {
    constructor(baseUrl, options = {}) {
        this.baseUrl = baseUrl;
        this.options = options;
    }
    
    async request(endpoint, config = {}) {
        const url = `${this.baseUrl}${endpoint}`;
        const headers = {
            'Content-Type': 'application/json',
            ...this.getAuthHeaders(),
            ...config.headers
        };
        
        try {
            const response = await fetch(url, {
                ...config,
                headers
            });
            
            if (!response.ok) {
                throw await this.handleError(response);
            }
            
            return await response.json();
        } catch (err) {
            return this.handleNetworkError(err);
        }
    }
}

// Usage
const customApi = new CustomApiClient('/api/v1/custom');
```

### Custom UI Controls

Add new interface elements:

```javascript
// Template
const customControl = {
    template: `
        <div class="custom-control" 
             x-data="customControl"
             @custom-event="handleCustomEvent">
            <div class="custom-control-header">
                <h3 x-text="title"></h3>
                <button @click="toggle">
                    <span x-text="expanded ? 'Hide' : 'Show'"></span>
                </button>
            </div>
            <div x-show="expanded" x-collapse>
                <slot></slot>
            </div>
        </div>
    `,
    
    // Component logic
    setup() {
        return {
            expanded: false,
            title: 'Custom Control',
            
            toggle() {
                this.expanded = !this.expanded;
            },
            
            handleCustomEvent(event) {
                // Handle custom events
            }
        };
    }
};

// Registration
Alpine.component('custom-control', customControl);
```

## Customizing Behavior

### Message Processing Pipeline

Extend the message processing pipeline:

```javascript
// Custom message processor
class MessageProcessor {
    constructor(options = {}) {
        this.processors = new Map();
        this.options = options;
    }
    
    register(type, processor) {
        this.processors.set(type, processor);
    }
    
    async process(message) {
        const processor = this.processors.get(message.type);
        if (processor) {
            return await processor(message, this.options);
        }
        return message;
    }
}

// Custom processors
const processor = new MessageProcessor({
    maxLength: 1000,
    allowHtml: false
});

processor.register('code', async (message) => {
    // Custom code processing
    return {
        ...message,
        content: await processCode(message.content)
    };
});
```

### Custom Renderers

Add support for new content types:

```javascript
// Custom content renderer
class CustomRenderer {
    constructor(options = {}) {
        this.options = options;
        this.renderers = new Map();
    }
    
    register(type, renderer) {
        this.renderers.set(type, renderer);
    }
    
    async render(content) {
        const renderer = this.renderers.get(content.type);
        if (renderer) {
            return await renderer(content, this.options);
        }
        return this.defaultRenderer(content);
    }
}

// Register custom renderer
const renderer = new CustomRenderer({
    sanitize: true,
    allowedTags: ['p', 'strong', 'em']
});

renderer.register('custom', async (content) => {
    // Custom rendering logic
    return `<div class="custom-content">${await renderCustom(content)}</div>`;
});
```

## Integration with External Tools

### Custom Tooling Integration

Add support for external tools:

```javascript
// Tool integration
class ExternalTool {
    constructor(config) {
        this.config = config;
        this.initialized = false;
    }
    
    async init() {
        if (this.initialized) return;
        
        try {
            await this.loadDependencies();
            await this.setupTool();
            this.initialized = true;
        } catch (err) {
            console.error('Tool initialization failed:', err);
            throw err;
        }
    }
    
    async execute(params) {
        if (!this.initialized) {
            await this.init();
        }
        
        return await this.runTool(params);
    }
}

// Usage
const customTool = new ExternalTool({
    name: 'custom-tool',
    dependencies: ['custom-lib'],
    config: {
        // Tool-specific configuration
    }
});
```

### Event System Integration

Add custom event handling:

```javascript
// Event system
class EventSystem {
    constructor() {
        this.handlers = new Map();
    }
    
    on(event, handler) {
        if (!this.handlers.has(event)) {
            this.handlers.set(event, new Set());
        }
        this.handlers.get(event).add(handler);
    }
    
    emit(event, data) {
        const handlers = this.handlers.get(event);
        if (handlers) {
            for (const handler of handlers) {
                handler(data);
            }
        }
    }
}

// Usage
const events = new EventSystem();

events.on('custom-event', async (data) => {
    // Handle custom event
    await processCustomEvent(data);
});
```

## Performance Optimizations

### Custom Caching

Implement custom caching strategies:

```javascript
class CustomCache {
    constructor(options = {}) {
        this.store = new Map();
        this.maxSize = options.maxSize || 100;
        this.ttl = options.ttl || 3600000; // 1 hour
    }
    
    set(key, value, ttl = this.ttl) {
        this.store.set(key, {
            value,
            expires: Date.now() + ttl
        });
        
        this.cleanup();
    }
    
    get(key) {
        const item = this.store.get(key);
        if (!item) return null;
        
        if (Date.now() > item.expires) {
            this.store.delete(key);
            return null;
        }
        
        return item.value;
    }
    
    cleanup() {
        const now = Date.now();
        for (const [key, item] of this.store) {
            if (now > item.expires) {
                this.store.delete(key);
            }
        }
    }
}
```

## Testing Extensions

### Test Utilities

Create test helpers for custom components:

```javascript
// Test utilities
const testUtils = {
    async mountComponent(component, props = {}) {
        return await Alpine.evaluate(() => {
            return Alpine.reactive({
                ...component,
                ...props
            });
        });
    },
    
    async simulateEvent(element, eventName, detail = {}) {
        const event = new CustomEvent(eventName, {
            bubbles: true,
            detail
        });
        element.dispatchEvent(event);
        await Alpine.nextTick();
    }
};

// Example test
describe('CustomComponent', () => {
    it('handles custom events', async () => {
        const component = await testUtils.mountComponent(CustomComponent);
        await testUtils.simulateEvent(component.$el, 'custom-event');
        
        expect(component.state).toBe('updated');
    });
});
```

## Conclusion

These customization patterns provide a foundation for extending AIChat's web interfaces while maintaining consistency with the core system. When implementing extensions:

1. Follow existing patterns and conventions
2. Maintain compatibility with the core system
3. Consider performance implications
4. Implement proper error handling
5. Add appropriate tests
6. Document customizations

The modular architecture makes it possible to extend functionality while preserving the reliability and performance of the base system.