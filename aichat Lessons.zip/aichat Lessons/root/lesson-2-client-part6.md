# AIChat Lesson 2: Client Abstraction Layer
## Part 6: Advanced User Features and Real-World Usage

### Interactive Features

#### REPL Environment

The REPL (Read-Eval-Print Loop) provides an interactive environment with several advanced features:

1. Multi-line Input Methods:
```bash
# Method 1: Triple colon
> :::
Write a Python function
that calculates factorial
:::

# Method 2: External editor (Ctrl+O)
> # Opens in your default editor

# Method 3: Direct paste
> # Paste multi-line text directly
```

2. Tab Completion:
```bash
# Complete commands
> .<tab>              # Shows all commands
> .mo<tab>           # Completes to .model
> .model g<tab>      # Shows all models starting with 'g'

# Complete file paths
> .file /path/to/<tab>  # File path completion
```

3. History Search:
```bash
# Press Ctrl+R to search history
> <Ctrl+R>python    # Searches for 'python' in history
> <Ctrl+R><Ctrl+R>  # Cycle through matches
```

### Web Interface Features

AIChat provides two web interfaces when running in server mode:

1. LLM Playground:
```bash
# Start server
aichat --serve

# Access playground
open http://localhost:8000/playground
```
Features:
- Model selection
- Parameter adjustment
- Real-time streaming
- History viewing
- Multi-modal input support

2. LLM Arena:
```bash
# Compare multiple models
open http://localhost:8000/arena?num=2

# Specify models
open http://localhost:8000/arena?models=gpt-4,claude-3
```

### Function Calling and Tools

1. Built-in Tools:
```bash
# Use web search
aichat --role %functions% "Search for latest Rust news"

# File system operations
aichat --role %functions% "Create a directory named 'project'"

# Execute commands
aichat --role %functions% "Show disk usage"
```

2. Shell Integration:
```bash
# Generate and execute commands
aichat -e "create a backup of my documents"

# Get command explanation
aichat -e "explain: ls -la | grep '^d'"
```

### Multi-Modal Interactions

1. Image Analysis:
```bash
# Single image analysis
aichat -f screenshot.png "What's wrong with this UI?"

# Multiple image comparison
aichat -f before.jpg -f after.jpg "What changed?"

# Image generation prompting
aichat -f reference.png "Create a prompt for a similar image"
```

2. Document Processing:
```bash
# PDF analysis
aichat -f document.pdf "Summarize this paper"

# Code review
aichat -f src/*.py "Review this Python code"

# Multi-format analysis
aichat -f spec.md -f impl.py "Is the implementation matching the spec?"
```

### Advanced Configuration Scenarios

1. Model-Specific Settings:
```yaml
clients:
  - type: openai
    models:
      - name: gpt-4
        max_input_tokens: 128000
        supports_vision: true
        supports_function_calling: true
    patch:
      chat_completions:
        'gpt-4':
          body:
            temperature: 0.7
            top_p: 0.9
```

2. RAG Configuration:
```yaml
rag_embedding_model: "text-embedding-3-large"
rag_reranker_model: "cohere-rerank-v2"
rag_top_k: 4
rag_chunk_size: 1500
rag_chunk_overlap: 200
```

### Real-World Usage Scenarios

1. Development Workflow:
```bash
# Start coding session
aichat -s coding -r developer

# Code review
aichat -f pull_request.diff "Review this PR"

# Documentation
aichat -f src/module.rs "Generate documentation"

# Testing
aichat -f src/main.rs "Write unit tests"
```

2. Document Analysis:
```bash
# Create RAG index
aichat -R docs_rag
> Add documents: ./documentation/**/*.md

# Query documentation
aichat -R docs_rag "How do I implement feature X?"

# Compare documents
aichat -R docs_rag "What changed between v1 and v2?"
```

3. Content Creation:
```bash
# Blog post writing
aichat -s blog "Write a post about Rust async"

# Technical documentation
aichat -r technical_writer -f api.yaml "Document this API"

# Report generation
aichat -f data.csv "Create a quarterly report"
```

### Automation Integration

1. Shell Scripts:
```bash
#!/bin/bash
# Automated documentation generator
for file in src/*.rs; do
    aichat -S -c -f "$file" "Generate documentation" > "docs/$(basename "$file" .rs).md"
done
```

2. CI/CD Integration:
```yaml
# GitHub Actions example
steps:
  - name: Code Review
    run: |
      aichat -S -f ${{ github.event.pull_request.diff_url }} \
        "Review this PR for security issues" > review.md
```

### Power User Features

1. Custom Prompt Templates:
```yaml
# Role definition
---
model: openai:gpt-4
temperature: 0.7
---
As an expert __DOMAIN__ developer:
1. Review the provided code
2. Identify potential issues
3. Suggest improvements
4. Provide code examples
```

2. Session Management:
```bash
# Save session state
aichat -s project --save-session

# Resume session
aichat -s project

# Compress history
aichat -s project
> .compress session
```

3. Tool Chaining:
```bash
# Combine multiple tools
aichat --role %functions% "
1. Search for best practices
2. Create a project structure
3. Initialize git repository
"
```

### Troubleshooting and Debugging

1. Debug Mode:
```bash
# Enable debug logging
export AICHAT_LOG_LEVEL=debug

# Check API interactions
tail -f ~/.config/aichat/aichat.log
```

2. Model Verification:
```bash
# Check model capabilities
aichat --info

# Test model settings
aichat --dry-run "Test message"
```

3. Configuration Testing:
```bash
# Test configuration
aichat --info | grep config_file

# Validate client settings
aichat --list-models
```

### Cross-Platform Considerations

1. Windows-Specific:
```powershell
# PowerShell integration
. .\scripts\shell-integration\integration.ps1

# File paths
aichat -f "C:\Users\Name\Documents\file.txt"
```

2. Unix-Specific:
```bash
# Shell integration
source ./scripts/shell-integration/integration.bash

# File permissions
chmod 600 ~/.config/aichat/.env
```

These advanced usage patterns demonstrate AIChat's flexibility in real-world scenarios. Users can combine different features to create powerful workflows for development, content creation, and automation tasks while maintaining security and efficiency across different platforms.

Remember that AIChat is constantly evolving, and new features may be added. Always check the latest documentation and release notes for updates and new capabilities.

Special note: In this section, we've covered mostly real-world usage patterns that build upon the basic features covered earlier. These patterns show how different features can be combined and customized for specific workflows and use cases.