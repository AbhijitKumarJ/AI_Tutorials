# End-User Guide: Understanding RAG Usage and Interaction

## Configuration Setup

Before using AIChat's RAG functionality, users need to understand the configuration system:

### Basic Configuration

The minimum configuration needed in `config.yaml`:

```yaml
# Essential RAG Settings
rag_embedding_model: "text-embedding-3-small"  # The model for creating embeddings
rag_top_k: 4                                  # Number of relevant chunks to retrieve
rag_chunk_size: 1000                          # Size of document chunks
rag_chunk_overlap: 200                        # Overlap between chunks

# Document Processing
document_loaders:
  pdf: 'pdftotext $1 -'           # PDF loader command
  docx: 'pandoc --to plain $1'    # DOCX loader command
```

### Environment Variables

Users can override configuration using environment variables:

```bash
# RAG-specific environment variables
export AICHAT_RAG_EMBEDDING_MODEL="text-embedding-3-large"
export AICHAT_RAG_TOP_K=5
export AICHAT_RAG_CHUNK_SIZE=1500
export AICHAT_RAG_CHUNK_OVERLAP=300

# Document loader paths
export AICHAT_PDFTOTEXT_PATH="/usr/local/bin/pdftotext"
export AICHAT_PANDOC_PATH="/usr/local/bin/pandoc"
```

## Working with Documents

### Supported File Types

By default, AIChat supports:
- Plain text (.txt)
- Markdown (.md)
- Source code files
- HTML files

With configured loaders:
- PDF documents
- Microsoft Word documents
- RTF files
- Other document types

### Document Organization

Best practices for organizing documents:

```
knowledge_base/
├── documentation/
│   ├── api/
│   │   ├── v1.md
│   │   └── v2.md
│   └── guides/
│       ├── getting-started.md
│       └── advanced-usage.md
├── articles/
│   ├── technical/
│   └── general/
└── references/
    ├── specifications/
    └── standards/
```

### Loading Documents

Different ways to add documents to RAG:

```bash
# Single file
> Add documents: /path/to/document.pdf

# Multiple files
> Add documents: doc1.pdf;doc2.md;doc3.txt

# Directory with file type filter
> Add documents: ./docs/**/*.{md,txt}

# URL loading
> Add documents: https://example.com/documentation.html

# Recursive website crawling
> Add documents: https://docs.example.com/**
```

## RAG Interaction Methods

### Basic Query Flow

Standard question-answer interaction:

```bash
> .rag my_knowledge_base
✓ RAG initialized successfully

> How do I implement feature X?
🔍 Searching knowledge base...
Based on the documentation, feature X can be implemented by...
```

### Advanced Query Techniques

1. Multi-context queries:
```bash
> Compare the implementation of feature X in v1 and v2
🔍 Searching across versions...
Analyzing differences...
```

2. Specific document targeting:
```bash
> What does the API documentation say about rate limiting?
🔍 Focusing on API documentation...
According to the API docs...
```

3. Time-based queries:
```bash
> What were the major changes in the last update?
🔍 Analyzing recent documentation changes...
The recent updates include...
```

### Managing Search Results

Users can control search behavior:

```bash
# Adjust result count
> .set rag_top_k 6

# Set minimum relevance scores
> .set rag_min_score_vector_search 0.7
> .set rag_min_score_keyword_search 0.5

# View source documents
> .sources rag
```

## Troubleshooting Common Issues

### Document Loading Problems

1. PDF Loading Issues:
```bash
# Check PDF loader configuration
> .info rag
Document Loaders:
  pdf: pdftotext not found

# Solution: Install pdftotext
$ sudo apt-get install poppler-utils  # Ubuntu/Debian
$ brew install poppler               # macOS
```

2. Encoding Problems:
```bash
# Check file encoding
$ file -i document.txt
# Convert to UTF-8 if needed
$ iconv -f ISO-8859-1 -t UTF-8 document.txt > document_utf8.txt
```

### Search Quality Issues

1. Poor Search Results:
```bash
# View search parameters
> .info rag
Chunk Size: 1000
Overlap: 200
Top K: 4

# Adjust parameters for better results
> .set rag_chunk_size 500
> .set rag_chunk_overlap 100
> .set rag_top_k 6
```

2. Irrelevant Results:
```bash
# Check source documents
> .sources rag

# Rebuild index if needed
> .rebuild rag
```

## Performance Optimization

### Memory Usage

Tips for managing memory usage:

```bash
# Check current memory usage
> .info rag
Total Vectors: 1000
Memory Usage: 500MB

# Optimize by adjusting chunk size
> .set rag_chunk_size 1500
```

### Search Speed

Improving search performance:

```bash
# Enable reranking for better results
> .set rag_reranker_model "cohere-rerank-v2-0"

# Adjust vector search parameters
> .set rag_min_score_vector_search 0.6
```

## Advanced Usage Scenarios

### Multi-Language Support

Working with multiple languages:

```bash
# Load multilingual documents
> Add documents: docs/{en,es,fr}/**/*.md

# Query in different languages
> ¿Cómo implemento la característica X?
> Comment puis-je implémenter la fonctionnalité X?
```

### Custom Document Processing

Using custom document processors:

```yaml
# config.yaml
document_loaders:
  custom: './process_doc.sh $1'
```

```bash
# process_doc.sh
#!/bin/bash
input_file=$1
# Custom processing logic
```

### Integration with External Tools

Using RAG with other tools:

```bash
# Export search results
> .sources rag > search_results.txt

# Process results with external tools
$ grep "API" search_results.txt | sort -u
```

## Best Practices

### Document Preparation

1. Content Organization:
   - Use clear directory structures
   - Maintain consistent file naming
   - Keep related documents together

2. Document Quality:
   - Clean and format documents
   - Remove irrelevant content
   - Ensure consistent encoding

### Query Formulation

1. Be Specific:
```bash
❌ "How does it work?"
✅ "How does the authentication system work in the v2 API?"
```

2. Use Context:
```bash
❌ "What are the limits?"
✅ "What are the rate limits for authenticated API users?"
```

3. Iterative Refinement:
```bash
# Start broad
> What security features are available?

# Then narrow down
> How is JWT authentication implemented?

# Get specific details
> What is the JWT token expiration policy?
```

These usage details and best practices help users effectively interact with AIChat's RAG system while avoiding common pitfalls and optimizing their experience.