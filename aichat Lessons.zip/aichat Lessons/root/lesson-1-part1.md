# AIChat Lesson 1: Foundation and Core Structure (Part 1)

## Introduction

AIChat is an all-in-one LLM CLI tool featuring Shell Assistant, Chat-REPL, RAG, AI Tools & Agents. This first lesson explores the foundational structure of AIChat, focusing on how the project is organized and how its core components interact. Understanding these foundational elements is crucial for anyone wanting to contribute to or extend the project.

## Project Layout

The core structure of AIChat follows a well-organized layout:

```
src/
├── cli.rs               # Command-line interface definitions
├── function.rs          # Function calling system
├── main.rs             # Application entry point
├── serve.rs            # HTTP server implementation
├── client/             # LLM providers implementations
│   ├── access_token.rs
│   ├── azure_openai.rs
│   ├── bedrock.rs
│   ├── claude.rs
│   ├── cohere.rs
│   └── ...
├── config/             # Configuration management
│   ├── agent.rs
│   ├── input.rs
│   ├── mod.rs
│   ├── role.rs
│   └── session.rs
├── rag/                # Document retrieval system
├── render/             # Output rendering
├── repl/              # Interactive shell
└── utils/             # Utility functions
```

## Core Module Architecture

### Main Entry Point (main.rs)

The heart of AIChat begins in main.rs, which serves as the application's entry point. The main function is annotated with `#[tokio::main]`, indicating this is an async application built on the Tokio runtime. The entry point handles several critical responsibilities:

1. Command-line argument parsing using clap
2. Environment setup including logger initialization
3. Configuration loading and validation
4. Execution mode determination 

Here's how the execution mode is determined:

```rust
let working_mode = if cli.serve.is_some() {
    WorkingMode::Serve
} else if text.is_none() && cli.file.is_empty() {
    WorkingMode::Repl
} else {
    WorkingMode::Cmd
};
```

### Configuration System (config/)

The configuration system is implemented in the config/ directory, with mod.rs serving as the central configuration store. The system follows a hierarchical structure where configurations can be loaded from multiple sources with a clear precedence order:

1. Command-line arguments
2. Environment variables  
3. Configuration files
4. Default values

The Config struct serves as the central configuration store:

```rust
pub struct Config {
    pub model_id: String,
    pub temperature: Option<f64>,
    pub top_p: Option<f64>,
    pub dry_run: bool,
    pub stream: bool,
    pub save: bool,
    // ... additional fields
}
```

### CLI Argument System (cli.rs)

The CLI system provides a robust interface for interacting with AIChat through command line arguments. Key features include:

1. Model selection (`-m`, `--model`)
2. Role selection (`-r`, `--role`)
3. Session management (`-s`, `--session`) 
4. Agent interaction (`-a`, `--agent`)
5. RAG functionality (`-R`, `--rag`)
6. Execution modes (`-e`, `--execute`)
7. Stream control (`-S`, `--no-stream`)

Example usage:
```sh
aichat                                          # Enter REPL
aichat Tell a joke                              # Generate response
aichat -e install nvim                          # Execute command
aichat -c fibonacci in js                       # Generate code
aichat -m openai:gpt-4o                         # Select LLM
aichat -r role1                                 # Use role 'role1'
aichat -s                                       # Begin a temp session
```

### Function Management (function.rs)

The function.rs module implements the infrastructure for function calling capabilities including:

1. Tool call evaluation and deduplication
2. Function declaration management  
3. Cross-platform command execution
4. Security considerations

The module demonstrates advanced Rust patterns like:

```rust
#[derive(Debug, Clone)]
pub struct FunctionDeclaration {
    pub name: String,
    pub description: String,
    pub parameters: JsonSchema,
    pub agent: bool,
}
```

### HTTP Server (serve.rs)

The serve.rs module provides a built-in HTTP server with capabilities for:

1. Chat completions API endpoint
2. Embeddings API endpoint
3. WebSocket handling for streaming
4. Static file serving

To start the server:

```sh
$ aichat --serve
Chat Completions API: http://127.0.0.1:8000/v1/chat/completions
Embeddings API:       http://127.0.0.1:8000/v1/embeddings
LLM Playground:       http://127.0.0.1:8000/playground
LLM Arena:            http://127.0.0.1:8000/arena?num=2
```

## Cross-Platform Considerations 

The codebase implements several strategies to ensure cross-platform compatibility:

### Path Handling
```rust
#[cfg(windows)]
const PATH_SEP: &str = ";";
#[cfg(not(windows))]
const PATH_SEP: &str = ":";
```

### Configuration Directories
```rust
pub fn config_dir() -> PathBuf {
    if let Ok(v) = env::var(get_env_name("config_dir")) {
        PathBuf::from(v)
    } else if let Ok(v) = env::var("XDG_CONFIG_HOME") {
        PathBuf::from(v).join(env!("CARGO_CRATE_NAME"))
    } else {
        dirs::config_dir()
            .expect("No user's config directory")
            .join(env!("CARGO_CRATE_NAME"))
    }
}
```

### Terminal Detection
```rust
#[cfg(target_os = "macos")]
fn is_terminal() -> bool {
    // macOS specific implementation
}

#[cfg(unix)]
fn is_terminal() -> bool {
    // Unix specific implementation  
}

#[cfg(windows)] 
fn is_terminal() -> bool {
    // Windows specific implementation
}
```
