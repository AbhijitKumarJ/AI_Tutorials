# AIChat Lesson 5: Understanding AIChat's RAG Implementation - Part 1

## Introduction to AIChat's RAG Implementation

AIChat implements a sophisticated Retrieval-Augmented Generation (RAG) system that enhances Large Language Model (LLM) capabilities by incorporating knowledge from external documents. This lesson explores the comprehensive RAG implementation, its architecture, and practical usage within AIChat.

## Project Structure

The RAG system's implementation is organized across multiple directories and files, with the core components residing in the following structure:

```
src/
├── rag/
│   ├── loader.rs       # Document loading and processing
│   ├── mod.rs         # Core RAG implementation
│   ├── serde_vectors.rs # Vector serialization utilities
│   └── splitter/
│       ├── language.rs # Language-specific splitting rules
│       └── mod.rs     # Text splitting implementation
├── config/
│   └── ...           # Configuration related files
└── utils/
    └── ...           # Utility functions and helpers
```

## Core Architecture

At the heart of AIChat's RAG system lies the `Rag` struct, which serves as the central orchestrator for all RAG-related operations. This structure encapsulates the essential components needed for document processing, embedding generation, and search functionality:

```rust
pub struct Rag {
    config: GlobalConfig,
    name: String,
    path: String,
    embedding_model: Model,
    hnsw: Hnsw<'static, f32, DistCosine>,
    bm25: SearchEngine<DocumentId>,
    data: RagData,
    last_sources: RwLock<Option<String>>,
}
```

The architecture implements a hybrid search approach combining vector similarity search through HNSW (Hierarchical Navigable Small World) and traditional keyword-based search using BM25. This dual approach ensures both semantic and lexical matching capabilities.

## Configuration System

AIChat's RAG system is highly configurable through a YAML configuration file. The key RAG-specific configuration options include:

```yaml
# RAG Configuration
rag_embedding_model: null       # Specifies the embedding model to use
rag_reranker_model: null       # Specifies the rerank model to use
rag_top_k: 4                   # Specifies the number of documents to retrieve
rag_chunk_size: null           # Specifies the chunk size
rag_chunk_overlap: null        # Specifies the chunk overlap
rag_min_score_vector_search: 0 # Minimum relevance score for vector-based searching
rag_min_score_keyword_search: 0 # Minimum relevance score for keyword-based searching
```

Additionally, document loaders can be configured to handle various file formats:

```yaml
document_loaders:
  pdf: 'pdftotext $1 -'        # Load .pdf file, requires pdftotext
  docx: 'pandoc --to plain $1' # Load .docx file, requires pandoc
```

## Document Processing Pipeline

The document processing pipeline in AIChat's RAG system consists of several sophisticated stages:

### 1. Document Loading

The document loader system supports multiple input sources and formats:

- Local files (PDF, DOCX, Markdown, etc.)
- Remote URLs and web pages
- Directory structures with glob pattern support
- Custom document loaders for specific file formats

Each document is loaded through the `load_document` function:

```rust
pub async fn load_document(
    loaders: &HashMap<String, String>,
    path: &str,
    has_error: &mut bool,
) -> (String, Vec<(String, RagMetadata)>)
```

### 2. Text Splitting

The text splitting system employs a recursive character-based approach through the `RecursiveCharacterTextSplitter`:

```rust
pub struct RecursiveCharacterTextSplitter {
    pub chunk_size: usize,
    pub chunk_overlap: usize,
    pub separators: Vec<String>,
    pub length_function: Box<dyn Fn(&str) -> usize + Send + Sync>,
}
```

This system provides:
- Configurable chunk sizes and overlap settings
- Language-specific splitting rules
- Intelligent separation based on document structure
- Preservation of document metadata

### 3. Vector Storage

The vector storage system is implemented through the `RagData` structure, which maintains:
- Document metadata and mappings
- Embedding vectors
- Search indices
- Serialization capabilities

## Usage Examples

Here are practical examples of using AIChat's RAG system:

1. Initializing a new RAG:
```bash
> .rag
⚙ Initializing RAG...
Select embedding model: text-embedding-3-small
Set chunk size: 1000
Set chunk overlay: 50
Add documents: /path/to/documents/**/*.md
```

2. Using RAG in a conversation:
```bash
> .rag my_knowledge_base
Loading knowledge base...
✓ Ready to answer questions based on the loaded documents
```

3. Querying with RAG:
```bash
> What information is available about feature X?
Searching knowledge base...
Based on the documents, feature X ...
```

This covers the first part of our deep dive into AIChat's RAG system. Part 2 will continue with advanced features, search implementation details, and best practices.