# AIChat Lesson 3: Configuration and State Management - Part 1
## Core Concepts and Architecture 

### File Structure

The configuration and state management system in AIChat is organized across multiple files in the `config` directory:

```
src/config/
├── mod.rs           # Main configuration module with core implementation
├── agent.rs         # Agent-specific configuration handling
├── input.rs         # Input processing and management
├── role.rs          # Role-based configuration
└── session.rs       # Session state management 
```

### Core Configuration Architecture

The configuration system in AIChat follows a layered architecture that provides flexibility while maintaining strict control over state. At its heart is the `Config` struct defined in `mod.rs`, which serves as the central configuration store and manages:

- Model selection and parameters
- Runtime behaviors and flags
- User preferences
- Feature toggles
- State tracking
- File paths and persistence

One of the key design choices is the use of a thread-safe global configuration through the `GlobalConfig` type:

```rust
pub type GlobalConfig = Arc<RwLock<Config>>;
```

This allows for safe concurrent access while providing atomic state updates across the application.

### Configuration Sources and Precedence

AIChat implements a sophisticated configuration loading system with clear precedence rules:

1. Command-line arguments (highest priority)
2. Environment variables 
3. Configuration files
4. Default values (lowest priority)

The configuration file is typically located at:
- Linux: `~/.config/aichat/config.yaml`
- macOS: `~/Library/Application Support/aichat/config.yaml` 
- Windows: `C:\Users\<User>\AppData\Roaming\aichat\config.yaml`

The system supports dynamic configuration through environment variables following a consistent naming pattern:
```rust
pub fn get_env_name(key: &str) -> String {
    format!("{}_{}", env!("CARGO_CRATE_NAME"), key).to_ascii_uppercase()
}
```

### State Management Overview

AIChat maintains several types of state:

1. Global State
   - Model configuration
   - Runtime flags
   - Feature toggles
   - User preferences

2. Session State
   - Conversation history
   - Message tracking
   - Token usage
   - Compression state

3. Role State
   - Model parameters
   - Temperature settings
   - Prompt templates
   - Tool configurations

4. Agent State
   - Tool configurations
   - Variable states
   - Document contexts
   - Function permissions

The state management system is designed around the following principles:

1. State Isolation: Different types of state are kept separate to prevent interference and maintain clean boundaries between features.

2. State Synchronization: Changes to state are propagated appropriately between components when needed:
```rust
impl Config {
    pub fn sync(&mut self, other: &Config) {
        self.model = other.model.clone();
        self.temperature = other.temperature;
        self.top_p = other.top_p;
        // Additional synchronization
    }
}
```

3. State Persistence: The system handles saving and loading state appropriately, with clear rules about what should be persisted and when.

4. State Access Control: The use of RwLock ensures thread-safe access to global state:
```rust
pub type GlobalConfig = Arc<RwLock<Config>>;
```

### Core Configuration Fields

Some of the key configuration fields managed by the system include:

```rust
pub struct Config {
    // Model Configuration
    pub model_id: String,
    pub temperature: Option<f64>,
    pub top_p: Option<f64>,

    // Runtime Behavior
    pub dry_run: bool,
    pub stream: bool,
    pub save: bool,

    // User Interface
    pub keybindings: String,
    pub editor: Option<String>,
    pub wrap: Option<String>,

    // Feature Toggles
    pub function_calling: bool,
    pub highlight: bool,

    // State Tracking
    pub role: Option<Role>,
    pub session: Option<Session>,
    pub rag: Option<Arc<Rag>>,
    pub agent: Option<Agent>,
}
```

### Error Handling Philosophy

The configuration system implements comprehensive error handling using Rust's Result type:

```rust
pub fn init(working_mode: WorkingMode) -> Result<Self> {
    let config_path = Self::config_file();
    let mut config = if !config_path.exists() {
        match env::var(get_env_name("platform")) {
            Ok(v) => Self::load_dynamic(&v)?,
            Err(_) => {
                if *IS_STDOUT_TERMINAL {
                    create_config_file(&config_path)?;
                }
                Self::load_from_file(&config_path)?
            }
        }
    } else {
        Self::load_from_file(&config_path)?
    };
    // Configuration initialization
    Ok(config)
}
```

This ensures that configuration errors are caught early and handled appropriately.

### Understanding State Flags

The system uses bitflags to track different states:

```rust
bitflags::bitflags! {
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    pub struct StateFlags: u32 {
        const ROLE = 1 << 0;
        const SESSION_EMPTY = 1 << 1;
        const SESSION = 1 << 2;
        const RAG = 1 << 3;
        const AGENT = 1 << 4;
    }
}
```

This allows for efficient state tracking and comparison operations throughout the application.

In the next part, we'll dive deeper into the implementation details of sessions and roles, showing how they integrate with this core architecture.