# Part 6: Web Integration and Advanced Topics

## Introduction

AIChat provides sophisticated web-based interfaces through two main components - the Arena for model comparison and the Playground for interactive testing. Let's explore the architecture and implementation details of these web components.

## Project Structure

The web components are organized in the assets directory:

```
assets/
├── arena.html       # Model comparison interface
└── playground.html  # Interactive testing interface
```

## Core Architecture

### HTML Structure

The web interfaces follow a modular structure:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- External Dependencies -->
    <link rel="stylesheet" href="//unpkg.com/github-markdown-css@5.5.1/github-markdown.css">
    <link rel="stylesheet" href="//unpkg.com/highlight.js@11.9.0/styles/github-dark.min.css">
    <script src="//unpkg.com/marked@12.0.2/lib/marked.umd.js" defer></script>
    <script src="//unpkg.com/alpinejs@3.13.10/dist/cdn.min.js" defer></script>
</head>
<body>
    <!-- Alpine.js-powered application container -->
    <div class="container" x-data="app">
        <!-- Application content -->
    </div>
</body>
</html>
```

### CSS Architecture

The CSS follows a modular and responsive design approach:

```css
:root {
    /* Theme Variables */
    --fg-primary: #1652f1;
    --fg-default: black;
    --bg-primary: white;
    --bg-default: #f9f9f9;
    --border-primary: #c3c3c3;
}

/* Dark Mode Support */
@media (prefers-color-scheme: dark) {
    :root {
        --fg-primary: #1652f1;
        --fg-default: white;
        --bg-primary: black;
        --bg-default: #121212;
        --border-primary: #3c3c3c;
    }
}

/* Responsive Design */
@media screen and (max-width: 768px) {
    body {
        height: calc(100vh - 56px);
        height: 100dvh;
    }
    
    .container {
        padding: 3px;
    }
}
```

### JavaScript Framework Integration

AIChat uses Alpine.js for reactive data management and UI updates:

```javascript
document.addEventListener("alpine:init", () => {
    Alpine.data("app", () => ({
        // State Management
        models: [],
        input: "",
        images: [],
        asking: false,
        messages: [],
        
        // Lifecycle Methods
        async init() {
            await this.loadModels();
            this.setupEventListeners();
            this.initializeState();
        },
        
        // API Integration
        async loadModels() {
            try {
                const response = await fetch(MODELS_API);
                this.models = await response.json();
            } catch (err) {
                this.handleError(err);
            }
        },
        
        // Event Handlers
        handleSubmit() {
            if (this.validateInput()) {
                this.sendMessage();
            }
        }
    }));
});
```

## Interactive Features

### Message Streaming 

The system implements sophisticated message streaming:

```javascript
async function* fetchChatCompletions(url, body, signal) {
    const stream = body.stream;
    const response = await fetch(url, {
        method: "POST",
        signal,
        headers: getHeaders(),
        body: JSON.stringify(body),
    });

    if (!response.ok) {
        throw await response.json();
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let remainingChunk = "";

    while (true) {
        const {value, done} = await reader.read();
        if (done) break;
        
        const chunk = decoder.decode(value);
        const lines = (remainingChunk + chunk).split("\n");
        
        for (const line of lines) {
            if (line.startsWith("data: ")) {
                yield JSON.parse(line.slice(5));
            }
        }
    }
}
```

### File Handling

Support for file uploads and processing:

```javascript
async handleImageUpload(event) {
    const files = event.target.files;
    if (!files?.length) return;
    
    const urls = await Promise.all(
        Array.from(files).map(file => this.convertToDataURL(file))
    );
    
    this.images.push(...urls);
    event.target.value = "";
},

async convertToDataURL(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = e => resolve(e.target.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}
```

### Markdown Processing

Integration with the Marked library for Markdown rendering:

```javascript
function setupMarked() {
    const renderer = new marked.Renderer();
    
    // Custom code block rendering
    renderer.code = (code, language) => {
        const highlighted = hljs.highlight(code, {language}).value;
        
        return `
            <div class="code-block">
                <pre><code class="hljs ${language}">${highlighted}</code></pre>
                <div class="copy-code-btn" @click="handleCopyCode">
                    <svg>...</svg>
                </div>
            </div>
        `;
    };
    
    marked.setOptions({renderer});
}
```

## Cross-Browser Compatibility

### Feature Detection

The system implements careful feature detection:

```javascript
const CAPABILITIES = {
    streamingSupported: 'ReadableStream' in window,
    clipboardSupported: 'clipboard' in navigator,
    speechSynthesisSupported: 'speechSynthesis' in window
};

// Usage
if (CAPABILITIES.streamingSupported) {
    // Implement streaming
} else {
    // Fallback to polling
}
```

### Legacy Browser Support

Polyfills and fallbacks for older browsers:

```javascript
// Fetch API polyfill
if (!window.fetch) {
    window.fetch = function(url, options) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open(options.method || 'GET', url);
            // ... XHR setup
            xhr.send(options.body);
        });
    };
}

// Event source polyfill
if (!window.EventSource) {
    class PolyfillEventSource {
        constructor(url) {
            this.url = url;
            this.polling = null;
            // ... implementation
        }
    }
    window.EventSource = PolyfillEventSource;
}
```

### Mobile Device Support

Responsive design considerations:

```javascript
// Touch event handling
const touchHandler = {
    start(e) {
        const touch = e.touches[0];
        this.startX = touch.clientX;
        this.startY = touch.clientY;
    },
    
    move(e) {
        if (!this.startX || !this.startY) return;
        
        const touch = e.touches[0];
        const deltaX = this.startX - touch.clientX;
        const deltaY = this.startY - touch.clientY;
        
        // Handle touch movement
        if (Math.abs(deltaX) > Math.abs(deltaY)) {
            e.preventDefault(); // Prevent horizontal scroll
        }
    }
};
```

## Advanced Topics

### State Management

Complex state handling with Alpine.js:

```javascript
Alpine.store('chat', {
    history: [],
    templates: {},
    preferences: {},
    
    addMessage(message) {
        this.history.push({
            ...message,
            timestamp: Date.now()
        });
        this.persist();
    },
    
    async persist() {
        try {
            localStorage.setItem('chat_history', 
                JSON.stringify(this.history)
            );
        } catch (err) {
            console.error('Failed to persist chat history:', err);
        }
    }
});
```

### Error Recovery

Sophisticated error handling and recovery:

```javascript
async function withErrorHandling(operation) {
    try {
        return await operation();
    } catch (err) {
        if (err.name === 'AbortError') {
            // Handle user cancellation
            return { cancelled: true };
        }
        
        if (err.status === 429) {
            // Handle rate limiting
            await sleep(1000);
            return await withErrorHandling(operation);
        }
        
        // Handle other errors
        throw err;
    }
}
```

### Performance Optimization

Techniques for optimal performance:

```javascript
// Message batching
const messageQueue = [];
let flushTimeout;

function queueMessage(message) {
    messageQueue.push(message);
    
    if (!flushTimeout) {
        flushTimeout = setTimeout(flushMessages, 100);
    }
}

async function flushMessages() {
    flushTimeout = null;
    if (!messageQueue.length) return;
    
    const batch = messageQueue.splice(0);
    await processMessageBatch(batch);
}
```

## Conclusion

AIChat's web integration demonstrates sophisticated frontend architecture while maintaining cross-browser compatibility and performance. The combination of modern frameworks like Alpine.js with careful feature detection and fallbacks ensures a robust user experience across different platforms and browsers.

The system's modular design allows for:
- Easy feature additions
- Consistent styling
- Responsive layouts
- Graceful degradation
- Efficient state management

Understanding these web components is crucial for:
- Extending the web interfaces
- Adding new features
- Maintaining cross-browser support
- Optimizing performance
- Ensuring accessibility