# AIChat Lesson 2: Client Abstraction Layer
## Part 3: Core Concepts and Implementation Details

### Foundation Concepts

#### Async Programming in Rust

The client abstraction layer makes extensive use of Rust's async/await syntax for handling asynchronous operations:

```rust
#[async_trait::async_trait]
pub trait Client: Sync + Send {
    async fn chat_completions(&self, input: Input) -> Result<ChatCompletionsOutput>;
    async fn embeddings(&self, data: &EmbeddingsData) -> Result<Vec<Vec<f32>>>;
}
```

The `async_trait` attribute is necessary because Rust doesn't natively support async functions in traits. This setup enables:
- Non-blocking I/O operations
- Efficient resource utilization
- Clean handling of concurrent requests

#### Token Management

Token management is crucial for LLM interactions. Tokens are the basic units that LLMs process:

```rust
pub struct Model {
    pub fn messages_tokens(&self, messages: &[Message]) -> usize {
        messages
            .iter()
            .map(|v| match &v.content {
                MessageContent::Text(text) => estimate_token_length(text),
                MessageContent::Array(_) => 0,
                MessageContent::ToolResults(_) => 0,
            })
            .sum()
    }
    
    pub fn guard_max_input_tokens(&self, messages: &[Message]) -> Result<()> {
        if let Some(max_tokens) = self.max_input_tokens() {
            let total = self.total_tokens(messages);
            if total > max_tokens {
                bail!(
                    "Input too long: {} tokens. Maximum is {} tokens.",
                    total,
                    max_tokens
                );
            }
        }
        Ok(())
    }
}
```

Key aspects include:
1. Token counting for rate limiting
2. Token estimation for cost calculation
3. Message compression for token limits
4. Token budget management

### Stream Processing Details

#### Event Stream Handling

The Server-Sent Events (SSE) implementation includes sophisticated handling of streaming responses:

```rust
pub struct JsonStreamParser {
    buffer: Vec<char>,
    cursor: usize,
    start: Option<usize>,
    balances: Vec<char>,
    quoting: bool,
    escape: bool,
}

impl JsonStreamParser {
    fn process<F>(&mut self, text: &str, handle: &mut F) -> Result<()>
    where
        F: FnMut(&str) -> Result<()> {
        for c in text.chars() {
            self.buffer.push(c);
            
            match c {
                '{' => self.balances.push(c),
                '}' => {
                    if let Some('{') = self.balances.last() {
                        self.balances.pop();
                        if self.balances.is_empty() {
                            let json = self.buffer[self.start.unwrap()..].iter().collect::<String>();
                            handle(&json)?;
                            self.start = None;
                        }
                    }
                }
                _ => {}
            }
        }
        Ok(())
    }
}
```

This parser handles:
1. Partial JSON messages
2. Proper escaping
3. Nested structures
4. Error recovery

#### Abort Signal Mechanism

The abort signal system provides graceful cancellation capabilities:

```rust
pub struct AbortSignalInner {
    ctrlc: AtomicBool,
    ctrld: AtomicBool,
}

impl AbortSignal {
    pub fn abort(&self) {
        self.0.ctrlc.store(true, Ordering::SeqCst);
    }

    pub fn aborted(&self) -> bool {
        self.0.ctrlc.load(Ordering::SeqCst) ||
        self.0.ctrld.load(Ordering::SeqCst)
    }
}
```

### Authentication and Authorization

#### Access Token Management

The system includes sophisticated token management:

```rust
lazy_static::lazy_static! {
    static ref ACCESS_TOKENS: RwLock<IndexMap<String, (String, i64)>> =
        RwLock::new(IndexMap::new());
}

pub fn set_access_token(client_name: &str, token: String, expires_at: i64) {
    let mut access_tokens = ACCESS_TOKENS.write().unwrap();
    access_tokens.insert(client_name.to_string(), (token, expires_at));
}

pub fn get_access_token(client_name: &str) -> Option<String> {
    let tokens = ACCESS_TOKENS.read().unwrap();
    tokens
        .get(client_name)
        .filter(|(_, expires_at)| *expires_at > chrono::Utc::now().timestamp())
        .map(|(token, _)| token.clone())
}
```

Features include:
1. Token caching
2. Expiration handling
3. Thread-safe access
4. Automatic renewal

### Advanced Configuration Features

#### Request Patching

The request patching system allows modification of API requests:

```rust
pub struct RequestPatch {
    pub chat_completions: Option<ApiPatch>,
    pub embeddings: Option<ApiPatch>,
    pub rerank: Option<ApiPatch>,
}

impl RequestData {
    pub fn apply_patch(&mut self, patch: Value) {
        if let Some(patch_url) = patch["url"].as_str() {
            self.url = patch_url.into();
        }
        if let Some(patch_body) = patch.get("body") {
            json_patch::merge(&mut self.body, patch_body);
        }
        if let Some(patch_headers) = patch.get("headers") {
            for (key, value) in patch_headers.as_object().unwrap() {
                self.headers.insert(
                    key.clone(),
                    value.as_str().unwrap().to_string(),
                );
            }
        }
    }
}
```

This system enables:
1. URL modification
2. Header injection
3. Body transformation
4. Per-model customization

### Error Handling Depth

#### Error Context Chain

The error handling system maintains error context:

```rust
pub fn catch_error(data: &Value, status: u16) -> Result<()> {
    if let Some(error) = data["error"].as_object() {
        if let (Some(typ), Some(message)) = (
            json_str_from_map(error, "type"),
            json_str_from_map(error, "message"),
        ) {
            bail!("{message} (type: {typ})");
        }
    }
    
    if status > 499 {
        bail!("Server error: HTTP {status}");
    } else if status > 399 {
        bail!("Client error: HTTP {status}");
    } else if status < 200 || status > 299 {
        bail!("Unexpected status code: {status}");
    }
    
    Ok(())
}
```

Features include:
1. Status code mapping
2. Error type preservation
3. Provider-specific error handling
4. Error context propagation

### Cross-Platform Details

#### Platform-Specific Paths

```rust
#[cfg(not(windows))]
fn default_adc_file() -> Option<PathBuf> {
    let mut path = dirs::home_dir()?;
    path.push(".config");
    path.push("gcloud");
    path.push("application_default_credentials.json");
    Some(path)
}

#[cfg(windows)]
fn default_adc_file() -> Option<PathBuf> {
    let mut path = dirs::config_dir()?;
    path.push("gcloud");
    path.push("application_default_credentials.json");
    Some(path)
}
```

#### Network Handling

```rust
fn set_proxy(
    builder: reqwest::ClientBuilder,
    proxy: Option<&String>,
) -> Result<reqwest::ClientBuilder> {
    let proxy = if let Some(proxy) = proxy {
        if proxy.is_empty() || proxy == "-" {
            return Ok(builder);
        }
        proxy.clone()
    } else if let Some(proxy) = ["HTTPS_PROXY", "https_proxy", "ALL_PROXY", "all_proxy"]
        .into_iter()
        .find_map(|v| env::var(v).ok())
    {
        proxy
    } else {
        return Ok(builder);
    };
    
    Ok(builder.proxy(reqwest::Proxy::all(&proxy)?))
}
```

### Model Management Details

The system implements comprehensive model management:

```rust
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModelData {
    pub name: String,
    pub model_type: String,
    pub max_input_tokens: Option<usize>,
    pub input_price: Option<f64>,
    pub output_price: Option<f64>,
    pub max_output_tokens: Option<isize>,
    pub require_max_tokens: bool,
    pub supports_vision: bool,
    pub supports_function_calling: bool,
    pub no_stream: bool,
    pub no_system_message: bool,
    pub max_tokens_per_chunk: Option<usize>,
    pub default_chunk_size: Option<usize>,
    pub max_batch_size: Option<usize>,
}
```

This handles:
1. Token limits
2. Pricing information
3. Feature support
4. Batch processing
5. Model constraints

### Testing Considerations

#### Mocking Complex Responses

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[tokio::test]
    async fn test_stream_parsing() {
        let chunks = vec![
            Ok(Bytes::from(r#"{"id":"1","choices":[{"delta":{"content":"Hello"}}]}"#)),
            Ok(Bytes::from(r#"{"id":"1","choices":[{"delta":{"content":" World"}}]}"#)),
        ];
        
        let stream = stream::iter(chunks);
        let mut output = String::new();
        
        json_stream(stream, |data| {
            let parsed: Value = serde_json::from_str(data)?;
            if let Some(content) = parsed["choices"][0]["delta"]["content"].as_str() {
                output.push_str(content);
            }
            Ok(())
        })
        .await
        .unwrap();
        
        assert_eq!(output, "Hello World");
    }
}
```

The testing system demonstrates:
1. Stream simulation
2. Async testing
3. Error handling testing
4. Response validation

### Conclusion

The client abstraction layer in AIChat demonstrates sophisticated handling of:
- Multi-platform support
- Streaming responses
- Error management
- Cross-platform compatibility
- Authentication
- Configuration
- Testing

This robust foundation enables AIChat to reliably interact with a wide range of LLM providers while maintaining consistent behavior and error handling across different platforms and environments.