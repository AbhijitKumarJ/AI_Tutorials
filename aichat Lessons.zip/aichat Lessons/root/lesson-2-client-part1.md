# AIChat Lesson 2: Client Abstraction Layer 
## Part 1: Multi-Platform Integration and Core Architecture

### Introduction

AIChat's client abstraction layer serves as a sophisticated bridge between the application and various Large Language Model (LLM) providers. This lesson explores the implementation details, architectural decisions, and best practices used in AIChat's client layer.

### Directory Structure

The client abstraction layer is organized in a modular structure within the `src/client` directory:

```
src/client/
├── access_token.rs     # Token management and auth
├── azure_openai.rs     # Azure OpenAI implementation
├── bedrock.rs         # AWS Bedrock API integration
├── claude.rs          # Anthropic Claude API
├── cohere.rs         # Cohere API implementation
├── common.rs         # Shared interfaces and utilities
├── ernie.rs          # Baidu ERNIE API 
├── gemini.rs         # Google Gemini API
├── macros.rs         # Shared macros for clients
├── message.rs        # Message handling
├── mod.rs           # Module definitions
├── model.rs         # Model management
├── openai.rs        # OpenAI API implementation
├── openai_compatible.rs  # OpenAI-compatible APIs
├── stream.rs       # Streaming response handling
└── vertexai.rs    # Google VertexAI API
```

### Core Client Architecture 

The heart of the client layer is the `Client` trait defined in `common.rs`:

```rust
#[async_trait::async_trait]
pub trait Client: Sync + Send {
    fn global_config(&self) -> &GlobalConfig;
    fn extra_config(&self) -> Option<&ExtraConfig>;
    fn patch_config(&self) -> Option<&RequestPatch>;
    fn name(&self) -> &str;
    fn model(&self) -> &Model;
    fn model_mut(&mut self) -> &mut Model;

    async fn chat_completions(&self, input: Input) -> Result<ChatCompletionsOutput>;
    async fn chat_completions_streaming(&self, input: &Input, handler: &mut SseHandler) -> Result<()>;
    async fn embeddings(&self, data: &EmbeddingsData) -> Result<Vec<Vec<f32>>>;
    async fn rerank(&self, data: &RerankData) -> Result<RerankOutput>;
}
```

This trait enforces a consistent interface across all LLM providers while allowing for provider-specific implementations. The design follows several key principles:

1. **Async First**: All operations that may involve network calls are asynchronous, leveraging Rust's async/await syntax.
2. **Error Handling**: Comprehensive error handling using Rust's Result type with anyhow for flexible error types.
3. **Configuration Management**: Structured handling of global and provider-specific settings.
4. **Type Safety**: Strong typing for all operations while maintaining flexibility.

### Message Handling System

The message handling system in `message.rs` provides a robust way to handle different types of messages:

```rust
pub struct Message {
    pub role: MessageRole,
    pub content: MessageContent,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(untagged)]
pub enum MessageContent {
    Text(String),
    Array(Vec<MessageContentPart>),
    ToolResults(ToolResults),
}
```

This system supports:
- Plain text messages
- Multi-modal content (text + images)
- Tool results from function calling
- System messages and role-based content

### Model Management 

The model system in `model.rs` provides sophisticated handling of different LLM capabilities and configurations:

```rust
pub struct Model {
    client_name: String,
    data: ModelData,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModelData {
    pub name: String,
    pub model_type: String,
    pub max_input_tokens: Option<usize>,
    pub input_price: Option<f64>,
    pub output_price: Option<f64>,
    pub supports_vision: bool,
    pub supports_function_calling: bool,
}
```

Key features include:
- Token limit management
- Pricing information
- Capability detection (vision, function calling)
- Cross-platform model compatibility

### Configuration System

The client layer implements a sophisticated configuration system that supports:

1. Global Settings:
```yaml
model: openai:gpt-4o             # Default model
temperature: null                # Temperature parameter
top_p: null                      # Top-p parameter
```

2. Client-Specific Settings:
```yaml
clients:
  - type: openai
    api_base: https://api.openai.com/v1
    api_key: xxx
    models:
      - name: gpt-4
        max_input_tokens: 128000
        supports_vision: true
```

3. Request Patching:
```yaml
patch:
  chat_completions:
    '.*':
      url: ''
      body: {}
      headers: {}
```

### Error Handling

The error handling system provides comprehensive error management:

```rust
pub fn catch_error(data: &Value, status: u16) -> Result<()> {
    if (200..300).contains(&status) {
        return Ok(());
    }
    
    if let Some(error) = data.get("error") {
        let message = error["message"]
            .as_str()
            .unwrap_or("Unknown error");
        bail!("API error: {message}");
    }
    
    bail!("Unexpected error: HTTP {status}")
}
```

This system provides:
- Unified error reporting
- Detailed debug information
- Provider-specific error mapping
- Consistent error handling patterns

[Continued in Part 2...]