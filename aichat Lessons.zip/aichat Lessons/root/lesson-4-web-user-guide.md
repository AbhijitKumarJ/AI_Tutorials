# Web Interfaces: User Guide and Features

## Starting the Web Interface

To access AIChat's web interfaces, you first need to start the server:

```bash
# Start with default settings
aichat --serve

# Start on specific port
aichat --serve 8080

# Start on specific address
aichat --serve 0.0.0.0:8080
```

This will make available several endpoints:
```
Chat Completions API: http://127.0.0.1:8000/v1/chat/completions
Embeddings API:       http://127.0.0.1:8000/v1/embeddings
LLM Playground:       http://127.0.0.1:8000/playground
LLM Arena:            http://127.0.0.1:8000/arena?num=2
```

## LLM Playground Interface

The Playground provides an interactive environment for testing and experimenting with different LLM models.

### Interface Layout

The Playground consists of three main sections:

1. **Settings Sidebar** (Left):
   - Model selection dropdown
   - RAG integration options
   - Role selection
   - System prompt input
   - Parameter controls (temperature, tokens, etc.)

2. **Chat Area** (Center):
   - Message history display
   - Code block rendering with syntax highlighting
   - Copy and regenerate options for messages
   - Automatic scrolling with manual override

3. **Input Panel** (Bottom):
   - Text input area with auto-resize
   - Image upload button (for vision models)
   - Send button
   - Abort button during generation

### Basic Features

1. **Model Selection**:
   ```
   1. Click the model dropdown in settings
   2. Browse available models
   3. Select desired model
   ```

2. **Adjusting Parameters**:
   - Temperature: Controls randomness (0.0 to 1.0)
   - Max Output Tokens: Limits response length
   - Top P: Controls diversity of responses

3. **Using Roles**:
   - Select predefined roles from the dropdown
   - Edit system prompts directly
   - Save custom roles for reuse

4. **Message Operations**:
   - Copy: Click the copy icon on any message
   - Regenerate: Click regenerate on the last message
   - Text-to-Speech: Click the speaker icon (if available)

### Advanced Features

1. **Image Support** (for vision models):
   ```
   Three ways to add images:
   1. Click the image button and select files
   2. Drag and drop images into the input area
   3. Paste images directly (Ctrl+V/Cmd+V)
   ```

2. **RAG Integration**:
   ```
   1. Select RAG from dropdown
   2. Upload or specify documents
   3. Messages will automatically include relevant context
   ```

3. **Session Management**:
   ```
   The interface maintains state during:
   - Model changes
   - Parameter adjustments
   - Page refreshes (if enabled)
   ```

4. **Multi-line Input**:
   - Shift+Enter for new line
   - Enter to send
   - Auto-expanding input area

## LLM Arena Interface

The Arena enables side-by-side comparison of different models.

### Interface Layout

1. **Model Panels**:
   - Multiple chat panels side by side
   - Independent model selection per panel
   - Synchronized input handling

2. **Shared Input**:
   - Single input area affects all panels
   - Simultaneous model responses
   - Unified image upload

### Usage Examples

1. **Model Comparison**:
   ```
   1. Navigate to: http://localhost:8000/arena?num=2
   2. Select different models in each panel
   3. Enter a prompt to see responses side by side
   ```

2. **Parameter Testing**:
   ```
   1. Use same model in multiple panels
   2. Adjust parameters differently
   3. Compare response variations
   ```

3. **Custom Configuration**:
   ```
   URL Parameters:
   arena?num=3              # Show 3 panels
   arena?models=gpt-4,claude # Pre-select models
   ```

### Interactive Features

1. **Synchronized Scrolling**:
   - Panels scroll together by default
   - Individual scroll control with manual override
   - "Scroll to Bottom" button appears when needed

2. **Message Management**:
   ```
   Per-message controls:
   - Copy content
   - Regenerate response
   - Text-to-speech playback
   ```

3. **Abort Control**:
   ```
   During generation:
   - Cancel individual responses
   - Cancel all responses
   - Partial response preservation
   ```

## Cross-Platform Considerations

### Mobile Usage

1. **Responsive Layout**:
   ```
   - Collapsible sidebar in Playground
   - Single panel view in Arena (swipeable)
   - Touch-friendly controls
   ```

2. **Mobile-Specific Features**:
   - Long-press for message options
   - Pull-to-refresh for updates
   - Mobile keyboard optimization

### Browser Support

1. **Modern Browsers**:
   - Full feature support in recent versions
   - Progressive enhancement for older browsers
   - Automatic capability detection

2. **Fallback Behaviors**:
   ```
   Feature            Fallback
   ---------------   -----------------
   Streaming         Polling
   File Drag/Drop    File picker
   Speech Synthesis  Hidden option
   ```

## Common Operations

### Working with Code

1. **Code Block Features**:
   ```
   - Syntax highlighting
   - Copy button
   - Language detection
   - Collapsible blocks
   ```

2. **Code Input**:
   ```
   Ways to input code:
   1. Backticks for inline code
   2. Triple backticks for blocks
   3. Paste with formatting preserved
   ```

### File Handling

1. **Supported Formats**:
   ```
   Images: jpg, jpeg, png, webp
   Documents: pdf, docx, txt (via RAG)
   ```

2. **Size Limits**:
   ```
   Images: Typically 20MB per file
   Documents: Based on server configuration
   ```

### Error Recovery

1. **Common Issues**:
   ```
   Error                  Solution
   -------------------   ------------------
   Model Unavailable     Try alternative model
   Token Limit           Adjust max tokens
   Network Error         Retry with backoff
   ```

2. **Auto-Recovery**:
   - Automatic reconnection
   - Message state preservation
   - Draft saving

## Best Practices

1. **Optimal Performance**:
   ```
   - Clear context when switching topics
   - Use appropriate temperature settings
   - Monitor token usage
   ```

2. **Effective Comparison**:
   ```
   - Use consistent prompts
   - Control for parameters
   - Document differences
   ```

3. **Resource Management**:
   ```
   - Close unused panels
   - Clear long conversations
   - Remove unused images
   ```

These interfaces provide powerful tools for interacting with LLMs, and understanding their features helps users make the most of AIChat's capabilities.