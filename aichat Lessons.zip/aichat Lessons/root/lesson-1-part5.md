# AIChat Lesson 1: Foundation and Core Structure (Part 5)
## User Guide and Practical Usage

### Installation and Setup

While we covered the technical aspects, here's the practical user setup process:

1. Installation Methods:
```bash
# Rust Developers
cargo install aichat

# Homebrew/Linuxbrew Users
brew install aichat

# Pacman Users
pacman -S aichat

# Windows Scoop Users
scoop install aichat

# Android Termux Users
pkg install aichat
```

2. Initial Configuration:
```bash
$ aichat
> No config file, create a new one? Yes
> Platform: openai
? API Key: ***
✨ Saved config file to '/home/alice/.config/aichat.yaml'
```

### REPL Commands and Usage

The REPL (Read-Eval-Print Loop) interface includes several key commands:

```
.help                    Show help message
.info                    View system info
.model                   Change the current LLM
.prompt                  Create a temporary role using a prompt
.role                    Create or switch to a specific role
.session                 Begin a session
.rag                     Init or use the RAG
.agent                   Use an agent
.file                    Include files with the message
.continue                Continue the response
.regenerate              Regenerate the last response
.copy                    Copy the last response
.set                     Adjust runtime configuration
.delete                  Delete roles/sessions/RAGs/agents
.exit                    Exit the REPL
```

### Session Management

1. Starting a New Session:
```bash
# Via command line
aichat -s mysession

# Via REPL
> .session mysession
```

2. Session Operations:
```bash
.empty session           # Clear session history
.compress session        # Compress session messages
.info session           # View session details
.edit session           # Edit current session
.save session           # Save session to file
.exit session           # End session
```

### Role System Usage

1. Using Built-in Roles:
```bash
# Code generation role
aichat -r %code% "write a python function to calculate fibonacci"

# Shell command generation
aichat -r %shell% "create a new directory and move all pdf files into it"
```

2. Creating Custom Roles:
```yaml
# mycoder.md
---
model: openai:gpt-4o
temperature: 0.3
---
You are an expert programmer specializing in clean, efficient code.
Always provide code with clear comments and error handling.
```

### RAG (Retrieval-Augmented Generation) Usage

1. Initializing RAG:
```bash
> .rag
⚙ Initializing RAG...
Select embedding model: text-embedding-3-small
Set chunk size: 1000
Set chunk overlay: 50
Add documents: /path/to/documents/**/*.md
```

2. Using RAG in Conversations:
```bash
> .rag my_knowledge_base
Loading knowledge base...
✓ Ready to answer questions based on loaded documents

> What information is available about feature X?
Searching knowledge base...
[Results based on documents]
```

### File Handling

The system supports various input types:

```bash
# Single file input
aichat -f data.txt "summarize this"

# Multiple files
aichat -f file1.txt -f file2.txt "compare these"

# Directory input
aichat -f ./documents/ "analyze all files"

# URL input
aichat -f https://example.com/doc.pdf "extract key points"
```

### Environment Variables

Important environment variables for configuration:

```bash
# Core Settings
AICHAT_MODEL=openai:gpt-4              # Set default model
AICHAT_TEMPERATURE=0.7                 # Set temperature
AICHAT_STREAM=false                    # Disable streaming

# API Keys
OPENAI_API_KEY=sk-...                  # OpenAI API key
ANTHROPIC_API_KEY=sk-...               # Anthropic API key

# Paths
AICHAT_CONFIG_DIR=/custom/path         # Custom config directory
AICHAT_ROLES_DIR=/custom/roles         # Custom roles directory
```

### Shell Integration

1. Bash Integration:
```bash
# Add to ~/.bashrc
source /path/to/aichat/scripts/shell-integration/integration.bash
```

2. Zsh Integration:
```bash
# Add to ~/.zshrc
source /path/to/aichat/scripts/shell-integration/integration.zsh
```

3. Fish Integration:
```fish
# Add to ~/.config/fish/config.fish
source /path/to/aichat/scripts/shell-integration/integration.fish
```

### Configuration File Format

The complete configuration structure:

```yaml
# LLM Settings
model: openai:gpt-4o
temperature: null
top_p: null

# Behavior Settings
stream: true
save: true
keybindings: emacs
editor: null
wrap: no
wrap_code: false

# Function Calling
function_calling: true
mapping_tools:
  fs: 'fs_cat,fs_ls,fs_mkdir,fs_rm,fs_write'
use_tools: null

# RAG Settings
rag_embedding_model: null
rag_reranker_model: null
rag_top_k: 4
rag_chunk_size: null
rag_chunk_overlap: null
```

### HTTP Server Usage

Starting the server:

```bash
# Basic server start
aichat --serve

# Custom address/port
aichat --serve 0.0.0.0:3000
```

Available endpoints:
- Chat Completions API: http://127.0.0.1:8000/v1/chat/completions
- Embeddings API: http://127.0.0.1:8000/v1/embeddings
- LLM Playground: http://127.0.0.1:8000/playground
- LLM Arena: http://127.0.0.1:8000/arena?num=2

### Common Issues and Solutions

1. Token Limits:
```bash
# Increase max tokens
.set max_output_tokens 4096

# Enable token usage display
.set show_tokens true
```

2. Rate Limiting:
```bash
# Configure timeouts
.set request_timeout 30

# Enable auto-retry
.set auto_retry true
```

3. File Permission Issues:
```bash
# Check config directory permissions
ls -la ~/.config/aichat

# Fix permissions
chmod 600 ~/.config/aichat/config.yaml
```

### Advanced Features

1. Custom Themes:
```yaml
# Download and apply theme
cd ~/.config/aichat
wget -O dark.tmTheme 'https://raw.githubusercontent.com/...'
```

2. Custom REPL Prompt:
```yaml
left_prompt: '{color.green}{?session {session}}{color.cyan}> {color.reset}'
right_prompt: '{color.purple}{consume_tokens}{color.reset}'
```

### Platform-Specific Considerations

1. Windows:
- Uses AppData for configuration
- PowerShell integration available
- Different path separators

2. macOS:
- Uses Application Support for configuration
- Terminal.app considerations
- Homebrew installation support

3. Linux:
- XDG base directory compliance
- Various terminal emulator support
- Package manager variations

### Best Practices

1. Organization:
- Keep related documents together for RAG
- Use consistent naming for sessions
- Maintain separate roles for different purposes

2. Performance:
- Use appropriate chunk sizes for RAG
- Compress sessions when needed
- Utilize caching when possible

3. Security:
- Keep API keys in environment file
- Use appropriate file permissions
- Validate input paths

This comprehensive guide covers the practical aspects of using AIChat that were assumed or not fully explained in previous parts. Understanding these details helps users:

1. Set up AIChat effectively
2. Use all available features
3. Troubleshoot common issues
4. Optimize their workflow
5. Maintain security best practices

The combination of technical understanding from previous parts and these practical usage details provides a complete picture of AIChat's capabilities and how to best utilize them.
