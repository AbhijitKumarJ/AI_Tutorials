# AIChat Lesson 2: Client Abstraction Layer
## Part 2: Advanced Features and Platform Support

### Platform Support and Integration

AIChat's client abstraction layer supports integration with over 20 different LLM platforms through a unified interface. The platform support is implemented through both direct implementations and OpenAI-compatible adaptors.

#### Direct Platform Implementations:
```rust
// Example OpenAI implementation
impl_client_trait!(
    OpenAIClient,
    (
        prepare_chat_completions,
        openai_chat_completions,
        openai_chat_completions_streaming
    ),
    (prepare_embeddings, openai_embeddings),
    (noop_prepare_rerank, noop_rerank),
);
```

Supported platforms include:
- OpenAI 
- Claude (Anthropic)
- Gemini (Google)
- Cohere
- Azure OpenAI
- VertexAI
- Bedrock (AWS)
- Ernie (Baidu)

#### OpenAI-Compatible Implementation:
The system supports numerous OpenAI-compatible platforms through a shared implementation:

```rust
pub const OPENAI_COMPATIBLE_PLATFORMS: [(&str, &str); 22] = [
    ("ai21", "https://api.ai21.com/studio/v1"),
    ("cloudflare", ""),
    ("deepinfra", "https://api.deepinfra.com/v1/openai"),
    // Additional platforms...
];
```

### Configuration Management

The configuration system provides extensive customization options:

```yaml
clients:
  - type: openai-compatible
    name: local
    api_base: http://localhost:8080/v1
    api_key: xxx
    models:
      - name: llama3.1
        max_input_tokens: 128000
        supports_function_calling: true
```

Features include:
1. Environment Variable Support
2. Proxy Configuration
3. Model Capability Definition
4. API Request Customization

### Streaming Implementation

The streaming system in `stream.rs` provides robust handling of streaming responses:

```rust
pub struct StreamHandler {
    sender: UnboundedSender<SseEvent>,
    abort_signal: AbortSignal,
    buffer: String,
    tool_calls: Vec<ToolCall>,
}

impl StreamHandler {
    pub async fn process_chunk(&mut self, chunk: &str) -> Result<()> {
        self.buffer.push_str(chunk);
        if let Some(message) = self.parse_buffer()? {
            self.sender.send(message)?;
        }
        Ok(())
    }
}
```

This implementation supports:
- Server-Sent Events (SSE)
- Function calling in streams
- Graceful error handling
- Abort capabilities

### Cross-Platform Considerations

The client abstraction layer implements careful handling for various platforms:

#### Token Management
```rust
pub fn token_count(&self, messages: &[Message]) -> usize {
    let num_messages = messages.len();
    let message_tokens = messages.iter()
        .map(|m| count_message_tokens(m))
        .sum::<usize>();
    message_tokens + num_messages * 4
}
```

#### Request Building
```rust
pub fn build_request(&self) -> Result<RequestBuilder> {
    let mut builder = self.client
        .request(Method::POST, &self.url)
        .timeout(Duration::from_secs(30));

    if let Some(proxy) = &self.proxy {
        builder = builder.proxy(reqwest::Proxy::all(proxy)?);
    }

    Ok(builder)
}
```

### Usage Examples

#### Basic Chat Completion
```rust
let client = init_client(&config, None)?;
let response = client.chat_completions(input).await?;
println!("{}", response.text);
```

#### Streaming Chat
```rust
let mut handler = StreamHandler::new(tx, abort_signal);
client.chat_completions_streaming(&input, &mut handler).await?;
```

#### Embeddings Generation
```rust
let embeddings = client.embeddings(&EmbeddingsData {
    texts: vec!["Sample text".to_string()],
    query: false,
}).await?;
```

### Testing Strategy

The testing approach includes:

1. Unit Tests:
```rust
#[tokio::test]
async fn test_chat_completion() {
    let mock_client = MockClient::new();
    let response = mock_client
        .chat_completions(test_input())
        .await;
    assert!(response.is_ok());
}
```

2. Integration Tests:
```rust
#[tokio::test]
async fn test_streaming() {
    let (tx, rx) = mpsc::channel();
    let handler = StreamHandler::new(tx);
    
    client.chat_completions_streaming(&input, &handler).await?;
    
    let messages: Vec<_> = rx.collect().await;
    assert!(!messages.is_empty());
}
```

3. Mock Implementations:
```rust
struct MockClient {
    responses: Arc<Mutex<VecDeque<Result<String>>>>,
}

impl MockClient {
    fn new() -> Self {
        Self {
            responses: Arc::new(Mutex::new(VecDeque::new())),
        }
    }
    
    fn push_response(&self, response: Result<String>) {
        self.responses.lock().unwrap().push_back(response);
    }
}
```

### Best Practices

When working with the client abstraction layer:

1. Error Handling
```rust
fn handle_error(err: Error) -> Error {
    match err {
        Error::Api(e) => Error::Api(normalize_api_error(e)),
        Error::Network(e) => Error::Network(e),
        _ => err,
    }
}
```

2. Configuration
```rust
fn init_client(config: &Config) -> Result<Box<dyn Client>> {
    let client_type = &config.client_type;
    match client_type.as_str() {
        "openai" => Ok(Box::new(OpenAIClient::new(config)?)),
        "anthropic" => Ok(Box::new(AnthropicClient::new(config)?)),
        _ => bail!("Unsupported client type: {}", client_type),
    }
}
```

3. Testing
```rust
fn create_test_client() -> Result<Box<dyn Client>> {
    let config = TestConfig::default();
    let client = MockClient::new();
    client.push_response(Ok("Test response".to_string()));
    Ok(Box::new(client))
}
```

4. Documentation
```rust
/// Creates a new client instance with the provided configuration.
/// 
/// # Arguments
/// * `config` - The client configuration
/// 
/// # Returns
/// A new client instance or an error if initialization fails
/// 
/// # Examples
/// ```
/// let client = init_client(&config)?;
/// ```
pub fn init_client(config: &Config) -> Result<Box<dyn Client>> {
    // Implementation
}
```

[Continued in Part 3...]