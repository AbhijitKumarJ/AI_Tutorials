# Web Component Implementation Details

## Arena Implementation

The Arena component enables side-by-side comparison of different LLM models. Let's explore its implementation in detail.

### Core Structure

The Arena's HTML structure:

```html
<div class="container" x-data="app">
    <div class="chats">
        <template x-for="(chat, index) in chats" :key="index">
            <div class="chat-panel">
                <!-- Model Selection -->
                <div class="chat-header">
                    <select x-model="chat.model">
                        <template x-for="model in chatModels">
                            <option :value="model.id" x-text="model.id"></option>
                        </template>
                    </select>
                </div>
                
                <!-- Message Display -->
                <div class="chat-body" :id="'chat-body-' + index">
                    <template x-for="message in chat.messages">
                        <div class="chat-message">
                            <!-- Message content -->
                        </div>
                    </template>
                </div>
            </div>
        </template>
    </div>
    
    <!-- Input Panel -->
    <div class="input-panel">
        <!-- Input controls -->
    </div>
</div>
```

### State Management

The Arena maintains complex state:

```javascript
Alpine.data("app", () => ({
    chatModels: [],
    input: "",
    images: [],
    asking: 0,
    chats: Array.from(Array(NUM)).map(_ => ({
        model: "",
        messages: [],
        hoveredMessageIndex: null,
        askAbortController: null,
        shouldScrollChatBodyToBottom: true,
        isShowScrollToBottomBtn: false,
    })),

    async init() {
        try {
            const models = await fetchJSON(MODELS_API);
            this.chatModels = models.filter(v => !v.type || v.type === "chat");
        } catch (err) {
            toast("No available model");
            console.error("Failed to load models", err);
        }
        // Initialize chat panels
        this.setupPanels();
    }
}));
```

### Communication Protocol

The Arena implements a sophisticated streaming protocol:

```javascript
async function* fetchChatCompletions(url, body, signal) {
    const stream = body.stream;
    const response = await fetch(url, {
        method: "POST",
        signal,
        headers: getHeaders(),
        body: JSON.stringify(body),
    });

    if (!response.ok) {
        const error = await response.json();
        throw error?.error || error;
    }

    if (!stream) {
        return await response.json();
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let done = false;
    let reamingChunkValue = "";

    while (!done) {
        if (signal?.aborted) {
            reader.cancel();
            break;
        }
        const { value, done: doneReading } = await reader.read();
        done = doneReading;
        
        // Process chunks
        const chunkValue = decoder.decode(value);
        const lines = (reamingChunkValue + chunkValue)
            .split("\n")
            .filter(line => line.trim().length > 0);
        
        // Handle remaining chunk
        reamingChunkValue = "";
        for (const line of lines) {
            try {
                const parsed = JSON.parse(line.replace(/^data: /, ""));
                yield parsed;
            } catch {
                reamingChunkValue = line;
            }
        }
    }
}
```

## Playground Implementation

The Playground provides an interactive environment for testing LLM capabilities.

### Core Structure

```html
<div class="container" x-data="app">
    <!-- Sidebar -->
    <div class="sidebar" x-ref="sidebar">
        <div class="settings">
            <!-- Model settings -->
            <div class="control">
                <label for="model">Model</label>
                <select id="model" x-model="settings.model">
                    <template x-for="model in models">
                        <option :value="model.id" x-text="model.id"></option>
                    </template>
                </select>
            </div>
            
            <!-- Additional controls -->
            <div class="control">
                <label for="temperature">Temperature</label>
                <input type="number" id="temperature" 
                       x-model="settings.temperature">
            </div>
        </div>
    </div>

    <!-- Main Chat Area -->
    <div class="main-panel">
        <!-- Message display -->
        <div class="chat-body">
            <!-- Messages -->
        </div>
        
        <!-- Input area -->
        <div class="input-panel">
            <!-- Input controls -->
        </div>
    </div>
</div>
```

### State and Settings Management

```javascript
Alpine.data("app", () => ({
    models: [],
    rags: [""],
    roles: [{ name: "", prompt: "" }],
    modelData: {},
    messages: [],
    hoveredMessageIndex: null,
    input: "",
    images: [],
    asking: false,
    sessionMode: false,
    settings: {
        model: "default",
        temperature: null,
        top_p: null,
        max_output_tokens: null,
    },

    async init() {
        // Load configuration
        await Promise.all([
            this.loadModels(),
            this.loadRags(),
            this.loadRoles()
        ]);
        
        // Setup event listeners
        this.setupEventListeners();
        
        // Initialize watchers
        this.$watch("settings", () => this.updateUrl());
        this.$watch("settings.model", () => this.handleModelChange());
    }
}));
```

### Advanced Features

#### Image Support

```javascript
async handleImageUpload(event) {
    const files = event.target.files;
    if (!files || files.length === 0) return;
    
    try {
        const urls = await Promise.all(Array.from(files).map(file => 
            convertImageToDataURL(file)
        ));
        this.images.push(...urls);
    } catch (err) {
        toast("Failed to process images");
        console.error(err);
    }
    
    event.target.value = "";
}

async handlePaste(event) {
    const files = Array.from(event.clipboardData.items)
        .filter(v => v.type.startsWith('image/'))
        .map(v => v.getAsFile());
        
    if (files.length === 0) return;
    
    try {
        const urls = await Promise.all(files.map(
            file => convertImageToDataURL(file)
        ));
        this.images.push(...urls);
    } catch (err) {
        toast("Failed to process pasted images");
        console.error(err);
    }
}
```

#### RAG Integration

```javascript
async searchRag(name, input) {
    const res = await fetch(SEARCH_RAG_API, {
        method: "POST",
        headers: getHeaders(),
        signal: this.askAbortController.signal,
        body: JSON.stringify({ name, input })
    });
    
    const data = await res.json();
    return data.data;
}

buildBody() {
    let messages = this.buildMessageChain();
    
    if (this.settings.rag) {
        // Add RAG context
        const lastMessage = messages[messages.length - 1];
        if (lastMessage.role === "user") {
            lastMessage.content = await this.searchRag(
                this.settings.rag,
                lastMessage.content
            );
        }
    }
    
    return {
        model: this.settings.model,
        messages,
        stream: true,
        // Add other parameters
        ...this.buildParameters()
    };
}
```

### Cross-Platform Optimizations

#### Mobile Support

```javascript
handleMobileLayout() {
    const isMobile = window.innerWidth <= 768;
    if (isMobile) {
        this.$refs.sidebar.style.display = 'none';
        this.$refs["main-panel"].style.width = '100%';
    } else {
        this.$refs.sidebar.style.display = 'block';
        this.$refs["main-panel"].style.width = 
            'calc(100vw - 360px - 2.5rem)';
    }
}

setupMobileHandlers() {
    // Show/hide sidebar buttons
    this.$refs["show-sidebar"].addEventListener('click', () => {
        this.$refs.sidebar.style.display = 'block';
        this.$refs["main-panel"].style.display = 'none';
    });
    
    this.$refs["hide-sidebar"].addEventListener('click', () => {
        this.$refs.sidebar.style.display = 'none';
        this.$refs["main-panel"].style.display = 'block';
    });
}
```

#### Performance Optimizations

```javascript
// Message batching
const messageBuffer = {
    messages: [],
    timeout: null,
    
    add(message) {
        this.messages.push(message);
        this.scheduleFlush();
    },
    
    scheduleFlush() {
        if (!this.timeout) {
            this.timeout = setTimeout(() => this.flush(), 100);
        }
    },
    
    async flush() {
        const messages = this.messages;
        this.messages = [];
        this.timeout = null;
        
        try {
            await processMessageBatch(messages);
        } catch (err) {
            console.error('Failed to process messages:', err);
            // Requeue failed messages
            this.messages.push(...messages);
            this.scheduleFlush();
        }
    }
};
```

### Testing and Quality Assurance

```javascript
// UI Test Helpers
const testUtils = {
    async simulateUserInput(text) {
        const input = document.querySelector('#chat-input');
        input.value = text;
        input.dispatchEvent(new Event('input'));
        
        // Wait for Alpine to process the change
        await nextTick();
    },
    
    async simulateModelResponse(response) {
        // Mock API response
        fetchMock.mockResponseOnce(JSON.stringify({
            choices: [{
                message: { content: response }
            }]
        }));
        
        // Trigger send
        await this.simulateUserInput('test');
        await click('[data-testid="send-button"]');
        
        // Wait for response processing
        await waitForElement('[data-testid="assistant-message"]');
    }
};
```

## Conclusion

The web components in AIChat demonstrate sophisticated implementation patterns while maintaining cross-browser compatibility and performance. Key takeaways include:

1. **Modular Architecture**
   - Clear separation of concerns
   - Reusable components
   - Maintainable code structure

2. **State Management**
   - Reactive updates
   - Efficient data flow
   - Consistent state handling

3. **Performance**
   - Optimized rendering
   - Efficient resource usage
   - Responsive design

4. **User Experience**
   - Intuitive interfaces
   - Smooth interactions
   - Cross-platform support

These implementations provide a solid foundation for building and extending AIChat's web capabilities while ensuring reliability and performance across different platforms and browsers.