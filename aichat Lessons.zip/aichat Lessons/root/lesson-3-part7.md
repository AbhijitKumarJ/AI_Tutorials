# AIChat Lesson 3: Configuration and State Management - Part 7
## Troubleshooting Guide and Common Recipes

### Debugging Common Issues

#### 1. Configuration Problems

1. Missing or Invalid Configuration:
```bash
# Check config location
aichat --info | grep config_file

# Verify config syntax
cat ~/.config/aichat/config.yaml
```

Common fixes:
```yaml
# Fix YAML syntax
model: openai:gpt-4o    # No quotes needed
temperature: 0.7        # Use . for decimals
stream: true           # Use true/false, not True/False

# Fix paths
editor: C:\\Program Files\\Editor\\editor.exe  # Windows paths need double backslash
```

2. Environment Variable Issues:
```bash
# Check environment setup
env | grep AICHAT_
env | grep OPENAI_

# Common fixes
export AICHAT_MODEL="openai:gpt-4o"      # Use quotes for values with special chars
export OPENAI_API_KEY="sk-..."           # API key must start with "sk-"
```

#### 2. Session Management Issues

1. Session Won't Save:
```bash
# Check permissions
ls -l ~/.config/aichat/sessions/

# Fix permissions
chmod 700 ~/.config/aichat/sessions/
chmod 600 ~/.config/aichat/sessions/*

# Verify session state
.info session
```

2. Token Limit Problems:
```bash
# Check current usage
.info session

# Force compression
.compress session

# Adjust compression threshold
.set compress_threshold 3000
```

#### 3. Role and Agent Problems

1. Role Not Found:
```bash
# List available roles
aichat --list-roles

# Check role location
ls ~/.config/aichat/roles/

# Fix role file permissions
chmod 600 ~/.config/aichat/roles/*
```

2. Agent Variables Not Working:
```bash
# Check current variables
.info agent

# Reset variables
.variable set VAR_NAME ""

# Verify in config
cat ~/.config/aichat/agents/agent_name/config.yaml
```

### Common Task Recipes

#### 1. Development Workflow Recipes

1. Code Review Setup:
```bash
# Create code review role
cat > ~/.config/aichat/roles/code-reviewer.md << EOF
---
model: openai:gpt-4o
temperature: 0.3
use_tools: git,fs
---
You are a code reviewer focusing on:
1. Security vulnerabilities
2. Performance issues
3. Code quality
4. Best practices
EOF

# Use in git workflow
git diff | aichat -r code-reviewer
```

2. Documentation Generator:
```bash
# Create documentation role
cat > ~/.config/aichat/roles/doc-writer.md << EOF
---
model: openai:gpt-4o
temperature: 0.7
---
Generate clear, concise documentation following these guidelines:
1. Use Markdown format
2. Include examples
3. Explain complex concepts
4. Add appropriate warnings
EOF

# Use with codebase
aichat -r doc-writer -f src/**/*.py "Generate API documentation"
```

#### 2. System Administration Recipes

1. Log Analysis Setup:
```bash
# Create log analyzer role
cat > ~/.config/aichat/roles/log-analyzer.md << EOF
---
model: openai:gpt-4o
temperature: 0.3
use_tools: fs,grep
---
Analyze log files for:
1. Error patterns
2. Security issues
3. Performance problems
4. Unusual behavior
EOF

# Use with logs
aichat -r log-analyzer -f /var/log/syslog "Find error patterns"
```

2. System Maintenance Helper:
```bash
# Create maintenance role
cat > ~/.config/aichat/roles/sys-maintenance.md << EOF
---
model: openai:gpt-4o
use_tools: fs,docker,systemctl
---
Help with system maintenance tasks:
1. Resource cleanup
2. Service management
3. Performance optimization
4. Security updates
EOF

# Use for maintenance
aichat -r sys-maintenance "Clean up old docker images"
```

#### 3. Content Creation Recipes

1. Technical Blog Writer:
```bash
# Create blog writer role
cat > ~/.config/aichat/roles/blog-writer.md << EOF
---
model: openai:gpt-4o
temperature: 0.7
---
Write technical blog posts that:
1. Start with clear introduction
2. Include code examples
3. Explain complex concepts simply
4. End with key takeaways
EOF

# Use with topic
aichat -r blog-writer "Write about Rust error handling"
```

2. Documentation Reviewer:
```bash
# Create doc reviewer role
cat > ~/.config/aichat/roles/doc-reviewer.md << EOF
---
model: openai:gpt-4o
temperature: 0.3
---
Review documentation for:
1. Clarity and completeness
2. Technical accuracy
3. Consistency
4. Missing information
EOF

# Use with existing docs
aichat -r doc-reviewer -f docs/*.md "Review these docs"
```

### Advanced Usage Recipes

#### 1. Multi-Stage Processing

1. Code Generation and Review Pipeline:
```bash
#!/bin/bash
# generate_and_review.sh

# Generate code
aichat -r code-generator -c "$1" > generated_code.py

# Review generated code
aichat -r code-reviewer -f generated_code.py > review.md

# Generate tests
aichat -r test-generator -f generated_code.py > tests.py
```

2. Documentation Pipeline:
```bash
#!/bin/bash
# doc_pipeline.sh

# Generate initial docs
aichat -r doc-writer -f src/*.py > docs_draft.md

# Review docs
aichat -r doc-reviewer -f docs_draft.md > review.md

# Final polish
aichat -r technical-editor -f docs_draft.md review.md > final_docs.md
```

#### 2. Integration Recipes

1. Git Hooks Setup:
```bash
# pre-commit hook
cat > .git/hooks/pre-commit << 'EOF'
#!/bin/bash
git diff --cached | aichat -r code-reviewer > review.txt
if grep -q "CRITICAL:" review.txt; then
    cat review.txt
    exit 1
fi
EOF
chmod +x .git/hooks/pre-commit
```

2. CI/CD Integration:
```yaml
# .github/workflows/aichat-review.yml
name: AIChat Code Review
on: [pull_request]
jobs:
  review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Install AIChat
        run: cargo install aichat
      - name: Review Changes
        run: |
          git diff origin/main | aichat -r code-reviewer > review.md
          if grep -q "CRITICAL:" review.md; then
            exit 1
          fi
```

### Performance Optimization Recipes

1. Fast Response Setup:
```yaml
# ~/.config/aichat/config.yaml
model: openai:gpt-3.5-turbo
temperature: 0.7
stream: false
save: false
function_calling: false
```

2. High Quality Setup:
```yaml
# ~/.config/aichat/config.yaml
model: openai:gpt-4o
temperature: 0.3
stream: true
save: true
compress_threshold: 8000
function_calling: true
```

### Debugging Recipes

1. Debug Log Enablement:
```bash
#!/bin/bash
# debug_aichat.sh

export AICHAT_LOG_LEVEL=debug
export AICHAT_LOG_FILE=/tmp/aichat_debug.log

aichat "$@" 

echo "Debug log available at: /tmp/aichat_debug.log"
```

2. Configuration Tester:
```bash
#!/bin/bash
# test_config.sh

echo "Testing AIChat configuration..."

# Test basic functionality
aichat --info

# Test model access
aichat -m openai:gpt-4o "test" --dry-run

# Test role loading
aichat --list-roles

# Test session creation
aichat -s test --empty-session --dry-run

echo "Configuration test complete"
```

### Recovery Recipes

1. Session Recovery:
```bash
#!/bin/bash
# recover_session.sh
SESSION_NAME=$1

# Backup existing session
cp ~/.config/aichat/sessions/$SESSION_NAME.yaml \
   ~/.config/aichat/sessions/$SESSION_NAME.backup

# Compress session
aichat -s $SESSION_NAME --empty-session
```

2. Configuration Recovery:
```bash
#!/bin/bash
# reset_config.sh

# Backup current config
cp ~/.config/aichat/config.yaml ~/.config/aichat/config.backup

# Reset to defaults
aichat --info > ~/.config/aichat/config.yaml

echo "Configuration reset. Backup at: ~/.config/aichat/config.backup"
```

These recipes provide ready-to-use solutions for common tasks and issues when working with AIChat. They can be customized and combined to create more complex workflows based on specific needs.