# Core Concepts and Additional Details

In this part, we'll explore the fundamental concepts that underpin AIChat's RAG system and explain elements that were assumed but not explicitly covered in the previous parts.

## Understanding Vector Embeddings

### What Are Embeddings?

Text embeddings are numerical representations of text that capture semantic meaning. In AIChat's RAG system, embeddings are crucial for several reasons:

1. Semantic Understanding:
   - Words and phrases with similar meanings have similar vector representations
   - Enables matching conceptually related content even with different wording
   - Allows for language-agnostic comparison of texts

2. Mathematical Properties:
   - Each embedding is a high-dimensional vector (typically hundreds or thousands of dimensions)
   - Similarity between texts can be measured using vector operations
   - Common metrics include cosine similarity and euclidean distance

Example of embedding generation in AIChat:
```rust
pub async fn create_embeddings(
    &self,
    data: EmbeddingsData,
    spinner: Option<Spinner>,
) -> Result<EmbeddingsOutput>
```

## HNSW Index Explained

### What is HNSW?

Hierarchical Navigable Small World (HNSW) is an algorithm for approximate nearest neighbor search. AIChat uses it for efficient vector similarity search:

1. Structure:
   - Multiple layers of graphs
   - Each layer is a "small world" network
   - Higher layers are sparser for quick traversal
   - Lower layers are denser for accuracy

2. Benefits:
   - Logarithmic search complexity
   - High recall rate
   - Memory efficient
   - Supports dynamic updates

AIChat's HNSW implementation:
```rust 
let hnsw = Hnsw::new(32, self.vectors.len(), 16, 200, DistCosine {});
```

Parameters explained:
- `32`: Maximum number of connections per node
- `16`: Number of layers
- `200`: Search depth
- `DistCosine`: Distance metric for similarity computation

## BM25 Search Algorithm

### Understanding BM25

BM25 (Best Matching 25) is a probabilistic ranking function used for traditional keyword search:

1. Core Components:
   - Term Frequency (TF): How often a term appears in a document
   - Inverse Document Frequency (IDF): How rare a term is across all documents
   - Document Length Normalization: Adjusting for document size

2. Formula Components:
```
score(D,Q) = ∑(IDF(qi) * TF(qi,D) * (k1 + 1)) / (TF(qi,D) + k1 * (1 - b + b * |D|/avgdl))
```
Where:
- D: Document
- Q: Query
- k1: Term frequency saturation parameter
- b: Length normalization parameter

AIChat's BM25 configuration:
```rust
SearchEngineBuilder::<DocumentId>::with_documents(Language::English, documents)
    .k1(1.5)
    .b(0.75)
    .build()
```

## Reciprocal Rank Fusion (RRF)

### How RRF Works

RRF is a method for combining results from multiple search systems:

1. Basic Principle:
   - Each result gets a score based on its rank in each system
   - Scores are combined using the RRF formula
   - Higher weights can be given to preferred systems

2. Formula:
```
RRF score = ∑ weight_i * 1/(k + rank_i)
```
Where:
- k: Constant to prevent division by zero and reduce impact of high ranks
- rank_i: Position of document in result list i
- weight_i: Importance weight for system i

AIChat's implementation:
```rust
fn reciprocal_rank_fusion(
    list_of_document_ids: Vec<Vec<DocumentId>>,
    list_of_weights: Vec<f32>,
    top_k: usize,
) -> Vec<DocumentId>
```

## Document Chunking Strategies

### Understanding Chunking

Document chunking is critical for effective RAG operation:

1. Purpose:
   - Break documents into manageable pieces
   - Maintain semantic coherence
   - Enable precise retrieval
   - Support model context windows

2. Chunking Parameters:
   ```rust
   pub struct SplitterChunkHeaderOptions {
       pub chunk_header: String,
       pub chunk_overlap_header: Option<String>,
   }
   ```

3. Language-Specific Rules:
   ```rust
   pub enum Language {
       Cpp,
       Go,
       Java,
       Js,
       // ... other languages
   }
   ```

Each language has specific separators defined for optimal chunking.

## Reranking Process

### How Reranking Works

Reranking improves search results through secondary evaluation:

1. Process Flow:
   - Initial search returns candidates
   - Reranker evaluates pairs of (query, document)
   - Results are reordered based on new scores

2. Benefits:
   - More accurate relevance assessment
   - Consideration of longer context
   - Better handling of nuanced queries

Implementation:
```rust
async fn rerank(&self, req: hyper::Request<Incoming>) -> Result<AppResponse> {
    // ... reranking logic
}
```

## Additional RAG Features

### File Type Support

AIChat supports various file types through configurable loaders:

1. Built-in Support:
   - Markdown (.md)
   - Plain text (.txt)
   - HTML (.html)
   - Source code files

2. External Loader Support:
   ```yaml
   document_loaders:
     pdf: 'pdftotext $1 -'
     docx: 'pandoc --to plain $1'
   ```

### Web Crawling Capabilities

Detailed web crawling features:

1. Configuration Options:
```rust
pub struct CrawlOptions {
    extract: Option<String>,
    exclude: Vec<String>,
    no_log: bool,
}
```

2. Special Handlers:
   - GitHub repository crawling
   - Wiki page processing
   - General website traversal

## Memory Management

### Memory Optimization Strategies

AIChat implements several memory optimization strategies:

1. Batch Processing:
   ```rust
   let batch_size = match self.embedding_model.max_input_tokens() {
       Some(max_input_tokens) => {
           let x = max_input_tokens / self.data.chunk_size;
           match batch_size {
               Some(y) => x.min(y),
               None => x,
           }
       }
       None => batch_size.unwrap_or(1),
   };
   ```

2. Vector Storage:
   - Efficient serialization
   - Compressed storage formats
   - Lazy loading strategies

### Concurrent Processing

AIChat handles concurrent operations through:

1. Tokio Runtime:
   ```rust
   async fn run_spinner(message: String, mut rx: mpsc::UnboundedReceiver<SpinnerEvent>)
   ```

2. Semaphore Control:
   ```rust
   let semaphore = Arc::new(Semaphore::new(MAX_CRAWLS));
   ```

## Integration Points

### LLM Integration

How RAG integrates with LLMs:

1. Context Injection:
   - Retrieved documents are formatted
   - Template system for context inclusion
   - Response generation with augmented context

2. Template Configuration:
```yaml
rag_template: |
  Answer the query based on the context while respecting the rules.
  <context>
  __CONTEXT__
  </context>
```

### API Integration

RAG system exposes APIs for:

1. Embeddings Generation:
```
POST /v1/embeddings
```

2. Search Operations:
```
POST /v1/rags/search
```

## Error Recovery and Resilience

### Handling Common Issues

1. Document Processing Errors:
   - Retry mechanisms for embeddings
   - Graceful degradation for unsupported formats
   - Partial success handling

2. Search Failures:
   - Fallback to alternative search methods
   - Automatic index rebuilding
   - Error reporting and logging

This concludes our deep dive into the underlying concepts and additional details of AIChat's RAG system. Understanding these concepts is crucial for effectively utilizing and potentially extending the system's capabilities.