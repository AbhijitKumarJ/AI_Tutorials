# Enterprise Integration and Advanced Usage Scenarios

## Integration with External Systems

### REST API Integration

AIChat's RAG system can be integrated with external systems through its HTTP server:

1. Server Configuration:
```yaml
# config.yaml
serve_addr: "0.0.0.0:8000"  # Listen on all interfaces
```

2. API Endpoints:
```bash
# Start the server
$ aichat --serve

Chat Completions API: http://localhost:8000/v1/chat/completions
Embeddings API:       http://localhost:8000/v1/embeddings
RAG Search API:       http://localhost:8000/v1/rags/search
```

3. API Usage Examples:
```bash
# RAG Search Request
curl -X POST http://localhost:8000/v1/rags/search \
  -H "Content-Type: application/json" \
  -d '{
    "name": "knowledge_base",
    "input": "How does feature X work?"
  }'

# Embeddings Generation
curl -X POST http://localhost:8000/v1/embeddings \
  -H "Content-Type: application/json" \
  -d '{
    "input": ["Text to embed"],
    "model": "text-embedding-3-small"
  }'
```

### Document Management System Integration

Integrating with enterprise document management systems:

```python
# Python script for SharePoint integration
from office365.sharepoint.client_context import ClientContext
from office365.runtime.auth.user_credential import UserCredential

async def sync_sharepoint_docs():
    # Connect to SharePoint
    ctx = ClientContext(sharepoint_url).with_credentials(
        UserCredential(username, password)
    )
    
    # Download documents
    lib = ctx.web.lists.get_by_title("Documents")
    items = lib.items.get().execute_query()
    
    # Update RAG system
    for item in items:
        subprocess.run([
            "aichat",
            "-R", "enterprise_kb",
            "-f", item.file.serverRelativeUrl
        ])
```

## Automation and Scripting

### Automated Document Processing

1. Watch Directory for Changes:
```bash
#!/bin/bash
# monitor_docs.sh

WATCH_DIR="/path/to/docs"
RAG_NAME="auto_kb"

inotifywait -m -r -e create,modify,delete "$WATCH_DIR" |
while read -r directory event filename; do
    echo "Processing changes in $filename..."
    aichat -R "$RAG_NAME" -f "$directory/$filename"
    aichat -R "$RAG_NAME" .rebuild rag
done
```

2. Scheduled Updates:
```bash
# crontab entry
0 2 * * * /usr/local/bin/update_rag.sh

# update_rag.sh
#!/bin/bash
aichat -R knowledge_base -f /data/docs/**/*.md
aichat -R knowledge_base .rebuild rag
```

### Batch Processing

Processing large document collections:

```python
# batch_process.py
import asyncio
from pathlib import Path

async def process_document_batch(docs, batch_size=10):
    for i in range(0, len(docs), batch_size):
        batch = docs[i:i + batch_size]
        tasks = [
            asyncio.create_subprocess_exec(
                'aichat', '-R', 'batch_kb',
                '-f', str(doc),
                stdout=asyncio.subprocess.PIPE
            ) for doc in batch
        ]
        await asyncio.gather(*tasks)

# Usage
docs = list(Path('documents').glob('**/*.pdf'))
asyncio.run(process_document_batch(docs))
```

## Enterprise Deployment

### Docker Deployment

1. Dockerfile:
```dockerfile
FROM ubuntu:22.04

# Install dependencies
RUN apt-get update && apt-get install -y \
    poppler-utils \
    pandoc \
    curl

# Install aichat
RUN curl -L https://github.com/sigoden/aichat/releases/download/v0.x.x/aichat-linux-x86_64.tar.gz | tar xz
RUN mv aichat /usr/local/bin/

# Configuration
COPY config.yaml /root/.config/aichat/
VOLUME ["/data"]

EXPOSE 8000
CMD ["aichat", "--serve"]
```

2. Docker Compose:
```yaml
version: '3'
services:
  aichat:
    build: .
    ports:
      - "8000:8000"
    volumes:
      - ./data:/data
      - ./config:/root/.config/aichat
    environment:
      - AICHAT_LOG_LEVEL=info
```

### Kubernetes Deployment

1. Deployment Configuration:
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: aichat-rag
spec:
  replicas: 3
  template:
    spec:
      containers:
      - name: aichat
        image: aichat:latest
        ports:
        - containerPort: 8000
        volumeMounts:
        - name: config
          mountPath: /root/.config/aichat
        - name: data
          mountPath: /data
      volumes:
      - name: config
        configMap:
          name: aichat-config
      - name: data
        persistentVolumeClaim:
          claimName: aichat-data
```

2. Service Configuration:
```yaml
apiVersion: v1
kind: Service
metadata:
  name: aichat-rag
spec:
  selector:
    app: aichat-rag
  ports:
  - port: 8000
    targetPort: 8000
  type: LoadBalancer
```

## Security Considerations

### Access Control

1. API Authentication:
```yaml
# config.yaml
api_key: "your-secret-key"
```

```bash
# Authenticated request
curl -H "Authorization: Bearer your-secret-key" \
     http://localhost:8000/v1/rags/search
```

2. Document Access Control:
```rust
pub struct DocumentAccess {
    permissions: HashMap<String, Vec<String>>,
}

impl DocumentAccess {
    pub fn can_access(&self, user: &str, doc: &str) -> bool {
        self.permissions.get(user)
            .map(|allowed| allowed.contains(&doc.to_string()))
            .unwrap_or(false)
    }
}
```

### Data Security

1. Document Encryption:
```yaml
# config.yaml
encryption:
  enabled: true
  key_file: /path/to/key.pem
```

2. Sensitive Data Filtering:
```rust
pub struct DataFilter {
    patterns: Vec<Regex>,
}

impl DataFilter {
    pub fn filter_sensitive_data(&self, text: &str) -> String {
        let mut filtered = text.to_string();
        for pattern in &self.patterns {
            filtered = pattern.replace_all(&filtered, "[REDACTED]")
                            .to_string();
        }
        filtered
    }
}
```

## Monitoring and Maintenance

### Performance Monitoring

1. Metrics Collection:
```rust
pub struct RagMetrics {
    query_times: Histogram,
    cache_hits: Counter,
    index_size: Gauge,
}

impl RagMetrics {
    pub fn record_query(&self, duration: Duration) {
        self.query_times.observe(duration.as_secs_f64());
    }
}
```

2. Prometheus Integration:
```yaml
# config.yaml
metrics:
  enabled: true
  endpoint: /metrics
```

### Health Checks

1. System Health Monitoring:
```bash
#!/bin/bash
# health_check.sh

check_rag_health() {
    # Check RAG system health
    response=$(curl -s http://localhost:8000/health)
    status=$(echo $response | jq -r '.status')
    
    if [ "$status" != "healthy" ]; then
        send_alert "RAG system unhealthy: $response"
    fi
}

# Run every 5 minutes
while true; do
    check_rag_health
    sleep 300
done
```

2. Automatic Recovery:
```python
# monitor.py
async def monitor_rag_health():
    while True:
        try:
            status = await check_health()
            if status != "healthy":
                await rebuild_indices()
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            await restart_service()
        await asyncio.sleep(300)
```

### Maintenance Tasks

1. Index Optimization:
```bash
# optimize_indices.sh
#!/bin/bash

# Compress indices
aichat -R knowledge_base .compress rag

# Rebuild if needed
if [ $? -ne 0 ]; then
    aichat -R knowledge_base .rebuild rag
fi
```

2. Backup Strategy:
```python
# backup.py
async def backup_rag_data():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = f"backups/rag_{timestamp}"
    
    # Stop RAG service
    await stop_service()
    
    try:
        # Backup data
        shutil.copytree("/data/rag", backup_dir)
        
        # Compress backup
        shutil.make_archive(backup_dir, 'gzip', backup_dir)
    finally:
        # Restart service
        await start_service()
```

## Advanced Configuration Patterns

### Dynamic Configuration

1. Configuration Reloading:
```yaml
# config.yaml
reload:
  enabled: true
  watch_paths:
    - /etc/aichat/conf.d/*.yaml
```

2. Environment-Based Configuration:
```yaml
# config.base.yaml
---
base_config: &base
  rag_chunk_size: 1000
  rag_chunk_overlap: 200

environments:
  development:
    <<: *base
    rag_top_k: 3
  
  production:
    <<: *base
    rag_top_k: 5
    rag_min_score_vector_search: 0.7
```

These advanced usage patterns enable enterprise-grade deployment and operation of AIChat's RAG system. They provide the foundation for scalable, secure, and maintainable implementations in production environments.