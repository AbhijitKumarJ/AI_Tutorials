# Lesson 5: Understanding AIChat's RAG System - Part 2

## Advanced Search Implementation

AIChat's RAG system implements a sophisticated hybrid search approach that combines multiple search strategies to provide accurate and relevant results.

### Vector Similarity Search

The vector search implementation uses HNSW (Hierarchical Navigable Small World) for efficient similarity search:

```rust
async fn vector_search(
    &self,
    query: &str,
    top_k: usize,
    min_score: f32,
) -> Result<Vec<(DocumentId, f32)>>
```

This approach enables semantic search capabilities by:
- Converting query text into embeddings
- Performing efficient nearest neighbor search
- Filtering results based on minimum similarity scores

### Keyword-Based Search

The keyword search implementation uses the BM25 algorithm:

```rust
async fn keyword_search(
    &self,
    query: &str,
    top_k: usize,
    min_score: f32,
) -> Result<Vec<(DocumentId, f32)>>
```

This provides traditional lexical matching by:
- Analyzing term frequency
- Considering document length
- Applying inverse document frequency

### Result Fusion

The system combines results from both search methods using Reciprocal Rank Fusion:

```rust
fn reciprocal_rank_fusion(
    list_of_document_ids: Vec<Vec<DocumentId>>,
    list_of_weights: Vec<f32>,
    top_k: usize,
) -> Vec<DocumentId>
```

## Advanced Features

### Reranking Support

AIChat supports result reranking through specialized reranking models:

```yaml
rag_reranker_model: "cohere/rerank-english-v2.0"  # Example reranker
```

The reranking process helps improve result relevance by:
1. Taking initial search results
2. Applying sophisticated reranking algorithms
3. Reordering results based on additional relevance metrics

### Web Page Processing

The system includes advanced web crawling capabilities for processing web-based content:

```rust
pub async fn crawl_website(start_url: &str, options: CrawlOptions) -> Result<Vec<Page>>
```

Features include:
- HTML to Markdown conversion
- Content extraction
- Link following with depth control
- Metadata preservation

### Batch Processing

The system implements efficient batch processing for document handling:

```rust
pub async fn create_embeddings(
    &self,
    data: EmbeddingsData,
    spinner: Option<Spinner>,
) -> Result<EmbeddingsOutput>
```

This enables:
- Parallel processing of documents
- Efficient resource utilization
- Progress tracking and user feedback

## RAG Commands and Operations

AIChat provides several commands for RAG operations:

```
.rag                     # Init or use the RAG
.rebuild rag            # Rebuild the RAG to sync document changes
.sources rag           # View the RAG sources in the last query
.info rag             # View RAG info
.exit rag             # Leave the RAG
```

Each command serves specific purposes:

1. `.rag` - Initializes a new RAG or switches to an existing one:
   - Prompts for embedding model selection
   - Allows document source specification
   - Sets up chunking parameters

2. `.rebuild rag` - Updates the RAG with changes:
   - Reprocesses documents
   - Updates embeddings
   - Rebuilds search indices

3. `.sources rag` - Shows document sources:
   - Displays source documents
   - Shows relevant chunks
   - Indicates match scores

4. `.info rag` - Provides RAG information:
   - Configuration details
   - Document statistics
   - Model information

## Best Practices and Usage Recommendations

### Document Processing

When working with AIChat's RAG system, follow these document processing best practices:

1. Document Organization:
   - Keep related documents together
   - Use consistent file formats
   - Maintain clear directory structures

2. Chunk Size Selection:
   - Consider document type and content
   - Balance between context and relevance
   - Account for model token limits

3. File Format Handling:
   - Configure appropriate document loaders
   - Validate input formats
   - Handle encoding correctly

### Search Optimization

To optimize search results:

1. Query Formation:
   - Be specific and clear
   - Include relevant keywords
   - Consider context requirements

2. Parameter Tuning:
   - Adjust top_k based on needs
   - Fine-tune minimum scores
   - Balance vector and keyword search weights

3. Performance Optimization:
   - Use appropriate batch sizes
   - Implement caching when needed
   - Monitor resource usage

## Example Workflows

### 1. Technical Documentation RAG

Setting up a RAG for technical documentation:

```bash
> .rag tech_docs
Select embedding model: text-embedding-3-large
Set chunk size: 1500
Add documents: ./technical_docs/**/*.{md,rst}
```

### 2. Web Content RAG

Creating a RAG from web content:

```bash
> .rag web_content
Add documents: https://docs.example.com/**
⚙ Crawling website...
✓ Processed 100 pages
```

### 3. Mixed Source RAG

Combining multiple source types:

```bash
> .rag mixed_sources
Add documents: ./local_docs/;https://api.docs.com/
Processing multiple sources...
✓ Combined knowledge base ready
```

## Error Handling and Troubleshooting

AIChat's RAG system implements comprehensive error handling:

1. Document Loading Errors:
   - File access issues
   - Format compatibility
   - Encoding problems

2. Processing Errors:
   - Embedding generation failures
   - Chunking issues
   - Storage problems

3. Search Errors:
   - Index corruption
   - Query formatting
   - Resource limitations

Common troubleshooting steps:

1. Verify document accessibility and format
2. Check configuration settings
3. Monitor system resources
4. Review error messages
5. Rebuild RAG if necessary

## Future Directions

The AIChat RAG system continues to evolve with planned improvements:

1. Enhanced Embedding Models:
   - Multi-modal support
   - Improved efficiency
   - Additional model options

2. Advanced Search Features:
   - Improved hybrid search
   - Better result ranking
   - Query optimization

3. Performance Improvements:
   - Faster indexing
   - Reduced memory usage
   - Better scaling

This concludes our comprehensive exploration of AIChat's RAG system. Understanding these components and practices enables effective use of RAG capabilities in various applications and scenarios.
