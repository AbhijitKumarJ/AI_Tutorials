# AIChat HTTP Server Implementation - Part 1: Architecture and Core Implementation

## Introduction

The HTTP server implementation in AIChat provides a robust foundation for exposing LLM capabilities through standardized REST APIs and web interfaces. This part covers the core architecture and implementation details of the server component.

## Project Structure

The HTTP server implementation spans several key files and directories:

```
src/
├── serve.rs                 # Main server implementation
├── client/
│   ├── common.rs           # Common client interfaces
│   └── stream.rs           # Streaming functionality
├── utils/
│   └── request.rs          # HTTP request utilities
└── assets/
    ├── arena.html          # LLM comparison interface
    └── playground.html     # Interactive LLM interface
```

## Core Server Architecture

The server implementation in AIChat follows a modular architecture centered around the `Server` struct defined in `serve.rs`. The server provides:

1. REST API endpoints for chat completions, embeddings, and reranking
2. Web interfaces for playground and arena interactions 
3. Support for both synchronous and streaming responses
4. Graceful shutdown capabilities
5. CORS and error handling

### Server Initialization

The server initialization process begins in the `run` function:

```rust
pub async fn run(config: GlobalConfig, addr: Option<String>) -> Result<()> {
    let addr = match addr {
        Some(addr) => {
            if let Ok(port) = addr.parse::<u16>() {
                format!("127.0.0.1:{port}")
            } else if let Ok(ip) = addr.parse::<IpAddr>() {
                format!("{ip}:8000")
            } else {
                addr
            }
        }
        None => config.read().serve_addr(),
    };
    let server = Arc::new(Server::new(&config));
    let listener = TcpListener::bind(&addr).await?;
    let stop_server = server.run(listener).await?;
    // Print server endpoints
    shutdown_signal().await;
    let _ = stop_server.send(());
    Ok(())
}
```

The server uses Tokio for async I/O operations and creates a TcpListener bound to the specified address. The server instance is wrapped in an Arc for safe sharing across multiple tasks.

### Request Handling

Request handling is implemented through the `handle` function which processes incoming HTTP requests:

```rust
async fn handle(
    self: Arc<Self>,
    req: hyper::Request<Incoming>,
) -> std::result::Result<AppResponse, hyper::Error> {
    let method = req.method().clone();
    let uri = req.uri().clone();
    let path = uri.path();

    // CORS handling
    if method == Method::OPTIONS {
        let mut res = Response::default();
        *res.status_mut() = StatusCode::NO_CONTENT;
        set_cors_header(&mut res);
        return Ok(res);
    }

    // Route handling
    let mut status = StatusCode::OK;
    let res = match path {
        "/v1/chat/completions" => self.chat_completions(req).await,
        "/v1/embeddings" => self.embeddings(req).await,
        "/v1/rerank" => self.rerank(req).await,
        "/v1/models" => self.list_models(),
        "/playground" => self.playground_page(),
        "/arena" => self.arena_page(),
        _ => {
            status = StatusCode::NOT_FOUND;
            Err(anyhow!("Not Found"))
        }
    };
    
    // Response processing and error handling
    let mut res = match res {
        Ok(res) => {
            info!("{method} {uri} {}", status.as_u16());
            res
        }
        Err(err) => {
            if status == StatusCode::OK {
                status = StatusCode::BAD_REQUEST;
            }
            error!("{method} {uri} {} {err}", status.as_u16());
            ret_err(err)
        }
    };
    *res.status_mut() = status;
    set_cors_header(&mut res);
    Ok(res)
}
```

### Streaming Implementation

One of the key features is support for streaming responses using Server-Sent Events (SSE). This is implemented through a `SseHandler` struct that manages the streaming state and event dispatch:

```rust
pub struct SseHandler {
    sender: UnboundedSender<SseEvent>,
    abort_signal: AbortSignal,
    buffer: String,
    tool_calls: Vec<ToolCall>,
}
```

The streaming implementation supports:
- Real-time text output
- Tool call handling 
- Graceful abort/shutdown
- Keep-alive handling
- Clean stream termination

### Error Handling

The server implements comprehensive error handling through the `ret_err` function:

```rust
fn ret_err<T: std::fmt::Display>(err: T) -> AppResponse {
    let data = json!({
        "error": {
            "message": err.to_string(),
            "type": "invalid_request_error",
        },
    });
    Response::builder()
        .header("Content-Type", "application/json")
        .body(Full::new(Bytes::from(data.to_string())).boxed())
        .unwrap()
}
```

This ensures consistent error responses across all endpoints with proper status codes and error details.

### Chat Completions Endpoint

The chat completions endpoint (`/v1/chat/completions`) is the most complex implementation, handling:

1. Request validation and parsing:
```rust
let req_body = req.collect().await?.to_bytes();
let req_body: Value = serde_json::from_slice(&req_body)
    .map_err(|err| anyhow!("Invalid request json, {err}"))?;
```

2. Model selection and configuration
3. Streaming mode handling
4. Tool calling support
5. Token management

### Web Interfaces

The server provides two web interfaces:

1. Playground (`/playground`) - Interactive LLM interface:
```rust
fn playground_page(&self) -> Result<AppResponse> {
    let res = Response::builder()
        .header("Content-Type", "text/html; charset=utf-8")
        .body(Full::new(Bytes::from(PLAYGROUND_HTML)).boxed())?;
    Ok(res)
}
```

2. Arena (`/arena`) - Model comparison interface:
```rust
fn arena_page(&self) -> Result<AppResponse> {
    let res = Response::builder()
        .header("Content-Type", "text/html; charset=utf-8")
        .body(Full::new(Bytes::from(ARENA_HTML)).boxed())?;
    Ok(res)
}
```

Both interfaces are served from embedded HTML assets in the binary.

## Cross-Platform Support

The server implementation includes several cross-platform considerations:

1. Path handling for different operating systems
2. Network interface binding
3. Process management
4. Resource cleanup
5. File system access patterns

This ensures consistent behavior across Windows, macOS and Linux environments.

## Conclusion

The AIChat HTTP server implementation provides a robust foundation for exposing LLM capabilities through standardized APIs and web interfaces. The modular architecture, comprehensive error handling, and streaming support make it suitable for both development and production use cases.