# AIChat Lesson 1: Foundation and Core Structure (Part 3)
## Core Concepts & Additional Details

### Understanding the LLM Integration Concepts

#### Model Types and Capabilities
AIChat works with different types of Large Language Models (LLMs) which have distinct capabilities:

1. Chat Models: Used for conversation and text generation
```rust
pub struct Model {
    client_name: String,
    data: ModelData,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModelData {
    pub name: String,
    pub model_type: String,
    pub max_input_tokens: Option<usize>,
    pub input_price: Option<f64>,
    pub output_price: Option<f64>,
    pub supports_vision: bool,
    pub supports_function_calling: bool,
}
```

2. Embedding Models: Used for RAG and semantic search
```yaml
- name: text-embedding-3-large
  type: embedding
  input_price: 0.13
  max_tokens_per_chunk: 8191
  default_chunk_size: 2000
  max_batch_size: 100
```

3. Reranker Models: Used to improve search result relevance
```yaml
- name: cohere-rerank-v2-0
  type: reranker
  max_input_tokens: 2048
```

#### Token Management
Tokens are fundamental units that LLMs process. AIChat handles token management in several ways:

```rust
impl Model {
    pub fn total_tokens(&self, messages: &[Message]) -> usize {
        let mut total = 0;
        for msg in messages {
            total += self.count_tokens(&msg.content);
        }
        total
    }

    pub fn guard_max_input_tokens(&self, messages: &[Message]) -> Result<()> {
        if let Some(max_tokens) = self.max_input_tokens() {
            let total = self.total_tokens(messages);
            if total > max_tokens {
                bail!(
                    "Input too long: {} tokens. Maximum is {} tokens.",
                    total,
                    max_tokens
                );
            }
        }
        Ok(())
    }
}
```

### Message Handling System

The message system forms the core of how AIChat communicates with LLMs:

```rust
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Message {
    pub role: MessageRole,
    pub content: MessageContent,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(untagged)]
pub enum MessageContent {
    Text(String),
    Array(Vec<MessageContentPart>),
    ToolResults(ToolResults),
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum MessageRole {
    System,
    User,
    Assistant,
}
```

### Role and Session Management

#### Role System
Roles define how AIChat interacts with LLMs through prompts and configurations:

```rust
pub struct Role {
    name: String,
    prompt: String,
    model_id: Option<String>,
    temperature: Option<f64>,
    top_p: Option<f64>,
    use_tools: Option<String>,
    model: Model,
}
```

Built-in roles include:
- `%shell%`: Generates shell commands
- `%explain-shell%`: Explains shell commands
- `%code%`: Generates code
- `%functions%`: Attaches function declarations

#### Session Management
Sessions maintain conversation state and history:

```rust
pub struct Session {
    model_id: String,
    temperature: Option<f64>,
    top_p: Option<f64>,
    use_tools: Option<String>,
    save_session: Option<bool>,
    compress_threshold: Option<usize>,
    role_name: Option<String>,
    messages: Vec<Message>,
    compressed_messages: Vec<Message>,
}
```

### Stream Handling and Async Operations

AIChat uses asynchronous programming extensively for handling streaming responses:

```rust
pub struct StreamHandler {
    sender: UnboundedSender<SseEvent>,
    abort_signal: AbortSignal,
    buffer: String,
    tool_calls: Vec<ToolCall>,
}

impl StreamHandler {
    pub async fn process_chunk(&mut self, chunk: &str) -> Result<()> {
        self.buffer.push_str(chunk);
        if let Some(message) = self.parse_buffer()? {
            self.sender.send(message)?;
        }
        Ok(())
    }
}
```

### Function Calling Architecture

Function calling allows LLMs to interact with external tools:

```rust
pub struct Functions {
    functions: Vec<FunctionDeclaration>,
    bin_dir: PathBuf,
}

impl Functions {
    pub async fn eval_tool_calls(
        config: &GlobalConfig,
        calls: Vec<ToolCall>,
    ) -> Result<Vec<ToolResult>> {
        let mut results = vec![];
        for call in calls {
            let output = self.execute_tool(&call.name, &call.arguments).await?;
            results.push(ToolResult {
                name: call.name,
                output,
            });
        }
        Ok(results)
    }
}
```

### Security Considerations

AIChat implements several security measures:

1. Path Safety
```rust
fn safe_join_path<T1: AsRef<Path>, T2: AsRef<Path>>(
    base_path: T1,
    sub_path: T2,
) -> Option<PathBuf> {
    let base_path = base_path.as_ref();
    let sub_path = sub_path.as_ref();
    
    let joined_path = base_path.join(sub_path);
    if !joined_path.starts_with(base_path) {
        return None;
    }
    Some(joined_path)
}
```

2. File Permissions
```rust
#[cfg(unix)]
fn set_secure_permissions(path: &Path) -> Result<()> {
    use std::os::unix::fs::PermissionsExt;
    let perms = std::fs::Permissions::from_mode(0o600);
    std::fs::set_permissions(path, perms)?;
    Ok(())
}
```

3. API Key Management
```rust
fn load_api_keys() -> Result<()> {
    let env_file = Config::env_file();
    if !env_file.exists() {
        return Ok(());
    }
    
    // Load keys from environment file
    let contents = read_to_string(&env_file)?;
    for line in contents.lines() {
        if let Some((key, value)) = line.split_once('=') {
            env::set_var(key.trim(), value.trim());
        }
    }
    Ok(())
}
```

### Plugin System Architecture

AIChat supports plugins through the function calling system:

```rust
pub trait Plugin {
    fn name(&self) -> &str;
    fn description(&self) -> &str;
    fn parameters(&self) -> JsonSchema;
    
    async fn execute(&self, args: Value) -> Result<String>;
}
```

### Resource Management

The system implements careful resource management:

1. File Handles
```rust
impl Drop for Session {
    fn drop(&mut self) {
        if let Err(e) = self.cleanup() {
            error!("Failed to cleanup session: {}", e);
        }
    }
}
```

2. Memory Management
```rust
pub fn compress_session(&mut self) -> Result<()> {
    if self.tokens() > self.compress_threshold {
        let summary = self.summarize_messages()?;
        self.compressed_messages.append(&mut self.messages);
        self.messages = vec![Message::new(
            MessageRole::System,
            MessageContent::Text(summary),
        )];
    }
    Ok(())
}
```

### Event System

AIChat implements an event system for handling various operations:

```rust
#[derive(Debug)]
pub enum Event {
    Message(Message),
    ToolCall(ToolCall),
    Error(Error),
    Done,
}

pub struct EventHandler {
    sender: mpsc::UnboundedSender<Event>,
    receiver: mpsc::UnboundedReceiver<Event>,
}
```

### State Management

The system maintains different states through bitflags:

```rust
bitflags::bitflags! {
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    pub struct StateFlags: u32 {
        const ROLE = 1 << 0;
        const SESSION_EMPTY = 1 << 1;
        const SESSION = 1 << 2;
        const RAG = 1 << 3;
        const AGENT = 1 << 4;
    }
}
```

### Dependency Management

AIChat uses several key dependencies:

1. Async Runtime
```toml
[dependencies]
tokio = { version = "1.34.0", features = ["rt", "time", "macros", "signal", "rt-multi-thread"] }
```

2. Serialization
```toml
[dependencies]
serde = { version = "1.0.152", features = ["derive"] }
serde_json = { version = "1.0.93", features = ["preserve_order"] }
serde_yaml = "0.9.17"
```

3. HTTP Client
```toml
[dependencies.reqwest]
version = "0.12.0"
features = ["json", "multipart", "socks", "rustls-tls", "rustls-tls-native-roots"]
default-features = false
```

### Further Resources

1. **Documentation Standards**
   - Inline documentation practices
   - API documentation guidelines
   - Example-driven documentation

2. **Development Environment Setup**
   - IDE configuration
   - Debug configuration
   - Testing environment

3. **Contribution Guidelines**
   - Code style guide
   - Pull request process
   - Issue reporting

4. **Performance Optimization**
   - Token counting optimization
   - Memory usage patterns
   - Async execution strategies

This part completes the foundation by explaining the underlying concepts and architectural decisions that make AIChat a robust and extensible system. Understanding these concepts is crucial for both using the system effectively and contributing to its development.
