# AIChat Lesson 8: Utility Functions and Helper Systems
## Part 6: Practical Examples and Testing Strategies

This section provides practical examples and testing strategies for working with AIChat's utility systems. These examples demonstrate real-world usage and best practices for implementing and testing utility functions.

### Practical Examples

#### 1. File Operation Utilities

Here's a complete example of implementing a safe file handling utility:

```rust
use anyhow::{Context, Result};
use std::path::{Path, PathBuf};

pub struct SafeFileHandler {
    root_dir: PathBuf,
    temp_dir: PathBuf,
}

impl SafeFileHandler {
    pub fn new(root_dir: impl AsRef<Path>) -> Result<Self> {
        let root_dir = root_dir.as_ref().to_path_buf();
        let temp_dir = root_dir.join("temp");
        std::fs::create_dir_all(&temp_dir)
            .context("Failed to create temp directory")?;
            
        Ok(Self { root_dir, temp_dir })
    }
    
    pub fn safe_write(&self, relative_path: &str, content: &[u8]) -> Result<()> {
        // Validate path is within root directory
        let target_path = safe_join_path(&self.root_dir, relative_path)
            .ok_or_else(|| anyhow::anyhow!("Invalid path"))?;
            
        // Create temporary file
        let temp_file = temp_file("-safe-write-", "");
        std::fs::write(&temp_file, content)?;
        
        // Ensure parent directory exists
        if let Some(parent) = target_path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        
        // Atomic move operation
        #[cfg(unix)]
        std::fs::rename(&temp_file, &target_path)?;
        
        #[cfg(windows)]
        {
            if target_path.exists() {
                std::fs::remove_file(&target_path)?;
            }
            std::fs::rename(&temp_file, &target_path)?;
        }
        
        Ok(())
    }
    
    pub fn safe_read(&self, relative_path: &str) -> Result<Vec<u8>> {
        let path = safe_join_path(&self.root_dir, relative_path)
            .ok_or_else(|| anyhow::anyhow!("Invalid path"))?;
            
        std::fs::read(&path).context("Failed to read file")
    }
}

// Example usage:
async fn example_usage() -> Result<()> {
    let handler = SafeFileHandler::new("/app/data")?;
    
    // Safe write operation
    handler.safe_write("configs/app.yaml", b"key: value\n")?;
    
    // Safe read operation
    let content = handler.safe_read("configs/app.yaml")?;
    println!("Read: {}", String::from_utf8_lossy(&content));
    
    Ok(())
}
```

#### 2. Custom Progress Indicator

Implementation of a custom progress indicator with percentage:

```rust
pub struct ProgressTracker {
    spinner: Spinner,
    total: usize,
    current: AtomicUsize,
}

impl ProgressTracker {
    pub async fn new(total: usize, message: &str) -> Self {
        let spinner = create_spinner(message).await;
        Self {
            spinner,
            total,
            current: AtomicUsize::new(0),
        }
    }
    
    pub fn increment(&self) -> Result<()> {
        let current = self.current.fetch_add(1, Ordering::SeqCst) + 1;
        let percentage = (current as f64 / self.total as f64 * 100.0) as usize;
        
        self.spinner.set_message(format!(
            "Progress: [{}/{}] {}%",
            current,
            self.total,
            percentage
        ))?;
        
        Ok(())
    }
}

// Example usage:
async fn process_items(items: Vec<String>) -> Result<()> {
    let progress = ProgressTracker::new(items.len(), "Processing items").await;
    
    for item in items {
        // Process item
        tokio::time::sleep(Duration::from_millis(100)).await;
        progress.increment()?;
    }
    
    Ok(())
}
```

### Testing Strategies

#### 1. Unit Testing Framework

Comprehensive testing framework for utilities:

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Arc;
    use tokio::sync::Mutex;
    
    struct TestContext {
        temp_dir: PathBuf,
        handler: SafeFileHandler,
    }
    
    impl TestContext {
        async fn setup() -> Result<Arc<Mutex<Self>>> {
            let temp_dir = tempdir()?.into_path();
            let handler = SafeFileHandler::new(&temp_dir)?;
            
            Ok(Arc::new(Mutex::new(Self {
                temp_dir,
                handler,
            })))
        }
        
        async fn cleanup(&self) -> Result<()> {
            std::fs::remove_dir_all(&self.temp_dir)?;
            Ok(())
        }
    }
    
    #[tokio::test]
    async fn test_file_operations() -> Result<()> {
        let ctx = TestContext::setup().await?;
        let ctx = ctx.lock().await;
        
        // Test safe write
        ctx.handler.safe_write("test.txt", b"Hello")?;
        
        // Test safe read
        let content = ctx.handler.safe_read("test.txt")?;
        assert_eq!(content, b"Hello");
        
        // Test invalid path
        assert!(ctx.handler.safe_read("../outside.txt").is_err());
        
        ctx.cleanup().await?;
        Ok(())
    }
    
    #[tokio::test]
    async fn test_progress_tracker() -> Result<()> {
        let items = vec!["a", "b", "c"];
        let progress = ProgressTracker::new(items.len(), "Testing").await;
        
        for _ in items {
            progress.increment()?;
        }
        
        assert_eq!(
            progress.current.load(Ordering::SeqCst),
            items.len()
        );
        
        Ok(())
    }
}
```

#### 2. Integration Testing Patterns

Examples of integration tests:

```rust
#[cfg(test)]
mod integration_tests {
    use super::*;
    use test_context::{test_context, TestContext};
    
    struct IntegrationTestContext {
        config: GlobalConfig,
        temp_dir: PathBuf,
    }
    
    #[async_trait]
    impl TestContext for IntegrationTestContext {
        async fn setup() -> Result<Self> {
            let temp_dir = tempdir()?.into_path();
            let config = Config::init_test(&temp_dir)?;
            
            Ok(Self {
                config: Arc::new(RwLock::new(config)),
                temp_dir,
            })
        }
        
        async fn teardown(self) -> Result<()> {
            std::fs::remove_dir_all(self.temp_dir)?;
            Ok(())
        }
    }
    
    #[test_context(IntegrationTestContext)]
    #[tokio::test]
    async fn test_http_operations(ctx: &IntegrationTestContext) -> Result<()> {
        let client = init_client(&ctx.config, None)?;
        
        // Test file download
        let (content, ext) = client
            .fetch(
                &HashMap::new(),
                "https://example.com/test.txt",
                false
            )
            .await?;
            
        assert_eq!(ext, "txt");
        assert!(!content.is_empty());
        
        Ok(())
    }
}
```

### Best Practices for Extension

#### 1. Adding New Utility Functions

When adding new utility functions, follow these patterns:

```rust
// 1. Clear documentation
/// Performs a fuzzy search on text using a pattern.
/// 
/// # Arguments
/// * `text` - The text to search in
/// * `pattern` - The pattern to search for
/// 
/// # Returns
/// `true` if the pattern matches, `false` otherwise
/// 
/// # Examples
/// ```
/// assert!(fuzzy_match("hello world", "hw"));
/// ```
pub fn fuzzy_match(text: &str, pattern: &str) -> bool {
    // Implementation
}

// 2. Error handling with context
pub fn process_file(path: &Path) -> Result<String> {
    let content = std::fs::read_to_string(path)
        .with_context(|| format!("Failed to read file: {}", path.display()))?;
        
    Ok(content)
}

// 3. Configuration integration
pub fn init_utility(config: &GlobalConfig) -> Result<()> {
    let settings = config.read().utility_settings()?;
    // Initialize with settings
    Ok(())
}
```

#### 2. Cross-Platform Compatibility

Ensure cross-platform compatibility in new utilities:

```rust
pub struct PlatformUtils {
    #[cfg(windows)]
    win_specific: WindowsSpecific,
    #[cfg(unix)]
    unix_specific: UnixSpecific,
    common: CommonUtils,
}

impl PlatformUtils {
    pub fn new() -> Result<Self> {
        Ok(Self {
            #[cfg(windows)]
            win_specific: WindowsSpecific::new()?,
            #[cfg(unix)]
            unix_specific: UnixSpecific::new()?,
            common: CommonUtils::new()?,
        })
    }
    
    pub fn platform_path(&self, path: &str) -> String {
        #[cfg(windows)]
        {
            path.replace('/', "\\")
        }
        #[cfg(unix)]
        {
            path.replace('\\', "/")
        }
    }
}
```

### Performance Optimization Patterns

Example of performance optimization strategies:

```rust
pub struct CachedOperation<T> {
    cache: Arc<RwLock<LruCache<String, T>>>,
    compute_fn: Arc<dyn Fn(&str) -> Result<T> + Send + Sync>,
}

impl<T: Clone + Send + Sync + 'static> CachedOperation<T> {
    pub fn new(
        capacity: usize,
        compute_fn: impl Fn(&str) -> Result<T> + Send + Sync + 'static,
    ) -> Self {
        Self {
            cache: Arc::new(RwLock::new(LruCache::new(capacity))),
            compute_fn: Arc::new(compute_fn),
        }
    }
    
    pub fn get(&self, key: &str) -> Result<T> {
        // Try read lock first
        if let Some(value) = self.cache.read().get(key) {
            return Ok(value.clone());
        }
        
        // Compute and cache if missing
        let value = (self.compute_fn)(key)?;
        self.cache.write().put(key.to_string(), value.clone());
        
        Ok(value)
    }
}

// Example usage:
async fn example_caching() -> Result<()> {
    let cached_op = CachedOperation::new(100, |key| {
        // Expensive computation
        Ok(key.to_uppercase())
    });
    
    // First call computes
    let result1 = cached_op.get("test")?;
    // Second call uses cache
    let result2 = cached_op.get("test")?;
    
    assert_eq!(result1, result2);
    Ok(())
}
```

These examples demonstrate practical applications of AIChat's utility systems and provide patterns for testing, extending, and optimizing utility functions. By following these patterns, developers can maintain consistency and reliability while adding new functionality to AIChat.