File: lesson-1-part1.md


# AIChat Lesson 1: Foundation and Core Structure (Part 1)

## Introduction

AIChat is an all-in-one LLM CLI tool featuring Shell Assistant, Chat-REPL, RAG, AI Tools & Agents. This first lesson explores the foundational structure of AIChat, focusing on how the project is organized and how its core components interact. Understanding these foundational elements is crucial for anyone wanting to contribute to or extend the project.

## Project Layout

The core structure of AIChat follows a well-organized layout:

```
src/
├── cli.rs               # Command-line interface definitions
├── function.rs          # Function calling system
├── main.rs             # Application entry point
├── serve.rs            # HTTP server implementation
├── client/             # LLM providers implementations
│   ├── access_token.rs
│   ├── azure_openai.rs
│   ├── bedrock.rs
│   ├── claude.rs
│   ├── cohere.rs
│   └── ...
├── config/             # Configuration management
│   ├── agent.rs
│   ├── input.rs
│   ├── mod.rs
│   ├── role.rs
│   └── session.rs
├── rag/                # Document retrieval system
├── render/             # Output rendering
├── repl/              # Interactive shell
└── utils/             # Utility functions
```

## Core Module Architecture

### Main Entry Point (main.rs)

The heart of AIChat begins in main.rs, which serves as the application's entry point. The main function is annotated with `#[tokio::main]`, indicating this is an async application built on the Tokio runtime. The entry point handles several critical responsibilities:

1. Command-line argument parsing using clap
2. Environment setup including logger initialization
3. Configuration loading and validation
4. Execution mode determination 

Here's how the execution mode is determined:

```rust
let working_mode = if cli.serve.is_some() {
    WorkingMode::Serve
} else if text.is_none() && cli.file.is_empty() {
    WorkingMode::Repl
} else {
    WorkingMode::Cmd
};
```

### Configuration System (config/)

The configuration system is implemented in the config/ directory, with mod.rs serving as the central configuration store. The system follows a hierarchical structure where configurations can be loaded from multiple sources with a clear precedence order:

1. Command-line arguments
2. Environment variables  
3. Configuration files
4. Default values

The Config struct serves as the central configuration store:

```rust
pub struct Config {
    pub model_id: String,
    pub temperature: Option<f64>,
    pub top_p: Option<f64>,
    pub dry_run: bool,
    pub stream: bool,
    pub save: bool,
    pub keybindings: String,
    pub editor: Option<String>,
    // ... additional fields
}
```

### CLI Argument System (cli.rs)

The CLI system provides a robust interface for interacting with AIChat through command line arguments. Key features include:

1. Model selection (`-m`, `--model`)
2. Role selection (`-r`, `--role`)
3. Session management (`-s`, `--session`) 
4. Agent interaction (`-a`, `--agent`)
5. RAG functionality (`-R`, `--rag`)
6. Execution modes (`-e`, `--execute`)
7. Stream control (`-S`, `--no-stream`)

Example usage:
```sh
aichat                                          # Enter REPL
aichat Tell a joke                              # Generate response
aichat -e install nvim                          # Execute command
aichat -c fibonacci in js                       # Generate code
aichat -m openai:gpt-4o                         # Select LLM
aichat -r role1                                 # Use role 'role1'
aichat -s                                       # Begin a temp session
```

### Function Management (function.rs)

The function.rs module implements the infrastructure for function calling capabilities including:

1. Tool call evaluation and deduplication
2. Function declaration management  
3. Cross-platform command execution
4. Security considerations

The module demonstrates advanced Rust patterns like:

```rust
#[derive(Debug, Clone)]
pub struct FunctionDeclaration {
    pub name: String,
    pub description: String,
    pub parameters: JsonSchema,
    pub agent: bool,
}
```

### HTTP Server (serve.rs)

The serve.rs module provides a built-in HTTP server with capabilities for:

1. Chat completions API endpoint
2. Embeddings API endpoint
3. WebSocket handling for streaming
4. Static file serving

To start the server:

```sh
$ aichat --serve
Chat Completions API: http://127.0.0.1:8000/v1/chat/completions
Embeddings API:       http://127.0.0.1:8000/v1/embeddings
LLM Playground:       http://127.0.0.1:8000/playground
LLM Arena:            http://127.0.0.1:8000/arena?num=2
```

## Cross-Platform Considerations 

The codebase implements several strategies to ensure cross-platform compatibility:

### Path Handling
```rust
#[cfg(windows)]
const PATH_SEP: &str = ";";
#[cfg(not(windows))]
const PATH_SEP: &str = ":";
```

### Configuration Directories
```rust
pub fn config_dir() -> PathBuf {
    if let Ok(v) = env::var(get_env_name("config_dir")) {
        PathBuf::from(v)
    } else if let Ok(v) = env::var("XDG_CONFIG_HOME") {
        PathBuf::from(v).join(env!("CARGO_CRATE_NAME"))
    } else {
        dirs::config_dir()
            .expect("No user's config directory")
            .join(env!("CARGO_CRATE_NAME"))
    }
}
```

### Terminal Detection
```rust
#[cfg(target_os = "macos")]
fn is_terminal() -> bool {
    // macOS specific implementation
}

#[cfg(unix)]
fn is_terminal() -> bool {
    // Unix specific implementation  
}

#[cfg(windows)] 
fn is_terminal() -> bool {
    // Windows specific implementation
}
```
















File: lesson-1-part2.md


# AIChat Lesson 1: Foundation and Core Structure (Part 2)

## Configuration System Deep Dive

### Config File Locations

The configuration file location follows platform-specific conventions:

- Windows: `C:\Users\Alice\AppData\Roaming\aichat\config.yaml`
- macOS: `/Users/Alice/Library/Application Support/aichat/config.yaml`  
- Linux: `/home/alice/.config/aichat/config.yaml`

### Configuration File Structure

The configuration file uses YAML format and supports extensive customization:

```yaml
# LLM settings
model: openai:gpt-4o
temperature: null
top_p: null

# Behavior settings
stream: true
save: true
keybindings: emacs
editor: null
wrap: no
wrap_code: false

# Function calling settings
function_calling: true
mapping_tools:
  fs: 'fs_cat,fs_ls,fs_mkdir,fs_rm,fs_write'
use_tools: null

# Session settings  
save_session: null
compress_threshold: 4000

# RAG settings
rag_embedding_model: null
rag_reranker_model: null
rag_top_k: 4
```

### Environment Variables

The system supports configuration through environment variables with a consistent naming scheme:

```sh
AICHAT_MODEL=openai:gpt-4o
AICHAT_TEMPERATURE=0.7
AICHAT_STREAM=false
```

All config items can be overridden through environment variables following the pattern `AICHAT_<KEY>`.

## Error Handling System

AIChat implements comprehensive error handling using anyhow:

### Error Context Propagation

```rust
fn setup_logger() -> Result<()> {
    let (log_level, log_path) = Config::log_config()?;
    
    if log_level == LevelFilter::Off {
        return Ok(());
    }

    // Error handling with context
    let config = LoggerConfig::new()
        .with_context(|| "Failed to initialize logger")?;
        
    Ok(())
}
```

### Custom Error Creation
```rust
if !validate_command(cmd) {
    bail!("Unable to run {cmd_name}, {err}")
}
```

## Module Organization

### Core Components:

1. **Client Layer**: Handles communication with various LLM providers
   - Located in `client/` directory
   - Implements provider-specific APIs
   - Manages authentication and rate limiting

2. **Configuration Management**: Handles all configuration aspects
   - Located in `config/` directory
   - Manages user preferences
   - Handles session state

3. **RAG System**: Manages document retrieval and embeddings
   - Located in `rag/` directory
   - Handles document processing
   - Manages vector storage

4. **Rendering System**: Handles output formatting
   - Located in `render/` directory
   - Manages terminal output
   - Handles syntax highlighting

5. **REPL System**: Provides interactive shell
   - Located in `repl/` directory
   - Manages command history
   - Handles auto-completion

## Practical Examples

### Basic Usage Examples

1. Command Line Interface:
```sh
# Generate a response
aichat "What is the capital of France?"

# Use a specific model
aichat -m openai:gpt-4o "Tell me a joke"

# Execute a shell command
aichat -e "create a new directory named src"

# Start a session
aichat -s mysession
```

2. REPL Commands:
```sh
# Show help
.help

# Change model
.model gpt-4

# Create/switch role
.role python-expert

# Start session
.session coding

# Use RAG
.rag docs
```

### Configuration Example:

```yaml
# config.yaml
model: openai:gpt-4o
temperature: 0.7
stream: true
save: true

clients:
  - type: openai
    api_key: xxx
    organization_id: org-xxx
    
  - type: anthropic
    api_key: xxx
```

## Shell Integration

AIChat provides shell integration scripts for various shells:

```bash
# Bash integration
source /path/to/aichat/scripts/shell-integration/integration.bash

# Zsh integration  
source /path/to/aichat/scripts/shell-integration/integration.zsh

# Fish integration
source /path/to/aichat/scripts/shell-integration/integration.fish
```

## Testing Strategy

AIChat uses a comprehensive testing approach:

1. Unit Tests:
```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_config_loading() {
        let config = Config::load_from_file("test_config.yaml");
        assert!(config.is_ok());
    }
}
```

2. Integration Tests:
```rust
#[tokio::test]
async fn test_chat_completion() {
    let config = test_utils::create_test_config();
    let client = config.create_client().unwrap();
    let response = client.chat_completions("test").await;
    assert!(response.is_ok());
}
```

## Best Practices

1. Error Handling:
   - Use anyhow::Result for flexible error handling
   - Provide context with .with_context()
   - Use structured error types where appropriate

2. Cross-Platform Compatibility:
   - Use cfg attributes for platform-specific code
   - Abstract platform differences behind common interfaces
   - Test on all supported platforms

3. Configuration Management:
   - Follow hierarchical configuration loading
   - Support environment variable overrides
   - Provide sensible defaults

4. Code Organization:
   - Keep related functionality together
   - Use clear naming conventions
   - Maintain consistent error handling patterns

## Exercises

1. Create a new configuration file:
```rust
fn create_config() -> Result<Config> {
    let config = Config {
        model_id: "openai:gpt-4".to_string(),
        temperature: Some(0.7),
        stream: true,
        save: true,
        ..Default::default()
    };
    Ok(config)
}
```

2. Implement cross-platform path handling:
```rust
fn normalize_path(path: &Path) -> Result<PathBuf> {
    // Implementation exercise
    // Handle Windows vs Unix paths
    // Expand home directory
    // Validate path safety
}
```

These exercises will help reinforce understanding of the core concepts while providing practical experience with the codebase.

## Conclusion

Understanding AIChat's foundational structure is crucial for both using and extending the application. The system's design provides a robust and user-friendly interface while maintaining cross-platform compatibility and extensibility. The next lesson will explore the client abstraction layer, building on this foundational knowledge.

## Additional Resources

1. Rust standard library documentation
2. Cross-platform Rust guidelines
3. Error handling patterns
4. Terminal manipulation guides
5. Async programming patterns
6. State management strategies

This comprehensive foundation will enable developers to effectively work with and contribute to the AIChat codebase.















File: lesson-1-part3.md


# AIChat Lesson 1: Foundation and Core Structure (Part 3)
## Core Concepts & Additional Details

### Understanding the LLM Integration Concepts

#### Model Types and Capabilities
AIChat works with different types of Large Language Models (LLMs) which have distinct capabilities:

1. Chat Models: Used for conversation and text generation
```rust
pub struct Model {
    client_name: String,
    data: ModelData,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModelData {
    pub name: String,
    pub model_type: String,
    pub max_input_tokens: Option<usize>,
    pub input_price: Option<f64>,
    pub output_price: Option<f64>,
    pub supports_vision: bool,
    pub supports_function_calling: bool,
}
```

2. Embedding Models: Used for RAG and semantic search
```yaml
- name: text-embedding-3-large
  type: embedding
  input_price: 0.13
  max_tokens_per_chunk: 8191
  default_chunk_size: 2000
  max_batch_size: 100
```

3. Reranker Models: Used to improve search result relevance
```yaml
- name: cohere-rerank-v2-0
  type: reranker
  max_input_tokens: 2048
```

#### Token Management
Tokens are fundamental units that LLMs process. AIChat handles token management in several ways:

```rust
impl Model {
    pub fn total_tokens(&self, messages: &[Message]) -> usize {
        let mut total = 0;
        for msg in messages {
            total += self.count_tokens(&msg.content);
        }
        total
    }

    pub fn guard_max_input_tokens(&self, messages: &[Message]) -> Result<()> {
        if let Some(max_tokens) = self.max_input_tokens() {
            let total = self.total_tokens(messages);
            if total > max_tokens {
                bail!(
                    "Input too long: {} tokens. Maximum is {} tokens.",
                    total,
                    max_tokens
                );
            }
        }
        Ok(())
    }
}
```

### Message Handling System

The message system forms the core of how AIChat communicates with LLMs:

```rust
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Message {
    pub role: MessageRole,
    pub content: MessageContent,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(untagged)]
pub enum MessageContent {
    Text(String),
    Array(Vec<MessageContentPart>),
    ToolResults(ToolResults),
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum MessageRole {
    System,
    User,
    Assistant,
}
```

### Role and Session Management

#### Role System
Roles define how AIChat interacts with LLMs through prompts and configurations:

```rust
pub struct Role {
    name: String,
    prompt: String,
    model_id: Option<String>,
    temperature: Option<f64>,
    top_p: Option<f64>,
    use_tools: Option<String>,
    model: Model,
}
```

Built-in roles include:
- `%shell%`: Generates shell commands
- `%explain-shell%`: Explains shell commands
- `%code%`: Generates code
- `%functions%`: Attaches function declarations

#### Session Management
Sessions maintain conversation state and history:

```rust
pub struct Session {
    model_id: String,
    temperature: Option<f64>,
    top_p: Option<f64>,
    use_tools: Option<String>,
    save_session: Option<bool>,
    compress_threshold: Option<usize>,
    role_name: Option<String>,
    messages: Vec<Message>,
    compressed_messages: Vec<Message>,
}
```

### Stream Handling and Async Operations

AIChat uses asynchronous programming extensively for handling streaming responses:

```rust
pub struct StreamHandler {
    sender: UnboundedSender<SseEvent>,
    abort_signal: AbortSignal,
    buffer: String,
    tool_calls: Vec<ToolCall>,
}

impl StreamHandler {
    pub async fn process_chunk(&mut self, chunk: &str) -> Result<()> {
        self.buffer.push_str(chunk);
        if let Some(message) = self.parse_buffer()? {
            self.sender.send(message)?;
        }
        Ok(())
    }
}
```

### Function Calling Architecture

Function calling allows LLMs to interact with external tools:

```rust
pub struct Functions {
    functions: Vec<FunctionDeclaration>,
    bin_dir: PathBuf,
}

impl Functions {
    pub async fn eval_tool_calls(
        config: &GlobalConfig,
        calls: Vec<ToolCall>,
    ) -> Result<Vec<ToolResult>> {
        let mut results = vec![];
        for call in calls {
            let output = self.execute_tool(&call.name, &call.arguments).await?;
            results.push(ToolResult {
                name: call.name,
                output,
            });
        }
        Ok(results)
    }
}
```

### Security Considerations

AIChat implements several security measures:

1. Path Safety
```rust
fn safe_join_path<T1: AsRef<Path>, T2: AsRef<Path>>(
    base_path: T1,
    sub_path: T2,
) -> Option<PathBuf> {
    let base_path = base_path.as_ref();
    let sub_path = sub_path.as_ref();
    
    let joined_path = base_path.join(sub_path);
    if !joined_path.starts_with(base_path) {
        return None;
    }
    Some(joined_path)
}
```

2. File Permissions
```rust
#[cfg(unix)]
fn set_secure_permissions(path: &Path) -> Result<()> {
    use std::os::unix::fs::PermissionsExt;
    let perms = std::fs::Permissions::from_mode(0o600);
    std::fs::set_permissions(path, perms)?;
    Ok(())
}
```

3. API Key Management
```rust
fn load_api_keys() -> Result<()> {
    let env_file = Config::env_file();
    if !env_file.exists() {
        return Ok(());
    }
    
    // Load keys from environment file
    let contents = read_to_string(&env_file)?;
    for line in contents.lines() {
        if let Some((key, value)) = line.split_once('=') {
            env::set_var(key.trim(), value.trim());
        }
    }
    Ok(())
}
```

### Plugin System Architecture

AIChat supports plugins through the function calling system:

```rust
pub trait Plugin {
    fn name(&self) -> &str;
    fn description(&self) -> &str;
    fn parameters(&self) -> JsonSchema;
    
    async fn execute(&self, args: Value) -> Result<String>;
}
```

### Resource Management

The system implements careful resource management:

1. File Handles
```rust
impl Drop for Session {
    fn drop(&mut self) {
        if let Err(e) = self.cleanup() {
            error!("Failed to cleanup session: {}", e);
        }
    }
}
```

2. Memory Management
```rust
pub fn compress_session(&mut self) -> Result<()> {
    if self.tokens() > self.compress_threshold {
        let summary = self.summarize_messages()?;
        self.compressed_messages.append(&mut self.messages);
        self.messages = vec![Message::new(
            MessageRole::System,
            MessageContent::Text(summary),
        )];
    }
    Ok(())
}
```

### Event System

AIChat implements an event system for handling various operations:

```rust
#[derive(Debug)]
pub enum Event {
    Message(Message),
    ToolCall(ToolCall),
    Error(Error),
    Done,
}

pub struct EventHandler {
    sender: mpsc::UnboundedSender<Event>,
    receiver: mpsc::UnboundedReceiver<Event>,
}
```

### State Management

The system maintains different states through bitflags:

```rust
bitflags::bitflags! {
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    pub struct StateFlags: u32 {
        const ROLE = 1 << 0;
        const SESSION_EMPTY = 1 << 1;
        const SESSION = 1 << 2;
        const RAG = 1 << 3;
        const AGENT = 1 << 4;
    }
}
```

### Dependency Management

AIChat uses several key dependencies:

1. Async Runtime
```toml
[dependencies]
tokio = { version = "1.34.0", features = ["rt", "time", "macros", "signal", "rt-multi-thread"] }
```

2. Serialization
```toml
[dependencies]
serde = { version = "1.0.152", features = ["derive"] }
serde_json = { version = "1.0.93", features = ["preserve_order"] }
serde_yaml = "0.9.17"
```

3. HTTP Client
```toml
[dependencies.reqwest]
version = "0.12.0"
features = ["json", "multipart", "socks", "rustls-tls", "rustls-tls-native-roots"]
default-features = false
```

### Further Resources

1. **Documentation Standards**
   - Inline documentation practices
   - API documentation guidelines
   - Example-driven documentation

2. **Development Environment Setup**
   - IDE configuration
   - Debug configuration
   - Testing environment

3. **Contribution Guidelines**
   - Code style guide
   - Pull request process
   - Issue reporting

4. **Performance Optimization**
   - Token counting optimization
   - Memory usage patterns
   - Async execution strategies

This part completes the foundation by explaining the underlying concepts and architectural decisions that make AIChat a robust and extensible system. Understanding these concepts is crucial for both using the system effectively and contributing to its development.
















File: lesson-2-part1.md


# AIChat Lesson 2: Client Abstraction Layer (Part 1)

## Introduction

The client abstraction layer in AIChat forms the core interface between the application and various LLM providers. This implementation serves as an excellent example of how to design a flexible, maintainable system that can adapt to multiple service providers while maintaining a consistent interface. This lesson will explore the design, implementation, and best practices used in AIChat's client abstraction layer.

## Directory Structure

The client abstraction layer is primarily implemented in the `src/client` directory with the following structure:

```
src/client/
├── access_token.rs     # Token management for APIs requiring auth tokens
├── azure_openai.rs     # Azure OpenAI API implementation
├── bedrock.rs         # AWS Bedrock API implementation
├── claude.rs          # Anthropic Claude API implementation
├── cohere.rs         # Cohere API implementation
├── common.rs         # Shared interfaces and utilities
├── ernie.rs          # Baidu ERNIE API implementation
├── gemini.rs         # Google Gemini API implementation
├── macros.rs         # Shared macros for client implementations
├── message.rs        # Message handling and formatting
├── mod.rs           # Module definitions and registration
├── model.rs         # Model management and capabilities
├── openai.rs        # OpenAI API implementation
├── openai_compatible.rs  # OpenAI-compatible API implementations
├── stream.rs       # Streaming response handling
└── vertexai.rs    # Google VertexAI API implementation
```

## Core Architecture

The client abstraction layer is built around the `Client` trait defined in `common.rs`, which provides the foundation for all provider implementations:

```rust
#[async_trait::async_trait]
pub trait Client: Sync + Send {
    fn global_config(&self) -> &GlobalConfig;
    fn extra_config(&self) -> Option<&ExtraConfig>;
    fn patch_config(&self) -> Option<&RequestPatch>;
    fn name(&self) -> &str;
    fn model(&self) -> &Model;
    fn model_mut(&mut self) -> &mut Model;

    async fn chat_completions(&self, input: Input) -> Result<ChatCompletionsOutput>;
    async fn chat_completions_streaming(&self, input: &Input, handler: &mut SseHandler) -> Result<()>;
    async fn embeddings(&self, data: &EmbeddingsData) -> Result<Vec<Vec<f32>>>;
    async fn rerank(&self, data: &RerankData) -> Result<RerankOutput>;
}
```

This design follows several key architectural principles:

1. **Unified Interface**: All providers implement the same trait, ensuring consistent behavior across different services.

2. **Async Support**: The trait uses Rust's async/await syntax for handling asynchronous operations.

3. **Error Handling**: Comprehensive error handling using Rust's Result type with anyhow for flexible error types.

4. **Configuration Management**: Structured configuration handling with support for global and provider-specific settings.

## Message Handling System

The message handling system in `message.rs` provides a robust way to handle different types of messages:

```rust
pub struct Message {
    pub role: MessageRole,
    pub content: MessageContent,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(untagged)]
pub enum MessageContent {
    Text(String),
    Array(Vec<MessageContentPart>),
    ToolResults(ToolResults),
}
```

This system supports:

1. Plain text messages
2. Multi-modal content (text + images)
3. Tool results from function calling
4. System messages and role-based content

## Model Management

The model system in `model.rs` handles different LLM capabilities and configurations:

```rust
pub struct Model {
    client_name: String,
    data: ModelData,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModelData {
    pub name: String,
    pub model_type: String,
    pub max_input_tokens: Option<usize>,
    pub input_price: Option<f64>,
    pub output_price: Option<f64>,
    // ... additional fields
}
```

The model system provides:

1. Token limit management
2. Pricing information
3. Capability detection (vision, function calling)
4. Cross-platform model compatibility

## Provider Implementation Pattern

Each provider implementation follows a consistent pattern demonstrated in the OpenAI implementation (openai.rs):

```rust
impl_client_trait!(
    OpenAIClient,
    (
        prepare_chat_completions,
        openai_chat_completions,
        openai_chat_completions_streaming
    ),
    (prepare_embeddings, openai_embeddings),
    (noop_prepare_rerank, noop_rerank),
);
```

This pattern ensures:

1. Consistent implementation across providers
2. Reusable code through macros
3. Clear separation of concerns
4. Easy addition of new capabilities

## Error Handling System

The error handling system is designed to handle various API-specific errors and convert them into consistent formats:

```rust
pub fn catch_error(data: &Value, status: u16) -> Result<()> {
    if (200..300).contains(&status) {
        return Ok(());
    }
    debug!("Invalid response, status: {status}, data: {data}");
    // ... error handling logic
}
```

This system provides:

1. Unified error reporting
2. Detailed debug information
3. Provider-specific error mapping
4. Consistent error handling patterns

[Continued in Part 2]
















File: lesson-2-part2.md


# AIChat Lesson 2: Client Abstraction Layer (Part 2)

## Platform Support and Integration

AIChat's client abstraction layer supports over 20 different LLM platforms through a unified interface. The platform support is implemented through a combination of direct implementations and OpenAI-compatible implementations:

### Direct Implementations:
- OpenAI
- Claude (Anthropic)
- Gemini (Google)
- Cohere
- Azure OpenAI
- VertexAI
- Bedrock (AWS)
- Ernie (Baidu)

### OpenAI-Compatible Implementations:
The system supports numerous OpenAI-compatible platforms through a shared implementation:

```rust
pub const OPENAI_COMPATIBLE_PLATFORMS: [(&str, &str); 22] = [
    ("ai21", "https://api.ai21.com/studio/v1"),
    ("cloudflare", ""),
    ("deepinfra", "https://api.deepinfra.com/v1/openai"),
    // ... additional platforms
];
```

## Configuration System

The configuration system provides a flexible way to configure different providers:

```yaml
clients:
  - type: openai
    api_base: https://api.openai.com/v1
    api_key: xxx
    models:
      - name: gpt-4o
        max_input_tokens: 128000
        supports_vision: true
        supports_function_calling: true
```

Key features include:

1. **Environment Variable Support**: Configuration can be overridden through environment variables
2. **Proxy Support**: Built-in support for SOCKS and HTTP proxies
3. **Model Configuration**: Detailed model capabilities and limits
4. **API Request Customization**: Request patching capabilities

## Streaming Implementation

The streaming system in `stream.rs` provides robust handling of streaming responses:

```rust
pub struct SseHandler {
    sender: UnboundedSender<SseEvent>,
    abort_signal: AbortSignal,
    buffer: String,
    tool_calls: Vec<ToolCall>,
}
```

This implementation supports:

1. Server-Sent Events (SSE)
2. Function calling in streams
3. Graceful error handling
4. Abort capabilities

## Cross-Platform Considerations

The client abstraction layer handles various cross-platform considerations:

### Token Management
```rust
pub fn token_count(&self, messages: &[Message]) -> usize {
    let num_messages = messages.len();
    let message_tokens = self.messages_tokens(messages);
    // ... token counting logic
}
```

### Request Building
```rust
pub fn build_request(&self, client: &ReqwestClient) -> Result<RequestBuilder> {
    let mut builder = client.request(self.method.clone(), &self.url);
    // ... cross-platform request building
}
```

### Error Handling
```rust
pub fn normalize_error(err: Error) -> Error {
    match err {
        Error::Http(e) => Error::Http(normalize_http_error(e)),
        // ... error normalization
    }
}
```

## Usage Examples

Here are some practical examples of using the client abstraction layer:

### Basic Chat Completion
```rust
let client = init_client(&config, None)?;
let response = client.chat_completions(input).await?;
println!("{}", response.text);
```

### Streaming Chat
```rust
let mut handler = SseHandler::new(tx, abort_signal);
client.chat_completions_streaming(&input, &mut handler).await?;
```

### Embeddings Generation
```rust
let embeddings = client.embeddings(&EmbeddingsData {
    texts: vec!["Sample text".to_string()],
    query: false,
}).await?;
```

## Testing Strategy

The testing approach for the client abstraction layer includes:

1. **Unit Tests**: Testing individual components and utilities
2. **Integration Tests**: Testing complete client implementations
3. **Mock Implementations**: Testing without actual API calls
4. **Cross-Platform Testing**: Ensuring compatibility

Example test:
```rust
#[tokio::test]
async fn test_chat_completion() {
    let mock_client = MockClient::new();
    let response = mock_client.chat_completions(test_input()).await;
    assert!(response.is_ok());
}
```

## Best Practices

When working with the client abstraction layer:

1. **Error Handling**: Always use the provided error handling utilities for consistent error reporting.
2. **Configuration**: Use the configuration system rather than hardcoding values.
3. **Testing**: Implement thorough tests for new providers.
4. **Documentation**: Maintain clear documentation of provider-specific behaviors.
5. **Cross-Platform**: Consider platform-specific differences in implementations.

## Exercises

1. **Implement a New Provider**
   - Create a new provider implementation
   - Handle authentication
   - Implement streaming
   - Add comprehensive tests

2. **Extend Existing Provider**
   - Add new model support
   - Implement additional capabilities
   - Update configuration handling
   - Add test coverage

3. **Create Mock Implementation**
   - Implement mock responses
   - Test error conditions
   - Verify streaming behavior
   - Test cross-platform compatibility

## Conclusion

AIChat's client abstraction layer demonstrates sophisticated software design patterns while maintaining flexibility and usability. Understanding these systems provides valuable insights into building complex, cross-platform CLI applications with AI integration.

The key takeaways include:
- Clean, maintainable architecture
- Robust error handling
- Flexible configuration
- Comprehensive platform support
- Strong testing practices

This knowledge enables developers to:
- Implement new providers effectively
- Debug integration issues
- Ensure cross-platform compatibility
- Maintain code quality
- Contribute meaningfully to AIChat
















File: lesson-2-part3.md


# AIChat Lesson 2: Client Abstraction Layer (Part 3) - Core Concepts & Additional Details

## Foundation Concepts

### Async Programming in Rust

The client abstraction layer makes heavy use of Rust's async/await syntax. Here are the key concepts:

1. **Async Trait**
```rust
#[async_trait::async_trait]
pub trait Client: Sync + Send {
    async fn chat_completions(&self, input: Input) -> Result<ChatCompletionsOutput>;
    // ...
}
```
The `async_trait` attribute is necessary because Rust doesn't natively support async functions in traits. This macro generates the necessary code to make async functions work in traits.

2. **Tokio Runtime**
AIChat uses the Tokio runtime for async operations:
```rust
#[tokio::main]
async fn main() {
    // Application entry point
}
```

### Token Management

Token management is a crucial concept in LLM interactions. Tokens are the basic units that LLMs process:

```rust
pub struct Model {
    // ...
    pub fn messages_tokens(&self, messages: &[Message]) -> usize {
        messages
            .iter()
            .map(|v| match &v.content {
                MessageContent::Text(text) => estimate_token_length(text),
                MessageContent::Array(_) => 0,
                MessageContent::ToolResults(_) => 0,
            })
            .sum()
    }
}
```

Key aspects include:
1. Token counting for rate limiting
2. Token estimation for cost calculation
3. Message compression for token limits
4. Token budget management

## Stream Processing Details

### Event Stream Handling

The Server-Sent Events (SSE) implementation is more complex than initially presented:

```rust
pub struct JsonStreamParser {
    buffer: Vec<char>,
    cursor: usize,
    start: Option<usize>,
    balances: Vec<char>,
    quoting: bool,
    escape: bool,
}

impl JsonStreamParser {
    fn process<F>(&mut self, text: &str, handle: &mut F) -> Result<()>
    where
        F: FnMut(&str) -> Result<()> {
        // Complex JSON stream parsing logic
    }
}
```

This parser handles:
1. Partial JSON messages
2. Proper escaping
3. Nested structures
4. Error recovery

### Abort Signal Mechanism

The abort signal system provides graceful cancellation:

```rust
pub struct AbortSignalInner {
    ctrlc: AtomicBool,
    ctrld: AtomicBool,
}

impl AbortSignal {
    pub fn abort(&self) {
        self.0.ctrlc.store(true, Ordering::SeqCst);
    }
}
```

## Authentication and Authorization

### Access Token Management

The system includes sophisticated token management:

```rust
lazy_static::lazy_static! {
    static ref ACCESS_TOKENS: RwLock<IndexMap<String, (String, i64)>> =
        RwLock::new(IndexMap::new());
}

pub fn set_access_token(client_name: &str, token: String, expires_at: i64) {
    let mut access_tokens = ACCESS_TOKENS.write();
    let entry = access_tokens.entry(client_name.to_string()).or_default();
    entry.0 = token;
    entry.1 = expires_at;
}
```

Features include:
1. Token caching
2. Expiration handling
3. Thread-safe access
4. Automatic renewal

## Advanced Configuration Features

### Request Patching

The request patching system allows modification of API requests:

```rust
pub struct RequestPatch {
    pub chat_completions: Option<ApiPatch>,
    pub embeddings: Option<ApiPatch>,
    pub rerank: Option<ApiPatch>,
}

impl RequestData {
    pub fn apply_patch(&mut self, patch: Value) {
        if let Some(patch_url) = patch["url"].as_str() {
            self.url = patch_url.into();
        }
        if let Some(patch_body) = patch.get("body") {
            json_patch::merge(&mut self.body, patch_body)
        }
        // ...
    }
}
```

This system enables:
1. URL modification
2. Header injection
3. Body transformation
4. Per-model customization

## Error Handling Depth

### Error Context Chain

The error handling system maintains error context:

```rust
pub fn catch_error(data: &Value, status: u16) -> Result<()> {
    if let Some(error) = data["error"].as_object() {
        if let (Some(typ), Some(message)) = (
            json_str_from_map(error, "type"),
            json_str_from_map(error, "message"),
        ) {
            bail!("{message} (type: {typ})");
        }
    }
    // Additional error handling...
}
```

Features include:
1. Status code mapping
2. Error type preservation
3. Provider-specific error handling
4. Error context propagation

## Cross-Platform Details

### Platform-Specific Paths

```rust
#[cfg(not(windows))]
fn default_adc_file() -> Option<PathBuf> {
    let mut path = dirs::home_dir()?;
    path.push(".config");
    path.push("gcloud");
    path.push("application_default_credentials.json");
    Some(path)
}

#[cfg(windows)]
fn default_adc_file() -> Option<PathBuf> {
    let mut path = dirs::config_dir()?;
    path.push("gcloud");
    path.push("application_default_credentials.json");
    Some(path)
}
```

### Network Handling

```rust
fn set_proxy(
    builder: reqwest::ClientBuilder,
    proxy: Option<&String>,
) -> Result<reqwest::ClientBuilder> {
    let proxy = if let Some(proxy) = proxy {
        if proxy.is_empty() || proxy == "-" {
            return Ok(builder);
        }
        proxy.clone()
    } else if let Some(proxy) = ["HTTPS_PROXY", "https_proxy", "ALL_PROXY", "all_proxy"]
        .into_iter()
        .find_map(|v| env::var(v).ok())
    {
        proxy
    } else {
        return Ok(builder);
    };
    Ok(builder.proxy(reqwest::Proxy::all(&proxy)?))
}
```

## Model Management Details

### Model Capabilities

```rust
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModelData {
    pub name: String,
    pub model_type: String,
    pub max_input_tokens: Option<usize>,
    pub input_price: Option<f64>,
    pub output_price: Option<f64>,
    pub max_output_tokens: Option<isize>,
    pub require_max_tokens: bool,
    pub supports_vision: bool,
    pub supports_function_calling: bool,
    pub no_stream: bool,
    pub no_system_message: bool,
    pub max_tokens_per_chunk: Option<usize>,
    pub default_chunk_size: Option<usize>,
    pub max_batch_size: Option<usize>,
}
```

This comprehensive structure handles:
1. Token limits
2. Pricing information
3. Feature support
4. Batch processing
5. Model constraints

## Testing Considerations

### Mocking Complex Responses

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[tokio::test]
    async fn test_stream_parsing() {
        let chunks = vec![
            Ok(Bytes::from(r#"{"id":"1","choices":[{"delta":{"content":"Hello"}}]}"#)),
            Ok(Bytes::from(r#"{"id":"1","choices":[{"delta":{"content":" World"}}]}"#)),
        ];
        let stream = stream::iter(chunks);
        let mut output = String::new();
        
        json_stream(stream, |data| {
            let parsed: Value = serde_json::from_str(data)?;
            if let Some(content) = parsed["choices"][0]["delta"]["content"].as_str() {
                output.push_str(content);
            }
            Ok(())
        })
        .await
        .unwrap();
        
        assert_eq!(output, "Hello World");
    }
}
```

This demonstrates:
1. Stream simulation
2. Async testing
3. Error handling testing
4. Response validation

## Additional Best Practices

### Rate Limiting
While not directly implemented, the system supports rate limiting through the configuration system:

```rust
pub struct ExtraConfig {
    pub proxy: Option<String>,
    pub connect_timeout: Option<u64>,
    // Can be extended with rate limiting configuration
}
```

### Retry Logic
The system includes basic retry capability through the request builder:

```rust
fn build_client(&self) -> Result<ReqwestClient> {
    let mut builder = ReqwestClient::builder();
    let extra = self.extra_config();
    let timeout = extra.and_then(|v| v.connect_timeout).unwrap_or(10);
    // ... additional client configuration
}
```

## Exercises

1. **Token Management Implementation**
   - Implement a token counting system
   - Handle different model token limits
   - Add token usage tracking
   - Implement token-based cost calculation

2. **Stream Parser Enhancement**
   - Add support for new response formats
   - Implement error recovery
   - Add timeout handling
   - Implement backpressure

3. **Authentication System**
   - Implement a new auth method
   - Add token refresh logic
   - Handle auth failures
   - Add rate limiting

These exercises help reinforce the underlying concepts and provide practical experience with the system's more complex aspects.
















File: lesson-3-part1.md


# AIChat Lesson 3: Configuration and State Management - Part 1
## Core Concepts and Architecture 

### File Structure

The configuration and state management system in AIChat is organized across multiple files in the `config` directory:

```
src/config/
├── mod.rs           # Main configuration module with core implementation
├── agent.rs         # Agent-specific configuration handling
├── input.rs         # Input processing and management
├── role.rs          # Role-based configuration
└── session.rs       # Session state management 
```

### Core Configuration Architecture

The configuration system in AIChat follows a layered architecture that provides flexibility while maintaining strict control over state. At its heart is the `Config` struct defined in `mod.rs`, which serves as the central configuration store and manages:

- Model selection and parameters
- Runtime behaviors and flags
- User preferences
- Feature toggles
- State tracking
- File paths and persistence

One of the key design choices is the use of a thread-safe global configuration through the `GlobalConfig` type:

```rust
pub type GlobalConfig = Arc<RwLock<Config>>;
```

This allows for safe concurrent access while providing atomic state updates across the application.

### Configuration Sources and Precedence

AIChat implements a sophisticated configuration loading system with clear precedence rules:

1. Command-line arguments (highest priority)
2. Environment variables 
3. Configuration files
4. Default values (lowest priority)

The configuration file is typically located at:
- Linux: `~/.config/aichat/config.yaml`
- macOS: `~/Library/Application Support/aichat/config.yaml` 
- Windows: `C:\Users\<User>\AppData\Roaming\aichat\config.yaml`

The system supports dynamic configuration through environment variables following a consistent naming pattern:
```rust
pub fn get_env_name(key: &str) -> String {
    format!("{}_{}", env!("CARGO_CRATE_NAME"), key).to_ascii_uppercase()
}
```

### State Management Overview

AIChat maintains several types of state:

1. Global State
   - Model configuration
   - Runtime flags
   - Feature toggles
   - User preferences

2. Session State
   - Conversation history
   - Message tracking
   - Token usage
   - Compression state

3. Role State
   - Model parameters
   - Temperature settings
   - Prompt templates
   - Tool configurations

4. Agent State
   - Tool configurations
   - Variable states
   - Document contexts
   - Function permissions

The state management system is designed around the following principles:

1. State Isolation: Different types of state are kept separate to prevent interference and maintain clean boundaries between features.

2. State Synchronization: Changes to state are propagated appropriately between components when needed:
```rust
impl Config {
    pub fn sync(&mut self, other: &Config) {
        self.model = other.model.clone();
        self.temperature = other.temperature;
        self.top_p = other.top_p;
        // Additional synchronization
    }
}
```

3. State Persistence: The system handles saving and loading state appropriately, with clear rules about what should be persisted and when.

4. State Access Control: The use of RwLock ensures thread-safe access to global state:
```rust
pub type GlobalConfig = Arc<RwLock<Config>>;
```

### Core Configuration Fields

Some of the key configuration fields managed by the system include:

```rust
pub struct Config {
    // Model Configuration
    pub model_id: String,
    pub temperature: Option<f64>,
    pub top_p: Option<f64>,

    // Runtime Behavior
    pub dry_run: bool,
    pub stream: bool,
    pub save: bool,

    // User Interface
    pub keybindings: String,
    pub editor: Option<String>,
    pub wrap: Option<String>,

    // Feature Toggles
    pub function_calling: bool,
    pub highlight: bool,

    // State Tracking
    pub role: Option<Role>,
    pub session: Option<Session>,
    pub rag: Option<Arc<Rag>>,
    pub agent: Option<Agent>,
}
```

### Error Handling Philosophy

The configuration system implements comprehensive error handling using Rust's Result type:

```rust
pub fn init(working_mode: WorkingMode) -> Result<Self> {
    let config_path = Self::config_file();
    let mut config = if !config_path.exists() {
        match env::var(get_env_name("platform")) {
            Ok(v) => Self::load_dynamic(&v)?,
            Err(_) => {
                if *IS_STDOUT_TERMINAL {
                    create_config_file(&config_path)?;
                }
                Self::load_from_file(&config_path)?
            }
        }
    } else {
        Self::load_from_file(&config_path)?
    };
    // Configuration initialization
    Ok(config)
}
```

This ensures that configuration errors are caught early and handled appropriately.

### Understanding State Flags

The system uses bitflags to track different states:

```rust
bitflags::bitflags! {
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    pub struct StateFlags: u32 {
        const ROLE = 1 << 0;
        const SESSION_EMPTY = 1 << 1;
        const SESSION = 1 << 2;
        const RAG = 1 << 3;
        const AGENT = 1 << 4;
    }
}
```

This allows for efficient state tracking and comparison operations throughout the application.

In the next part, we'll dive deeper into the implementation details of sessions and roles, showing how they integrate with this core architecture.
















File: lesson-3-part2.md


# AIChat Lesson 3: Configuration and State Management - Part 2
## Sessions, Roles, and Agents Implementation

### Session Management

Sessions in AIChat provide persistent conversation state and context management. The session system is implemented in `session.rs` and centers around the Session struct:

```rust
pub struct Session {
    model_id: String,
    temperature: Option<f64>,
    top_p: Option<f64>,
    use_tools: Option<String>,
    save_session: Option<bool>,
    compress_threshold: Option<usize>,

    role_name: Option<String>,
    agent_variables: IndexMap<String, String>,
    data_urls: HashMap<String, String>,
    compressed_messages: Vec<Message>,
    messages: Vec<Message>,

    #[serde(skip)]
    model: Model,
    #[serde(skip)]
    role_prompt: String,
    #[serde(skip)]
    name: String,
    #[serde(skip)]
    path: Option<String>,
}
```

Sessions implement several key features:

1. Message History Management:
```rust
pub fn add_message(&mut self, input: &Input, output: &str) -> Result<()> {
    if input.continue_output().is_some() {
        if let Some(message) = self.messages.last_mut() {
            if let MessageContent::Text(text) = &mut message.content {
                *text = format!("{text}{output}");
            }
        }
    }
    // Additional message handling
}
```

2. Token Tracking:
```rust
pub fn tokens_usage(&self) -> (usize, f32) {
    let tokens = self.tokens();
    let max_input_tokens = self.model().max_input_tokens().unwrap_or_default();
    let percent = if max_input_tokens == 0 {
        0.0
    } else {
        let percent = tokens as f32 / max_input_tokens as f32 * 100.0;
        (percent * 100.0).round() / 100.0
    };
    (tokens, percent)
}
```

3. Compression Management:
```rust
pub fn compress(&mut self, mut prompt: String) {
    if let Some(system_prompt) = self.messages.first().and_then(|v| {
        if MessageRole::System == v.role {
            let content = v.content.to_text();
            if !content.is_empty() {
                return Some(content);
            }
        }
        None
    }) {
        prompt = format!("{system_prompt}\n\n{prompt}",);
    }
    self.compressed_messages.append(&mut self.messages);
    self.messages.push(Message::new(
        MessageRole::System,
        MessageContent::Text(prompt),
    ));
}
```

### Role Management

Roles provide customized LLM behaviors and are implemented in `role.rs`. The Role struct defines:

```rust
pub struct Role {
    name: String,
    prompt: String,
    model_id: Option<String>,
    temperature: Option<f64>,
    top_p: Option<f64>,
    use_tools: Option<String>,
    
    #[serde(skip)]
    model: Model,
}
```

Roles support several formats:

1. Embedded Prompts:
```rust
pub fn is_embedded_prompt(&self) -> bool {
    self.prompt.contains(INPUT_PLACEHOLDER)
}
```

2. System Prompts:
```rust
pub fn build_messages(&self, input: &Input) -> Vec<Message> {
    let (system, cases) = parse_structure_prompt(&self.prompt);
    if !system.is_empty() {
        messages.push(Message::new(
            MessageRole::System,
            MessageContent::Text(system.to_string()),
        ));
    }
    // Additional message building
}
```

3. Few-shot Learning Prompts:
The system supports structured prompts with examples:
```rust
fn parse_structure_prompt(prompt: &str) -> (&str, Vec<(&str, &str)>) {
    // Extracts system message and input/output pairs
}
```

### Agent Implementation

Agents combine roles, tools, and document retrieval, implemented in `agent.rs`:

```rust
pub struct Agent {
    name: String,
    config: AgentConfig,
    definition: AgentDefinition,
    shared_variables: IndexMap<String, String>,
    session_variables: Option<IndexMap<String, String>>,
    functions: Functions,
    rag: Option<Arc<Rag>>,
    model: Model,
}
```

Key agent features include:

1. Variable Management:
```rust
pub fn init_agent_variables(
    agent_variables: &[AgentVariable],
    variables: &IndexMap<String, String>,
) -> Result<IndexMap<String, String>> {
    // Initialize and validate agent variables
}
```

2. Tool Integration:
```rust
pub fn functions(&self) -> &Functions {
    &self.functions
}
```

3. RAG Integration:
```rust
pub fn rag(&self) -> Option<Arc<Rag>> {
    self.rag.clone()
}
```

### State Interaction Patterns

The three systems (Sessions, Roles, and Agents) interact through the RoleLike trait:

```rust
pub trait RoleLike {
    fn to_role(&self) -> Role;
    fn model(&self) -> &Model;
    fn model_mut(&mut self) -> &mut Model;
    fn temperature(&self) -> Option<f64>;
    fn top_p(&self) -> Option<f64>;
    fn use_tools(&self) -> Option<String>;
    fn set_model(&mut self, model: &Model);
    fn set_temperature(&mut self, value: Option<f64>);
    fn set_top_p(&mut self, value: Option<f64>);
    fn set_use_tools(&mut self, value: Option<String>);
}
```

This trait ensures consistent behavior across different types of state holders while maintaining proper encapsulation.

In the final part, we'll explore practical usage patterns, persistence mechanisms, and cross-platform considerations.















File: lesson-3-part3.md


# AIChat Lesson 3: Configuration and State Management - Part 3
## Practical Usage, Persistence, and Cross-Platform Considerations

### Configuration File Management

AIChat uses YAML as its configuration format, with a sophisticated loading system that handles multiple scenarios:

```rust
fn load_from_file(config_path: &Path) -> Result<Self> {
    let err = || format!("Failed to load config at '{}'", config_path.display());
    let content = read_to_string(config_path).with_context(err)?;
    let config: Self = serde_yaml::from_str(&content)
        .map_err(|err| {
            let err_msg = err.to_string();
            let err_msg = if err_msg.starts_with(&format!("{}: ", CLIENTS_FIELD)) {
                err_msg
                    .split_once(" at line")
                    .map(|(v, _)| format!("{v} (Sorry for being unable to provide an exact location)"))
                    .unwrap_or_else(|| "clients: invalid value".into())
            } else {
                err_msg
            };
            anyhow!("{err_msg}")
        })
        .with_context(err)?;
    Ok(config)
}
```

The configuration file supports various settings, including:

1. Model Configuration:
```yaml
model: openai:gpt-4o             # Specify the LLM to use
temperature: 0.7                 # Set temperature parameter
top_p: 0.9                      # Set top-p parameter
```

2. Behavior Settings:
```yaml
stream: true                     # Controls stream-style API
save: true                      # Indicates message persistence
keybindings: emacs              # Choose keybinding style
wrap: no                        # Controls text wrapping
```

3. Function Calling Configuration:
```yaml
function_calling: true           # Enables function calling
mapping_tools:                   # Tool aliases
  fs: 'fs_cat,fs_ls,fs_mkdir,fs_rm,fs_write'
use_tools: 'fs,web_search'      # Default tools
```

### Environment Variables System

The environment variable system provides runtime configuration through standardized variable names:

```rust
pub fn load_envs(&mut self) {
    if let Ok(v) = env::var(get_env_name("model")) {
        self.model_id = v;
    }
    if let Some(v) = read_env_value::<f64>(&get_env_name("temperature")) {
        self.temperature = v;
    }
    // Additional environment variable loading
}
```

Environment variables can override most configuration settings:
```bash
AICHAT_MODEL=gpt-4               # Override model
AICHAT_TEMPERATURE=0.8          # Override temperature
AICHAT_STREAM=false             # Disable streaming
```

### Cross-Platform Path Handling

The system implements careful path handling for different operating systems:

```rust
pub fn config_dir() -> PathBuf {
    if let Ok(v) = env::var(get_env_name("config_dir")) {
        PathBuf::from(v)
    } else if let Ok(v) = env::var("XDG_CONFIG_HOME") {
        PathBuf::from(v).join(env!("CARGO_CRATE_NAME"))
    } else {
        let dir = dirs::config_dir().expect("No user's config directory");
        dir.join(env!("CARGO_CRATE_NAME"))
    }
}
```

Platform-specific considerations include:
1. Windows paths handling
2. Unix-style permissions
3. XDG base directory support
4. Home directory resolution

### Session Persistence

Sessions implement a sophisticated persistence mechanism:

```rust
pub fn save(&mut self, session_name: &str, session_path: &Path, is_repl: bool) -> Result<()> {
    ensure_parent_exists(session_path)?;

    self.path = Some(session_path.display().to_string());

    let content = serde_yaml::to_string(&self)
        .with_context(|| format!("Failed to serde session '{}'", self.name))?;
    write(session_path, content).with_context(|| {
        format!(
            "Failed to write session '{}' to '{}'",
            self.name,
            session_path.display()
        )
    })?;

    if is_repl {
        println!("✓ Saved session to '{}'.", session_path.display());
    }

    self.dirty = false;
    Ok(())
}
```

Session persistence includes:
1. Conversation history
2. Model parameters
3. Tool configurations
4. Variable states
5. Data URL mappings

### Role and Agent State Management

The system implements different state management strategies for roles and agents:

1. Role State:
```rust
pub fn save_role(&mut self, name: Option<&str>) -> Result<()> {
    let mut role_name = match &self.role {
        Some(role) => {
            if role.has_args() {
                bail!("Unable to save the role with arguments (whose name contains '#')")
            }
            match name {
                Some(v) => v.to_string(),
                None => role.name().to_string(),
            }
        }
        None => bail!("No role"),
    };
    // Role saving logic
}
```

2. Agent State:
```rust
pub fn exit_agent(&mut self) -> Result<()> {
    self.exit_session()?;
    if self.agent.take().is_some() {
        self.rag.take();
        self.last_message = None;
    }
    Ok(())
}
```

### Practical Examples

1. Setting up a new configuration:
```rust
let config = Config::init(WorkingMode::Repl)?;
let global_config = Arc::new(RwLock::new(config));
```

2. Updating configuration values:
```rust
let mut config = global_config.write();
config.set_model("gpt-4")?;
config.set_temperature(Some(0.7));
```

3. Managing sessions:
```rust
let mut session = Session::new(&config, "my-session");
session.add_message(&input, "Hello, world!")?;
session.save()?;
```

### Best Practices

1. Configuration Access:
- Always use the `GlobalConfig` type for shared state
- Implement proper error handling for configuration operations
- Use environment variables for runtime configuration
- Keep configuration files human-readable and well-documented

2. State Management:
- Maintain clear state boundaries
- Implement proper validation for all configuration values
- Handle cross-platform differences explicitly
- Use atomic operations for state updates

3. Error Handling:
- Provide clear error messages
- Implement proper cleanup in error cases
- Handle cross-platform error scenarios
- Maintain audit trail for configuration changes

### Common Pitfalls

1. Configuration Loading:
- Direct modification without proper locking
- Missing error handling
- Improper type conversion
- Incomplete validation

2. State Management:
- Race conditions in updates
- Memory leaks in session management
- Incomplete cleanup
- Missing state synchronization

3. Cross-Platform Issues:
- Hardcoded path separators
- Platform-specific assumptions
- Inconsistent file permissions
- Environment variable case sensitivity

### Conclusion

AIChat's configuration and state management system demonstrates several key principles:

1. Separation of Concerns:
- Clear boundaries between different types of state
- Proper encapsulation of functionality
- Consistent interfaces through traits
- Modular design for extensibility

2. Robustness:
- Comprehensive error handling
- Proper validation of all inputs
- Safe concurrent access
- Proper cleanup and resource management

3. Flexibility:
- Multiple configuration sources
- Runtime configuration changes
- Cross-platform compatibility
- Extensible state management

This system provides a solid foundation for managing application state while maintaining flexibility and reliability across different platforms and use cases.
















File: lesson-4-part1.md


# AIChat Lesson 4: Understanding REPL Architecture and Core Concepts

## Introduction

The Read-Eval-Print Loop (REPL) forms the interactive heart of AIChat, providing users with a powerful command-line interface for engaging with various Large Language Models (LLMs). Drawing from the knowledge base, AIChat's REPL is implemented as a sophisticated system that combines multiple components to deliver a seamless interactive experience.

## Project Structure

The REPL implementation follows a well-organized directory structure:

```
src/repl/
├── mod.rs           # Core REPL implementation
├── completer.rs     # Tab completion system
├── highlighter.rs   # Syntax highlighting engine
└── prompt.rs        # Custom prompt handling
```

This modular organization separates concerns while maintaining cohesive functionality. Each component serves a specific purpose in the overall REPL experience.

## Core Architecture

At the heart of AIChat's REPL lies the `Repl` struct, which orchestrates various components into a cohesive system:

```rust
pub struct Repl {
    config: GlobalConfig,      // Global configuration management
    editor: Reedline,         // Text editing capabilities
    prompt: ReplPrompt,       // Custom prompt handling
    abort_signal: AbortSignal // Signal handling for interrupts
}
```

### State Management

The REPL maintains various states through its interaction with the GlobalConfig:

1. Working Mode (REPL, Command, or Serve)
2. Session Management
3. Role Management
4. Agent Interaction
5. RAG (Retrieval-Augmented Generation) Integration

### Command System

The command system is built around the concept of ReplCommands:

```rust
pub struct ReplCommand {
    name: &'static str,        // Command identifier
    description: &'static str,  // Help text
    state: AssertState,        // State requirements
}
```

REPL commands follow a consistent pattern:
- Start with a dot (e.g., `.help`, `.model`, `.role`)
- Support optional arguments
- Maintain state awareness
- Provide clear feedback

## Key Features

### Multi-line Input

AIChat's REPL supports multi-line input through several mechanisms:
- Triple colon syntax (`:::`)
- External editor integration (Ctrl+O)
- Automatic line continuation
- Smart indentation

### Tab Completion

The tab completion system offers context-aware suggestions for:
- Command names
- Model names
- Role names
- File paths
- Agent names
- Configuration keys

### Syntax Highlighting

Real-time syntax highlighting enhances readability by:
- Highlighting commands
- Distinguishing arguments
- Marking special syntax
- Indicating errors
- Supporting both light and dark themes

### Custom Prompts

The prompt system provides dynamic information:
- Current mode indicator
- Active role
- Session status
- RAG status
- Agent context
- Token usage

## Integration Points

### LLM Integration

The REPL seamlessly integrates with multiple LLM platforms:
- OpenAI
- Claude
- Gemini
- Azure OpenAI
- And many others

### File System Integration

Robust file system handling supports:
- File input/output
- Configuration management
- Session persistence
- Role storage
- Agent data management

### Shell Integration

Shell integration features include:
- Command execution
- Environment variable access
- Path management
- Cross-platform compatibility

## Cross-Platform Support

AIChat's REPL maintains consistent behavior across:
- Linux
- macOS
- Windows
- Various terminal emulators

Key considerations include:
- Path separators
- Terminal capabilities
- Key bindings
- Color support
- Unicode handling

## Configuration System

The REPL's behavior can be customized through:
- Configuration files
- Environment variables
- Command-line options
- Runtime settings

## Error Handling

Robust error handling ensures:
- Clear error messages
- Graceful recovery
- State consistency
- User guidance
- Debug information when needed

## Session Management

Session features include:
- History management
- Context preservation
- Automatic saving
- Compression
- State recovery

## Security Considerations

The REPL implements various security measures:
- Input validation
- Path sanitization
- Environment isolation
- Secure credential handling
- Safe command execution

## User Experience

The REPL prioritizes user experience through:
- Consistent feedback
- Clear prompts
- Helpful messages
- Intuitive commands
- Responsive interface

## Advanced Features

### Function Calling

The REPL supports LLM function calling:
- Tool integration
- Agent capabilities
- Custom functions
- Result handling

### RAG Integration

Seamless RAG functionality:
- Document loading
- Vector search
- Context injection
- Result presentation

## Conclusion

AIChat's REPL implementation represents a sophisticated blend of features and capabilities, providing users with a powerful interface for LLM interaction. Understanding its architecture and components is crucial for both using and extending the system effectively.

Next: Part 2 will focus on practical implementation details and usage examples.
















File: lesson-4-part2.md


# AIChat Lesson 4: REPL Usage and Implementation Details

## REPL Commands and Usage

### Basic Commands

AIChat's REPL provides a rich set of commands for interaction. Here's a detailed look at the core commands and their usage:

The `.help` command displays available commands:
```
.help                    Show this help message
.info                    View system info
.model                   Change the current LLM
.prompt                  Create a temporary role using a prompt
.role                    Create or switch to a specific role
.session                 Begin a session
.rag                     Init or use the RAG
.agent                   Use an agent
.file                    Include files with the message
.continue                Continue the response
.regenerate              Regenerate the last response
.copy                    Copy the last response
.set                     Adjust runtime configuration
.delete                  Delete roles/sessions/RAGs/agents
.exit                    Exit the REPL
```

### Session Management

Session commands provide context management:
```
.session                 Begin a session
.empty session           Erase messages in the current session
.compress session        Compress messages in the current session
.info session           View session info
.edit session           Edit the current session
.save session           Save the current session to file
.exit session           End the session
```

### Role Management

Role-related commands handle role contexts:
```
.role                    Create or switch to a specific role
.info role              View role info
.edit role              Edit the current role
.save role              Save the current role to file
.exit role              Leave the role
```

### RAG Operations

RAG functionality commands:
```
.rag                     Init or use the RAG
.rebuild rag            Rebuild the RAG to sync document changes
.sources rag            View the RAG sources in the last query
.info rag               View RAG info
.exit rag               Leave the RAG
```

## Implementation Details

### Multi-line Input Processing

The REPL handles multi-line input through several mechanisms:

```rust
struct ReplValidator;

impl Validator for ReplValidator {
    fn validate(&self, line: &str) -> ValidationResult {
        let line = line.trim();
        if line.starts_with(r#":::"#) && !line[3..].ends_with(r#":::"#) {
            ValidationResult::Incomplete
        } else {
            ValidationResult::Complete
        }
    }
}
```

### Command Processing Pipeline

The command processing flow:

1. Input Collection
2. Command Parsing
3. State Validation
4. Execution
5. Output Formatting

Example implementation:

```rust
fn parse_command(line: &str) -> Option<(&str, Option<&str>)> {
    match COMMAND_RE.captures(line) {
        Ok(Some(captures)) => {
            let cmd = captures.get(1)?.as_str();
            let args = line[captures[0].len()..].trim();
            let args = if args.is_empty() { None } else { Some(args) };
            Some((cmd, args))
        }
        _ => None,
    }
}
```

### Completion System

The completion system provides context-aware suggestions:

```rust
impl Completer for ReplCompleter {
    fn complete(&mut self, line: &str, pos: usize) -> Vec<Suggestion> {
        let mut suggestions = vec![];
        // ... completion logic ...
        suggestions
    }
}
```

### Custom Prompt Rendering

The prompt system provides dynamic information:

```rust
impl Prompt for ReplPrompt {
    fn render_prompt_left(&self) -> Cow<str> {
        Cow::Owned(self.config.read().render_prompt_left())
    }

    fn render_prompt_right(&self) -> Cow<str> {
        Cow::Owned(self.config.read().render_prompt_right())
    }
}
```

## Advanced Usage Examples

### Role Creation and Usage

```shell
# Create a new role
.role coder
# Use a role temporarily
.role translator Tell me how to say "hello" in French
# View role information
.info role
```

### Session Management

```shell
# Start a new session
.session mysession
# View session information
.info session
# Compress session history
.compress session
```

### RAG Integration

```shell
# Initialize RAG with documents
.rag mydocs
# Add documents
.file document1.pdf document2.md -- What are the key points?
# View sources
.sources rag
```

### Configuration Adjustments

```shell
# Change model
.model openai:gpt-4
# Adjust settings
.set temperature 0.7
.set stream false
```

## Error Handling and Recovery

Error handling examples:

```rust
async fn handle_error(&self, err: Error) {
    render_error(err);
    if self.abort_signal.aborted() {
        println!("Operation aborted.");
    }
}
```

## Best Practices

### Command Implementation

When implementing new commands:

1. Validate state requirements
2. Handle errors gracefully
3. Provide clear feedback
4. Maintain consistency
5. Document behavior

### Input Processing

For robust input handling:

1. Validate input early
2. Handle special characters
3. Support Unicode
4. Process escape sequences
5. Handle line endings

### State Management

For reliable state handling:

1. Check state preconditions
2. Update state atomically
3. Handle transitions
4. Maintain consistency
5. Provide rollback

## Common Patterns

### Command Pattern

```rust
impl ReplCommand {
    fn new(name: &'static str, desc: &'static str, state: AssertState) -> Self {
        Self {
            name,
            description: desc,
            state,
        }
    }
}
```

### State Validation

```rust
fn is_valid(&self, flags: StateFlags) -> bool {
    match self.state {
        AssertState::True(true_flags) => true_flags & flags != StateFlags::empty(),
        AssertState::False(false_flags) => false_flags & flags == StateFlags::empty(),
        AssertState::TrueFalse(true_flags, false_flags) => {
            (true_flags & flags != StateFlags::empty())
                && (false_flags & flags == StateFlags::empty())
        }
        AssertState::Equal(check_flags) => check_flags == flags,
    }
}
```

## Troubleshooting Guide

Common issues and solutions:

1. Command not found
   - Check command syntax
   - Verify state requirements
   - Check configuration

2. Completion not working
   - Check terminal capabilities
   - Verify completion data
   - Check key bindings

3. Session errors
   - Check file permissions
   - Verify session state
   - Check storage space

4. RAG issues
   - Verify document format
   - Check embedding model
   - Verify index status

## Conclusion

Understanding AIChat's REPL implementation details and usage patterns is crucial for effective interaction with the system. The combination of robust implementation and user-friendly interface makes it a powerful tool for LLM interaction. Continue exploring the various features and capabilities to make the most of AIChat's REPL environment.

For further details and updates, refer to the AIChat documentation and GitHub repository. The next lesson will explore AIChat's client implementation and API integration features.















File: lesson-5-part1.md


# Lesson 5: Understanding AIChat's RAG System - Part 1

## Introduction to AIChat's RAG Implementation

AIChat implements a sophisticated Retrieval-Augmented Generation (RAG) system that enhances Large Language Model (LLM) capabilities by incorporating knowledge from external documents. This lesson explores the comprehensive RAG implementation, its architecture, and practical usage within AIChat.

## Project Structure

The RAG system's implementation is organized across multiple directories and files, with the core components residing in the following structure:

```
src/
├── rag/
│   ├── loader.rs       # Document loading and processing
│   ├── mod.rs         # Core RAG implementation
│   ├── serde_vectors.rs # Vector serialization utilities
│   └── splitter/
│       ├── language.rs # Language-specific splitting rules
│       └── mod.rs     # Text splitting implementation
├── config/
│   └── ...           # Configuration related files
└── utils/
    └── ...           # Utility functions and helpers
```

## Core Architecture

At the heart of AIChat's RAG system lies the `Rag` struct, which serves as the central orchestrator for all RAG-related operations. This structure encapsulates the essential components needed for document processing, embedding generation, and search functionality:

```rust
pub struct Rag {
    config: GlobalConfig,
    name: String,
    path: String,
    embedding_model: Model,
    hnsw: Hnsw<'static, f32, DistCosine>,
    bm25: SearchEngine<DocumentId>,
    data: RagData,
    last_sources: RwLock<Option<String>>,
}
```

The architecture implements a hybrid search approach combining vector similarity search through HNSW (Hierarchical Navigable Small World) and traditional keyword-based search using BM25. This dual approach ensures both semantic and lexical matching capabilities.

## Configuration System

AIChat's RAG system is highly configurable through a YAML configuration file. The key RAG-specific configuration options include:

```yaml
# RAG Configuration
rag_embedding_model: null       # Specifies the embedding model to use
rag_reranker_model: null       # Specifies the rerank model to use
rag_top_k: 4                   # Specifies the number of documents to retrieve
rag_chunk_size: null           # Specifies the chunk size
rag_chunk_overlap: null        # Specifies the chunk overlap
rag_min_score_vector_search: 0 # Minimum relevance score for vector-based searching
rag_min_score_keyword_search: 0 # Minimum relevance score for keyword-based searching
```

Additionally, document loaders can be configured to handle various file formats:

```yaml
document_loaders:
  pdf: 'pdftotext $1 -'        # Load .pdf file, requires pdftotext
  docx: 'pandoc --to plain $1' # Load .docx file, requires pandoc
```

## Document Processing Pipeline

The document processing pipeline in AIChat's RAG system consists of several sophisticated stages:

### 1. Document Loading

The document loader system supports multiple input sources and formats:

- Local files (PDF, DOCX, Markdown, etc.)
- Remote URLs and web pages
- Directory structures with glob pattern support
- Custom document loaders for specific file formats

Each document is loaded through the `load_document` function:

```rust
pub async fn load_document(
    loaders: &HashMap<String, String>,
    path: &str,
    has_error: &mut bool,
) -> (String, Vec<(String, RagMetadata)>)
```

### 2. Text Splitting

The text splitting system employs a recursive character-based approach through the `RecursiveCharacterTextSplitter`:

```rust
pub struct RecursiveCharacterTextSplitter {
    pub chunk_size: usize,
    pub chunk_overlap: usize,
    pub separators: Vec<String>,
    pub length_function: Box<dyn Fn(&str) -> usize + Send + Sync>,
}
```

This system provides:
- Configurable chunk sizes and overlap settings
- Language-specific splitting rules
- Intelligent separation based on document structure
- Preservation of document metadata

### 3. Vector Storage

The vector storage system is implemented through the `RagData` structure, which maintains:
- Document metadata and mappings
- Embedding vectors
- Search indices
- Serialization capabilities

## Usage Examples

Here are practical examples of using AIChat's RAG system:

1. Initializing a new RAG:
```bash
> .rag
⚙ Initializing RAG...
Select embedding model: text-embedding-3-small
Set chunk size: 1000
Set chunk overlay: 50
Add documents: /path/to/documents/**/*.md
```

2. Using RAG in a conversation:
```bash
> .rag my_knowledge_base
Loading knowledge base...
✓ Ready to answer questions based on the loaded documents
```

3. Querying with RAG:
```bash
> What information is available about feature X?
Searching knowledge base...
Based on the documents, feature X ...
```

This covers the first part of our deep dive into AIChat's RAG system. Part 2 will continue with advanced features, search implementation details, and best practices.
















File: lesson-5-part2.md


# Lesson 5: Understanding AIChat's RAG System - Part 2

## Advanced Search Implementation

AIChat's RAG system implements a sophisticated hybrid search approach that combines multiple search strategies to provide accurate and relevant results.

### Vector Similarity Search

The vector search implementation uses HNSW (Hierarchical Navigable Small World) for efficient similarity search:

```rust
async fn vector_search(
    &self,
    query: &str,
    top_k: usize,
    min_score: f32,
) -> Result<Vec<(DocumentId, f32)>>
```

This approach enables semantic search capabilities by:
- Converting query text into embeddings
- Performing efficient nearest neighbor search
- Filtering results based on minimum similarity scores

### Keyword-Based Search

The keyword search implementation uses the BM25 algorithm:

```rust
async fn keyword_search(
    &self,
    query: &str,
    top_k: usize,
    min_score: f32,
) -> Result<Vec<(DocumentId, f32)>>
```

This provides traditional lexical matching by:
- Analyzing term frequency
- Considering document length
- Applying inverse document frequency

### Result Fusion

The system combines results from both search methods using Reciprocal Rank Fusion:

```rust
fn reciprocal_rank_fusion(
    list_of_document_ids: Vec<Vec<DocumentId>>,
    list_of_weights: Vec<f32>,
    top_k: usize,
) -> Vec<DocumentId>
```

## Advanced Features

### Reranking Support

AIChat supports result reranking through specialized reranking models:

```yaml
rag_reranker_model: "cohere/rerank-english-v2.0"  # Example reranker
```

The reranking process helps improve result relevance by:
1. Taking initial search results
2. Applying sophisticated reranking algorithms
3. Reordering results based on additional relevance metrics

### Web Page Processing

The system includes advanced web crawling capabilities for processing web-based content:

```rust
pub async fn crawl_website(start_url: &str, options: CrawlOptions) -> Result<Vec<Page>>
```

Features include:
- HTML to Markdown conversion
- Content extraction
- Link following with depth control
- Metadata preservation

### Batch Processing

The system implements efficient batch processing for document handling:

```rust
pub async fn create_embeddings(
    &self,
    data: EmbeddingsData,
    spinner: Option<Spinner>,
) -> Result<EmbeddingsOutput>
```

This enables:
- Parallel processing of documents
- Efficient resource utilization
- Progress tracking and user feedback

## RAG Commands and Operations

AIChat provides several commands for RAG operations:

```
.rag                     # Init or use the RAG
.rebuild rag            # Rebuild the RAG to sync document changes
.sources rag           # View the RAG sources in the last query
.info rag             # View RAG info
.exit rag             # Leave the RAG
```

Each command serves specific purposes:

1. `.rag` - Initializes a new RAG or switches to an existing one:
   - Prompts for embedding model selection
   - Allows document source specification
   - Sets up chunking parameters

2. `.rebuild rag` - Updates the RAG with changes:
   - Reprocesses documents
   - Updates embeddings
   - Rebuilds search indices

3. `.sources rag` - Shows document sources:
   - Displays source documents
   - Shows relevant chunks
   - Indicates match scores

4. `.info rag` - Provides RAG information:
   - Configuration details
   - Document statistics
   - Model information

## Best Practices and Usage Recommendations

### Document Processing

When working with AIChat's RAG system, follow these document processing best practices:

1. Document Organization:
   - Keep related documents together
   - Use consistent file formats
   - Maintain clear directory structures

2. Chunk Size Selection:
   - Consider document type and content
   - Balance between context and relevance
   - Account for model token limits

3. File Format Handling:
   - Configure appropriate document loaders
   - Validate input formats
   - Handle encoding correctly

### Search Optimization

To optimize search results:

1. Query Formation:
   - Be specific and clear
   - Include relevant keywords
   - Consider context requirements

2. Parameter Tuning:
   - Adjust top_k based on needs
   - Fine-tune minimum scores
   - Balance vector and keyword search weights

3. Performance Optimization:
   - Use appropriate batch sizes
   - Implement caching when needed
   - Monitor resource usage

## Example Workflows

### 1. Technical Documentation RAG

Setting up a RAG for technical documentation:

```bash
> .rag tech_docs
Select embedding model: text-embedding-3-large
Set chunk size: 1500
Add documents: ./technical_docs/**/*.{md,rst}
```

### 2. Web Content RAG

Creating a RAG from web content:

```bash
> .rag web_content
Add documents: https://docs.example.com/**
⚙ Crawling website...
✓ Processed 100 pages
```

### 3. Mixed Source RAG

Combining multiple source types:

```bash
> .rag mixed_sources
Add documents: ./local_docs/;https://api.docs.com/
Processing multiple sources...
✓ Combined knowledge base ready
```

## Error Handling and Troubleshooting

AIChat's RAG system implements comprehensive error handling:

1. Document Loading Errors:
   - File access issues
   - Format compatibility
   - Encoding problems

2. Processing Errors:
   - Embedding generation failures
   - Chunking issues
   - Storage problems

3. Search Errors:
   - Index corruption
   - Query formatting
   - Resource limitations

Common troubleshooting steps:

1. Verify document accessibility and format
2. Check configuration settings
3. Monitor system resources
4. Review error messages
5. Rebuild RAG if necessary

## Future Directions

The AIChat RAG system continues to evolve with planned improvements:

1. Enhanced Embedding Models:
   - Multi-modal support
   - Improved efficiency
   - Additional model options

2. Advanced Search Features:
   - Improved hybrid search
   - Better result ranking
   - Query optimization

3. Performance Improvements:
   - Faster indexing
   - Reduced memory usage
   - Better scaling

This concludes our comprehensive exploration of AIChat's RAG system. Understanding these components and practices enables effective use of RAG capabilities in various applications and scenarios.
















File: lesson-5-part3.md


# Lesson 5: Understanding AIChat's RAG System - Part 3
## Core Concepts and Additional Details

In this part, we'll explore the fundamental concepts that underpin AIChat's RAG system and explain elements that were assumed but not explicitly covered in the previous parts.

## Understanding Vector Embeddings

### What Are Embeddings?

Text embeddings are numerical representations of text that capture semantic meaning. In AIChat's RAG system, embeddings are crucial for several reasons:

1. Semantic Understanding:
   - Words and phrases with similar meanings have similar vector representations
   - Enables matching conceptually related content even with different wording
   - Allows for language-agnostic comparison of texts

2. Mathematical Properties:
   - Each embedding is a high-dimensional vector (typically hundreds or thousands of dimensions)
   - Similarity between texts can be measured using vector operations
   - Common metrics include cosine similarity and euclidean distance

Example of embedding generation in AIChat:
```rust
pub async fn create_embeddings(
    &self,
    data: EmbeddingsData,
    spinner: Option<Spinner>,
) -> Result<EmbeddingsOutput>
```

## HNSW Index Explained

### What is HNSW?

Hierarchical Navigable Small World (HNSW) is an algorithm for approximate nearest neighbor search. AIChat uses it for efficient vector similarity search:

1. Structure:
   - Multiple layers of graphs
   - Each layer is a "small world" network
   - Higher layers are sparser for quick traversal
   - Lower layers are denser for accuracy

2. Benefits:
   - Logarithmic search complexity
   - High recall rate
   - Memory efficient
   - Supports dynamic updates

AIChat's HNSW implementation:
```rust
let hnsw = Hnsw::new(32, self.vectors.len(), 16, 200, DistCosine {});
```

Parameters explained:
- `32`: Maximum number of connections per node
- `16`: Number of layers
- `200`: Search depth
- `DistCosine`: Distance metric for similarity computation

## BM25 Search Algorithm

### Understanding BM25

BM25 (Best Matching 25) is a probabilistic ranking function used for traditional keyword search:

1. Core Components:
   - Term Frequency (TF): How often a term appears in a document
   - Inverse Document Frequency (IDF): How rare a term is across all documents
   - Document Length Normalization: Adjusting for document size

2. Formula Components:
```
score(D,Q) = ∑(IDF(qi) * TF(qi,D) * (k1 + 1)) / (TF(qi,D) + k1 * (1 - b + b * |D|/avgdl))
```
Where:
- D: Document
- Q: Query
- k1: Term frequency saturation parameter
- b: Length normalization parameter

AIChat's BM25 configuration:
```rust
SearchEngineBuilder::<DocumentId>::with_documents(Language::English, documents)
    .k1(1.5)
    .b(0.75)
    .build()
```

## Reciprocal Rank Fusion (RRF)

### How RRF Works

RRF is a method for combining results from multiple search systems:

1. Basic Principle:
   - Each result gets a score based on its rank in each system
   - Scores are combined using the RRF formula
   - Higher weights can be given to preferred systems

2. Formula:
```
RRF score = ∑ weight_i * 1/(k + rank_i)
```
Where:
- k: Constant to prevent division by zero and reduce impact of high ranks
- rank_i: Position of document in result list i
- weight_i: Importance weight for system i

AIChat's implementation:
```rust
fn reciprocal_rank_fusion(
    list_of_document_ids: Vec<Vec<DocumentId>>,
    list_of_weights: Vec<f32>,
    top_k: usize,
) -> Vec<DocumentId>
```

## Document Chunking Strategies

### Understanding Chunking

Document chunking is critical for effective RAG operation:

1. Purpose:
   - Break documents into manageable pieces
   - Maintain semantic coherence
   - Enable precise retrieval
   - Support model context windows

2. Chunking Parameters:
   ```rust
   pub struct SplitterChunkHeaderOptions {
       pub chunk_header: String,
       pub chunk_overlap_header: Option<String>,
   }
   ```

3. Language-Specific Rules:
   ```rust
   pub enum Language {
       Cpp,
       Go,
       Java,
       Js,
       // ... other languages
   }
   ```

Each language has specific separators defined for optimal chunking.

## Reranking Process

### How Reranking Works

Reranking improves search results through secondary evaluation:

1. Process Flow:
   - Initial search returns candidates
   - Reranker evaluates pairs of (query, document)
   - Results are reordered based on new scores

2. Benefits:
   - More accurate relevance assessment
   - Consideration of longer context
   - Better handling of nuanced queries

Implementation:
```rust
async fn rerank(&self, req: hyper::Request<Incoming>) -> Result<AppResponse> {
    // ... reranking logic
}
```

## Additional RAG Features

### File Type Support

AIChat supports various file types through configurable loaders:

1. Built-in Support:
   - Markdown (.md)
   - Plain text (.txt)
   - HTML (.html)
   - Source code files

2. External Loader Support:
   ```yaml
   document_loaders:
     pdf: 'pdftotext $1 -'
     docx: 'pandoc --to plain $1'
   ```

### Web Crawling Capabilities

Detailed web crawling features:

1. Configuration Options:
```rust
pub struct CrawlOptions {
    extract: Option<String>,
    exclude: Vec<String>,
    no_log: bool,
}
```

2. Special Handlers:
   - GitHub repository crawling
   - Wiki page processing
   - General website traversal

## Performance Considerations

### Memory Management

AIChat implements several memory optimization strategies:

1. Batch Processing:
   ```rust
   let batch_size = match self.embedding_model.max_input_tokens() {
       Some(max_input_tokens) => {
           let x = max_input_tokens / self.data.chunk_size;
           match batch_size {
               Some(y) => x.min(y),
               None => x,
           }
       }
       None => batch_size.unwrap_or(1),
   };
   ```

2. Vector Storage:
   - Efficient serialization
   - Compressed storage formats
   - Lazy loading strategies

### Concurrent Processing

AIChat handles concurrent operations through:

1. Tokio Runtime:
   ```rust
   async fn run_spinner(message: String, mut rx: mpsc::UnboundedReceiver<SpinnerEvent>)
   ```

2. Semaphore Control:
   ```rust
   let semaphore = Arc::new(Semaphore::new(MAX_CRAWLS));
   ```

## Integration Points

### LLM Integration

How RAG integrates with LLMs:

1. Context Injection:
   - Retrieved documents are formatted
   - Template system for context inclusion
   - Response generation with augmented context

2. Template Configuration:
```yaml
rag_template: |
  Answer the query based on the context while respecting the rules.
  <context>
  __CONTEXT__
  </context>
```

### API Integration

RAG system exposes APIs for:

1. Embeddings Generation:
```
POST /v1/embeddings
```

2. Search Operations:
```
POST /v1/rags/search
```

## Error Recovery and Resilience

### Handling Common Issues

1. Document Processing Errors:
   - Retry mechanisms for embeddings
   - Graceful degradation for unsupported formats
   - Partial success handling

2. Search Failures:
   - Fallback to alternative search methods
   - Automatic index rebuilding
   - Error reporting and logging

This concludes our deep dive into the underlying concepts and additional details of AIChat's RAG system. Understanding these concepts is crucial for effectively utilizing and potentially extending the system's capabilities.
















File: lesson-6-part1 main.md


# Lesson 6: Rendering and Output Management in AIChat 

## Introduction

AIChat's rendering and output management system is a sophisticated component responsible for presenting information to users in a clear, styled, and platform-independent way. This lesson explores the architecture, implementation details, and best practices for working with AIChat's rendering capabilities.

## System Architecture Overview

The rendering system in AIChat is structured across multiple modules located in the `src/render` directory. Let's examine the file layout:

```
src/
├── render/
│   ├── markdown.rs     # Markdown rendering implementation
│   ├── mod.rs         # Module definitions and core rendering logic
│   └── stream.rs      # Stream rendering functionality
└── utils/
    ├── spinner.rs     # Progress indicator implementation
    └── variables.rs   # Variable interpolation for prompts
```

### Core Components

The rendering system is built around several key components that work together to provide a cohesive output experience:

1. **MarkdownRender**: The primary component responsible for rendering formatted text and code blocks. It handles syntax highlighting, text wrapping, and terminal-aware formatting. The MarkdownRender struct is implemented in `markdown.rs` and provides methods for both single-line and multi-line rendering.

2. **StreamHandler**: Located in `stream.rs`, this component manages real-time rendering of streaming responses from Language Models. It maintains state during streaming to ensure proper formatting and cursor positioning, particularly important for interactive sessions.

3. **RenderOptions**: A configuration struct that controls various aspects of rendering behavior:
   - Theme selection (light/dark)
   - Text wrapping settings
   - Code block wrapping behavior
   - True color support detection

### Terminal Awareness

The rendering system is designed to be terminal-aware, adapting its output based on whether stdout is a terminal or being piped to another process. This is implemented through:

1. Terminal capability detection
2. Automatic fallback mechanisms for different color support levels
3. Platform-specific terminal setup routines

## Markdown Rendering Implementation

The markdown rendering system is one of the most sophisticated parts of AIChat's output management. It supports:

1. Syntax Highlighting: Using the syntect library for code highlighting with theme support
2. Automatic Language Detection: For code blocks without explicit language tags
3. Configurable Text Wrapping: Smart wrapping that preserves code formatting
4. Theme Management: Support for both light and dark themes

## Stream Processing

Stream processing in AIChat handles real-time rendering of responses from Language Models. The system:

1. Manages partial line buffering
2. Handles cursor positioning
3. Implements proper ANSI escape sequence handling
4. Provides progress indicators during operations

## Cross-Platform Considerations

AIChat's rendering system implements specific handling for different platforms:

### Windows Support
```rust
#[cfg(windows)]
fn setup_terminal() -> Result<()> {
    // Enable ANSI support on Windows
    // Handle Windows-specific terminal quirks
}
```

### Unix-like Systems
```rust
#[cfg(unix)]
fn setup_terminal() -> Result<()> {
    // Configure terminal for Unix-like systems
    // Handle specific terminal types
}
```

## Error Presentation

The error handling system in AIChat provides:

1. Formatted error messages with appropriate styling
2. Context-aware error chains
3. Warning messages with distinct styling
4. Platform-specific error formatting

## Usage Examples

Here are some practical examples of using AIChat's rendering system:

### Basic Text Rendering
```rust
let render = MarkdownRender::init(RenderOptions::default())?;
let output = render.render("Hello **bold** world");
println!("{}", output);
```

### Code Block Rendering
```rust
let render = MarkdownRender::init(RenderOptions::default())?;
let code = "```rust\nfn main() {\n    println!(\"Hello\");\n}\n```";
let output = render.render(code);
println!("{}", output);
```

### Progress Indication
```rust
let spinner = Spinner::new("Loading...");
// Perform long-running operation
spinner.stop();
```

## Best Practices

When working with AIChat's rendering system:

1. Always check terminal capabilities before using advanced features
2. Use appropriate error handling for different output scenarios
3. Consider platform-specific requirements
4. Implement proper cleanup for spinners and other terminal modifications
5. Handle text wrapping appropriately for different content types

## Conclusion

AIChat's rendering and output management system demonstrates sophisticated handling of terminal output across different platforms. Understanding this system is crucial for maintaining and extending the project's user interface capabilities. The system's modular design and careful handling of platform-specific features ensure a consistent and professional user experience across different environments.















File: lesson-6-part2 features.md


# Lesson 6: Advanced Features and Practical Applications

## Terminal Features and Capabilities

AIChat's rendering system includes sophisticated terminal handling capabilities that adapt to different environments. These features are essential for providing a consistent user experience across various platforms and terminal types.

### Color Support

The color support system implements a graceful degradation approach:

```rust
fn detect_color_support() -> ColorSupport {
    // Check COLORTERM environment variable
    // Fall back to basic color support if needed
    // Handle NO_COLOR environment variable
}
```

The system includes color mappings for:
- 24-bit true color
- 8-bit color (256 colors)
- Basic ANSI colors (16 colors)

### Progress Indicators

The progress indicator system, implemented in `spinner.rs`, provides visual feedback during long-running operations. The spinner system is highly configurable and includes:

1. Multiple spinner styles
2. Customizable messages
3. Automatic terminal capability detection
4. Clean handling of terminal states

### Text Wrapping

The text wrapping system is sophisticated and context-aware:

1. Smart wrapping of markdown content
2. Preservation of code block formatting
3. Handling of complex Unicode text
4. Terminal width awareness

## Integration with AIChat Features

### Session Management

The rendering system integrates closely with AIChat's session management:

1. Maintains consistent formatting across session messages
2. Handles history display and navigation
3. Manages state for multi-line editing
4. Provides visual indicators for session status

### RAG Integration

When working with RAG (Retrieval-Augmented Generation), the rendering system:

1. Formats source citations appropriately
2. Highlights relevant passages
3. Manages display of context windows
4. Provides visual separation of different information sources

### Function Calling Support

The rendering system provides special handling for function calls:

1. Formatted display of function signatures
2. Syntax highlighting for arguments
3. Visual feedback during function execution
4. Error presentation for function calls

## Practical Applications

### Interactive Shell Integration

The rendering system provides special support for shell integration:

1. Command highlighting
2. Error message formatting
3. Progress indication for long-running commands
4. Status line management

Example of shell command rendering:
```rust
let render = MarkdownRender::init(RenderOptions::default())?;
let command = "ls -la | grep \".txt\"";
let output = render.render(&format!("```bash\n{}\n```", command));
println!("{}", output);
```

### Code Generation

When generating code, the rendering system provides:

1. Language-specific syntax highlighting
2. Proper indentation preservation
3. Copy-paste friendly output
4. Error highlighting in generated code

### Documentation Display

For documentation and help text:

1. Formatted markdown rendering
2. Section highlighting
3. Command summary formatting
4. Example code highlighting

## Implementation Details

### Theme System

The theme system is implemented using syntect's theme support:

1. Built-in light and dark themes
2. Custom theme support
3. Terminal background detection
4. Automatic theme switching

### Stream Processing

The stream processing system handles:

1. Buffered output
2. Cursor management
3. Terminal width handling
4. ANSI escape sequence processing

### Error Handling

The error handling system provides:

1. Contextual error messages
2. Stack trace formatting
3. Warning level indication
4. Error source highlighting

## Configuration Options

The rendering system can be configured through various options:

### RenderOptions Structure
```rust
pub struct RenderOptions {
    pub theme: Option<Theme>,
    pub wrap: Option<String>,
    pub wrap_code: bool,
    pub truecolor: bool,
}
```

### Environment Variables

The system respects several environment variables:
- NO_COLOR: Disables color output
- COLORTERM: Controls color support level
- TERM: Determines terminal capabilities

## Testing and Development

When developing with AIChat's rendering system:

### Test Cases
1. Create tests for different terminal types
2. Verify color support detection
3. Test unicode handling
4. Verify platform-specific behavior

### Development Tools
1. Terminal capability testing
2. Color scheme verification
3. Performance profiling
4. Cross-platform testing

## Future Developments

Planned improvements to the rendering system include:

1. Enhanced Unicode support
2. Additional theme options
3. Improved performance for large outputs
4. Extended platform support

## Conclusion

The rendering and output management system in AIChat is a sophisticated component that provides consistent and professional output across different platforms and environments. Its modular design and careful handling of platform-specific features make it a reliable foundation for building terminal-based applications.

Understanding and properly utilizing these features is essential for:
- Creating professional-looking output
- Handling different terminal environments
- Providing consistent user experience
- Managing complex interactive sessions
- Supporting advanced features like RAG and function calling

The system's flexibility and extensibility make it a powerful tool for developing sophisticated terminal applications while maintaining cross-platform compatibility and user-friendly output.















File: lesson-6-part3 concepts.md


# Lesson 6: Foundation Concepts and Additional Details

## Terminal Fundamentals

Before diving deeper into AIChat's rendering system, it's important to understand several fundamental concepts about terminal operations that were assumed in the previous sections.

### ANSI Escape Sequences

ANSI escape sequences are special character sequences that control cursor location, color, font styling, and other terminal operations. In AIChat, these sequences are crucial for:

1. **Cursor Control**: Moving the cursor around the terminal
   ```rust
   // Example ANSI sequence to move cursor up one line
   let move_up = "\x1B[1A";
   // Example to move to beginning of line
   let move_start = "\x1B[0G";
   ```

2. **Color Control**: Setting text and background colors
   ```rust
   // Example ANSI sequence for red text
   let red_text = "\x1B[31m";
   // Example for blue background
   let blue_bg = "\x1B[44m";
   ```

3. **Text Styling**: Adding bold, italic, or underline formatting
   ```rust
   // Example ANSI sequence for bold text
   let bold_text = "\x1B[1m";
   // Example for underlined text
   let underline = "\x1B[4m";
   ```

### Terminal Modes

Terminals can operate in different modes, which affect how input and output are handled:

1. **Canonical Mode (Cooked Mode)**:
   - Default terminal mode
   - Input is buffered until Enter key
   - Line editing is enabled
   - Special characters (like Ctrl+C) are processed

2. **Raw Mode**:
   - Input is processed immediately
   - No line editing
   - Special characters are passed directly to the application
   ```rust
   // Example of entering raw mode in AIChat
   enable_raw_mode()?;
   // Operations in raw mode
   disable_raw_mode()?;
   ```

### Terminal Capabilities

Understanding terminal capabilities is crucial for proper rendering:

1. **Color Support Levels**:
   - No Color: Basic terminal with no color support
   - ANSI Colors (4-bit): 16 colors
   - 256 Colors (8-bit): Extended color palette
   - True Color (24-bit): Full RGB color support

2. **Unicode Support**:
   - Basic ASCII
   - UTF-8 encoding
   - Combining characters
   - Width considerations for CJK characters

## Stream Processing Details

The streaming system in AIChat, which was briefly covered earlier, involves several important concepts:

### Buffering Strategies

1. **Line Buffering**:
   ```rust
   pub struct StreamBuffer {
       current_line: String,
       completed_lines: Vec<String>,
       width: usize,
   }
   ```

2. **Chunk Processing**:
   ```rust
   impl StreamHandler {
       fn process_chunk(&mut self, chunk: &str) -> Result<()> {
           // Split chunk into lines
           // Process partial lines
           // Handle overflow
       }
   }
   ```

### Event Loop Management

AIChat's event loop for streaming handles multiple concerns:

1. **Input Events**:
   ```rust
   enum StreamEvent {
       Input(String),
       Signal(Signal),
       Timeout(Duration),
   }
   ```

2. **Output Buffering**:
   ```rust
   struct OutputBuffer {
       content: Vec<u8>,
       position: usize,
       max_size: usize,
   }
   ```

## Markdown Processing Internals

The markdown processing system involves several sophisticated components:

### Syntax Tree Processing

1. **Parse Tree**:
   ```rust
   struct MarkdownNode {
       node_type: NodeType,
       content: String,
       children: Vec<MarkdownNode>,
   }
   ```

2. **Syntax Recognition**:
   ```rust
   enum SyntaxElement {
       Heading(usize),  // Level
       CodeBlock(String), // Language
       List(ListType),
       Paragraph,
       // ...
   }
   ```

### Language Detection

The language detection system uses multiple strategies:

1. **Extension Mapping**:
   ```rust
   lazy_static! {
       static ref LANG_MAPS: HashMap<String, String> = {
           let mut m = HashMap::new();
           m.insert("js".into(), "javascript".into());
           m.insert("py".into(), "python".into());
           // ...
           m
       };
   }
   ```

2. **Content Analysis**:
   ```rust
   fn detect_language(content: &str) -> Option<String> {
       // Check for shebang
       // Look for language-specific patterns
       // Fall back to extension mapping
   }
   ```

## Advanced Terminal Features

### Window Size Management

AIChat handles terminal resizing events:

```rust
pub struct TerminalSize {
    pub width: u16,
    pub height: u16,
    pub resized: Arc<AtomicBool>,
}

impl TerminalSize {
    pub fn update(&self) {
        if let Ok((w, h)) = terminal::size() {
            self.width.store(w, Ordering::SeqCst);
            self.height.store(h, Ordering::SeqCst);
        }
    }
}
```

### Input Handling

The input system handles various special cases:

1. **Bracketed Paste Mode**:
   ```rust
   pub struct InputHandler {
       bracketed_paste: bool,
       input_buffer: Vec<u8>,
       // ...
   }
   ```

2. **Key Mapping**:
   ```rust
   enum KeyEvent {
       Char(char),
       Control(char),
       Function(u8),
       // ...
   }
   ```

## Platform-Specific Considerations

### Windows-Specific Features

1. **Console API Integration**:
   ```rust
   #[cfg(windows)]
   mod windows {
       use winapi::um::consoleapi::*;
       // Windows-specific terminal handling
   }
   ```

2. **Code Page Management**:
   ```rust
   #[cfg(windows)]
   fn set_console_utf8() -> Result<()> {
       // Enable UTF-8 output on Windows
   }
   ```

### Unix-Specific Features

1. **TTY Handling**:
   ```rust
   #[cfg(unix)]
   mod unix {
       use termios::*;
       // Unix-specific terminal handling
   }
   ```

2. **Signal Management**:
   ```rust
   #[cfg(unix)]
   fn setup_signals() -> Result<()> {
       // Handle SIGWINCH for terminal resizing
       // Handle SIGINT for interruption
   }
   ```

## Memory Management

### Buffer Management

The rendering system implements efficient buffer management:

```rust
pub struct RenderBuffer {
    content: Vec<u8>,
    position: usize,
    capacity: usize,
}

impl RenderBuffer {
    pub fn write(&mut self, data: &[u8]) -> Result<()> {
        // Handle buffer overflow
        // Manage memory allocation
    }
}
```

### Resource Cleanup

Proper resource management is crucial:

```rust
impl Drop for RenderContext {
    fn drop(&mut self) {
        // Restore terminal state
        // Clear screen if necessary
        // Reset colors and attributes
    }
}
```

## Performance Considerations

### Batch Processing

The rendering system implements batch processing for efficiency:

```rust
struct BatchRenderer {
    queue: Vec<RenderOperation>,
    threshold: usize,
}

impl BatchRenderer {
    fn flush(&mut self) -> Result<()> {
        // Process queued operations
        // Clear queue
    }
}
```

### Caching

Various caching strategies are implemented:

1. **Theme Caching**:
   ```rust
   struct ThemeCache {
       themes: HashMap<String, Arc<Theme>>,
       max_size: usize,
   }
   ```

2. **Syntax Highlighting Cache**:
   ```rust
   struct HighlightCache {
       entries: LruCache<String, Vec<ColoredString>>,
       capacity: usize,
   }
   ```

## Testing Considerations

### Test Utilities

AIChat provides several testing utilities:

```rust
pub mod test_utils {
    pub fn create_test_terminal() -> TestTerminal {
        // Create a virtual terminal for testing
    }

    pub fn capture_output<F>(f: F) -> String 
    where F: FnOnce() -> Result<()> {
        // Capture terminal output for testing
    }
}
```

### Mock Terminal

A mock terminal implementation for testing:

```rust
pub struct MockTerminal {
    output: Vec<u8>,
    width: u16,
    height: u16,
    // ...
}

impl Terminal for MockTerminal {
    // Implementation of terminal traits for testing
}
```

## Conclusion

Understanding these underlying concepts is crucial for working with AIChat's rendering system effectively. The system builds upon these fundamentals to provide its sophisticated rendering capabilities while handling the complexities of different terminal environments and platforms.

The combination of these concepts allows AIChat to:
- Provide consistent output across different platforms
- Handle complex terminal interactions efficiently
- Manage resources effectively
- Maintain high performance
- Support extensive testing capabilities

This deeper understanding of the underlying concepts helps in:
- Debugging rendering issues
- Implementing new features
- Optimizing performance
- Ensuring cross-platform compatibility
- Writing effective tests















File: lesson-7-part1.md


# AIChat HTTP Server Implementation - Part 1: Architecture and Core Implementation

## Introduction

The HTTP server implementation in AIChat provides a robust foundation for exposing LLM capabilities through standardized REST APIs and web interfaces. This part covers the core architecture and implementation details of the server component.

## Project Structure

The HTTP server implementation spans several key files and directories:

```
src/
├── serve.rs                 # Main server implementation
├── client/
│   ├── common.rs           # Common client interfaces
│   └── stream.rs           # Streaming functionality
├── utils/
│   └── request.rs          # HTTP request utilities
└── assets/
    ├── arena.html          # LLM comparison interface
    └── playground.html     # Interactive LLM interface
```

## Core Server Architecture

The server implementation in AIChat follows a modular architecture centered around the `Server` struct defined in `serve.rs`. The server provides:

1. REST API endpoints for chat completions, embeddings, and reranking
2. Web interfaces for playground and arena interactions 
3. Support for both synchronous and streaming responses
4. Graceful shutdown capabilities
5. CORS and error handling

### Server Initialization

The server initialization process begins in the `run` function:

```rust
pub async fn run(config: GlobalConfig, addr: Option<String>) -> Result<()> {
    let addr = match addr {
        Some(addr) => {
            if let Ok(port) = addr.parse::<u16>() {
                format!("127.0.0.1:{port}")
            } else if let Ok(ip) = addr.parse::<IpAddr>() {
                format!("{ip}:8000")
            } else {
                addr
            }
        }
        None => config.read().serve_addr(),
    };
    let server = Arc::new(Server::new(&config));
    let listener = TcpListener::bind(&addr).await?;
    let stop_server = server.run(listener).await?;
    // Print server endpoints
    shutdown_signal().await;
    let _ = stop_server.send(());
    Ok(())
}
```

The server uses Tokio for async I/O operations and creates a TcpListener bound to the specified address. The server instance is wrapped in an Arc for safe sharing across multiple tasks.

### Request Handling

Request handling is implemented through the `handle` function which processes incoming HTTP requests:

```rust
async fn handle(
    self: Arc<Self>,
    req: hyper::Request<Incoming>,
) -> std::result::Result<AppResponse, hyper::Error> {
    let method = req.method().clone();
    let uri = req.uri().clone();
    let path = uri.path();

    // CORS handling
    if method == Method::OPTIONS {
        let mut res = Response::default();
        *res.status_mut() = StatusCode::NO_CONTENT;
        set_cors_header(&mut res);
        return Ok(res);
    }

    // Route handling
    let mut status = StatusCode::OK;
    let res = match path {
        "/v1/chat/completions" => self.chat_completions(req).await,
        "/v1/embeddings" => self.embeddings(req).await,
        "/v1/rerank" => self.rerank(req).await,
        "/v1/models" => self.list_models(),
        "/playground" => self.playground_page(),
        "/arena" => self.arena_page(),
        _ => {
            status = StatusCode::NOT_FOUND;
            Err(anyhow!("Not Found"))
        }
    };
    
    // Response processing and error handling
    let mut res = match res {
        Ok(res) => {
            info!("{method} {uri} {}", status.as_u16());
            res
        }
        Err(err) => {
            if status == StatusCode::OK {
                status = StatusCode::BAD_REQUEST;
            }
            error!("{method} {uri} {} {err}", status.as_u16());
            ret_err(err)
        }
    };
    *res.status_mut() = status;
    set_cors_header(&mut res);
    Ok(res)
}
```

### Streaming Implementation

One of the key features is support for streaming responses using Server-Sent Events (SSE). This is implemented through a `SseHandler` struct that manages the streaming state and event dispatch:

```rust
pub struct SseHandler {
    sender: UnboundedSender<SseEvent>,
    abort_signal: AbortSignal,
    buffer: String,
    tool_calls: Vec<ToolCall>,
}
```

The streaming implementation supports:
- Real-time text output
- Tool call handling 
- Graceful abort/shutdown
- Keep-alive handling
- Clean stream termination

### Error Handling

The server implements comprehensive error handling through the `ret_err` function:

```rust
fn ret_err<T: std::fmt::Display>(err: T) -> AppResponse {
    let data = json!({
        "error": {
            "message": err.to_string(),
            "type": "invalid_request_error",
        },
    });
    Response::builder()
        .header("Content-Type", "application/json")
        .body(Full::new(Bytes::from(data.to_string())).boxed())
        .unwrap()
}
```

This ensures consistent error responses across all endpoints with proper status codes and error details.

### Chat Completions Endpoint

The chat completions endpoint (`/v1/chat/completions`) is the most complex implementation, handling:

1. Request validation and parsing:
```rust
let req_body = req.collect().await?.to_bytes();
let req_body: Value = serde_json::from_slice(&req_body)
    .map_err(|err| anyhow!("Invalid request json, {err}"))?;
```

2. Model selection and configuration
3. Streaming mode handling
4. Tool calling support
5. Token management

### Web Interfaces

The server provides two web interfaces:

1. Playground (`/playground`) - Interactive LLM interface:
```rust
fn playground_page(&self) -> Result<AppResponse> {
    let res = Response::builder()
        .header("Content-Type", "text/html; charset=utf-8")
        .body(Full::new(Bytes::from(PLAYGROUND_HTML)).boxed())?;
    Ok(res)
}
```

2. Arena (`/arena`) - Model comparison interface:
```rust
fn arena_page(&self) -> Result<AppResponse> {
    let res = Response::builder()
        .header("Content-Type", "text/html; charset=utf-8")
        .body(Full::new(Bytes::from(ARENA_HTML)).boxed())?;
    Ok(res)
}
```

Both interfaces are served from embedded HTML assets in the binary.

## Cross-Platform Support

The server implementation includes several cross-platform considerations:

1. Path handling for different operating systems
2. Network interface binding
3. Process management
4. Resource cleanup
5. File system access patterns

This ensures consistent behavior across Windows, macOS and Linux environments.

## Conclusion

The AIChat HTTP server implementation provides a robust foundation for exposing LLM capabilities through standardized APIs and web interfaces. The modular architecture, comprehensive error handling, and streaming support make it suitable for both development and production use cases.















File: lesson-7-part2.md


# AIChat HTTP Server Implementation - Part 2: API Endpoints, Usage and Integration

## API Endpoints

### Chat Completions API

The chat completions endpoint is accessed through `/v1/chat/completions`. It accepts POST requests with a JSON body in the following format:

```json
{
    "model": "model-name",
    "messages": [
        {
            "role": "user",
            "content": "Hello world"
        }
    ],
    "temperature": 0.7,
    "top_p": 1,
    "stream": true
}
```

The response format follows the OpenAI API convention:

```json
{
    "id": "chatcmpl-123",
    "object": "chat.completion",
    "created": 1677858242,
    "model": "model-name",
    "choices": [
        {
            "index": 0,
            "message": {
                "role": "assistant", 
                "content": "Response text"
            }
        }
    ]
}
```

### Embeddings API

The embeddings endpoint is accessed through `/v1/embeddings`. It accepts POST requests with:

```json
{
    "model": "embedding-model",
    "input": ["Text to embed"]
}
```

The response provides vector embeddings:

```json
{
    "object": "list",
    "data": [
        {
            "object": "embedding",
            "embedding": [0.1, 0.2, ...],
            "index": 0
        }
    ],
    "model": "embedding-model"
}
```

### Rerank API 

The rerank endpoint at `/v1/rerank` accepts:

```json
{
    "model": "rerank-model",
    "query": "search query",
    "documents": ["doc1", "doc2"],
    "top_n": 2
}
```

Response format:

```json
{
    "id": "rerank-123", 
    "results": [
        {
            "index": 0,
            "relevance_score": 0.95,
            "document": "doc1"
        }
    ]
}
```

## Web Interfaces

### Playground Interface

The playground interface provides an interactive environment for testing LLM capabilities. Key features include:

1. Model selection dropdown
2. Interactive chat interface
3. Parameter configuration
4. Response streaming
5. Copy/regenerate options
6. Tool call visualization

The playground can be accessed by running:

```bash
aichat --serve
# Access at http://localhost:8000/playground
```

### Arena Interface

The arena interface enables side-by-side model comparison with:

1. Multiple model selection
2. Parallel request processing
3. Response comparison 
4. Performance metrics
5. Unified prompt input

Access the arena at:
```bash
http://localhost:8000/arena?num=2
```

The num parameter controls how many models to compare simultaneously.

## Usage Examples

### Starting the Server

Basic server start:
```bash
aichat --serve
```

Custom address/port:
```bash 
aichat --serve 0.0.0.0:3000
```

### API Usage Examples

Chat completion request:
```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "gpt-4",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

Streaming chat completion:
```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "gpt-4",
    "messages": [{"role": "user", "content": "Hello!"}],
    "stream": true
  }'
```

Embeddings request:
```bash
curl -X POST http://localhost:8000/v1/embeddings \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "text-embedding-3-small",
    "input": ["Hello world"]
  }'
```

## Integration Patterns

### Client Library Integration

The server can be integrated with client libraries through the standard OpenAI-compatible interface:

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="dummy"
)

response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}]
)
```

### Environment Configuration

The server behavior can be configured through environment variables:

```bash
export AICHAT_SERVE_ADDR=0.0.0.0:3000
export AICHAT_MODEL=gpt-4
export AICHAT_TEMPERATURE=0.7
```

### Proxy Configuration

The server supports various proxy configurations:

```yaml
extra:
  proxy: socks5://127.0.0.1:1080
  connect_timeout: 10
```

### Security Considerations 

When deploying the server, consider:

1. API key validation
2. Rate limiting
3. CORS policy configuration
4. Error message sanitization
5. Input validation and sanitization

Example CORS configuration:
```rust
fn set_cors_header(res: &mut AppResponse) {
    res.headers_mut().insert(
        hyper::header::ACCESS_CONTROL_ALLOW_ORIGIN,
        hyper::header::HeaderValue::from_static("*")
    );
    // Additional CORS headers...
}
```

## Testing

The server implementation includes comprehensive testing:

1. Unit tests for individual components:
```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_chat_completions() {
        // Test implementation
    }
}
```

2. Integration tests for API endpoints
3. Load testing for performance verification
4. Cross-platform compatibility testing
5. Error handling verification

## Troubleshooting

Common troubleshooting steps:

1. Enable debug logging:
```bash
export AICHAT_LOG_LEVEL=debug
```

2. Check server logs:
```bash
tail -f ~/.config/aichat/aichat.log
```

3. Verify API endpoint availability:
```bash
curl http://localhost:8000/v1/models
```

4. Test streaming connection:
```bash
curl -N http://localhost:8000/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{"stream":true,...}'
```

## Conclusion

The AIChat HTTP server implementation provides a feature-rich platform for exposing LLM capabilities through standardized APIs and web interfaces. The comprehensive API support, web interfaces, and integration patterns make it suitable for a wide range of applications. The robust error handling, security considerations, and testing infrastructure ensure reliable operation in production environments.















File: lesson-7-part3.md


# AIChat HTTP Server Implementation - Part 3: Core Concepts and Additional Details

## Foundational Technologies and Concepts

### Hyper and HTTP/1.1

AIChat uses Hyper, a fast and correct HTTP implementation in Rust. Key concepts include:

1. The Request-Response Cycle:
```rust
pub async fn handle(
    self: Arc<Self>,
    req: hyper::Request<Incoming>,
) -> std::result::Result<AppResponse, hyper::Error>
```

The `Request` struct contains:
- Method (GET, POST, etc.)
- URI 
- Headers
- Body (as a stream of bytes)

The `Response` struct contains:
- Status code
- Headers
- Body

2. HTTP Headers:
```rust
res.headers_mut().insert(
    hyper::header::ACCESS_CONTROL_ALLOW_ORIGIN,
    hyper::header::HeaderValue::from_static("*"),
);
```

### Tokio Async Runtime

Tokio provides the async runtime for AIChat. Core concepts include:

1. **Futures**: Asynchronous computations that can be polled to completion
```rust
pub trait Future {
    type Output;
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}
```

2. **Tasks**: Units of concurrent work
```rust
tokio::spawn(async move {
    // Concurrent work here
});
```

3. **Channels**: Communication between tasks
```rust
let (tx, rx) = tokio::sync::mpsc::unbounded_channel();
// tx.send(message)
// rx.recv().await
```

### Server-Sent Events (SSE)

SSE is used for streaming LLM responses. The protocol looks like:

```plaintext
HTTP/1.1 200 OK
Content-Type: text/event-stream
Cache-Control: no-cache
Connection: keep-alive

data: {"content": "Hello"}

data: {"content": " World"}

data: [DONE]
```

Implementation in AIChat:
```rust
#[derive(Debug)]
pub enum SseEvent {
    Text(String),
    Done,
}

pub struct SseHandler {
    sender: UnboundedSender<SseEvent>,
    abort_signal: AbortSignal,
    buffer: String,
    tool_calls: Vec<ToolCall>,
}
```

### Bytes and BytesMut

Understanding Bytes types is crucial:

1. `Bytes`: An immutable buffer
```rust
let bytes = Bytes::from("Hello World");
```

2. `BytesMut`: A mutable buffer
```rust
let mut buffer = BytesMut::new();
buffer.extend_from_slice(b"Hello");
```

These are used extensively in the streaming implementation.

## Advanced Server Concepts

### Connection Management

1. Connection Pooling:
```rust
pub struct ConnectionPool {
    idle_timeout: Duration,
    max_lifetime: Duration,
    max_idle: usize,
    connections: Vec<PooledConnection>,
}
```

2. Keep-Alive:
```rust
Response::builder()
    .header("Connection", "keep-alive")
    .header("Keep-Alive", "timeout=5, max=1000")
```

### Backpressure Handling

Backpressure occurs when data is produced faster than it can be consumed. AIChat handles this through:

1. Buffering:
```rust
pub struct Buffer {
    data: VecDeque<Bytes>,
    max_size: usize,
}
```

2. Flow Control:
```rust
impl<S: Stream> StreamExt<S> {
    fn buffer_unordered(self, limit: usize) -> BufferUnordered<S>
}
```

### Error Propagation

Error handling patterns in async code:

```rust
#[derive(Debug, Error)]
pub enum ServerError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    
    #[error("HTTP error: {0}")]
    Http(#[from] hyper::Error),
    
    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),
}

async fn handle_request() -> Result<Response, ServerError> {
    let data = read_data().await?;
    let processed = process_data(data).await?;
    Ok(create_response(processed))
}
```

## Protocol-Specific Details

### HTTP Status Codes

Important status codes used in AIChat:

```rust
const STATUS_OK: StatusCode = StatusCode::OK;                    // 200
const STATUS_BAD_REQUEST: StatusCode = StatusCode::BAD_REQUEST;  // 400
const STATUS_NOT_FOUND: StatusCode = StatusCode::NOT_FOUND;      // 404
const STATUS_SERVER_ERROR: StatusCode = StatusCode::INTERNAL_SERVER_ERROR; // 500
```

### Content Types

Common content types:
```rust
const CONTENT_TYPE_JSON: &str = "application/json";
const CONTENT_TYPE_SSE: &str = "text/event-stream";
const CONTENT_TYPE_HTML: &str = "text/html; charset=utf-8";
```

### CORS Headers

Cross-Origin Resource Sharing headers:
```rust
ACCESS_CONTROL_ALLOW_ORIGIN: "*"
ACCESS_CONTROL_ALLOW_METHODS: "GET,POST,PUT,PATCH,DELETE"
ACCESS_CONTROL_ALLOW_HEADERS: "Content-Type,Authorization"
```

## Memory Management

### Buffer Management

Efficient buffer handling:
```rust
pub struct StreamBuffer {
    inner: BytesMut,
    capacity: usize,
}

impl StreamBuffer {
    pub fn new(capacity: usize) -> Self {
        Self {
            inner: BytesMut::with_capacity(capacity),
            capacity,
        }
    }
    
    pub fn extend(&mut self, data: &[u8]) -> Result<()> {
        if self.inner.len() + data.len() > self.capacity {
            return Err(anyhow!("Buffer capacity exceeded"));
        }
        self.inner.extend_from_slice(data);
        Ok(())
    }
}
```

### Memory Pooling

Pool of reusable buffers:
```rust
pub struct BufferPool {
    buffers: Vec<BytesMut>,
    capacity: usize,
}

impl BufferPool {
    pub fn acquire(&mut self) -> Option<BytesMut> {
        self.buffers.pop()
    }
    
    pub fn release(&mut self, mut buffer: BytesMut) {
        buffer.clear();
        self.buffers.push(buffer);
    }
}
```

## Security Considerations

### Request Validation

Input validation implementation:
```rust
fn validate_request<T: DeserializeOwned>(body: &[u8]) -> Result<T> {
    // Check size
    if body.len() > MAX_REQUEST_SIZE {
        return Err(anyhow!("Request too large"));
    }
    
    // Validate JSON
    let value: Value = serde_json::from_slice(body)?;
    
    // Schema validation
    validate_schema(&value)?;
    
    // Parse to type
    let parsed: T = serde_json::from_value(value)?;
    
    Ok(parsed)
}
```

### Rate Limiting

Token bucket implementation:
```rust
pub struct TokenBucket {
    tokens: AtomicU32,
    capacity: u32,
    refill_rate: f64,
    last_refill: AtomicI64,
}

impl TokenBucket {
    pub fn try_acquire(&self) -> bool {
        self.refill();
        
        let current = self.tokens.load(Ordering::Relaxed);
        if current > 0 {
            self.tokens.fetch_sub(1, Ordering::Relaxed);
            true
        } else {
            false
        }
    }
    
    fn refill(&self) {
        let now = Instant::now();
        let last = self.last_refill.load(Ordering::Relaxed);
        let elapsed = now.duration_since(last).as_secs_f64();
        
        let new_tokens = (elapsed * self.refill_rate) as u32;
        if new_tokens > 0 {
            self.tokens.fetch_add(new_tokens, Ordering::Relaxed);
            self.last_refill.store(now, Ordering::Relaxed);
        }
    }
}
```

## Testing Infrastructure

### Unit Testing

Example of unit test structure:
```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[tokio::test]
    async fn test_request_handling() {
        // Setup
        let server = Server::new(&config);
        
        // Create test request
        let request = Request::builder()
            .method("POST")
            .uri("/v1/chat/completions")
            .body(Body::from(r#"{"model": "test"}"#))
            .unwrap();
            
        // Send request
        let response = server.handle(request).await.unwrap();
        
        // Assert response
        assert_eq!(response.status(), StatusCode::OK);
    }
}
```

### Integration Testing

Testing the full server:
```rust
#[tokio::test]
async fn test_server_integration() {
    // Start server
    let server = TestServer::start().await;
    
    // Create client
    let client = reqwest::Client::new();
    
    // Send request
    let response = client
        .post(&format!("{}/v1/chat/completions", server.addr()))
        .json(&json!({
            "model": "test-model",
            "messages": [{"role": "user", "content": "test"}]
        }))
        .send()
        .await
        .unwrap();
        
    assert!(response.status().is_success());
}
```

## Configuration Management

### Environment Variables

Loading configuration:
```rust
pub struct ServerConfig {
    pub host: String,
    pub port: u16,
    pub max_connections: usize,
}

impl ServerConfig {
    pub fn from_env() -> Result<Self> {
        Ok(Self {
            host: env::var("AICHAT_HOST")
                .unwrap_or_else(|_| "127.0.0.1".to_string()),
            port: env::var("AICHAT_PORT")
                .ok()
                .and_then(|s| s.parse().ok())
                .unwrap_or(8000),
            max_connections: env::var("AICHAT_MAX_CONNECTIONS")
                .ok()
                .and_then(|s| s.parse().ok())
                .unwrap_or(100),
        })
    }
}
```

### Dynamic Configuration

Supporting runtime config changes:
```rust
pub struct DynamicConfig {
    inner: RwLock<ServerConfig>,
    watchers: Vec<Sender<ConfigUpdate>>,
}

impl DynamicConfig {
    pub async fn update(&self, update: ConfigUpdate) -> Result<()> {
        let mut config = self.inner.write().await;
        config.apply_update(update.clone())?;
        
        for watcher in &self.watchers {
            let _ = watcher.send(update.clone()).await;
        }
        
        Ok(())
    }
}
```

## Logging and Monitoring

### Structured Logging

Log implementation:
```rust
#[derive(Debug, Serialize)]
struct LogEntry {
    timestamp: DateTime<Utc>,
    level: String,
    message: String,
    metadata: HashMap<String, Value>,
}

fn log_request(req: &Request<Body>, metadata: HashMap<String, Value>) {
    let entry = LogEntry {
        timestamp: Utc::now(),
        level: "INFO".to_string(),
        message: format!("{} {}", req.method(), req.uri()),
        metadata,
    };
    
    info!("{}", serde_json::to_string(&entry).unwrap());
}
```

### Metrics Collection

Basic metrics tracking:
```rust
pub struct Metrics {
    requests_total: AtomicU64,
    requests_failed: AtomicU64,
    response_time_ms: Histogram,
}

impl Metrics {
    pub fn record_request(&self, duration: Duration, success: bool) {
        self.requests_total.fetch_add(1, Ordering::Relaxed);
        if !success {
            self.requests_failed.fetch_add(1, Ordering::Relaxed);
        }
        self.response_time_ms.record(duration.as_millis() as u64);
    }
}
```

## Conclusion

Understanding these underlying concepts is crucial for working with and extending AIChat's HTTP server implementation. These concepts form the foundation for the server's robust operation and provide context for the implementation details covered in Parts 1 and 2.















File: lesson-8-part1.md


# AIChat Lesson 8: Utility Functions and Helper Systems
## Part 1: Architecture Overview and Core Utilities

The utility system forms the backbone of AIChat's infrastructure, providing essential functionality used throughout the application. This lesson explores the comprehensive utility framework that enables AIChat's features while ensuring cross-platform compatibility and robust error handling.

### Directory Structure and Organization

The utilities module is organized in a hierarchical structure that separates concerns while maintaining cohesive functionality:

```
utils/
├── mod.rs                 # Main module file with common utilities
├── abort_signal.rs        # Abort signal handling
├── clipboard.rs           # Cross-platform clipboard operations  
├── command.rs            # Shell command execution
├── crypto.rs             # Cryptographic functions
├── html_to_md.rs         # HTML to Markdown conversion
├── path.rs               # Path manipulation utilities
├── prompt_input.rs       # User input handling
├── render_prompt.rs      # REPL prompt rendering
├── request.rs            # HTTP request handling
├── spinner.rs            # Terminal progress indicators
└── variables.rs          # Variable interpolation
```

### Core Utility Components

The main utility module (`mod.rs`) provides foundational functionality used throughout AIChat's codebase. It implements several critical features:

1. Environment Detection:
   The module maintains important environmental awareness through lazy static variables:

```rust
lazy_static::lazy_static! {
    pub static ref CODE_BLOCK_RE: Regex = Regex::new(r"(?ms)```\w*(.*)```").unwrap();
    pub static ref IS_STDOUT_TERMINAL: bool = std::io::stdout().is_terminal();
    pub static ref NO_COLOR: bool = env::var("NO_COLOR").is_ok() || !*IS_STDOUT_TERMINAL;
}
```

These variables help AIChat adapt its behavior based on the execution environment, particularly for terminal capabilities and display options.

2. Error Handling Framework:
   The module implements a sophisticated error handling system that provides context-aware error reporting:

```rust
pub fn pretty_error(err: &anyhow::Error) -> String {
    let mut output = vec![];
    output.push(format!("Error: {err}"));
    let causes: Vec<_> = err.chain().skip(1).collect();
    if causes.len() > 0 {
        output.push("\nCaused by:".to_string());
        for (i, cause) in causes.into_iter().enumerate() {
            output.push(format!("{i:5}: {}", indent_text(cause, 7).trim()));
        }
    }
    output.join("\n")
}
```

This allows for detailed error reporting with full error chains while maintaining readability.

### The Abort Signal System

One of the most critical utility components is the abort signal system, implemented in `abort_signal.rs`. This system provides a thread-safe mechanism for canceling operations throughout the application:

```rust
pub struct AbortSignalInner {
    ctrlc: AtomicBool,
    ctrld: AtomicBool,
}
```

The abort signal system offers several key features:

1. Thread-safe state management using atomic operations
2. Support for both CTRL+C and CTRL+D signal handling
3. Ability to reset signals and check abort status
4. Async support through tokio integration

Example usage:

```rust
let abort_signal = create_abort_signal();

// Wait for abort signal asynchronously
async fn wait_abort_signal(abort_signal: &AbortSignal) {
    loop {
        if abort_signal.aborted() {
            break;
        }
        tokio::time::sleep(std::time::Duration::from_millis(25)).await;
    }
}
```

### Cross-Platform Clipboard Support

The clipboard utility module provides a unified interface for clipboard operations across different platforms:

```rust
#[cfg(not(any(target_os = "android", target_os = "emscripten")))]
pub fn set_text(text: &str) -> anyhow::Result<()> {
    let mut clipboard = CLIPBOARD.lock().unwrap();
    match clipboard.as_mut() {
        Some(clipboard) => {
            clipboard.set_text(text)?;
            #[cfg(target_os = "linux")]
            std::thread::sleep(std::time::Duration::from_millis(50));
        }
        None => anyhow::bail!("Failed to copy the text; no available clipboard"),
    }
    Ok(())
}
```

The clipboard module handles platform-specific considerations for:
- Windows using Win32 API
- macOS using AppKit
- Linux with both X11 and Wayland support
- Fallback behavior for unsupported platforms

These core utilities form the foundation of AIChat's functionality, providing essential services that other components build upon. The careful organization and robust implementation ensure reliability and maintainability across the entire application.

In the next section, we'll explore the command execution and path manipulation utilities that enable AIChat's powerful shell integration capabilities.















File: lesson-8-part2.md


# AIChat Lesson 8: Utility Functions and Helper Systems
## Part 2: Command Execution and Path Management

The command execution and path management utilities form a critical part of AIChat's functionality, enabling secure and reliable interaction with the underlying operating system. These components are essential for AIChat's shell integration and file handling capabilities.

### Command Execution System

The command execution module (`command.rs`) provides a robust interface for running shell commands and managing processes across different platforms. Let's examine its key components:

#### Shell Detection and Configuration

The module implements automatic shell detection and configuration through the `Shell` struct:

```rust
pub struct Shell {
    pub name: String,
    pub cmd: String,
    pub arg: String,
}

pub fn detect_shell() -> Shell {
    let cmd = env::var(get_env_name("shell")).ok().or_else(|| {
        if cfg!(windows) {
            // Windows-specific shell detection logic
            if let Ok(ps_module_path) = env::var("PSModulePath") {
                // ... PowerShell detection logic
            }
            None
        } else {
            env::var("SHELL").ok()
        }
    });
    // ... shell configuration logic
}
```

This system handles multiple shells including:
- Bash and sh on Unix-like systems
- PowerShell and cmd.exe on Windows
- Fish shell
- Nushell
- Custom shell configurations

#### Command Execution Interface

The module provides several ways to execute commands:

1. Basic Command Execution:
```rust
pub fn run_command<T: AsRef<OsStr>>(
    cmd: &str,
    args: &[T],
    envs: Option<HashMap<String, String>>,
) -> Result<i32> {
    let status = Command::new(cmd)
        .args(args.iter())
        .envs(envs.unwrap_or_default())
        .status()?;
    Ok(status.code().unwrap_or_default())
}
```

2. Command Execution with Output Capture:
```rust
pub fn run_command_with_output<T: AsRef<OsStr>>(
    cmd: &str,
    args: &[T],
    envs: Option<HashMap<String, String>>,
) -> Result<(bool, String, String)> {
    let output = Command::new(cmd)
        .args(args.iter())
        .envs(envs.unwrap_or_default())
        .output()?;
    // ... output processing
}
```

### Path Management System

The path management module (`path.rs`) implements secure path manipulation and file system operations. This module is crucial for maintaining security and preventing path traversal attacks.

#### Safe Path Operations

The module provides safe path joining and validation:

```rust
pub fn safe_join_path<T1: AsRef<Path>, T2: AsRef<Path>>(
    base_path: T1,
    sub_path: T2,
) -> Option<PathBuf> {
    let base_path = base_path.as_ref();
    let sub_path = sub_path.as_ref();
    if sub_path.is_absolute() {
        return None;
    }

    let mut joined_path = PathBuf::from(base_path);
    
    for component in sub_path.components() {
        if Component::ParentDir == component {
            return None;
        }
        joined_path.push(component);
    }

    if joined_path.starts_with(base_path) {
        Some(joined_path)
    } else {
        None
    }
}
```

This ensures that:
1. No path traversal attacks are possible
2. Paths remain within their intended boundaries
3. Cross-platform path handling is consistent

#### Glob Pattern Support

The module implements glob pattern handling for file operations:

```rust
pub async fn expand_glob_paths<T: AsRef<str>>(paths: &[T]) -> Result<Vec<String>> {
    let mut new_paths = vec![];
    for path in paths {
        let (path_str, suffixes) = parse_glob(path.as_ref())?;
        let suffixes = if suffixes.is_empty() {
            None
        } else {
            Some(&suffixes)
        };
        list_files(&mut new_paths, Path::new(&path_str), suffixes).await?;
    }
    Ok(new_paths)
}
```

This allows for:
- Pattern-based file selection
- Directory traversal with filters
- Extension-based file filtering

### Integration with Configuration System

The command and path utilities integrate closely with AIChat's configuration system to provide contextual awareness:

```rust
pub fn get_env_name(key: &str) -> String {
    format!("{}_{key}", env!("CARGO_CRATE_NAME"),).to_ascii_uppercase()
}

pub fn normalize_env_name(value: &str) -> String {
    value.replace('-', "_").to_ascii_uppercase()
}
```

This integration enables:
1. Environment-aware command execution
2. Configuration-driven path resolution
3. Dynamic shell behavior based on settings

### Cross-Platform Considerations

Both the command and path utilities implement careful platform-specific handling:

```rust
#[cfg(windows)]
fn polyfill_cmd_name<T: AsRef<Path>>(cmd_name: &str, bin_dir: &[T]) -> String {
    let cmd_name = cmd_name.to_string();
    if let Ok(exts) = std::env::var("PATHEXT") {
        for name in exts.split(';').map(|ext| format!("{cmd_name}{ext}")) {
            for dir in bin_dir {
                let path = dir.as_ref().join(&name);
                if path.exists() {
                    return name.to_string();
                }
            }
        }
    }
    cmd_name
}
```

These utilities form a crucial part of AIChat's infrastructure, enabling secure and reliable system interactions while maintaining cross-platform compatibility. Their robust implementation ensures that AIChat can provide consistent behavior across different operating systems and shell environments.

In the next section, we'll explore AIChat's HTTP request handling and progress indication systems.















File: lesson-8-part3.md


# AIChat Lesson 8: Utility Functions and Helper Systems
## Part 3: HTTP Requests and Progress Indication

The HTTP request handling and progress indication systems in AIChat provide essential capabilities for interacting with external services and providing visual feedback to users. These components are crucial for AIChat's RAG (Retrieval-Augmented Generation) capabilities and overall user experience.

### HTTP Request System

The request module (`request.rs`) implements a sophisticated system for handling HTTP operations with support for various content types, automatic retries, and progress tracking.

#### Core HTTP Client Configuration

The module maintains a global HTTP client with carefully configured defaults:

```rust
lazy_static::lazy_static! {
    static ref CLIENT: Result<reqwest::Client> = {
        let builder = reqwest::ClientBuilder::new().timeout(Duration::from_secs(30));
        let builder = set_proxy(builder, None)?;
        let client = builder.build()?;
        Ok(client)
    };
}
```

This configuration includes:
- Default timeout settings
- Proxy support
- Cross-platform compatibility
- Error handling and recovery

#### Content Type Handling

The module implements comprehensive content type detection and handling:

```rust
let content_type = res
    .headers()
    .get(CONTENT_TYPE)
    .and_then(|v| v.to_str().ok())
    .map(|v| match v.split_once(';') {
        Some((mime, _)) => mime.trim(),
        None => v,
    })
    .unwrap_or_else(|| {
        format!(
            "_/{}",
            get_patch_extension(path).unwrap_or_else(|| DEFAULT_EXTENSION.into())
        )
    });
```

The system supports various content types including:
- PDF documents
- Office documents (DOCX, XLSX, etc.)
- HTML content with markdown conversion
- Media files with base64 encoding
- Plain text and custom formats

#### Web Crawling Capabilities

The request module includes a robust web crawling system for document retrieval:

```rust
pub async fn crawl_website(start_url: &str, options: CrawlOptions) -> Result<Vec<Page>> {
    let start_url = Url::parse(start_url)?;
    let mut paths = vec![start_url.path().to_string()];
    let normalized_start_url = normalize_start_url(&start_url);
    
    // Crawler configuration and setup
    let semaphore = Arc::new(Semaphore::new(MAX_CRAWLS));
    let mut result_pages = Vec::new();

    // Main crawling loop
    while index < paths.len() {
        let batch = paths[index..std::cmp::min(index + MAX_CRAWLS, paths.len())].to_vec();
        // Concurrent page processing
        // ...
    }
    
    Ok(result_pages)
}
```

The crawler provides features like:
- Concurrent page processing
- Rate limiting
- Content extraction
- Link following with filters

### Progress Indication System

The spinner module (`spinner.rs`) implements a sophisticated progress indication system for long-running operations.

#### Spinner Implementation

The core spinner functionality is implemented through the `SpinnerInner` struct:

```rust
pub struct SpinnerInner {
    index: usize,
    message: String,
}

impl SpinnerInner {
    const DATA: [&'static str; 10] = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];

    fn step(&mut self) -> Result<()> {
        if !*IS_STDOUT_TERMINAL || self.message.is_empty() {
            return Ok(());
        }
        let mut writer = stdout();
        let frame = Self::DATA[self.index % Self::DATA.len()];
        let dots = ".".repeat((self.index / 5) % 4);
        let line = format!("{frame}{}{:<3}", self.message, dots);
        queue!(writer, cursor::MoveToColumn(0), style::Print(line),)?;
        // ... terminal handling
    }
}
```

#### Asynchronous Progress Handling

The spinner system integrates with Tokio for asynchronous operation:

```rust
pub async fn create_spinner(message: &str) -> Spinner {
    let message = format!(" {message}");
    let (tx, rx) = mpsc::unbounded_channel();
    tokio::spawn(run_spinner(message, rx));
    Spinner(tx)
}

async fn run_spinner(message: String, mut rx: mpsc::UnboundedReceiver<SpinnerEvent>) -> Result<()> {
    let mut spinner = SpinnerInner::new(&message);
    let mut interval = interval(Duration::from_millis(50));
    
    loop {
        tokio::select! {
            _ = interval.tick() => {
                let _ = spinner.step();
            }
            evt = rx.recv() => {
                // Handle spinner events
            }
        }
    }
}
```

This enables:
- Non-blocking progress indication
- Message updates
- Clean cancellation
- Terminal state management

#### Integration with Terminal

The spinner system carefully manages terminal state:

```rust
async fn run_abortable_spinner(
    message: &str,
    abort_signal: AbortSignal,
    done_rx: oneshot::Receiver<()>,
) -> Result<()> {
    enable_raw_mode()?;
    let ret = run_abortable_spinner_inner(message, abort_signal, done_rx).await;
    disable_raw_mode()?;
    ret
}
```

This ensures:
- Proper terminal cleanup
- Cursor visibility management
- Cross-platform compatibility
- Signal handling

### Error Handling and Recovery

Both systems implement comprehensive error handling:

```rust
pub async fn abortable_run_with_spinner<F, T>(
    task: F,
    message: &str,
    abort_signal: AbortSignal,
) -> Result<T>
where
    F: Future<Output = Result<T>>,
{
    if *IS_STDOUT_TERMINAL {
        let (done_tx, done_rx) = oneshot::channel();
        let run_task = async {
            tokio::select! {
                ret = task => {
                    let _ = done_tx.send(());
                    ret
                }
                _ = wait_abort_signal(&abort_signal) => {
                    let _ = done_tx.send(());
                    bail!("Aborted.");
                },
            }
        };
        // Task execution with progress indication
    } else {
        task.await
    }
}
```

This provides:
- Graceful error recovery
- Resource cleanup
- User feedback
- Operation cancellation

The HTTP request and progress indication systems work together to provide a robust foundation for AIChat's network operations and user interface feedback. Their careful implementation ensures reliable operation across different platforms and usage scenarios.

In the final section, we'll explore AIChat's variable interpolation and terminal rendering systems.















File: lesson-8-part4.md


# AIChat Lesson 8: Utility Functions and Helper Systems
## Part 4: Variable Interpolation and Terminal Rendering

The final components of AIChat's utility system handle variable interpolation and terminal rendering, providing crucial functionality for dynamic content generation and user interface presentation. These systems enable AIChat's sophisticated REPL interface and dynamic content generation capabilities.

### Variable Interpolation System

The variables module (`variables.rs`) implements a powerful system for handling dynamic content substitution throughout the application.

#### Core Variable Pattern Matching

The module defines a regex pattern for variable interpolation:

```rust
lazy_static::lazy_static! {
    pub static ref RE_VARIABLE: Regex = Regex::new(r"\{\{(\w+)\}\}").unwrap();
}
```

This pattern enables the recognition of variables in the format `{{variable_name}}`.

#### System Variable Support

The interpolation system provides access to system information through predefined variables:

```rust
pub fn interpolate_variables(text: &mut String) {
    *text = RE_VARIABLE
        .replace_all(text, |caps: &Captures<'_>| {
            let key = &caps[1];
            match key {
                "__os__" => env::consts::OS.to_string(),
                "__os_distro__" => {
                    let info = os_info::get();
                    if env::consts::OS == "linux" {
                        format!("{info} (linux)")
                    } else {
                        info.to_string()
                    }
                }
                "__os_family__" => env::consts::FAMILY.to_string(),
                "__arch__" => env::consts::ARCH.to_string(),
                "__shell__" => SHELL.name.clone(),
                "__locale__" => sys_locale::get_locale().unwrap_or_default(),
                "__now__" => now(),
                "__cwd__" => env::current_dir()
                    .map(|v| v.display().to_string())
                    .unwrap_or_default(),
                _ => format!("{{{{{}}}}}", key),
            }
        })
        .to_string();
}
```

### Terminal Rendering System

The render_prompt module (`render_prompt.rs`) provides sophisticated terminal rendering capabilities for AIChat's REPL interface.

#### Template-Based Rendering

The module implements a template-based rendering system:

```rust
pub fn render_prompt(template: &str, variables: &HashMap<&str, String>) -> String {
    let exprs = parse_template(template);
    eval_exprs(&exprs, variables)
}
```

This system supports:
- Conditional rendering
- Variable substitution
- Complex template structures
- Error handling

#### Expression Parsing

The system implements sophisticated expression parsing:

```rust
fn parse_block(current: &mut Vec<char>) -> Expr {
    let value: String = current.drain(..).collect();
    match value.split_once(' ') {
        Some((name, tail)) => {
            if let Some(name) = name.strip_prefix('?') {
                let block_exprs = parse_template(tail);
                Expr::Block(BlockType::Yes, name.to_string(), block_exprs)
            } else if let Some(name) = name.strip_prefix('!') {
                let block_exprs = parse_template(tail);
                Expr::Block(BlockType::No, name.to_string(), block_exprs)
            } else {
                Expr::Text(format!("{{{value}}}"))
            }
        }
        None => Expr::Variable(value),
    }
}
```

#### Color and Style Support

The utility system includes comprehensive color and style support:

```rust
pub fn color_text(input: &str, color: nu_ansi_term::Color) -> String {
    if *NO_COLOR {
        return input.to_string();
    }
    nu_ansi_term::Style::new()
        .fg(color)
        .paint(input)
        .to_string()
}

pub fn dimmed_text(input: &str) -> String {
    if *NO_COLOR {
        return input.to_string();
    }
    nu_ansi_term::Style::new().dimmed().paint(input).to_string()
}
```

### Integration with HTML Processing

The system includes HTML processing capabilities through the html_to_md module:

```rust
pub fn html_to_md(html: &str) -> String {
    let mut handlers: Vec<TagHandler> = vec![
        Rc::new(RefCell::new(markdown::ParagraphHandler)),
        Rc::new(RefCell::new(markdown::HeadingHandler)),
        Rc::new(RefCell::new(markdown::ListHandler)),
        Rc::new(RefCell::new(markdown::TableHandler::new())),
        Rc::new(RefCell::new(markdown::StyledTextHandler)),
        Rc::new(RefCell::new(markdown::CodeHandler)),
        Rc::new(RefCell::new(markdown::WebpageChromeRemover)),
    ];

    html_to_markdown::convert_html_to_markdown(html.as_bytes(), &mut handlers)
        .unwrap_or_else(|_| html.to_string())
}
```

### Testing and Verification

The utility systems include comprehensive testing capabilities:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_render() {
        let prompt = "{?session {session}{?role /}}{role}{?session )}{!session >}";
        assert_render!(prompt, [], ">");
        assert_render!(prompt, [("role", "coder"),], "coder>");
        assert_render!(prompt, [("session", "temp"),], "temp)");
        assert_render!(
            prompt,
            [("session", "temp"), ("role", "coder"),],
            "temp/coder)"
        );
    }
}
```

### Performance Considerations

The utility systems implement various performance optimizations:

1. Lazy Evaluation:
```rust
lazy_static::lazy_static! {
    static ref CODE_BLOCK_RE: Regex = Regex::new(r"(?ms)```\w*(.*)```").unwrap();
    static ref IS_STDOUT_TERMINAL: bool = std::io::stdout().is_terminal();
    static ref NO_COLOR: bool = env::var("NO_COLOR").is_ok() || !*IS_STDOUT_TERMINAL;
}
```

2. Buffer Management:
```rust
pub fn indent_text<T: ToString>(s: T, size: usize) -> String {
    let indent_str = " ".repeat(size);
    s.to_string()
        .split('\n')
        .map(|line| format!("{}{}", indent_str, line))
        .collect::<Vec<String>>()
        .join("\n")
}
```

Together, these components provide AIChat with powerful capabilities for dynamic content generation and terminal interaction. Their careful implementation ensures reliable operation across different platforms while maintaining high performance and user experience quality.

This concludes our exploration of AIChat's utility systems. The combination of these utilities provides a robust foundation for AIChat's functionality, enabling sophisticated features while maintaining code quality and maintainability.















File: lesson-8-part5.md


# AIChat Lesson 8: Utility Functions and Helper Systems
## Part 5: Core Concepts and Advanced Topics

This section covers fundamental concepts that were assumed in previous parts and explores additional important aspects of AIChat's utility systems. Understanding these concepts is crucial for working with and extending AIChat's functionality.

### Rust-Specific Concepts

#### 1. Trait System and Implementation Patterns

AIChat makes extensive use of Rust's trait system for abstraction and code organization:

```rust
pub trait ReplHighlighter {
    fn highlight(&self, line: &str, cursor: usize) -> StyledText;
}

pub trait Client {
    fn chat_completions(&self, input: Input) -> BoxFuture<'_, Result<ChatCompletionsOutput>>;
    fn embeddings(&self, data: &EmbeddingsData) -> BoxFuture<'_, Result<Vec<Vec<f32>>>>;
    // ... other required methods
}
```

Important trait-related concepts include:
- Trait bounds and generic constraints
- Dynamic dispatch with trait objects
- Associated types and default implementations
- Marker traits for type safety

#### 2. Memory Management and Ownership

AIChat implements careful memory management patterns:

```rust
// Arc for thread-safe reference counting
pub type AbortSignal = Arc<AbortSignalInner>;

// Smart pointer usage for interior mutability
lazy_static::lazy_static! {
    static ref CLIPBOARD: std::sync::Arc<std::sync::Mutex<Option<arboard::Clipboard>>> =
        std::sync::Arc::new(std::sync::Mutex::new(arboard::Clipboard::new().ok()));
}
```

Key memory concepts include:
- RAII (Resource Acquisition Is Initialization)
- Borrowing rules and lifetimes
- Interior mutability patterns
- Thread safety considerations

### Asynchronous Programming

#### 1. Tokio Runtime and Async Patterns

AIChat is built on Tokio for asynchronous operation:

```rust
#[tokio::main]
async fn main() -> Result<()> {
    // Application setup
    if let Err(err) = run(config, cli, text).await {
        render_error(err);
        std::process::exit(1);
    }
    Ok(())
}
```

Important async concepts include:
- Future trait and async/await syntax
- Task spawning and management
- Channel communication
- Error propagation in async contexts

#### 2. Stream Processing

Stream handling is crucial for real-time data processing:

```rust
pub async fn crawl_website(start_url: &str, options: CrawlOptions) -> Result<Vec<Page>> {
    let stream = UnboundedReceiverStream::new(rx);
    let stream = stream.filter_map(move |res_event| {
        // Stream transformation logic
    });
    // ... stream processing
}
```

### Cross-Platform Development

#### 1. Conditional Compilation

AIChat uses conditional compilation for platform-specific code:

```rust
#[cfg(windows)]
const PATH_SEP: &str = ";";
#[cfg(not(windows))]
const PATH_SEP: &str = ":";

#[cfg(target_os = "macos")]
mod macos_specific {
    // macOS-specific implementations
}
```

Important concepts include:
- Platform detection
- Feature flags
- Target-specific dependencies
- Build script integration

#### 2. Terminal Handling

Terminal interaction requires platform-specific considerations:

```rust
pub struct Terminal {
    raw_mode: bool,
    color_support: bool,
    size: (u16, u16),
}

impl Terminal {
    pub fn enable_raw_mode(&mut self) -> Result<()> {
        #[cfg(unix)]
        {
            // Unix-specific terminal handling
        }
        #[cfg(windows)]
        {
            // Windows-specific terminal handling
        }
    }
}
```

### Error Handling Patterns

#### 1. Error Context and Propagation

AIChat implements sophisticated error handling:

```rust
pub fn init(declarations_path: &Path) -> Result<Self> {
    let declarations: Vec<FunctionDeclaration> = if declarations_path.exists() {
        let ctx = || {
            format!(
                "Failed to load functions at {}",
                declarations_path.display()
            )
        };
        let content = fs::read_to_string(declarations_path).with_context(ctx)?;
        serde_json::from_str(&content).with_context(ctx)?
    } else {
        vec![]
    };
    Ok(Self { declarations })
}
```

Important error handling concepts:
- Error type conversion
- Context addition
- Error chaining
- Result combinators

#### 2. Custom Error Types

AIChat defines custom error types for specific scenarios:

```rust
#[derive(Debug, Error)]
pub enum ConfigError {
    #[error("Invalid configuration: {0}")]
    Invalid(String),
    #[error("Missing required field: {0}")]
    MissingField(String),
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
}
```

### Testing Methodologies

#### 1. Unit Testing

Comprehensive unit testing patterns:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_fuzzy_match() {
        assert!(fuzzy_match("openai:gpt-4-turbo", "gpt4"));
        assert!(fuzzy_match("openai:gpt-4-turbo", "oai4"));
        assert!(!fuzzy_match("openai:gpt-4-turbo", "4gpt"));
    }

    #[test]
    fn test_path_operations() {
        assert_eq!(
            safe_join_path("/home/user/dir1", "files/file1"),
            Some(PathBuf::from("/home/user/dir1/files/file1"))
        );
    }
}
```

#### 2. Integration Testing

Integration test patterns:

```rust
#[cfg(test)]
mod integration_tests {
    use super::*;

    #[tokio::test]
    async fn test_http_client() {
        let client = init_client(&config, None)?;
        let result = client.chat_completions(input).await?;
        assert!(result.text.len() > 0);
    }
}
```

### Security Considerations

#### 1. Input Validation

Careful input validation patterns:

```rust
pub fn validate_path(path: &Path) -> Result<()> {
    if path.components().any(|c| matches!(c, Component::ParentDir)) {
        bail!("Path traversal detected");
    }
    Ok(())
}
```

#### 2. Resource Cleanup

Proper resource management:

```rust
impl Drop for SpinnerInner {
    fn drop(&mut self) {
        let _ = disable_raw_mode();
        let _ = execute!(
            stdout(),
            cursor::Show,
            terminal::Clear(terminal::ClearType::FromCursorDown)
        );
    }
}
```

### Additional Components

#### 1. Configuration Management

Configuration handling patterns:

```rust
pub struct Config {
    pub model: Model,
    pub temperature: Option<f64>,
    pub top_p: Option<f64>,
    pub stream: bool,
    pub functions: Functions,
    // ... other configuration fields
}
```

#### 2. Logging System

Logging implementation:

```rust
fn setup_logger(is_serve: bool) -> Result<()> {
    let config = ConfigBuilder::new()
        .add_filter_allow(log_filter)
        .set_time_format_custom(format_description!(
            "[year]-[month]-[day]T[hour]:[minute]:[second].[subsecond digits:3]Z"
        ))
        .set_thread_level(LevelFilter::Off)
        .build();
    
    match log_path {
        None => {
            SimpleLogger::init(log_level, config)?;
        }
        Some(log_path) => {
            ensure_parent_exists(&log_path)?;
            let log_file = std::fs::File::create(log_path)?;
            WriteLogger::init(log_level, config, log_file)?;
        }
    }
    Ok(())
}
```

These concepts and components form the foundation upon which AIChat's utility systems are built. Understanding them is crucial for:
- Maintaining the codebase
- Implementing new features
- Debugging issues
- Ensuring cross-platform compatibility
- Maintaining security and reliability

The careful implementation of these concepts ensures that AIChat remains maintainable, secure, and reliable across different platforms and usage scenarios.















File: lesson-8-part6.md


# AIChat Lesson 8: Utility Functions and Helper Systems
## Part 6: Practical Examples and Testing Strategies

This section provides practical examples and testing strategies for working with AIChat's utility systems. These examples demonstrate real-world usage and best practices for implementing and testing utility functions.

### Practical Examples

#### 1. File Operation Utilities

Here's a complete example of implementing a safe file handling utility:

```rust
use anyhow::{Context, Result};
use std::path::{Path, PathBuf};

pub struct SafeFileHandler {
    root_dir: PathBuf,
    temp_dir: PathBuf,
}

impl SafeFileHandler {
    pub fn new(root_dir: impl AsRef<Path>) -> Result<Self> {
        let root_dir = root_dir.as_ref().to_path_buf();
        let temp_dir = root_dir.join("temp");
        std::fs::create_dir_all(&temp_dir)
            .context("Failed to create temp directory")?;
            
        Ok(Self { root_dir, temp_dir })
    }
    
    pub fn safe_write(&self, relative_path: &str, content: &[u8]) -> Result<()> {
        // Validate path is within root directory
        let target_path = safe_join_path(&self.root_dir, relative_path)
            .ok_or_else(|| anyhow::anyhow!("Invalid path"))?;
            
        // Create temporary file
        let temp_file = temp_file("-safe-write-", "");
        std::fs::write(&temp_file, content)?;
        
        // Ensure parent directory exists
        if let Some(parent) = target_path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        
        // Atomic move operation
        #[cfg(unix)]
        std::fs::rename(&temp_file, &target_path)?;
        
        #[cfg(windows)]
        {
            if target_path.exists() {
                std::fs::remove_file(&target_path)?;
            }
            std::fs::rename(&temp_file, &target_path)?;
        }
        
        Ok(())
    }
    
    pub fn safe_read(&self, relative_path: &str) -> Result<Vec<u8>> {
        let path = safe_join_path(&self.root_dir, relative_path)
            .ok_or_else(|| anyhow::anyhow!("Invalid path"))?;
            
        std::fs::read(&path).context("Failed to read file")
    }
}

// Example usage:
async fn example_usage() -> Result<()> {
    let handler = SafeFileHandler::new("/app/data")?;
    
    // Safe write operation
    handler.safe_write("configs/app.yaml", b"key: value\n")?;
    
    // Safe read operation
    let content = handler.safe_read("configs/app.yaml")?;
    println!("Read: {}", String::from_utf8_lossy(&content));
    
    Ok(())
}
```

#### 2. Custom Progress Indicator

Implementation of a custom progress indicator with percentage:

```rust
pub struct ProgressTracker {
    spinner: Spinner,
    total: usize,
    current: AtomicUsize,
}

impl ProgressTracker {
    pub async fn new(total: usize, message: &str) -> Self {
        let spinner = create_spinner(message).await;
        Self {
            spinner,
            total,
            current: AtomicUsize::new(0),
        }
    }
    
    pub fn increment(&self) -> Result<()> {
        let current = self.current.fetch_add(1, Ordering::SeqCst) + 1;
        let percentage = (current as f64 / self.total as f64 * 100.0) as usize;
        
        self.spinner.set_message(format!(
            "Progress: [{}/{}] {}%",
            current,
            self.total,
            percentage
        ))?;
        
        Ok(())
    }
}

// Example usage:
async fn process_items(items: Vec<String>) -> Result<()> {
    let progress = ProgressTracker::new(items.len(), "Processing items").await;
    
    for item in items {
        // Process item
        tokio::time::sleep(Duration::from_millis(100)).await;
        progress.increment()?;
    }
    
    Ok(())
}
```

### Testing Strategies

#### 1. Unit Testing Framework

Comprehensive testing framework for utilities:

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Arc;
    use tokio::sync::Mutex;
    
    struct TestContext {
        temp_dir: PathBuf,
        handler: SafeFileHandler,
    }
    
    impl TestContext {
        async fn setup() -> Result<Arc<Mutex<Self>>> {
            let temp_dir = tempdir()?.into_path();
            let handler = SafeFileHandler::new(&temp_dir)?;
            
            Ok(Arc::new(Mutex::new(Self {
                temp_dir,
                handler,
            })))
        }
        
        async fn cleanup(&self) -> Result<()> {
            std::fs::remove_dir_all(&self.temp_dir)?;
            Ok(())
        }
    }
    
    #[tokio::test]
    async fn test_file_operations() -> Result<()> {
        let ctx = TestContext::setup().await?;
        let ctx = ctx.lock().await;
        
        // Test safe write
        ctx.handler.safe_write("test.txt", b"Hello")?;
        
        // Test safe read
        let content = ctx.handler.safe_read("test.txt")?;
        assert_eq!(content, b"Hello");
        
        // Test invalid path
        assert!(ctx.handler.safe_read("../outside.txt").is_err());
        
        ctx.cleanup().await?;
        Ok(())
    }
    
    #[tokio::test]
    async fn test_progress_tracker() -> Result<()> {
        let items = vec!["a", "b", "c"];
        let progress = ProgressTracker::new(items.len(), "Testing").await;
        
        for _ in items {
            progress.increment()?;
        }
        
        assert_eq!(
            progress.current.load(Ordering::SeqCst),
            items.len()
        );
        
        Ok(())
    }
}
```

#### 2. Integration Testing Patterns

Examples of integration tests:

```rust
#[cfg(test)]
mod integration_tests {
    use super::*;
    use test_context::{test_context, TestContext};
    
    struct IntegrationTestContext {
        config: GlobalConfig,
        temp_dir: PathBuf,
    }
    
    #[async_trait]
    impl TestContext for IntegrationTestContext {
        async fn setup() -> Result<Self> {
            let temp_dir = tempdir()?.into_path();
            let config = Config::init_test(&temp_dir)?;
            
            Ok(Self {
                config: Arc::new(RwLock::new(config)),
                temp_dir,
            })
        }
        
        async fn teardown(self) -> Result<()> {
            std::fs::remove_dir_all(self.temp_dir)?;
            Ok(())
        }
    }
    
    #[test_context(IntegrationTestContext)]
    #[tokio::test]
    async fn test_http_operations(ctx: &IntegrationTestContext) -> Result<()> {
        let client = init_client(&ctx.config, None)?;
        
        // Test file download
        let (content, ext) = client
            .fetch(
                &HashMap::new(),
                "https://example.com/test.txt",
                false
            )
            .await?;
            
        assert_eq!(ext, "txt");
        assert!(!content.is_empty());
        
        Ok(())
    }
}
```

### Best Practices for Extension

#### 1. Adding New Utility Functions

When adding new utility functions, follow these patterns:

```rust
// 1. Clear documentation
/// Performs a fuzzy search on text using a pattern.
/// 
/// # Arguments
/// * `text` - The text to search in
/// * `pattern` - The pattern to search for
/// 
/// # Returns
/// `true` if the pattern matches, `false` otherwise
/// 
/// # Examples
/// ```
/// assert!(fuzzy_match("hello world", "hw"));
/// ```
pub fn fuzzy_match(text: &str, pattern: &str) -> bool {
    // Implementation
}

// 2. Error handling with context
pub fn process_file(path: &Path) -> Result<String> {
    let content = std::fs::read_to_string(path)
        .with_context(|| format!("Failed to read file: {}", path.display()))?;
        
    Ok(content)
}

// 3. Configuration integration
pub fn init_utility(config: &GlobalConfig) -> Result<()> {
    let settings = config.read().utility_settings()?;
    // Initialize with settings
    Ok(())
}
```

#### 2. Cross-Platform Compatibility

Ensure cross-platform compatibility in new utilities:

```rust
pub struct PlatformUtils {
    #[cfg(windows)]
    win_specific: WindowsSpecific,
    #[cfg(unix)]
    unix_specific: UnixSpecific,
    common: CommonUtils,
}

impl PlatformUtils {
    pub fn new() -> Result<Self> {
        Ok(Self {
            #[cfg(windows)]
            win_specific: WindowsSpecific::new()?,
            #[cfg(unix)]
            unix_specific: UnixSpecific::new()?,
            common: CommonUtils::new()?,
        })
    }
    
    pub fn platform_path(&self, path: &str) -> String {
        #[cfg(windows)]
        {
            path.replace('/', "\\")
        }
        #[cfg(unix)]
        {
            path.replace('\\', "/")
        }
    }
}
```

### Performance Optimization Patterns

Example of performance optimization strategies:

```rust
pub struct CachedOperation<T> {
    cache: Arc<RwLock<LruCache<String, T>>>,
    compute_fn: Arc<dyn Fn(&str) -> Result<T> + Send + Sync>,
}

impl<T: Clone + Send + Sync + 'static> CachedOperation<T> {
    pub fn new(
        capacity: usize,
        compute_fn: impl Fn(&str) -> Result<T> + Send + Sync + 'static,
    ) -> Self {
        Self {
            cache: Arc::new(RwLock::new(LruCache::new(capacity))),
            compute_fn: Arc::new(compute_fn),
        }
    }
    
    pub fn get(&self, key: &str) -> Result<T> {
        // Try read lock first
        if let Some(value) = self.cache.read().get(key) {
            return Ok(value.clone());
        }
        
        // Compute and cache if missing
        let value = (self.compute_fn)(key)?;
        self.cache.write().put(key.to_string(), value.clone());
        
        Ok(value)
    }
}

// Example usage:
async fn example_caching() -> Result<()> {
    let cached_op = CachedOperation::new(100, |key| {
        // Expensive computation
        Ok(key.to_uppercase())
    });
    
    // First call computes
    let result1 = cached_op.get("test")?;
    // Second call uses cache
    let result2 = cached_op.get("test")?;
    
    assert_eq!(result1, result2);
    Ok(())
}
```

These examples demonstrate practical applications of AIChat's utility systems and provide patterns for testing, extending, and optimizing utility functions. By following these patterns, developers can maintain consistency and reliability while adding new functionality to AIChat.















File: lesson-9-part1.md


# Lesson 9: Agent System and Function Calling
## Overview and Architecture

The agent system represents one of AIChat's most sophisticated features, combining prompts, tools, and document retrieval into a unified interface. This lesson explores the implementation details, architectural decisions, and cross-platform considerations that make this system both powerful and flexible.

### Project Structure
```
src/
├── config/
│   └── agent.rs               # Agent configuration and management
├── function.rs                # Core function calling implementation
└── client/
    ├── message.rs             # Message handling for function calls
    └── common.rs              # Shared functionality for function calling
```

The agent system is built around three key components:

1. Agent Configuration - Defined in `config/agent.rs`, handles agent state, variables and configuration management
2. Function Declarations - Implemented in `function.rs`, provides the core function calling capabilities 
3. Message Handling - Managed through `client/message.rs`, handles communication between components

### Core Architecture 

The agent system is designed around the concept of combining three key elements into a unified interface:

1. Instructions (Prompts) - Provides the base behavior and guidance for the agent
2. Tools (Function Callings) - Enables interaction with external systems and data
3. Documents (RAG) - Allows context-aware responses using external knowledge

The implementation centers around the `Agent` struct which serves as the primary orchestrator:

```rust
pub struct Agent {
    name: String,
    config: AgentConfig,
    definition: AgentDefinition,
    shared_variables: IndexMap<String, String>, 
    session_variables: Option<IndexMap<String, String>>,
    functions: Functions,
    rag: Option<Arc<Rag>>,
    model: Model,
}
```

This structure provides:

- Encapsulation of agent state and behavior
- Management of variables across different scopes
- Integration with the function calling system
- Connection to the RAG subsystem for knowledge retrieval

The agent configuration is handled through `AgentConfig` which manages settings like:

```rust
pub struct AgentConfig {
    pub model_id: Option<String>,
    pub temperature: Option<f64>, 
    pub top_p: Option<f64>,
    pub use_tools: Option<String>,
    pub agent_prelude: Option<String>,
    pub variables: IndexMap<String, String>,
}
```

### Function Declaration System

The function calling system uses a JSON Schema-based approach for declaring available tools:

```rust
pub struct FunctionDeclaration {
    pub name: String,
    pub description: String, 
    pub parameters: JsonSchema,
    pub agent: bool,
}
```

This schema-based approach provides:

1. Strong typing of function parameters
2. Clear documentation of function capabilities 
3. Runtime validation of function calls
4. Cross-platform compatibility of function definitions

### Variable Management

The agent system implements a sophisticated variable management system that handles both shared and session-specific variables:

```rust
pub fn init_agent_variables(
    agent_variables: &[AgentVariable],
    variables: &IndexMap<String, String>,
) -> Result<IndexMap<String, String>>
```

Key features include:

- Persistent variable storage across sessions
- Dynamic variable updates during execution
- Proper scoping between shared and session contexts
- Type-safe variable access and modification

### Security Architecture 

The agent system implements several critical security measures:

1. Tool Isolation - Each tool runs as a separate process with its own environment
2. Input Validation - All function parameters are validated against their JSON schema
3. Resource Limits - Tools are executed with appropriate timeouts and constraints
4. Path Sanitization - All file paths are properly sanitized and validated

### Cross-Platform Support

The system implements careful cross-platform handling:

```rust
pub fn agent_functions_dir(name: &str) -> PathBuf {
    match env::var(format!("{}_FUNCTIONS_DIR", normalize_env_name(name))) {
        Ok(value) => PathBuf::from(value),
        Err(_) => Self::agents_functions_dir().join(name),
    }
}
```

Platform-specific considerations include:

1. Path normalization for different operating systems
2. Shell detection and command execution
3. Environment variable handling
4. File system permissions and access

This architectural foundation provides a robust base for building sophisticated AI agents that can safely interact with external systems while maintaining state and context across interactions.















File: lesson-9-part2.md


# Implementation and Usage Guide

### Agent Configuration and Usage

Agents in AIChat can be configured through YAML files that define their behavior, tools, and capabilities. Here's a comprehensive example:

```yaml
name: enhanced_agent
description: "Enhanced capabilities agent"
version: "1.0"
instructions: |
  This agent assists with enhanced capabilities...
variables:
  - name: API_KEY
    description: "API key for external service"
    default: null
  - name: WORKSPACE
    description: "Working directory"
    default: "/tmp"
conversation_starters:
  - "What can you help me with?"
  - "How do I use this tool?"
documents:
  - "docs/**/*.md"
```

The configuration system supports several key features:

1. Variables with defaults and descriptions
2. Conversation starters for guided interaction
3. Document paths for knowledge integration
4. Version tracking and documentation

### Using the Agent System

From the command line:
```bash
# Start an agent
aichat -a agent_name

# Start with specific session
aichat -a agent_name -s session_name

# List available agents
aichat --list-agents
```

From the REPL:
```
> .agent agent_name
> .variable set API_KEY your_key_here
> .starter   # Show conversation starters
```

### RAG Integration

The agent system integrates with AIChat's RAG capabilities through two primary mechanisms:

1. Document Configuration:
```yaml
documents:
  - "docs/**/*.md"    # Load all markdown files
  - "api/*.yaml"      # Load API specifications
  - "https://example.com/docs/**"  # Load web documents
```

2. Runtime Integration:
```rust
impl Agent {
    pub async fn init(
        config: &GlobalConfig,
        name: &str,
        abort_signal: AbortSignal,
    ) -> Result<Self> {
        // Initialize RAG system
        let rag = if rag_path.exists() {
            Some(Arc::new(Rag::load(config, DEFAULT_AGENT_NAME, &rag_path)?))
        } else if !definition.documents.is_empty() {
            // Initialize new RAG from documents
            let rag = Rag::init(config, "rag", &rag_path, &document_paths, abort_signal).await?;
            Some(Arc::new(rag))
        } else {
            None
        };
        // ... rest of initialization
    }
}
```

### Function Calling Implementation

The function calling system is implemented through a combination of JSON Schema definitions and runtime execution:

1. Function Declaration:
```json
{
  "name": "web_search",
  "description": "Search the web for information",
  "parameters": {
    "type": "object",
    "properties": {
      "query": {
        "type": "string",
        "description": "Search query"
      },
      "max_results": {
        "type": "integer",
        "description": "Maximum number of results"
      }
    },
    "required": ["query"]
  }
}
```

2. Tool Integration:
```rust
pub fn eval_tool_calls(config: &GlobalConfig, mut calls: Vec<ToolCall>) -> Result<Vec<ToolResult>> {
    let mut output = vec![];
    // Dedup and validate calls
    calls = ToolCall::dedup(calls);
    if calls.is_empty() {
        bail!("Infinite loop detected");
    }
    // Execute each call
    for call in calls {
        let result = call.eval(config)?;
        output.push(ToolResult::new(call, result));
    }
    Ok(output)
}
```

### Error Handling and Recovery

The system implements comprehensive error handling:

```rust
pub fn eval(&self, config: &GlobalConfig) -> Result<Value> {
    let function_name = self.name.clone();
    // Various error checks
    if !config.read().functions.contains(&function_name) {
        bail!("Unexpected call: {function_name}");
    }
    
    // Execute with proper cleanup
    let result = catch_unwind(|| {
        // Tool execution
    });

    match result {
        Ok(value) => Ok(value),
        Err(err) => {
            cleanup();
            Err(err)
        }
    }
}
```

### Best Practices

When working with the agent system:

1. Tool Development:
   - Implement proper error handling and status codes
   - Use structured logging for debugging
   - Validate all inputs before processing
   - Implement proper cleanup in case of failures

2. Agent Configuration:
   - Keep prompts focused and specific
   - Implement proper variable validation
   - Use appropriate model settings for the task
   - Document tool dependencies and requirements

3. Security:
   - Validate and sanitize all inputs
   - Implement proper access controls
   - Use environment variables for sensitive data
   - Monitor and limit resource usage

4. Performance:
   - Implement caching where appropriate
   - Use async/await for I/O operations
   - Batch operations when possible
   - Monitor memory usage















File: lesson-9-part3.md


# Advanced Features and Platform Integrations

### LLM Platform Integration

The agent system in AIChat is designed to work seamlessly with multiple LLM platforms through a unified interface. This is implemented through the client system in `client/common.rs`:

```rust
#[async_trait::async_trait]
pub trait Client: Sync + Send {
    fn global_config(&self) -> &GlobalConfig;
    fn extra_config(&self) -> Option<&ExtraConfig>;
    fn patch_config(&self) -> Option<&RequestPatch>;
    fn name(&self) -> &str;
    fn model(&self) -> &Model;
    fn model_mut(&mut self) -> &mut Model;
    // ... other trait methods
}
```

The system supports integration with numerous platforms including:

1. OpenAI and Compatible APIs
2. Claude/Anthropic
3. Gemini/Google
4. Mistral
5. Local Models (via Ollama)
6. Azure OpenAI
7. Custom Model Implementations

### Advanced Function Calling Features

The function calling system includes several advanced features:

#### Dynamic Tool Loading
```rust
pub fn init(declarations_path: &Path) -> Result<Self> {
    let declarations: Vec<FunctionDeclaration> = if declarations_path.exists() {
        let content = fs::read_to_string(declarations_path)?;
        serde_json::from_str(&content)?
    } else {
        vec![]
    };
    Ok(Self { declarations })
}
```

#### Tool Chaining
Tools can be chained together through the response handling system:
```rust
pub fn need_send_tool_results(arr: &[ToolResult]) -> bool {
    arr.iter().any(|v| !v.output.is_null())
}

#[async_recursion::async_recursion]
async fn start_directive(
    config: &GlobalConfig,
    input: Input,
    code_mode: bool,
    abort_signal: AbortSignal,
) -> Result<()> {
    // ... process initial request
    if need_send_tool_results(&tool_results) {
        start_directive(
            config,
            input.merge_tool_call(output, tool_results),
            code_mode,
            abort_signal,
        ).await?;
    }
}
```

#### Cross-Platform Path Handling
```rust
#[cfg(windows)]
fn polyfill_cmd_name<T: AsRef<Path>>(cmd_name: &str, bin_dir: &[T]) -> String {
    if let Ok(exts) = std::env::var("PATHEXT") {
        for name in exts.split(';').map(|ext| format!("{cmd_name}{ext}")) {
            for dir in bin_dir {
                let path = dir.as_ref().join(&name);
                if path.exists() {
                    return name.to_string();
                }
            }
        }
    }
    cmd_name.to_string()
}
```

### Advanced RAG Integration

The agent system includes sophisticated RAG (Retrieval Augmented Generation) capabilities:

#### Document Loading
```rust
impl Agent {
    async fn load_documents(
        &self,
        local_paths: Vec<String>,
        remote_urls: Vec<String>,
    ) -> Result<(Vec<(String, String)>, Vec<String>, HashMap<String, String>)> {
        let mut files = vec![];
        let mut medias = vec![];
        let mut data_urls = HashMap::new();
        let loaders = self.config.read().document_loaders.clone();
        
        // Process local files
        let local_files = expand_glob_paths(&local_paths).await?;
        for file_path in local_files {
            if is_image(&file_path) {
                let data_url = read_media_to_data_url(&file_path)?;
                data_urls.insert(sha256(&data_url), file_path);
                medias.push(data_url)
            } else {
                let text = read_file(&file_path)?;
                files.push((file_path, text));
            }
        }
        
        // Process remote URLs
        for url in remote_urls {
            let (contents, extension) = fetch(&loaders, &url, true).await?;
            if extension == MEDIA_URL_EXTENSION {
                data_urls.insert(sha256(&contents), url.clone());
                medias.push(contents)
            } else {
                files.push((url, contents));
            }
        }
        
        Ok((files, medias, data_urls))
    }
}
```

#### Embeddings Integration
```rust
pub async fn use_embeddings(&mut self, abort_signal: AbortSignal) -> Result<()> {
    if !self.text.is_empty() {
        let rag = self.config.read().rag.clone();
        if let Some(rag) = rag {
            let result = Config::search_rag(
                &self.config,
                &rag,
                &self.text,
                abort_signal
            ).await?;
            self.patched_text = Some(result);
            self.rag_name = Some(rag.name().to_string());
        }
    }
    Ok(())
}
```

### Advanced Agent Features

#### Variable Management
```rust
pub fn init_agent_variables(
    agent_variables: &[AgentVariable],
    variables: &IndexMap<String, String>,
) -> Result<IndexMap<String, String>> {
    let mut output = IndexMap::new();
    if agent_variables.is_empty() {
        return Ok(output);
    }
    
    let mut unset_variables = vec![];
    for agent_variable in agent_variables {
        let key = agent_variable.name.clone();
        match variables.get(&key) {
            Some(value) => {
                output.insert(key, value.clone());
            }
            None => {
                if let Some(value) = agent_variable.default.clone() {
                    output.insert(key, value);
                    continue;
                }
                // Handle interactive or error cases
            }
        }
    }
    Ok(output)
}
```

#### Session Management
The agent system includes sophisticated session management capabilities:
```rust
pub struct Session {
    model_id: String,
    temperature: Option<f64>,
    top_p: Option<f64>,
    use_tools: Option<String>,
    save_session: Option<bool>,
    compress_threshold: Option<usize>,
    role_name: Option<String>,
    agent_variables: IndexMap<String, String>,
    data_urls: HashMap<String, String>,
    compressed_messages: Vec<Message>,
    messages: Vec<Message>,
    // ... other fields
}
```

### HTTP Server Integration

The agent system can be exposed via an HTTP server:
```rust
pub async fn run(config: GlobalConfig, addr: Option<String>) -> Result<()> {
    let addr = match addr {
        Some(addr) => {
            if let Ok(port) = addr.parse::<u16>() {
                format!("127.0.0.1:{port}")
            } else if let Ok(ip) = addr.parse::<IpAddr>() {
                format!("{ip}:8000")
            } else {
                addr
            }
        }
        None => config.read().serve_addr(),
    };
    
    let server = Arc::new(Server::new(&config));
    let listener = TcpListener::bind(&addr).await?;
    let stop_server = server.run(listener).await?;
    
    // Print available endpoints
    println!("Chat Completions API: http://{addr}/v1/chat/completions");
    println!("Embeddings API:       http://{addr}/v1/embeddings");
    println!("Rerank API:           http://{addr}/v1/rerank");
    println!("LLM Playground:       http://{addr}/playground");
    println!("LLM Arena:            http://{addr}/arena?num=2");
    
    Ok(())
}
```

This integration allows agents to be accessed via a REST API, making them available to external systems and web interfaces. The server implementation includes full CORS support, proper error handling, and streaming capabilities for real-time interactions.















File: lesson-9-part4.md


# Example Implementations and Best Practices

### Example Agent Implementations

Let's explore several practical examples of implementing agents in AIChat.

### 1. Document Analysis Agent

This example demonstrates creating an agent that can analyze documents using RAG capabilities:

```yaml
# doc-analyzer.yaml
name: doc-analyzer
description: "Intelligent document analysis agent"
version: "1.0"
instructions: |
  You are a document analysis specialist. You have access to the following capabilities:
  {{__tools__}}
  
  When analyzing documents:
  1. First understand the document type and structure
  2. Extract key information using appropriate tools
  3. Provide clear, organized summaries
  4. Respond to specific queries about the content

variables:
  - name: ANALYSIS_DEPTH
    description: "Level of analysis detail (basic/detailed)"
    default: "basic"
  - name: OUTPUT_FORMAT
    description: "Output format (text/markdown/json)"
    default: "markdown"

conversation_starters:
  - "Analyze this document for key points"
  - "Extract all dates and events"
  - "Compare these two documents"
  - "Generate a summary report"

documents:
  - "templates/*.md"
  - "examples/*.pdf"
```

Implementation in code:
```rust
use aichat::config::{Agent, AgentConfig, AgentDefinition};

async fn setup_doc_analyzer() -> Result<()> {
    // Initialize configuration
    let config = AgentConfig {
        model_id: Some("gpt-4".to_string()),
        temperature: Some(0.3),
        use_tools: Some("text_analysis,pdf_extract".to_string()),
        ..Default::default()
    };

    // Set up document processing
    let doc_processors = vec![
        ("pdf", "pdftotext $1 -"),
        ("docx", "pandoc --to plain $1"),
    ];
    
    // Initialize agent
    let agent = Agent::init(
        &config,
        "doc-analyzer",
        create_abort_signal(),
    ).await?;

    // Add document loaders
    agent.add_document_loaders(doc_processors)?;

    Ok(())
}
```

### 2. Development Assistant Agent

An agent designed to help with software development tasks:

```yaml
# dev-assistant.yaml
name: dev-assistant
description: "AI-powered development assistant"
version: "1.0"
instructions: |
  You are a development assistant with these capabilities:
  {{__tools__}}
  
  Your primary responsibilities are:
  1. Code analysis and review
  2. Bug identification and fixes
  3. Documentation generation
  4. Testing suggestions
  
  Always ensure:
  - Code follows best practices
  - Documentation is clear and complete
  - Security considerations are addressed
  - Performance implications are considered

variables:
  - name: LANGUAGE
    description: "Primary programming language"
    default: "python"
  - name: STYLE_GUIDE
    description: "Style guide to follow"
    default: "pep8"

conversation_starters:
  - "Review this code for issues"
  - "Help me document this function"
  - "Suggest test cases for this module"
  - "Optimize this implementation"
```

Implementation example:
```rust
async fn create_dev_assistant() -> Result<Agent> {
    // Define tool configurations
    let tools = vec![
        FunctionDeclaration {
            name: "analyze_code".to_string(),
            description: "Static code analysis".to_string(),
            parameters: JsonSchema {
                type_value: "object".to_string(),
                properties: Some(indexmap! {
                    "code".to_string() => JsonSchema {
                        type_value: "string".to_string(),
                        description: Some("Code to analyze".to_string()),
                        ..Default::default()
                    },
                    "language".to_string() => JsonSchema {
                        type_value: "string".to_string(),
                        description: Some("Programming language".to_string()),
                        ..Default::default()
                    }
                }),
                required: Some(vec!["code".to_string()]),
                ..Default::default()
            },
            agent: false,
        },
        // Additional tool declarations...
    ];

    // Initialize agent with tools
    let mut agent = Agent::init(
        &config,
        "dev-assistant",
        create_abort_signal(),
    ).await?;

    agent.add_tools(tools)?;
    Ok(agent)
}
```

### 3. Data Analysis Agent

An agent specialized in data analysis and visualization:

```yaml
# data-analyst.yaml
name: data-analyst
description: "Data analysis and visualization specialist"
version: "1.0"
instructions: |
  You are a data analysis specialist with these tools:
  {{__tools__}}
  
  Your capabilities include:
  1. Data loading and cleaning
  2. Statistical analysis
  3. Visualization generation
  4. Insight extraction
  
  Always:
  - Verify data quality
  - Use appropriate statistical methods
  - Create clear visualizations
  - Explain insights in plain language

variables:
  - name: DATA_FORMAT
    description: "Preferred data format"
    default: "csv"
  - name: VIZ_STYLE
    description: "Visualization style"
    default: "plotly"

conversation_starters:
  - "Analyze this dataset"
  - "Create a visualization of trends"
  - "Find correlations in this data"
  - "Generate a summary report"
```

Implementation:
```rust
use aichat::function::{ToolCall, ToolResult};

async fn handle_data_analysis(
    agent: &Agent,
    input: &str,
    data: &[u8]
) -> Result<AnalysisResults> {
    // Set up data processing pipeline
    let tool_chain = vec![
        ToolCall::new(
            "load_data".to_string(),
            json!({ "data": base64_encode(data) }),
            None
        ),
        ToolCall::new(
            "analyze".to_string(),
            json!({ "query": input }),
            None
        ),
        ToolCall::new(
            "visualize".to_string(),
            json!({ "format": "svg" }),
            None
        ),
    ];

    // Process tool chain
    let results = eval_tool_calls(
        agent.config(),
        tool_chain
    )?;

    // Extract results
    let analysis = process_tool_results(&results)?;
    
    Ok(analysis)
}
```

### Best Practices

#### 1. Tool Development Guidelines

When developing tools for agents:

```rust
// 1. Implement proper error handling
pub fn tool_function(args: Value) -> Result<Value> {
    // Validate inputs
    let params = serde_json::from_value::<ToolParams>(args)
        .context("Invalid parameters")?;
        
    // Set up error recovery
    let _cleanup = CleanupGuard::new(|| {
        // Cleanup code
    });
    
    // Execute with timeouts
    let result = tokio::time::timeout(
        Duration::from_secs(30),
        async_operation()
    ).await??;
    
    Ok(json!({ "result": result }))
}

// 2. Use structured logging
fn process_data(data: &[u8]) -> Result<()> {
    debug!("Processing {} bytes of data", data.len());
    // Processing logic
    info!("Successfully processed data");
    Ok(())
}

// 3. Implement proper resource management
struct ResourceGuard<T> {
    resource: T,
}

impl<T: Resource> Drop for ResourceGuard<T> {
    fn drop(&mut self) {
        self.resource.cleanup();
    }
}
```

#### 2. Security Considerations

```rust
// 1. Input validation
fn validate_path(path: &Path) -> Result<()> {
    let canonical = path.canonicalize()?;
    if !canonical.starts_with(&SAFE_ROOT) {
        bail!("Path traversal attempt detected");
    }
    Ok(())
}

// 2. Resource limits
fn limit_resources() -> Result<()> {
    // Set memory limits
    rlimit::setrlimit(rlimit::Resource::AS, 
                     maxmem as u64, 
                     maxmem as u64)?;
    
    // Set CPU limits
    rlimit::setrlimit(rlimit::Resource::CPU,
                     maxcpu as u64,
                     maxcpu as u64)?;
    Ok(())
}

// 3. Secure environment setup
fn setup_secure_env() -> Result<()> {
    // Clear sensitive environment variables
    for var in &SENSITIVE_VARS {
        env::remove_var(var);
    }
    
    // Set up temporary directory
    let temp_dir = TempDir::new()?;
    env::set_current_dir(&temp_dir)?;
    
    Ok(())
}
```

#### 3. Performance Optimization

```rust
// 1. Implement caching
use cached::proc_macro::cached;

#[cached(
    time = 300, // Cache for 5 minutes
    key = "String",
    convert = r#"{ format!("{}", query) }"#,
    result = true
)]
async fn cached_operation(query: &str) -> Result<Value> {
    // Expensive operation
    Ok(json!({}))
}

// 2. Batch operations
async fn batch_process<T>(
    items: Vec<T>,
    batch_size: usize
) -> Result<Vec<Output>> {
    let mut results = Vec::new();
    for chunk in items.chunks(batch_size) {
        let batch_results = future::join_all(
            chunk.iter().map(process_item)
        ).await;
        results.extend(batch_results);
    }
    Ok(results)
}

// 3. Resource pooling
use deadpool::managed::{Manager, Pool};

struct ResourceManager;

impl Manager for ResourceManager {
    type Type = Resource;
    type Error = Error;

    async fn create(&self) -> Result<Resource> {
        // Create new resource
        Ok(Resource::new())
    }

    async fn recycle(
        &self,
        resource: &Self::Type,
    ) -> deadpool::managed::RecycleResult<Error> {
        // Check if resource can be reused
        if resource.is_healthy() {
            Ok(())
        } else {
            Err(Error::ResourceUnhealthy)
        }
    }
}
```

### Documentation Practices

All agent implementations should include:

1. Clear purpose and capabilities documentation
2. Required dependencies and setup instructions
3. Examples of common use cases
4. Error handling and troubleshooting guides
5. Security considerations and limitations
6. Performance characteristics and requirements

Example documentation structure:
```markdown
# Agent Name

## Purpose
Detailed description of the agent's purpose and capabilities.

## Configuration
```yaml
# Configuration example with explanations
```

## Tools
List and description of available tools.

## Usage Examples
Common use cases and example interactions.

## Security
Security considerations and best practices.

## Troubleshooting
Common issues and their solutions.
```

This comprehensive documentation ensures that other developers can effectively use and maintain the agent implementation.















File: lesson-9-part5.md


# Foundational Concepts and Additional Details

### Prerequisite Concepts

#### 1. REPL (Read-Eval-Print Loop)
AIChat's agent system builds upon a REPL foundation, which needs to be understood:

```rust
pub struct Repl {
    config: GlobalConfig,
    prompt: ReplPrompt,
    completer: ReplCompleter,
    highlighter: ReplHighlighter,
    editor: Editor,
    last_input: Option<Input>,
}
```

The REPL provides:
- Command history management
- Tab completion
- Syntax highlighting
- Multi-line editing
- Command parsing

Key REPL commands related to agents:
```
.agent                   Use an agent
.starter                 Use conversation starter
.variable               Set agent variable
.save agent-config      Save agent configuration
.info agent            View agent info
.exit agent            Leave agent
```

#### 2. Message Structure
Understanding the message system is crucial:

```rust
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Message {
    pub role: MessageRole,
    pub content: MessageContent,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Deserialize, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum MessageRole {
    System,
    Assistant,
    User,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(untagged)]
pub enum MessageContent {
    Text(String),
    Array(Vec<MessageContentPart>),
    ToolResults(ToolResults),
}
```

Messages form the backbone of agent-LLM communication, with different roles and content types serving specific purposes:
- System messages set context and behavior
- User messages contain queries or commands
- Assistant messages contain responses
- Tool results contain function execution outputs

#### 3. Environment Variables and Configuration
AIChat uses a sophisticated environment variable system:

```rust
# Environment Variable Handling
AICHAT_LOG_LEVEL=debug           # Enable debug logging
AICHAT_PLATFORM=openai           # Set default platform
{platform}_API_KEY               # Platform-specific API keys
AICHAT_PATCH_{platform}_{type}   # Platform-specific patches
```

Configuration file structure:
```yaml
# Configuration hierarchy
- Global configuration
  - Agent-specific configuration
    - Session-specific configuration
      - Tool-specific configuration
```

### Additional Implementation Details

#### 1. Token Management
Token counting and management is crucial for LLM interactions:

```rust
impl Model {
    pub fn total_tokens(&self, messages: &[Message]) -> usize {
        let mut total = 0;
        for message in messages {
            total += match &message.content {
                MessageContent::Text(text) => self.count_tokens(text),
                MessageContent::Array(parts) => {
                    parts.iter().map(|p| self.count_tokens(&p.to_string())).sum()
                }
                MessageContent::ToolResults((results, text)) => {
                    self.count_tokens(text) + 
                    results.iter().map(|r| self.count_tokens(&r.to_string())).sum()
                }
            };
        }
        total
    }

    pub fn guard_max_input_tokens(&self, messages: &[Message]) -> Result<()> {
        if let Some(max_tokens) = self.max_input_tokens() {
            let total = self.total_tokens(messages);
            if total > max_tokens {
                bail!(
                    "Input tokens ({}) exceed model's maximum ({}).",
                    total,
                    max_tokens
                );
            }
        }
        Ok(())
    }
}
```

#### 2. Session State Management
Session handling is more complex than shown earlier:

```rust
pub trait SessionState {
    fn save_state(&self) -> Result<Value>;
    fn load_state(&mut self, state: Value) -> Result<()>;
    fn clear_state(&mut self);
}

impl Session {
    pub fn compress(&mut self, prompt: String) {
        // Compress previous messages into summary
        if let Some(system_prompt) = self.messages.first()
            .and_then(|v| if v.role.is_system() {
                Some(v.content.to_text())
            } else {
                None
            }) 
        {
            self.compressed_messages.append(&mut self.messages);
            self.messages = vec![Message::new(
                MessageRole::System,
                MessageContent::Text(format!(
                    "{}\n\n{}",
                    system_prompt,
                    prompt
                ))
            )];
        }
    }

    pub fn tokens_usage(&self) -> (usize, f32) {
        let tokens = self.tokens();
        let max_tokens = self.model()
            .max_input_tokens()
            .unwrap_or_default();
        let percent = if max_tokens == 0 {
            0.0
        } else {
            let percent = tokens as f32 / max_tokens as f32 * 100.0;
            (percent * 100.0).round() / 100.0
        };
        (tokens, percent)
    }
}
```

#### 3. Cross-Platform Considerations
Detailed platform-specific handling:

```rust
#[cfg(windows)]
const PATH_SEP: &str = ";";
#[cfg(not(windows))]
const PATH_SEP: &str = ":";

pub fn detect_shell() -> Shell {
    #[cfg(windows)] {
        if let Ok(prog) = env::var("COMSPEC") {
            if prog.ends_with("cmd.exe") {
                return Shell::new("cmd.exe", "/C");
            }
        }
        Shell::new("powershell.exe", "-Command")
    }
    #[cfg(not(windows))] {
        if let Ok(shell) = env::var("SHELL") {
            let shell = PathBuf::from(shell);
            if let Some(name) = shell.file_name() {
                if let Some(name) = name.to_str() {
                    match name {
                        "fish" => return Shell::new("fish", "-c"),
                        "nu" => return Shell::new("nu", "-c"),
                        _ => {}
                    }
                }
            }
        }
        Shell::new("bash", "-c")
    }
}
```

### Edge Cases and Error Handling

#### 1. Tool Execution Errors
Comprehensive error handling for tool execution:

```rust
pub fn eval(&self, config: &GlobalConfig) -> Result<Value> {
    let function_name = self.name.clone();
    let (call_name, cmd_name, mut cmd_args, mut envs) = match &config.read().agent {
        Some(agent) => match agent.functions().find(&function_name) {
            Some(function) => {
                if function.agent {
                    let envs: HashMap<String, String> = agent
                        .variables()
                        .iter()
                        .map(|(k, v)| {
                            (
                                format!("LLM_AGENT_VAR_{}", 
                                    normalize_env_name(k)
                                ),
                                v.clone(),
                            )
                        })
                        .collect();
                    (
                        format!("{}:{}", agent.name(), function_name),
                        agent.name().to_string(),
                        vec![function_name],
                        envs,
                    )
                } else {
                    (
                        function_name.clone(),
                        function_name,
                        vec![],
                        Default::default(),
                    )
                }
            }
            None => bail!(
                "Unexpected call {function_name} {}",
                self.arguments
            ),
        },
        None => match config.read().functions.contains(&function_name) {
            true => (
                function_name.clone(),
                function_name,
                vec![],
                Default::default(),
            ),
            false => bail!(
                "Unexpected call: {function_name} {}", 
                self.arguments
            ),
        },
    };

    // Handle timeouts and resource limits
    let result = tokio::time::timeout(
        Duration::from_secs(30),
        async {
            let exit_code = run_command(
                &cmd_name,
                &cmd_args,
                Some(envs)
            )?;
            if exit_code != 0 {
                bail!("Tool call exit with {exit_code}");
            }
            Ok(())
        }
    ).await??;

    Ok(result)
}
```

#### 2. Memory Management
Handling large message histories and memory constraints:

```rust
impl Session {
    pub fn need_compress(
        &self,
        global_compress_threshold: usize
    ) -> bool {
        let threshold = self.compress_threshold
            .unwrap_or(global_compress_threshold);
        threshold > 0 && self.tokens() > threshold
    }

    pub fn compress_messages(&mut self) -> Result<()> {
        let summarize_prompt = self.config
            .read()
            .summarize_prompt
            .clone();
            
        // Create summary using LLM
        let summary = self.create_summary(
            &summarize_prompt
        )?;

        // Replace messages with summary
        self.compress(summary);
        Ok(())
    }
}
```

#### 3. Rate Limiting and Retries
Handling API rate limits and retries:

```rust
#[derive(Debug)]
pub struct RateLimiter {
    requests: VecDeque<Instant>,
    max_requests: usize,
    time_window: Duration,
}

impl RateLimiter {
    pub fn new(
        max_requests: usize,
        time_window: Duration
    ) -> Self {
        Self {
            requests: VecDeque::with_capacity(max_requests),
            max_requests,
            time_window,
        }
    }

    pub async fn acquire(&mut self) {
        let now = Instant::now();
        
        // Remove old requests
        while let Some(time) = self.requests.front() {
            if now.duration_since(*time) > self.time_window {
                self.requests.pop_front();
            } else {
                break;
            }
        }

        // Wait if at limit
        if self.requests.len() >= self.max_requests {
            let oldest = self.requests.front().unwrap();
            let wait_time = self.time_window
                - now.duration_since(*oldest);
            tokio::time::sleep(wait_time).await;
        }

        // Add new request
        self.requests.push_back(now);
    }
}
```

### Additional Documentation Resources

For deeper understanding, refer to:

1. Function Signatures Documentation
```rust
/// Tool call result type alias
pub type ToolResults = (Vec<ToolResult>, String);

/// Tool declaration type for defining available tools
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolDeclaration {
    /// Name of the tool
    pub name: String,
    /// Description of tool functionality
    pub description: String,
    /// Parameter schema for validation
    pub parameters: JsonSchema,
    /// Whether tool is agent-specific
    #[serde(skip_serializing, default)]
    pub agent: bool,
}
```

2. Configuration File Formats
```yaml
# Agent Configuration
version: 1.0
name: example_agent
description: "Example agent configuration"
instructions: |
  Detailed instructions...
variables:
  - name: VAR_NAME
    description: "Variable description"
    default: "default_value"
tools:
  - name: tool_name
    description: "Tool description"
    parameters:
      type: object
      properties:
        param_name:
          type: string
          description: "Parameter description"
```

3. API Documentation for Integration Points
```rust
/// Trait for implementing custom tool handlers
pub trait ToolHandler: Send + Sync {
    /// Handle tool execution
    async fn handle(
        &self,
        args: Value,
        context: &Context
    ) -> Result<Value>;
    
    /// Tool metadata
    fn declaration(&self) -> ToolDeclaration;
}
```

This additional information should help fill in the gaps and provide a more complete understanding of AIChat's agent system.















