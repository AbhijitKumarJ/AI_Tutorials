# AIChat Lesson 8: Utility Functions and Helper Systems
## Part 4: Variable Interpolation and Terminal Rendering

The final components of AIChat's utility system handle variable interpolation and terminal rendering, providing crucial functionality for dynamic content generation and user interface presentation. These systems enable AIChat's sophisticated REPL interface and dynamic content generation capabilities.

### Variable Interpolation System

The variables module (`variables.rs`) implements a powerful system for handling dynamic content substitution throughout the application.

#### Core Variable Pattern Matching

The module defines a regex pattern for variable interpolation:

```rust
lazy_static::lazy_static! {
    pub static ref RE_VARIABLE: Regex = Regex::new(r"\{\{(\w+)\}\}").unwrap();
}
```

This pattern enables the recognition of variables in the format `{{variable_name}}`.

#### System Variable Support

The interpolation system provides access to system information through predefined variables:

```rust
pub fn interpolate_variables(text: &mut String) {
    *text = RE_VARIABLE
        .replace_all(text, |caps: &Captures<'_>| {
            let key = &caps[1];
            match key {
                "__os__" => env::consts::OS.to_string(),
                "__os_distro__" => {
                    let info = os_info::get();
                    if env::consts::OS == "linux" {
                        format!("{info} (linux)")
                    } else {
                        info.to_string()
                    }
                }
                "__os_family__" => env::consts::FAMILY.to_string(),
                "__arch__" => env::consts::ARCH.to_string(),
                "__shell__" => SHELL.name.clone(),
                "__locale__" => sys_locale::get_locale().unwrap_or_default(),
                "__now__" => now(),
                "__cwd__" => env::current_dir()
                    .map(|v| v.display().to_string())
                    .unwrap_or_default(),
                _ => format!("{{{{{}}}}}", key),
            }
        })
        .to_string();
}
```

### Terminal Rendering System

The render_prompt module (`render_prompt.rs`) provides sophisticated terminal rendering capabilities for AIChat's REPL interface.

#### Template-Based Rendering

The module implements a template-based rendering system:

```rust
pub fn render_prompt(template: &str, variables: &HashMap<&str, String>) -> String {
    let exprs = parse_template(template);
    eval_exprs(&exprs, variables)
}
```

This system supports:
- Conditional rendering
- Variable substitution
- Complex template structures
- Error handling

#### Expression Parsing

The system implements sophisticated expression parsing:

```rust
fn parse_block(current: &mut Vec<char>) -> Expr {
    let value: String = current.drain(..).collect();
    match value.split_once(' ') {
        Some((name, tail)) => {
            if let Some(name) = name.strip_prefix('?') {
                let block_exprs = parse_template(tail);
                Expr::Block(BlockType::Yes, name.to_string(), block_exprs)
            } else if let Some(name) = name.strip_prefix('!') {
                let block_exprs = parse_template(tail);
                Expr::Block(BlockType::No, name.to_string(), block_exprs)
            } else {
                Expr::Text(format!("{{{value}}}"))
            }
        }
        None => Expr::Variable(value),
    }
}
```

#### Color and Style Support

The utility system includes comprehensive color and style support:

```rust
pub fn color_text(input: &str, color: nu_ansi_term::Color) -> String {
    if *NO_COLOR {
        return input.to_string();
    }
    nu_ansi_term::Style::new()
        .fg(color)
        .paint(input)
        .to_string()
}

pub fn dimmed_text(input: &str) -> String {
    if *NO_COLOR {
        return input.to_string();
    }
    nu_ansi_term::Style::new().dimmed().paint(input).to_string()
}
```

### Integration with HTML Processing

The system includes HTML processing capabilities through the html_to_md module:

```rust
pub fn html_to_md(html: &str) -> String {
    let mut handlers: Vec<TagHandler> = vec![
        Rc::new(RefCell::new(markdown::ParagraphHandler)),
        Rc::new(RefCell::new(markdown::HeadingHandler)),
        Rc::new(RefCell::new(markdown::ListHandler)),
        Rc::new(RefCell::new(markdown::TableHandler::new())),
        Rc::new(RefCell::new(markdown::StyledTextHandler)),
        Rc::new(RefCell::new(markdown::CodeHandler)),
        Rc::new(RefCell::new(markdown::WebpageChromeRemover)),
    ];

    html_to_markdown::convert_html_to_markdown(html.as_bytes(), &mut handlers)
        .unwrap_or_else(|_| html.to_string())
}
```

### Testing and Verification

The utility systems include comprehensive testing capabilities:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_render() {
        let prompt = "{?session {session}{?role /}}{role}{?session )}{!session >}";
        assert_render!(prompt, [], ">");
        assert_render!(prompt, [("role", "coder"),], "coder>");
        assert_render!(prompt, [("session", "temp"),], "temp)");
        assert_render!(
            prompt,
            [("session", "temp"), ("role", "coder"),],
            "temp/coder)"
        );
    }
}
```

### Performance Considerations

The utility systems implement various performance optimizations:

1. Lazy Evaluation:
```rust
lazy_static::lazy_static! {
    static ref CODE_BLOCK_RE: Regex = Regex::new(r"(?ms)```\w*(.*)```").unwrap();
    static ref IS_STDOUT_TERMINAL: bool = std::io::stdout().is_terminal();
    static ref NO_COLOR: bool = env::var("NO_COLOR").is_ok() || !*IS_STDOUT_TERMINAL;
}
```

2. Buffer Management:
```rust
pub fn indent_text<T: ToString>(s: T, size: usize) -> String {
    let indent_str = " ".repeat(size);
    s.to_string()
        .split('\n')
        .map(|line| format!("{}{}", indent_str, line))
        .collect::<Vec<String>>()
        .join("\n")
}
```

Together, these components provide AIChat with powerful capabilities for dynamic content generation and terminal interaction. Their careful implementation ensures reliable operation across different platforms while maintaining high performance and user experience quality.

This concludes our exploration of AIChat's utility systems. The combination of these utilities provides a robust foundation for AIChat's functionality, enabling sophisticated features while maintaining code quality and maintainability.