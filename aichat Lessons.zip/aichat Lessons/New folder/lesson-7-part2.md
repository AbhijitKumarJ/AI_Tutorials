# AIChat HTTP Server Implementation - Part 2: API Endpoints, Usage and Integration

## API Endpoints

### Chat Completions API

The chat completions endpoint is accessed through `/v1/chat/completions`. It accepts POST requests with a JSON body in the following format:

```json
{
    "model": "model-name",
    "messages": [
        {
            "role": "user",
            "content": "Hello world"
        }
    ],
    "temperature": 0.7,
    "top_p": 1,
    "stream": true
}
```

The response format follows the OpenAI API convention:

```json
{
    "id": "chatcmpl-123",
    "object": "chat.completion",
    "created": 1677858242,
    "model": "model-name",
    "choices": [
        {
            "index": 0,
            "message": {
                "role": "assistant", 
                "content": "Response text"
            }
        }
    ]
}
```

### Embeddings API

The embeddings endpoint is accessed through `/v1/embeddings`. It accepts POST requests with:

```json
{
    "model": "embedding-model",
    "input": ["Text to embed"]
}
```

The response provides vector embeddings:

```json
{
    "object": "list",
    "data": [
        {
            "object": "embedding",
            "embedding": [0.1, 0.2, ...],
            "index": 0
        }
    ],
    "model": "embedding-model"
}
```

### Rerank API 

The rerank endpoint at `/v1/rerank` accepts:

```json
{
    "model": "rerank-model",
    "query": "search query",
    "documents": ["doc1", "doc2"],
    "top_n": 2
}
```

Response format:

```json
{
    "id": "rerank-123", 
    "results": [
        {
            "index": 0,
            "relevance_score": 0.95,
            "document": "doc1"
        }
    ]
}
```

## Web Interfaces

### Playground Interface

The playground interface provides an interactive environment for testing LLM capabilities. Key features include:

1. Model selection dropdown
2. Interactive chat interface
3. Parameter configuration
4. Response streaming
5. Copy/regenerate options
6. Tool call visualization

The playground can be accessed by running:

```bash
aichat --serve
# Access at http://localhost:8000/playground
```

### Arena Interface

The arena interface enables side-by-side model comparison with:

1. Multiple model selection
2. Parallel request processing
3. Response comparison 
4. Performance metrics
5. Unified prompt input

Access the arena at:
```bash
http://localhost:8000/arena?num=2
```

The num parameter controls how many models to compare simultaneously.

## Usage Examples

### Starting the Server

Basic server start:
```bash
aichat --serve
```

Custom address/port:
```bash 
aichat --serve 0.0.0.0:3000
```

### API Usage Examples

Chat completion request:
```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "gpt-4",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

Streaming chat completion:
```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "gpt-4",
    "messages": [{"role": "user", "content": "Hello!"}],
    "stream": true
  }'
```

Embeddings request:
```bash
curl -X POST http://localhost:8000/v1/embeddings \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "text-embedding-3-small",
    "input": ["Hello world"]
  }'
```

## Integration Patterns

### Client Library Integration

The server can be integrated with client libraries through the standard OpenAI-compatible interface:

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="dummy"
)

response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}]
)
```

### Environment Configuration

The server behavior can be configured through environment variables:

```bash
export AICHAT_SERVE_ADDR=0.0.0.0:3000
export AICHAT_MODEL=gpt-4
export AICHAT_TEMPERATURE=0.7
```

### Proxy Configuration

The server supports various proxy configurations:

```yaml
extra:
  proxy: socks5://127.0.0.1:1080
  connect_timeout: 10
```

### Security Considerations 

When deploying the server, consider:

1. API key validation
2. Rate limiting
3. CORS policy configuration
4. Error message sanitization
5. Input validation and sanitization

Example CORS configuration:
```rust
fn set_cors_header(res: &mut AppResponse) {
    res.headers_mut().insert(
        hyper::header::ACCESS_CONTROL_ALLOW_ORIGIN,
        hyper::header::HeaderValue::from_static("*")
    );
    // Additional CORS headers...
}
```

## Testing

The server implementation includes comprehensive testing:

1. Unit tests for individual components:
```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_chat_completions() {
        // Test implementation
    }
}
```

2. Integration tests for API endpoints
3. Load testing for performance verification
4. Cross-platform compatibility testing
5. Error handling verification

## Troubleshooting

Common troubleshooting steps:

1. Enable debug logging:
```bash
export AICHAT_LOG_LEVEL=debug
```

2. Check server logs:
```bash
tail -f ~/.config/aichat/aichat.log
```

3. Verify API endpoint availability:
```bash
curl http://localhost:8000/v1/models
```

4. Test streaming connection:
```bash
curl -N http://localhost:8000/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{"stream":true,...}'
```

## Conclusion

The AIChat HTTP server implementation provides a feature-rich platform for exposing LLM capabilities through standardized APIs and web interfaces. The comprehensive API support, web interfaces, and integration patterns make it suitable for a wide range of applications. The robust error handling, security considerations, and testing infrastructure ensure reliable operation in production environments.