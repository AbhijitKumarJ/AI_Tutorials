# Lesson 9: Agent System and Function Calling
## Overview and Architecture

The agent system represents one of AIChat's most sophisticated features, combining prompts, tools, and document retrieval into a unified interface. This lesson explores the implementation details, architectural decisions, and cross-platform considerations that make this system both powerful and flexible.

### Project Structure
```
src/
├── config/
│   └── agent.rs               # Agent configuration and management
├── function.rs                # Core function calling implementation
└── client/
    ├── message.rs             # Message handling for function calls
    └── common.rs              # Shared functionality for function calling
```

The agent system is built around three key components:

1. Agent Configuration - Defined in `config/agent.rs`, handles agent state, variables and configuration management
2. Function Declarations - Implemented in `function.rs`, provides the core function calling capabilities 
3. Message Handling - Managed through `client/message.rs`, handles communication between components

### Core Architecture 

The agent system is designed around the concept of combining three key elements into a unified interface:

1. Instructions (Prompts) - Provides the base behavior and guidance for the agent
2. Tools (Function Callings) - Enables interaction with external systems and data
3. Documents (RAG) - Allows context-aware responses using external knowledge

The implementation centers around the `Agent` struct which serves as the primary orchestrator:

```rust
pub struct Agent {
    name: String,
    config: AgentConfig,
    definition: AgentDefinition,
    shared_variables: IndexMap<String, String>, 
    session_variables: Option<IndexMap<String, String>>,
    functions: Functions,
    rag: Option<Arc<Rag>>,
    model: Model,
}
```

This structure provides:

- Encapsulation of agent state and behavior
- Management of variables across different scopes
- Integration with the function calling system
- Connection to the RAG subsystem for knowledge retrieval

The agent configuration is handled through `AgentConfig` which manages settings like:

```rust
pub struct AgentConfig {
    pub model_id: Option<String>,
    pub temperature: Option<f64>, 
    pub top_p: Option<f64>,
    pub use_tools: Option<String>,
    pub agent_prelude: Option<String>,
    pub variables: IndexMap<String, String>,
}
```

### Function Declaration System

The function calling system uses a JSON Schema-based approach for declaring available tools:

```rust
pub struct FunctionDeclaration {
    pub name: String,
    pub description: String, 
    pub parameters: JsonSchema,
    pub agent: bool,
}
```

This schema-based approach provides:

1. Strong typing of function parameters
2. Clear documentation of function capabilities 
3. Runtime validation of function calls
4. Cross-platform compatibility of function definitions

### Variable Management

The agent system implements a sophisticated variable management system that handles both shared and session-specific variables:

```rust
pub fn init_agent_variables(
    agent_variables: &[AgentVariable],
    variables: &IndexMap<String, String>,
) -> Result<IndexMap<String, String>>
```

Key features include:

- Persistent variable storage across sessions
- Dynamic variable updates during execution
- Proper scoping between shared and session contexts
- Type-safe variable access and modification

### Security Architecture 

The agent system implements several critical security measures:

1. Tool Isolation - Each tool runs as a separate process with its own environment
2. Input Validation - All function parameters are validated against their JSON schema
3. Resource Limits - Tools are executed with appropriate timeouts and constraints
4. Path Sanitization - All file paths are properly sanitized and validated

### Cross-Platform Support

The system implements careful cross-platform handling:

```rust
pub fn agent_functions_dir(name: &str) -> PathBuf {
    match env::var(format!("{}_FUNCTIONS_DIR", normalize_env_name(name))) {
        Ok(value) => PathBuf::from(value),
        Err(_) => Self::agents_functions_dir().join(name),
    }
}
```

Platform-specific considerations include:

1. Path normalization for different operating systems
2. Shell detection and command execution
3. Environment variable handling
4. File system permissions and access

This architectural foundation provides a robust base for building sophisticated AI agents that can safely interact with external systems while maintaining state and context across interactions.