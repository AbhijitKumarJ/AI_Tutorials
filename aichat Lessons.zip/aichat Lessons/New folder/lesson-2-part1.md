# AIChat Lesson 2: Client Abstraction Layer (Part 1)

## Introduction

The client abstraction layer in AIChat forms the core interface between the application and various LLM providers. This implementation serves as an excellent example of how to design a flexible, maintainable system that can adapt to multiple service providers while maintaining a consistent interface. This lesson will explore the design, implementation, and best practices used in AIChat's client abstraction layer.

## Directory Structure

The client abstraction layer is primarily implemented in the `src/client` directory with the following structure:

```
src/client/
├── access_token.rs     # Token management for APIs requiring auth tokens
├── azure_openai.rs     # Azure OpenAI API implementation
├── bedrock.rs         # AWS Bedrock API implementation
├── claude.rs          # Anthropic Claude API implementation
├── cohere.rs         # Cohere API implementation
├── common.rs         # Shared interfaces and utilities
├── ernie.rs          # Baidu ERNIE API implementation
├── gemini.rs         # Google Gemini API implementation
├── macros.rs         # Shared macros for client implementations
├── message.rs        # Message handling and formatting
├── mod.rs           # Module definitions and registration
├── model.rs         # Model management and capabilities
├── openai.rs        # OpenAI API implementation
├── openai_compatible.rs  # OpenAI-compatible API implementations
├── stream.rs       # Streaming response handling
└── vertexai.rs    # Google VertexAI API implementation
```

## Core Architecture

The client abstraction layer is built around the `Client` trait defined in `common.rs`, which provides the foundation for all provider implementations:

```rust
#[async_trait::async_trait]
pub trait Client: Sync + Send {
    fn global_config(&self) -> &GlobalConfig;
    fn extra_config(&self) -> Option<&ExtraConfig>;
    fn patch_config(&self) -> Option<&RequestPatch>;
    fn name(&self) -> &str;
    fn model(&self) -> &Model;
    fn model_mut(&mut self) -> &mut Model;

    async fn chat_completions(&self, input: Input) -> Result<ChatCompletionsOutput>;
    async fn chat_completions_streaming(&self, input: &Input, handler: &mut SseHandler) -> Result<()>;
    async fn embeddings(&self, data: &EmbeddingsData) -> Result<Vec<Vec<f32>>>;
    async fn rerank(&self, data: &RerankData) -> Result<RerankOutput>;
}
```

This design follows several key architectural principles:

1. **Unified Interface**: All providers implement the same trait, ensuring consistent behavior across different services.

2. **Async Support**: The trait uses Rust's async/await syntax for handling asynchronous operations.

3. **Error Handling**: Comprehensive error handling using Rust's Result type with anyhow for flexible error types.

4. **Configuration Management**: Structured configuration handling with support for global and provider-specific settings.

## Message Handling System

The message handling system in `message.rs` provides a robust way to handle different types of messages:

```rust
pub struct Message {
    pub role: MessageRole,
    pub content: MessageContent,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(untagged)]
pub enum MessageContent {
    Text(String),
    Array(Vec<MessageContentPart>),
    ToolResults(ToolResults),
}
```

This system supports:

1. Plain text messages
2. Multi-modal content (text + images)
3. Tool results from function calling
4. System messages and role-based content

## Model Management

The model system in `model.rs` handles different LLM capabilities and configurations:

```rust
pub struct Model {
    client_name: String,
    data: ModelData,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModelData {
    pub name: String,
    pub model_type: String,
    pub max_input_tokens: Option<usize>,
    pub input_price: Option<f64>,
    pub output_price: Option<f64>,
    // ... additional fields
}
```

The model system provides:

1. Token limit management
2. Pricing information
3. Capability detection (vision, function calling)
4. Cross-platform model compatibility

## Provider Implementation Pattern

Each provider implementation follows a consistent pattern demonstrated in the OpenAI implementation (openai.rs):

```rust
impl_client_trait!(
    OpenAIClient,
    (
        prepare_chat_completions,
        openai_chat_completions,
        openai_chat_completions_streaming
    ),
    (prepare_embeddings, openai_embeddings),
    (noop_prepare_rerank, noop_rerank),
);
```

This pattern ensures:

1. Consistent implementation across providers
2. Reusable code through macros
3. Clear separation of concerns
4. Easy addition of new capabilities

## Error Handling System

The error handling system is designed to handle various API-specific errors and convert them into consistent formats:

```rust
pub fn catch_error(data: &Value, status: u16) -> Result<()> {
    if (200..300).contains(&status) {
        return Ok(());
    }
    debug!("Invalid response, status: {status}, data: {data}");
    // ... error handling logic
}
```

This system provides:

1. Unified error reporting
2. Detailed debug information
3. Provider-specific error mapping
4. Consistent error handling patterns

[Continued in Part 2]
