# AIChat Lesson 2: Client Abstraction Layer (Part 3) - Core Concepts & Additional Details

## Foundation Concepts

### Async Programming in Rust

The client abstraction layer makes heavy use of Rust's async/await syntax. Here are the key concepts:

1. **Async Trait**
```rust
#[async_trait::async_trait]
pub trait Client: Sync + Send {
    async fn chat_completions(&self, input: Input) -> Result<ChatCompletionsOutput>;
    // ...
}
```
The `async_trait` attribute is necessary because Rust doesn't natively support async functions in traits. This macro generates the necessary code to make async functions work in traits.

2. **Tokio Runtime**
AIChat uses the Tokio runtime for async operations:
```rust
#[tokio::main]
async fn main() {
    // Application entry point
}
```

### Token Management

Token management is a crucial concept in LLM interactions. Tokens are the basic units that LLMs process:

```rust
pub struct Model {
    // ...
    pub fn messages_tokens(&self, messages: &[Message]) -> usize {
        messages
            .iter()
            .map(|v| match &v.content {
                MessageContent::Text(text) => estimate_token_length(text),
                MessageContent::Array(_) => 0,
                MessageContent::ToolResults(_) => 0,
            })
            .sum()
    }
}
```

Key aspects include:
1. Token counting for rate limiting
2. Token estimation for cost calculation
3. Message compression for token limits
4. Token budget management

## Stream Processing Details

### Event Stream Handling

The Server-Sent Events (SSE) implementation is more complex than initially presented:

```rust
pub struct JsonStreamParser {
    buffer: Vec<char>,
    cursor: usize,
    start: Option<usize>,
    balances: Vec<char>,
    quoting: bool,
    escape: bool,
}

impl JsonStreamParser {
    fn process<F>(&mut self, text: &str, handle: &mut F) -> Result<()>
    where
        F: FnMut(&str) -> Result<()> {
        // Complex JSON stream parsing logic
    }
}
```

This parser handles:
1. Partial JSON messages
2. Proper escaping
3. Nested structures
4. Error recovery

### Abort Signal Mechanism

The abort signal system provides graceful cancellation:

```rust
pub struct AbortSignalInner {
    ctrlc: AtomicBool,
    ctrld: AtomicBool,
}

impl AbortSignal {
    pub fn abort(&self) {
        self.0.ctrlc.store(true, Ordering::SeqCst);
    }
}
```

## Authentication and Authorization

### Access Token Management

The system includes sophisticated token management:

```rust
lazy_static::lazy_static! {
    static ref ACCESS_TOKENS: RwLock<IndexMap<String, (String, i64)>> =
        RwLock::new(IndexMap::new());
}

pub fn set_access_token(client_name: &str, token: String, expires_at: i64) {
    let mut access_tokens = ACCESS_TOKENS.write();
    let entry = access_tokens.entry(client_name.to_string()).or_default();
    entry.0 = token;
    entry.1 = expires_at;
}
```

Features include:
1. Token caching
2. Expiration handling
3. Thread-safe access
4. Automatic renewal

## Advanced Configuration Features

### Request Patching

The request patching system allows modification of API requests:

```rust
pub struct RequestPatch {
    pub chat_completions: Option<ApiPatch>,
    pub embeddings: Option<ApiPatch>,
    pub rerank: Option<ApiPatch>,
}

impl RequestData {
    pub fn apply_patch(&mut self, patch: Value) {
        if let Some(patch_url) = patch["url"].as_str() {
            self.url = patch_url.into();
        }
        if let Some(patch_body) = patch.get("body") {
            json_patch::merge(&mut self.body, patch_body)
        }
        // ...
    }
}
```

This system enables:
1. URL modification
2. Header injection
3. Body transformation
4. Per-model customization

## Error Handling Depth

### Error Context Chain

The error handling system maintains error context:

```rust
pub fn catch_error(data: &Value, status: u16) -> Result<()> {
    if let Some(error) = data["error"].as_object() {
        if let (Some(typ), Some(message)) = (
            json_str_from_map(error, "type"),
            json_str_from_map(error, "message"),
        ) {
            bail!("{message} (type: {typ})");
        }
    }
    // Additional error handling...
}
```

Features include:
1. Status code mapping
2. Error type preservation
3. Provider-specific error handling
4. Error context propagation

## Cross-Platform Details

### Platform-Specific Paths

```rust
#[cfg(not(windows))]
fn default_adc_file() -> Option<PathBuf> {
    let mut path = dirs::home_dir()?;
    path.push(".config");
    path.push("gcloud");
    path.push("application_default_credentials.json");
    Some(path)
}

#[cfg(windows)]
fn default_adc_file() -> Option<PathBuf> {
    let mut path = dirs::config_dir()?;
    path.push("gcloud");
    path.push("application_default_credentials.json");
    Some(path)
}
```

### Network Handling

```rust
fn set_proxy(
    builder: reqwest::ClientBuilder,
    proxy: Option<&String>,
) -> Result<reqwest::ClientBuilder> {
    let proxy = if let Some(proxy) = proxy {
        if proxy.is_empty() || proxy == "-" {
            return Ok(builder);
        }
        proxy.clone()
    } else if let Some(proxy) = ["HTTPS_PROXY", "https_proxy", "ALL_PROXY", "all_proxy"]
        .into_iter()
        .find_map(|v| env::var(v).ok())
    {
        proxy
    } else {
        return Ok(builder);
    };
    Ok(builder.proxy(reqwest::Proxy::all(&proxy)?))
}
```

## Model Management Details

### Model Capabilities

```rust
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModelData {
    pub name: String,
    pub model_type: String,
    pub max_input_tokens: Option<usize>,
    pub input_price: Option<f64>,
    pub output_price: Option<f64>,
    pub max_output_tokens: Option<isize>,
    pub require_max_tokens: bool,
    pub supports_vision: bool,
    pub supports_function_calling: bool,
    pub no_stream: bool,
    pub no_system_message: bool,
    pub max_tokens_per_chunk: Option<usize>,
    pub default_chunk_size: Option<usize>,
    pub max_batch_size: Option<usize>,
}
```

This comprehensive structure handles:
1. Token limits
2. Pricing information
3. Feature support
4. Batch processing
5. Model constraints

## Testing Considerations

### Mocking Complex Responses

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[tokio::test]
    async fn test_stream_parsing() {
        let chunks = vec![
            Ok(Bytes::from(r#"{"id":"1","choices":[{"delta":{"content":"Hello"}}]}"#)),
            Ok(Bytes::from(r#"{"id":"1","choices":[{"delta":{"content":" World"}}]}"#)),
        ];
        let stream = stream::iter(chunks);
        let mut output = String::new();
        
        json_stream(stream, |data| {
            let parsed: Value = serde_json::from_str(data)?;
            if let Some(content) = parsed["choices"][0]["delta"]["content"].as_str() {
                output.push_str(content);
            }
            Ok(())
        })
        .await
        .unwrap();
        
        assert_eq!(output, "Hello World");
    }
}
```

This demonstrates:
1. Stream simulation
2. Async testing
3. Error handling testing
4. Response validation

## Additional Best Practices

### Rate Limiting
While not directly implemented, the system supports rate limiting through the configuration system:

```rust
pub struct ExtraConfig {
    pub proxy: Option<String>,
    pub connect_timeout: Option<u64>,
    // Can be extended with rate limiting configuration
}
```

### Retry Logic
The system includes basic retry capability through the request builder:

```rust
fn build_client(&self) -> Result<ReqwestClient> {
    let mut builder = ReqwestClient::builder();
    let extra = self.extra_config();
    let timeout = extra.and_then(|v| v.connect_timeout).unwrap_or(10);
    // ... additional client configuration
}
```

## Exercises

1. **Token Management Implementation**
   - Implement a token counting system
   - Handle different model token limits
   - Add token usage tracking
   - Implement token-based cost calculation

2. **Stream Parser Enhancement**
   - Add support for new response formats
   - Implement error recovery
   - Add timeout handling
   - Implement backpressure

3. **Authentication System**
   - Implement a new auth method
   - Add token refresh logic
   - Handle auth failures
   - Add rate limiting

These exercises help reinforce the underlying concepts and provide practical experience with the system's more complex aspects.
