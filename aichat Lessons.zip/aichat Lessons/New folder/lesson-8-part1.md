# AIChat Lesson 8: Utility Functions and Helper Systems
## Part 1: Architecture Overview and Core Utilities

The utility system forms the backbone of AIChat's infrastructure, providing essential functionality used throughout the application. This lesson explores the comprehensive utility framework that enables AIChat's features while ensuring cross-platform compatibility and robust error handling.

### Directory Structure and Organization

The utilities module is organized in a hierarchical structure that separates concerns while maintaining cohesive functionality:

```
utils/
├── mod.rs                 # Main module file with common utilities
├── abort_signal.rs        # Abort signal handling
├── clipboard.rs           # Cross-platform clipboard operations  
├── command.rs            # Shell command execution
├── crypto.rs             # Cryptographic functions
├── html_to_md.rs         # HTML to Markdown conversion
├── path.rs               # Path manipulation utilities
├── prompt_input.rs       # User input handling
├── render_prompt.rs      # REPL prompt rendering
├── request.rs            # HTTP request handling
├── spinner.rs            # Terminal progress indicators
└── variables.rs          # Variable interpolation
```

### Core Utility Components

The main utility module (`mod.rs`) provides foundational functionality used throughout AIChat's codebase. It implements several critical features:

1. Environment Detection:
   The module maintains important environmental awareness through lazy static variables:

```rust
lazy_static::lazy_static! {
    pub static ref CODE_BLOCK_RE: Regex = Regex::new(r"(?ms)```\w*(.*)```").unwrap();
    pub static ref IS_STDOUT_TERMINAL: bool = std::io::stdout().is_terminal();
    pub static ref NO_COLOR: bool = env::var("NO_COLOR").is_ok() || !*IS_STDOUT_TERMINAL;
}
```

These variables help AIChat adapt its behavior based on the execution environment, particularly for terminal capabilities and display options.

2. Error Handling Framework:
   The module implements a sophisticated error handling system that provides context-aware error reporting:

```rust
pub fn pretty_error(err: &anyhow::Error) -> String {
    let mut output = vec![];
    output.push(format!("Error: {err}"));
    let causes: Vec<_> = err.chain().skip(1).collect();
    if causes.len() > 0 {
        output.push("\nCaused by:".to_string());
        for (i, cause) in causes.into_iter().enumerate() {
            output.push(format!("{i:5}: {}", indent_text(cause, 7).trim()));
        }
    }
    output.join("\n")
}
```

This allows for detailed error reporting with full error chains while maintaining readability.

### The Abort Signal System

One of the most critical utility components is the abort signal system, implemented in `abort_signal.rs`. This system provides a thread-safe mechanism for canceling operations throughout the application:

```rust
pub struct AbortSignalInner {
    ctrlc: AtomicBool,
    ctrld: AtomicBool,
}
```

The abort signal system offers several key features:

1. Thread-safe state management using atomic operations
2. Support for both CTRL+C and CTRL+D signal handling
3. Ability to reset signals and check abort status
4. Async support through tokio integration

Example usage:

```rust
let abort_signal = create_abort_signal();

// Wait for abort signal asynchronously
async fn wait_abort_signal(abort_signal: &AbortSignal) {
    loop {
        if abort_signal.aborted() {
            break;
        }
        tokio::time::sleep(std::time::Duration::from_millis(25)).await;
    }
}
```

### Cross-Platform Clipboard Support

The clipboard utility module provides a unified interface for clipboard operations across different platforms:

```rust
#[cfg(not(any(target_os = "android", target_os = "emscripten")))]
pub fn set_text(text: &str) -> anyhow::Result<()> {
    let mut clipboard = CLIPBOARD.lock().unwrap();
    match clipboard.as_mut() {
        Some(clipboard) => {
            clipboard.set_text(text)?;
            #[cfg(target_os = "linux")]
            std::thread::sleep(std::time::Duration::from_millis(50));
        }
        None => anyhow::bail!("Failed to copy the text; no available clipboard"),
    }
    Ok(())
}
```

The clipboard module handles platform-specific considerations for:
- Windows using Win32 API
- macOS using AppKit
- Linux with both X11 and Wayland support
- Fallback behavior for unsupported platforms

These core utilities form the foundation of AIChat's functionality, providing essential services that other components build upon. The careful organization and robust implementation ensure reliability and maintainability across the entire application.

In the next section, we'll explore the command execution and path manipulation utilities that enable AIChat's powerful shell integration capabilities.