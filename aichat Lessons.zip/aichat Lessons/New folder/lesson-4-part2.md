# AIChat Lesson 4: REPL Usage and Implementation Details

## REPL Commands and Usage

### Basic Commands

AIChat's REPL provides a rich set of commands for interaction. Here's a detailed look at the core commands and their usage:

The `.help` command displays available commands:
```
.help                    Show this help message
.info                    View system info
.model                   Change the current LLM
.prompt                  Create a temporary role using a prompt
.role                    Create or switch to a specific role
.session                 Begin a session
.rag                     Init or use the RAG
.agent                   Use an agent
.file                    Include files with the message
.continue                Continue the response
.regenerate              Regenerate the last response
.copy                    Copy the last response
.set                     Adjust runtime configuration
.delete                  Delete roles/sessions/RAGs/agents
.exit                    Exit the REPL
```

### Session Management

Session commands provide context management:
```
.session                 Begin a session
.empty session           Erase messages in the current session
.compress session        Compress messages in the current session
.info session           View session info
.edit session           Edit the current session
.save session           Save the current session to file
.exit session           End the session
```

### Role Management

Role-related commands handle role contexts:
```
.role                    Create or switch to a specific role
.info role              View role info
.edit role              Edit the current role
.save role              Save the current role to file
.exit role              Leave the role
```

### RAG Operations

RAG functionality commands:
```
.rag                     Init or use the RAG
.rebuild rag            Rebuild the RAG to sync document changes
.sources rag            View the RAG sources in the last query
.info rag               View RAG info
.exit rag               Leave the RAG
```

## Implementation Details

### Multi-line Input Processing

The REPL handles multi-line input through several mechanisms:

```rust
struct ReplValidator;

impl Validator for ReplValidator {
    fn validate(&self, line: &str) -> ValidationResult {
        let line = line.trim();
        if line.starts_with(r#":::"#) && !line[3..].ends_with(r#":::"#) {
            ValidationResult::Incomplete
        } else {
            ValidationResult::Complete
        }
    }
}
```

### Command Processing Pipeline

The command processing flow:

1. Input Collection
2. Command Parsing
3. State Validation
4. Execution
5. Output Formatting

Example implementation:

```rust
fn parse_command(line: &str) -> Option<(&str, Option<&str>)> {
    match COMMAND_RE.captures(line) {
        Ok(Some(captures)) => {
            let cmd = captures.get(1)?.as_str();
            let args = line[captures[0].len()..].trim();
            let args = if args.is_empty() { None } else { Some(args) };
            Some((cmd, args))
        }
        _ => None,
    }
}
```

### Completion System

The completion system provides context-aware suggestions:

```rust
impl Completer for ReplCompleter {
    fn complete(&mut self, line: &str, pos: usize) -> Vec<Suggestion> {
        let mut suggestions = vec![];
        // ... completion logic ...
        suggestions
    }
}
```

### Custom Prompt Rendering

The prompt system provides dynamic information:

```rust
impl Prompt for ReplPrompt {
    fn render_prompt_left(&self) -> Cow<str> {
        Cow::Owned(self.config.read().render_prompt_left())
    }

    fn render_prompt_right(&self) -> Cow<str> {
        Cow::Owned(self.config.read().render_prompt_right())
    }
}
```

## Advanced Usage Examples

### Role Creation and Usage

```shell
# Create a new role
.role coder
# Use a role temporarily
.role translator Tell me how to say "hello" in French
# View role information
.info role
```

### Session Management

```shell
# Start a new session
.session mysession
# View session information
.info session
# Compress session history
.compress session
```

### RAG Integration

```shell
# Initialize RAG with documents
.rag mydocs
# Add documents
.file document1.pdf document2.md -- What are the key points?
# View sources
.sources rag
```

### Configuration Adjustments

```shell
# Change model
.model openai:gpt-4
# Adjust settings
.set temperature 0.7
.set stream false
```

## Error Handling and Recovery

Error handling examples:

```rust
async fn handle_error(&self, err: Error) {
    render_error(err);
    if self.abort_signal.aborted() {
        println!("Operation aborted.");
    }
}
```

## Best Practices

### Command Implementation

When implementing new commands:

1. Validate state requirements
2. Handle errors gracefully
3. Provide clear feedback
4. Maintain consistency
5. Document behavior

### Input Processing

For robust input handling:

1. Validate input early
2. Handle special characters
3. Support Unicode
4. Process escape sequences
5. Handle line endings

### State Management

For reliable state handling:

1. Check state preconditions
2. Update state atomically
3. Handle transitions
4. Maintain consistency
5. Provide rollback

## Common Patterns

### Command Pattern

```rust
impl ReplCommand {
    fn new(name: &'static str, desc: &'static str, state: AssertState) -> Self {
        Self {
            name,
            description: desc,
            state,
        }
    }
}
```

### State Validation

```rust
fn is_valid(&self, flags: StateFlags) -> bool {
    match self.state {
        AssertState::True(true_flags) => true_flags & flags != StateFlags::empty(),
        AssertState::False(false_flags) => false_flags & flags == StateFlags::empty(),
        AssertState::TrueFalse(true_flags, false_flags) => {
            (true_flags & flags != StateFlags::empty())
                && (false_flags & flags == StateFlags::empty())
        }
        AssertState::Equal(check_flags) => check_flags == flags,
    }
}
```

## Troubleshooting Guide

Common issues and solutions:

1. Command not found
   - Check command syntax
   - Verify state requirements
   - Check configuration

2. Completion not working
   - Check terminal capabilities
   - Verify completion data
   - Check key bindings

3. Session errors
   - Check file permissions
   - Verify session state
   - Check storage space

4. RAG issues
   - Verify document format
   - Check embedding model
   - Verify index status

## Conclusion

Understanding AIChat's REPL implementation details and usage patterns is crucial for effective interaction with the system. The combination of robust implementation and user-friendly interface makes it a powerful tool for LLM interaction. Continue exploring the various features and capabilities to make the most of AIChat's REPL environment.

For further details and updates, refer to the AIChat documentation and GitHub repository. The next lesson will explore AIChat's client implementation and API integration features.