# AIChat Lesson 8: Utility Functions and Helper Systems
## Part 3: HTTP Requests and Progress Indication

The HTTP request handling and progress indication systems in AIChat provide essential capabilities for interacting with external services and providing visual feedback to users. These components are crucial for AIChat's RAG (Retrieval-Augmented Generation) capabilities and overall user experience.

### HTTP Request System

The request module (`request.rs`) implements a sophisticated system for handling HTTP operations with support for various content types, automatic retries, and progress tracking.

#### Core HTTP Client Configuration

The module maintains a global HTTP client with carefully configured defaults:

```rust
lazy_static::lazy_static! {
    static ref CLIENT: Result<reqwest::Client> = {
        let builder = reqwest::ClientBuilder::new().timeout(Duration::from_secs(30));
        let builder = set_proxy(builder, None)?;
        let client = builder.build()?;
        Ok(client)
    };
}
```

This configuration includes:
- Default timeout settings
- Proxy support
- Cross-platform compatibility
- Error handling and recovery

#### Content Type Handling

The module implements comprehensive content type detection and handling:

```rust
let content_type = res
    .headers()
    .get(CONTENT_TYPE)
    .and_then(|v| v.to_str().ok())
    .map(|v| match v.split_once(';') {
        Some((mime, _)) => mime.trim(),
        None => v,
    })
    .unwrap_or_else(|| {
        format!(
            "_/{}",
            get_patch_extension(path).unwrap_or_else(|| DEFAULT_EXTENSION.into())
        )
    });
```

The system supports various content types including:
- PDF documents
- Office documents (DOCX, XLSX, etc.)
- HTML content with markdown conversion
- Media files with base64 encoding
- Plain text and custom formats

#### Web Crawling Capabilities

The request module includes a robust web crawling system for document retrieval:

```rust
pub async fn crawl_website(start_url: &str, options: CrawlOptions) -> Result<Vec<Page>> {
    let start_url = Url::parse(start_url)?;
    let mut paths = vec![start_url.path().to_string()];
    let normalized_start_url = normalize_start_url(&start_url);
    
    // Crawler configuration and setup
    let semaphore = Arc::new(Semaphore::new(MAX_CRAWLS));
    let mut result_pages = Vec::new();

    // Main crawling loop
    while index < paths.len() {
        let batch = paths[index..std::cmp::min(index + MAX_CRAWLS, paths.len())].to_vec();
        // Concurrent page processing
        // ...
    }
    
    Ok(result_pages)
}
```

The crawler provides features like:
- Concurrent page processing
- Rate limiting
- Content extraction
- Link following with filters

### Progress Indication System

The spinner module (`spinner.rs`) implements a sophisticated progress indication system for long-running operations.

#### Spinner Implementation

The core spinner functionality is implemented through the `SpinnerInner` struct:

```rust
pub struct SpinnerInner {
    index: usize,
    message: String,
}

impl SpinnerInner {
    const DATA: [&'static str; 10] = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];

    fn step(&mut self) -> Result<()> {
        if !*IS_STDOUT_TERMINAL || self.message.is_empty() {
            return Ok(());
        }
        let mut writer = stdout();
        let frame = Self::DATA[self.index % Self::DATA.len()];
        let dots = ".".repeat((self.index / 5) % 4);
        let line = format!("{frame}{}{:<3}", self.message, dots);
        queue!(writer, cursor::MoveToColumn(0), style::Print(line),)?;
        // ... terminal handling
    }
}
```

#### Asynchronous Progress Handling

The spinner system integrates with Tokio for asynchronous operation:

```rust
pub async fn create_spinner(message: &str) -> Spinner {
    let message = format!(" {message}");
    let (tx, rx) = mpsc::unbounded_channel();
    tokio::spawn(run_spinner(message, rx));
    Spinner(tx)
}

async fn run_spinner(message: String, mut rx: mpsc::UnboundedReceiver<SpinnerEvent>) -> Result<()> {
    let mut spinner = SpinnerInner::new(&message);
    let mut interval = interval(Duration::from_millis(50));
    
    loop {
        tokio::select! {
            _ = interval.tick() => {
                let _ = spinner.step();
            }
            evt = rx.recv() => {
                // Handle spinner events
            }
        }
    }
}
```

This enables:
- Non-blocking progress indication
- Message updates
- Clean cancellation
- Terminal state management

#### Integration with Terminal

The spinner system carefully manages terminal state:

```rust
async fn run_abortable_spinner(
    message: &str,
    abort_signal: AbortSignal,
    done_rx: oneshot::Receiver<()>,
) -> Result<()> {
    enable_raw_mode()?;
    let ret = run_abortable_spinner_inner(message, abort_signal, done_rx).await;
    disable_raw_mode()?;
    ret
}
```

This ensures:
- Proper terminal cleanup
- Cursor visibility management
- Cross-platform compatibility
- Signal handling

### Error Handling and Recovery

Both systems implement comprehensive error handling:

```rust
pub async fn abortable_run_with_spinner<F, T>(
    task: F,
    message: &str,
    abort_signal: AbortSignal,
) -> Result<T>
where
    F: Future<Output = Result<T>>,
{
    if *IS_STDOUT_TERMINAL {
        let (done_tx, done_rx) = oneshot::channel();
        let run_task = async {
            tokio::select! {
                ret = task => {
                    let _ = done_tx.send(());
                    ret
                }
                _ = wait_abort_signal(&abort_signal) => {
                    let _ = done_tx.send(());
                    bail!("Aborted.");
                },
            }
        };
        // Task execution with progress indication
    } else {
        task.await
    }
}
```

This provides:
- Graceful error recovery
- Resource cleanup
- User feedback
- Operation cancellation

The HTTP request and progress indication systems work together to provide a robust foundation for AIChat's network operations and user interface feedback. Their careful implementation ensures reliable operation across different platforms and usage scenarios.

In the final section, we'll explore AIChat's variable interpolation and terminal rendering systems.