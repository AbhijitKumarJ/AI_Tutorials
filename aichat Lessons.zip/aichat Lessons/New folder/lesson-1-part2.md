# AIChat Lesson 1: Foundation and Core Structure (Part 2)

## Configuration System Deep Dive

### Config File Locations

The configuration file location follows platform-specific conventions:

- Windows: `C:\Users\Alice\AppData\Roaming\aichat\config.yaml`
- macOS: `/Users/Alice/Library/Application Support/aichat/config.yaml`  
- Linux: `/home/alice/.config/aichat/config.yaml`

### Configuration File Structure

The configuration file uses YAML format and supports extensive customization:

```yaml
# LLM settings
model: openai:gpt-4o
temperature: null
top_p: null

# Behavior settings
stream: true
save: true
keybindings: emacs
editor: null
wrap: no
wrap_code: false

# Function calling settings
function_calling: true
mapping_tools:
  fs: 'fs_cat,fs_ls,fs_mkdir,fs_rm,fs_write'
use_tools: null

# Session settings  
save_session: null
compress_threshold: 4000

# RAG settings
rag_embedding_model: null
rag_reranker_model: null
rag_top_k: 4
```

### Environment Variables

The system supports configuration through environment variables with a consistent naming scheme:

```sh
AICHAT_MODEL=openai:gpt-4o
AICHAT_TEMPERATURE=0.7
AICHAT_STREAM=false
```

All config items can be overridden through environment variables following the pattern `AICHAT_<KEY>`.

## Error Handling System

AIChat implements comprehensive error handling using anyhow:

### Error Context Propagation

```rust
fn setup_logger() -> Result<()> {
    let (log_level, log_path) = Config::log_config()?;
    
    if log_level == LevelFilter::Off {
        return Ok(());
    }

    // Error handling with context
    let config = LoggerConfig::new()
        .with_context(|| "Failed to initialize logger")?;
        
    Ok(())
}
```

### Custom Error Creation
```rust
if !validate_command(cmd) {
    bail!("Unable to run {cmd_name}, {err}")
}
```

## Module Organization

### Core Components:

1. **Client Layer**: Handles communication with various LLM providers
   - Located in `client/` directory
   - Implements provider-specific APIs
   - Manages authentication and rate limiting

2. **Configuration Management**: Handles all configuration aspects
   - Located in `config/` directory
   - Manages user preferences
   - Handles session state

3. **RAG System**: Manages document retrieval and embeddings
   - Located in `rag/` directory
   - Handles document processing
   - Manages vector storage

4. **Rendering System**: Handles output formatting
   - Located in `render/` directory
   - Manages terminal output
   - Handles syntax highlighting

5. **REPL System**: Provides interactive shell
   - Located in `repl/` directory
   - Manages command history
   - Handles auto-completion

## Practical Examples

### Basic Usage Examples

1. Command Line Interface:
```sh
# Generate a response
aichat "What is the capital of France?"

# Use a specific model
aichat -m openai:gpt-4o "Tell me a joke"

# Execute a shell command
aichat -e "create a new directory named src"

# Start a session
aichat -s mysession
```

2. REPL Commands:
```sh
# Show help
.help

# Change model
.model gpt-4

# Create/switch role
.role python-expert

# Start session
.session coding

# Use RAG
.rag docs
```

### Configuration Example:

```yaml
# config.yaml
model: openai:gpt-4o
temperature: 0.7
stream: true
save: true

clients:
  - type: openai
    api_key: xxx
    organization_id: org-xxx
    
  - type: anthropic
    api_key: xxx
```

## Shell Integration

AIChat provides shell integration scripts for various shells:

```bash
# Bash integration
source /path/to/aichat/scripts/shell-integration/integration.bash

# Zsh integration  
source /path/to/aichat/scripts/shell-integration/integration.zsh

# Fish integration
source /path/to/aichat/scripts/shell-integration/integration.fish
```

## Testing Strategy

AIChat uses a comprehensive testing approach:

1. Unit Tests:
```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_config_loading() {
        let config = Config::load_from_file("test_config.yaml");
        assert!(config.is_ok());
    }
}
```

2. Integration Tests:
```rust
#[tokio::test]
async fn test_chat_completion() {
    let config = test_utils::create_test_config();
    let client = config.create_client().unwrap();
    let response = client.chat_completions("test").await;
    assert!(response.is_ok());
}
```

## Best Practices

1. Error Handling:
   - Use anyhow::Result for flexible error handling
   - Provide context with .with_context()
   - Use structured error types where appropriate

2. Cross-Platform Compatibility:
   - Use cfg attributes for platform-specific code
   - Abstract platform differences behind common interfaces
   - Test on all supported platforms

3. Configuration Management:
   - Follow hierarchical configuration loading
   - Support environment variable overrides
   - Provide sensible defaults

4. Code Organization:
   - Keep related functionality together
   - Use clear naming conventions
   - Maintain consistent error handling patterns

## Exercises

1. Create a new configuration file:
```rust
fn create_config() -> Result<Config> {
    let config = Config {
        model_id: "openai:gpt-4".to_string(),
        temperature: Some(0.7),
        stream: true,
        save: true,
        ..Default::default()
    };
    Ok(config)
}
```

2. Implement cross-platform path handling:
```rust
fn normalize_path(path: &Path) -> Result<PathBuf> {
    // Implementation exercise
    // Handle Windows vs Unix paths
    // Expand home directory
    // Validate path safety
}
```

These exercises will help reinforce understanding of the core concepts while providing practical experience with the codebase.

## Conclusion

Understanding AIChat's foundational structure is crucial for both using and extending the application. The system's design provides a robust and user-friendly interface while maintaining cross-platform compatibility and extensibility. The next lesson will explore the client abstraction layer, building on this foundational knowledge.

## Additional Resources

1. Rust standard library documentation
2. Cross-platform Rust guidelines
3. Error handling patterns
4. Terminal manipulation guides
5. Async programming patterns
6. State management strategies

This comprehensive foundation will enable developers to effectively work with and contribute to the AIChat codebase.