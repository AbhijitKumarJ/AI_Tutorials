# AIChat Lesson 3: Configuration and State Management - Part 2
## Sessions, Roles, and Agents Implementation

### Session Management

Sessions in AIChat provide persistent conversation state and context management. The session system is implemented in `session.rs` and centers around the Session struct:

```rust
pub struct Session {
    model_id: String,
    temperature: Option<f64>,
    top_p: Option<f64>,
    use_tools: Option<String>,
    save_session: Option<bool>,
    compress_threshold: Option<usize>,

    role_name: Option<String>,
    agent_variables: IndexMap<String, String>,
    data_urls: HashMap<String, String>,
    compressed_messages: Vec<Message>,
    messages: Vec<Message>,

    #[serde(skip)]
    model: Model,
    #[serde(skip)]
    role_prompt: String,
    #[serde(skip)]
    name: String,
    #[serde(skip)]
    path: Option<String>,
}
```

Sessions implement several key features:

1. Message History Management:
```rust
pub fn add_message(&mut self, input: &Input, output: &str) -> Result<()> {
    if input.continue_output().is_some() {
        if let Some(message) = self.messages.last_mut() {
            if let MessageContent::Text(text) = &mut message.content {
                *text = format!("{text}{output}");
            }
        }
    }
    // Additional message handling
}
```

2. Token Tracking:
```rust
pub fn tokens_usage(&self) -> (usize, f32) {
    let tokens = self.tokens();
    let max_input_tokens = self.model().max_input_tokens().unwrap_or_default();
    let percent = if max_input_tokens == 0 {
        0.0
    } else {
        let percent = tokens as f32 / max_input_tokens as f32 * 100.0;
        (percent * 100.0).round() / 100.0
    };
    (tokens, percent)
}
```

3. Compression Management:
```rust
pub fn compress(&mut self, mut prompt: String) {
    if let Some(system_prompt) = self.messages.first().and_then(|v| {
        if MessageRole::System == v.role {
            let content = v.content.to_text();
            if !content.is_empty() {
                return Some(content);
            }
        }
        None
    }) {
        prompt = format!("{system_prompt}\n\n{prompt}",);
    }
    self.compressed_messages.append(&mut self.messages);
    self.messages.push(Message::new(
        MessageRole::System,
        MessageContent::Text(prompt),
    ));
}
```

### Role Management

Roles provide customized LLM behaviors and are implemented in `role.rs`. The Role struct defines:

```rust
pub struct Role {
    name: String,
    prompt: String,
    model_id: Option<String>,
    temperature: Option<f64>,
    top_p: Option<f64>,
    use_tools: Option<String>,
    
    #[serde(skip)]
    model: Model,
}
```

Roles support several formats:

1. Embedded Prompts:
```rust
pub fn is_embedded_prompt(&self) -> bool {
    self.prompt.contains(INPUT_PLACEHOLDER)
}
```

2. System Prompts:
```rust
pub fn build_messages(&self, input: &Input) -> Vec<Message> {
    let (system, cases) = parse_structure_prompt(&self.prompt);
    if !system.is_empty() {
        messages.push(Message::new(
            MessageRole::System,
            MessageContent::Text(system.to_string()),
        ));
    }
    // Additional message building
}
```

3. Few-shot Learning Prompts:
The system supports structured prompts with examples:
```rust
fn parse_structure_prompt(prompt: &str) -> (&str, Vec<(&str, &str)>) {
    // Extracts system message and input/output pairs
}
```

### Agent Implementation

Agents combine roles, tools, and document retrieval, implemented in `agent.rs`:

```rust
pub struct Agent {
    name: String,
    config: AgentConfig,
    definition: AgentDefinition,
    shared_variables: IndexMap<String, String>,
    session_variables: Option<IndexMap<String, String>>,
    functions: Functions,
    rag: Option<Arc<Rag>>,
    model: Model,
}
```

Key agent features include:

1. Variable Management:
```rust
pub fn init_agent_variables(
    agent_variables: &[AgentVariable],
    variables: &IndexMap<String, String>,
) -> Result<IndexMap<String, String>> {
    // Initialize and validate agent variables
}
```

2. Tool Integration:
```rust
pub fn functions(&self) -> &Functions {
    &self.functions
}
```

3. RAG Integration:
```rust
pub fn rag(&self) -> Option<Arc<Rag>> {
    self.rag.clone()
}
```

### State Interaction Patterns

The three systems (Sessions, Roles, and Agents) interact through the RoleLike trait:

```rust
pub trait RoleLike {
    fn to_role(&self) -> Role;
    fn model(&self) -> &Model;
    fn model_mut(&mut self) -> &mut Model;
    fn temperature(&self) -> Option<f64>;
    fn top_p(&self) -> Option<f64>;
    fn use_tools(&self) -> Option<String>;
    fn set_model(&mut self, model: &Model);
    fn set_temperature(&mut self, value: Option<f64>);
    fn set_top_p(&mut self, value: Option<f64>);
    fn set_use_tools(&mut self, value: Option<String>);
}
```

This trait ensures consistent behavior across different types of state holders while maintaining proper encapsulation.

In the final part, we'll explore practical usage patterns, persistence mechanisms, and cross-platform considerations.