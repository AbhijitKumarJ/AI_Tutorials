# AIChat HTTP Server Implementation - Part 3: Core Concepts and Additional Details

## Foundational Technologies and Concepts

### Hyper and HTTP/1.1

AIChat uses Hyper, a fast and correct HTTP implementation in Rust. Key concepts include:

1. The Request-Response Cycle:
```rust
pub async fn handle(
    self: Arc<Self>,
    req: hyper::Request<Incoming>,
) -> std::result::Result<AppResponse, hyper::Error>
```

The `Request` struct contains:
- Method (GET, POST, etc.)
- URI 
- Headers
- Body (as a stream of bytes)

The `Response` struct contains:
- Status code
- Headers
- Body

2. HTTP Headers:
```rust
res.headers_mut().insert(
    hyper::header::ACCESS_CONTROL_ALLOW_ORIGIN,
    hyper::header::HeaderValue::from_static("*"),
);
```

### Tokio Async Runtime

Tokio provides the async runtime for AIChat. Core concepts include:

1. **Futures**: Asynchronous computations that can be polled to completion
```rust
pub trait Future {
    type Output;
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}
```

2. **Tasks**: Units of concurrent work
```rust
tokio::spawn(async move {
    // Concurrent work here
});
```

3. **Channels**: Communication between tasks
```rust
let (tx, rx) = tokio::sync::mpsc::unbounded_channel();
// tx.send(message)
// rx.recv().await
```

### Server-Sent Events (SSE)

SSE is used for streaming LLM responses. The protocol looks like:

```plaintext
HTTP/1.1 200 OK
Content-Type: text/event-stream
Cache-Control: no-cache
Connection: keep-alive

data: {"content": "Hello"}

data: {"content": " World"}

data: [DONE]
```

Implementation in AIChat:
```rust
#[derive(Debug)]
pub enum SseEvent {
    Text(String),
    Done,
}

pub struct SseHandler {
    sender: UnboundedSender<SseEvent>,
    abort_signal: AbortSignal,
    buffer: String,
    tool_calls: Vec<ToolCall>,
}
```

### Bytes and BytesMut

Understanding Bytes types is crucial:

1. `Bytes`: An immutable buffer
```rust
let bytes = Bytes::from("Hello World");
```

2. `BytesMut`: A mutable buffer
```rust
let mut buffer = BytesMut::new();
buffer.extend_from_slice(b"Hello");
```

These are used extensively in the streaming implementation.

## Advanced Server Concepts

### Connection Management

1. Connection Pooling:
```rust
pub struct ConnectionPool {
    idle_timeout: Duration,
    max_lifetime: Duration,
    max_idle: usize,
    connections: Vec<PooledConnection>,
}
```

2. Keep-Alive:
```rust
Response::builder()
    .header("Connection", "keep-alive")
    .header("Keep-Alive", "timeout=5, max=1000")
```

### Backpressure Handling

Backpressure occurs when data is produced faster than it can be consumed. AIChat handles this through:

1. Buffering:
```rust
pub struct Buffer {
    data: VecDeque<Bytes>,
    max_size: usize,
}
```

2. Flow Control:
```rust
impl<S: Stream> StreamExt<S> {
    fn buffer_unordered(self, limit: usize) -> BufferUnordered<S>
}
```

### Error Propagation

Error handling patterns in async code:

```rust
#[derive(Debug, Error)]
pub enum ServerError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    
    #[error("HTTP error: {0}")]
    Http(#[from] hyper::Error),
    
    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),
}

async fn handle_request() -> Result<Response, ServerError> {
    let data = read_data().await?;
    let processed = process_data(data).await?;
    Ok(create_response(processed))
}
```

## Protocol-Specific Details

### HTTP Status Codes

Important status codes used in AIChat:

```rust
const STATUS_OK: StatusCode = StatusCode::OK;                    // 200
const STATUS_BAD_REQUEST: StatusCode = StatusCode::BAD_REQUEST;  // 400
const STATUS_NOT_FOUND: StatusCode = StatusCode::NOT_FOUND;      // 404
const STATUS_SERVER_ERROR: StatusCode = StatusCode::INTERNAL_SERVER_ERROR; // 500
```

### Content Types

Common content types:
```rust
const CONTENT_TYPE_JSON: &str = "application/json";
const CONTENT_TYPE_SSE: &str = "text/event-stream";
const CONTENT_TYPE_HTML: &str = "text/html; charset=utf-8";
```

### CORS Headers

Cross-Origin Resource Sharing headers:
```rust
ACCESS_CONTROL_ALLOW_ORIGIN: "*"
ACCESS_CONTROL_ALLOW_METHODS: "GET,POST,PUT,PATCH,DELETE"
ACCESS_CONTROL_ALLOW_HEADERS: "Content-Type,Authorization"
```

## Memory Management

### Buffer Management

Efficient buffer handling:
```rust
pub struct StreamBuffer {
    inner: BytesMut,
    capacity: usize,
}

impl StreamBuffer {
    pub fn new(capacity: usize) -> Self {
        Self {
            inner: BytesMut::with_capacity(capacity),
            capacity,
        }
    }
    
    pub fn extend(&mut self, data: &[u8]) -> Result<()> {
        if self.inner.len() + data.len() > self.capacity {
            return Err(anyhow!("Buffer capacity exceeded"));
        }
        self.inner.extend_from_slice(data);
        Ok(())
    }
}
```

### Memory Pooling

Pool of reusable buffers:
```rust
pub struct BufferPool {
    buffers: Vec<BytesMut>,
    capacity: usize,
}

impl BufferPool {
    pub fn acquire(&mut self) -> Option<BytesMut> {
        self.buffers.pop()
    }
    
    pub fn release(&mut self, mut buffer: BytesMut) {
        buffer.clear();
        self.buffers.push(buffer);
    }
}
```

## Security Considerations

### Request Validation

Input validation implementation:
```rust
fn validate_request<T: DeserializeOwned>(body: &[u8]) -> Result<T> {
    // Check size
    if body.len() > MAX_REQUEST_SIZE {
        return Err(anyhow!("Request too large"));
    }
    
    // Validate JSON
    let value: Value = serde_json::from_slice(body)?;
    
    // Schema validation
    validate_schema(&value)?;
    
    // Parse to type
    let parsed: T = serde_json::from_value(value)?;
    
    Ok(parsed)
}
```

### Rate Limiting

Token bucket implementation:
```rust
pub struct TokenBucket {
    tokens: AtomicU32,
    capacity: u32,
    refill_rate: f64,
    last_refill: AtomicI64,
}

impl TokenBucket {
    pub fn try_acquire(&self) -> bool {
        self.refill();
        
        let current = self.tokens.load(Ordering::Relaxed);
        if current > 0 {
            self.tokens.fetch_sub(1, Ordering::Relaxed);
            true
        } else {
            false
        }
    }
    
    fn refill(&self) {
        let now = Instant::now();
        let last = self.last_refill.load(Ordering::Relaxed);
        let elapsed = now.duration_since(last).as_secs_f64();
        
        let new_tokens = (elapsed * self.refill_rate) as u32;
        if new_tokens > 0 {
            self.tokens.fetch_add(new_tokens, Ordering::Relaxed);
            self.last_refill.store(now, Ordering::Relaxed);
        }
    }
}
```

## Testing Infrastructure

### Unit Testing

Example of unit test structure:
```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[tokio::test]
    async fn test_request_handling() {
        // Setup
        let server = Server::new(&config);
        
        // Create test request
        let request = Request::builder()
            .method("POST")
            .uri("/v1/chat/completions")
            .body(Body::from(r#"{"model": "test"}"#))
            .unwrap();
            
        // Send request
        let response = server.handle(request).await.unwrap();
        
        // Assert response
        assert_eq!(response.status(), StatusCode::OK);
    }
}
```

### Integration Testing

Testing the full server:
```rust
#[tokio::test]
async fn test_server_integration() {
    // Start server
    let server = TestServer::start().await;
    
    // Create client
    let client = reqwest::Client::new();
    
    // Send request
    let response = client
        .post(&format!("{}/v1/chat/completions", server.addr()))
        .json(&json!({
            "model": "test-model",
            "messages": [{"role": "user", "content": "test"}]
        }))
        .send()
        .await
        .unwrap();
        
    assert!(response.status().is_success());
}
```

## Configuration Management

### Environment Variables

Loading configuration:
```rust
pub struct ServerConfig {
    pub host: String,
    pub port: u16,
    pub max_connections: usize,
}

impl ServerConfig {
    pub fn from_env() -> Result<Self> {
        Ok(Self {
            host: env::var("AICHAT_HOST")
                .unwrap_or_else(|_| "127.0.0.1".to_string()),
            port: env::var("AICHAT_PORT")
                .ok()
                .and_then(|s| s.parse().ok())
                .unwrap_or(8000),
            max_connections: env::var("AICHAT_MAX_CONNECTIONS")
                .ok()
                .and_then(|s| s.parse().ok())
                .unwrap_or(100),
        })
    }
}
```

### Dynamic Configuration

Supporting runtime config changes:
```rust
pub struct DynamicConfig {
    inner: RwLock<ServerConfig>,
    watchers: Vec<Sender<ConfigUpdate>>,
}

impl DynamicConfig {
    pub async fn update(&self, update: ConfigUpdate) -> Result<()> {
        let mut config = self.inner.write().await;
        config.apply_update(update.clone())?;
        
        for watcher in &self.watchers {
            let _ = watcher.send(update.clone()).await;
        }
        
        Ok(())
    }
}
```

## Logging and Monitoring

### Structured Logging

Log implementation:
```rust
#[derive(Debug, Serialize)]
struct LogEntry {
    timestamp: DateTime<Utc>,
    level: String,
    message: String,
    metadata: HashMap<String, Value>,
}

fn log_request(req: &Request<Body>, metadata: HashMap<String, Value>) {
    let entry = LogEntry {
        timestamp: Utc::now(),
        level: "INFO".to_string(),
        message: format!("{} {}", req.method(), req.uri()),
        metadata,
    };
    
    info!("{}", serde_json::to_string(&entry).unwrap());
}
```

### Metrics Collection

Basic metrics tracking:
```rust
pub struct Metrics {
    requests_total: AtomicU64,
    requests_failed: AtomicU64,
    response_time_ms: Histogram,
}

impl Metrics {
    pub fn record_request(&self, duration: Duration, success: bool) {
        self.requests_total.fetch_add(1, Ordering::Relaxed);
        if !success {
            self.requests_failed.fetch_add(1, Ordering::Relaxed);
        }
        self.response_time_ms.record(duration.as_millis() as u64);
    }
}
```

## Conclusion

Understanding these underlying concepts is crucial for working with and extending AIChat's HTTP server implementation. These concepts form the foundation for the server's robust operation and provide context for the implementation details covered in Parts 1 and 2.