# Lesson 6: End-User Guide and Practical Usage

## Terminal Setup and Configuration

### Terminal Emulator Selection

AIChat works with various terminal emulators, but some provide better experiences than others:

**Recommended Terminal Emulators:**

Windows:
- Windows Terminal (Modern, full feature support)
- Alacritty (Excellent performance)
- iTerm2 (When using WSL)

macOS:
- iTerm2 (Best overall experience)
- Terminal.app (Built-in, good basic support)
- Alacritty (High performance)

Linux:
- GNOME Terminal (Full feature support)
- Konsole (KDE's terminal, excellent integration)
- Alacritty (Performance focused)
- Kitty (Modern features)

### Color Scheme Considerations

AIChat supports various color schemes through its theme system. To get the best experience:

1. **Terminal Color Settings:**
```yaml
# Example terminal color settings
background_color: "#1E1E1E"
foreground_color: "#D4D4D4"
cursor_color: "#FFFFFF"
```

2. **Theme Selection:**
```yaml
# In aichat config
light_theme: false  # Use dark theme
highlight: true     # Enable syntax highlighting
```

3. **Custom Color Schemes:**
- Place custom `.tmTheme` files in your AIChat configuration directory
- Name them `dark.tmTheme` or `light.tmTheme` based on their purpose

## Text Rendering and Formatting

### Working with Code Blocks

AIChat provides several ways to format code blocks:

1. **Fenced Code Blocks:**
   ```
   ```python
   def hello():
       print("Hello, World!")
   ```
   ```

2. **Inline Code:**
   Use backticks for inline code: `print("Hello")`

3. **Code Block Languages:**
   - Specify language for proper highlighting
   - Use common aliases (js for javascript, py for python)

### Text Wrapping Options

Control how text is wrapped in your terminal:

```yaml
# In aichat config
wrap: "auto"        # Automatic width based on terminal
wrap_code: false    # Don't wrap code blocks
```

Available wrap options:
- `no`: No wrapping
- `auto`: Wrap based on terminal width
- `<number>`: Wrap at specific column

## Interactive Features

### Progress Indicators

AIChat displays progress indicators during:
1. Model responses
2. File processing
3. RAG operations
4. Function calls

You can control their appearance:
```yaml
# In aichat config
spinner_style: "dots"    # Style of spinner
spinner_color: "blue"    # Color of spinner
```

### Copy and Paste

AIChat provides several clipboard operations:

1. **Copying Output:**
   - Use `.copy` command in REPL
   - Use system clipboard shortcuts
   - Select and copy text manually

2. **Pasting Input:**
   - Use system paste shortcuts
   - Right-click paste (terminal dependent)
   - Bracketed paste mode support

### Navigation

Moving through output:

1. **Scrolling:**
   - Use terminal scrollbar
   - Mouse wheel/trackpad
   - Page Up/Down keys
   - Shift+Arrow keys

2. **Search:**
   - Terminal search (usually Ctrl+Shift+F)
   - Text selection
   - Command history (Ctrl+R)

## Customization

### REPL Prompt Customization

Customize your prompt appearance:

```yaml
# In aichat config
left_prompt: '{color.green}{?session {session}}{color.cyan}> '
right_prompt: '{color.purple}{?session {consume_tokens}}{color.reset}'
```

Available variables:
- `session`: Current session name
- `role`: Active role
- `model`: Current model
- `consume_tokens`: Token usage

### Output Styling

Control how different elements are displayed:

```yaml
# In aichat config
highlight: true          # Enable syntax highlighting
light_theme: false       # Use dark theme
wrap: "auto"            # Text wrapping mode
wrap_code: false        # Code block wrapping
```

## Troubleshooting Common Issues

### Display Problems

1. **Garbled Output:**
   ```bash
   # Check terminal encoding
   echo $LANG
   # Should be UTF-8, e.g.:
   # en_US.UTF-8
   ```

2. **Color Issues:**
   ```bash
   # Check color support
   echo $COLORTERM
   # Should be:
   # truecolor or 24bit
   ```

3. **Formatting Problems:**
   ```bash
   # Check if NO_COLOR is set
   echo $NO_COLOR
   # Should be empty for color support
   ```

### Performance Optimization

1. **Reduce Resource Usage:**
   ```yaml
   # In aichat config
   stream: true          # Enable streaming for faster response
   cache_size: 1000      # Adjust cache size
   ```

2. **Terminal Performance:**
   - Reduce scrollback buffer size
   - Use GPU acceleration if available
   - Consider using Alacritty for better performance

## Environment Variables

Important environment variables that affect rendering:

```bash
# Color control
export NO_COLOR=0               # Disable colors
export COLORTERM=truecolor      # Enable true color support

# Terminal configuration
export TERM=xterm-256color      # Terminal type
export AICHAT_LIGHT_THEME=1     # Force light theme

# Editor integration
export EDITOR=vim               # Set default editor
```

## Integration with Terminal Multiplexers

### TMux Support

When using TMux:

1. **Configuration:**
   ```tmux
   # ~/.tmux.conf
   set -g default-terminal "tmux-256color"
   set -ag terminal-overrides ",xterm-256color:RGB"
   ```

2. **Split Panes:**
   - Vertical splits for side-by-side comparison
   - Horizontal splits for input/output separation

### Screen Support

For GNU Screen users:

1. **Configuration:**
   ```screen
   # ~/.screenrc
   term screen-256color
   termcapinfo xterm* Ti@:te@
   ```

## File Handling

### Working with Different File Types

AIChat handles various file types differently:

1. **Text Files:**
   - Direct rendering
   - Syntax highlighting based on extension
   - Automatic encoding detection

2. **Binary Files:**
   - Hex view for small files
   - Size warning for large files
   - Optional binary file filtering

3. **Images:**
   - ASCII art rendering (when possible)
   - Image links in markdown
   - Terminal image protocol support (iTerm2)

### Large File Handling

When working with large files:

1. **Streaming Mode:**
   ```yaml
   # In aichat config
   stream_threshold: 1MB    # Stream files larger than this
   ```

2. **Pagination:**
   - Automatic for large outputs
   - Manual page navigation
   - Search within paged content

## Advanced Usage

### Custom Rendering Rules

Create custom rendering rules:

```yaml
# In aichat config
render_rules:
  - pattern: "WARNING:"
    style: "yellow bold"
  - pattern: "ERROR:"
    style: "red bold"
```

### Output Redirection

Handle output redirection:

1. **File Output:**
   ```bash
   aichat query > output.txt
   ```

2. **Pipeline Usage:**
   ```bash
   aichat query | grep "result"
   ```

### Multiple Instance Management

When running multiple AIChat instances:

1. **Session Management:**
   - Unique session names
   - Separate configuration files
   - Independent history

2. **Resource Sharing:**
   - Shared theme files
   - Common configuration elements
   - Global settings

## Best Practices

1. **Terminal Setup:**
   - Use a modern terminal emulator
   - Enable true color support
   - Configure proper font with programming ligatures

2. **Configuration:**
   - Start with default settings
   - Customize incrementally
   - Document your changes

3. **Usage Patterns:**
   - Use appropriate wrap settings for your screen
   - Enable streaming for better responsiveness
   - Utilize clipboard integration

4. **Maintenance:**
   - Regular configuration backups
   - Theme file updates
   - Cache cleanup

## Conclusion

Understanding these usage details helps in:
- Getting the best experience from AIChat
- Avoiding common pitfalls
- Customizing the environment effectively
- Troubleshooting issues
- Optimizing performance

The rendering system's flexibility allows for:
- Personal customization
- Different workflow adaptations
- Various use cases
- Integration with other tools
- Efficient problem solving

Remember that AIChat's rendering system is designed to be:
- User-friendly
- Customizable
- Efficient
- Platform-independent
- Feature-rich while maintaining simplicity