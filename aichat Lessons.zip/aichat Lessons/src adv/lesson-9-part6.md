# End-User Guide and Practical Usage

### Installation and Setup

Before using AIChat's agent system, users need to understand the setup process:

1. Installation Methods:
```bash
# Using Cargo (Rust package manager)
cargo install aichat

# Using Homebrew
brew install aichat

# Using Pacman
pacman -S aichat

# Windows using Scoop
scoop install aichat

# Android using Termux
pkg install aichat
```

2. Initial Configuration:
```bash
$ aichat
> No config file, create a new one? Yes
> Platform: openai
? API Key: ***
✨ Saved config file to '/home/user/.config/aichat.yaml'
```

### Configuration Files Location

Understanding where configuration files are stored is crucial:

```plaintext
Configuration locations by OS:
- Windows: C:\Users\Username\AppData\Roaming\aichat\config.yaml
- macOS: /Users/Username/Library/Application Support/aichat/config.yaml
- Linux: /home/username/.config/aichat/config.yaml
```

To find your config file location:
```bash
aichat --info | grep config_file
```

### Basic Usage Patterns

#### 1. Starting an Agent

From the command line:
```bash
# Basic agent start
aichat -a agent_name

# Agent with specific session
aichat -a agent_name -s my_session

# Agent with file input
aichat -a agent_name -f document.pdf

# Agent with multiple files
aichat -a agent_name -f file1.txt -f file2.md -- analyze these files
```

From within the REPL:
```
> .agent agent_name      # Start agent
> .info agent           # View agent info
> .variable set KEY VALUE  # Set agent variable
> .starter              # Show conversation starters
```

#### 2. Working with Sessions

Sessions help maintain context:
```
# Start new session
> .session my_session

# View session info
> .info session

# Compress session to save tokens
> .compress session

# Save session
> .save session

# Empty session
> .empty session

# Exit session
> .exit session
```

#### 3. Using RAG Capabilities

```
# Initialize RAG with documents
> Add documents: /path/to/docs/*.md

# Adding multiple document types
> Add documents: docs/**/*.{md,txt,pdf}

# Using web documents
> Add documents: https://example.com/docs/**

# View RAG info
> .info rag

# Search within RAG
> .search rag "query"
```

### Common Use Cases

#### 1. Document Analysis

```bash
# Analyze a PDF document
aichat -a doc-analyzer -f report.pdf -- summarize this report

# Compare multiple documents
aichat -a doc-analyzer -f doc1.pdf -f doc2.pdf -- compare these documents

# Extract specific information
aichat -a doc-analyzer -f contract.pdf -- extract payment terms
```

Interactive mode:
```
> .agent doc-analyzer
✨ Loaded doc-analyzer agent
> .file contract.pdf
> What are the key dates in this document?
```

#### 2. Code Assistant

```bash
# Code review
aichat -a dev-assistant -f src/*.py -- review these files

# Documentation generation
aichat -a dev-assistant -f app.js -- generate documentation

# Test case generation
aichat -a dev-assistant -f module.py -- suggest test cases
```

Interactive mode:
```
> .agent dev-assistant
✨ Loaded development assistant
> .file main.rs
> How can I optimize this code?
```

#### 3. Data Analysis

```bash
# Analyze dataset
aichat -a data-analyst -f data.csv -- analyze this dataset

# Create visualizations
aichat -a data-analyst -f sales.csv -- create monthly trend visualization

# Generate reports
aichat -a data-analyst -f metrics.csv -- generate quarterly report
```

### Understanding Output and Responses

#### 1. Message Types

Users should understand different message indicators:

```plaintext
System Messages: Appear as context/instructions
User Messages: Your inputs (>)
Assistant Messages: Agent responses
Tool Results: Output from function calls [🔧]
```

#### 2. Status Indicators

```plaintext
⌛ Processing request
✨ Operation successful
❌ Error occurred
🔧 Tool execution
📝 Session saved
```

### Troubleshooting Common Issues

#### 1. Token Limits

When you see "Input tokens exceed model's maximum":
```
# Option 1: Compress session
> .compress session

# Option 2: Empty session
> .empty session

# Option 3: Use a model with higher limits
> .model gpt-4-32k
```

#### 2. Tool Execution Errors

When tools fail:
```
# Check tool requirements
> .info agent

# Verify tool permissions
> .variable set TOOL_PATH /correct/path

# Enable debug logging
$ AICHAT_LOG_LEVEL=debug aichat
```

#### 3. Session Management

When session issues occur:
```
# View session status
> .info session

# Clear problematic session
> .empty session

# Start fresh session
> .session new_session
```

### Customization and Advanced Usage

#### 1. Environment Variables

Users can customize behavior:
```bash
# Logging level
export AICHAT_LOG_LEVEL=debug

# Custom configuration directory
export AICHAT_CONFIG_DIR=/path/to/config

# Platform selection
export AICHAT_PLATFORM=openai

# Model selection
export AICHAT_MODEL=gpt-4
```

#### 2. Custom Prompts

Creating custom prompts:
```yaml
# my_prompt.yaml
instructions: |
  Custom instructions here
  
variables:
  - name: CUSTOM_VAR
    description: "Custom variable"
    default: "default_value"
```

Using custom prompts:
```bash
aichat --prompt my_prompt.yaml
```

#### 3. Integration with Other Tools

Shell integration:
```bash
# Bash integration
echo 'bind -x "\ee": _aichat_bash' >> ~/.bashrc

# Fish integration
function _aichat_fish
    set -l _old (commandline)
    commandline -r (aichat -e $_old)
end
bind \ee _aichat_fish
```

### Best Practices for Users

1. Session Management:
   - Start new sessions for different contexts
   - Regularly compress long sessions
   - Save important sessions for later use
   - Clear sessions when switching topics

2. Document Handling:
   - Organize related documents in directories
   - Use appropriate file formats
   - Verify document loading succeeded
   - Consider document size limits

3. Tool Usage:
   - Check tool availability before use
   - Verify tool permissions
   - Use appropriate error handling
   - Monitor tool execution time

4. Performance Optimization:
   - Use appropriate models for tasks
   - Manage token usage
   - Compress sessions when needed
   - Clear unnecessary context

### Additional Resources

Users should be aware of available help:

1. Built-in Help:
```bash
# Command help
aichat --help

# REPL help
> .help
```

2. Documentation Access:
```bash
# View local configuration
> .info

# List available models
> .list-models

# List available roles
> .list-roles

# List available agents
> .list-agents
```

3. Online Resources:
- AIChat Wiki: https://github.com/sigoden/aichat/wiki
- Issue Tracker: https://github.com/sigoden/aichat/issues
- Discussion Forum: https://github.com/sigoden/aichat/discussions

### Keeping Up to Date

Stay current with AIChat:
```bash
# Check version
aichat --version

# Update installation
cargo install aichat --force

# View release notes
https://github.com/sigoden/aichat/releases
```

This comprehensive user guide should help bridge the gap between technical implementation details and practical usage, making the agent system more accessible to end users.