# AIChat Lesson 4: Comprehensive REPL User Guide

## File Operations and Input Handling

### Working with Files

The `.file` command in AIChat provides versatile file handling capabilities:

1. Basic file processing:
```bash
> .file data.txt
```

2. Multiple files with query:
```bash
> .file document1.pdf document2.txt -- What are the common themes?
```

3. Directory processing:
```bash
> .file /project_dir/ -- Analyze this codebase
```

4. URL handling:
```bash
> .file https://example.com/doc.md -- Summarize this
```

### Supported File Types and Loaders

AIChat can process various file types through configured document loaders:

```yaml
document_loaders:
  pdf: 'pdftotext $1 -'
  docx: 'pandoc --to plain $1'
  odt: 'pandoc --to plain $1'
```

Common supported formats:
- Plain text (.txt, .md, .rst)
- Documents (.pdf, .docx, .odt)
- Source code files
- Images (with vision-capable models)
- Web pages and URLs

## Interactive Features

### Response Management

AIChat offers several ways to manage AI responses:

1. Continuing truncated responses:
```bash
> .continue
```

2. Regenerating responses:
```bash
> .regenerate
```

3. Copying responses:
```bash
> .copy
✓ Copied to clipboard
```

### Shell Integration Features

When using shell integration:

1. Command generation:
```bash
> find all pdf files modified in last week
find . -name "*.pdf" -mtime -7

Options:
[e]xecute
[r]evise
[d]escribe
[c]opy
[q]uit

Your choice: e
```

2. Command explanation:
```bash
> describe
find . -name "*.pdf" -mtime -7

This command:
- Searches current directory (.)
- For files ending in .pdf
- Modified in the last 7 days
```

3. Command revision:
```bash
Your revision: change to search in Documents folder
> find ~/Documents -name "*.pdf" -mtime -7
```

## Advanced Configuration

### Model Settings

Fine-tune model behavior:

```bash
> .set temperature 0.7
> .set top_p 0.9
> .set max_output_tokens 2000
> .set stream true
```

View current settings:
```bash
> .info
Model: openai:gpt-4o
Temperature: 0.7
Stream: true
Save: true
...
```

### Session Management

Detailed session control:

1. Create/join named session:
```bash
> .session mysession
mysession) 
```

2. View session info:
```bash
> .info session
Session: mysession
Messages: 15
Tokens: 1843 (18%)
Created: 2024-03-15T10:30:00
```

3. Session compression:
```bash
> .compress session
Compressing...
✓ Session compressed (1843 -> 920 tokens)
```

## RAG System Usage

### Document Management

1. Initialize RAG:
```bash
> .rag mydocs
```

2. Add documents:
```bash
> Add documents: /path/to/docs/**/*.{md,txt}
Loading file1.md [1/3]
Loading file2.txt [2/3]
Loading file3.md [3/3]
✨ Documents loaded successfully
```

3. View sources:
```bash
> .sources rag
Latest sources:
1. docs/file1.md (relevance: 0.89)
2. docs/file2.txt (relevance: 0.75)
```

### RAG Operations

1. Rebuild index:
```bash
> .rebuild rag
Rebuilding index...
✓ Index rebuilt successfully
```

2. View RAG info:
```bash
> .info rag
Name: mydocs
Documents: 23
Chunks: 67
Embeddings: text-embedding-3-small
Reranker: cohere-rerank-2
```

## Role System

### Role Management

1. Create/switch roles:
```bash
> .role coder
```

2. Temporary role usage:
```bash
> .role translator Tell me how to say "hello" in French
```

3. View role info:
```bash
> .info role
Role: coder
Template: System prompt for coding assistance
Model: openai:gpt-4o
```

### Built-in Roles

1. Code generation:
```bash
> .role %code%
```

2. Shell commands:
```bash
> .role %shell%
```

3. Explanation mode:
```bash
> .role %explain-shell%
```

## Function Calling and Tools

### Tool Usage

1. Enable tools:
```bash
> .set use_tools fs,web_search
```

2. Tool interactions:
```bash
> Show me the contents of config.yaml
Using fs_cat...
[contents displayed]
```

### Agent Integration

1. Start agent:
```bash
> .agent todo-sh
```

2. Agent variables:
```bash
> .variable TODOFILE ~/todo.txt
```

## Keyboard Shortcuts and Navigation

### Essential Shortcuts

1. Editing:
- Ctrl+A: Start of line
- Ctrl+E: End of line
- Ctrl+W: Delete word
- Ctrl+U: Clear line
- Ctrl+L: Clear screen

2. History:
- Up/Down: Navigate history
- Ctrl+R: Search history
- Ctrl+S: Forward search

3. Multi-line:
- Ctrl+O: Open editor
- Ctrl+Enter: New line
- Shift+Enter: New line
- Alt+Enter: New line

### Special Commands

1. Control:
- Ctrl+C: Cancel operation
- Ctrl+D: Exit REPL
- Tab: Completion

## Troubleshooting Guide

### Common Issues

1. Connection Problems:
```
Error: Failed to connect to API
- Check API keys
- Verify network connection
- Check proxy settings
```

2. Rate Limits:
```
Error: Rate limit exceeded
- Wait before retry
- Switch to different model
- Use session compression
```

3. Context Length:
```
Error: Maximum context length exceeded
- Use .compress session
- Start new session
- Split large inputs
```

## Best Practices

1. Session Management:
- Use descriptive session names
- Compress long sessions
- Save important sessions

2. Role Usage:
- Create task-specific roles
- Document custom roles
- Use temporary roles for one-offs

3. RAG Efficiency:
- Organize documents by topic
- Update index when needed
- Use specific queries

4. Tool Integration:
- Enable only needed tools
- Check tool output
- Handle errors gracefully

## Security Considerations

1. File Access:
- Verify file permissions
- Use absolute paths
- Check file contents

2. API Keys:
- Use environment variables
- Rotate keys regularly
- Check key permissions

3. Tool Execution:
- Review commands before execution
- Use dry-run mode
- Limit tool access

## Conclusion

This comprehensive guide covers the practical aspects of using AIChat's REPL interface that might not be immediately apparent from the help documentation. Understanding these features and patterns will help you make the most of AIChat's capabilities while avoiding common pitfalls.

Remember that the REPL interface is constantly evolving, and new features are added regularly. Keep an eye on the official documentation and use the `.help` command to discover new functionality as it becomes available.