# AIChat Features and Usage Guide

AIChat is a versatile command-line tool that provides various ways to interact with Large Language Models. This guide covers its key features and usage patterns.

## Core Features

### Chat REPL

The Chat REPL (Read-Eval-Print Loop) is the primary interface for interacting with AIChat. It provides an interactive environment with several advanced features:

The REPL includes sophisticated features like:
- Tab completion for commands and options
- Multi-line input support with several input methods:
  - External editor access via Ctrl+O
  - Multi-line paste support
  - Triple colon (:::) delimited input
  - Special key combinations for newlines
- History search with Ctrl+R
- Customizable key bindings (Emacs and VI styles)
- Customizable prompt display

REPL commands are accessed using a dot prefix:
```
.help                    # Show help message
.model                   # Change the current LLM
.prompt                  # Create a temporary role
.role                    # Create/switch roles
.session                 # Begin a session
.rag                     # Initialize/use RAG
.agent                   # Use an AI agent
.file                    # Include files with messages
```

### RAG (Retrieval Augmented Generation)

The RAG system enhances LLM responses by incorporating knowledge from local documents. It features:

1. Document Processing:
   - Support for multiple document formats (MD, PDF, DOCX, etc.)
   - Automatic text chunking with configurable sizes
   - Embedding generation for semantic search
   - Support for both vector and keyword search

2. Configuration Options:
   ```yaml
   rag_embedding_model: null        # Embedding model
   rag_reranker_model: null        # Reranking model
   rag_top_k: 4                    # Number of documents to retrieve
   rag_chunk_size: null            # Chunk size for splitting
   rag_chunk_overlap: null         # Overlap between chunks
   ```

3. Usage Examples:
   ```bash
   # Initialize RAG with documents
   .rag
   > Add documents: /path/to/docs/

   # Query with RAG context
   What information is in the documentation?
   ```

### Function Calling

AIChat supports function calling to integrate with external tools and systems:

1. Configuration:
   ```yaml
   function_calling: true           # Enable function calling
   mapping_tools:                   # Tool groupings
     fs: 'fs_cat,fs_ls,fs_mkdir,fs_rm,fs_write'
   use_tools: null                  # Default tools to use
   ```

2. Tool Integration:
   - File system operations
   - Web searches
   - Shell command execution
   - Custom tool integration

### Shell Integration

AIChat provides deep shell integration capabilities:

1. Shell Assistant:
   ```bash
   # Execute commands using natural language
   aichat -e "create a new directory called project"
   ```

2. Integration Scripts:
   - Support for multiple shells (bash, zsh, fish, powershell)
   - Command completion
   - History integration
   - Custom key bindings

### Web Interface

AIChat includes a built-in web server with two main interfaces:

1. Playground:
   - Interactive chat interface
   - Model selection
   - Configuration adjustment
   - Response streaming

2. Arena:
   - Side-by-side model comparison
   - Concurrent model evaluation
   - Response analysis

To start the web interface:
```bash
aichat --serve [address:port]
```

## Configuration Management

### Configuration File Locations

The configuration files are stored in user-specific locations:
- Windows: `C:\Users\<user>\AppData\Roaming\aichat\config.yaml`
- macOS: `/Users/<user>/Library/Application Support/aichat/config.yaml`
- Linux: `/home/<user>/.config/aichat/config.yaml`

### Environment Variables

Configuration can be overridden using environment variables:
```bash
AICHAT_MODEL="openai:gpt-4"        # Set default model
AICHAT_TEMPERATURE=0.7             # Set temperature
AICHAT_STREAM=false                # Disable streaming
```

### Role Management

Roles allow customizing LLM behavior:

1. Role Definition:
   ```yaml
   ---
   model: openai:gpt-4
   temperature: 0.7
   top_p: 0.9
   ---
   Your role instructions here...
   ```

2. Role Usage:
   ```bash
   aichat -r coder "Write a Python function"
   ```

### Session Management

Sessions maintain conversation context:

1. Session Commands:
   ```bash
   .session                 # Start session
   .empty session          # Clear session
   .compress session       # Compress history
   .exit session          # End session
   ```

2. Session Configuration:
   ```yaml
   save_session: null
   compress_threshold: 4000
   summarize_prompt: '...'
   ```

## Advanced Features

### Custom Themes

AIChat supports custom syntax highlighting themes:
1. Download a .tmTheme file
2. Place in config directory as dark.tmTheme/light.tmTheme
3. Restart AIChat

### Custom REPL Prompt

The REPL prompt can be customized:
```yaml
left_prompt: '{color.green}{session}{?role /}{role}{color.cyan}>'
right_prompt: '{color.purple}{consume_tokens}'
```

### Document Loaders

Configure custom document loaders:
```yaml
document_loaders:
  pdf: 'pdftotext $1 -'
  docx: 'pandoc --to plain $1'
```

## Best Practices

1. Session Management:
   - Use sessions for related conversations
   - Compress long sessions regularly
   - Save important sessions

2. RAG Usage:
   - Chunk documents appropriately
   - Use reranking for better results
   - Monitor token usage

3. Function Calling:
   - Group related tools
   - Use tool aliases
   - Handle errors gracefully

4. Shell Integration:
   - Install completion scripts
   - Use natural language for commands
   - Leverage the shell assistant

## Troubleshooting

1. Logging:
   ```bash
   AICHAT_LOG_LEVEL=debug aichat
   ```

2. Common Issues:
   - Configuration file locations
   - API key setup
   - Model availability
   - Function calling setup

3. Debug Tools:
   ```bash
   aichat --info                   # System information
   aichat --dry-run               # Test without execution
   ```