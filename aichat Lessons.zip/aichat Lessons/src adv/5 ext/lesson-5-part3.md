# AIChat Core Concepts and Advanced Topics

This section covers fundamental concepts and advanced topics that are essential for understanding AIChat's implementation and functionality but may not be immediately obvious from the code or basic documentation.

## Core Concepts

### Vector Embeddings

Vector embeddings are numerical representations of text that capture semantic meaning. In AIChat's RAG system, these are crucial for several reasons:

1. Embedding Generation:
   ```rust
   pub async fn create_embeddings(
       &self,
       data: EmbeddingsData,
       spinner: Option<Spinner>,
   ) -> Result<EmbeddingsOutput>
   ```
   
The embedding process converts text chunks into high-dimensional vectors (typically 768 to 1536 dimensions) using specialized models. These vectors capture semantic relationships between different pieces of text, allowing for meaningful similarity comparisons.

### HNSW Index

Hierarchical Navigable Small World (HNSW) is an algorithm for approximate nearest neighbor search, implemented in AIChat as:

```rust
pub struct Rag {
    hnsw: Hnsw<'static, f32, DistCosine>,
    // ...
}
```

HNSW creates a multi-layer graph structure that enables:
- Fast approximate nearest neighbor search
- Efficient vector similarity calculations
- Scalable performance with large document collections

The algorithm maintains multiple layers of connections between vectors, with higher layers serving as highways for quick navigation during search.

### BM25 Algorithm

BM25 (Best Matching 25) is a ranking function used for keyword-based search:

```rust
bm25: SearchEngine<DocumentId>,
```

This algorithm improves upon simple keyword matching by:
1. Term Frequency Normalization: Prevents bias towards longer documents
2. Inverse Document Frequency: Gives higher weight to rare terms
3. Length Normalization: Accounts for document length variations

### Reciprocal Rank Fusion

RRF is a method for combining results from different search approaches:

```rust
fn reciprocal_rank_fusion(
    list_of_document_ids: Vec<Vec<DocumentId>>,
    list_of_weights: Vec<f32>,
    top_k: usize,
) -> Vec<DocumentId>
```

The algorithm:
1. Takes ranked lists from different search methods
2. Assigns scores based on rank position
3. Combines scores with configurable weights
4. Produces a final unified ranking

## Advanced Topics

### Token Management

Token management is crucial for effective LLM interaction:

```rust
pub fn estimate_token_length(text: &str) -> usize {
    let words: Vec<&str> = text.unicode_words().collect();
    let mut output: f32 = 0.0;
    for word in words {
        if word.is_ascii() {
            output += 1.3;
        } else {
            let count = word.chars().count();
            if count == 1 {
                output += 1.0
            } else {
                output += (count as f32) * 0.5;
            }
        }
    }
    output.ceil() as usize
}
```

Understanding token management involves:
1. Token Estimation: Approximating token counts before API calls
2. Context Window Management: Tracking available context space
3. Token Budgeting: Allocating tokens between prompt and response
4. Compression Strategies: Managing long conversations

### Language-Aware Text Splitting

The text splitting system accounts for different language characteristics:

```rust
pub enum Language {
    Cpp,
    Go,
    Java,
    Js,
    Php,
    Proto,
    Python,
    Rst,
    Ruby,
    Rust,
    Scala,
    Swift,
    Markdown,
    Latex,
    Html,
    Sol,
}
```

Each language has specific splitting rules based on:
1. Syntax Structure: Understanding code blocks and documentation
2. Semantic Boundaries: Preserving meaning in splits
3. Language Features: Handling language-specific constructs

### Concurrent Processing

AIChat implements concurrent processing for efficiency:

```rust
pub async fn sync_documents<T: AsRef<str>>(
    &mut self,
    loaders: HashMap<String, String>,
    paths: &[T],
    spinner: Option<Spinner>,
) -> Result<()>
```

Key concurrency concepts include:
1. Tokio Runtime: Async execution environment
2. Resource Management: Semaphore-based concurrency control
3. Task Coordination: Managing multiple concurrent operations

### Error Recovery and Resilience

The system implements robust error handling:

```rust
pub struct RagFile {
    hash: String,
    path: String,
    documents: Vec<RagDocument>,
}
```

Error handling strategies include:
1. Document Validation: Checking file integrity
2. Incremental Processing: Handling partial failures
3. State Recovery: Maintaining system state during errors

## Implementation Details

### Vector Serialization

Vector data is efficiently serialized using base64 encoding:

```rust
pub fn serialize<S>(
    vectors: &IndexMap<DocumentId, Vec<f32>>,
    serializer: S,
) -> Result<S::Ok, S::Error>
where
    S: Serializer
```

This approach:
1. Reduces Storage Size: Efficient binary representation
2. Maintains Precision: Preserves floating-point accuracy
3. Enables Fast Loading: Quick deserialization

### Cross-Platform Path Handling

Path handling accommodates different operating systems:

```rust
pub fn safe_join_path<T1: AsRef<Path>, T2: AsRef<Path>>(
    base_path: T1,
    sub_path: T2,
) -> Option<PathBuf>
```

Considerations include:
1. Path Separators: Windows vs Unix-style paths
2. Security: Preventing path traversal attacks
3. Unicode Support: Handling non-ASCII paths

### Memory Management

Efficient memory handling is crucial for large document collections:

```rust
pub struct RagData {
    pub vectors: IndexMap<DocumentId, Vec<f32>>,
    // ...
}
```

Key aspects include:
1. Chunked Processing: Processing documents in manageable sizes
2. Memory Mapping: Efficient vector storage
3. Resource Cleanup: Proper deallocation

## Advanced Configuration

### Custom Document Processors

Document processors can be customized:

```yaml
document_loaders:
  pdf: 'pdftotext $1 -'
  docx: 'pandoc --to plain $1'
  custom: './my-processor $1 $2'
```

Implementation considerations:
1. Input/Output Handling: Processing binary and text formats
2. Error Reporting: Providing meaningful error messages
3. Performance: Optimizing processing speed

### Reranker Configuration

The reranking system can be fine-tuned:

```yaml
rag_reranker_model: "custom-reranker"
rag_top_k: 5
```

Reranking aspects:
1. Model Selection: Choosing appropriate reranking models
2. Score Calibration: Adjusting relevance thresholds
3. Performance Tuning: Balancing accuracy and speed

### Vector Search Parameters

Vector search can be optimized:

```yaml
rag_min_score_vector_search: 0.7
rag_min_score_keyword_search: 0.5
```

Configuration aspects:
1. Similarity Thresholds: Setting minimum match scores
2. Result Count: Adjusting number of retrieved documents
3. Search Balance: Weighting different search methods

## Performance Optimization

### Batch Processing

Batch processing improves efficiency:

```rust
let batch_size = self
    .data
    .batch_size
    .or_else(|| self.embedding_model.max_batch_size());
```

Optimization strategies:
1. Batch Size Tuning: Finding optimal batch sizes
2. Memory Usage: Managing memory during batch operations
3. Concurrent Processing: Parallel batch execution

### Search Optimization

Search performance can be improved:

```rust
async fn hybird_search(
    &self,
    query: &str,
    top_k: usize,
    min_score_vector_search: f32,
    min_score_keyword_search: f32,
    rerank_model: Option<&str>,
) -> Result<Vec<(DocumentId, String)>>
```

Optimization areas:
1. Index Structure: Tuning HNSW parameters
2. Search Parameters: Adjusting search thresholds
3. Caching: Implementing result caching

### Resource Management

Effective resource management is essential:

```rust
pub struct Rag {
    config: GlobalConfig,
    embedding_model: Model,
    hnsw: Hnsw<'static, f32, DistCosine>,
    bm25: SearchEngine<DocumentId>,
    // ...
}
```

Management strategies:
1. Resource Pooling: Sharing expensive resources
2. Connection Management: Handling API connections
3. Memory Limits: Setting resource boundaries