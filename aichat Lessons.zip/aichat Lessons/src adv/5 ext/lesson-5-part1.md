# AIChat: Project Structure and Code Organization

AIChat is a sophisticated command-line interface tool designed to integrate with multiple Large Language Models (LLMs). The project follows a well-organized structure with clear separation of concerns. Let's explore its organization and key components.

## Project Layout

The project follows a standard Rust project structure with the following main directories:

```
/
├── src/                    # Main source code directory
│   ├── cli.rs             # CLI argument parsing and handling
│   ├── function.rs        # Function calling implementation
│   ├── main.rs            # Application entry point
│   ├── serve.rs           # HTTP server implementation
│   ├── client/            # LLM client implementations
│   │   ├── access_token.rs
│   │   ├── azure_openai.rs
│   │   ├── bedrock.rs
│   │   ├── claude.rs
│   │   ├── cohere.rs
│   │   └── ...
│   ├── config/            # Configuration handling
│   │   ├── agent.rs
│   │   ├── input.rs
│   │   ├── mod.rs
│   │   ├── role.rs
│   │   └── session.rs
│   ├── rag/               # RAG (Retrieval Augmented Generation) implementation
│   │   ├── loader.rs
│   │   ├── mod.rs
│   │   ├── serde_vectors.rs
│   │   └── splitter/
│   ├── render/           # Output rendering
│   ├── repl/            # REPL implementation
│   └── utils/           # Utility functions
├── assets/              # Static assets and role templates
│   ├── arena.html
│   ├── playground.html
│   └── roles/
├── scripts/            # Shell integration scripts
│   ├── completions/
│   └── shell-integration/
└── .github/           # GitHub configuration files
```

## Core Components

### 1. Client Layer (src/client/)

The client layer handles communication with various LLM providers. Each provider has its own implementation file (e.g., claude.rs, openai.rs) that implements the necessary traits for interacting with the respective APIs. This modular approach makes it easy to add support for new providers.

### 2. Configuration Management (src/config/)

Configuration management is handled through several modules:
- agent.rs: Manages AI agent configurations
- input.rs: Handles user input processing
- role.rs: Manages role definitions and behaviors
- session.rs: Handles chat session management

The configuration system supports both YAML files and environment variables, making it flexible for different deployment scenarios.

### 3. RAG Implementation (src/rag/)

The RAG system provides document retrieval and context augmentation:
- loader.rs: Handles document loading from various sources
- splitter/: Contains text splitting logic for chunking documents
- serde_vectors.rs: Handles serialization of vector data

### 4. Core Functions

#### Main Entry Point (main.rs)
The main.rs file serves as the entry point and coordinates between different components. It handles:
- Command line argument parsing
- Configuration loading
- Server initialization
- REPL startup
- Error handling

#### Function Calling (function.rs)
Implements the function calling system that allows AIChat to:
- Execute shell commands
- Handle file operations
- Integrate with external tools
- Manage tool execution context

#### Server Implementation (serve.rs)
Provides an HTTP server that:
- Exposes chat completion API endpoints
- Serves the web playground interface
- Handles API authentication
- Manages streaming responses

## Utility Modules

The utils/ directory contains various helper functions and utilities:
- abort_signal.rs: Handles graceful shutdowns and interrupts
- clipboard.rs: Manages clipboard operations
- command.rs: Handles shell command execution
- crypto.rs: Provides cryptographic functions
- html_to_md.rs: Converts HTML to Markdown
- path.rs: Handles file path operations
- spinner.rs: Implements terminal progress indicators

## Shell Integration

The scripts/ directory contains shell integration files that enable:
- Command completion in various shells
- Shell integration for easier interaction
- PowerShell, Bash, Zsh, and Fish support

## Assets

The assets/ directory contains:
- HTML templates for the web interface
- Role definitions
- Default configurations
- Web playground interface
- Arena comparison interface

## Build Configuration

The project uses Cargo for build management with the following key dependencies:
- tokio: For async runtime
- clap: For command line argument parsing
- serde: For serialization/deserialization
- reqwest: For HTTP client functionality
- hyper: For HTTP server implementation

The build configuration supports cross-platform compilation with specific optimizations for different operating systems.

## Testing Infrastructure

The project includes a comprehensive testing setup:
- Unit tests within individual modules
- Integration tests for key features
- Test utilities for mocking LLM responses
- GitHub Actions CI configuration

## Configuration Files

The configuration system supports multiple files:
- config.yaml: Main configuration file
- config.agent.example.yaml: Example agent configuration
- .env: Environment variable configuration
- Role-specific configuration files in the roles directory