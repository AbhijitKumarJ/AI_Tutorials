# Lesson 5: Understanding AIChat's RAG System - Part 4
## Comprehensive End User Guide

This part focuses on the practical usage of AIChat's RAG system from an end user's perspective, covering detailed workflows, commands, and common scenarios that weren't fully explained in previous parts.

## Getting Started with RAG

### Initial Setup

Before using RAG, ensure your configuration file (`config.yaml`) has the necessary settings:

```yaml
rag_embedding_model: null        # Will prompt if not specified
rag_reranker_model: null        # Optional reranker for better results
rag_top_k: 4                    # Number of documents to retrieve
document_loaders:               # Configure document loaders
  pdf: 'pdftotext $1 -'        # PDF loader using pdftotext
  docx: 'pandoc --to plain $1' # DOCX loader using pandoc
```

### First Time RAG Usage

1. Starting a New RAG Session:
```bash
> .rag
⚙ Initializing RAG...
```

2. Model Selection Dialog:
```
Select embedding model: [Use arrow keys to select]
> text-embedding-3-small
  text-embedding-3-large
  [other available models...]
```

3. Document Loading Options:
```
Add documents: [Enter paths or URLs]
Examples:
- Single file: /path/to/document.pdf
- Multiple files: file1.md;file2.txt
- Directory: /path/to/docs/
- Website: https://docs.example.com/
- Multiple sources: local/docs/;https://api.docs.com/
```

## Working with Documents

### Supported Document Types and Formats

1. Direct Support:
- Markdown (.md)
- Plain text (.txt)
- Source code files
- HTML web pages

2. With Document Loaders:
- PDF files (.pdf)
- Word documents (.docx)
- HTML files (.html)
- Other formats with custom loaders

### Adding Documents

1. Single Document:
```bash
> Add documents: /path/to/document.pdf
Loading /path/to/document.pdf [1/1]
✨ Document loaded successfully
```

2. Multiple Documents:
```bash
> Add documents: doc1.md;doc2.pdf;doc3.txt
Loading doc1.md [1/3]
Loading doc2.pdf [2/3]
Loading doc3.txt [3/3]
✨ All documents loaded successfully
```

3. Directory with Pattern:
```bash
> Add documents: /docs/**/*.{md,txt}
🚀 Scanning directory...
✨ Found 15 matching files
Loading files...
```

4. Website Content:
```bash
> Add documents: https://docs.example.com/**
⚙ maxConnections=5 exclude='' extract='' toMarkdown=true
🚀 Crawling https://docs.example.com/
✨ Crawl completed
```

## Using RAG in Conversations

### Basic Query Patterns

1. Simple Queries:
```bash
> What is feature X?
Searching knowledge base...
Based on the documents: [Response based on retrieved content]
```

2. Follow-up Questions:
```bash
> Can you explain more about its configuration?
Searching knowledge base...
According to the documentation: [Contextual response]
```

3. Viewing Sources:
```bash
> .sources rag
Retrieved from:
- docs/features.md (chunks 2,3)
- config/examples.md (chunk 1)
```

### Advanced Usage Patterns

1. With Different Roles:
```bash
> .role technical
> .rag documentation
Now using RAG with technical role...
```

2. In Sessions:
```bash
> .session coding
> .rag api_docs
Session will maintain context across queries...
```

## RAG Management Commands

### Essential Commands

1. Viewing RAG Information:
```bash
> .info rag
RAG Details:
- Name: documentation
- Embedding Model: text-embedding-3-small
- Documents: 25
- Chunks: 150
- Last Updated: 2024-01-15
```

2. Rebuilding RAG:
```bash
> .rebuild rag
Rebuilding index...
✨ RAG rebuilt successfully
```

3. Listing Available RAGs:
```bash
> .list-rags
Available RAGs:
- documentation
- api_docs
- tutorials
```

4. Switching RAGs:
```bash
> .rag api_docs
Switching to api_docs RAG...
Ready for queries
```

### Configuration Commands

1. Setting Top-K Results:
```bash
> .set rag_top_k 5
Updated number of results to return
```

2. Changing Reranker:
```bash
> .set rag_reranker_model cohere/rerank-english-v2.0
Updated reranker model
```

## Troubleshooting Common Issues

### Document Loading Issues

1. Unsupported Format:
```bash
> Add documents: file.unsupported
Error: No loader configured for .unsupported files
Solution: Add appropriate loader in config.yaml
```

2. Access Issues:
```bash
> Add documents: /restricted/doc.pdf
Error: Permission denied
Solution: Check file permissions
```

### Query Issues

1. No Results:
```bash
> What about feature Y?
No relevant information found in the knowledge base
Consider:
- Adding relevant documents
- Rephrasing the question
- Checking document processing
```

2. Irrelevant Results:
```bash
Solutions:
1. Adjust rag_top_k value
2. Enable reranking
3. Rebuild RAG index
4. Review document chunks
```

## Best Practices for Users

### Document Organization

1. Structure Your Knowledge Base:
```
docs/
├── api/          # API documentation
├── guides/       # User guides
├── tutorials/    # Tutorials
└── reference/    # Reference materials
```

2. File Naming Conventions:
```
YYYY-MM-DD-topic-name.md    # For dated content
feature-name-v1.0.md        # For versioned content
category-subcategory.md     # For categorized content
```

### Query Optimization

1. Effective Queries:
```bash
# Good queries
> What is the configuration syntax for feature X?
> How do I implement Y in version 2.0?

# Less effective queries
> Tell me everything
> What about X?
```

2. Using Context:
```bash
# Provide specific context
> In version 2.0, how does feature X differ from version 1.0?

# Build on previous queries
> What are the prerequisites for this feature?
> How do I install those prerequisites?
```

## Advanced Features

### Custom Document Processing

1. Adding Custom Loaders:
```yaml
document_loaders:
  custom: 'python /scripts/custom_loader.py $1'
```

2. Web Crawling Options:
```bash
> Add documents: https://docs.example.com/**
Options:
  --exclude=changelog,license
  --depth=3
  --follow-links=true
```

### Integration with AIChat Features

1. Combining with Functions:
```bash
> .role %functions%
> .rag documentation
Now RAG can use function calling with documentation...
```

2. Using with Agents:
```bash
> .agent dev_assistant
> .rag codebase
Agent can now reference codebase documentation...
```

## Performance Tips

### Optimizing RAG Usage

1. Document Size Management:
- Keep individual documents focused
- Use appropriate chunk sizes
- Balance between detail and searchability

2. Query Performance:
- Be specific in questions
- Use appropriate terminology
- Build context progressively

### Resource Considerations

1. Memory Usage:
- Monitor document count
- Use appropriate embedding models
- Consider chunking parameters

2. Response Time:
- Optimize number of documents
- Use appropriate top_k values
- Consider using reranking selectively

This comprehensive guide should help users effectively utilize AIChat's RAG capabilities. Remember that RAG is a powerful tool that becomes more effective with well-organized documents and thoughtful querying strategies.
