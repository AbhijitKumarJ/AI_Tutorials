# AIChat Lesson 8: Utility Functions and Helper Systems
## Part 7: End-User Guide and Usage Details

This section covers AIChat's utility functions from an end-user perspective, explaining configuration options, commands, and features that were previously assumed to be understood.

### Terminal Usage Basics

#### 1. Command-Line Interface

The basic command structure for AIChat:

```bash
# Basic usage
aichat [OPTIONS] [TEXT]...

# Common options
-m, --model <MODEL>        # Select a specific LLM model
-r, --role <ROLE>          # Select a role
-s, --session [<SESSION>]  # Start or join a session
-e, --execute             # Execute commands in natural language
-c, --code                # Output code only
-f, --file <FILE>         # Include files with message
```

Key usage patterns:
```bash
# Start interactive REPL
aichat

# Direct query
aichat "What is the weather in London?"

# Execute shell commands
aichat -e "create a backup of my documents folder"

# Generate code
aichat -c "write a python function to calculate fibonacci numbers"

# Use with files
aichat -f data.csv "analyze this data"
```

#### 2. REPL Navigation

Essential REPL keyboard shortcuts and commands:

```
Navigation Commands:
Ctrl+A          Move cursor to start of line
Ctrl+E          Move cursor to end of line
Ctrl+B/←        Move cursor back one character
Ctrl+F/→        Move cursor forward one character
Alt+B           Move cursor back one word
Alt+F           Move cursor forward one word

Editing Commands:
Ctrl+K          Cut text from cursor to end of line
Ctrl+U          Cut text from start of line to cursor
Ctrl+W          Cut previous word
Ctrl+Y          Paste previously cut text
Ctrl+_          Undo
Tab             Auto-complete command or path

Special Commands:
Ctrl+C          Cancel current operation
Ctrl+D          Exit REPL
Ctrl+L          Clear screen
```

### Configuration Settings

#### 1. User Configuration File

The configuration file location varies by platform:
```bash
# Windows
C:\Users\<username>\AppData\Roaming\aichat\config.yaml

# macOS
/Users/<username>/Library/Application Support/aichat/config.yaml

# Linux
/home/<username>/.config/aichat/config.yaml
```

Essential configuration settings:
```yaml
# Core Settings
model: openai:gpt-4o             # Default LLM model
temperature: null                # Temperature parameter (0-2)
top_p: null                      # Top-p parameter (0-1)

# Behavior Settings
stream: true                     # Enable/disable streaming output
save: true                       # Auto-save conversations
keybindings: emacs              # Keybinding style (emacs/vi)
wrap: no                        # Text wrapping (no/auto/<width>)
wrap_code: false                # Code block wrapping

# Display Settings
highlight: true                 # Syntax highlighting
light_theme: false              # Light/dark theme

# Session Settings
save_session: null              # Session auto-save behavior
compress_threshold: 4000        # Session compression threshold

# RAG Settings
rag_embedding_model: null       # Embedding model for RAG
rag_top_k: 4                    # Number of documents to retrieve
```

#### 2. Environment Variables

Important environment variables for customization:
```bash
# Core Settings
export AICHAT_MODEL="openai:gpt-4o"    # Set default model
export AICHAT_TEMPERATURE="0.7"         # Set temperature
export AICHAT_STREAM="false"            # Disable streaming

# Path Settings
export AICHAT_CONFIG_DIR="/custom/path" # Custom config directory
export AICHAT_LOG_LEVEL="debug"         # Set log level

# Proxy Settings
export HTTPS_PROXY="http://proxy:8080"  # Set HTTPS proxy
export ALL_PROXY="socks5://proxy:1080"  # Set SOCKS proxy
```

### Feature Usage Details

#### 1. File Operations

Working with files in AIChat:
```bash
# Single file analysis
aichat -f data.csv "summarize this data"

# Multiple file comparison
aichat -f file1.txt -f file2.txt "compare these files"

# Directory analysis
aichat -f ./project/ "analyze this codebase"

# URL content analysis
aichat -f https://example.com/doc.pdf "summarize this document"
```

File operation features:
- Automatic file type detection
- Built-in format conversion
- Directory traversal
- URL content fetching
- Binary file handling

#### 2. RAG (Retrieval-Augmented Generation)

Using RAG features:
```bash
# Initialize RAG with documents
aichat -R myproject
> Add documents: /path/to/docs/**/*.md

# Query RAG
aichat -R myproject "what are the key features?"

# Update RAG
aichat -R myproject --rebuild
```

RAG capabilities:
- Multiple document formats
- Incremental updates
- Embedded search
- Relevance ranking
- Context-aware responses

#### 3. Role Management

Working with roles:
```bash
# List available roles
aichat --list-roles

# Use specific role
aichat -r coder "explain binary search"

# Create custom role
cat > ~/.config/aichat/roles/expert.md << EOL
---
model: openai:gpt-4o
temperature: 0.7
---
You are an expert in explaining complex topics...
EOL
```

Role features:
- Predefined roles
- Custom role creation
- Role-specific settings
- Role composition

#### 4. Session Management

Session operations:
```bash
# Start new session
aichat -s mysession

# List sessions
aichat --list-sessions

# Continue session
aichat -s mysession "continue our discussion"

# Clean session
aichat -s mysession --empty-session
```

Session features:
- Automatic context management
- Session compression
- History preservation
- Multi-session support

### Common Use Cases

#### 1. Code Generation and Analysis

```bash
# Generate code
aichat -c "create a REST API in Python"

# Code explanation
aichat -f src/ "explain this codebase"

# Code review
aichat -f pr.diff "review this PR"
```

#### 2. Shell Command Generation

```bash
# Basic command generation
aichat -e "find all PDF files modified in last week"

# Complex operations
aichat -e "backup MySQL database and compress the dump"

# System administration
aichat -e "show system resource usage in real-time"
```

#### 3. Document Analysis

```bash
# Single document analysis
aichat -f document.pdf "summarize key points"

# Multiple document comparison
aichat -f doc1.pdf -f doc2.pdf "compare these documents"

# Web content analysis
aichat -f https://example.com "extract main ideas"
```

### Troubleshooting

Common issues and solutions:

1. Configuration Issues
```bash
# Check configuration
aichat --info

# Reset configuration
rm ~/.config/aichat/config.yaml
aichat  # Will create new default config

# Debug mode
AICHAT_LOG_LEVEL=debug aichat
```

2. Permission Issues
```bash
# Fix config directory permissions
chmod 700 ~/.config/aichat
chmod 600 ~/.config/aichat/config.yaml

# Fix role directory permissions
chmod -R 700 ~/.config/aichat/roles/
```

3. Network Issues
```bash
# Test with proxy
HTTPS_PROXY=http://proxy:8080 aichat "test"

# Disable streaming
aichat -S "test without streaming"
```

4. Performance Optimization
```yaml
# config.yaml optimizations
compress_threshold: 2000        # Lower for faster responses
rag_top_k: 3                   # Reduce for faster RAG queries
stream: false                  # Disable for bulk operations
```

These usage details provide a comprehensive guide for end users to effectively utilize AIChat's utility functions and features. Understanding these aspects enables users to maximize the benefits of AIChat's capabilities while avoiding common pitfalls and configuration issues.