# Foundation Concepts and Additional User Guide Details

## Starting with AIChat

To enter the REPL environment, simply run AIChat without any arguments:
```bash
aichat
```

The REPL provides an interactive prompt where you can start conversing with your configured LLM. You'll see a prompt that looks like:
```
>
```

If you're using a role, session, or RAG, the prompt will reflect this:
```
coder>        # When using a role
mysession)    # When in a session 
rag@docs>     # When using RAG
```

## Key Usage Patterns

### Asking Questions

Simply type your question or prompt and press Enter. You can use multi-line input in several ways:

1. Using triple colon:
```
> :::
Write a poem about
coding in Rust
:::
```

2. Using Ctrl+O to open external editor
3. Shift+Enter for line breaks
4. Pasting multi-line text directly

### Managing Chat Flow

#### Session Management
Sessions maintain context between interactions:

1. Start a new session:
```
> .session mysession
```

2. View current session info:
```
> .info session
Name: mysession
Messages: 10
Token usage: 1205 (30.1%)
```

3. Save session state:
```
> .save session
```

#### Role Usage
Roles define specific behaviors for the LLM:

1. List available roles:
```
> .role
Available roles:
- coder
- translator
- shell
```

2. Use a role:
```
> .role coder
Now using role: coder
```

3. Temporary role use:
```
> .role translator Tell me how to say "hello" in French
```

### Document Integration

You can include documents in your conversations using the `.file` command:

1. Include a single file:
```
> .file document.pdf -- Summarize this
```

2. Include multiple files:
```
> .file doc1.md doc2.txt -- Compare these documents
```

3. Include directories:
```
> .file ./docs/ -- Analyze all documents in this directory
```

### Managing Model Settings

Adjust model behavior using the `.set` command:

1. Change temperature:
```
> .set temperature 0.7
```

2. Modify token limits:
```
> .set max_output_tokens 1000
```

3. Toggle streaming:
```
> .set stream false
```

## Special Features

### Image Support

For models that support vision capabilities:

1. Include images in conversation:
```
> .file image.jpg -- Describe this image
```

2. Multiple images:
```
> .file image1.png image2.png -- Compare these images
```

### Tool Integration

When using function calling:

1. Enable specific tools:
```
> .set use_tools web_search,fs
```

2. View available tools:
```
> .info tools
```

### Voice Features

If available in your terminal:

1. Text-to-Speech: Click the speaker icon or use system shortcuts
2. Speech-to-Text: Use system integrations if available

## Navigation and Editing

### History Navigation

1. Search history: Press Ctrl+R
2. Navigate history: Up/Down arrows
3. Clear current line: Ctrl+C

### Text Editing

1. Move by word: Alt+B (back), Alt+F (forward)
2. Delete word: Alt+D
3. Clear line: Ctrl+U
4. Paste: Ctrl+Y

### Completion Usage

1. Command completion: `.` + Tab
2. Model completion: `.model` + Tab
3. Role completion: `.role` + Tab
4. File completion: `.file` + Tab

## Visual Feedback

### Progress Indicators

The system shows different indicators:

```
⌛ Processing...  # During long operations
✓ Completed      # Success indicator
✗ Failed         # Error indicator
```

### Error Messages

Error messages provide context:
```
Error: No model selected
Error: Session not found: mysession
Error: File not accessible: /path/to/file
```

## Environment Integration

### Shell Integration

Access AIChat from your shell:

1. Bash/Zsh: Alt+E to process current line
2. Fish: Alt+E or custom binding
3. PowerShell: Alt+E or custom binding

### Custom Prompts

Customize your prompt display:
```yaml
left_prompt: '{color.green}{?session {session}{?role /}}{role}{color.cyan}{?session )}{!session >}{color.reset} '
right_prompt: '{color.purple}{?session {consume_tokens}({consume_percent}%)}{color.reset}'
```

## Common Configurations

### Configuration File Structure

```yaml
# Basic settings
model: openai:gpt-4
temperature: 0.7
stream: true

# Behavior settings
save: true
keybindings: emacs
wrap: no
```

### Environment Variables

Override settings with environment variables:
```bash
export AICHAT_MODEL=gpt-4
export AICHAT_TEMPERATURE=0.8
export AICHAT_STREAM=false
```

## Troubleshooting Tips

### Common Issues and Solutions

1. Connection Problems:
```
Error: Failed to connect to API
Solution: Check internet connection and API key
```

2. Token Limits:
```
Error: Input too long
Solution: Use session compression or split input
```

3. File Access:
```
Error: Permission denied
Solution: Check file permissions and paths
```

4. Model Issues:
```
Error: Model not available
Solution: Verify model name and availability
```

### Debug Mode

Enable debug logging:
```bash
export AICHAT_LOG_LEVEL=debug
```

Check logs at:
```bash
~/.config/aichat/aichat.log   # Unix systems
%APPDATA%/aichat/aichat.log   # Windows
```

## Best User Practices

1. Session Management:
   - Use sessions for related conversations
   - Save sessions regularly
   - Use compression for long sessions

2. Role Usage:
   - Choose appropriate roles for tasks
   - Create custom roles for repeated tasks
   - Use temporary roles for one-off needs

3. Document Handling:
   - Break large documents into manageable chunks
   - Use appropriate file formats
   - Verify document accessibility

4. Configuration:
   - Keep configuration backed up
   - Use environment variables for temporary changes
   - Document custom configurations

## Additional Resources

1. Configuration Examples:
   - Basic configuration templates
   - Advanced configuration examples
   - Platform-specific settings

2. Shell Integration:
   - Installation guides
   - Custom key binding examples
   - Shell-specific features

3. Documentation Links:
   - Full command reference
   - Model capabilities guide
   - Troubleshooting guide

This comprehensive guide covers the fundamental concepts and additional details that might have been assumed or left out in the previous parts of the lesson. It provides a user-centric view of AIChat's REPL functionality and should help users make the most of the system's capabilities.

Remember that AIChat is regularly updated, so some features might change or new ones might be added. Always refer to the official documentation for the most up-to-date information.