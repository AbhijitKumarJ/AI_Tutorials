# AIChat HTTP Server Implementation - Part 4: End User Guide and Usage Details

## Getting Started with AIChat Server

### Installation and Setup

1. Install AIChat:
```bash
# Using cargo
cargo install aichat

# Or download from releases
curl -L https://github.com/sigoden/aichat/releases/latest/download/aichat-x86_64-unknown-linux-gnu.tar.gz | tar xz
```

2. Configuration Setup:
Create a configuration file at `~/.config/aichat/config.yaml` (Linux/macOS) or `%APPDATA%\aichat\config.yaml` (Windows):

```yaml
# Basic configuration
model: openai:gpt-4
temperature: 0.7
serve_addr: 127.0.0.1:8000

# API configurations
clients:
  - type: openai
    api_key: "your-api-key"
    # Optional configurations
    api_base: "https://api.openai.com/v1"
    organization_id: "org-xxxxx"
```

### Starting the Server

Basic server start:
```bash
aichat --serve
```

Custom address and port:
```bash
# Specific port
aichat --serve 3000

# Specific address
aichat --serve 0.0.0.0

# Both address and port
aichat --serve 0.0.0.0:3000
```

## Using the Web Interfaces

### Playground Interface

The playground interface is accessible at `http://localhost:8000/playground` and provides an interactive environment for testing your LLM setup.

1. Model Selection:
   - Click the model dropdown in the top-right
   - Select from available models
   - Models shown are based on your configuration

2. Parameter Configuration:
   ```json
   {
     "temperature": 0.7,
     "top_p": 1.0,
     "max_tokens": 1000
   }
   ```

3. Message Input:
   - Type in the input box
   - Support for markdown formatting
   - File attachments (if configured)
   - Support for system messages

4. Response Controls:
   - Copy button for responses
   - Regenerate option for retrying
   - Stop generation button
   - Clear conversation history

### Arena Interface

The Arena interface at `http://localhost:8000/arena` enables model comparison:

1. Setting up comparison:
```
http://localhost:8000/arena?num=2  # Compare 2 models
http://localhost:8000/arena?num=3  # Compare 3 models
```

2. Model Selection:
   - Select different models for each panel
   - Same prompt is sent to all models
   - Responses appear side-by-side

3. Comparing Results:
   - Response timing
   - Token usage
   - Output differences
   - Cost comparison

## API Integration Guide

### Authentication

1. API Key Setup:
```yaml
# config.yaml
clients:
  - type: openai
    api_key: "sk-xxx"
```

2. Using in requests:
```bash
curl http://localhost:8000/v1/chat/completions \
  -H "Authorization: Bearer sk-xxx" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

### Chat Completions API

1. Basic chat request:
```python
import requests

response = requests.post(
    "http://localhost:8000/v1/chat/completions",
    json={
        "model": "gpt-4",
        "messages": [
            {"role": "user", "content": "Hello!"}
        ]
    }
)
print(response.json())
```

2. Streaming response:
```python
import requests

response = requests.post(
    "http://localhost:8000/v1/chat/completions",
    json={
        "model": "gpt-4",
        "messages": [{"role": "user", "content": "Hello!"}],
        "stream": True
    },
    stream=True
)

for line in response.iter_lines():
    if line:
        # Process SSE data
        print(line.decode('utf-8'))
```

3. Function calling:
```python
response = requests.post(
    "http://localhost:8000/v1/chat/completions",
    json={
        "model": "gpt-4",
        "messages": [{"role": "user", "content": "What's the weather?"}],
        "tools": [{
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get current weather",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"},
                    },
                    "required": ["location"]
                }
            }
        }]
    }
)
```

### Embeddings API

1. Single text embedding:
```python
response = requests.post(
    "http://localhost:8000/v1/embeddings",
    json={
        "model": "text-embedding-ada-002",
        "input": "Hello world"
    }
)
```

2. Batch embeddings:
```python
response = requests.post(
    "http://localhost:8000/v1/embeddings",
    json={
        "model": "text-embedding-ada-002",
        "input": ["Hello world", "Another text"]
    }
)
```

### Rerank API

```python
response = requests.post(
    "http://localhost:8000/v1/rerank",
    json={
        "model": "rerank-model",
        "query": "search query",
        "documents": [
            "document 1 text",
            "document 2 text"
        ],
        "top_n": 2
    }
)
```

## Configuration Details

### Environment Variables

1. Server configuration:
```bash
export AICHAT_SERVE_ADDR=0.0.0.0:3000
export AICHAT_MODEL=gpt-4
export AICHAT_TEMPERATURE=0.7
```

2. API configurations:
```bash
export OPENAI_API_KEY=sk-xxx
export AICHAT_API_BASE=https://api.openai.com/v1
```

3. Logging configuration:
```bash
export AICHAT_LOG_LEVEL=debug
export AICHAT_LOG_FILE=/path/to/custom.log
```

### Configuration File Options

1. Basic server settings:
```yaml
serve_addr: 127.0.0.1:8000
stream: true
save: true
highlight: true
wrap: auto
```

2. Model configurations:
```yaml
model: openai:gpt-4
temperature: 0.7
top_p: 1.0
max_tokens: 1000
```

3. Proxy settings:
```yaml
extra:
  proxy: socks5://127.0.0.1:1080
  connect_timeout: 10
```

## Common Use Cases

### Integrating with Web Applications

1. JavaScript/TypeScript integration:
```typescript
async function chatCompletion(message: string) {
    const response = await fetch('http://localhost:8000/v1/chat/completions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            model: 'gpt-4',
            messages: [{ role: 'user', content: message }]
        })
    });
    return await response.json();
}
```

2. Streaming responses:
```javascript
const response = await fetch('http://localhost:8000/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        model: 'gpt-4',
        messages: [{ role: 'user', content: message }],
        stream: true
    })
});

const reader = response.body.getReader();
while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    console.log(new TextDecoder().decode(value));
}
```

### Command Line Integration

1. Using with curl:
```bash
# Basic completion
curl http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4",
    "messages": [{"role": "user", "content": "Hello"}]
  }'

# Streaming response
curl -N http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4",
    "messages": [{"role": "user", "content": "Hello"}],
    "stream": true
  }'
```

2. Using with httpie:
```bash
http POST http://localhost:8000/v1/chat/completions \
  model=gpt-4 \
  messages:='[{"role": "user", "content": "Hello"}]'
```

## Troubleshooting Guide

### Common Issues

1. Connection Issues:
```bash
# Check server status
curl http://localhost:8000/v1/models

# Test with minimal request
curl http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"gpt-4","messages":[{"role":"user","content":"hi"}]}'
```

2. Configuration Issues:
```bash
# View current configuration
aichat --info

# Test configuration
aichat --dry-run
```

3. API Issues:
```bash
# Enable debug logging
export AICHAT_LOG_LEVEL=debug

# Check logs
tail -f ~/.config/aichat/aichat.log
```

### Performance Optimization

1. Response Streaming:
- Enable streaming for faster initial response
- Use appropriate chunk sizes
- Monitor connection stability

2. Connection Pooling:
- Reuse connections when possible
- Set appropriate timeouts
- Monitor connection pool size

3. Rate Limiting:
- Implement client-side rate limiting
- Use appropriate batch sizes
- Monitor API usage

## Best Practices

1. Error Handling:
```python
try:
    response = requests.post(
        "http://localhost:8000/v1/chat/completions",
        json=payload,
        timeout=30
    )
    response.raise_for_status()
except requests.exceptions.Timeout:
    print("Request timed out")
except requests.exceptions.HTTPError as e:
    print(f"HTTP error: {e}")
except requests.exceptions.RequestException as e:
    print(f"Error: {e}")
```

2. Response Processing:
```python
def process_response(response):
    if response.status_code == 200:
        data = response.json()
        if "choices" in data and len(data["choices"]) > 0:
            return data["choices"][0]["message"]["content"]
    return None
```

3. Resource Management:
```python
def get_completion(message):
    with requests.Session() as session:
        try:
            response = session.post(
                "http://localhost:8000/v1/chat/completions",
                json={
                    "model": "gpt-4",
                    "messages": [{"role": "user", "content": message}]
                },
                timeout=30
            )
            return process_response(response)
        except Exception as e:
            logger.error(f"Error getting completion: {e}")
            return None
```

## Conclusion

This user guide provides a comprehensive overview of using the AIChat server implementation from an end-user perspective. Whether you're integrating the server into a web application, using it from the command line, or building more complex integrations, understanding these usage patterns and best practices will help you effectively utilize the server's capabilities.