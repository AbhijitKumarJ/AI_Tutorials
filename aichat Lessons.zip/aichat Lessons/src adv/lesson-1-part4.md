# AIChat Lesson 1: Foundation and Core Structure (Part 4)
## End User Perspective & Usage Details

### Installation Guide

#### Package Manager Installation

AIChat can be installed through various package managers:

1. Rust Developers (using cargo):
```bash
cargo install aichat
```

2. Homebrew/Linuxbrew Users:
```bash
brew install aichat
```

3. Pacman Users:
```bash
pacman -S aichat
```

4. Windows Scoop Users:
```bash
scoop install aichat
```

5. Android Termux Users:
```bash
pkg install aichat
```

#### Manual Installation

For manual installation from pre-built binaries:

1. Download the appropriate binary for your system from [GitHub Releases](https://github.com/sigoden/aichat/releases)
2. Extract the archive
3. Add the aichat binary to your PATH

### Initial Configuration

When running AIChat for the first time, you'll need to set up the configuration:

```bash
$ aichat
> No config file, create a new one? Yes
> Platform: openai
? API Key: ***
✨ Saved config file to '/home/alice/.config/aichat/config.yaml'
```

#### Configuration File Structure

The configuration file is created at platform-specific locations:
- Windows: `C:\Users\<username>\AppData\Roaming\aichat\config.yaml`
- macOS: `/Users/<username>/Library/Application Support/aichat/config.yaml`
- Linux: `/home/<username>/.config/aichat/config.yaml`

Basic configuration example:
```yaml
# LLM settings
model: openai:gpt-4o
temperature: 0.7
stream: true

# API configuration
clients:
  - type: openai
    api_key: your_api_key_here
    organization_id: optional_org_id
```

### Core Usage Modes

#### 1. Direct Command Mode

Quick one-off queries:
```bash
# Simple question
aichat "What is the capital of France?"

# Code generation
aichat -c "write a python function to calculate fibonacci numbers"

# Shell command assistance
aichat -e "create a new directory and move all .txt files into it"
```

#### 2. REPL Mode

Interactive shell mode with extensive features:

```bash
$ aichat
> .help                    # Show help message
> .model                   # Change the current LLM
> .role                    # Use a specific role
> .session                 # Begin a session
> .rag                     # Init or use the RAG
> .agent                   # Use an agent
```

Key REPL Features:
- Tab Autocompletion
- Multi-line Support
- History Search
- Configurable Keybinding

##### Multi-line Input Methods:
1. External Editor: `ctrl+o`
2. Paste multi-line text
3. Use `:::` delimiter:
```
> ::: 
Write a python function
that calculates the 
factorial of a number
:::
```

##### History Navigation:
- `ctrl+r` - Search history
- `↑↓` - Navigate through history

#### 3. Server Mode

Running AIChat as a server:
```bash
$ aichat --serve [address]
Chat Completions API: http://127.0.0.1:8000/v1/chat/completions
Embeddings API:       http://127.0.0.1:8000/v1/embeddings
LLM Playground:       http://127.0.0.1:8000/playground
LLM Arena:            http://127.0.0.1:8000/arena?num=2
```

### Working with Files and Input

#### File Input Methods

1. Local Files:
```bash
# Single file
aichat -f data.txt

# Multiple files
aichat -f file1.txt -f file2.txt

# Directory
aichat -f dir/

# Specific extensions
aichat -f "dir/**/*.{md,txt}"
```

2. Remote URLs:
```bash
aichat -f https://example.com/doc.txt
```

3. Images:
```bash
# Local image
aichat -f image.png "describe this image"

# Multiple images
aichat -f image1.jpg -f image2.jpg "compare these images"
```

#### Pipe Support
```bash
# Pipe input
echo "Hello" | aichat

# Process file content
cat data.txt | aichat -c "convert to json" > data.json
```

### Role System Usage

#### Built-in Roles

1. Shell Assistant (`%shell%`):
```bash
aichat -r %shell% "create a backup of all .txt files"
```

2. Code Generator (`%code%`):
```bash
aichat -r %code% "write a quicksort implementation"
```

3. Shell Explainer (`%explain-shell%`):
```bash
aichat -r %explain-shell% "ls -la | grep '^d'"
```

#### Custom Roles

1. Creating a new role:
```bash
# Using REPL
> .role python-expert
# Enter role definition in editor
```

2. Role file structure:
```yaml
---
model: openai:gpt-4o
temperature: 0.7
---
You are an expert Python programmer...
```

### Session Management

#### Session Commands

1. Starting a session:
```bash
# Temporary session
aichat -s

# Named session
aichat -s coding_session
```

2. Session management in REPL:
```bash
> .session                 # Start session
> .empty session          # Clear messages
> .compress session       # Compress history
> .info session           # View info
> .save session           # Save to file
> .exit session          # End session
```

### RAG (Retrieval-Augmented Generation)

#### Setting up RAG:

1. Initialize RAG:
```bash
> .rag
> Add documents: /path/to/docs
```

2. Using RAG with files:
```bash
aichat -R docs_rag -f additional_file.txt "explain this"
```

### Environment Variables

AIChat supports configuration through environment variables:

```bash
# Model selection
export AICHAT_MODEL=openai:gpt-4o

# Behavior control
export AICHAT_STREAM=false
export AICHAT_SAVE=true

# Debug logging
export AICHAT_LOG_LEVEL=debug
```

### Customization Features

#### 1. Custom Themes

AIChat supports custom themes for syntax highlighting:

1. Download theme:
```bash
cd ~/.config/aichat
wget -O dark.tmTheme 'https://raw.githubusercontent.com/braver/Solarized/master/Solarized%20(dark).tmTheme'
```

2. Configure theme:
```yaml
# config.yaml
highlight: true
light_theme: false  # or true for light theme
```

#### 2. Custom REPL Prompt

Customize the REPL prompt appearance:
```yaml
# config.yaml
left_prompt: '{color.green}{session}{color.cyan}> '
right_prompt: '{color.purple}{tokens}{color.reset}'
```

### Common Workflows

#### 1. Code Development
```bash
# Start a coding session
aichat -s coding -r %code%

# Generate and iterate on code
> write a REST API in Python
> add authentication to the API
```

#### 2. Shell Task Automation
```bash
# Get command suggestions
aichat -e "find all files modified in last 24 hours"

# Execute suggested command
aichat -e "organize my downloads folder by file type"
```

#### 3. Document Analysis
```bash
# Initialize RAG with documents
aichat -R docs -f "project/**/*.md"

# Query documents
> explain the architecture explained in these documents
```

### Troubleshooting Guide

1. Logging:
```bash
# Enable debug logging
export AICHAT_LOG_LEVEL=debug
```

2. Common Issues:
- Configuration issues: Check `~/.config/aichat/config.yaml`
- API errors: Verify API keys in config or `.env`
- Path issues: Ensure correct file permissions

3. Getting Help:
```bash
# Show version and config info
aichat --info

# List available commands
aichat --help
```

This comprehensive user guide covers the practical aspects of using AIChat from an end-user perspective, explaining features that might have been assumed or left unexplained in the previous parts. It provides concrete examples and workflows that users can follow to make the most of AIChat's capabilities.

### Additional Resources

1. Documentation
- [Chat-REPL Guide](https://github.com/sigoden/aichat/wiki/Chat-REPL-Guide)
- [Command-Line Guide](https://github.com/sigoden/aichat/wiki/Command-Line-Guide)
- [Configuration Guide](https://github.com/sigoden/aichat/wiki/Configuration-Guide)
- [FAQ](https://github.com/sigoden/aichat/wiki/FAQ)

2. Community Resources
- GitHub Issues for bug reports
- Discussion forum for questions
- Wiki for community contributions

This concludes the user-focused perspective of AIChat's foundation and structure, providing practical knowledge needed to effectively use the tool.
