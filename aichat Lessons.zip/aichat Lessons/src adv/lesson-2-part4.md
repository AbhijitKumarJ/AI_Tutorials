# AIChat Lesson 2: Client Abstraction Layer (Part 4) - End User Guide

## Getting Started with AIChat

This guide covers the practical aspects of using AIChat from an end user's perspective, focusing on the client abstraction layer features.

### Initial Configuration

When you first run AIChat, it creates a default configuration file:

```bash
$ aichat
> No config file, create a new one? Yes
> Platform: openai
? API Key: ***
✨ Saved config file to '/home/alice/.config/aichat.yaml'
```

Configuration file locations:
- Windows: `C:\Users\Alice\AppData\Roaming\aichat\config.yaml`
- macOS: `/Users/Alice/Library/Application Support/aichat/config.yaml`
- Linux: `/home/alice/.config/aichat/config.yaml`

### Basic Configuration Structure

A typical configuration for multiple providers:

```yaml
model: openai:gpt-4o             # Default model
temperature: 0.7                 # Default temperature
top_p: 0.9                      # Default top-p parameter

clients:
  - type: openai
    api_key: "sk-..."
    
  - type: claude
    api_key: "sk-..."
    
  - type: gemini
    api_key: "..."
```

## Working with Different Models

### Listing Available Models

```bash
$ aichat --list-models
openai:gpt-4o     128000 /     4096  |     5.0 /    15.0    👁 ⚒ 
openai:gpt-3.5-turbo  16385 /     4096  |     0.5 /     1.5    ⚒
claude:claude-3-haiku  200000 /     4096  |     0.25 /    1.25   👁 ⚒
```

Understanding the output:
- First column: `provider:model`
- Second/third columns: Input/output token limits
- Fourth/fifth columns: Input/output prices per million tokens
- Icons: 👁 = Vision support, ⚒ = Function calling support

### Selecting Models

Via command line:
```bash
$ aichat -m openai:gpt-4o "What is 2+2?"
4

$ aichat -m claude:claude-3-haiku "Tell me a joke"
Here's a lighthearted one...
```

Via configuration file:
```yaml
model: claude:claude-3-haiku  # Sets default model
```

## Managing API Keys

### Environment Variables

Each provider supports environment variables for API keys:
```bash
# OpenAI
export OPENAI_API_KEY="sk-..."

# Google Gemini
export GEMINI_API_KEY="..."

# Anthropic Claude
export CLAUDE_API_KEY="..."
```

### Using Multiple Keys

For multiple accounts/organizations:
```yaml
clients:
  - type: openai
    api_key: "sk-..."
    name: "work"
    
  - type: openai
    api_key: "sk-..."
    name: "personal"
```

Usage:
```bash
$ aichat -m work:gpt-4o "Work related query"
$ aichat -m personal:gpt-4o "Personal query"
```

## Advanced Usage Features

### Stream Mode Control

By default, AIChat uses streaming responses:
```bash
$ aichat "Tell me a story"
Once upon a time... [text appears word by word]
```

Disable streaming:
```bash
$ aichat -S "Tell me a story"
[Full response appears at once]
```

Configuration file setting:
```yaml
stream: false  # Globally disable streaming
```

### Vision Support

For models supporting vision:
```bash
$ aichat -f image.png "What's in this image?"
$ aichat -f diagram.jpg -f chart.png "Compare these images"
```

Supported formats:
- JPG/JPEG
- PNG
- WebP
- GIF (first frame)

### Function Calling

Using tools:
```yaml
function_calling: true           # Enable function calling
mapping_tools:                   # Tool aliases
  fs: 'fs_cat,fs_ls,fs_mkdir,fs_rm,fs_write'
use_tools: "fs,web_search"      # Default tools to use
```

Example usage:
```bash
$ aichat "What files are in the current directory?"
Let me check that for you...
[Uses fs_ls tool to list directory contents]
```

## Common Troubleshooting

### API Key Issues

If you see authentication errors:
```bash
# Check current API key
$ aichat --info | grep "api_key"

# Test API connection
$ aichat -m openai:gpt-3.5-turbo "Hello" --dry-run
```

### Rate Limiting

When hitting rate limits:
```yaml
# Add to config.yaml
clients:
  - type: openai
    extra:
      connect_timeout: 30    # Increase timeout
```

### Network Issues

Configure proxy settings:
```yaml
clients:
  - type: openai
    extra:
      proxy: "socks5://127.0.0.1:1080"
```

Or via environment:
```bash
export HTTPS_PROXY="http://proxy.example.com:8080"
```

## Model-Specific Features

### OpenAI GPT-4 Vision

```bash
$ aichat -m openai:gpt-4o -f image.png "Describe this image in detail"
```

### Claude System Messages

```bash
$ aichat -m claude:claude-3-haiku --prompt "You are a helpful assistant" "Hello"
```

### Gemini Pro Features

```bash
$ aichat -m gemini:gemini-1.5-pro --temperature 0.9 "Be creative"
```

## Performance Optimization

### Token Management

Manage token usage:
```yaml
compress_threshold: 4000  # Auto-compress at 4000 tokens
```

### Cost Control

Monitor spending:
```bash
$ aichat --info
Model: openai:gpt-4o
Pricing: $0.01/1K tokens (input), $0.03/1K tokens (output)
...
```

## Data Privacy

### Local Operation Mode

For sensitive data:
```bash
$ aichat -m ollama:llama3.1 "Process sensitive data"
```

### Session Management

Save conversations:
```bash
$ aichat -s my-session
[Conversation is saved to session file]
```

Session files location:
```bash
~/.config/aichat/sessions/my-session.yaml
```

## Environment Integration

### Shell Integration

Enable intelligent command completion:
```bash
# Bash
echo 'source "$(which aichat)"' >> ~/.bashrc

# Zsh
echo 'source "$(which aichat)"' >> ~/.zshrc

# Fish
echo 'source (which aichat)' >> ~/.config/fish/config.fish
```

### VS Code Integration

Create tasks.json:
```json
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "AIChat: Ask",
      "type": "shell",
      "command": "aichat",
      "args": ["-c", "${selectedText}"],
      "presentation": {
        "reveal": "always",
        "panel": "new"
      }
    }
  ]
}
```

## Additional Tips

### Markdown Output

AIChat renders markdown by default:
```bash
$ aichat "Create a table of fruits"
| Fruit  | Color  | Taste    |
|--------|--------|----------|
| Apple  | Red    | Sweet    |
| Lemon  | Yellow | Sour     |
| Orange | Orange | Sweet    |
```

### Code Extraction

Extract only code:
```bash
$ aichat -c "Write a Python function to calculate fibonacci"
[Returns only the code without explanation]
```

These practical usage details help users maximize the value they get from AIChat's client abstraction layer features while avoiding common pitfalls and understanding the system's capabilities.
