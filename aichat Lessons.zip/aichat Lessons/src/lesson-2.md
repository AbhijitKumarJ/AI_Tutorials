# Lesson 2: Client Abstraction Layer

## Introduction

The client abstraction layer in AIChat is a sophisticated system that enables seamless interaction with multiple LLM providers through a unified interface. This lesson explores how AIChat implements this abstraction, handles different provider APIs, and manages the complexities of cross-platform networking.

## Client Trait System

At the core of the client abstraction is the Client trait defined in client/common.rs. This trait provides the foundation for all LLM provider implementations:

```rust
#[async_trait::async_trait]
pub trait Client: Sync + Send {
    fn global_config(&self) -> &GlobalConfig;
    fn extra_config(&self) -> Option<&ExtraConfig>;
    fn patch_config(&self) -> Option<&RequestPatch>;
    fn name(&self) -> &str;
    fn model(&self) -> &Model;
    fn model_mut(&mut self) -> &mut Model;

    async fn chat_completions(&self, input: Input) -> Result<ChatCompletionsOutput>;
    async fn chat_completions_streaming(&self, input: &Input, handler: &mut SseHandler) -> Result<()>;
    async fn embeddings(&self, data: &EmbeddingsData) -> Result<Vec<Vec<f32>>>;
    async fn rerank(&self, data: &RerankData) -> Result<RerankOutput>;
}
```

## Model Management

The Model system (client/model.rs) provides a unified way to handle different LLM capabilities and configurations:

```rust
pub struct Model {
    client_name: String,
    data: ModelData,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModelData {
    pub name: String,
    pub model_type: String,
    pub max_input_tokens: Option<usize>,
    pub input_price: Option<f64>,
    pub output_price: Option<f64>,
    pub supports_vision: bool,
    pub supports_function_calling: bool,
    // ... other fields
}
```

## Provider Implementations

Let's examine how different providers are implemented:

### OpenAI Implementation (client/openai.rs)
```rust
impl_client_trait!(
    OpenAIClient,
    (
        prepare_chat_completions,
        openai_chat_completions,
        openai_chat_completions_streaming
    ),
    (prepare_embeddings, openai_embeddings),
    (noop_prepare_rerank, noop_rerank),
);
```

### Claude Implementation (client/claude.rs)
```rust
pub async fn claude_chat_completions(
    builder: RequestBuilder,
    _model: &Model,
) -> Result<ChatCompletionsOutput> {
    let res = builder.send().await?;
    let status = res.status();
    let data: Value = res.json().await?;
    if !status.is_success() {
        catch_error(&data, status.as_u16())?;
    }
    debug!("non-stream-data: {data}");
    claude_extract_chat_completions(&data)
}
```

## Message Handling

The message system (client/message.rs) provides a unified way to handle different types of messages:

```rust
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Message {
    pub role: MessageRole,
    pub content: MessageContent,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(untagged)]
pub enum MessageContent {
    Text(String),
    Array(Vec<MessageContentPart>),
    ToolResults(ToolResults),
}
```

## Streaming Implementation

The streaming system (client/stream.rs) handles real-time responses:

```rust
pub struct SseHandler {
    sender: UnboundedSender<SseEvent>,
    abort_signal: AbortSignal,
    buffer: String,
    tool_calls: Vec<ToolCall>,
}
```

## Cross-Platform Networking

The codebase handles cross-platform networking considerations in several ways:

1. Request Configuration:
```rust
fn set_proxy(
    builder: reqwest::ClientBuilder,
    proxy: Option<&String>,
) -> Result<reqwest::ClientBuilder> {
    let proxy = if let Some(proxy) = proxy {
        if proxy.is_empty() || proxy == "-" {
            return Ok(builder);
        }
        proxy.clone()
    } else if let Some(proxy) = ["HTTPS_PROXY", "https_proxy", "ALL_PROXY", "all_proxy"]
        .into_iter()
        .find_map(|v| env::var(v).ok())
    {
        proxy
    } else {
        return Ok(builder);
    };
    let builder = builder
        .proxy(reqwest::Proxy::all(&proxy)?);
    Ok(builder)
}
```

2. Timeout Handling:
```rust
fn build_client(&self) -> Result<ReqwestClient> {
    let mut builder = ReqwestClient::builder();
    let extra = self.extra_config();
    let timeout = extra.and_then(|v| v.connect_timeout).unwrap_or(10);
    let proxy = extra.and_then(|v| v.proxy.clone());
    builder = set_proxy(builder, proxy.as_ref())?;
    if let Some(user_agent) = self.global_config().read().user_agent.as_ref() {
        builder = builder.user_agent(user_agent);
    }
    let client = builder
        .connect_timeout(Duration::from_secs(timeout))
        .build()?;
    Ok(client)
}
```

## Error Handling

The client layer implements sophisticated error handling:

```rust
pub fn catch_error(data: &Value, status: u16) -> Result<()> {
    if (200..300).contains(&status) {
        return Ok(());
    }
    debug!("Invalid response, status: {status}, data: {data}");
    if let Some(error) = data["error"].as_object() {
        if let (Some(typ), Some(message)) = (
            json_str_from_map(error, "type"),
            json_str_from_map(error, "message"),
        ) {
            bail!("{message} (type: {typ})");
        }
        // ... other error handling cases
    }
    bail!("Invalid response data: {data} (status: {status})")
}
```

## Client Registration System

The macros.rs file provides a sophisticated registration system for clients:

```rust
#[macro_export]
macro_rules! register_client {
    (
        $(($module:ident, $name:literal, $config:ident, $client:ident),)+
    ) => {
        $(
            mod $module;
        )+
        $(
            use self::$module::$config;
        )+

        #[derive(Debug, Clone, serde::Deserialize)]
        #[serde(tag = "type")]
        pub enum ClientConfig {
            $(
                #[serde(rename = $name)]
                $config($config),
            )+
            #[serde(other)]
            Unknown,
        }
        // ... implementation details
    };
}
```

## Practical Exercise

To reinforce your understanding:

1. Implement a new client for a hypothetical LLM provider
2. Add proper error handling and request/response processing
3. Implement streaming capabilities
4. Add cross-platform considerations
5. Write tests for your implementation

Example structure:
```rust
#[derive(Debug, Clone, Deserialize, Default)]
pub struct NewProviderConfig {
    pub name: Option<String>,
    pub api_key: Option<String>,
    pub api_base: Option<String>,
    #[serde(default)]
    pub models: Vec<ModelData>,
    pub patch: Option<RequestPatch>,
    pub extra: Option<ExtraConfig>,
}

impl_client_trait!(
    NewProviderClient,
    (prepare_chat_completions, chat_completions, chat_completions_streaming),
    (prepare_embeddings, embeddings),
    (prepare_rerank, rerank),
);
```

## Conclusion

The client abstraction layer is a crucial component of AIChat, enabling seamless integration with multiple LLM providers while maintaining clean architecture and robust error handling. Understanding this layer is essential for contributing to the project or implementing similar systems.

In the next lesson, we'll explore the Configuration and State Management system, which handles user preferences, session state, and role-based configurations.