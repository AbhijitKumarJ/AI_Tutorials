# AIChat Lesson 3: Configuration and State Management

## Introduction

Configuration and state management form the backbone of AIChat's functionality, enabling the application to maintain user preferences, handle different environments, and manage complex runtime states. This lesson explores how AIChat implements these critical systems through a sophisticated yet maintainable architecture.

## File Structure Overview

The configuration and state management system primarily lives in the `config` directory within the src folder:

```
src/config/
├── mod.rs          # Main configuration module and core implementation
├── agent.rs        # Agent-specific configuration handling
├── input.rs        # Input processing and management
├── role.rs         # Role-based configuration
└── session.rs      # Session state management
```

## Core Configuration System

The heart of AIChat's configuration system is implemented in `config/mod.rs`. The system follows a hierarchical structure where configurations can be loaded from multiple sources with a clear precedence order:

1. Command-line arguments
2. Environment variables
3. Configuration files
4. Default values

The `Config` struct serves as the central configuration store:

```rust
pub struct Config {
    pub model_id: String,
    pub temperature: Option<f64>,
    pub top_p: Option<f64>,
    pub dry_run: bool,
    pub stream: bool,
    pub save: bool,
    // ... additional fields
}
```

### Configuration File Management

AIChat uses YAML as its configuration format. The system looks for configuration files in the following locations:

1. Custom path specified by `AICHAT_CONFIG_FILE`
2. User's config directory (e.g., `~/.config/aichat/config.yaml` on Unix systems)
3. Default configuration bundled with the application

The configuration loading process is handled by the `Config::init()` method, which follows these steps:

1. Determine the configuration file location
2. Load and parse the YAML configuration
3. Apply environment variable overrides
4. Validate the configuration
5. Initialize dependent systems

### Environment Variables

The environment variable system in AIChat is sophisticated, supporting multiple variable types and automatic type conversion. The `get_env_name()` utility function ensures consistent environment variable naming:

```rust
pub fn get_env_name(key: &str) -> String {
    format!("{}_{}", env!("CARGO_CRATE_NAME"), key).to_ascii_uppercase()
}
```

Variables can be accessed through the `read_env_value<T>()` generic function, which handles type conversion and validation:

```rust
fn read_env_value<T>(key: &str) -> Option<Option<T>>
where
    T: std::str::FromStr
{
    let value = env::var(key).ok()?;
    let value = parse_value(&value).ok()?;
    Some(value)
}
```

## State Management

AIChat implements a sophisticated state management system that handles various runtime states including:

### Session State

Sessions are managed through the `Session` struct in `config/session.rs`. The session system maintains:

- Conversation history
- Model configurations
- Token usage tracking
- Compression states

The `Session` struct implements methods for:

1. Creating new sessions
2. Loading existing sessions
3. Saving session state
4. Managing message history
5. Handling token limits
6. Implementing compression strategies

### Role Management

Roles are handled by the `Role` struct in `config/role.rs`. The role system provides:

- Custom prompts
- Model configurations
- Temperature settings
- Tool configurations

Roles can be:

1. Built-in (shipped with AIChat)
2. User-defined (stored in the roles directory)
3. Temporary (created for single use)

### Agent State

The agent system (`config/agent.rs`) manages more complex states including:

- Tool configurations
- Variable states
- Document contexts
- Function permissions

## Global State Management

AIChat uses a thread-safe global state management system implemented using `Arc<RwLock<Config>>`:

```rust
pub type GlobalConfig = Arc<RwLock<Config>>;
```

This allows for:

1. Safe concurrent access to configuration
2. Runtime configuration updates
3. State sharing between components
4. Atomic state transitions

### State Synchronization

The system implements various synchronization mechanisms:

```rust
impl Config {
    pub fn sync(&mut self, other: &Config) {
        self.model = other.model.clone();
        self.temperature = other.temperature;
        self.top_p = other.top_p;
        // ... additional synchronization
    }
}
```

## Cross-Platform Considerations

The configuration system handles cross-platform differences through:

### File Paths

Platform-specific path handling:

```rust
pub fn config_dir() -> PathBuf {
    if let Ok(v) = env::var(get_env_name("config_dir")) {
        PathBuf::from(v)
    } else if let Ok(v) = env::var("XDG_CONFIG_HOME") {
        PathBuf::from(v).join(env!("CARGO_CRATE_NAME"))
    } else {
        dirs::config_dir()
            .expect("No user's config directory")
            .join(env!("CARGO_CRATE_NAME"))
    }
}
```

### Environment Detection

System-specific environment detection:

```rust
#[cfg(windows)]
const PATH_SEP: &str = ";";
#[cfg(not(windows))]
const PATH_SEP: &str = ":";
```

## Practical Examples

### Loading Configuration

```rust
let config = Config::init(WorkingMode::Repl)?;
let global_config = Arc::new(RwLock::new(config));
```

### Updating Configuration

```rust
let mut config = global_config.write();
config.set_model("gpt-4")?;
config.set_temperature(Some(0.7));
```

### Managing Sessions

```rust
let mut session = Session::new(&config, "my-session");
session.add_message(&input, "Hello, world!")?;
session.save()?;
```

## Best Practices

1. Always use the `GlobalConfig` type for shared state
2. Implement proper error handling for configuration operations
3. Use the environment variable system for runtime configuration
4. Keep configuration files human-readable and well-documented
5. Implement proper validation for all configuration values
6. Handle cross-platform differences explicitly
7. Use atomic operations for state updates

## Common Pitfalls

1. Direct modification of configuration without proper locking
2. Incorrect handling of platform-specific paths
3. Missing error handling in configuration loading
4. Improper type conversion in environment variables
5. Race conditions in state updates
6. Memory leaks in session management
7. Incomplete validation of configuration values

## Exercises

1. Implement a new configuration option with environment variable support
2. Create a custom role with specific model configurations
3. Build a session management utility
4. Implement a configuration validation system
5. Create a cross-platform path handling utility
6. Build a state synchronization mechanism
7. Implement a configuration migration system

## Conclusion

Understanding AIChat's configuration and state management system is crucial for both using and contributing to the project. The system's design balances flexibility with reliability, providing a robust foundation for the application's functionality while maintaining cross-platform compatibility and user configurability.

The next lesson will explore the REPL implementation, building on the knowledge of configuration and state management covered here.