# Lesson 1: Foundation and Core Structure

## Introduction

The AIChat codebase represents a sophisticated CLI application that interfaces with various LLM providers. In this first lesson, we'll explore the foundational structure of the application, focusing on how the project is organized and how the core components interact. This understanding is crucial for anyone wanting to contribute to or learn from the project.

## Main Entry Point (main.rs)

The heart of AIChat begins in main.rs, which serves as the application's entry point. This file is particularly interesting as it demonstrates several important Rust patterns for CLI applications. The main function is annotated with #[tokio::main], indicating this is an async application built on the Tokio runtime.

The main.rs file handles several critical responsibilities:
1. Command-line argument parsing using clap
2. Environment setup including logger initialization
3. Configuration loading and validation
4. Execution mode determination (REPL, command, or server)

The code is structured to handle different execution modes elegantly:
```rust
let working_mode = if cli.serve.is_some() {
    WorkingMode::Serve
} else if text.is_none() && cli.file.is_empty() {
    WorkingMode::Repl
} else {
    WorkingMode::Cmd
};
```

## CLI Argument Processing (cli.rs)

The cli.rs module defines the command-line interface using the clap framework. It demonstrates excellent practices in CLI application design:

1. Comprehensive argument definitions using derive macros
2. Clear documentation for each option
3. Logical grouping of related options
4. Cross-platform path handling

The Cli struct shows thoughtful API design with options for:
- Model selection
- System prompts
- Role selection
- Session management
- RAG functionality
- Execution modes

## Function Management (function.rs)

The function.rs module implements the infrastructure for function calling capabilities. Key features include:

1. Tool call evaluation and deduplication
2. Function declaration management
3. Cross-platform command execution
4. Security considerations for function execution

The module demonstrates advanced Rust patterns like:
- Error handling with anyhow
- JSON schema validation
- Dynamic function dispatch
- Cross-platform path handling

## Serve Mode (serve.rs)

The serve.rs module implements the HTTP server functionality, showing how to:

1. Create a WebSocket server for streaming responses
2. Handle multiple API endpoints
3. Manage concurrent connections
4. Implement OpenAI-compatible APIs

This module is particularly interesting for its use of:
- Hyper for HTTP handling
- Tokio for async operations
- Cross-platform networking considerations

## Cross-Platform Considerations

Throughout these core files, several cross-platform considerations are evident:

1. Path Handling:
```rust
#[cfg(windows)]
const PATH_SEP: &str = ";";
#[cfg(not(windows))]
const PATH_SEP: &str = ":";
```

2. Terminal Detection:
```rust
#[cfg(target_os = "macos")]
use crossterm::terminal::is_terminal;
```

3. File System Operations:
The codebase uses platform-agnostic path handling:
```rust
pub fn config_dir() -> PathBuf {
    if let Ok(v) = env::var(get_env_name("config_dir")) {
        PathBuf::from(v)
    } else if let Ok(v) = env::var("XDG_CONFIG_HOME") {
        PathBuf::from(v).join(env!("CARGO_CRATE_NAME"))
    } else {
        dirs::config_dir()
            .expect("No user's config directory")
            .join(env!("CARGO_CRATE_NAME"))
    }
}
```

## Error Handling Patterns

The project demonstrates robust error handling using anyhow:

1. Context propagation:
```rust
fn setup_logger(is_serve: bool) -> Result<()> {
    let (log_level, log_path) = Config::log_config(is_serve)?;
    if log_level == LevelFilter::Off {
        return Ok(());
    }
    // ... error handling with context
}
```

2. Custom error creation:
```rust
bail!("Unable to run {cmd_name}, {err}")
```

## Module Organization

The project follows a clean and logical module structure:

1. Core Modules:
   - cli.rs: Command-line interface
   - function.rs: Function calling system
   - main.rs: Application entry point
   - serve.rs: HTTP server implementation

2. Specialized Directories:
   - client/: LLM provider implementations
   - config/: Configuration management
   - rag/: Document retrieval system
   - render/: Output rendering
   - repl/: Interactive shell
   - utils/: Utility functions

## Practical Exercise

To reinforce your understanding:

1. Add a new command-line option to the Cli struct in cli.rs
2. Implement the handling of this option in main.rs
3. Ensure your implementation works across different platforms
4. Add appropriate error handling
5. Write tests for your new functionality

## Conclusion

This first lesson has covered the foundational structure of the AIChat codebase. We've explored how the application boots up, processes commands, and maintains cross-platform compatibility. Understanding these core components is crucial for working with the rest of the codebase effectively.

In the next lesson, we'll dive into the client abstraction layer, exploring how AIChat interfaces with different LLM providers while maintaining a clean and consistent API.