# Lesson 8: Utility Functions and Helper Systems

## Overview

This lesson explores AIChat's utility system located in the `utils` directory, which provides essential support functions and helper systems used throughout the application. The utilities module is critical for maintaining clean, DRY code while handling common operations consistently across the codebase.

## Module Structure

The utilities are organized in the following structure:

```
utils/
├── mod.rs                 # Main module file with common utilities
├── abort_signal.rs        # Abort signal handling
├── clipboard.rs           # Cross-platform clipboard operations
├── command.rs            # Shell command execution utilities
├── crypto.rs             # Cryptographic operations
├── html_to_md.rs         # HTML to Markdown conversion
├── path.rs               # Path manipulation utilities
├── prompt_input.rs       # User input prompting
├── render_prompt.rs      # REPL prompt rendering
├── request.rs            # HTTP request handling
├── spinner.rs            # Terminal progress indicators
└── variables.rs          # Variable interpolation
```

## Core Functionality Areas

### 1. Abort Signal System (abort_signal.rs)

The abort signal system provides a mechanism for gracefully canceling operations throughout the application. It implements a thread-safe signal using atomic operations that can be triggered by Ctrl+C or Ctrl+D keyboard combinations.

Key components:
```rust
pub struct AbortSignalInner {
    ctrlc: AtomicBool,
    ctrld: AtomicBool,
}
```

The system supports:
- Creation of new abort signals
- Checking abort status
- Resetting signals
- Waiting for abort signals asynchronously
- Cross-thread signal propagation

### 2. Clipboard Management (clipboard.rs)

The clipboard module provides cross-platform clipboard interaction using the arboard crate. It handles text operations with platform-specific considerations for:
- Windows
- macOS
- Linux (with both X11 and Wayland support)
- Android/Emscripten platform detection

### 3. Command Execution (command.rs)

This module handles shell command execution and process management. It provides:

- Shell detection and configuration
- Command execution with environment variable support
- Output capture and parsing
- Cross-platform command adaptation
- Error handling for command execution

### 4. Cryptographic Operations (crypto.rs)

The crypto module implements various cryptographic functions needed throughout the application:

- SHA-256 hashing
- HMAC-SHA256 generation
- Base64 encoding/decoding
- URL-safe encoding
- Hex encoding

### 5. Path Management (path.rs)

The path module provides safe path manipulation utilities:

- Path joining with security checks
- Glob pattern expansion
- File extension handling
- Directory traversal prevention
- Cross-platform path normalization

### 6. User Input Handling (prompt_input.rs)

This module manages user input prompting with:

- Validated string input
- Integer input with validation
- Optional input handling
- Selection prompts
- Error messaging

### 7. REPL Prompt Rendering (render_prompt.rs)

The prompt rendering system provides:

- Template-based prompt generation
- Variable interpolation
- Conditional rendering
- Color and styling support
- Cross-platform terminal handling

### 8. HTTP Request Management (request.rs)

The request module handles HTTP operations with:

- Configurable clients
- Retry logic
- Timeout handling
- Response parsing
- Error management
- Proxy support

### 9. Progress Indication (spinner.rs)

The spinner module provides terminal progress indicators:

- Animated spinners
- Progress messages
- Cancelable operations
- Cross-platform terminal support
- Async operation support

### 10. Variable Management (variables.rs)

This module handles variable interpolation throughout the application:

- Environment variable support
- Template variable replacement
- System information injection
- Dynamic variable resolution

## Cross-Platform Considerations

The utilities module handles various platform-specific considerations:

1. File System Operations
   - Different path separators (Windows vs Unix)
   - Platform-specific directory locations
   - File permission handling

2. Terminal Handling
   - Windows console support
   - ANSI color support detection
   - Terminal capability detection

3. Clipboard Operations
   - Platform-specific clipboard APIs
   - Wayland vs X11 support on Linux
   - Permission handling

4. Process Management
   - Shell detection and execution
   - Environment variable handling
   - Process signal handling

## Error Handling Patterns

The utilities module implements consistent error handling patterns:

1. Error Context
```rust
pub fn pretty_error(err: &anyhow::Error) -> String {
    let mut output = vec![];
    output.push(format!("Error: {err}"));
    let causes: Vec<_> = err.chain().skip(1).collect();
    // ... error formatting logic
}
```

2. Result Propagation
```rust
pub fn run_command<T: AsRef<OsStr>>(
    cmd: &str,
    args: &[T],
    envs: Option<HashMap<String, String>>,
) -> Result<i32>
```

3. Error Type Conversion
```rust
fn parse_value<T>(value: &str) -> Result<Option<T>>
where
    T: std::str::FromStr
```

## Common Utility Patterns

1. Lazy Static Initialization
```rust
lazy_static::lazy_static! {
    static ref CODE_BLOCK_RE: Regex = Regex::new(r"(?ms)```\w*(.*)```").unwrap();
    static ref IS_STDOUT_TERMINAL: bool = std::io::stdout().is_terminal();
    static ref NO_COLOR: bool = env::var("NO_COLOR").is_ok() || !*IS_STDOUT_TERMINAL;
}
```

2. Trait Implementation for Utilities
```rust
pub trait ReplHighlighter {
    fn highlight(&self, line: &str, cursor: usize) -> StyledText;
}
```

3. Configuration Management
```rust
pub fn get_env_name(key: &str) -> String {
    format!("{}_{key}", env!("CARGO_CRATE_NAME"),).to_ascii_uppercase()
}
```

## Testing Strategies

The utilities module employs various testing approaches:

1. Unit Tests
```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_fuzzy_match() {
        assert!(fuzzy_match("openai:gpt-4-turbo", "gpt4"));
        assert!(fuzzy_match("openai:gpt-4-turbo", "oai4"));
        assert!(!fuzzy_match("openai:gpt-4-turbo", "4gpt"));
    }
}
```

2. Integration Tests
```rust
#[cfg(test)]
mod tests {
    #[test]
    fn test_process_command_line() {
        assert_eq!(parse_command(" ."), Some((".", None)));
        assert_eq!(parse_command(" .role"), Some((".role", None)));
    }
}
```

## Documentation Practices

The utilities module follows these documentation practices:

1. Module Documentation
```rust
//! Utility functions and helper systems for the AIChat application.
//! This module provides common functionality used throughout the codebase.
```

2. Function Documentation
```rust
/// Creates an abort signal that can be used to cancel operations.
/// 
/// # Examples
/// ```
/// let signal = create_abort_signal();
/// assert!(!signal.aborted());
/// ```
pub fn create_abort_signal() -> AbortSignal {
    AbortSignalInner::new()
}
```

## Best Practices and Guidelines

1. Error Handling
   - Use anyhow::Result for flexible error handling
   - Provide context with .with_context()
   - Use structured error types where appropriate

2. Cross-Platform Compatibility
   - Use cfg attributes for platform-specific code
   - Abstract platform differences behind common interfaces
   - Test on all supported platforms

3. Performance Considerations
   - Use lazy_static for expensive initializations
   - Implement caching where appropriate
   - Avoid unnecessary allocations

4. Code Organization
   - Keep related functionality together
   - Use clear naming conventions
   - Maintain consistent error handling patterns

## Practical Exercises

1. Implement a new utility function that handles file size formatting:
```rust
fn format_file_size(size: u64) -> String {
    // Implementation exercise
}
```

2. Create a cross-platform path normalization function:
```rust
fn normalize_path(path: &Path) -> Result<PathBuf> {
    // Implementation exercise
}
```

3. Add a new progress indicator style:
```rust
fn create_progress_bar(total: usize) -> ProgressBar {
    // Implementation exercise
}
```

## Further Reading

- Rust standard library documentation: https://doc.rust-lang.org/std/
- Cross-platform Rust: https://rust-lang.github.io/api-guidelines/platform.html
- Error handling patterns: https://doc.rust-lang.org/book/ch09-00-error-handling.html
- Terminal manipulation: https://docs.rs/crossterm/latest/crossterm/

## Conclusion

The utilities module forms the backbone of AIChat's infrastructure, providing essential functionality used throughout the application. Understanding these utilities is crucial for maintaining and extending the application effectively while ensuring cross-platform compatibility and robust error handling.
