# Lesson 9: Agent System and Function Calling

## Introduction

This lesson explores the agent system and function calling capabilities within AIChat. The agent system represents one of the most sophisticated features of the application, combining prompts, tools, and document retrieval into a unified interface. We'll examine the implementation details, architectural decisions, and cross-platform considerations that make this system both powerful and flexible.

## Relevant Files Structure

```
src/
├── config/
│   └── agent.rs               # Agent configuration and management
├── function.rs                # Core function calling implementation
└── client/
    ├── message.rs             # Message handling for function calls
    └── common.rs              # Shared functionality for function calling
```

## Core Concepts

### Agent System Architecture

The agent system in AIChat is built around the concept of combining three key elements:
1. Instructions (Prompts)
2. Tools (Function Callings)
3. Documents (RAG - Retrieval Augmented Generation)

The implementation centers around the `Agent` struct in `config/agent.rs`, which serves as the core orchestrator for these components. The agent system maintains its own configuration, session state, and variables, allowing for complex interactions while maintaining context across conversations.

### Agent Implementation Details

The `Agent` struct contains several critical fields that manage its state and capabilities:

```rust
pub struct Agent {
    name: String,
    config: AgentConfig,
    definition: AgentDefinition,
    shared_variables: IndexMap<String, String>,
    session_variables: Option<IndexMap<String, String>>,
    functions: Functions,
    rag: Option<Arc<Rag>>,
    model: Model,
}
```

The `AgentConfig` handles agent-specific settings like model selection, temperature, and tool configurations. The `AgentDefinition` manages the core behavior definition including prompts, conversation starters, and document paths. This separation of concerns allows for flexible configuration while maintaining clean abstractions.

### Function Declaration System

The function calling system uses a JSON Schema-based approach for declaring available tools. The `FunctionDeclaration` struct in `function.rs` defines the structure:

```rust
pub struct FunctionDeclaration {
    pub name: String,
    pub description: String,
    pub parameters: JsonSchema,
    pub agent: bool,
}
```

This schema-based approach allows for:
- Strong typing of function parameters
- Clear documentation of function capabilities
- Runtime validation of function calls
- Cross-platform compatibility of function definitions

### Tool Integration Architecture

Tool integration follows a modular pattern where each tool is defined as a separate executable in the agent's function directory. The system uses a combination of environment variables and JSON for communication between the agent and tools:

1. Tools receive their input as JSON via command-line arguments
2. Tools communicate their output through a temporary file specified in the `LLM_OUTPUT` environment variable
3. The agent manages tool execution through the `eval_tool_calls` function

### Cross-Platform Execution Handling

The system implements several strategies to ensure cross-platform compatibility:

1. Path Normalization:
```rust
pub fn agent_functions_dir(name: &str) -> PathBuf {
    match env::var(format!("{}_FUNCTIONS_DIR", normalize_env_name(name))) {
        Ok(value) => PathBuf::from(value),
        Err(_) => Self::agents_functions_dir().join(name),
    }
}
```

2. Shell Detection:
```rust
pub fn detect_shell() -> Shell {
    if cfg!(windows) {
        // Windows-specific shell detection logic
    } else {
        // Unix-like shell detection logic
    }
}
```

3. Tool Execution:
```rust
#[cfg(windows)]
fn polyfill_cmd_name<T: AsRef<Path>>(cmd_name: &str, bin_dir: &[T]) -> String {
    // Windows-specific command name handling
}
```

### Variable Management

The agent system implements a sophisticated variable management system that handles both shared and session-specific variables:

```rust
pub fn init_agent_variables(
    agent_variables: &[AgentVariable],
    variables: &IndexMap<String, String>,
) -> Result<IndexMap<String, String>>
```

This system allows for:
- Persistent variable storage across sessions
- Dynamic variable updates during execution
- Proper scoping of variables between shared and session contexts
- Type-safe variable access and modification

### Error Handling and Recovery

The agent system implements comprehensive error handling using Rust's Result type and custom error types. Key aspects include:

1. Graceful degradation when tools fail
2. Clear error messages for configuration issues
3. Recovery mechanisms for interrupted sessions
4. Proper cleanup of temporary resources

Example error handling pattern:
```rust
pub fn eval_tool_calls(config: &GlobalConfig, mut calls: Vec<ToolCall>) -> Result<Vec<ToolResult>> {
    let mut output = vec![];
    if calls.is_empty() {
        return Ok(output);
    }
    calls = ToolCall::dedup(calls);
    if calls.is_empty() {
        bail!("The request was aborted because an infinite loop of function calls was detected.")
    }
    // ... error handling for tool execution
}
```

## Security Considerations

The agent system implements several security measures:

1. Tool Isolation: Each tool runs as a separate process with its own environment
2. Input Validation: All function parameters are validated against their JSON schema
3. Resource Limits: Tools are executed with appropriate timeouts and resource constraints
4. Path Sanitization: All file paths are properly sanitized and validated

## Best Practices and Implementation Guidelines

When working with the agent system, consider these best practices:

1. Tool Development
   - Implement proper error handling and status codes
   - Use structured logging for debugging
   - Validate all inputs before processing
   - Implement proper cleanup in case of failures

2. Agent Configuration
   - Keep prompts focused and specific
   - Implement proper variable validation
   - Use appropriate model settings for the task
   - Document tool dependencies and requirements

3. Error Handling
   - Implement proper error propagation
   - Provide clear error messages
   - Clean up resources in case of failures
   - Log errors appropriately for debugging

## Practical Exercises

1. Implement a New Tool
Create a new tool that integrates with the agent system:
```rust
#[derive(Parser, Debug)]
struct ToolArgs {
    input: String,
    #[clap(long)]
    output: String,
}

fn main() -> Result<()> {
    let args = ToolArgs::parse();
    // Tool implementation
    // Write output using LLM_OUTPUT environment variable
}
```

2. Extend Agent Configuration
Add new capabilities to an existing agent:
```yaml
name: enhanced_agent
description: "Enhanced capabilities agent"
version: "1.0"
instructions: |
  Enhanced agent with new capabilities
variables:
  - name: API_KEY
    description: "API key for external service"
conversation_starters:
  - "What can you help me with?"
documents:
  - "docs/**/*.md"
```

3. Implement Error Recovery
Add error recovery mechanisms to tool execution:
```rust
pub fn safe_tool_execution(tool: &Tool) -> Result<Output> {
    let result = tool.execute()?;
    if !result.success() {
        // Implement recovery mechanism
    }
    Ok(result)
}
```

## Advanced Topics

1. Custom Tool Frameworks
   - Implementing tool-specific configuration
   - Creating tool templates
   - Managing tool dependencies
   - Cross-platform tool development

2. State Management
   - Implementing persistent storage
   - Managing concurrent tool execution
   - Handling session recovery
   - Variable scope management

3. Performance Optimization
   - Tool execution caching
   - Resource pooling
   - Parallel tool execution
   - Output buffering

## Conclusion

The agent system and function calling capabilities in AIChat demonstrate sophisticated software design patterns while maintaining flexibility and usability. Understanding these systems provides valuable insights into building complex, cross-platform CLI applications with AI integration.

