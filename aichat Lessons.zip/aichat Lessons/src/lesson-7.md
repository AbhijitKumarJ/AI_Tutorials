# Lesson 7: HTTP Server Implementation in AIChat

## Introduction

This lesson explores the HTTP server implementation in AIChat, which provides API endpoints for chat completions, embeddings, and reranking, along with web interfaces for LLM interaction. The server component is primarily implemented in `src/serve.rs` with supporting utilities throughout the codebase. Understanding this implementation provides insights into building robust HTTP servers that interface with LLM APIs while maintaining proper error handling and response streaming.

## Files Layout

The server implementation primarily involves these files:
```
src/
├── serve.rs                 # Main server implementation
├── client/
│   ├── common.rs           # Common client interfaces
│   └── stream.rs           # Streaming functionality
└── utils/
    └── request.rs          # HTTP request utilities
```

## Core Server Architecture

The server implementation in `serve.rs` follows a modular design pattern centered around the `Server` struct. This structure maintains the configuration state and handles incoming HTTP requests through a router-like pattern. The server supports both synchronous and streaming responses, making it suitable for various LLM interaction patterns.

The server initialization begins in the `run` function, which sets up the TCP listener and spawns a new task for each incoming connection. This implementation uses Tokio for async I/O operations and Hyper for HTTP protocol handling. The server supports graceful shutdown through a shutdown signal handler, ensuring all ongoing operations complete properly before termination.

## Request Handling Flow

The request handling follows a clear pattern in the `handle` function:

1. CORS handling through OPTIONS requests
2. Route matching based on URI paths
3. Request processing based on the matched route
4. Response formatting and error handling
5. Adding appropriate headers to responses

Let's examine a key code section from `serve.rs` that demonstrates this flow:

```rust
async fn handle(
    self: Arc<Self>,
    req: hyper::Request<Incoming>,
) -> std::result::Result<AppResponse, hyper::Error> {
    let method = req.method().clone();
    let uri = req.uri().clone();
    let path = uri.path();

    if method == Method::OPTIONS {
        let mut res = Response::default();
        *res.status_mut() = StatusCode::NO_CONTENT;
        set_cors_header(&mut res);
        return Ok(res);
    }

    let mut status = StatusCode::OK;
    let res = match path {
        "/v1/chat/completions" => self.chat_completions(req).await,
        "/v1/embeddings" => self.embeddings(req).await,
        "/v1/rerank" => self.rerank(req).await,
        // ... other routes
        _ => {
            status = StatusCode::NOT_FOUND;
            Err(anyhow!("Not Found"))
        }
    };
    
    // Response processing
    let mut res = match res {
        Ok(res) => {
            info!("{method} {uri} {}", status.as_u16());
            res
        }
        Err(err) => {
            if status == StatusCode::OK {
                status = StatusCode::BAD_REQUEST;
            }
            error!("{method} {uri} {} {err}", status.as_u16());
            ret_err(err)
        }
    };
    *res.status_mut() = status;
    set_cors_header(&mut res);
    Ok(res)
}
```

## API Endpoints Implementation

### Chat Completions Endpoint

The chat completions endpoint (`/v1/chat/completions`) is the most complex implementation, supporting both streaming and non-streaming responses. The endpoint handles:

1. Request validation and parsing
2. Model selection and configuration
3. Token management and counting
4. Stream processing for real-time responses
5. Error handling and status reporting

The implementation leverages the `ChatCompletionsData` struct to manage request data and the `SseHandler` for streaming responses. The streaming implementation is particularly interesting as it manages both text outputs and function calling results through a unified interface.

### Embeddings Endpoint

The embeddings endpoint (`/v1/embeddings`) provides vector representations of input texts. This implementation:

1. Validates input format (single string or array of strings)
2. Processes inputs through the selected embedding model
3. Returns normalized vector representations
4. Handles batch processing efficiently

### Rerank Endpoint

The rerank endpoint (`/v1/rerank`) implements document reranking functionality, using:

1. Query and document validation
2. Relevance scoring computation
3. Result sorting and ranking
4. Top-N selection implementation

## Web Interfaces

### Playground Implementation

The playground interface provides a web-based UI for interaction with the LLM APIs. The implementation includes:

1. Static file serving for HTML/CSS/JS assets
2. WebSocket handling for real-time updates
3. Model selection and configuration interface
4. Response visualization and formatting

### Arena Implementation

The arena interface enables side-by-side comparison of different models. Key features include:

1. Multiple model selection and configuration
2. Parallel request processing
3. Response comparison visualization
4. Performance metrics display

## Error Handling and Response Formatting

The server implements robust error handling through the `ret_err` function, which transforms internal errors into appropriate HTTP responses. The error handling system:

1. Maps internal error types to HTTP status codes
2. Formats error messages for API consumers
3. Maintains consistent error response structure
4. Provides detailed logging for debugging

Example error response structure:
```json
{
    "error": {
        "message": "Detailed error message",
        "type": "invalid_request_error"
    }
}
```

## Streaming Implementation

The streaming implementation uses Server-Sent Events (SSE) for real-time communication. The implementation includes:

1. Stream initialization and connection management
2. Chunk encoding and transmission
3. Keep-alive handling
4. Error handling during streaming
5. Clean stream termination

Key streaming code example:
```rust
pub async fn chat_completions_streaming(
    builder: RequestBuilder,
    handler: &mut SseHandler,
    model: &Model,
) -> Result<()> {
    let res = builder.send().await?;
    let status = res.status();
    if !status.is_success() {
        let data: Value = res.json().await?;
        catch_error(&data, status.as_u16())?;
    } else {
        let handle = |message: SseMmessage| -> Result<bool> {
            // Stream processing logic
            Ok(false)
        };
        sse_stream(builder, handle).await?;
    }
    Ok(())
}
```

## Cross-Platform Considerations

The server implementation takes into account various cross-platform considerations:

1. Path handling for different operating systems
2. File system access patterns
3. Network interface binding
4. Process management
5. Resource cleanup

## Performance Optimization

Several performance optimizations are implemented:

1. Connection pooling for backend API calls
2. Request batching where appropriate
3. Efficient memory management for streams
4. Proper resource cleanup
5. Caching strategies for static content

## Testing Strategy

The server implementation includes comprehensive testing:

1. Unit tests for individual components
2. Integration tests for API endpoints
3. Load testing for performance verification
4. Cross-platform compatibility testing
5. Error handling verification

## Security Considerations

The server implementation includes several security measures:

1. Input validation and sanitization
2. Rate limiting capability
3. API key validation
4. CORS policy implementation
5. Error message sanitization

## Exercises and Practice

To reinforce understanding, try these exercises:

1. Implement a new API endpoint following the existing patterns
2. Add a new streaming feature to the chat completions endpoint
3. Implement additional error handling cases
4. Add new performance optimizations
5. Create new test cases for existing functionality

## Conclusion

The HTTP server implementation in AIChat demonstrates a robust approach to building a scalable and maintainable API server. Understanding this implementation provides valuable insights into:

1. Proper HTTP server architecture
2. Streaming response handling
3. Error management and reporting
4. Cross-platform compatibility
5. Performance optimization techniques

This knowledge can be applied to building similar systems or extending the current implementation with new features and capabilities.