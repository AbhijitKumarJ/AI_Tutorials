# AIChat Lesson 4: REPL Implementation Deep Dive

## Introduction

The REPL (Read-Eval-Print Loop) is one of AIChat's core features, providing an interactive environment for users to engage with various LLMs. This lesson explores the sophisticated REPL implementation, covering its architecture, command handling, input processing, and cross-platform considerations.

## File Structure Overview

The REPL implementation is primarily contained within the `repl` directory:

```
src/repl/
├── mod.rs           # Main REPL module and core implementation
├── completer.rs     # Tab completion implementation
├── highlighter.rs   # Syntax highlighting for input/output
└── prompt.rs        # Custom prompt handling
```

## Core REPL Architecture

The REPL system is built around the `Repl` struct in `repl/mod.rs`, which coordinates various components:

```rust
pub struct Repl {
    config: GlobalConfig,
    editor: Reedline,
    prompt: ReplPrompt,
    abort_signal: AbortSignal,
}
```

### Initialization Process

The REPL initialization follows a careful sequence:

```rust
impl Repl {
    pub fn init(config: &GlobalConfig) -> Result<Self> {
        let editor = Self::create_editor(config)?;
        let prompt = ReplPrompt::new(config);
        let abort_signal = create_abort_signal();

        Ok(Self {
            config: config.clone(),
            editor,
            prompt,
            abort_signal,
        })
    }
}
```

### Main Loop Implementation

The REPL's main loop is implemented in the `run` method:

```rust
pub async fn run(&mut self) -> Result<()> {
    self.banner();

    loop {
        if self.abort_signal.aborted_ctrld() {
            break;
        }
        let sig = self.editor.read_line(&self.prompt);
        match sig {
            Ok(Signal::Success(line)) => {
                self.abort_signal.reset();
                match self.handle(&line).await {
                    Ok(exit) => {
                        if exit {
                            break;
                        }
                    }
                    Err(err) => {
                        render_error(err);
                        println!()
                    }
                }
            }
            Ok(Signal::CtrlC) => {
                self.abort_signal.set_ctrlc();
                println!("(To exit, press Ctrl+D or enter \".exit\")\n");
            }
            Ok(Signal::CtrlD) => {
                self.abort_signal.set_ctrld();
                break;
            }
            _ => {}
        }
    }
    self.handle(".exit session").await?;
    Ok(())
}
```

## Command Processing System

### Command Structure

Commands are defined using the `ReplCommand` struct:

```rust
pub struct ReplCommand {
    name: &'static str,
    description: &'static str,
    state: AssertState,
}
```

### Command Parsing

The command parsing system uses regular expressions to identify and parse commands:

```rust
fn parse_command(line: &str) -> Option<(&str, Option<&str>)> {
    match COMMAND_RE.captures(line) {
        Ok(Some(captures)) => {
            let cmd = captures.get(1)?.as_str();
            let args = line[captures[0].len()..].trim();
            let args = if args.is_empty() { None } else { Some(args) };
            Some((cmd, args))
        }
        _ => None,
    }
}
```

## Input Handling and Completion

### Tab Completion

The completion system is implemented in `completer.rs` using the `ReplCompleter` struct:

```rust
pub struct ReplCompleter {
    config: GlobalConfig,
    commands: Vec<ReplCommand>,
    groups: HashMap<&'static str, usize>,
}
```

The completion logic handles various types of completions:

1. Command completions
2. Argument completions
3. File path completions
4. Variable name completions

### Input Validation

Input validation is handled by the `ReplValidator` struct:

```rust
struct ReplValidator;

impl Validator for ReplValidator {
    fn validate(&self, line: &str) -> ValidationResult {
        let line = line.trim();
        if line.starts_with(r#":::"#) && !line[3..].ends_with(r#":::"#) {
            ValidationResult::Incomplete
        } else {
            ValidationResult::Complete
        }
    }
}
```

## Syntax Highlighting

The syntax highlighting system in `highlighter.rs` provides real-time coloring of input:

```rust
pub struct ReplHighlighter;

impl Highlighter for ReplHighlighter {
    fn highlight(&self, line: &str, _cursor: usize) -> StyledText {
        let mut styled_text = StyledText::new();

        if *NO_COLOR {
            styled_text.push((Style::default(), line.to_string()));
        } else if REPL_COMMANDS.iter().any(|cmd| line.contains(cmd.name)) {
            // Command highlighting logic
            // ...
        } else {
            styled_text.push((Style::new().fg(DEFAULT_COLOR), line.to_string()));
        }

        styled_text
    }
}
```

## Custom Prompt System

The prompt system in `prompt.rs` allows for dynamic prompt generation:

```rust
pub struct ReplPrompt {
    config: GlobalConfig,
}

impl Prompt for ReplPrompt {
    fn render_prompt_left(&self) -> Cow<str> {
        Cow::Owned(self.config.read().render_prompt_left())
    }

    fn render_prompt_right(&self) -> Cow<str> {
        Cow::Owned(self.config.read().render_prompt_right())
    }
}
```

## History Management

The REPL maintains command history through the Reedline library:

1. Persistent history storage
2. History search functionality
3. History deduplication
4. Cross-session history

## Cross-Platform Considerations

### Terminal Handling

The REPL handles different terminal capabilities across platforms:

```rust
#[cfg(windows)]
const PATH_SEP: &str = ";";
#[cfg(not(windows))]
const PATH_SEP: &str = ":";

#[cfg(target_os = "windows")]
fn get_terminal_size() -> (u16, u16) {
    // Windows-specific implementation
}

#[cfg(unix)]
fn get_terminal_size() -> (u16, u16) {
    // Unix-specific implementation
}
```

### Key Binding System

The REPL supports multiple keybinding modes:

```rust
fn create_edit_mode(config: &GlobalConfig) -> Box<dyn EditMode> {
    let edit_mode: Box<dyn EditMode> = if config.read().keybindings == "vi" {
        let mut normal_keybindings = default_vi_normal_keybindings();
        let mut insert_keybindings = default_vi_insert_keybindings();
        Self::extra_keybindings(&mut normal_keybindings);
        Self::extra_keybindings(&mut insert_keybindings);
        Box::new(Vi::new(insert_keybindings, normal_keybindings))
    } else {
        let mut keybindings = default_emacs_keybindings();
        Self::extra_keybindings(&mut keybindings);
        Box::new(Emacs::new(keybindings))
    };
    edit_mode
}
```

## Error Handling and Recovery

The REPL implements robust error handling:

```rust
fn handle_error(&self, err: Error) {
    render_error(err);
    if self.abort_signal.aborted() {
        println!("Operation aborted.");
    }
}
```

## State Management Integration

The REPL integrates with the global state management system:

1. Configuration access
2. Session management
3. Role handling
4. Agent interaction

## Practical Examples

### Implementing a Custom Command

```rust
fn implement_custom_command() {
    let command = ReplCommand::new(
        ".custom",
        "Custom command description",
        AssertState::pass(),
    );
    // Implementation
}
```

### Adding Custom Completion

```rust
fn add_custom_completion(&mut self, text: &str) -> Vec<Suggestion> {
    // Custom completion logic
    vec![
        Suggestion {
            value: "completion".to_string(),
            description: Some("Description".to_string()),
            style: None,
            extra: None,
            span: Span::new(0, text.len()),
            append_whitespace: false,
        }
    ]
}
```

## Best Practices

1. Always handle terminal capabilities appropriately
2. Implement proper error recovery
3. Maintain consistent command syntax
4. Handle user interrupts gracefully
5. Provide helpful error messages
6. Implement efficient completion
7. Maintain state consistency

## Common Pitfalls

1. Incorrect handling of terminal width
2. Memory leaks in history management
3. Incomplete error handling
4. Inefficient completion implementations
5. Poor cross-platform compatibility
6. Inconsistent state management
7. Missing input validation

## Exercises

1. Implement a new REPL command
2. Create a custom completion provider
3. Add a new keybinding mode
4. Implement a custom prompt format
5. Create a history management feature
6. Add a new syntax highlighting rule
7. Implement a custom validator

## Advanced Topics

### Custom Keybindings

```rust
fn implement_custom_keybindings(keybindings: &mut Keybindings) {
    keybindings.add_binding(
        KeyModifiers::CONTROL,
        KeyCode::Enter,
        ReedlineEvent::Edit(vec![EditCommand::InsertNewline]),
    );
}
```

### Multi-line Editing

```rust
fn handle_multiline(&mut self, content: &str) -> Result<String> {
    if content.starts_with(":::") {
        // Multi-line handling logic
    }
    Ok(content.to_string())
}
```

### Custom Completion Menu

```rust
fn create_menu() -> ReedlineMenu {
    let completion_menu = ColumnarMenu::default()
        .with_name(MENU_NAME)
        .with_columns(2);
    ReedlineMenu::EngineCompleter(Box::new(completion_menu))
}
```

## Conclusion

Understanding AIChat's REPL implementation is crucial for both using and extending the application. The system's design provides a robust and user-friendly interface while maintaining cross-platform compatibility and extensibility.

The next lesson will explore the RAG (Retrieval-Augmented Generation) system, building on the knowledge of REPL implementation covered here.

## Additional Resources

1. Reedline documentation
2. Terminal handling best practices
3. Cross-platform development guides
4. ANSI escape code references
5. Rust async programming patterns
6. Error handling patterns
7. State management strategies