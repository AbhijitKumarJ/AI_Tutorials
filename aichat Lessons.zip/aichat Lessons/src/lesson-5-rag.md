# Lesson 5: Understanding AIChat's RAG System Implementation

## Overview

This lesson explores AIChat's Retrieval-Augmented Generation (RAG) system, which enables the application to enhance LLM responses with relevant information from external documents. We'll examine the implementation details found in the `src/rag` directory and related components, understanding how AIChat manages document processing, vector storage, and retrieval operations.

## Directory Structure

The RAG system's core components are organized as follows:

```
src/rag/
├── loader.rs       # Document loading and processing
├── mod.rs         # Core RAG implementation
├── serde_vectors.rs # Vector serialization utilities
└── splitter/
    ├── language.rs # Language-specific splitting rules
    └── mod.rs     # Text splitting implementation
```

## Core RAG Components

The RAG system is built around several key structures defined in `mod.rs`:

### Rag Structure

The `Rag` struct serves as the main entry point for RAG functionality:

```rust
pub struct Rag {
    config: GlobalConfig,
    name: String,
    path: String,
    embedding_model: Model,
    hnsw: Hnsw<'static, f32, DistCosine>,
    bm25: SearchEngine<DocumentId>,
    data: RagData,
    last_sources: RwLock<Option<String>>,
}
```

This structure encapsulates all necessary components for document processing, embedding generation, and search functionality. The HNSW (Hierarchical Navigable Small World) index provides efficient similarity search capabilities, while BM25 offers traditional keyword-based search.

## Document Processing Pipeline

### 1. Document Loading

The document loading system, implemented in `loader.rs`, supports various file formats and sources:

- Local files with different extensions (PDF, DOCX, MD, etc.)
- Remote URLs and web pages
- Directory traversal with glob pattern support
- Custom document loaders for specific file formats

Example of the document loading process:

```rust
pub async fn load_document(
    loaders: &HashMap<String, String>,
    path: &str,
    has_error: &mut bool,
) -> (String, Vec<(String, RagMetadata)>) {
    // Implementation handles different source types and formats
}
```

### 2. Text Splitting

The text splitting system, implemented in `splitter/mod.rs`, uses the RecursiveCharacterTextSplitter to divide documents into manageable chunks:

```rust
pub struct RecursiveCharacterTextSplitter {
    pub chunk_size: usize,
    pub chunk_overlap: usize,
    pub separators: Vec<String>,
    pub length_function: Box<dyn Fn(&str) -> usize + Send + Sync>,
}
```

The splitter supports:
- Configurable chunk sizes and overlap
- Language-specific splitting rules
- Smart separation based on document structure
- Metadata preservation for chunks

### 3. Vector Storage

Vector storage is handled through the `RagData` structure, which maintains:
- Document metadata
- Embedding vectors
- Document mappings
- Search indices

The system uses efficient serialization through `serde_vectors.rs` to manage large vector datasets:

```rust
pub fn serialize<S>(
    vectors: &IndexMap<DocumentId, Vec<f32>>,
    serializer: S,
) -> Result<S::Ok, S::Error>
where
    S: Serializer
```

## Search and Retrieval System

The search system implements a hybrid approach combining:

1. Vector Similarity Search:
```rust
async fn vector_search(
    &self,
    query: &str,
    top_k: usize,
    min_score: f32,
) -> Result<Vec<(DocumentId, f32)>>
```

2. Keyword Search:
```rust
async fn keyword_search(
    &self,
    query: &str,
    top_k: usize,
    min_score: f32,
) -> Result<Vec<(DocumentId, f32)>>
```

3. Hybrid Results Fusion:
```rust
fn reciprocal_rank_fusion(
    list_of_document_ids: Vec<Vec<DocumentId>>,
    list_of_weights: Vec<f32>,
    top_k: usize,
) -> Vec<DocumentId>
```

## Configuration Management

The RAG system is highly configurable through the config file:

```yaml
rag_embedding_model: null        # Embedding model specification
rag_reranker_model: null        # Reranking model specification
rag_top_k: 5                    # Number of results to retrieve
rag_chunk_size: null            # Document chunk size
rag_chunk_overlap: null         # Overlap between chunks
rag_min_score_vector_search: 0  # Minimum vector search score
rag_min_score_keyword_search: 0 # Minimum keyword search score
```

## Cross-Platform Considerations

The RAG system handles cross-platform compatibility through:

1. Path Normalization:
```rust
pub fn safe_join_path<T1: AsRef<Path>, T2: AsRef<Path>>(
    base_path: T1,
    sub_path: T2,
) -> Option<PathBuf>
```

2. File System Operations:
```rust
async fn list_files(
    files: &mut Vec<String>,
    entry_path: &Path,
    suffixes: Option<&Vec<String>>,
) -> Result<()>
```

## Error Handling

The RAG system implements robust error handling:

1. Custom Error Types
2. Result propagation
3. Proper cleanup on failures
4. Informative error messages

## Performance Optimizations

Several optimizations are implemented:

1. Batch Processing:
```rust
pub async fn create_embeddings(
    &self,
    data: EmbeddingsData,
    spinner: Option<Spinner>,
) -> Result<EmbeddingsOutput>
```

2. Parallel Processing:
```rust
let tasks: Vec<_> = batch
    .iter()
    .map(|path| {
        let options = options.clone();
        let permit = semaphore.clone().acquire_owned();
        async move {
            // Implementation
        }
    })
    .collect();
```

3. Efficient Vector Storage and Retrieval

## Practical Exercises

1. Document Loading
   - Implement a custom document loader for a new file format
   - Add support for a new remote source type

2. Text Splitting
   - Implement a new language-specific splitter
   - Optimize chunk size for specific use cases

3. Search Implementation
   - Implement a new search algorithm
   - Optimize search parameters for specific scenarios

4. Performance Testing
   - Benchmark different chunk sizes
   - Test search performance with various dataset sizes

## Common Pitfalls and Solutions

1. Memory Management
   - Large document handling
   - Efficient vector storage

2. Error Handling
   - Graceful failure recovery
   - User feedback

3. Performance
   - Batch size optimization
   - Search parameter tuning

## Best Practices

1. Document Processing
   - Validate input formats
   - Implement proper cleanup
   - Handle encoding correctly

2. Vector Operations
   - Use appropriate vector dimensions
   - Implement efficient serialization
   - Optimize storage formats

3. Search Implementation
   - Balance accuracy and performance
   - Implement proper caching
   - Handle edge cases

## Additional Resources

1. Related Documentation
   - RAG Guide in the wiki
   - Configuration Guide
   - API Documentation

2. External References
   - Vector Search Algorithms
   - Text Processing Techniques
   - Embedding Models

## Next Steps

After completing this lesson, you should be able to:

1. Understand AIChat's RAG implementation
2. Implement new document processors
3. Optimize search functionality
4. Debug RAG-related issues
5. Contribute improvements to the RAG system

## Review Questions

1. How does AIChat's RAG system handle different document formats?
2. What are the key components of the vector search implementation?
3. How does the hybrid search system combine different search methods?
4. What role does configuration play in RAG system behavior?
5. How does the system handle cross-platform compatibility?
