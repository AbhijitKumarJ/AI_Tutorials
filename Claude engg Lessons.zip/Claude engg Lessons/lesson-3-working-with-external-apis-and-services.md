# Lesson 3: Working with External APIs and Services

In this lesson, we'll explore how to work with external APIs and services in the context of CLI tool development. This is a crucial skill for creating tools that can interact with web services, databases, and other external systems.

## 1. Introduction to API integration

API (Application Programming Interface) integration is the process of incorporating external services or data sources into your application. For CLI tools, this often means making HTTP requests to web APIs to retrieve or send data.

Key concepts in API integration:

1. **Endpoints**: Specific URLs that represent different functions of an API.
2. **HTTP Methods**: GET (retrieve data), POST (send data), PUT (update data), DELETE (remove data), etc.
3. **Authentication**: Many APIs require some form of authentication, such as API keys or OAuth tokens.
4. **Request and Response Formats**: Common formats include JSON and XML.

Example of a simple API request using the `requests` library:

```python
import requests

def get_weather(city):
    api_key = "your_api_key_here"
    base_url = "http://api.openweathermap.org/data/2.5/weather"
    params = {
        "q": city,
        "appid": api_key,
        "units": "metric"
    }
    response = requests.get(base_url, params=params)
    if response.status_code == 200:
        data = response.json()
        return f"The temperature in {city} is {data['main']['temp']}°C"
    else:
        return f"Error: Unable to fetch weather data for {city}"

print(get_weather("London"))
```

This example demonstrates a basic API integration, making a GET request to the OpenWeatherMap API and parsing the JSON response.

## 2. Using environment variables for secure API key management

When working with APIs that require authentication, it's crucial to manage your API keys securely. Storing keys directly in your code is a security risk, especially if your code is version-controlled or shared.

Environment variables provide a secure way to store sensitive information:

1. They keep sensitive data out of your codebase.
2. They allow for easy configuration changes without modifying code.
3. They reduce the risk of accidentally exposing secrets.

### Setting up environment variables:

1. Create a `.env` file in your project root:
   ```
   API_KEY=your_actual_api_key_here
   ```

2. Use the `python-dotenv` library to load these variables:

   ```python
   from dotenv import load_dotenv
   import os

   load_dotenv()  # Load variables from .env file

   api_key = os.getenv("API_KEY")
   ```

3. Make sure to add `.env` to your `.gitignore` file to prevent it from being committed to version control.

Example usage in a CLI tool:

```python
import os
from dotenv import load_dotenv
import requests
import sys

load_dotenv()

API_KEY = os.getenv("WEATHER_API_KEY")
if not API_KEY:
    print("Error: WEATHER_API_KEY not found in environment variables")
    sys.exit(1)

def get_weather(city):
    base_url = "http://api.openweathermap.org/data/2.5/weather"
    params = {
        "q": city,
        "appid": API_KEY,
        "units": "metric"
    }
    response = requests.get(base_url, params=params)
    if response.status_code == 200:
        data = response.json()
        return f"The temperature in {city} is {data['main']['temp']}°C"
    else:
        return f"Error: Unable to fetch weather data for {city}"

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python weather_cli.py <city>")
        sys.exit(1)
    
    city = sys.argv[1]
    print(get_weather(city))
```

This example demonstrates how to use environment variables to securely store and access an API key in a CLI tool.

## 3. Making API requests with the `aiohttp` library

While the `requests` library is great for synchronous API calls, `aiohttp` is preferred for asynchronous operations, which can significantly improve performance when making multiple API calls.

Here's an example of using `aiohttp` to make concurrent API requests:

```python
import asyncio
import aiohttp
from dotenv import load_dotenv
import os

load_dotenv()

API_KEY = os.getenv("WEATHER_API_KEY")

async def get_weather(session, city):
    base_url = "http://api.openweathermap.org/data/2.5/weather"
    params = {
        "q": city,
        "appid": API_KEY,
        "units": "metric"
    }
    async with session.get(base_url, params=params) as response:
        if response.status == 200:
            data = await response.json()
            return f"The temperature in {city} is {data['main']['temp']}°C"
        else:
            return f"Error: Unable to fetch weather data for {city}"

async def main(cities):
    async with aiohttp.ClientSession() as session:
        tasks = [get_weather(session, city) for city in cities]
        results = await asyncio.gather(*tasks)
        for result in results:
            print(result)

if __name__ == "__main__":
    cities = ["London", "New York", "Tokyo", "Sydney", "Moscow"]
    asyncio.run(main(cities))
```

This example demonstrates how to use `aiohttp` to make concurrent API requests, which is particularly useful when you need to fetch data from multiple sources or for multiple entities.

## 4. Integrating Anthropic's Claude API

The Claude Engineer project uses Anthropic's Claude API for natural language processing tasks. Here's an example of how to integrate and use the Claude API in a CLI tool:

```python
import os
from dotenv import load_dotenv
from anthropic import Anthropic, HUMAN_PROMPT, AI_PROMPT
import asyncio

load_dotenv()

API_KEY = os.getenv("ANTHROPIC_API_KEY")
if not API_KEY:
    raise ValueError("ANTHROPIC_API_KEY not found in environment variables")

anthropic = Anthropic(api_key=API_KEY)

async def get_claude_response(prompt):
    try:
        response = await anthropic.completions.create(
            model="claude-2.0",
            max_tokens_to_sample=300,
            prompt=f"{HUMAN_PROMPT} {prompt}{AI_PROMPT}",
        )
        return response.completion
    except Exception as e:
        return f"Error: {str(e)}"

async def main():
    while True:
        user_input = input("You: ")
        if user_input.lower() == 'exit':
            break
        response = await get_claude_response(user_input)
        print(f"Claude: {response}")

if __name__ == "__main__":
    asyncio.run(main())
```

This example creates a simple CLI chat interface using the Claude API. It demonstrates:
1. Setting up the Anthropic client with an API key from environment variables.
2. Making asynchronous API calls to Claude.
3. Handling user input and displaying responses in a loop.

## 5. Integrating Tavily API for web searches

The Claude Engineer project uses the Tavily API for web searches. Here's an example of how to integrate and use the Tavily API in a CLI tool:

```python
import os
from dotenv import load_dotenv
from tavily import TavilyClient
import asyncio

load_dotenv()

API_KEY = os.getenv("TAVILY_API_KEY")
if not API_KEY:
    raise ValueError("TAVILY_API_KEY not found in environment variables")

tavily = TavilyClient(api_key=API_KEY)

async def tavily_search(query):
    try:
        response = await asyncio.to_thread(tavily.search, query=query, search_depth="advanced")
        return response
    except Exception as e:
        return f"Error performing search: {str(e)}"

async def main():
    while True:
        query = input("Enter your search query (or 'exit' to quit): ")
        if query.lower() == 'exit':
            break
        results = await tavily_search(query)
        if isinstance(results, str):
            print(results)  # This is an error message
        else:
            print("\nSearch Results:")
            for i, result in enumerate(results['results'], 1):
                print(f"{i}. {result['title']}")
                print(f"   URL: {result['url']}")
                print(f"   Snippet: {result['snippet']}\n")

if __name__ == "__main__":
    asyncio.run(main())
```

This example creates a simple CLI search interface using the Tavily API. It demonstrates:
1. Setting up the Tavily client with an API key from environment variables.
2. Making asynchronous API calls to Tavily using `asyncio.to_thread()` since the Tavily client is synchronous.
3. Handling user input for search queries and displaying results in a formatted manner.

## 6. Handling rate limits and API errors

When working with external APIs, it's crucial to handle rate limits and various API errors gracefully. This ensures your CLI tool remains robust and user-friendly even when facing network issues or API restrictions.

Here's an example that demonstrates how to handle rate limits and API errors:

```python
import aiohttp
import asyncio
import time
from dotenv import load_dotenv
import os

load_dotenv()

API_KEY = os.getenv("EXAMPLE_API_KEY")
BASE_URL = "https://api.example.com/v1"

async def make_api_request(session, endpoint, params=None):
    url = f"{BASE_URL}/{endpoint}"
    headers = {"Authorization": f"Bearer {API_KEY}"}
    max_retries = 3
    retry_delay = 1

    for attempt in range(max_retries):
        try:
            async with session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    return await response.json()
                elif response.status == 429:  # Too Many Requests
                    retry_after = int(response.headers.get("Retry-After", retry_delay))
                    print(f"Rate limit hit. Retrying in {retry_after} seconds...")
                    await asyncio.sleep(retry_after)
                elif response.status == 401:  # Unauthorized
                    raise ValueError("Invalid API key. Please check your credentials.")
                elif response.status == 404:  # Not Found
                    raise ValueError(f"Endpoint not found: {endpoint}")
                else:
                    raise aiohttp.ClientResponseError(
                        response.request_info,
                        response.history,
                        status=response.status,
                        message=f"HTTP Error {response.status}: {response.reason}",
                        headers=response.headers,
                    )
        except aiohttp.ClientError as e:
            if attempt == max_retries - 1:
                raise
            print(f"Network error occurred: {str(e)}. Retrying in {retry_delay} seconds...")
            await asyncio.sleep(retry_delay)
            retry_delay *= 2  # Exponential backoff

    raise Exception(f"Failed to get response after {max_retries} attempts")

async def main():
    async with aiohttp.ClientSession() as session:
        try:
            data = await make_api_request(session, "users")
            print("API Response:", data)
        except ValueError as e:
            print(f"Error: {str(e)}")
        except aiohttp.ClientResponseError as e:
            print(f"API Error: {e.status} - {e.message}")
        except Exception as e:
            print(f"An unexpected error occurred: {str(e)}")

if __name__ == "__main__":
    asyncio.run(main())
```

This example demonstrates several important concepts for handling API errors and rate limits:

1. **Retry Mechanism**: The function attempts to make the API request up to a maximum number of times (3 in this case) before giving up.

2. **Rate Limit Handling**: If a 429 (Too Many Requests) status is received, the function waits for the time specified in the "Retry-After" header before retrying.

3. **Exponential Backoff**: The retry delay doubles after each failed attempt, reducing the load on the server during periods of high traffic or errors.

4. **Specific Error Handling**: Different HTTP status codes are handled separately, providing more informative error messages to the user.

5. **Network Error Handling**: Catches and retries on network-related errors, improving resilience against temporary network issues.

6. **Clear User Feedback**: Prints informative messages about retries and errors, keeping the user informed about what's happening.

By implementing these error handling and rate limiting strategies, you can create more robust CLI tools that gracefully handle various API-related issues, providing a better user experience and reducing the chances of unexpected crashes or behavior.

## Conclusion

Working with external APIs and services is a crucial skill for developing powerful CLI tools. By understanding how to integrate APIs, manage authentication securely, make efficient asynchronous requests, and handle errors gracefully, you can create tools that leverage the vast capabilities of various web services and APIs.

Remember to always refer to the specific documentation of the APIs you're working with, as they may have unique requirements or best practices. Additionally, consider implementing caching mechanisms for frequently accessed data to reduce API calls and improve your tool's performance.

In the next lesson, we'll explore how to build interactive CLI interfaces, which will allow us to present the data we've retrieved from these APIs in a user-friendly manner.

