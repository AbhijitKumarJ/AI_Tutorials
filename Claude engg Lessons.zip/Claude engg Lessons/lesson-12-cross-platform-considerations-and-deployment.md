# Lesson 12: Cross-Platform Considerations and Deployment

## Introduction

In this lesson, we'll dive deep into the cross-platform considerations and deployment strategies for the Claude Engineer project. As a Python-based CLI tool that integrates with various APIs and performs complex operations, ensuring that our application works seamlessly across different operating systems is crucial. We'll also explore how to package and distribute the application, making it easy for users to install and run on their systems.

## Learning Objectives

By the end of this lesson, you will be able to:

1. Understand and handle platform-specific differences in Windows, macOS, and Linux
2. Package the Claude Engineer application for distribution
3. Create executable files for different platforms
4. Deploy and update the application efficiently
5. Handle file path differences across platforms
6. Implement auto-update mechanisms for the application

## 1. Handling Platform-Specific Differences

When developing a cross-platform application like Claude Engineer, it's essential to account for differences between Windows, macOS, and Linux. Let's explore some key areas where platform-specific code is necessary:

### 1.1 File Path Handling

One of the most common issues in cross-platform development is handling file paths. Windows uses backslashes (`\`) as path separators, while macOS and Linux use forward slashes (`/`). To ensure our application works correctly on all platforms, we use the `os.path` module.

Let's look at how we handle file paths in the Claude Engineer project:

```python
import os

# Instead of hardcoding path separators
file_path = "folder/subfolder/file.txt"  # This works on all platforms

# For joining paths
full_path = os.path.join("folder", "subfolder", "file.txt")

# To get the correct path separator for the current platform
path_separator = os.path.sep

print(f"The path separator on this system is: {path_separator}")
```

### 1.2 Environment Variables

Environment variables are another area where platforms differ. In the Claude Engineer project, we use environment variables to store sensitive information like API keys. Here's how we handle them:

```python
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Access environment variables
anthropic_api_key = os.getenv("ANTHROPIC_API_KEY")
tavily_api_key = os.getenv("TAVILY_API_KEY")

if not anthropic_api_key or not tavily_api_key:
    raise ValueError("Missing required API keys in environment variables")
```

### 1.3 Command Execution

When executing system commands or running subprocesses, the syntax can vary between platforms. In the Claude Engineer project, we use the `subprocess` module to handle these differences:

```python
import subprocess
import sys

def run_shell_command(command):
    try:
        if sys.platform == "win32":
            result = subprocess.run(command, shell=True, check=True, text=True, capture_output=True)
        else:
            result = subprocess.run(command, shell=True, check=True, text=True, capture_output=True, executable="/bin/bash")
        
        return {
            "stdout": result.stdout,
            "stderr": result.stderr,
            "return_code": result.returncode
        }
    except subprocess.CalledProcessError as e:
        return {
            "stdout": e.stdout,
            "stderr": e.stderr,
            "return_code": e.returncode,
            "error": str(e)
        }
    except Exception as e:
        return {
            "error": f"An error occurred while executing the command: {str(e)}"
        }
```

## 2. Packaging the Application for Distribution

To make it easy for users to install and run Claude Engineer, we need to package it properly. We'll use `setuptools` to create a distributable package.

### 2.1 Creating a `setup.py` File

First, let's create a `setup.py` file in the root directory of our project:

```python
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="claude-engineer",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="An AI-powered CLI tool for software development tasks",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/claude-engineer",
    packages=find_packages(),
    install_requires=[
        "anthropic",
        "python-dotenv",
        "tavily-python",
        "Pillow",
        "rich",
        "prompt_toolkit",
        "pydub",
        "websockets",
        "SpeechRecognition",
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
    ],
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "claude-engineer=claude_engineer.main:main",
        ],
    },
)
```

This `setup.py` file defines the package metadata, dependencies, and creates a console script entry point for easy execution.

### 2.2 Creating a Source Distribution

To create a source distribution, run the following command in the project root directory:

```bash
python setup.py sdist
```

This will create a `dist` folder containing a `.tar.gz` file with your packaged application.

### 2.3 Creating a Wheel Distribution

To create a wheel distribution, which is a built package format, run:

```bash
python setup.py bdist_wheel
```

This will create a `.whl` file in the `dist` folder.

## 3. Creating Executable Files for Different Platforms

To make it even easier for users to run Claude Engineer without having to install Python or dependencies, we can create standalone executable files for different platforms using PyInstaller.

### 3.1 Installing PyInstaller

First, install PyInstaller:

```bash
pip install pyinstaller
```

### 3.2 Creating the Executable

To create an executable, run the following command in the project root directory:

```bash
pyinstaller --onefile --name claude-engineer main.py
```

This will create a single executable file in the `dist` folder.

### 3.3 Platform-Specific Considerations

- For Windows: The executable will be named `claude-engineer.exe`
- For macOS and Linux: The executable will be named `claude-engineer`

Remember to create executables on each target platform to ensure compatibility.

## 4. Deploying and Updating the Application

Once we have our packaged application and executables, we need to consider how to deploy and update them efficiently.

### 4.1 Hosting the Package

You can host your package on PyPI (Python Package Index) for easy installation via pip. To do this:

1. Register an account on PyPI (https://pypi.org)
2. Install twine: `pip install twine`
3. Upload your package: `twine upload dist/*`

Users can then install your package using:

```bash
pip install claude-engineer
```

### 4.2 Hosting Executables

For executables, consider hosting them on a file sharing service or your own web server. You can use platforms like GitHub Releases to host different versions of your executables.

### 4.3 Implementing an Auto-Update Mechanism

To keep users up-to-date with the latest version of Claude Engineer, we can implement an auto-update mechanism. Here's a simple implementation:

```python
import requests
import sys
import os

CURRENT_VERSION = "1.0.0"
UPDATE_URL = "https://api.github.com/repos/yourusername/claude-engineer/releases/latest"

def check_for_updates():
    try:
        response = requests.get(UPDATE_URL)
        latest_version = response.json()["tag_name"]
        
        if latest_version > CURRENT_VERSION:
            print(f"A new version ({latest_version}) is available!")
            if input("Do you want to update? (y/n): ").lower() == 'y':
                download_url = response.json()["assets"][0]["browser_download_url"]
                download_and_install_update(download_url)
        else:
            print("You're running the latest version!")
    except Exception as e:
        print(f"Error checking for updates: {str(e)}")

def download_and_install_update(url):
    try:
        response = requests.get(url)
        new_executable = response.content
        
        # Backup the current executable
        current_executable = sys.executable
        backup_path = current_executable + ".bak"
        os.rename(current_executable, backup_path)
        
        # Write the new executable
        with open(current_executable, "wb") as f:
            f.write(new_executable)
        
        print("Update successful! Please restart the application.")
        sys.exit(0)
    except Exception as e:
        print(f"Error updating: {str(e)}")
        print("Reverting to the previous version...")
        os.rename(backup_path, current_executable)

# Call this function at the start of your application
check_for_updates()
```

This auto-update mechanism checks for new releases on GitHub, downloads the latest version if available, and replaces the current executable.

## 5. Handling File Path Differences Across Platforms

We've touched on this earlier, but let's dive deeper into handling file path differences across platforms:

### 5.1 Using `os.path` for Path Operations

Always use `os.path` functions for path operations to ensure cross-platform compatibility:

```python
import os

# Joining paths
config_dir = os.path.join(os.path.expanduser("~"), ".claude-engineer")

# Getting the absolute path
abs_path = os.path.abspath("relative/path/to/file.txt")

# Checking if a path exists
if os.path.exists(config_dir):
    print("Config directory exists")

# Getting the parent directory
parent_dir = os.path.dirname(abs_path)
```

### 5.2 Using `pathlib` for Modern Path Handling

For more modern and object-oriented path handling, consider using the `pathlib` module:

```python
from pathlib import Path

# Creating paths
config_dir = Path.home() / ".claude-engineer"

# Joining paths
log_file = config_dir / "logs" / "app.log"

# Creating directories
config_dir.mkdir(parents=True, exist_ok=True)

# Reading files
with log_file.open("r") as f:
    log_contents = f.read()

# Writing files
log_file.write_text("Log entry")

# Checking if a path exists
if log_file.exists():
    print("Log file exists")
```

`pathlib` provides a more intuitive and consistent way to work with paths across different platforms.

## Conclusion

In this lesson, we've covered crucial aspects of cross-platform development and deployment for the Claude Engineer project. We've learned how to handle platform-specific differences, package the application for distribution, create executables, implement deployment strategies, and manage file paths consistently across different operating systems.

By applying these techniques, you can ensure that Claude Engineer works seamlessly on Windows, macOS, and Linux, providing a consistent experience for all users regardless of their platform.

Remember to test your application thoroughly on all target platforms before distribution, and consider setting up automated cross-platform testing to catch any platform-specific issues early in the development process.

## Exercises

1. Modify the `run_shell_command` function to use `subprocess.Popen` instead of `subprocess.run`, allowing for more fine-grained control over the process execution.

2. Create a `config.py` file that uses `pathlib` to define all the necessary paths for the Claude Engineer project, ensuring cross-platform compatibility.

3. Implement a simple GUI using a cross-platform library like PyQt or wxPython to provide a graphical interface for Claude Engineer alongside the CLI.

4. Extend the auto-update mechanism to include a changelog display and the option to skip updates.

5. Create a cross-platform installation script that sets up the necessary environment variables and creates required directories on the user's system.

By completing these exercises, you'll gain hands-on experience in handling cross-platform development and deployment challenges, further solidifying your understanding of the concepts covered in this lesson.
