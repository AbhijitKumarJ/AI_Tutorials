# Lesson 11: Error Handling, Logging, and Debugging

## Introduction

In this lesson, we'll focus on implementing robust error handling, setting up comprehensive logging, and introducing effective debugging techniques for our AI-powered CLI tool. These practices are crucial for creating a reliable, maintainable, and user-friendly application. We'll explore how to gracefully handle exceptions, provide informative error messages, set up a logging system for better troubleshooting, and implement debugging tools to aid in development and maintenance.

## Lesson Objectives

By the end of this lesson, students will be able to:

1. Implement robust error handling mechanisms
2. Set up a comprehensive logging system
3. Develop effective debugging strategies
4. Create detailed error reports
5. Implement global exception handling
6. Apply best practices for maintaining and extending the codebase

## File Structure

Before we begin, let's review the file structure of our project, highlighting the files we'll be working with in this lesson:

```
claude-engineer/
├── main.py
├── autonomous_mode.py
├── task_planning.py
├── error_handling.py  (new file we'll create)
├── logging_config.py  (new file we'll create)
├── debug_tools.py     (new file we'll create)
├── requirements.txt
└── .env
```

We'll be adding three new files to our project: `error_handling.py`, `logging_config.py`, and `debug_tools.py`. These will help us organize our error handling, logging, and debugging code.

## 1. Implementing Robust Error Handling

Error handling is crucial for creating a reliable application. It helps prevent crashes, provides useful information to users, and makes debugging easier. Let's create a new file called `error_handling.py` to implement our error handling mechanisms.

```python
# error_handling.py

import sys
from typing import Any, Callable
from rich.console import Console

console = Console()

class CLIToolException(Exception):
    """Base exception class for our CLI tool."""
    def __init__(self, message: str, error_code: int = 1):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)

class InputValidationError(CLIToolException):
    """Exception raised for errors in the input."""
    pass

class APIError(CLIToolException):
    """Exception raised for errors in API calls."""
    pass

class TaskExecutionError(CLIToolException):
    """Exception raised for errors during task execution."""
    pass

def handle_exception(func: Callable) -> Callable:
    """Decorator to handle exceptions in a consistent manner."""
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)
        except CLIToolException as e:
            console.print(f"[bold red]Error:[/bold red] {e.message}")
            return e.error_code
        except Exception as e:
            console.print(f"[bold red]An unexpected error occurred:[/bold red] {str(e)}")
            console.print_exception(show_locals=True)
            return 1
    return wrapper

def global_exception_handler(exctype: Any, value: Any, traceback: Any) -> None:
    """Global exception handler for unhandled exceptions."""
    if issubclass(exctype, KeyboardInterrupt):
        sys.__excepthook__(exctype, value, traceback)
        return

    console.print("[bold red]An unexpected error occurred:[/bold red]")
    console.print_exception(show_locals=True)

# Set the global exception handler
sys.excepthook = global_exception_handler
```

This `error_handling.py` file introduces several important components:

1. **Custom Exception Classes**: We define a base `CLIToolException` class and several specific exception types (`InputValidationError`, `APIError`, `TaskExecutionError`). These allow us to raise and catch specific types of errors in our application.

2. **Exception Handling Decorator**: The `handle_exception` decorator provides a consistent way to handle exceptions across our application. It catches our custom exceptions and unexpected exceptions, printing appropriate error messages.

3. **Global Exception Handler**: The `global_exception_handler` function is set as the global exception hook. This ensures that any unhandled exceptions are caught and reported, preventing silent failures.

## 2. Setting Up a Comprehensive Logging System

Logging is essential for tracking the behavior of our application, especially when running in production. Let's create a `logging_config.py` file to set up our logging system:

```python
# logging_config.py

import logging
import os
from logging.handlers import RotatingFileHandler
from rich.logging import RichHandler

def setup_logging(log_level: str = "INFO", log_file: str = "cli_tool.log") -> None:
    """Set up logging configuration."""
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Create logs directory if it doesn't exist
    os.makedirs("logs", exist_ok=True)
    
    # Set up file handler with rotation
    file_handler = RotatingFileHandler(
        f"logs/{log_file}", maxBytes=10*1024*1024, backupCount=5
    )
    file_handler.setFormatter(logging.Formatter(log_format))
    
    # Set up console handler with Rich formatting
    console_handler = RichHandler(rich_tracebacks=True)
    console_handler.setFormatter(logging.Formatter("%(message)s"))
    
    # Configure root logger
    logging.basicConfig(
        level=log_level,
        format=log_format,
        handlers=[file_handler, console_handler]
    )

    # Suppress overly verbose logs from libraries
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)

def get_logger(name: str) -> logging.Logger:
    """Get a logger with the specified name."""
    return logging.getLogger(name)
```

This logging configuration provides several benefits:

1. **Dual Logging**: It sets up both file logging (with rotation to manage file sizes) and console logging (using Rich for improved readability).

2. **Customizable Log Level**: The log level can be easily adjusted, allowing for more or less verbose logging as needed.

3. **Structured Log Format**: The log format includes timestamp, logger name, log level, and message, making it easy to parse and analyze logs.

4. **Library Log Suppression**: It suppresses overly verbose logs from some common libraries to keep our logs focused on our application's behavior.

## 3. Developing Effective Debugging Strategies

To aid in debugging, let's create a `debug_tools.py` file with some useful debugging functions:

```python
# debug_tools.py

import time
import functools
from typing import Any, Callable
from rich.console import Console
from rich.table import Table

console = Console()

def measure_time(func: Callable) -> Callable:
    """Decorator to measure the execution time of a function."""
    @functools.wraps(func)
    
def wrapper(*args: Any, **kwargs: Any) -> Any:
    start_time = time.time()
    result = func(*args, **kwargs)
    end_time = time.time()
    console.print(f"[cyan]Function '{func.__name__}' took {end_time - start_time:.4f} seconds to execute.[/cyan]")
    return result
return wrapper

def print_object_info(obj: Any) -> None:
    """Print detailed information about an object."""
    console.print(f"[bold green]Object Information for {type(obj).__name__}:[/bold green]")
    
    table = Table(title="Attributes and Methods")
    table.add_column("Name", style="cyan")
    table.add_column("Type", style="magenta")
    table.add_column("Value/Description", style="yellow")

    for name in dir(obj):
        if name.startswith('__'):
            continue
        attr = getattr(obj, name)
        attr_type = type(attr).__name__
        if callable(attr):
            value = "Method"
        else:
            value = str(attr)
        table.add_row(name, attr_type, value)

    console.print(table)

def trace_calls(func: Callable) -> Callable:
    """Decorator to trace function calls and their arguments."""
    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        arg_str = ', '.join([repr(a) for a in args] + [f"{k}={v!r}" for k, v in kwargs.items()])
        console.print(f"[bold blue]Calling {func.__name__}({arg_str})[/bold blue]")
        result = func(*args, **kwargs)
        console.print(f"[bold green]{func.__name__} returned {result!r}[/bold green]")
        return result
    return wrapper
```

This `debug_tools.py` file provides several useful debugging tools:

1. **measure_time Decorator**: This decorator measures and prints the execution time of a function. It's useful for identifying performance bottlenecks.

2. **print_object_info Function**: This function prints detailed information about an object, including its attributes and methods. It's helpful for inspecting complex objects during debugging.

3. **trace_calls Decorator**: This decorator traces function calls, printing the function name, arguments, and return value. It's valuable for understanding the flow of your program and the data being passed between functions.

Now, let's update our main files to incorporate these error handling, logging, and debugging features:

```python
# main.py

import asyncio
import signal
from autonomous_mode import AutonomousMode
from rich.console import Console
from rich.panel import Panel
from rich.tree import Tree
from error_handling import handle_exception, CLIToolException
from logging_config import setup_logging, get_logger
from debug_tools import measure_time, trace_calls

console = Console()
setup_logging()
logger = get_logger(__name__)

# ... (existing imports and code)

@handle_exception
@measure_time
@trace_calls
async def chat_with_claude(user_input: str, image_path: str = None, current_iteration: int = None, max_iterations: int = None):
    # ... (existing code)
    logger.info(f"Processing user input: {user_input}")
    # ... (rest of the existing code)

@handle_exception
async def main():
    logger.info("Starting the CLI tool")
    # ... (existing code)

    autonomous_mode = AutonomousMode()

    while True:
        try:
            user_input = await get_user_input()

            if user_input.lower() == 'exit':
                logger.info("User requested exit")
                console.print("Thank you for chatting. Goodbye!", style="bold green")
                break

            if user_input.lower().startswith('automode'):
                # ... (existing automode code)
                logger.info(f"Entering automode with {max_iterations} iterations")
                # ... (rest of the existing automode code)

            # Regular chat mode
            response, exit_continuation = await chat_with_claude(user_input)
            console.print(Panel(response, title="Claude's Response", style="cyan"))

            if CONTINUATION_EXIT_PHRASE in response:
                logger.info("Autonomous mode completed its task")
                console.print("Autonomous mode completed its task.", style="bold green")
                break

        except CLIToolException as e:
            logger.error(f"CLI Tool Error: {str(e)}")
            console.print(f"[bold red]Error:[/bold red] {str(e)}")
        except Exception as e:
            logger.exception("An unexpected error occurred")
            console.print(f"[bold red]An unexpected error occurred:[/bold red] {str(e)}")

    logger.info("CLI tool shutting down")

if __name__ == "__main__":
    # ... (existing signal handling code)

    try:
        loop.run_until_complete(main())
    except Exception as e:
        logger.exception("Fatal error in main loop")
        console.print(f"[bold red]A fatal error occurred:[/bold red] {str(e)}")
    finally:
        logger.info("Cleaning up and exiting")
        loop.close()

@handle_exception
async def shutdown(loop: asyncio.AbstractEventLoop, signal: signal.Signals = None) -> None:
    """Cleanup tasks tied to the service's shutdown."""
    if signal:
        logger.info(f"Received exit signal {signal.name}")
        console.print(f"Received exit signal {signal.name}...", style="bold red")
    
    tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]

    for task in tasks:
        task.cancel()

    await asyncio.gather(*tasks, return_exceptions=True)
    loop.stop()
    logger.info("Shutdown complete")
```

Let's also update the `autonomous_mode.py` file:

```python
# autonomous_mode.py

import asyncio
from typing import List, Dict, Any
from task_planning import TaskPlanner, Task
from error_handling import handle_exception, TaskExecutionError
from logging_config import get_logger
from debug_tools import measure_time, trace_calls

logger = get_logger(__name__)

CONTINUATION_EXIT_PHRASE = "AUTOMODE_COMPLETE"

class AutonomousMode:
    def __init__(self, max_iterations: int = 25):
        self.max_iterations = max_iterations
        self.current_iteration = 0
        self.task_planner = TaskPlanner()
        self.running = False
        self.task_completed = False

    @handle_exception
    @measure_time
    async def start(self, initial_goal: str) -> None:
        logger.info(f"Starting autonomous mode with initial goal: {initial_goal}")
        self.running = True
        await self.task_planner.plan_tasks(initial_goal)
        await self.run()

    @handle_exception
    async def run(self) -> None:
        while self.running and self.current_iteration < self.max_iterations and not self.task_completed:
            self.current_iteration += 1
            logger.info(f"Starting iteration {self.current_iteration}")
            
            await self.task_planner.execute_tasks(self.process_task)
            
            if not self.task_planner.task_queue.get_all_tasks():
                logger.info("All tasks completed")
                self.task_completed = True

    @trace_calls
    async def process_task(self, task: Task) -> None:
        logger.info(f"Processing task: {task.description}")
        try:
            # Here, we'll implement the logic to process the task
            # This will involve calling the AI model and interpreting its response
            
            # For demonstration purposes, let's simulate task processing
            await asyncio.sleep(2)  # Simulating some work
            
            # Simulate AI response
            ai_response = self.simulate_ai_response(task)
            
            if CONTINUATION_EXIT_PHRASE in ai_response:
                logger.info("Received continuation exit phrase")
                self.task_completed = True
                return
            
            # Randomly decide if the task generates new subtasks
            import random
            if random.choice([True, False]):
                new_subtask = Task(f"Generated subtask for {task.description}")
                task.add_subtask(new_subtask)
                await self.task_planner.task_queue.add_task(new_subtask)
                logger.info(f"Generated new subtask: {new_subtask.description}")
        except Exception as e:
            logger.exception(f"Error processing task: {task.description}")
            raise TaskExecutionError(f"Failed to process task: {task.description}") from e

    def simulate_ai_response(self, task: Task) -> str:
        # This method simulates an AI response
        # In a real implementation, this would call the actual AI model
        responses = [
            f"Completed task: {task.description}",
            f"Made progress on task: {task.description}",
            f"Encountered difficulty with task: {task.description}",
            CONTINUATION_EXIT_PHRASE
        ]
        response = random.choice(responses)
        logger.info(f"AI response for task '{task.description}': {response}")
        return response

    def stop(self) -> None:
        logger.info("Stopping autonomous mode")
        self.running = False

    def get_progress(self) -> Dict[str, Any]:
        progress = {
            "current_iteration": self.current_iteration,
            "max_iterations": self.max_iterations,
            "tasks": self.task_planner.get_task_status(),
            "remaining_tasks": len(self.task_planner.task_queue.get_all_tasks()),
            "task_completed": self.task_completed
        }
        logger.debug(f"Current progress: {progress}")
        return progress
```

These updates incorporate our error handling, logging, and debugging tools into the main components of our CLI tool. Key changes include:

1. **Error Handling**: We've applied the `@handle_exception` decorator to key functions, ensuring consistent error handling throughout the application.

2. **Logging**: We've added logging statements at important points in the code, providing visibility into the application's behavior.

3. **Debugging Tools**: We've applied the `@measure_time` and `@trace_calls` decorators to key functions, aiding in performance analysis and debugging.

4. **Exception Handling**: We've added try-except blocks in critical areas, catching and logging exceptions, and raising custom exceptions where appropriate.

## Conclusion

In this lesson, we've implemented robust error handling, comprehensive logging, and effective debugging tools for our AI-powered CLI tool. These enhancements significantly improve the reliability, maintainability, and debuggability of our application. Key achievements include:

1. Custom exception classes for specific error types
2. A consistent error handling mechanism using decorators
3. A global exception handler for unhandled exceptions
4. A flexible logging system with both file and console output
5. Debugging tools for measuring execution time and tracing function calls
6. Integration of these tools into our main application components

These practices will help in identifying and resolving issues quickly, improving the overall quality of the codebase, and making it easier to maintain and extend the application in the future.

In the next lesson, we'll focus on cross-platform considerations and deployment strategies to ensure our CLI tool works consistently across different operating systems and can be easily distributed to users.

