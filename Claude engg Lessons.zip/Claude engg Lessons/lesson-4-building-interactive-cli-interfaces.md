# Lesson 4: Building Interactive CLI Interfaces

In this lesson, we'll explore how to create engaging and user-friendly Command-Line Interface (CLI) tools. We'll focus on enhancing the user experience through interactive prompts, effective command parsing, and visually appealing output.

## 1. Introduction to the `rich` library for enhanced terminal output

The `rich` library is a powerful tool for creating beautiful and informative terminal output in Python. It provides a wide range of formatting options, including colors, styles, tables, and progress bars.

Key features of `rich`:

1. **Text styling**: Apply colors, bold, italic, and other styles to text.
2. **Tables**: Create formatted tables with ease.
3. **Syntax highlighting**: Automatically highlight code snippets.
4. **Progress bars**: Display progress for long-running operations.
5. **Tree structures**: Visualize hierarchical data.
6. **Markdown rendering**: Render markdown directly in the terminal.

Let's start with a simple example to demonstrate some basic `rich` functionality:

```python
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax

console = Console()

# Styled text
console.print("Welcome to the [bold magenta]Rich[/bold magenta] CLI demo!", style="bold green")

# Panel
console.print(Panel("This is a panel", title="Panel Demo", expand=False))

# Syntax highlighting
code = """
def greet(name):
    return f"Hello, {name}!"
"""
console.print(Syntax(code, "python", theme="monokai", line_numbers=True))

# Table
from rich.table import Table

table = Table(title="Rich Features")
table.add_column("Feature", style="cyan", no_wrap=True)
table.add_column("Description", style="magenta")

table.add_row("Text Styling", "Apply colors and styles to text")
table.add_row("Panels", "Create boxed content with titles")
table.add_row("Syntax Highlighting", "Highlight code with line numbers")

console.print(table)
```

This example demonstrates several key features of `rich`:
1. Styled text with colors and emphasis.
2. Panels for creating boxed content with titles.
3. Syntax highlighting for code snippets.
4. Tables for organizing data in a visually appealing manner.

Using `rich` can significantly enhance the visual appeal and readability of your CLI tools, making them more user-friendly and professional-looking.

## 2. Creating interactive prompts with `prompt_toolkit`

While `rich` enhances the output of your CLI tools, `prompt_toolkit` is excellent for creating interactive input prompts. It provides features like auto-completion, syntax highlighting, and multi-line editing for user input.

Here's an example that demonstrates some key features of `prompt_toolkit`:

```python
from prompt_toolkit import prompt
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit.styles import Style

# Custom validator
class NumberValidator(Validator):
    def validate(self, document):
        text = document.text
        if text and not text.isdigit():
            raise ValidationError(message="Please enter a valid number")

# Custom style
style = Style.from_dict({
    'prompt': 'bg:#ansibrightblue #ansiblack',
    'input': '#ansigreen',
})

# Command completer
command_completer = WordCompleter(['help', 'exit', 'status', 'settings'])

def main():
    while True:
        # Basic prompt with styling
        name = prompt("What's your name? ", style=style)
        print(f"Hello, {name}!")

        # Prompt with validation
        age = prompt("How old are you? ", validator=NumberValidator(), style=style)
        print(f"You are {age} years old.")

        # Prompt with auto-completion
        command = prompt("Enter a command: ", completer=command_completer, style=style)
        if command == 'exit':
            break
        print(f"You entered: {command}")

if __name__ == "__main__":
    main()
```

This example showcases several important features of `prompt_toolkit`:

1. **Custom Validation**: The `NumberValidator` class ensures that age input is a valid number.
2. **Styling**: Custom styles are applied to the prompt and input text.
3. **Auto-completion**: The `WordCompleter` provides auto-completion for a predefined set of commands.

These features enhance the user experience by providing immediate feedback, reducing errors, and speeding up input for known commands.

## 3. Implementing command parsing and execution

For more complex CLI tools, you often need to parse and execute various commands with different arguments. The `argparse` module from the Python standard library is excellent for this purpose.

Here's an example of a CLI tool that uses `argparse` for command parsing, combined with `rich` for output formatting:

```python
import argparse
from rich.console import Console
from rich.table import Table

console = Console()

def list_items(args):
    items = ["apple", "banana", "cherry", "date"]
    table = Table(title="Fruit List")
    table.add_column("Index", style="cyan", no_wrap=True)
    table.add_column("Fruit", style="magenta")
    
    for i, item in enumerate(items, start=1):
        table.add_row(str(i), item)
    
    console.print(table)

def add_item(args):
    console.print(f"Adding item: [bold green]{args.name}[/bold green]")

def remove_item(args):
    console.print(f"Removing item at index: [bold red]{args.index}[/bold red]")

def main():
    parser = argparse.ArgumentParser(description="Fruit Inventory CLI")
    subparsers = parser.add_subparsers(title="commands", dest="command")

    # List command
    list_parser = subparsers.add_parser("list", help="List all fruits")
    list_parser.set_defaults(func=list_items)

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new fruit")
    add_parser.add_argument("name", help="Name of the fruit to add")
    add_parser.set_defaults(func=add_item)

    # Remove command
    remove_parser = subparsers.add_parser("remove", help="Remove a fruit by index")
    remove_parser.add_argument("index", type=int, help="Index of the fruit to remove")
    remove_parser.set_defaults(func=remove_item)

    args = parser.parse_args()
    if args.command:
        args.func(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
```

This example demonstrates several key concepts:

1. **Subcommands**: The tool supports different commands (list, add, remove) with their own arguments.
2. **Argument Parsing**: Each command has its own argument parser with specific arguments.
3. **Command Execution**: The parsed command is mapped to a specific function for execution.
4. **Rich Output**: The `rich` library is used to create visually appealing output, especially for the list command.

To use this CLI tool, you would run commands like:
- `python fruit_cli.py list`
- `python fruit_cli.py add orange`
- `python fruit_cli.py remove 2`

This structure allows for a more complex and feature-rich CLI tool while maintaining a clean and organized codebase.

## 4. Handling user input and providing feedback

Effective CLI tools not only execute commands but also provide clear feedback and handle user input gracefully. Let's enhance our previous example to include more robust input handling and user feedback:

```python
import argparse
from rich.console import Console
from rich.prompt import Confirm
from rich.panel import Panel

console = Console()

fruits = ["apple", "banana", "cherry", "date"]

def list_items(args):
    if not fruits:
        console.print(Panel("The fruit list is empty.", title="Fruit List", style="yellow"))
        return

    table = Table(title="Fruit List")
    table.add_column("Index", style="cyan", no_wrap=True)
    table.add_column("Fruit", style="magenta")
    
    for i, item in enumerate(fruits, start=1):
        table.add_row(str(i), item)
    
    console.print(table)

def add_item(args):
    if args.name.lower() in [f.lower() for f in fruits]:
        console.print(f"[bold yellow]Warning:[/bold yellow] '{args.name}' is already in the list.")
        if Confirm.ask("Do you want to add it anyway?"):
            fruits.append(args.name)
            console.print(f"Added: [bold green]{args.name}[/bold green]")
        else:
            console.print("Addition cancelled.")
    else:
        fruits.append(args.name)
        console.print(f"Added: [bold green]{args.name}[/bold green]")

def remove_item(args):
    if 1 <= args.index <= len(fruits):
        item = fruits[args.index - 1]
        if Confirm.ask(f"Are you sure you want to remove '{item}'?"):
            removed = fruits.pop(args.index - 1)
            console.print(f"Removed: [bold red]{removed}[/bold red]")
        else:
            console.print("Removal cancelled.")
    else:
        console.print(f"[bold red]Error:[/bold red] Invalid index. Please use an index between 1 and {len(fruits)}.")

def main():
    parser = argparse.ArgumentParser(description="Fruit Inventory CLI")
    subparsers = parser.add_subparsers(title="commands", dest="command")

    list_parser = subparsers.add_parser("list", help="List all fruits")
    list_parser.set_defaults(func=list_items)

    add_parser = subparsers.add_parser("add", help="Add a new fruit")
    add_parser.add_argument("name", help="Name of the fruit to add")
    add_parser.set_defaults(func=add_item)

    remove_parser = subparsers.add_parser("remove", help="Remove a fruit by index")
    remove_parser.add_argument("index", type=int, help="Index of the fruit to remove")
    remove_parser.set_defaults(func=remove_item)

    args = parser.parse_args()
    if args.command:
        args.func(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
```

This enhanced version includes several improvements in user input handling and feedback:

1. **Duplicate Checking**: When adding a fruit, it checks if it already exists and asks for confirmation before adding a duplicate.
2. **Confirmation Prompts**: Uses `rich.prompt.Confirm` to ask for user confirmation before removing items or adding duplicates.
3. **Error Handling**: Provides clear error messages for invalid inputs, such as out-of-range indices for removal.
4. **Empty List Handling**: Displays a special message when trying to list an empty fruit inventory.
5. **Colorful Feedback**: Uses color-coded messages to distinguish between different types of feedback (success, warning, error).

These enhancements make the CLI tool more user-friendly and robust, reducing the chance of unintended actions and providing clear feedback at each step.

## 5. Creating progress bars and spinners for long-running tasks

For CLI tools that perform long-running operations, it's important to provide visual feedback to the user about the progress. The `rich` library offers excellent tools for this purpose. Let's add a new command to our fruit inventory CLI that simulates a long-running task with a progress bar:

```python
import time
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn

def process_fruits(args):
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
    ) as progress:
        task = progress.add_task("[green]Processing fruits...", total=100)
        for i in range(100):
            time.sleep(0.1)  # Simulate some work
            progress.update(task, advance=1)
    console.print(Panel("Fruit processing completed!", title="Task Complete", style="bold green"))

# Add this to the main function:
process_parser = subparsers.add_parser("process", help="Process fruits (demo of progress bar)")
process_parser.set_defaults(func=process_fruits)
```

This example demonstrates:
1. **Progress Bar**: A visual indicator of task progress.
2. **Spinner**: An animated spinner to show that the task is active.
3. **Percentage Display**: Numerical representation of progress.

## Conclusion

Building interactive CLI interfaces is crucial for creating user-friendly and efficient command-line tools. By leveraging libraries like `rich` and `prompt_toolkit`, and utilizing built-in modules like `argparse`, you can create CLIs that are not only functional but also visually appealing and intuitive to use.

Key takeaways from this lesson:
1. Use `rich` for enhanced, colorful terminal output.
2. Implement interactive prompts with `prompt_toolkit` for better user input handling.
3. Utilize `argparse` for robust command parsing and execution.
4. Provide clear feedback and confirmation prompts for user actions.
5. Use progress bars and spinners for long-running tasks to keep users informed.

By applying these techniques, you can significantly improve the user experience of your CLI tools, making them more professional and user-friendly. In the next lesson, we'll dive deeper into AI agent architecture and implementation, building upon these interface concepts to create more intelligent and responsive CLI tools.

