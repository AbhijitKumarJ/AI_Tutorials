# Lesson 14: Security Best Practices

## Introduction

In this lesson, we'll focus on implementing security best practices in the Claude Engineer project. As an AI-powered tool that interacts with various APIs and performs file system operations, ensuring the security of the application and its users is paramount. We'll cover securing API keys, implementing safe code execution practices, handling user permissions, addressing ethical considerations, implementing input sanitization, and creating a responsible AI usage policy.

## Learning Objectives

By the end of this lesson, you will be able to:

1. Implement secure methods for handling API keys and sensitive information
2. Develop safe code execution practices to protect against malicious inputs
3. Implement user permissions and access control mechanisms
4. Address ethical considerations in AI-powered tools
5. Apply input sanitization techniques to prevent security vulnerabilities
6. Create a comprehensive responsible AI usage policy

## 1. Securing API Keys and Sensitive Information

Protecting API keys and other sensitive information is crucial to maintain the security of your application. Here are some best practices:

### 1.1 Using Environment Variables

Instead of hardcoding API keys in your source code, use environment variables. This approach prevents accidental exposure of sensitive information when sharing or publishing your code.

```python
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Access API keys
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")

if not ANTHROPIC_API_KEY or not TAVILY_API_KEY:
    raise ValueError("Missing required API keys in environment variables")
```

Create a `.env` file in your project root to store these variables:

```
ANTHROPIC_API_KEY=your_anthropic_api_key_here
TAVILY_API_KEY=your_tavily_api_key_here
```

Make sure to add `.env` to your `.gitignore` file to prevent it from being committed to version control:

```
# .gitignore
.env
```

### 1.2 Using Secret Management Systems

For production environments, consider using a secret management system like HashiCorp Vault or AWS Secrets Manager. These systems provide secure storage and access control for sensitive information.

Here's an example using AWS Secrets Manager:

```python
import boto3
from botocore.exceptions import ClientError

def get_secret():
    secret_name = "claude_engineer/api_keys"
    region_name = "us-west-2"

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        raise e

    return get_secret_value_response['SecretString']

# Use the secret
api_keys = json.loads(get_secret())
ANTHROPIC_API_KEY = api_keys['ANTHROPIC_API_KEY']
TAVILY_API_KEY = api_keys['TAVILY_API_KEY']
```

This approach provides an additional layer of security and allows for easy rotation of secrets.

## 2. Implementing Safe Code Execution Practices

When allowing user-provided code to be executed, it's crucial to implement strict safety measures to prevent malicious actions. Here are some strategies:

### 2.1 Using a Separate Environment

Execute user code in a separate, isolated environment. This can be achieved using Docker containers or virtual machines. Here's an example using the `subprocess` module to run code in a Docker container:

```python
import subprocess
import tempfile

def execute_code_safely(code):
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as temp_file:
        temp_file.write(code)
        temp_file.flush()
        
        try:
            result = subprocess.run(
                ['docker', 'run', '--rm', '-v', f'{temp_file.name}:/code.py:ro', 'python:3.9-slim', 'python', '/code.py'],
                capture_output=True,
                text=True,
                timeout=30  # Set a timeout to prevent infinite loops
            )
            return result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return '', 'Execution timed out'
        finally:
            os.unlink(temp_file.name)

# Usage
code = """
print("Hello, World!")
"""
stdout, stderr = execute_code_safely(code)
print(f"Output: {stdout}")
print(f"Errors: {stderr}")
```

This approach runs the code in a disposable Docker container, providing isolation from the host system.

### 2.2 Restricting Import Statements

When executing user-provided code, it's important to restrict which modules can be imported to prevent potential security breaches. You can achieve this by overriding the built-in `__import__` function:

```python
import builtins

ALLOWED_MODULES = set(['math', 'random', 'datetime'])

def restricted_import(name, globals=None, locals=None, fromlist=(), level=0):
    if name not in ALLOWED_MODULES:
        raise ImportError(f"Import of '{name}' is not allowed")
    return original_import(name, globals, locals, fromlist, level)

original_import = builtins.__import__
builtins.__import__ = restricted_import

# Now, only allowed modules can be imported
```

## 3. Handling User Permissions and Access Control

Implementing proper user permissions and access control is crucial for maintaining security in multi-user environments. Here's an example of how you might implement a basic role-based access control system:

```python
from enum import Enum, auto
from functools import wraps

class UserRole(Enum):
    ADMIN = auto()
    DEVELOPER = auto()
    VIEWER = auto()

class User:
    def __init__(self, username, role):
        self.username = username
        self.role = role

def require_role(role):
    def decorator(func):
        @wraps(func)
        def wrapper(user, *args, **kwargs):
            if user.role != role:
                raise PermissionError(f"User {user.username} does not have the required role {role}")
            return func(user, *args, **kwargs)
        return wrapper
    return decorator

@require_role(UserRole.ADMIN)
def admin_function(user):
    print(f"Admin function executed by {user.username}")

@require_role(UserRole.DEVELOPER)
def developer_function(user):
    print(f"Developer function executed by {user.username}")

# Usage
admin_user = User("admin", UserRole.ADMIN)
dev_user = User("developer", UserRole.DEVELOPER)

admin_function(admin_user)  # This works
try:
    admin_function(dev_user)  # This raises a PermissionError
except PermissionError as e:
    print(e)
```

This example demonstrates a simple role-based access control system where functions can be decorated to require specific user roles.

## 4. Addressing Ethical Considerations in AI-Powered Tools

When developing AI-powered tools like Claude Engineer, it's crucial to consider the ethical implications of your application. Here are some key considerations:

### 4.1 Bias and Fairness

AI models can inadvertently perpetuate or amplify biases present in their training data. To address this:

1. Regularly audit your AI's outputs for bias.
2. Use diverse datasets for training and testing.
3. Implement fairness metrics to evaluate your model's performance across different demographic groups.

Here's a simple example of how you might implement a basic fairness check:

```python
from collections import defaultdict

def check_fairness(model, test_data, sensitive_attribute):
    results = defaultdict(list)
    
    for input_data, true_label in test_data:
        prediction = model.predict(input_data)
        attribute_value = input_data[sensitive_attribute]
        results[attribute_value].append(prediction == true_label)
    
    fairness_report = {}
    for attribute_value, outcomes in results.items():
        fairness_report[attribute_value] = sum(outcomes) / len(outcomes)
    
    return fairness_report

# Usage
fairness_report = check_fairness(model, test_data, "gender")
print("Fairness Report:", fairness_report)
```

This simple check compares the model's accuracy across different values of a sensitive attribute. In a production system, you would want to use more sophisticated fairness metrics and analysis tools.

### 4.2 Transparency and Explainability

Users should understand when they're interacting with an AI and how decisions are being made. Implement features that provide explanations for the AI's outputs. For example:

```python
def generate_response(prompt):
    response = claude_model.generate(prompt)
    explanation = claude_model.explain_generation(response)
    return {
        "response": response,
        "explanation": explanation
    }

# Usage
result = generate_response("What is the capital of France?")
print(f"Response: {result['response']}")
print(f"Explanation: {result['explanation']}")
```

### 4.3 Data Privacy

Respect user privacy by minimizing data collection and implementing strong data protection measures. Be transparent about what data is collected and how it's used. Here's an example of a data minimization function:

```python
def minimize_user_data(user_data):
    allowed_fields = {'username', 'email'}
    return {k: v for k, v in user_data.items() if k in allowed_fields}

# Usage
full_user_data = {
    'username': 'john_doe',
    'email': 'john@example.com',
    'age': 30,
    'address': '123 Main St'
}
minimized_data = minimize_user_data(full_user_data)
print("Minimized user data:", minimized_data)
```

This function ensures that only necessary user data is stored or processed.

## 5. Implementing Input Sanitization

Input sanitization is crucial to prevent security vulnerabilities like SQL injection, cross-site scripting (XSS), and other forms of attack. Here's how you can implement input sanitization in the Claude Engineer project:

### 5.1 Sanitizing User Input

Use libraries like `bleach` to sanitize user input, especially if it will be displayed or stored:

```python
import bleach

def sanitize_input(user_input):
    return bleach.clean(user_input)

# Usage
user_input = "<script>alert('XSS attack!');</script>Hello, world!"
sanitized_input = sanitize_input(user_input)
print("Sanitized input:", sanitized_input)
```

This will strip out potentially dangerous HTML tags and attributes.

### 5.2 Validating and Sanitizing File Paths

When working with file paths, it's important to validate and sanitize them to prevent directory traversal attacks:

```python
import os
from pathlib import Path

def safe_join(base, *paths):
    """Safely join one or more path components."""
    base = Path(base).resolve()
    path = base.joinpath(*paths).resolve()
    if not path.is_relative_to(base):
        raise ValueError("Resulting path is outside of the base path")
    return str(path)

# Usage
try:
    safe_path = safe_join("/safe/base/dir", user_input)
    with open(safe_path, 'r') as f:
        content = f.read()
except ValueError as e:
    print(f"Error: {e}")
```

This function ensures that the resulting path is within the specified base directory, preventing access to files outside of the intended directory structure.

## 6. Creating a Responsible AI Usage Policy

Developing a responsible AI usage policy is crucial for guiding the ethical use of your AI-powered tool. Here's an outline of what such a policy might include:

1. **Purpose and Scope**: Clearly define the intended use of the AI tool and its limitations.

2. **Data Handling and Privacy**: Explain how user data is collected, used, and protected.

3. **Fairness and Non-Discrimination**: Commit to fair and unbiased operation of the AI system across different user groups. This includes regular audits of the AI's outputs to detect and mitigate potential biases. For example:

   ```python
   def audit_ai_outputs(outputs, sensitive_attributes):
       bias_report = {}
       for attribute in sensitive_attributes:
           attribute_values = set(output[attribute] for output in outputs)
           bias_report[attribute] = {}
           for value in attribute_values:
               relevant_outputs = [o for o in outputs if o[attribute] == value]
               bias_report[attribute][value] = {
                   'count': len(relevant_outputs),
                   'average_score': sum(o['score'] for o in relevant_outputs) / len(relevant_outputs)
               }
       return bias_report

   # Usage
   outputs = [
       {'user_id': 1, 'gender': 'male', 'age_group': '18-25', 'score': 0.8},
       {'user_id': 2, 'gender': 'female', 'age_group': '26-35', 'score': 0.7},
       # ... more outputs ...
   ]
   bias_report = audit_ai_outputs(outputs, ['gender', 'age_group'])
   print(json.dumps(bias_report, indent=2))
   ```

   This function provides a basic framework for auditing AI outputs across different demographic groups, allowing you to identify potential biases in the system's performance.

4. **Transparency and Explainability**: Commit to providing clear explanations of how the AI system makes decisions. This could include implementing feature importance analysis for predictions or generating natural language explanations for AI outputs. For example:

   ```python
   import shap

   def explain_prediction(model, input_data):
       explainer = shap.Explainer(model)
       shap_values = explainer(input_data)
       
       feature_importance = dict(zip(input_data.columns, shap_values.abs.mean(0).values))
       sorted_importance = sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)
       
       explanation = "The most important features for this prediction were:\n"
       for feature, importance in sorted_importance[:5]:  # Top 5 features
           explanation += f"- {feature}: {importance:.3f}\n"
       
       return explanation

   # Usage
   explanation = explain_prediction(model, input_data)
   print(explanation)
   ```

   This function uses the SHAP (SHapley Additive exPlanations) library to provide interpretable explanations for model predictions.

5. **Security and Data Protection**: Outline the measures taken to protect user data and prevent unauthorized access or use of the AI system. This includes encryption of data in transit and at rest, secure API key management, and regular security audits. For example:

   ```python
   import hashlib
   import os

   def hash_user_data(data, salt=None):
       if salt is None:
           salt = os.urandom(32)
       key = hashlib.pbkdf2_hmac('sha256', data.encode('utf-8'), salt, 100000)
       return salt + key

   def verify_user_data(stored_data, provided_data):
       salt = stored_data[:32]
       stored_key = stored_data[32:]
       provided_key = hashlib.pbkdf2_hmac('sha256', provided_data.encode('utf-8'), salt, 100000)
       return stored_key == provided_key

   # Usage
   user_data = "sensitive_user_information"
   stored_hash = hash_user_data(user_data)
   
   # Later, when verifying:
   is_valid = verify_user_data(stored_hash, user_data)
   print(f"Data verification result: {is_valid}")
   ```

   This example demonstrates secure hashing of user data, which can be used to store sensitive information without keeping it in plaintext.

6. **Accountability and Governance**: Establish clear lines of responsibility for the AI system's operation and decision-making processes. This includes designating individuals or teams responsible for monitoring the system's performance, handling user complaints, and making necessary adjustments. For example:

   ```python
   class AIGovernance:
       def __init__(self):
           self.responsible_team = "AI Ethics Board"
           self.monitoring_schedule = "Weekly"
           self.complaint_handler = "Customer Support Team"
   
       def log_decision(self, decision_id, input_data, output, explanation):
           # Log important decisions for later audit
           pass
   
       def handle_complaint(self, complaint):
           # Process and escalate user complaints
           pass
   
       def perform_audit(self):
           # Conduct regular system audits
           pass

   # Usage
   governance = AIGovernance()
   governance.log_decision("decision_123", input_data, model_output, explanation)
   ```

   This class provides a basic framework for implementing AI governance in your system.

7. **Continuous Improvement**: Commit to ongoing monitoring and improvement of the AI system. This includes regular updates to the model, incorporation of user feedback, and staying abreast of the latest developments in AI ethics and best practices. For example:

   ```python
   import schedule
   import time

   def update_model():
       # Fetch new training data
       new_data = fetch_new_data()
       
       # Retrain the model
       updated_model = retrain_model(current_model, new_data)
       
       # Evaluate the updated model
       performance = evaluate_model(updated_model, test_data)
       
       # If performance improved, deploy the new model
       if performance > current_performance:
           deploy_model(updated_model)
           log_model_update(performance)

   # Schedule model updates
   schedule.every().week.do(update_model)

   while True:
       schedule.run_pending()
       time.sleep(1)
   ```

   This script demonstrates a simple framework for scheduling regular model updates and improvements.

8. **User Rights and Control**: Clearly state the rights of users interacting with the AI system, including the right to opt-out of AI-driven features, request explanations for AI decisions, and appeal decisions they believe to be unfair. For example:

   ```python
   class UserRights:
       def __init__(self, user_id):
           self.user_id = user_id
           self.ai_enabled = True
   
       def toggle_ai(self):
           self.ai_enabled = not self.ai_enabled
           print(f"AI features {'enabled' if self.ai_enabled else 'disabled'} for user {self.user_id}")
   
       def request_explanation(self, decision_id):
           # Fetch and return explanation for a specific AI decision
           pass
   
       def appeal_decision(self, decision_id, reason):
           # Log and process an appeal for a specific AI decision
           pass

   # Usage
   user_rights = UserRights("user_123")
   user_rights.toggle_ai()
   user_rights.appeal_decision("decision_456", "I believe this decision was based on incomplete information")
   ```

   This class provides a framework for implementing user rights and control over AI features in your system.

By implementing these policies and the accompanying code examples, you create a robust framework for responsible AI usage in the Claude Engineer project. This not only helps to protect users and maintain ethical standards but also builds trust in your AI system.

Remember, a responsible AI usage policy should be a living document, regularly reviewed and updated as the AI system evolves and new ethical considerations emerge in the field of AI.

## Conclusion

In this lesson, we've covered crucial security best practices for the Claude Engineer project. We've explored methods for securing sensitive information, implementing safe code execution, handling user permissions, addressing ethical considerations, implementing input sanitization, and creating a responsible AI usage policy.

Remember that security is an ongoing process. Regularly review and update your security measures, stay informed about new security threats and best practices, and foster a culture of security awareness within your development team.

## Exercises

1. Implement a secret rotation mechanism that automatically updates API keys stored in environment variables or a secret management system.

2. Create a sandboxed environment for code execution using Python's `subprocess` module and Docker. Implement resource limits (CPU, memory, network access) for the sandboxed environment.

3. Extend the role-based access control system to include fine-grained permissions for different actions within the Claude Engineer project.

4. Implement a bias detection algorithm that analyzes the outputs of the AI model for potential biases based on sensitive attributes like gender, age, or ethnicity.

5. Create a user-friendly interface for the responsible AI usage policy, allowing users to easily view their rights, toggle AI features, and submit appeals for AI decisions.

By completing these exercises, you'll gain hands-on experience implementing security best practices and ethical considerations in the Claude Engineer project, ensuring a more secure and responsible AI-powered tool.
