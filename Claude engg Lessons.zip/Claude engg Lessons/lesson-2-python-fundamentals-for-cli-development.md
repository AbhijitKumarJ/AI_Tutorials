# Lesson 2: Python Fundamentals for CLI Development

## 1. Basic Python syntax and data structures

Python's syntax and data structures form the foundation of any Python program, including CLI tools. Let's explore the key elements:

### Variables and Data Types

Python is dynamically typed, meaning you don't need to declare variable types explicitly. Common data types include:

- **Integers**: Whole numbers, e.g., `x = 5`
- **Floats**: Decimal numbers, e.g., `y = 3.14`
- **Strings**: Text enclosed in quotes, e.g., `name = "Claude"`
- **Booleans**: True or False values, e.g., `is_active = True`

Example:
```python
age = 25
height = 1.75
name = "Alice"
is_student = True
```

### Lists

Lists are ordered, mutable sequences. They're versatile and commonly used in CLI tools for storing collections of data.

Example:
```python
fruits = ["apple", "banana", "cherry"]
numbers = [1, 2, 3, 4, 5]

# Accessing elements
print(fruits[0])  # Output: apple

# Modifying elements
fruits[1] = "orange"

# Adding elements
fruits.append("grape")

# List comprehension
squares = [x**2 for x in numbers]
```

### Dictionaries

Dictionaries are unordered collections of key-value pairs. They're excellent for storing structured data and configuration settings in CLI tools.

Example:
```python
user = {
    "name": "Bob",
    "age": 30,
    "city": "New York"
}

# Accessing values
print(user["name"])  # Output: Bob

# Adding or modifying key-value pairs
user["job"] = "Developer"

# Dictionary comprehension
squared_numbers = {x: x**2 for x in range(5)}
```

### Control Flow

Control flow structures help manage the execution of your CLI tool based on conditions.

#### If-Else Statements
```python
age = 20
if age >= 18:
    print("You are an adult")
elif age >= 13:
    print("You are a teenager")
else:
    print("You are a child")
```

#### Loops
For loops and while loops are crucial for iterating over data or repeating actions in CLI tools.

```python
# For loop
for fruit in fruits:
    print(f"I like {fruit}")

# While loop
count = 0
while count < 5:
    print(f"Count is {count}")
    count += 1
```

Understanding these basic syntax elements and data structures is crucial for building efficient and readable CLI tools. They form the building blocks for more complex operations and data management within your applications.

## 2. Functions, decorators, and modules

Functions, decorators, and modules are essential concepts in Python that help organize code, enhance reusability, and extend functionality. They are particularly useful in CLI development for creating modular and maintainable tools.

### Functions

Functions in Python are blocks of reusable code that perform specific tasks. They help in organizing code, improving readability, and reducing repetition.

Basic function structure:
```python
def greet(name):
    """This function greets the person passed in as a parameter"""
    return f"Hello, {name}!"

# Calling the function
message = greet("Alice")
print(message)  # Output: Hello, Alice!
```

Functions can have default parameters and return multiple values:

```python
def calculate_stats(numbers, include_sum=True):
    """Calculate statistics for a list of numbers"""
    average = sum(numbers) / len(numbers)
    if include_sum:
        return average, sum(numbers)
    return average

# Using the function
nums = [1, 2, 3, 4, 5]
avg, total = calculate_stats(nums)
print(f"Average: {avg}, Sum: {total}")
```

### Decorators

Decorators are a powerful feature in Python that allow you to modify or enhance functions without changing their source code. They are particularly useful in CLI tools for adding functionality like logging, timing, or error handling to existing functions.

Basic decorator example:
```python
import time

def timer_decorator(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        print(f"{func.__name__} took {end_time - start_time:.2f} seconds to execute")
        return result
    return wrapper

@timer_decorator
def slow_function():
    time.sleep(2)
    print("Function executed")

slow_function()
# Output:
# Function executed
# slow_function took 2.00 seconds to execute
```

In this example, the `timer_decorator` adds timing functionality to any function it decorates, which can be useful for performance monitoring in CLI tools.

### Modules

Modules in Python are files containing Python definitions and statements. They help in organizing related code into separate files, making large projects more manageable. In CLI development, modules can be used to separate different functionalities of your tool.

Creating a module:
1. Create a new file, e.g., `utils.py`
2. Add functions or classes to the file

```python
# utils.py
def celsius_to_fahrenheit(celsius):
    return (celsius * 9/5) + 32

def fahrenheit_to_celsius(fahrenheit):
    return (fahrenheit - 32) * 5/9
```

Using a module in your main script:
```python
import utils

temp_c = 25
temp_f = utils.celsius_to_fahrenheit(temp_c)
print(f"{temp_c}°C is equal to {temp_f}°F")
```

You can also use `from ... import ...` to import specific functions:
```python
from utils import celsius_to_fahrenheit

temp_c = 25
temp_f = celsius_to_fahrenheit(temp_c)
print(f"{temp_c}°C is equal to {temp_f}°F")
```

Understanding and effectively using functions, decorators, and modules will help you create well-structured, maintainable, and efficient CLI tools.

## 3. File I/O operations and context managers

File Input/Output (I/O) operations are crucial for CLI tools that need to read from or write to files. Python provides simple and powerful ways to handle file operations, and context managers ensure proper resource management.

### Basic File Operations

Python uses the `open()` function to open files. The basic syntax is:
```python
file = open('filename.txt', 'mode')
```
Where `mode` can be:
- `'r'` for reading (default)
- `'w'` for writing (overwrites the file)
- `'a'` for appending
- `'b'` added to the mode for binary files (e.g., `'rb'` for reading binary)

#### Reading from a file:
```python
# Reading entire file
with open('example.txt', 'r') as file:
    content = file.read()
    print(content)

# Reading line by line
with open('example.txt', 'r') as file:
    for line in file:
        print(line.strip())
```

#### Writing to a file:
```python
# Writing to a file
with open('output.txt', 'w') as file:
    file.write("Hello, World!\n")
    file.write("This is a new line.")

# Appending to a file
with open('output.txt', 'a') as file:
    file.write("\nThis line is appended.")
```

### Context Managers

Context managers, implemented using the `with` statement, ensure that resources (like file handles) are properly managed and closed after use, even if exceptions occur. They are essential for writing robust CLI tools that handle files efficiently.

The basic syntax is:
```python
with open('filename.txt', 'r') as file:
    # operations with the file
# file is automatically closed here
```

Benefits of using context managers:
1. Automatic resource management (closing files)
2. Exception handling
3. Cleaner and more readable code

Example of a custom context manager:
```python
from contextlib import contextmanager

@contextmanager
def file_manager(filename, mode):
    try:
        file = open(filename, mode)
        yield file
    finally:
        file.close()

# Using the custom context manager
with file_manager('example.txt', 'r') as file:
    content = file.read()
    print(content)
```

This custom context manager ensures that the file is always closed, even if an exception occurs during file operations.

### Practical CLI Tool Example

Let's create a simple CLI tool that reads a configuration file and performs an action based on the configuration:

```python
import json

def read_config(filename):
    with open(filename, 'r') as config_file:
        return json.load(config_file)

def write_log(filename, message):
    with open(filename, 'a') as log_file:
        log_file.write(f"{message}\n")

def main():
    try:
        config = read_config('config.json')
        action = config.get('action', 'default_action')
        
        print(f"Performing action: {action}")
        
        # Perform the action here
        
        write_log('app.log', f"Action '{action}' completed successfully")
    except FileNotFoundError:
        print("Config file not found. Please create a config.json file.")
    except json.JSONDecodeError:
        print("Invalid JSON in config file. Please check the format.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        write_log('app.log', f"Error: {str(e)}")

if __name__ == "__main__":
    main()
```

This example demonstrates how to use file I/O operations and context managers in a practical CLI tool scenario, including error handling and logging.

## 4. Error handling and exceptions

Proper error handling is crucial for creating robust and user-friendly CLI tools. Python's exception handling mechanism allows you to gracefully manage errors and provide meaningful feedback to users.

### Basic Exception Handling

The basic structure for exception handling in Python is the `try`-`except` block:

```python
try:
    # Code that might raise an exception
    result = 10 / 0
except ZeroDivisionError:
    # Handle the specific exception
    print("Error: Division by zero!")
```

You can handle multiple exceptions and provide a general catch-all:

```python
try:
    # Some risky operation
    value = int(input("Enter a number: "))
    result = 10 / value
except ValueError:
    print("Invalid input. Please enter a number.")
except ZeroDivisionError:
    print("Cannot divide by zero.")
except Exception as e:
    print(f"An unexpected error occurred: {str(e)}")
else:
    # This block runs if no exception was raised
    print(f"Result: {result}")
finally:
    # This block always runs, regardless of whether an exception was raised
    print("Operation completed.")
```

### Custom Exceptions

For CLI tools, it's often useful to define custom exceptions that provide more context about the specific errors that can occur in your application:

```python
class ConfigError(Exception):
    """Exception raised for errors in the configuration."""
    pass

class NetworkError(Exception):
    """Exception raised for network-related errors."""
    pass

def read_config(filename):
    try:
        with open(filename, 'r') as file:
            # Read and parse config
            if 'important_setting' not in config:
                raise ConfigError("Missing 'important_setting' in config")
    except FileNotFoundError:
        raise ConfigError(f"Config file '{filename}' not found")
    except json.JSONDecodeError:
        raise ConfigError(f"Invalid JSON in config file '{filename}'")

def main():
    try:
        config = read_config('config.json')
        # Use the config
    except ConfigError as e:
        print(f"Configuration error: {str(e)}")
        sys.exit(1)
    except NetworkError as e:
        print(f"Network error: {str(e)}")
        sys.exit(2)
    except Exception as e:
        print(f"An unexpected error occurred: {str(e)}")
        sys.exit(3)
```

### Best Practices for Error Handling in CLI Tools

1. **Be specific**: Catch specific exceptions when possible, rather than using a blanket `except` clause.
2. **Provide context**: When re-raising exceptions or creating custom ones, include relevant information to help diagnose the issue.
3. **Log errors**: In addition to displaying user-friendly messages, log detailed error information for debugging.
4. **Fail gracefully**: When an error occurs, ensure your tool cleans up resources and exits in a controlled manner.
5. **Use appropriate exit codes**: Different exit codes can indicate different types of errors to the calling process.

Example of implementing these practices:

```python
import sys
import logging

logging.basicConfig(filename='app.log', level=logging.ERROR)

def process_data(filename):
    try:
        with open(filename, 'r') as file:
            data = file.read()
        # Process the data
        return processed_data
    except FileNotFoundError:
        logging.error(f"File not found: {filename}")
        raise FileNotFoundError(f"The file '{filename}' does not exist.")
    except PermissionError:
        logging.error(f"Permission denied: {filename}")
        raise PermissionError(f"You don't have permission to read '{filename}'.")
    except Exception as e:
        logging.exception("An unexpected error occurred while processing the file")
        raise RuntimeError(f"An unexpected error occurred: {str(e)}")

def main():
    if len(sys.argv) < 2:
        print("Usage: python script.py <filename>")
        sys.exit(1)
    
    filename = sys.argv[1]
    try:
        result = process_data(filename)
        print(f"Data processed successfully: {result}")
    except FileNotFoundError as e:
        print(str(e))
        sys.exit(2)
    except PermissionError as e:
        print(str(e))
        sys.exit(3)
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        print("Please check the log file for more details.")
        sys.exit(4)

if __name__ == "__main__":
    main()
```

This example demonstrates how to handle errors in a CLI tool, providing user-friendly messages while also logging detailed information for debugging purposes.

## 5. Asynchronous programming with asyncio

Asynchronous programming is a powerful paradigm that allows your CLI tools to perform I/O-bound operations efficiently, such as making network requests or reading large files, without blocking the execution of other tasks. Python's `asyncio` library provides a way to write asynchronous code using coroutines, event loops, and tasks.

### Key Concepts

1. **Coroutines**: Functions defined with `async def` that can be paused and resumed.
2. **Event Loop**: The core of every asyncio application, it runs asynchronous tasks and callbacks.
3. **Tasks**: Wrappers around coroutines to track their execution.
4. **Awaitables**: Objects that can be used in an `await` expression (coroutines, tasks, and futures).

### Basic asyncio Usage

Here's a simple example to demonstrate the basic usage of asyncio:

```python
import asyncio

async def say_hello(name, delay):
    await asyncio.sleep(delay)  # Simulate an I/O-bound operation
    print(f"Hello, {name}!")

async def main():
    # Create tasks
    task1 = asyncio.create_task(say_hello("Alice", 2))
    task2 = asyncio.create_task(say_hello("Bob", 1))
    
    # Wait for both tasks to complete
    await task1
    await task2

if __name__ == "__main__":
    asyncio.run(main())
```

In this example, `say_hello` is a coroutine that simulates an I/O-bound operation using `asyncio.sleep()`. The `main()` function creates two tasks that run concurrently.

### Practical CLI Tool Example with asyncio

Let's create a more practical example of a CLI tool that uses asyncio to fetch data from multiple URLs concurrently:

```python
import asyncio
import aiohttp
import sys
from rich.console import Console
from rich.progress import Progress

console = Console()

async def fetch_url(session, url):
    async with session.get(url) as response:
        return await response.text()

async def process_urls(urls):
    async with aiohttp.ClientSession() as session:
        tasks = []
        for url in urls:
            tasks.append(asyncio.create_task(fetch_url(session, url)))
        
        results = []
        with Progress() as progress:
            overall_progress = progress.add_task("[green]Fetching URLs...", total=len(tasks))
            for future in asyncio.as_completed(tasks):
                result = await future
                results.append(result)
                progress.update(overall_progress, advance=1)
        
        return results

async def main(urls):
    try:
        results = await process_urls(urls)
        for url, result in zip(urls, results):
            console.print(f"[bold blue]{url}[/bold blue]: {len(result)} characters fetched")
    except aiohttp.ClientError as e:
        console.print(f"[bold red]Error fetching URLs: {str(e)}[/bold red]")
    except Exception as e:
        console.print(f"[bold red]An unexpected error occurred: {str(e)}[/bold red]")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        console.print("[bold red]Usage: python script.py <url1> <url2> ...[/bold red]")
        sys.exit(1)
    
    urls = sys.argv[1:]
    asyncio.run(main(urls))
```

This CLI tool fetches content from multiple URLs concurrently using `aiohttp` and `asyncio`. It demonstrates several key aspects of asyncio and CLI development:

1. **Concurrent I/O operations**: The tool fetches multiple URLs simultaneously, improving efficiency for I/O-bound tasks.
2. **Progress tracking**: It uses the `rich` library to display a progress bar, enhancing the user experience.
3. **Error handling**: The tool catches and reports errors specific to network operations and unexpected exceptions.
4. **Command-line argument parsing**: It processes URLs passed as command-line arguments.

### Best Practices for Using asyncio in CLI Tools

1. **Use asyncio for I/O-bound tasks**: Asynchronous programming shines when dealing with operations that involve waiting, such as network requests or file I/O.

2. **Avoid blocking calls**: Ensure that CPU-intensive operations don't block the event loop. Consider using `asyncio.to_thread()` for CPU-bound tasks.

3. **Manage concurrency**: Use `asyncio.Semaphore` to limit the number of concurrent operations if needed.

4. **Proper task management**: Always await or cancel tasks to prevent resource leaks.

5. **Error handling**: Use try/except blocks within coroutines to handle exceptions gracefully.

6. **Timeouts**: Implement timeouts for operations that might take too long using `asyncio.wait_for()`.

By incorporating asynchronous programming with asyncio, you can create more efficient and responsive CLI tools, especially when dealing with I/O-bound operations like network requests or file processing.

## 6. Type hinting and its benefits

Type hinting is a feature in Python that allows you to explicitly specify the expected types of function parameters, return values, and variables. While Python remains a dynamically typed language, type hints provide several benefits, especially for larger projects and CLI tools.

### Basic Syntax for Type Hinting

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"

age: int = 30
is_active: bool = True
```

In this example:
- `name: str` indicates that `name` is expected to be a string.
- `-> str` indicates that the function is expected to return a string.
- `age: int` and `is_active: bool` specify the expected types for variables.

### More Complex Type Hints

For more complex data structures, you can use the `typing` module:

```python
from typing import List, Dict, Optional, Union

def process_data(items: List[int]) -> Dict[str, int]:
    return {"sum": sum(items), "length": len(items)}

def find_user(user_id: int) -> Optional[Dict[str, Union[str, int]]]:
    # This function might return None or a dictionary with string keys and string or int values
    pass
```

### Benefits of Type Hinting

1. **Improved code readability**: Type hints serve as inline documentation, making it easier for developers to understand what kind of data a function expects and returns.

2. **Better IDE support**: IDEs can provide more accurate auto-completion, refactoring support, and error detection based on type hints.

3. **Catch errors early**: Static type checkers like mypy can catch type-related errors before runtime, reducing bugs in production.

4. **Easier refactoring**: When changing function signatures or data structures, type hints help identify places that need to be updated.

5. **Self-documenting code**: Type hints reduce the need for explicit documentation about parameter and return types.

6. **Improved collaboration**: In team projects, type hints make it clearer how functions and modules should be used.

### Type Hinting in CLI Tools

Let's look at an example of how type hinting can be used in a CLI tool:

```python
import argparse
from typing import List, Optional

def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Process some integers.")
    parser.add_argument('integers', metavar='N', type=int, nargs='+',
                        help='an integer for the accumulator')
    parser.add_argument('--sum', dest='accumulate', action='store_const',
                        const=sum, default=max,
                        help='sum the integers (default: find the max)')
    return parser.parse_args()

def process_numbers(numbers: List[int], operation: Optional[str] = None) -> int:
    if operation == 'sum':
        return sum(numbers)
    return max(numbers)

def main() -> None:
    args = parse_arguments()
    result = process_numbers(args.integers, 'sum' if args.accumulate == sum else None)
    print(f"The result is: {result}")

if __name__ == "__main__":
    main()
```

In this example:
- Type hints clearly indicate what types of arguments functions expect and what they return.
- The `Optional[str]` hint in `process_numbers` indicates that the `operation` parameter can be a string or None.
- The `-> None` hint for `main()` indicates that it doesn't return anything.

### Best Practices for Type Hinting

1. **Be consistent**: Once you start using type hints, try to use them throughout your project for consistency.

2. **Use type checkers**: Regularly run static type checkers like mypy to catch type-related issues early.

3. **Don't overspecify**: Use broader types when appropriate. For example, use `Sequence[int]` instead of `List[int]` if you only need the sequence protocol.

4. **Use forward references**: When hinting with a type that hasn't been defined yet, use string literals: `def f() -> "MyClass": ...`

5. **Consider using TypedDict for dictionaries**: When working with dictionaries that have a specific structure, `TypedDict` can provide more precise typing.

6. **Use Protocol for duck typing**: When you care about the presence of certain methods rather than the exact type, consider using `Protocol`.

By incorporating type hinting into your CLI tools, you can create more robust, self-documenting code that's easier to maintain and less prone to certain types of errors. While it requires a bit more upfront effort, the long-term benefits in code quality and developer productivity are significant.


    