# Lesson 7: Code Execution and Process Management

## Introduction

In this lesson, we'll explore how our AI-powered CLI tool handles code execution and process management. These features allow the AI agent to run code, analyze its output, and manage long-running processes. This functionality is crucial for testing code snippets, diagnosing issues, and performing complex operations that may take significant time to complete.

## 1. Setting up Isolated Virtual Environments for Code Execution

To ensure security and consistency in code execution, we use isolated virtual environments. This approach prevents potential conflicts with the system's global Python installation and provides a clean, controlled environment for running code. Let's examine how we set up these environments:

```python
def setup_virtual_environment() -> Tuple[str, str]:
    venv_name = "code_execution_env"
    venv_path = os.path.join(os.getcwd(), venv_name)
    try:
        if not os.path.exists(venv_path):
            venv.create(venv_path, with_pip=True)

        # Activate the virtual environment
        if sys.platform == "win32":
            activate_script = os.path.join(venv_path, "Scripts", "activate.bat")
        else:
            activate_script = os.path.join(venv_path, "bin", "activate")

        return venv_path, activate_script
    except Exception as e:
        logging.error(f"Error setting up virtual environment: {str(e)}")
        raise
```

Key points about this implementation:
- We use the `venv` module to create a virtual environment named "code_execution_env" if it doesn't already exist.
- The function determines the correct activation script path based on the operating system (Windows or Unix-based).
- It returns both the virtual environment path and the activation script path, which will be used when executing code.
- Error handling is implemented to log any issues that occur during setup.

This setup ensures that each code execution happens in a fresh, isolated environment, reducing the risk of interference from previously installed packages or system-wide configurations.

## 2. Implementing the execute_code Tool

The `execute_code` function is the core of our code execution capability. It runs Python code in the isolated virtual environment and returns the output. Here's its implementation:

```python
async def execute_code(code, timeout=10):
    global running_processes
    venv_path, activate_script = setup_virtual_environment()

    # Input validation
    if not isinstance(code, str):
        raise ValueError("code must be a string")
    if not isinstance(timeout, (int, float)):
        raise ValueError("timeout must be a number")

    # Generate a unique identifier for this process
    process_id = f"process_{len(running_processes)}"

    # Write the code to a temporary file
    try:
        with open(f"{process_id}.py", "w") as f:
            f.write(code)
    except IOError as e:
        return process_id, f"Error writing code to file: {str(e)}"

    # Prepare the command to run the code
    if sys.platform == "win32":
        command = f'"{activate_script}" && python3 {process_id}.py'
    else:
        command = f'source "{activate_script}" && python3 {process_id}.py'

    try:
        # Create a process to run the command
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            shell=True,
            preexec_fn=None if sys.platform == "win32" else os.setsid
        )

        # Store the process in our global dictionary
        running_processes[process_id] = process

        try:
            # Wait for initial output or timeout
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
            stdout = stdout.decode()
            stderr = stderr.decode()
            return_code = process.returncode
        except asyncio.TimeoutError:
            # If we timeout, it means the process is still running
            stdout = "Process started and running in the background."
            stderr = ""
            return_code = "Running"

        execution_result = f"Process ID: {process_id}\n\nStdout:\n{stdout}\n\nStderr:\n{stderr}\n\nReturn Code: {return_code}"
        return process_id, execution_result
    except Exception as e:
        return process_id, f"Error executing code: {str(e)}"
    finally:
        # Cleanup: remove the temporary file
        try:
            os.remove(f"{process_id}.py")
        except OSError:
            pass  # Ignore errors in removing the file
```

Key points about this implementation:
- The function takes a code string and an optional timeout parameter.
- It creates a temporary Python file with the provided code.
- The code is executed in the isolated virtual environment using the activation script.
- Asynchronous subprocesses are used to run the code, allowing for non-blocking execution.
- A timeout mechanism is implemented to handle long-running processes.
- The function returns a process ID, which can be used to manage long-running processes.
- Detailed output, including stdout, stderr, and return code, is captured and returned.
- Error handling is implemented at various stages to catch and report issues.
- Cleanup is performed to remove temporary files after execution.

## 3. Managing Long-running Processes

To handle long-running processes, we implement a `stop_process` function:

```python
def stop_process(process_id):
    global running_processes
    if process_id in running_processes:
        process = running_processes[process_id]
        if sys.platform == "win32":
            process.terminate()
        else:
            os.killpg(os.getpgid(process.pid), signal.SIGTERM)
        del running_processes[process_id]
        return f"Process {process_id} has been stopped."
    else:
        return f"No running process found with ID {process_id}."
```

Key points about this implementation:
- It uses the `running_processes` dictionary to keep track of active processes.
- The function handles process termination differently on Windows and Unix-based systems.
- It removes the process from the `running_processes` dictionary after termination.
- Clear feedback is provided about the success or failure of the operation.

This function allows users to stop long-running processes that were started by the `execute_code` tool, providing control over resource usage and execution time.

## 4. Analyzing Code Execution Results

After executing code, it's often useful to provide an analysis of the results. We use the CODEEXECUTIONMODEL for this purpose:

```python
async def send_to_ai_for_executing(code, execution_result):
    global code_execution_tokens

    try:
        system_prompt = f"""
        You are an AI code execution agent. Your task is to analyze the provided code and its execution result from the 'code_execution_env' virtual environment, then provide a concise summary of what worked, what didn't work, and any important observations. Follow these steps:

        1. Review the code that was executed in the 'code_execution_env' virtual environment:
        {code}

        2. Analyze the execution result from the 'code_execution_env' virtual environment:
        {execution_result}

        3. Provide a brief summary of:
           - What parts of the code executed successfully in the virtual environment
           - Any errors or unexpected behavior encountered in the virtual environment
           - Potential improvements or fixes for issues, considering the isolated nature of the environment
           - Any important observations about the code's performance or output within the virtual environment
           - If the execution timed out, explain what this might mean (e.g., long-running process, infinite loop)

        Be concise and focus on the most important aspects of the code execution within the 'code_execution_env' virtual environment.

        IMPORTANT: PROVIDE ONLY YOUR ANALYSIS AND OBSERVATIONS. DO NOT INCLUDE ANY PREFACING STATEMENTS OR EXPLANATIONS OF YOUR ROLE.
        """

        response = client.beta.prompt_caching.messages.create(
            model=CODEEXECUTIONMODEL,
            max_tokens=2000,
            system=[
                {
                    "type": "text",
                    "text": system_prompt,
                    "cache_control": {"type": "ephemeral"}
                }
            ],
            messages=[
                {"role": "user", "content": f"Analyze this code execution from the 'code_execution_env' virtual environment:\n\nCode:\n{code}\n\nExecution Result:\n{execution_result}"}
            ],
            extra_headers={"anthropic-beta": "prompt-caching-2024-07-31"}
        )

        # Update token usage for code execution
        code_execution_tokens['input'] += response.usage.input_tokens
        code_execution_tokens['output'] += response.usage.output_tokens
        code_execution_tokens['cache_creation'] = response.usage.cache_creation_input_tokens
        code_execution_tokens['cache_read'] = response.usage.cache_read_input_tokens

        analysis = response.content[0].text

        return analysis

    except Exception as e:
        console.print(f"Error in AI code execution analysis: {str(e)}", style="bold red")
        return f"Error analyzing code execution from 'code_execution_env': {str(e)}"
```

Key points about this implementation:
- It uses a specialized AI model (CODEEXECUTIONMODEL) to analyze the code and its execution results.
- The system prompt provides clear instructions on what aspects of the code execution to analyze.
- The function handles token usage tracking for the code execution model.
- Error handling is implemented to catch and report any issues during the analysis process.

This analysis provides valuable insights into the code execution, helping users understand the results and identify any issues or areas for improvement.

## 5. Ensuring Security in Code Execution

Security is a critical concern when implementing code execution features. Here are some key security measures implemented in our system:

1. Isolated Virtual Environments: By using separate virtual environments for code execution, we prevent malicious code from affecting the main system or other projects.

2. Timeout Mechanism: The timeout in `execute_code` prevents infinite loops or resource-intensive processes from running indefinitely.

3. Process Management: The ability to stop long-running processes gives users control over execution and resource usage.

4. File Cleanup: Temporary files created for code execution are removed after use, preventing potential information leaks.

5. Input Validation: The `execute_code` function validates its inputs to ensure they meet expected types and formats.

6. Error Handling: Comprehensive error handling prevents exposure of sensitive information in error messages.

7. Limited Scope: The execution environment has limited access to system resources and is not connected to sensitive parts of the main application.

While these measures significantly enhance security, it's important to note that executing arbitrary code always carries some risk. Users should be cautioned about running untrusted code, and additional measures like sandboxing could be considered for higher security requirements.

## Conclusion

In this lesson, we've explored the implementation of code execution and process management features in our AI-powered CLI tool. We've seen how to set up isolated virtual environments, execute code safely, manage long-running processes, and analyze execution results.

These features greatly enhance the capabilities of our tool, allowing it to not just suggest code but also run and analyze it. This enables more interactive and dynamic problem-solving, as the AI agent can propose solutions, test them, and refine based on the results.

In the next lesson, we'll dive into web search integration and information retrieval, further expanding the knowledge base and capabilities of our AI agent.

