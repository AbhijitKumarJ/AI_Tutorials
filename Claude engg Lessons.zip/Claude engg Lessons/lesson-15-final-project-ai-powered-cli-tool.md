# Lesson 15: Final Project: Building Your Own AI-Powered CLI Tool

## Introduction

In this final lesson, we'll put all the knowledge and skills you've acquired throughout this course into practice by building your own AI-powered CLI tool. This project will consolidate your understanding of CLI development, API integration, AI implementation, security practices, and software engineering principles.

## Project Overview

You'll be creating a versatile AI-powered CLI tool called "DevAssist" that helps developers with various tasks such as code analysis, documentation generation, and project management. This tool will integrate with multiple APIs, implement secure coding practices, and follow the ethical AI guidelines we've discussed.

## Learning Objectives

By the end of this project, you will be able to:

1. Design and implement a comprehensive AI-powered CLI tool
2. Integrate multiple external APIs securely
3. Implement advanced CLI features using libraries like Click and Rich
4. Apply security best practices in a real-world project
5. Create comprehensive documentation and testing for your tool

## Project Requirements

Your DevAssist CLI tool should include the following features:

1. Code Analysis: Analyze code snippets or entire files for potential improvements, security vulnerabilities, and adherence to best practices.
2. Documentation Generation: Generate documentation for code files or entire projects.
3. Project Management: Create project structures, manage tasks, and generate reports.
4. AI-Powered Assistance: Provide intelligent responses to development-related questions.
5. Security Features: Implement secure handling of API keys, input sanitization, and safe code execution.
6. Ethical AI: Implement features to ensure responsible AI usage, including bias detection and explainable AI outputs.

Let's break down the implementation of these features:

### 1. Project Setup

First, let's set up the basic structure of our project:

```
devassist/
├── devassist/
│   ├── __init__.py
│   ├── cli.py
│   ├── code_analysis.py
│   ├── documentation.py
│   ├── project_management.py
│   ├── ai_assistant.py
│   ├── security.py
│   └── utils.py
├── tests/
│   ├── __init__.py
│   ├── test_code_analysis.py
│   ├── test_documentation.py
│   ├── test_project_management.py
│   └── test_ai_assistant.py
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── setup.py
```

### 2. Setting Up the CLI

We'll use Click to create our CLI interface. Here's a basic setup in `cli.py`:

```python
import click
from rich.console import Console
from devassist import code_analysis, documentation, project_management, ai_assistant

console = Console()

@click.group()
def cli():
    """DevAssist: Your AI-powered development assistant."""
    pass

@cli.command()
@click.argument('file_path')
def analyze(file_path):
    """Analyze a code file for improvements and vulnerabilities."""
    result = code_analysis.analyze_file(file_path)
    console.print(result)

@cli.command()
@click.argument('path')
def document(path):
    """Generate documentation for a file or project."""
    result = documentation.generate_docs(path)
    console.print(result)

@cli.command()
@click.argument('project_name')
def create_project(project_name):
    """Create a new project structure."""
    result = project_management.create_project(project_name)
    console.print(result)

@cli.command()
@click.argument('question')
def ask(question):
    """Ask a development-related question."""
    result = ai_assistant.ask_question(question)
    console.print(result)

if __name__ == '__main__':
    cli()
```

### 3. Implementing Code Analysis

In `code_analysis.py`, we'll implement code analysis using a combination of static analysis tools and AI:

```python
import ast
import pylint.lint
from anthropic import Anthropic
from devassist.security import get_api_key

anthropic = Anthropic(api_key=get_api_key('ANTHROPIC_API_KEY'))

def analyze_file(file_path):
    with open(file_path, 'r') as file:
        code = file.read()
    
    # Static analysis
    tree = ast.parse(code)
    static_analysis = analyze_ast(tree)
    
    # Pylint analysis
    pylint_analysis = run_pylint(file_path)
    
    # AI analysis
    ai_analysis = get_ai_analysis(code)
    
    return {
        'static_analysis': static_analysis,
        'pylint_analysis': pylint_analysis,
        'ai_analysis': ai_analysis
    }

def analyze_ast(tree):
    # Implement AST analysis here
    pass

def run_pylint(file_path):
    # Run pylint and capture output
    pass

def get_ai_analysis(code):
    prompt = f"Analyze the following Python code for potential improvements and security vulnerabilities:\n\n{code}"
    response = anthropic.completions.create(
        model="claude-2",
        prompt=prompt,
        max_tokens_to_sample=1000
    )
    return response.completion
```

### 4. Generating Documentation

In `documentation.py`, we'll implement documentation generation:

```python
import ast
from anthropic import Anthropic
from devassist.security import get_api_key

anthropic = Anthropic(api_key=get_api_key('ANTHROPIC_API_KEY'))

def generate_docs(path):
    if path.endswith('.py'):
        return generate_file_docs(path)
    else:
        return generate_project_docs(path)

def generate_file_docs(file_path):
    with open(file_path, 'r') as file:
        code = file.read()
    
    tree = ast.parse(code)
    docstrings = extract_docstrings(tree)
    
    prompt = f"Generate comprehensive documentation for the following Python code:\n\n{code}\n\nExisting docstrings:\n{docstrings}"
    response = anthropic.completions.create(
        model="claude-2",
        prompt=prompt,
        max_tokens_to_sample=2000
    )
    return response.completion

def extract_docstrings(tree):
    # Extract existing docstrings from the AST
    pass

def generate_project_docs(project_path):
    # Generate documentation for an entire project
    pass
```

### 5. Project Management

In `project_management.py`, we'll implement project creation and management features:

```python
import os
import json
from anthropic import Anthropic
from devassist.security import get_api_key

anthropic = Anthropic(api_key=get_api_key('ANTHROPIC_API_KEY'))

def create_project(project_name):
    # Create project directory
    os.makedirs(project_name, exist_ok=True)
    
    # Generate project structure
    structure = generate_project_structure(project_name)
    
    # Create files and directories
    create_project_files(project_name, structure)
    
    return f"Project '{project_name}' created successfully."

def generate_project_structure(project_name):
    prompt = f"Generate a detailed project structure for a Python project named '{project_name}'. Include directories for source code, tests, documentation, and any other relevant components. Provide the structure as a JSON object."
    
    response = anthropic.completions.create(
        model="claude-2",
        prompt=prompt,
        max_tokens_to_sample=1000
    )
    
    return json.loads(response.completion)

def create_project_files(project_name, structure):
    for item, content in structure.items():
        path = os.path.join(project_name, item)
        if isinstance(content, dict):
            os.makedirs(path, exist_ok=True)
            create_project_files(path, content)
        else:
            with open(path, 'w') as f:
                f.write(content)

def add_task(project_name, task_description):
    tasks_file = os.path.join(project_name, 'tasks.json')
    
    if os.path.exists(tasks_file):
        with open(tasks_file, 'r') as f:
            tasks = json.load(f)
    else:
        tasks = []
    
    new_task = {
        'id': len(tasks) + 1,
        'description': task_description,
        'status': 'To Do'
    }
    tasks.append(new_task)
    
    with open(tasks_file, 'w') as f:
        json.dump(tasks, f, indent=2)
    
    return f"Task added to project '{project_name}'"

def generate_report(project_name):
    # Analyze project structure
    structure = analyze_project_structure(project_name)
    
    # Analyze tasks
    tasks = analyze_tasks(project_name)
    
    # Generate report using AI
    prompt = f"Generate a comprehensive project report for '{project_name}' based on the following information:\n\nProject Structure:\n{json.dumps(structure, indent=2)}\n\nTasks:\n{json.dumps(tasks, indent=2)}"
    
    response = anthropic.completions.create(
        model="claude-2",
        prompt=prompt,
        max_tokens_to_sample=2000
    )
    
    return response.completion

def analyze_project_structure(project_name):
    # Implement project structure analysis
    pass

def analyze_tasks(project_name):
    # Implement task analysis
    pass
```

This implementation of the project management module provides several key features:

1. **Project Creation**: The `create_project` function generates a new project structure based on AI recommendations. It uses the Anthropic API to generate a detailed project structure, which is then created on the file system.

2. **Task Management**: The `add_task` function allows users to add tasks to a project. Tasks are stored in a JSON file within the project directory, making it easy to track and manage project tasks.

3. **Report Generation**: The `generate_report` function creates a comprehensive project report. It analyzes the project structure and tasks, then uses the Anthropic API to generate a detailed report based on this information.

### 6. AI Assistant

Let's implement the AI assistant functionality in `ai_assistant.py`:

```python
from anthropic import Anthropic
from devassist.security import get_api_key

anthropic = Anthropic(api_key=get_api_key('ANTHROPIC_API_KEY'))

def ask_question(question):
    prompt = f"As an AI assistant for software development, please answer the following question:\n\n{question}\n\nProvide a detailed and helpful response, including code examples where appropriate."
    
    response = anthropic.completions.create(
        model="claude-2",
        prompt=prompt,
        max_tokens_to_sample=2000
    )
    
    return response.completion

def suggest_improvements(code):
    prompt = f"Analyze the following code and suggest improvements:\n\n{code}\n\nProvide detailed suggestions for improving code quality, efficiency, and adherence to best practices."
    
    response = anthropic.completions.create(
        model="claude-2",
        prompt=prompt,
        max_tokens_to_sample=2000
    )
    
    return response.completion

def explain_code(code):
    prompt = f"Explain the following code in detail:\n\n{code}\n\nProvide a comprehensive explanation of what the code does, how it works, and any important concepts or patterns used."
    
    response = anthropic.completions.create(
        model="claude-2",
        prompt=prompt,
        max_tokens_to_sample=2000
    )
    
    return response.completion
```

This AI assistant module provides three main functions:

1. **ask_question**: Allows users to ask general development-related questions.
2. **suggest_improvements**: Analyzes a given piece of code and suggests improvements.
3. **explain_code**: Provides a detailed explanation of a given code snippet.

### 7. Security Implementation

In `security.py`, let's implement some security features:

```python
import os
from cryptography.fernet import Fernet
from dotenv import load_dotenv

load_dotenv()

# Initialize encryption key
ENCRYPTION_KEY = os.getenv('ENCRYPTION_KEY')
if not ENCRYPTION_KEY:
    ENCRYPTION_KEY = Fernet.generate_key()
    with open('.env', 'a') as f:
        f.write(f'\nENCRYPTION_KEY={ENCRYPTION_KEY.decode()}')

fernet = Fernet(ENCRYPTION_KEY)

def encrypt_data(data):
    return fernet.encrypt(data.encode()).decode()

def decrypt_data(encrypted_data):
    return fernet.decrypt(encrypted_data.encode()).decode()

def get_api_key(key_name):
    encrypted_key = os.getenv(key_name)
    if encrypted_key:
        return decrypt_data(encrypted_key)
    else:
        raise ValueError(f"{key_name} not found in environment variables")

def set_api_key(key_name, value):
    encrypted_value = encrypt_data(value)
    os.environ[key_name] = encrypted_value
    with open('.env', 'a') as f:
        f.write(f'\n{key_name}={encrypted_value}')

def sanitize_input(input_string):
    # Implement input sanitization
    # This is a basic example; in a real-world scenario, you'd want more comprehensive sanitization
    return input_string.replace(';', '').replace('&', '').replace('|', '')
```

This security module provides several important features:

1. **Encryption**: It uses the Fernet symmetric encryption to encrypt sensitive data like API keys.
2. **Secure API Key Management**: The `get_api_key` and `set_api_key` functions allow for secure storage and retrieval of API keys.
3. **Input Sanitization**: The `sanitize_input` function provides a basic example of input sanitization to prevent command injection attacks.

### 8. Ethical AI Implementation

Let's add some ethical AI features to our `ai_assistant.py`:

```python
import json
from anthropic import Anthropic
from devassist.security import get_api_key

anthropic = Anthropic(api_key=get_api_key('ANTHROPIC_API_KEY'))

def detect_bias(text):
    prompt = f"Analyze the following text for potential biases:\n\n{text}\n\nIdentify any language or concepts that might exhibit bias related to gender, race, age, or other protected characteristics. Provide a detailed analysis of any biases found and suggestions for more inclusive alternatives."
    
    response = anthropic.completions.create(
        model="claude-2",
        prompt=prompt,
        max_tokens_to_sample=1000
    )
    
    return json.loads(response.completion)

def explain_decision(decision, context):
    prompt = f"Provide a detailed explanation for the following AI-generated decision:\n\nDecision: {decision}\n\nContext: {context}\n\nExplain the reasoning behind this decision, including the factors considered and how they influenced the outcome. Ensure the explanation is clear and understandable to a non-technical audience."
    
    response = anthropic.completions.create(
        model="claude-2",
        prompt=prompt,
        max_tokens_to_sample=1000
    )
    
    return response.completion

def ethical_review(code):
    prompt = f"Conduct an ethical review of the following code:\n\n{code}\n\nAnalyze the code for potential ethical issues, including but not limited to privacy concerns, fairness, transparency, and potential for misuse. Provide a detailed report of any ethical considerations found and suggestions for addressing them."
    
    response = anthropic.completions.create(
        model="claude-2",
        prompt=prompt,
        max_tokens_to_sample=2000
    )
    
    return json.loads(response.completion)
```

These functions enhance our AI assistant with ethical considerations:

1. **detect_bias**: Analyzes text for potential biases related to protected characteristics.
2. **explain_decision**: Provides clear explanations for AI-generated decisions, promoting transparency.
3. **ethical_review**: Conducts an ethical review of code, considering privacy, fairness, and potential misuse.

### 9. Testing

Finally, let's add some tests to ensure our tool works as expected. Here's an example test file `test_code_analysis.py`:

```python
import unittest
from devassist import code_analysis

class TestCodeAnalysis(unittest.TestCase):
    def test_analyze_file(self):
        result = code_analysis.analyze_file('test_file.py')
        self.assertIn('static_analysis', result)
        self.assertIn('pylint_analysis', result)
        self.assertIn('ai_analysis', result)
    
    def test_analyze_ast(self):
        code = "def test_function():\n    pass"
        tree = ast.parse(code)
        result = code_analysis.analyze_ast(tree)
        self.assertIsInstance(result, dict)
    
    def test_run_pylint(self):
        result = code_analysis.run_pylint('test_file.py')
        self.assertIsInstance(result, str)
    
    def test_get_ai_analysis(self):
        code = "def test_function():\n    pass"
        result = code_analysis.get_ai_analysis(code)
        self.assertIsInstance(result, str)
        self.assertGreater(len(result), 0)

if __name__ == '__main__':
    unittest.main()
```

This test file covers the main functionalities of our code analysis module. You should create similar test files for other modules to ensure comprehensive test coverage.

## Conclusion

In this final project, we've created a powerful AI-powered CLI tool that assists developers with various tasks. We've implemented code analysis, documentation generation, project management, and an AI assistant. We've also incorporated security best practices and ethical AI considerations.

This project demonstrates how to integrate multiple APIs, implement CLI functionality, and apply the concepts of security and ethical AI that we've learned throughout the course. By completing this project, you've gained practical experience in building a real-world AI-powered developer tool.

## Next Steps

To further improve and expand your DevAssist tool, consider the following:

1. Implement more advanced code analysis features, such as detecting design patterns or suggesting refactorings.
2. Enhance the project management capabilities with features like dependency tracking or integration with version control systems.
3. Expand the AI assistant to provide more specialized advice for different programming languages or frameworks.
4. Implement a plugin system to allow users to extend the tool's functionality.
5. Create a web interface to complement the CLI, providing a more visual way to interact with the tool.
6. Implement continuous integration and deployment for your tool, including automated testing and release management.

Remember to continually update and improve your tool based on user feedback and new developments in AI and software engineering best practices.
