# Lesson 5: AI Agent Architecture and Implementation

## Introduction

In this lesson, we'll dive deep into the heart of our AI-powered CLI tool: the AI agent architecture. We'll explore how to design and implement an intelligent agent that can understand user queries, maintain context, and leverage different AI models for specialized tasks. By the end of this lesson, you'll have a solid understanding of how to create a sophisticated AI agent that can handle complex interactions and tasks.

## 1. Understanding the Concept of AI Agents

Before we delve into the implementation details, let's first understand what an AI agent is and why it's crucial for our CLI tool.

An AI agent is a software entity that can perceive its environment, make decisions, and take actions to achieve specific goals. In the context of our Claude Engineer project, the AI agent serves as the brain of our CLI tool, processing user inputs, managing conversations, and coordinating various tools and models to provide intelligent responses and perform tasks.

Key characteristics of our AI agent include:

- Ability to understand and process natural language inputs
- Maintenance of conversation history and context
- Dynamic adaptation of its behavior based on the current mode (e.g., regular chat vs. automode)
- Coordination of multiple AI models for specialized tasks
- Management of token usage and optimization of responses

## 2. Implementing Conversation History and Context Management

One of the most critical aspects of our AI agent is its ability to maintain context throughout a conversation. This allows it to provide more relevant and coherent responses over time. Let's look at how we implement this in our `main.py` file:

```python
# At the top of main.py
conversation_history = []

# Inside the chat_with_claude function
def chat_with_claude(user_input, image_path=None, current_iteration=None, max_iterations=None):
    global conversation_history

    current_conversation = []

    if image_path:
        # Process image input
        # ...

    current_conversation.append({"role": "user", "content": user_input})

    # Filter conversation history
    filtered_conversation_history = []
    for message in conversation_history:
        if isinstance(message['content'], list):
            filtered_content = [
                content for content in message['content']
                if content.get('type') != 'tool_result' or (
                    content.get('type') == 'tool_result' and
                    not any(keyword in content.get('output', '') for keyword in [
                        "File contents updated in system prompt",
                        "File created and added to system prompt",
                        "has been read and stored in the system prompt"
                    ])
                )
            ]
            if filtered_content:
                filtered_conversation_history.append({**message, 'content': filtered_content})
        else:
            filtered_conversation_history.append(message)

    # Combine filtered history with current conversation
    messages = filtered_conversation_history + current_conversation

    # ... (API call and response processing)

    # Update conversation history
    conversation_history = messages + [{"role": "assistant", "content": assistant_response}]
```

In this implementation:

1. We maintain a global `conversation_history` list to store all messages.
2. For each new interaction, we create a `current_conversation` list to hold the latest user input and any potential image data.
3. We filter the conversation history to remove certain tool results that don't need to be included in the context.
4. We combine the filtered history with the current conversation to create the full context for the AI model.
5. After receiving and processing the AI's response, we update the `conversation_history` with the new interaction.

This approach allows our AI agent to maintain context over long conversations while also managing the token usage by filtering out unnecessary information.

## 3. Creating a Dynamic System Prompt

To make our AI agent more flexible and context-aware, we implement a dynamic system prompt that adapts based on the current mode of operation (regular chat or automode). This is achieved through the `update_system_prompt` function:

```python
def update_system_prompt(current_iteration: Optional[int] = None, max_iterations: Optional[int] = None) -> str:
    global file_contents
    chain_of_thought_prompt = """
    Answer the user's request using relevant tools (if they are available). Before calling a tool, do some analysis within <thinking></thinking> tags. First, think about which of the provided tools is the relevant tool to answer the user's request. Second, go through each of the required parameters of the relevant tool and determine if the user has directly provided or given enough information to infer a value. When deciding if the parameter can be inferred, carefully consider all the context to see if it supports a specific value. If all of the required parameters are present or can be reasonably inferred, close the thinking tag and proceed with the tool call. BUT, if one of the values for a required parameter is missing, DO NOT invoke the function (not even with fillers for the missing params) and instead, ask the user to provide the missing parameters. DO NOT ask for more information on optional parameters if it is not provided.

    Do not reflect on the quality of the returned search results in your response.

    IMPORTANT: Before using the read_multiple_files tool, always check if the files you need are already in your context (system prompt).
    If the file contents are already available to you, use that information directly instead of calling the read_multiple_files tool.
    Only use the read_multiple_files tool for files that are not already in your context.
    When instructing to read a file, always use the full file path.
    """

    files_in_context = "\n".join(file_contents.keys())
    file_contents_prompt = f"\n\nFiles already in your context:\n{files_in_context}\n\nFile Contents:\n"
    for path, content in file_contents.items():
        file_contents_prompt += f"\n--- {path} ---\n{content}\n"

    if automode:
        iteration_info = ""
        if current_iteration is not None and max_iterations is not None:
            iteration_info = f"You are currently on iteration {current_iteration} out of {max_iterations} in automode."
        return BASE_SYSTEM_PROMPT + file_contents_prompt + "\n\n" + AUTOMODE_SYSTEM_PROMPT.format(iteration_info=iteration_info) + "\n\n" + chain_of_thought_prompt
    else:
        return BASE_SYSTEM_PROMPT + file_contents_prompt + "\n\n" + chain_of_thought_prompt
```

This function does several important things:

1. It includes a `chain_of_thought_prompt` that guides the AI's thinking process, especially when using tools.
2. It adds information about files already in the context, helping to prevent unnecessary file reads.
3. It adapts the prompt based on whether the agent is in automode or not, including iteration information when relevant.
4. It combines different components of the prompt (base prompt, file contents, automode-specific instructions) to create a comprehensive system prompt.

By using this dynamic system prompt, our AI agent can adapt its behavior and knowledge base to the current state of the conversation and the mode of operation.

## 4. Handling Different AI Models

Our Claude Engineer project uses multiple AI models for different tasks. This allows us to optimize performance and tailor the AI's capabilities to specific needs. Here's how we define and use these models:

```python
# Constants for different models
MAINMODEL = "claude-3-5-sonnet-20240620"
TOOLCHECKERMODEL = "claude-3-5-sonnet-20240620"
CODEEDITORMODEL = "claude-3-5-sonnet-20240620"
CODEEXECUTIONMODEL = "claude-3-5-sonnet-20240620"

# Using different models for specific tasks
# Main conversation model
response = client.beta.prompt_caching.messages.create(
    model=MAINMODEL,
    max_tokens=8000,
    system=[
        {
            "type": "text",
            "text": update_system_prompt(current_iteration, max_iterations),
            "cache_control": {"type": "ephemeral"}
        },
        {
            "type": "text",
            "text": json.dumps(tools),
            "cache_control": {"type": "ephemeral"}
        }
    ],
    messages=messages,
    tools=tools,
    tool_choice={"type": "auto"},
    extra_headers={"anthropic-beta": "prompt-caching-2024-07-31"}
)

# Tool checker model
tool_response = client.messages.create(
    model=TOOLCHECKERMODEL,
    max_tokens=8000,
    system=update_system_prompt(current_iteration, max_iterations),
    extra_headers={"anthropic-beta": "max-tokens-3-5-sonnet-2024-07-15"},
    messages=messages,
    tools=tools,
    tool_choice={"type": "auto"}
)

# Code editor model
response = client.beta.prompt_caching.messages.create(
    model=CODEEDITORMODEL,
    max_tokens=8000,
    system=[
        {
            "type": "text",
            "text": system_prompt,
            "cache_control": {"type": "ephemeral"}
        }
    ],
    messages=[
        {"role": "user", "content": "Generate SEARCH/REPLACE blocks for the necessary changes."}
    ],
    extra_headers={"anthropic-beta": "prompt-caching-2024-07-31"}
)

# Code execution model
response = client.beta.prompt_caching.messages.create(
    model=CODEEXECUTIONMODEL,
    max_tokens=2000,
    system=[
        {
            "type": "text",
            "text": system_prompt,
            "cache_control": {"type": "ephemeral"}
        }
    ],
    messages=[
        {"role": "user", "content": f"Analyze this code execution from the 'code_execution_env' virtual environment:\n\nCode:\n{code}\n\nExecution Result:\n{execution_result}"}
    ],
    extra_headers={"anthropic-beta": "prompt-caching-2024-07-31"}
)
```

By using different models for different tasks, we can:

1. Optimize performance by using more powerful models for complex tasks and lighter models for simpler tasks.
2. Tailor the system prompts and instructions to the specific requirements of each task.
3. Manage token usage more effectively by using appropriate model sizes for each task.
4. Potentially parallelize certain operations by leveraging multiple models simultaneously.

## 5. Token Management and Optimization

Efficient token management is crucial for maintaining performance and controlling costs when working with AI models. Our Claude Engineer project implements token tracking for each model:

```python
# Token tracking variables
main_model_tokens = {'input': 0, 'output': 0, 'cache_write': 0, 'cache_read': 0}
tool_checker_tokens = {'input': 0, 'output': 0, 'cache_write': 0, 'cache_read': 0}
code_editor_tokens = {'input': 0, 'output': 0, 'cache_write': 0, 'cache_read': 0}
code_execution_tokens = {'input': 0, 'output': 0, 'cache_write': 0, 'cache_read': 0}

# Updating token usage after each model call
main_model_tokens['input'] += response.usage.input_tokens
main_model_tokens['output'] += response.usage.output_tokens
main_model_tokens['cache_write'] = response.usage.cache_creation_input_tokens
main_model_tokens['cache_read'] = response.usage.cache_read_input_tokens

# Displaying token usage
def display_token_usage():
    # ... (implementation details)
```

This token tracking system allows us to:

1. Monitor the token usage of each model separately.
2. Optimize our prompts and inputs to reduce token consumption.
3. Provide transparency to users about the resource usage of the AI agent.
4. Make informed decisions about model selection and prompt design based on token usage patterns.

## 6. Implementing the Chat Loop and Message Handling

The heart of our AI agent's interaction is the chat loop, implemented in the `main()` function:

```python
async def main():
    global automode, conversation_history
    console.print(Panel("Welcome to the Claude-3-Sonnet Engineer Chat with Multi-Agent, Image, and Voice Support!", title="Welcome", style="bold green"))
    # ... (welcome messages and instructions)

    while True:
        if voice_mode:
            user_input = await voice_input()
            # ... (voice mode handling)
        else:
            user_input = await get_user_input()

        if user_input.lower() == 'exit':
            # ... (exit handling)
        
        # ... (other special command handling)

        if user_input.lower().startswith('automode'):
            # ... (automode handling)
        else:
            response, _ = await chat_with_claude(user_input)

# Run the main program
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        console.print("\nProgram interrupted by user. Exiting...", style="bold red")
    except Exception as e:
        console.print(f"An unexpected error occurred: {str(e)}", style="bold red")
        logging.error(f"Unexpected error: {str(e)}", exc_info=True)
    finally:
        console.print("Program finished. Goodbye!", style="bold green")
```

This main loop handles:

1. Different input modes (text and voice)
2. Special commands (exit, reset, save chat, etc.)
3. Entering and exiting automode
4. Regular chat interactions with the AI agent
5. Graceful error handling and program termination

The `chat_with_claude()` function is where the core interaction with the AI model happens:

```python
async def chat_with_claude(user_input, image_path=None, current_iteration=None, max_iterations=None):
    global conversation_history, automode, main_model_tokens, use_tts, tts_enabled

    # ... (input validation and conversation preparation)

    try:
        # MAINMODEL call with prompt caching
        response = client.beta.prompt_caching.messages.create(
            # ... (model parameters)
        )
        # ... (token usage update)
    except APIStatusError as e:
        # ... (error handling)
    except APIError as e:
        # ... (error handling)

    # ... (process AI response and handle tool calls)

    # Update conversation history
    conversation_history = messages + [{"role": "assistant", "content": assistant_response}]

    # Display token usage
    display_token_usage()

    return assistant_response, exit_continuation
```

This function orchestrates the entire interaction process, including:

1. Preparing the conversation context
2. Making the API call to the AI model
3. Processing the AI's response
4. Handling any tool calls made by the AI
5. Updating the conversation history
6. Managing token usage and display

By implementing these components, we create a sophisticated AI agent that can maintain context, adapt to different modes of operation, leverage multiple specialized models, and efficiently manage its resource usage. This architecture provides a solid foundation for building complex, AI-powered CLI tools that can handle a wide range of tasks and interactions.

## Conclusion

In this lesson, we've explored the core components of the AI agent architecture in our Claude Engineer project. We've seen how to implement conversation history and context management, create dynamic system prompts, handle different AI models, manage token usage, and implement the main chat loop.

By understanding and implementing these concepts, you can create powerful AI agents that can adapt to complex scenarios, maintain coherent conversations, and efficiently leverage different AI models for specialized tasks. This forms the backbone of our AI-powered CLI tool, enabling it to provide intelligent, context-aware assistance across a wide range of development tasks.

In the next lesson, we'll dive deeper into file system operations and project management, building upon the AI agent architecture we've established here.

