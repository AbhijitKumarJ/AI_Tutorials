# Lesson 9: Advanced Features - Image Analysis and Voice Input

## Introduction

In this lesson, we'll dive deep into the advanced features of our AI-powered CLI tool, focusing on image analysis capabilities and voice input integration. These features enhance the tool's versatility, allowing it to process visual information and interact with users through speech. We'll explore how to implement these features, handle different scenarios, and integrate them seamlessly into our existing codebase.

## Lesson Objectives

By the end of this lesson, students will be able to:

1. Implement image analysis capabilities in a Python CLI tool
2. Integrate speech recognition for voice input
3. Implement text-to-speech functionality using 11labs
4. Handle different image formats and sizes
5. Implement fallback mechanisms for voice recognition
6. Understand the challenges and best practices in working with multimedia inputs in CLI applications

## File Structure

Before we begin, let's review the file structure of our project, highlighting the files we'll be working with in this lesson:

```
claude-engineer/
├── main.py
├── requirements.txt
├── .env
└── code_execution_env/
```

We'll primarily be working with `main.py`, but we'll also need to update `requirements.txt` to include new dependencies.

## 1. Implementing Image Analysis Capabilities

Image analysis is a powerful feature that allows our CLI tool to extract information from visual data. We'll use the Pillow library for basic image processing and leverage Claude's built-in image analysis capabilities.

### 1.1 Setting Up Image Analysis

First, we need to install the Pillow library. Add the following line to your `requirements.txt` file:

```
Pillow==8.3.2
```

Then, run `pip install -r requirements.txt` to install the new dependency.

In `main.py`, add the following imports at the top of the file:

```python
from PIL import Image
import io
import base64
```

### 1.2 Implementing the Image Encoding Function

We'll create a function to encode images into base64 format, which is required for sending images to the Claude API. Add the following function to `main.py`:

```python
def encode_image_to_base64(image_path):
    try:
        with Image.open(image_path) as img:
            # Resize the image if it's too large
            max_size = (1024, 1024)
            img.thumbnail(max_size, Image.ANTIALIAS)
            
            # Convert to RGB if the image is in a different mode
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Save the image to a bytes buffer
            img_byte_arr = io.BytesIO()
            img.save(img_byte_arr, format='JPEG')
            
            # Encode the image to base64
            return base64.b64encode(img_byte_arr.getvalue()).decode('utf-8')
    except Exception as e:
        return f"Error encoding image: {str(e)}"
```

This function handles opening the image, resizing it if necessary, converting it to RGB format, and encoding it to base64. It also includes error handling to catch any issues during the process.

### 1.3 Updating the Chat Function for Image Analysis

Next, we need to modify our `chat_with_claude` function to handle image inputs. Update the function as follows:

```python
async def chat_with_claude(user_input, image_path=None, current_iteration=None, max_iterations=None):
    # ... (existing code)

    if image_path:
        console.print(Panel(f"Processing image at path: {image_path}", title="Image Processing", style="yellow"))
        image_base64 = encode_image_to_base64(image_path)

        if image_base64.startswith("Error"):
            console.print(Panel(f"Error encoding image: {image_base64}", title="Error", style="bold red"))
            return "I'm sorry, there was an error processing the image. Please try again.", False

        image_message = {
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": "image/jpeg",
                        "data": image_base64
                    }
                },
                {
                    "type": "text",
                    "text": f"User input for image: {user_input}"
                }
            ]
        }
        current_conversation.append(image_message)
    else:
        current_conversation.append({"role": "user", "content": user_input})

    # ... (rest of the existing code)
```

This update allows the function to handle both text and image inputs, encoding images when provided.

### 1.4 Handling Different Image Formats and Sizes

Our `encode_image_to_base64` function already handles different image formats by converting them to RGB and resizing large images. However, we can enhance it to provide more information about the original image:

```python
def encode_image_to_base64(image_path):
    try:
        with Image.open(image_path) as img:
            original_format = img.format
            original_size = img.size

            # Resize the image if it's too large
            max_size = (1024, 1024)
            img.thumbnail(max_size, Image.ANTIALIAS)
            
            # Convert to RGB if the image is in a different mode
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Save the image to a bytes buffer
            img_byte_arr = io.BytesIO()
            img.save(img_byte_arr, format='JPEG')
            
            # Encode the image to base64
            base64_image = base64.b64encode(img_byte_arr.getvalue()).decode('utf-8')
            
            return {
                "base64": base64_image,
                "original_format": original_format,
                "original_size": original_size,
                "resized_size": img.size
            }
    except Exception as e:
        return f"Error encoding image: {str(e)}"
```

This enhanced function now returns additional information about the image, which can be useful for debugging or providing context to the AI model.

## 2. Integrating Speech Recognition for Voice Input

To add voice input capabilities to our CLI tool, we'll use the SpeechRecognition library. This will allow users to interact with the tool using their voice, providing a more natural and accessible interface.

### 2.1 Setting Up Speech Recognition

First, add the following line to your `requirements.txt` file:

```
SpeechRecognition==3.8.1
```

Then, run `pip install -r requirements.txt` to install the new dependency.

In `main.py`, add the following imports:

```python
import speech_recognition as sr
```

### 2.2 Implementing Voice Input Function

Let's create a function to handle voice input:

```python
async def voice_input(max_retries=3):
    recognizer = sr.Recognizer()
    microphone = sr.Microphone()

    for attempt in range(max_retries):
        try:
            with microphone as source:
                console.print("Listening... Speak now.", style="bold green")
                audio = recognizer.listen(source, timeout=5)
                
            console.print("Processing speech...", style="bold yellow")
            text = recognizer.recognize_google(audio)
            console.print(f"You said: {text}", style="cyan")
            return text.lower()
        except sr.WaitTimeoutError:
            console.print(f"No speech detected. Attempt {attempt + 1} of {max_retries}.", style="bold red")
        except sr.UnknownValueError:
            console.print(f"Speech was unintelligible. Attempt {attempt + 1} of {max_retries}.", style="bold red")
        except sr.RequestError as e:
            console.print(f"Could not request results from speech recognition service; {e}", style="bold red")
            return None
        
    console.print("Max retries reached. Returning to text input mode.", style="bold red")
    return None
```

This function uses the microphone to listen for user input, processes the audio using Google's speech recognition service, and returns the recognized text. It includes error handling and retry logic to ensure a smooth user experience.

### 2.3 Updating the Main Loop for Voice Input

Now, let's modify our main loop to support voice input. Update the `main` function as follows:

```python
async def main():
    # ... (existing code)

    voice_mode = False

    while True:
        if voice_mode:
            user_input = await voice_input()
            if user_input is None:
                voice_mode = False
                console.print("Exited voice input mode. Returning to text input.", style="bold yellow")
                continue
            elif user_input == "exit voice mode":
                voice_mode = False
                console.print("Exited voice input mode. Returning to text input.", style="bold green")
                continue
        else:
            user_input = await get_user_input()

        if user_input.lower() == 'exit':
            console.print("Thank you for chatting. Goodbye!", style="bold green")
            break

        if user_input.lower() == 'voice':
            voice_mode = True
            console.print("Entering voice input mode. Say 'exit voice mode' to return to text input.", style="bold green")
            continue

        # ... (rest of the existing code)
```

This update allows users to switch between text and voice input modes, providing a flexible interface for interaction.

## 3. Implementing Text-to-Speech with 11labs

To complete our multimedia interaction capabilities, let's implement text-to-speech functionality using the 11labs API. This will allow our CLI tool to respond audibly to user inputs.

### 3.1 Setting Up 11labs Integration

First, add the following lines to your `requirements.txt` file:

```
websockets==10.3
pydub==0.25.1
```

Then, run `pip install -r requirements.txt` to install the new dependencies.

In `main.py`, add the following imports:

```python
import websockets
from pydub import AudioSegment
from pydub.playback import play
```

### 3.2 Implementing Text-to-Speech Function

Let's create a function to handle text-to-speech conversion:

```python
async def text_to_speech(text):
    ELEVEN_LABS_API_KEY = os.getenv('ELEVEN_LABS_API_KEY')
    VOICE_ID = 'YOUR_VOICE_ID'  # Replace with your chosen voice ID
    
    if not ELEVEN_LABS_API_KEY:
        console.print("ElevenLabs API key not found. Text-to-speech is disabled.", style="bold yellow")
        console.print(text)
        return

    uri = f"wss://api.elevenlabs.io/v1/text-to-speech/{VOICE_ID}/stream-input?model_id=eleven_monolingual_v1"
    
    async with websockets.connect(uri, extra_headers={'xi-api-key': ELEVEN_LABS_API_KEY}) as websocket:
        await websocket.send(json.dumps({
            "text": " ",
            "voice_settings": {"stability": 0.5, "similarity_boost": 0.5},
            "xi_api_key": ELEVEN_LABS_API_KEY,
        }))

        audio_data = b''
        async for chunk in text_chunker(text):
            await websocket.send(json.dumps({"text": chunk, "try_trigger_generation": True}))
            
        await websocket.send(json.dumps({"text": ""}))

        while True:
            try:
                message = await websocket.recv()
                data = json.loads(message)
                if data.get("audio"):
                    audio_data += base64.b64decode(data["audio"])
                elif data.get('isFinal'):
                    break
            except websockets.exceptions.ConnectionClosed:
                break

    if audio_data:
        audio = AudioSegment.from_mp3(io.BytesIO(audio_data))
        play(audio)
    else:
        console.print("No audio data received from ElevenLabs API.", style="bold red")
```

This function connects to the 11labs API, sends the text to be converted to speech, receives the audio data, and plays it using the `pydub` library.

### 3.3 Implementing Text Chunker

To optimize the text-to-speech process, we'll implement a text chunker that splits long text into smaller, more manageable pieces:

```python
async def text_chunker(text):
    splitters = (".", ",", "?", "!", ";", ":", "—", "-", "(", ")", "[", "]", "}", " ")
    buffer = ""
    for char in text:
        buffer += char
        if char in splitters:
            yield buffer
            buffer = ""
    if buffer:
        yield buffer
```

This function yields chunks of text, breaking at natural punctuation points to ensure smooth speech synthesis.

### 3.4 Updating the Chat Function for Text-to-Speech

Now, let's modify our `chat_with_claude` function to include text-to-speech capabilities:

```python
async def chat_with_claude(user_input, image_path=None, current_iteration=None, max_iterations=None):
    # ... (existing code)

    assistant_response = response.content[0].text
    console.print(Panel(Markdown(assistant_response), title="Claude's Response", style="blue"))

    # Add text-to-speech here
    await text_to_speech(assistant_response)

    # ... (rest of the existing code)
```

This update allows the AI's responses to be read aloud, providing an auditory dimension to the interaction.

## 4. Implementing Fallback Mechanisms for Voice Recognition

To enhance the reliability of our voice input feature, let's implement some fallback mechanisms:

### 4.1 Adding Multiple Speech Recognition Services

We can extend our `voice_input` function to try multiple speech recognition services if the primary one fails:

```python
async def voice_input(max_retries=3):
    recognizer = sr.Recognizer()
    microphone = sr.Microphone()

    for attempt in range(max_retries):
        try:
            with microphone as source:
                console.print("Listening... Speak now.", style="bold green")
                audio = recognizer.listen(source, timeout=5)
                
            console.print("Processing speech...", style="bold yellow")
            
            # Try Google Speech Recognition
            try:
                text = recognizer.recognize_google(audio)
            except sr.RequestError:
                # If Google fails, try Sphinx (offline recognition)
                try:
                    text = recognizer.recognize_sphinx(audio)
                except sr.RequestError:
                    # If both fail, raise an exception
                    raise sr.RequestError("All speech recognition services failed")
            
            console.print(f"You said: {text}", style="cyan")
            return text.lower()
        except sr.WaitTimeoutError:
            console.print(f"No speech detected. Attempt {attempt + 1} of {max_retries}.", style="bold red")
        except sr.UnknownValueError:
            console.print(f"Speech was unintelligible. Attempt {attempt + 1} of {max_retries}.", style="bold red")
        except sr.RequestError as e:
            console.print(f"Could not request results from speech recognition service; {e}", style="bold red")
            return None
        
    console.print("Max retries reached. Returning to text input mode.", style="bold red")
    return None
```

This updated function first tries Google's speech recognition service, and if that fails, it falls back to the offline Sphinx recognizer.

### 4.2 Implementing Noise Reduction

To improve the accuracy of voice recognition, especially in noisy environments, we can implement a simple noise reduction technique. Add the following function to `main.py`:

```python
def reduce_noise(audio_data):
    try:
        import numpy as np
        from scipy.signal import butter, lfilter

        # Convert audio data to numpy array
        y = np.frombuffer(audio_data.frame_data, dtype=np.int16)
        
        # Define filter parameters
        order = 6
        cutoff = 1000  # Cutoff frequency in Hz
        nyquist = 0.5 * audio_data.sample_rate
        normal_cutoff = cutoff / nyquist

        # Create Butterworth filter
        b, a = butter(order, normal_cutoff, btype='high', analog=False)
        
        # Apply filter
        y_filtered = lfilter(b, a, y)
        
        # Convert back to audio data
        filtered_audio = sr.AudioData(y_filtered.tobytes(), audio_data.sample_rate, audio_data.sample_width)
        
        return filtered_audio
    except ImportError:
        console.print("Noise reduction requires NumPy and SciPy. Skipping noise reduction.", style="bold yellow")
        return audio_data
```

This function applies a high-pass Butterworth filter to reduce low-frequency noise. Update the `voice_input` function to use this noise reduction:

```python
async def voice_input(max_retries=3):
    recognizer = sr.Recognizer()
    microphone = sr.Microphone()

    for attempt in range(max_retries):
        try:
            with microphone as source:
                console.print("Listening... Speak now.", style="bold green")
                audio = recognizer.listen(source, timeout=5)
                
            console.print("Processing speech...", style="bold yellow")
            
            # Apply noise reduction
            filtered_audio = reduce_noise(audio)
            
            # Try Google Speech Recognition with noise-reduced audio
            try:
                text = recognizer.recognize_google(filtered_audio)
            except sr.RequestError:
                # If Google fails, try Sphinx (offline recognition)
                try:
                    text = recognizer.recognize_sphinx(filtered_audio)
                except sr.RequestError:
                    # If both fail, raise an exception
                    raise sr.RequestError("All speech recognition services failed")
            
            console.print(f"You said: {text}", style="cyan")
            return text.lower()
        except sr.WaitTimeoutError:
            console.print(f"No speech detected. Attempt {attempt + 1} of {max_retries}.", style="bold red")
        except sr.UnknownValueError:
            console.print(f"Speech was unintelligible. Attempt {attempt + 1} of {max_retries}.", style="bold red")
        except sr.RequestError as e:
            console.print(f"Could not request results from speech recognition service; {e}", style="bold red")
            return None
        
    console.print("Max retries reached. Returning to text input mode.", style="bold red")
    return None
```

This enhancement improves the robustness of our voice input feature, making it more reliable in various environments.

## 5. Handling Challenges in Multimedia Inputs

When working with multimedia inputs like images and voice in a CLI application, there are several challenges to consider. Let's discuss these challenges and implement strategies to address them.

### 5.1 Image File Validation

To ensure that users provide valid image files, we can implement a file validation function:

```python
def validate_image_file(file_path):
    try:
        with Image.open(file_path) as img:
            # Check if the file is a valid image
            img.verify()
        return True
    except Exception as e:
        console.print(f"Invalid image file: {str(e)}", style="bold red")
        return False
```

Use this function before processing any image input:

```python
if image_path:
    if validate_image_file(image_path):
        # Process the image
        image_base64 = encode_image_to_base64(image_path)
        # ... rest of the image processing code
    else:
        return "Please provide a valid image file.", False
```

### 5.2 Handling Large Files

When dealing with large image files, we need to be mindful of memory usage and processing time. We can implement a function to check the file size and optionally resize very large images:

```python
def check_and_resize_image(file_path, max_size_mb=5, max_dimension=2000):
    file_size = os.path.getsize(file_path) / (1024 * 1024)  # Size in MB
    
    if file_size > max_size_mb:
        console.print(f"Image file is large ({file_size:.2f} MB). Resizing...", style="yellow")
        with Image.open(file_path) as img:
            # Calculate new dimensions while maintaining aspect ratio
            ratio = min(max_dimension / max(img.size), 1)
            new_size = tuple(int(dim * ratio) for dim in img.size)
            
            # Resize the image
            img_resized = img.resize(new_size, Image.LANCZOS)
            
            # Save the resized image
            new_file_path = f"{os.path.splitext(file_path)[0]}_resized{os.path.splitext(file_path)[1]}"
            img_resized.save(new_file_path, optimize=True, quality=85)
            
        console.print(f"Resized image saved as: {new_file_path}", style="green")
        return new_file_path
    
    return file_path
```

Integrate this function into your image processing workflow:

```python
if image_path:
    if validate_image_file(image_path):
        image_path = check_and_resize_image(image_path)
        image_base64 = encode_image_to_base64(image_path)
        # ... rest of the image processing code
    else:
        return "Please provide a valid image file.", False
```

### 5.3 Handling Network Issues in Speech Recognition

Network connectivity is crucial for online speech recognition services. Let's implement a function to check network connectivity and fall back to offline recognition if needed:

```python
import socket

def check_internet_connection():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except OSError:
        return False

async def voice_input_with_network_check(max_retries=3):
    if check_internet_connection():
        return await voice_input(max_retries)
    else:
        console.print("No internet connection detected. Using offline speech recognition.", style="bold yellow")
        recognizer = sr.Recognizer()
        microphone = sr.Microphone()

        try:
            with microphone as source:
                console.print("Listening... Speak now.", style="bold green")
                audio = recognizer.listen(source, timeout=5)
            
            console.print("Processing speech...", style="bold yellow")
            text = recognizer.recognize_sphinx(audio)
            console.print(f"You said: {text}", style="cyan")
            return text.lower()
        except sr.UnknownValueError:
            console.print("Speech was unintelligible.", style="bold red")
        except sr.RequestError as e:
            console.print(f"Sphinx error; {e}", style="bold red")
        
        return None
```

Update your main loop to use this new function:

```python
if voice_mode:
    user_input = await voice_input_with_network_check()
    # ... rest of the voice input handling code
```

## Conclusion

In this lesson, we've explored advanced features for our AI-powered CLI tool, focusing on image analysis and voice input. We've implemented robust image processing capabilities, integrated speech recognition with fallback mechanisms, and added text-to-speech functionality. We've also addressed common challenges in working with multimedia inputs in CLI applications, such as file validation, handling large files, and managing network connectivity issues.

These enhancements significantly improve the user experience and expand the tool's capabilities. Users can now interact with the AI using voice commands, process and analyze images, and receive auditory responses. The fallback mechanisms and error handling we've implemented ensure that the tool remains functional even in suboptimal conditions.

In the next lesson, we'll explore how to implement autonomous mode and task planning, allowing our AI assistant to work on complex tasks independently.

