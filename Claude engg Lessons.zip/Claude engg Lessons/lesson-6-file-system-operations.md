# Lesson 6: File System Operations and Project Management

## Introduction

In this lesson, we'll dive deep into file system operations and project management within our AI-powered CLI tool. These functionalities are crucial for enabling our AI agent to interact with the user's file system, manage project structures, and perform various file-related tasks. By the end of this lesson, you'll have a solid understanding of how to implement robust file system operations that work across different platforms and how to manage complex project structures efficiently.

## 1. Implementing File and Folder Creation Tools

One of the fundamental operations our CLI tool needs to perform is creating files and folders. Let's explore how we implement these functionalities:

### Creating Folders

The `create_folders` function allows the AI agent to create one or more directories, including nested ones:

```python
def create_folders(paths):
    results = []
    for path in paths:
        try:
            # Use os.makedirs with exist_ok=True to create nested directories
            os.makedirs(path, exist_ok=True)
            results.append(f"Folder(s) created: {path}")
        except Exception as e:
            results.append(f"Error creating folder(s) {path}: {str(e)}")
    return "\n".join(results)
```

Key points about this implementation:
- We use `os.makedirs()` with `exist_ok=True` to create directories, including nested ones.
- This function can create multiple directories in a single call, improving efficiency.
- It handles errors gracefully, providing feedback for each path attempted.
- The use of `os.makedirs()` ensures cross-platform compatibility.

### Creating Files

The `create_files` function is responsible for creating new files with specified content:

```python
def create_files(files):
    global file_contents
    results = []
    
    # Handle different input types
    if isinstance(files, str):
        # If a string is passed, assume it's a single file path
        files = [{"path": files, "content": ""}]
    elif isinstance(files, dict):
        # If a single dictionary is passed, wrap it in a list
        files = [files]
    elif not isinstance(files, list):
        return "Error: Invalid input type for create_files. Expected string, dict, or list."
    
    for file in files:
        try:
            if not isinstance(file, dict):
                results.append(f"Error: Invalid file specification: {file}")
                continue
            
            path = file.get('path')
            content = file.get('content', '')
            
            if path is None:
                results.append(f"Error: Missing 'path' for file")
                continue
            
            dir_name = os.path.dirname(path)
            if dir_name:
                os.makedirs(dir_name, exist_ok=True)
            
            with open(path, 'w') as f:
                f.write(content)
            
            file_contents[path] = content
            results.append(f"File created and added to system prompt: {path}")
        except Exception as e:
            results.append(f"Error creating file: {str(e)}")
    
    return "\n".join(results)
```

Key points about this implementation:
- It's flexible, accepting a single file path, a dictionary, or a list of dictionaries.
- It automatically creates any necessary parent directories.
- The function updates the `file_contents` dictionary, which is used to maintain context for the AI agent.
- It provides detailed feedback for each file creation attempt.
- The implementation uses `with` statements for proper file handling.

## 2. Reading and Writing Files

Efficient file reading and writing operations are crucial for our CLI tool. Let's examine how we implement these functionalities:

### Reading Files

We have two functions for reading files: `read_file` for single files and `read_multiple_files` for multiple files:

```python
def read_file(path):
    global file_contents
    try:
        with open(path, 'r') as f:
            content = f.read()
        file_contents[path] = content
        return f"File '{path}' has been read and stored in the system prompt."
    except Exception as e:
        return f"Error reading file: {str(e)}"

def read_multiple_files(paths, recursive=False):
    global file_contents
    results = []

    if isinstance(paths, str):
        paths = [paths]

    for path in paths:
        try:
            abs_path = os.path.abspath(path)
            if os.path.isdir(abs_path):
                if recursive:
                    file_paths = glob.glob(os.path.join(abs_path, '**', '*'), recursive=True)
                else:
                    file_paths = glob.glob(os.path.join(abs_path, '*'))
                file_paths = [f for f in file_paths if os.path.isfile(f)]
            else:
                file_paths = glob.glob(abs_path, recursive=recursive)

            for file_path in file_paths:
                abs_file_path = os.path.abspath(file_path)
                if os.path.isfile(abs_file_path):
                    if abs_file_path not in file_contents:
                        with open(abs_file_path, 'r', encoding='utf-8') as f:
                            content = f.read()
                        file_contents[abs_file_path] = content
                        results.append(f"File '{abs_file_path}' has been read and stored in the system prompt.")
                    else:
                        results.append(f"File '{abs_file_path}' is already in the system prompt. No need to read again.")
                else:
                    results.append(f"Skipped '{abs_file_path}': Not a file.")
        except Exception as e:
            results.append(f"Error reading path '{path}': {str(e)}")

    return "\n".join(results)
```

Key points about these implementations:
- Both functions update the `file_contents` dictionary, which serves as a cache and context for the AI agent.
- `read_multiple_files` supports reading entire directories, with an option for recursive reading.
- The functions handle various input types (single path, list of paths) for flexibility.
- They provide detailed feedback about each file read operation.
- Error handling is implemented to gracefully handle issues like permission errors or non-existent files.

### Writing Files

File writing is primarily handled through the `create_files` function we discussed earlier. However, for editing existing files, we use a more sophisticated approach with the `edit_and_apply` function, which we'll discuss in the next section.

## 3. Implementing Diff-based File Editing

One of the more complex file operations in our CLI tool is the ability to edit existing files intelligently. This is implemented through the `edit_and_apply` function:

```python
async def edit_and_apply(path, instructions, project_context, is_automode=False, max_retries=3):
    global file_contents
    try:
        original_content = file_contents.get(path, "")
        if not original_content:
            with open(path, 'r') as file:
                original_content = file.read()
            file_contents[path] = original_content

        for attempt in range(max_retries):
            edit_instructions_json = await generate_edit_instructions(path, original_content, instructions, project_context, file_contents)
            
            if edit_instructions_json:
                edit_instructions = json.loads(edit_instructions_json)
                console.print(Panel(f"Attempt {attempt + 1}/{max_retries}: The following SEARCH/REPLACE blocks have been generated:", title="Edit Instructions", style="cyan"))
                for i, block in enumerate(edit_instructions, 1):
                    console.print(f"Block {i}:")
                    console.print(Panel(f"SEARCH:\n{block['search']}\n\nREPLACE:\n{block['replace']}", expand=False))

                edited_content, changes_made, failed_edits = await apply_edits(path, edit_instructions, original_content)

                if changes_made:
                    file_contents[path] = edited_content
                    console.print(Panel(f"File contents updated in system prompt: {path}", style="green"))
                    
                    if failed_edits:
                        console.print(Panel(f"Some edits could not be applied. Retrying...", style="yellow"))
                        instructions += f"\n\nPlease retry the following edits that could not be applied:\n{failed_edits}"
                        original_content = edited_content
                        continue
                    
                    return f"Changes applied to {path}"
                elif attempt == max_retries - 1:
                    return f"No changes could be applied to {path} after {max_retries} attempts. Please review the edit instructions and try again."
                else:
                    console.print(Panel(f"No changes could be applied in attempt {attempt + 1}. Retrying...", style="yellow"))
            else:
                return f"No changes suggested for {path}"
        
        return f"Failed to apply changes to {path} after {max_retries} attempts."
    except Exception as e:
        return f"Error editing/applying to file: {str(e)}"
```

Key points about this implementation:
- It uses an AI model (through `generate_edit_instructions`) to generate edit instructions based on the original content and user instructions.
- The function implements a retry mechanism to handle cases where edits cannot be applied successfully on the first attempt.
- It provides detailed feedback about the editing process, including displaying the generated edit instructions.
- The function updates the `file_contents` dictionary to maintain context for the AI agent.
- It uses the `apply_edits` function to actually perform the edits, which we'll examine next.

The `apply_edits` function is responsible for actually applying the changes to the file content:

```python
async def apply_edits(file_path, edit_instructions, original_content):
    changes_made = False
    edited_content = original_content
    total_edits = len(edit_instructions)
    failed_edits = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        console=console
    ) as progress:
        edit_task = progress.add_task("[cyan]Applying edits...", total=total_edits)

        for i, edit in enumerate(edit_instructions, 1):
            search_content = edit['search'].strip()
            replace_content = edit['replace'].strip()
            
            # Use regex to find the content, ignoring leading/trailing whitespace
            pattern = re.compile(re.escape(search_content), re.DOTALL)
            match = pattern.search(edited_content)
            
            if match:
                # Replace the content, preserving the original whitespace
                start, end = match.span()
                # Strip <SEARCH> and <REPLACE> tags from replace_content
                replace_content_cleaned = re.sub(r'</?SEARCH>|</?REPLACE>', '', replace_content)
                edited_content = edited_content[:start] + replace_content_cleaned + edited_content[end:]
                changes_made = True
                
                # Display the diff for this edit
                diff_result = generate_diff(search_content, replace_content, file_path)
                console.print(Panel(diff_result, title=f"Changes in {file_path} ({i}/{total_edits})", style="cyan"))
            else:
                console.print(Panel(f"Edit {i}/{total_edits} not applied: content not found", style="yellow"))
                failed_edits.append(f"Edit {i}: {search_content}")

            progress.update(edit_task, advance=1)

    if not changes_made:
        console.print(Panel("No changes were applied. The file content already matches the desired state.", style="green"))
    else:
        # Write the changes to the file
        with open(file_path, 'w') as file:
            file.write(edited_content)
        console.print(Panel(f"Changes have been written to {file_path}", style="green"))

    return edited_content, changes_made, "\n".join(failed_edits)
```

Key points about this implementation:
- It uses regular expressions to find and replace content, allowing for more flexible matching.
- The function provides a progress bar to show the status of applying edits.
- It generates and displays diffs for each successful edit, helping users understand the changes made.
- The function handles cases where edits cannot be applied, keeping track of failed edits.
- It only writes changes to the file if actual modifications were made.

## 4. Listing Directory Contents

To help users and the AI agent understand the structure of projects, we implement a `list_files` function:

```python
def list_files(path="."):
    try:
        files = os.listdir(path)
        return "\n".join(files)
    except Exception as e:
        return f"Error listing files: {str(e)}"
```

This simple yet effective function:
- Uses `os.listdir()` for cross-platform compatibility.
- Returns a string with each file or directory on a new line for easy reading.
- Handles errors gracefully, providing feedback if the directory can't be read.

## 5. Handling File Permissions and Cross-Platform Path Issues

When working with file systems, it's crucial to handle permissions and path issues that may arise across different platforms. Here are some strategies we employ:

1. Using `os.path` for cross-platform path handling:
   ```python
   import os

   # Instead of hardcoding path separators
   full_path = os.path.join(directory, filename)
   ```

2. Converting to absolute paths to avoid relative path issues:
   ```python
   abs_path = os.path.abspath(path)
   ```

3. Checking file existence and permissions before operations:
   ```python
   if os.path.exists(path):
       if os.access(path, os.R_OK):
           # Perform read operation
       else:
           return "Permission denied"
   else:
       return "File not found"
   ```

4. Using `try-except` blocks to catch and handle permission errors:
   ```python
   try:
       with open(path, 'r') as file:
           content = file.read()
   except PermissionError:
       return "Permission denied"
   except FileNotFoundError:
       return "File not found"
   ```

5. For write operations, checking directory write permissions:
   ```python
   dir_path = os.path.dirname(file_path)
   if not os.access(dir_path, os.W_OK):
       return "Permission denied: Cannot write to directory"
   ```

These strategies help ensure that our file operations work consistently across different operating systems and handle common file system issues gracefully.

## 6. Implementing the scan_folder Functionality

The `scan_folder` function is a powerful tool for generating comprehensive documentation of project structures. Here's its implementation:

```python
def scan_folder(folder_path: str, output_file: str) -> str:
    ignored_folders = {'.git', '__pycache__', 'node_modules', 'venv', 'env'}
    markdown_content = f"# Folder Scan: {folder_path}\n\n"
    total_chars = len(markdown_content)
    max_chars = 600000  # Approximating 150,000 tokens

    for root, dirs, files in os.walk(folder_path):
        dirs[:] = [d for d in dirs if d not in ignored_folders]

        for file in files:
            file_path = os.path.join(root, file)
            relative_path = os.path.relpath(file_path, folder_path)

            mime_type, _ = mimetypes.guess_type(file_path)
            if mime_type and mime_type.startswith('text'):
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()

                    file_content = f"## {relative_path}\n\n```\n{content}\n```\n\n"
                    if total_chars + len(file_content) > max_chars:
                        remaining_chars = max_chars - total_chars
                        if remaining_chars > 0:
                            truncated_content = file_content[:remaining_chars]
                            markdown_content += truncated_content
                            markdown_content += "\n\n... Content truncated due to size limitations ...\n"
                        else:
                            markdown_content += "\n\n... Additional files omitted due to size limitations ...\n"
                        break
                    else:
                        markdown_content += file_content
                        total_chars += len(file_content)
                except Exception as e:
                    error_msg = f"## {relative_path}\n\nError reading file: {str(e)}\n\n"
                    if total_chars + len(error_msg) <= max_chars:
                        markdown_content += error_msg
                        total_chars += len(error_msg)

        if total_chars >= max_chars:
            break

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(markdown_content)

    return f"Folder scan complete. Markdown file created at: {output_file}. Total characters: {total_chars}"
```

Key points about this implementation:
- It uses `os.walk()` to recursively traverse the directory structure.
- The function ignores common folders that typically don't need to be included in project documentation (e.g., `.git`, `__pycache__`).
- It uses the `mimetypes` library to identify text files, ensuring only readable content is included.
- The function implements a character limit to prevent generating excessively large files, which could cause issues with token limits in AI models.
- It creates a Markdown-formatted output, making it easy to read and integrate with other documentation tools.
- The function provides error handling for individual file read operations, ensuring the overall process continues even if some files can't be read.
- It returns a summary of the operation, including the output file location and total character count.

## Conclusion

In this lesson, we've explored the implementation of various file system operations and project management functionalities in our AI-powered CLI tool. We've covered creating files and folders, reading and writing files, implementing diff-based file editing, listing directory contents, handling file permissions and cross-platform issues, and scanning folders for comprehensive project documentation.

These functionalities form the backbone of our tool's ability to interact with the user's file system and manage complex project structures. By implementing these features with careful attention to error handling, cross-platform compatibility, and user feedback, we've created a robust and flexible system that can handle a wide range of file-related tasks.

In the next lesson, we'll dive into code execution and process management, building upon the file system operations we've established here to create a powerful environment for running and analyzing code.

