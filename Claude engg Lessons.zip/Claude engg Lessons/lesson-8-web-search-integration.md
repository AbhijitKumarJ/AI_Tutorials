# Lesson 8: Web Search Integration and Information Retrieval

## Introduction

In this lesson, we'll explore how our AI-powered CLI tool integrates web search capabilities and manages information retrieval. This functionality is crucial for keeping the AI agent up-to-date with the latest information and allowing it to access a vast knowledge base beyond its initial training data. We'll focus on the implementation of the Tavily search API, how we handle and present search results, and how we integrate this information into the AI agent's context.

## 1. Implementing the tavily_search Tool

The core of our web search functionality is the `tavily_search` function. This function utilizes the Tavily API to perform web searches and retrieve relevant information. Let's examine its implementation:

```python
def tavily_search(query):
    try:
        response = tavily.qna_search(query=query, search_depth="advanced")
        return response
    except Exception as e:
        return f"Error performing search: {str(e)}"
```

Key points about this implementation:
- We use the Tavily client (`tavily`) to perform a Question and Answer (QnA) search.
- The `search_depth` parameter is set to "advanced" to get more comprehensive results.
- The function is wrapped in a try-except block to handle any potential errors during the API call.
- If an error occurs, it returns a string describing the error, allowing the calling function to handle it appropriately.

While this implementation is concise, it's powerful in its ability to fetch relevant information from the web. The Tavily API is designed to provide high-quality, context-aware search results, which is particularly useful for our AI agent.

## 2. Initializing the Tavily Client

Before we can use the `tavily_search` function, we need to initialize the Tavily client. This is typically done at the start of our application:

```python
from tavily import TavilyClient
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Initialize the Tavily client
tavily_api_key = os.getenv("TAVILY_API_KEY")
if not tavily_api_key:
    raise ValueError("TAVILY_API_KEY not found in environment variables")
tavily = TavilyClient(api_key=tavily_api_key)
```

Key points about this setup:
- We use `python-dotenv` to load environment variables from a `.env` file, which is a secure way to manage API keys.
- We check if the `TAVILY_API_KEY` is present in the environment variables. If not, we raise an error, preventing the application from running without proper configuration.
- The Tavily client is initialized with the API key, making it available for use throughout our application.

This initialization ensures that our application has access to the Tavily API and can perform web searches when needed.

## 3. Integrating Web Search into the AI Agent's Workflow

To make effective use of the web search capability, we need to integrate it into our AI agent's decision-making process. This is typically done in the main chat loop, where the AI agent can decide to use the search tool when it needs additional information. Here's how we might implement this:

```python
async def chat_with_claude(user_input, image_path=None, current_iteration=None, max_iterations=None):
    global conversation_history, automode, main_model_tokens

    # ... (previous code for preparing the conversation)

    try:
        response = client.beta.prompt_caching.messages.create(
            model=MAINMODEL,
            max_tokens=8000,
            system=[
                {
                    "type": "text",
                    "text": update_system_prompt(current_iteration, max_iterations),
                    "cache_control": {"type": "ephemeral"}
                },
                {
                    "type": "text",
                    "text": json.dumps(tools),
                    "cache_control": {"type": "ephemeral"}
                }
            ],
            messages=messages,
            tools=tools,
            tool_choice={"type": "auto"},
            extra_headers={"anthropic-beta": "prompt-caching-2024-07-31"}
        )

        # ... (code for processing the response)

        for tool_call in tool_calls:
            if tool_call['function']['name'] == 'tavily_search':
                search_query = json.loads(tool_call['function']['arguments'])['query']
                search_result = tavily_search(search_query)
                
                # Process and display search results
                console.print(Panel(f"Search Query: {search_query}", title="Web Search", style="cyan"))
                console.print(Panel(json.dumps(search_result, indent=2), title="Search Results", style="green"))

                # Add search results to the conversation history
                current_conversation.append({
                    "role": "tool",
                    "content": json.dumps(search_result),
                    "tool_call_id": tool_call['id']
                })

        # ... (rest of the function)

    except Exception as e:
        # ... (error handling)

    return assistant_response, exit_continuation
```

Key points about this integration:
- The web search capability is included in the `tools` list, allowing the AI agent to choose when to use it.
- When the AI decides to use the `tavily_search` tool, we extract the search query from the tool call arguments.
- We perform the search using our `tavily_search` function and display the results to the user.
- The search results are added to the conversation history, allowing the AI agent to reference them in future responses.
- This integration allows the AI agent to dynamically fetch information as needed during the conversation.

## 4. Handling and Presenting Search Results

The Tavily API returns rich search results that can include various types of information. It's important to process and present these results in a way that's useful for both the AI agent and the human user. Here's an example of how we might handle this:

```python
def process_search_results(search_result):
    processed_result = {
        "answer": search_result.get("answer", "No direct answer found."),
        "snippets": [],
        "sources": []
    }

    for result in search_result.get("results", []):
        if result.get("content"):
            processed_result["snippets"].append({
                "content": result["content"],
                "url": result.get("url", "No URL provided")
            })
        if result.get("url"):
            processed_result["sources"].append(result["url"])

    return processed_result

# In the chat_with_claude function, after performing the search:
search_result = tavily_search(search_query)
processed_result = process_search_results(search_result)

console.print(Panel(f"Search Query: {search_query}", title="Web Search", style="cyan"))
console.print(Panel(processed_result["answer"], title="Direct Answer", style="green"))
console.print(Panel("\n".join([f"- {snippet['content']} (Source: {snippet['url']})" for snippet in processed_result["snippets"]]), title="Relevant Snippets", style="yellow"))
console.print(Panel("\n".join(processed_result["sources"]), title="Sources", style="blue"))

# Add processed results to conversation history
current_conversation.append({
    "role": "tool",
    "content": json.dumps(processed_result),
    "tool_call_id": tool_call['id']
})
```

Key points about handling search results:
- We process the raw search results to extract the most relevant information: a direct answer (if available), content snippets, and source URLs.
- The results are presented in a structured way using Rich panels, making it easy for the user to distinguish between different types of information.
- We include source URLs, which is important for transparency and allowing users to verify information if needed.
- The processed results are added to the conversation history, providing context for the AI agent's future responses.

## 5. Integrating Search Results into the AI Agent's Context

Once we have the search results, it's crucial to integrate this information effectively into the AI agent's context. This allows the agent to use the newly acquired information in its responses. Here's how we might approach this:

```python
def update_system_prompt(current_iteration: Optional[int] = None, max_iterations: Optional[int] = None) -> str:
    global file_contents, recent_search_results
    
    # ... (previous code for basic prompt construction)

    # Add recent search results to the prompt
    if recent_search_results:
        search_context = "Recent search results:\n"
        for query, result in recent_search_results:
            search_context += f"Query: {query}\n"
            search_context += f"Answer: {result['answer']}\n"
            search_context += "Relevant snippets:\n"
            for snippet in result['snippets'][:3]:  # Limit to top 3 snippets
                search_context += f"- {snippet['content']}\n"
            search_context += "\n"
        
        system_prompt += f"\n\n{search_context}"

    # ... (rest of the function)

    return system_prompt

# In the chat_with_claude function, after processing search results:
recent_search_results.append((search_query, processed_result))
if len(recent_search_results) > 5:  # Keep only the 5 most recent searches
    recent_search_results.pop(0)
```

Key points about integrating search results:
- We maintain a `recent_search_results` list to keep track of the latest search queries and their results.
- The `update_system_prompt` function is modified to include recent search results in the system prompt.
- We limit the number of recent searches and the number of snippets per search to manage the prompt's length.
- By including this information in the system prompt, we ensure that the AI agent has access to the latest web-sourced information for every response.

## 6. Implementing Caching for Search Results

To optimize performance and reduce API calls, we can implement a simple caching mechanism for search results:

```python
import time

search_cache = {}
CACHE_EXPIRY = 3600  # Cache expiry time in seconds (1 hour)

def cached_tavily_search(query):
    current_time = time.time()
    
    # Check if the query is in cache and not expired
    if query in search_cache and current_time - search_cache[query]['timestamp'] < CACHE_EXPIRY:
        return search_cache[query]['result']
    
    # If not in cache or expired, perform the search
    result = tavily_search(query)
    
    # Update the cache
    search_cache[query] = {
        'result': result,
        'timestamp': current_time
    }
    
    return result

# Replace tavily_search with cached_tavily_search in the chat_with_claude function
search_result = cached_tavily_search(search_query)
```

Key points about caching search results:
- We use a dictionary (`search_cache`) to store search results along with their timestamps.
- Before making an API call, we check if the query exists in the cache and if it's still valid (not expired).
- If a valid cached result is found, we return it immediately, saving an API call.
- If no valid cache entry is found, we perform the search and update the cache.
- This caching mechanism can significantly reduce API usage and improve response times for repeated queries.

## 7. Handling Different Search Depths and Result Types

The Tavily API offers different search depths and can return various types of results. Let's enhance our search function to handle these options:

```python
def advanced_tavily_search(query, search_depth="advanced", result_type="auto"):
    try:
        if result_type == "auto":
            response = tavily.qna_search(query=query, search_depth=search_depth)
        elif result_type == "search":
            response = tavily.search(query=query, search_depth=search_depth)
        else:
            raise ValueError(f"Invalid result_type: {result_type}")
        
        return response
    except Exception as e:
        return f"Error performing search: {str(e)}"

# In the chat_with_claude function:
search_args = json.loads(tool_call['function']['arguments'])
search_query = search_args['query']
search_depth = search_args.get('search_depth', 'advanced')
result_type = search_args.get('result_type', 'auto')

search_result = advanced_tavily_search(search_query, search_depth, result_type)
```

Key points about handling different search options:
- We've added parameters for `search_depth` and `result_type` to allow more flexible searches.
- The function can now handle both QnA-style searches and regular searches based on the `result_type`.
- We've included error handling for invalid `result_type` values.
- This flexibility allows the AI agent to request different types of searches based on the specific information need.

## Conclusion

In this lesson, we've explored the implementation of web search integration and information retrieval in our AI-powered CLI tool. We've seen how to set up and use the Tavily API for web searches, how to process and present search results, and how to integrate this information into the AI agent's context.

These features greatly enhance the capabilities of our tool, allowing the AI agent to access up-to-date information from the web and provide more informed and current responses. The caching mechanism helps optimize performance, while the flexibility in search types allows for more targeted information retrieval.

By implementing these features, we've created a more dynamic and knowledgeable AI assistant that can draw upon a vast wealth of online information to better serve user queries and tasks. This combination of AI language understanding and real-time web search creates a powerful tool for a wide range of applications in software development and beyond.

In the next lesson, we'll explore advanced features such as image analysis and voice input, further expanding the interactive capabilities of our CLI tool.

