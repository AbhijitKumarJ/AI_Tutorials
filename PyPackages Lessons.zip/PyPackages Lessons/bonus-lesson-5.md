# Bonus Lesson 5: Packaging and Distributing Your CLI Tool

In this final lesson, we'll learn how to package our TaskMaster CLI tool and distribute it so that others can easily install and use it. We'll cover creating a Python package, uploading it to PyPI (Python Package Index), and exploring alternative distribution methods.

## 1. Preparing Your Project for Packaging

First, let's ensure our project structure is ready for packaging. Your project should look like this:

```
taskmaster/
│
├── taskmaster/
│   ├── __init__.py
│   ├── cli.py
│   ├── task.py
│   ├── database.py
│   ├── logger.py
│   ├── config.py
│   ├── plugin_manager.py
│   └── plugins/
│       ├── __init__.py
│       └── priority.py
│
├── tests/
│   ├── __init__.py
│   ├── test_task.py
│   ├── test_database.py
│   └── test_cli.py
│
├── README.md
├── LICENSE.txt
├── setup.py
├── MANIFEST.in
└── requirements.txt
```

If you haven't already, create a `README.md` file with a description of your project, installation instructions, and basic usage examples.

Create a `LICENSE.txt` file with your chosen license (e.g., MIT License).

Update your `setup.py` file:

```python
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="taskmaster-cli",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A simple CLI task manager",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/taskmaster",
    packages=find_packages(exclude=["tests", "tests.*"]),
    install_requires=[
        "click>=7.1.2",
        "pytest>=6.2.3",
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
    ],
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "taskmaster=taskmaster.cli:cli",
        ],
    },
)
```

Create a `MANIFEST.in` file to include additional files in your package:

```
include README.md
include LICENSE.txt
include requirements.txt
recursive-include taskmaster *.py
```

## 2. Building Your Package

To build your package, you'll need to install some additional tools:

```bash
pip install setuptools wheel twine
```

Now, build your package:

```bash
python setup.py sdist bdist_wheel
```

This will create a `dist` directory with your package files.

## 3. Testing Your Package Locally

Before publishing, it's a good idea to test your package locally:

1. Create a new virtual environment:
   ```bash
   python -m venv test_env
   source test_env/bin/activate  # On Windows, use `test_env\Scripts\activate`
   ```

2. Install your package from the local files:
   ```bash
   pip install dist/taskmaster_cli-0.1.0-py3-none-any.whl
   ```

3. Try running your CLI tool:
   ```bash
   taskmaster --help
   ```

## 4. Uploading to PyPI

First, create an account on [PyPI](https://pypi.org/) if you haven't already.

To upload your package to PyPI, use twine:

```bash
twine upload dist/*
```

You'll be prompted for your PyPI username and password.

## 5. Installing Your Published Package

Now, anyone can install your package using pip:

```bash
pip install taskmaster-cli
```

## 6. Updating Your Package

When you make changes to your package:

1. Update the version number in `setup.py`.
2. Rebuild the package:
   ```bash
   python setup.py sdist bdist_wheel
   ```
3. Upload the new version:
   ```bash
   twine upload dist/*
   ```

## 7. Alternative Distribution Methods

### GitHub Releases

You can also distribute your tool through GitHub releases:

1. Create a new release on GitHub.
2. Upload your dist files to the release.
3. Users can then install directly from GitHub:
   ```bash
   pip install https://github.com/yourusername/taskmaster/archive/v0.1.0.tar.gz
   ```

### Docker

For more complex applications or those with specific environment requirements, consider using Docker:

1. Create a `Dockerfile`:

```Dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY . .

RUN pip install --no-cache-dir -r requirements.txt

RUN pip install .

ENTRYPOINT ["taskmaster"]
```

2. Build the Docker image:
   ```bash
   docker build -t taskmaster .
   ```

3. Run TaskMaster in a Docker container:
   ```bash
   docker run taskmaster --help
   ```

## 8. Cross-platform Considerations

When packaging and distributing your CLI tool, keep these cross-platform considerations in mind:

1. **File Paths**: Always use `os.path` or `pathlib` for handling file paths to ensure compatibility across different operating systems.

2. **Dependencies**: Ensure all your dependencies work across different platforms. If some dependencies are platform-specific, use conditional dependencies in your `setup.py`.

3. **Shebang Line**: If you include a shebang line in your entry point script, use `#!/usr/bin/env python` for better cross-platform compatibility.

4. **Line Endings**: Be aware that different operating systems use different line endings. Git can help manage this with its `core.autocrlf` setting.

5. **Executable Bit**: On Unix-like systems, ensure your entry point script has the executable bit set. This isn't an issue on Windows.

6. **Platform-specific Code**: If you have any platform-specific code, use `sys.platform` or `os.name` to conditionally execute it.

## Conclusion

Congratulations! You've now learned how to package and distribute your TaskMaster CLI tool. You've created a Python package, uploaded it to PyPI, and explored alternative distribution methods like GitHub releases and Docker.

Remember to keep your package updated, respond to issues and pull requests if you open-source your project, and always test thoroughly on different platforms before releasing new versions.

This concludes our bonus lesson series on building a comprehensive CLI tool. You now have the skills to create, test, package, and distribute your own