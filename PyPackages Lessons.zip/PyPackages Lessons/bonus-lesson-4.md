# Bonus Lesson 4: Testing and Debugging Your CLI Tool

In this lesson, we'll focus on testing and debugging our TaskMaster CLI tool. We'll implement unit tests, integration tests, and learn how to effectively debug our application across different platforms.

## 1. Setting Up Testing Framework

We'll use Python's built-in `unittest` module along with `pytest` for our testing framework. First, let's install `pytest`:

```bash
pip install pytest pytest-cov
```

Now, let's create a test directory and some test files:

```
mkdir tests
touch tests/__init__.py
touch tests/test_task.py
touch tests/test_database.py
touch tests/test_cli.py
```

## 2. Writing Unit Tests

Let's start by writing unit tests for our `Task` class. Update `tests/test_task.py`:

```python
import unittest
from datetime import datetime
from taskmaster.task import Task

class TestTask(unittest.TestCase):
    def test_task_creation(self):
        task = Task("Test task")
        self.assertEqual(task.title, "Test task")
        self.assertIsNone(task.due_date)
        self.assertFalse(task.completed)

    def test_task_with_due_date(self):
        due_date = datetime(2023, 12, 31)
        task = Task("Test task", due_date)
        self.assertEqual(task.due_date, due_date)

    def test_task_completion(self):
        task = Task("Test task")
        task.complete()
        self.assertTrue(task.completed)

    def test_task_string_representation(self):
        task = Task("Test task")
        task.id = 1
        self.assertEqual(str(task), "[1] Test task (Pending)")

if __name__ == '__main__':
    unittest.main()
```

Next, let's write tests for our `TaskDatabase` class. Update `tests/test_database.py`:

```python
import unittest
import os
import json
from taskmaster.database import TaskDatabase
from taskmaster.task import Task

class TestTaskDatabase(unittest.TestCase):
    def setUp(self):
        self.test_file = "test_tasks.json"
        self.db = TaskDatabase(self.test_file)

    def tearDown(self):
        if os.path.exists(self.test_file):
            os.remove(self.test_file)

    def test_add_task(self):
        task = Task("Test task")
        self.db.add_task(task)
        self.assertEqual(len(self.db.tasks), 1)
        self.assertEqual(self.db.tasks[0].title, "Test task")

    def test_get_all_tasks(self):
        self.db.add_task(Task("Task 1"))
        self.db.add_task(Task("Task 2"))
        tasks = self.db.get_all_tasks()
        self.assertEqual(len(tasks), 2)
        self.assertEqual(tasks[0].title, "Task 1")
        self.assertEqual(tasks[1].title, "Task 2")

    def test_get_task(self):
        self.db.add_task(Task("Task 1"))
        task = self.db.get_task(1)
        self.assertIsNotNone(task)
        self.assertEqual(task.title, "Task 1")

    def test_update_task(self):
        self.db.add_task(Task("Task 1"))
        task = self.db.get_task(1)
        task.title = "Updated Task 1"
        self.db.update_task(task)
        updated_task = self.db.get_task(1)
        self.assertEqual(updated_task.title, "Updated Task 1")

    def test_save_and_load_tasks(self):
        self.db.add_task(Task("Task 1"))
        self.db.add_task(Task("Task 2"))
        self.db.save_tasks()
        
        new_db = TaskDatabase(self.test_file)
        tasks = new_db.get_all_tasks()
        self.assertEqual(len(tasks), 2)
        self.assertEqual(tasks[0].title, "Task 1")
        self.assertEqual(tasks[1].title, "Task 2")

if __name__ == '__main__':
    unittest.main()
```

## 3. Writing Integration Tests

Now, let's write integration tests for our CLI. Update `tests/test_cli.py`:

```python
import unittest
from click.testing import CliRunner
from taskmaster.cli import cli

class TestTaskMasterCLI(unittest.TestCase):
    def setUp(self):
        self.runner = CliRunner()

    def test_add_task(self):
        result = self.runner.invoke(cli, ['add', 'Test task'])
        self.assertEqual(result.exit_code, 0)
        self.assertIn('Task added', result.output)

    def test_list_tasks(self):
        self.runner.invoke(cli, ['add', 'Test task 1'])
        self.runner.invoke(cli, ['add', 'Test task 2'])
        result = self.runner.invoke(cli, ['list'])
        self.assertEqual(result.exit_code, 0)
        self.assertIn('Test task 1', result.output)
        self.assertIn('Test task 2', result.output)

    def test_complete_task(self):
        self.runner.invoke(cli, ['add', 'Test task'])
        result = self.runner.invoke(cli, ['complete', '1'])
        self.assertEqual(result.exit_code, 0)
        self.assertIn('Task completed', result.output)

    def test_configure(self):
        result = self.runner.invoke(cli, ['configure', '--database', 'test_db.json'])
        self.assertEqual(result.exit_code, 0)
        self.assertIn('Database file set to: test_db.json', result.output)

if __name__ == '__main__':
    unittest.main()
```

## 4. Running Tests

To run all tests, use the following command:

```bash
pytest tests/
```

To run tests with coverage report:

```bash
pytest --cov=taskmaster tests/
```

## 5. Debugging Techniques

### Using pdb

Python's built-in debugger, `pdb`, is a powerful tool for debugging. Here's how to use it:

1. Add this line where you want to set a breakpoint:
   ```python
   import pdb; pdb.set_trace()
   ```

2. Run your script normally. It will pause at the breakpoint.

3. Use commands like `n` (next), `s` (step), `c` (continue), and `p` (print) to navigate and inspect your code.

### Using logging for debugging

We've already set up logging in our application. To use it for debugging:

1. Set the log level to DEBUG in your configuration.

2. Add detailed log messages in your code:
   ```python
   logger.debug(f"Variable x has value: {x}")
   ```

3. Check the log file for debugging information.

### Platform-specific debugging

#### Windows
- Use Visual Studio Code with the Python extension for an integrated debugging experience.
- For console applications, you can use the Windows command prompt or PowerShell to run your Python script with the `-m pdb` flag:
  ```
  python -m pdb your_script.py
  ```

#### macOS/Linux
- Use command-line tools like `gdb` or `lldb` for low-level debugging if needed.
- Many IDEs like PyCharm or VS Code provide excellent debugging support on these platforms as well.

## 6. Continuous Integration

Setting up Continuous Integration (CI) can help catch issues early. Here's a simple GitHub Actions workflow (save as `.github/workflows/python-app.yml`):

```yaml
name: Python application

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: 3.8
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Run tests
      run: |
        pytest tests/
```

This workflow will run your tests every time you push to the main branch or create a pull request.

## Conclusion

In this lesson, we've set up a comprehensive testing suite for our TaskMaster CLI tool. We've written unit tests for individual components and integration tests for the CLI interface. We've also explored debugging techniques and set up a basic CI pipeline.

Remember, testing and debugging are ongoing processes. As you add new features or refactor your code, always update and run your tests to ensure everything is working as expected.

In the next and final lesson, we'll focus on packaging and distributing our CLI tool, making it easy for others to install and use TaskMaster.

