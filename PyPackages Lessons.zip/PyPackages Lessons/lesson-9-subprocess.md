# Lesson 9: Subprocess Management

## Introduction

Welcome to Lesson 9 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore subprocess management using Python's `subprocess` module. The ability to run external commands and interact with other programs is crucial for many tasks, from system administration to complex data processing pipelines.

By the end of this lesson, you'll understand how to effectively run external commands, capture their output, handle errors, and manage subprocesses across different operating systems.

## Prerequisites

Before we begin, ensure you have Python installed on your system (Python 3.6 or later is recommended). We'll be using the built-in `subprocess` module, so no additional installations are required.

## Project Structure

Let's set up our project structure. Create a new directory for this lesson and add the following files:

```
subprocess_lesson/
│
├── scripts/
│   ├── hello.py
│   ├── counter.py
│   └── error_script.py
│
├── subprocess_basics.py
├── subprocess_advanced.py
└── subprocess_cross_platform.py
```

You can create this structure using the following commands:

On Unix-like systems (Linux/macOS):
```bash
mkdir -p subprocess_lesson/scripts
touch subprocess_lesson/scripts/hello.py
touch subprocess_lesson/scripts/counter.py
touch subprocess_lesson/scripts/error_script.py
touch subprocess_lesson/subprocess_basics.py
touch subprocess_lesson/subprocess_advanced.py
touch subprocess_lesson/subprocess_cross_platform.py
```

On Windows:
```cmd
mkdir subprocess_lesson
mkdir subprocess_lesson\scripts
type nul > subprocess_lesson\scripts\hello.py
type nul > subprocess_lesson\scripts\counter.py
type nul > subprocess_lesson\scripts\error_script.py
type nul > subprocess_lesson\subprocess_basics.py
type nul > subprocess_lesson\subprocess_advanced.py
type nul > subprocess_lesson\subprocess_cross_platform.py
```

Now, let's add some content to our script files:

In `scripts/hello.py`:
```python
print("Hello from the subprocess!")
```

In `scripts/counter.py`:
```python
import sys
import time

for i in range(1, 6):
    print(f"Count: {i}")
    sys.stdout.flush()
    time.sleep(1)
```

In `scripts/error_script.py`:
```python
import sys

print("This is printed to stdout")
print("This is an error message", file=sys.stderr)
sys.exit(1)
```

## 1. Subprocess Basics

Let's start with the basics of using the `subprocess` module. Open `subprocess_basics.py` and add the following code:

```python
import subprocess

def run_command(command):
    try:
        result = subprocess.run(command, check=True, text=True, capture_output=True)
        print(f"Command '{' '.join(command)}' executed successfully.")
        print("Output:")
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print(f"Error executing command '{' '.join(command)}':")
        print(e.stderr)

def main():
    # Running a simple command
    run_command(["echo", "Hello, Subprocess!"])

    # Running a Python script
    run_command(["python", "scripts/hello.py"])

    # Running a command that doesn't exist
    run_command(["non_existent_command"])

    # Running a command with arguments
    run_command(["python", "-c", "print('Inline Python code')"])

if __name__ == "__main__":
    main()
```

Let's break down this code and explain each part:

1. We define a `run_command` function that takes a command as a list of strings.

2. `subprocess.run()` is used to execute the command. We set `check=True` to raise an exception if the command fails, `text=True` to return strings instead of bytes, and `capture_output=True` to capture stdout and stderr.

3. If the command executes successfully, we print its output. If it fails, we catch the `CalledProcessError` and print the error message.

4. In the `main` function, we demonstrate running different types of commands:
   - A simple shell command (`echo`)
   - A Python script
   - A non-existent command to show error handling
   - A Python command with inline code

## 2. Advanced Subprocess Techniques

Now let's explore some more advanced subprocess techniques. Open `subprocess_advanced.py` and add the following code:

```python
import subprocess
import time

def run_with_timeout(command, timeout):
    try:
        result = subprocess.run(command, timeout=timeout, text=True, capture_output=True)
        print(f"Command '{' '.join(command)}' completed successfully.")
        print("Output:")
        print(result.stdout)
    except subprocess.TimeoutExpired:
        print(f"Command '{' '.join(command)}' timed out after {timeout} seconds.")

def run_with_input(command, input_data):
    result = subprocess.run(command, input=input_data, text=True, capture_output=True)
    print(f"Command '{' '.join(command)}' executed with input.")
    print("Output:")
    print(result.stdout)

def run_with_real_time_output(command):
    process = subprocess.Popen(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    while True:
        output = process.stdout.readline()
        if output:
            print(output.strip())
        elif process.poll() is not None:
            break
    
    if process.returncode != 0:
        print(f"Command '{' '.join(command)}' failed with return code {process.returncode}")
        print("Error output:")
        print(process.stderr.read())

def main():
    # Running a command with a timeout
    run_with_timeout(["python", "scripts/counter.py"], 3)

    # Running a command with input
    run_with_input(["python", "-c", "name = input('Enter your name: '); print(f'Hello, {name}!')"], "Alice\n")

    # Running a command and capturing real-time output
    run_with_real_time_output(["python", "scripts/counter.py"])

    # Running a command and handling both stdout and stderr
    result = subprocess.run(["python", "scripts/error_script.py"], text=True, capture_output=True)
    print("Stdout:")
    print(result.stdout)
    print("Stderr:")
    print(result.stderr)
    print(f"Return code: {result.returncode}")

if __name__ == "__main__":
    main()
```

Let's break down these advanced techniques:

1. **Timeout**: We use the `timeout` parameter in `subprocess.run()` to limit the execution time of a command.

2. **Providing Input**: We use the `input` parameter to provide input to a command.

3. **Real-time Output**: We use `subprocess.Popen()` and read the output line by line to display it in real-time.

4. **Handling stdout and stderr**: We capture both stdout and stderr separately and handle the return code.

## 3. Cross-Platform Considerations

When working with subprocesses across different platforms, there are several things to keep in mind. Open `subprocess_cross_platform.py` and add the following code:

```python
import subprocess
import sys
import os

def run_command(command):
    try:
        result = subprocess.run(command, check=True, text=True, capture_output=True)
        print(f"Command '{' '.join(command)}' executed successfully.")
        print("Output:")
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print(f"Error executing command '{' '.join(command)}':")
        print(e.stderr)

def get_platform_specific_command(command):
    if sys.platform.startswith('win'):
        return ['cmd', '/c'] + command
    else:
        return command

def run_shell_command(command):
    if sys.platform.startswith('win'):
        shell_command = f'cmd /c "{command}"'
    else:
        shell_command = f'/bin/sh -c "{command}"'
    
    result = subprocess.run(shell_command, shell=True, text=True, capture_output=True)
    print(f"Shell command '{command}' executed.")
    print("Output:")
    print(result.stdout)

def main():
    # List directory contents
    if sys.platform.startswith('win'):
        list_command = ['dir']
    else:
        list_command = ['ls', '-l']
    
    run_command(list_command)

    # Use platform-specific path separator
    script_path = os.path.join('scripts', 'hello.py')
    run_command([sys.executable, script_path])

    # Run a shell command
    if sys.platform.startswith('win'):
        shell_command = 'echo %PATH%'
    else:
        shell_command = 'echo $PATH'
    
    run_shell_command(shell_command)

    # Use platform-specific command execution
    ping_command = get_platform_specific_command(['ping', '-c', '4', 'example.com'])
    run_command(ping_command)

if __name__ == "__main__":
    main()
```

This script demonstrates several important cross-platform considerations:

1. **Platform Detection**: We use `sys.platform` to detect the operating system and adjust our commands accordingly.

2. **Command Differences**: We handle differences in commands between Windows and Unix-like systems (e.g., `dir` vs `ls`).

3. **Path Handling**: We use `os.path.join()` to create platform-independent file paths.

4. **Shell Commands**: We demonstrate how to run shell commands, accounting for differences between Windows and Unix-like shells.

5. **Command Wrapping**: On Windows, we sometimes need to wrap commands with `cmd /c` for proper execution.

## Conclusion

In this lesson, we've covered the fundamentals of subprocess management in Python, including:

1. Basic command execution using `subprocess.run()`
2. Advanced techniques like handling timeouts, providing input, and capturing real-time output
3. Cross-platform considerations for running commands on different operating systems

Subprocess management is a powerful tool that allows Python to interact with the system and other programs. While it provides great flexibility, it's important to use it carefully, especially when dealing with user input, to avoid security risks like shell injection.

## Exercises

To reinforce your learning, try these exercises:

1. Write a function that runs a command and returns its output only if it completes within a specified timeout.

2. Create a script that runs multiple commands in parallel using `subprocess.Popen` and waits for all of them to complete.

3. Implement a function that takes a shell command as a string and executes it safely across different platforms, handling potential shell injection vulnerabilities.

4. Write a cross-platform script that finds all Python files in a directory and its subdirectories, and runs them as subprocesses, capturing their output.

5. Create a simple task manager that can start, stop, and monitor the status of long-running background processes.

Remember, when working with subprocesses, always consider security implications, especially when dealing with user input or running commands with elevated privileges.

Happy coding!
