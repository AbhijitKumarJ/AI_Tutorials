# Lesson 29: Hashing and Cryptography Basics with hashlib

## Introduction

Welcome to Lesson 29 of our "Mastering Python Packages for Efficient Programming" series! Today, we're diving into the `hashlib` module, a fundamental tool in Python's standard library for working with cryptographic hash functions. By the end of this lesson, you'll understand what hash functions are, how to use various algorithms provided by `hashlib`, and how to apply them in real-world scenarios.

## What are Cryptographic Hash Functions?

Before we jump into `hashlib`, let's understand what cryptographic hash functions are:

- A hash function is an algorithm that takes an input (or 'message') and returns a fixed-size string of bytes.
- The output is called a 'hash value', 'digest', or simply 'hash'.
- Cryptographic hash functions have several important properties:
  1. Deterministic: The same input always produces the same output.
  2. Quick to compute: It's fast to calculate the hash of any given input.
  3. One-way: It's infeasible to generate a message from its hash value.
  4. Collision-resistant: It's extremely unlikely to find two different messages with the same hash.

Common use cases for cryptographic hash functions include:
- Password storage
- Data integrity checks
- Digital signatures
- Blockchain technology

## Getting Started with hashlib

The `hashlib` module provides a common interface to many different secure hash and message digest algorithms. Let's start by importing it:

```python
import hashlib
```

Now, let's explore the main functionalities of `hashlib`:

1. Generating hashes for strings
2. Generating hashes for files
3. Using different hash algorithms
4. Comparing hashes
5. Key derivation functions

## 1. Generating Hashes for Strings

Let's start with a simple example of generating a hash for a string:

```python
message = "Hello, World!"
hash_object = hashlib.sha256(message.encode())
hex_dig = hash_object.hexdigest()
print(f"SHA256 hash of '{message}' is: {hex_dig}")
```

Output:
```
SHA256 hash of 'Hello, World!' is: dffd6021bb2bd5b0af676290809ec3a53191dd81c7f70a4b28688a362182986f
```

Here's what's happening:
1. We create a message string.
2. We create a hash object using SHA256 algorithm.
3. We encode the message to bytes (required by hashlib).
4. We get the hexadecimal representation of the hash.

## 2. Generating Hashes for Files

Hashing files is useful for checking file integrity. Here's how to hash a file:

```python
def hash_file(filename):
    h = hashlib.sha256()
    with open(filename, 'rb') as file:
        chunk = 0
        while chunk != b'':
            chunk = file.read(1024)
            h.update(chunk)
    return h.hexdigest()

file_hash = hash_file('example.txt')
print(f"SHA256 hash of 'example.txt' is: {file_hash}")
```

This function reads the file in chunks to efficiently handle large files.

## 3. Using Different Hash Algorithms

`hashlib` provides several hash algorithms. Here's how to use different ones:

```python
message = "Hello, World!"

for algorithm in ['md5', 'sha1', 'sha224', 'sha256', 'sha384', 'sha512']:
    hash_object = hashlib.new(algorithm)
    hash_object.update(message.encode())
    print(f"{algorithm}: {hash_object.hexdigest()}")
```

Output:
```
md5: 65a8e27d8879283831b664bd8b7f0ad4
sha1: 0a0a9f2a6772942557ab5355d76af442f8f65e01
sha224: 72a23dfa411ba6fde01dbfabf3b00a709c93ebf273dc29e2d8b261ff
sha256: dffd6021bb2bd5b0af676290809ec3a53191dd81c7f70a4b28688a362182986f
sha384: 5485cc9b3365b4305dfb4e8337e0a598a574f8242bf17289e0dd6c20a3cd44a089de16ab4ab308f63e44b1170eb5f515
sha512: db9b1cd3262dee37756a09b9064973589847caa8e53d31a9d142ea2701b1b28abd97838bb9a27068ba305dc8d04a45a1fcf079de54d607666996b992dcbc732b
```

Note: While `hashlib` provides MD5 and SHA1, these algorithms are considered cryptographically weak and should not be used for security-critical applications.

## 4. Comparing Hashes

Comparing hashes is useful for verifying data integrity. Here's an example:

```python
def verify_message(message, hash_value):
    hash_object = hashlib.sha256(message.encode())
    return hash_object.hexdigest() == hash_value

message = "Hello, World!"
correct_hash = "dffd6021bb2bd5b0af676290809ec3a53191dd81c7f70a4b28688a362182986f"
incorrect_hash = "0000000000000000000000000000000000000000000000000000000000000000"

print(f"Correct hash verification: {verify_message(message, correct_hash)}")
print(f"Incorrect hash verification: {verify_message(message, incorrect_hash)}")
```

Output:
```
Correct hash verification: True
Incorrect hash verification: False
```

## 5. Key Derivation Functions

Key derivation functions (KDFs) are used to derive secret keys from a password or passphrase for use in symmetric encryption algorithms. `hashlib` provides PBKDF2 (Password-Based Key Derivation Function 2):

```python
import os

def derive_key(password, salt=None):
    if salt is None:
        salt = os.urandom(16)
    key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
    return salt, key

# Derive a key
password = "mysecretpassword"
salt, key = derive_key(password)

print(f"Salt: {salt.hex()}")
print(f"Derived key: {key.hex()}")

# Verify the key
verified_salt, verified_key = derive_key(password, salt)
print(f"Key verification: {key == verified_key}")
```

Output:
```
Salt: 8d3989d1f8d005e9f5240aa66d1a07e8
Derived key: 13d6d8a19a656d56b5d54d1b3195fe22b7e9a69303b55fee363447ab178f0de3
Key verification: True
```

This example demonstrates how to use PBKDF2 to derive a key from a password, which is much more secure than using the password directly.

## Practical Example: Simple File Integrity Checker

Let's create a practical example that demonstrates how `hashlib` can be used for checking file integrity. We'll create a simple tool that generates and verifies file hashes.

First, let's set up our project structure:

```
hashlib_example/
│
├── files/
│   ├── document1.txt
│   └── document2.txt
│
├── file_integrity.py
└── main.py
```

Now, let's create some sample files:

`document1.txt`:
```
This is the content of document 1.
It contains some important information.
```

`document2.txt`:
```
This is the content of document 2.
It also contains some important information.
```

Now, let's create our `file_integrity.py`:

```python
import hashlib
import os

def calculate_file_hash(filename):
    h = hashlib.sha256()
    with open(filename, 'rb') as file:
        chunk = 0
        while chunk != b'':
            chunk = file.read(1024)
            h.update(chunk)
    return h.hexdigest()

def generate_hash_file(directory, output_file):
    with open(output_file, 'w') as out_file:
        for root, _, files in os.walk(directory):
            for filename in files:
                file_path = os.path.join(root, filename)
                file_hash = calculate_file_hash(file_path)
                out_file.write(f"{file_path}: {file_hash}\n")

def verify_files(hash_file):
    with open(hash_file, 'r') as file:
        for line in file:
            file_path, stored_hash = line.strip().split(': ')
            if os.path.exists(file_path):
                current_hash = calculate_file_hash(file_path)
                if current_hash == stored_hash:
                    print(f"[OK] {file_path}")
                else:
                    print(f"[MISMATCH] {file_path}")
            else:
                print(f"[MISSING] {file_path}")

```

Now, let's create our `main.py`:

```python
import os
from file_integrity import generate_hash_file, verify_files

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    files_dir = os.path.join(script_dir, 'files')
    hash_file = os.path.join(script_dir, 'file_hashes.txt')

    print("Generating hash file...")
    generate_hash_file(files_dir, hash_file)
    print("Hash file generated.")

    print("\nVerifying files:")
    verify_files(hash_file)

    # Simulate a file change
    print("\nSimulating a change in document1.txt...")
    with open(os.path.join(files_dir, 'document1.txt'), 'a') as file:
        file.write("\nThis line was added to simulate a change.")

    print("\nVerifying files again:")
    verify_files(hash_file)

if __name__ == "__main__":
    main()
```

To run the example, execute `main.py`:

```
python main.py
```

This example demonstrates several `hashlib` concepts:

1. We use `hashlib.sha256()` to generate hashes for files.
2. We create a hash file that stores the hash values for all files in a directory.
3. We verify the integrity of files by comparing their current hash with the stored hash.
4. We simulate a file change to show how the hash verification detects modifications.

## Cross-platform Considerations

The `hashlib` module is part of Python's standard library, so it works consistently across Windows, macOS, and Linux. However, there are a few things to keep in mind:

1. **File paths**: Use `os.path.join()` or `pathlib.Path` to create file paths to ensure they're correct for the current operating system.

2. **Line endings**: Different operating systems use different line ending characters. This can affect the hash of text files if they're transferred between systems. To avoid this, always open files in binary mode ('rb') when hashing.

3. **Available algorithms**: The availability of certain hash algorithms might depend on the underlying OpenSSL library that Python uses. Use `hashlib.algorithms_available` to see which algorithms are available on your system.

## Security Considerations

When working with cryptographic functions, keep these security considerations in mind:

1. **Algorithm choice**: Avoid using MD5 and SHA1 for security-critical applications, as they are considered cryptographically weak. Prefer SHA256 or stronger algorithms.

2. **Password hashing**: For storing password hashes, use specialized password hashing functions like bcrypt, scrypt, or Argon2. While PBKDF2 (provided by `hashlib`) is better than a plain hash, it's not the most secure option for password storage.

3. **Timing attacks**: When comparing hashes (e.g., for password verification), use constant-time comparison functions to prevent timing attacks. Python 3.7+ provides `hmac.compare_digest()` for this purpose.

4. **Salt usage**: Always use a unique salt when deriving keys from passwords or creating password hashes. This prevents rainbow table attacks.

## Conclusion

In this lesson, we've explored the `hashlib` module and its various functions for cryptographic hashing. We've seen how to generate hashes for strings and files, use different hash algorithms, compare hashes, and perform basic key derivation. We've also applied these concepts to a practical file integrity checking example.

Understanding cryptographic hashing is crucial for many aspects of secure programming, from data integrity verification to password storage. As you continue to work on security-related tasks, you'll find many opportunities to apply these techniques to improve your code's security and reliability.

## Exercises

To reinforce your understanding, try these exercises:

1. Modify the file integrity checker to use a command-line interface, allowing users to specify the directory to check and the hash file to use.
2. Implement a simple password hashing and verification system using PBKDF2. (Remember, for real-world applications, use specialized password hashing libraries.)
3. Create a function that generates a unique file name based on the hash of its contents. Use this to identify duplicate files in a directory.

Remember, while `hashlib` provides powerful tools, always stay updated on current security best practices when working with cryptographic functions in real-world applications.

