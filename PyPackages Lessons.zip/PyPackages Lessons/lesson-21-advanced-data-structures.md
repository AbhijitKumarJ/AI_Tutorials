# Lesson 21: Advanced Data Structures with collections

## Introduction

Welcome to Lesson 21 of our "Mastering Python Packages for Efficient Programming" series! Today, we're diving into the `collections` module, which provides specialized container datatypes that extend Python's built-in containers. These data structures offer powerful alternatives to Python's general-purpose built-in containers like dict, list, set, and tuple.

In this lesson, we'll cover:

1. namedtuple: Creating lightweight object types
2. Counter: Efficient counting of hashable objects
3. OrderedDict: Dictionaries that remember insertion order
4. defaultdict: Dictionaries with default values
5. deque: Efficient queue operations

By the end of this lesson, you'll be comfortable using these advanced data structures to write more efficient and expressive code.

## Project Setup

Let's start by setting up our project structure. Create a new directory for this lesson and navigate into it:

```
mkdir lesson_21_collections
cd lesson_21_collections
```

Now, let's create our main Python file and a directory for some sample data:

```
touch collections_examples.py
mkdir sample_data
```

Your project structure should look like this:

```
lesson_21_collections/
│
├── collections_examples.py
└── sample_data/
```

Now, let's open `collections_examples.py` in your favorite text editor and start exploring the `collections` module!

## 1. namedtuple: Creating lightweight object types

`namedtuple` is a factory function that creates tuple subclasses with named fields. It's a great way to create simple classes for storing data without the need for writing a full class definition.

Add the following code to `collections_examples.py`:

```python
from collections import namedtuple

# Define a Person namedtuple
Person = namedtuple('Person', ['name', 'age', 'city'])

# Create a Person instance
alice = Person('Alice', 30, 'New York')

print(f"Name: {alice.name}")
print(f"Age: {alice.age}")
print(f"City: {alice.city}")

# namedtuples are immutable
try:
    alice.age = 31
except AttributeError as e:
    print(f"Error: {e}")

# But you can create a new instance with updated values
bob = alice._replace(name='Bob', age=35)
print(f"New person: {bob}")
```

In this example, we create a `Person` namedtuple with fields for name, age, and city. We can access these fields using dot notation, just like with regular objects. However, namedtuples are immutable, so we can't change their values after creation. The `_replace()` method allows us to create a new instance with updated values.

## 2. Counter: Efficient counting of hashable objects

`Counter` is a dict subclass for counting hashable objects. It's particularly useful for tallying items, finding the most common elements, or performing mathematical operations on counts.

Add the following code to `collections_examples.py`:

```python
from collections import Counter

# Count occurrences of words in a sentence
sentence = "the quick brown fox jumps over the lazy dog"
word_counts = Counter(sentence.split())
print(f"Word counts: {word_counts}")

# Find the three most common words
print(f"Three most common words: {word_counts.most_common(3)}")

# Perform mathematical operations on counters
more_words = Counter(["fox", "dog", "cat", "fox"])
combined_counts = word_counts + more_words
print(f"Combined counts: {combined_counts}")

# Subtract counts
subtracted_counts = combined_counts - word_counts
print(f"Subtracted counts: {subtracted_counts}")
```

This example demonstrates how to use `Counter` to count word occurrences, find the most common elements, and perform mathematical operations on counts.

## 3. OrderedDict: Dictionaries that remember insertion order

`OrderedDict` is a dict subclass that remembers the order in which items were inserted. While regular dictionaries in Python 3.7+ also maintain insertion order, `OrderedDict` provides additional functionality.

Add the following code to `collections_examples.py`:

```python
from collections import OrderedDict

# Create an OrderedDict
od = OrderedDict()
od['first'] = 1
od['second'] = 2
od['third'] = 3

print("Original OrderedDict:")
for key, value in od.items():
    print(f"{key}: {value}")

# Move 'third' to the beginning
od.move_to_end('third', last=False)

print("\nAfter moving 'third' to the beginning:")
for key, value in od.items():
    print(f"{key}: {value}")

# Compare OrderedDict with regular dict
regular_dict = {'a': 1, 'b': 2, 'c': 3}
ordered_dict = OrderedDict({'a': 1, 'b': 2, 'c': 3})

print(f"\nregular_dict == ordered_dict: {regular_dict == ordered_dict}")
print(f"ordered_dict == OrderedDict(regular_dict): {ordered_dict == OrderedDict(regular_dict)}")
```

This example shows how to create and manipulate an `OrderedDict`, including moving items within the dictionary. It also demonstrates the difference in equality comparison between `OrderedDict` and regular dict.

## 4. defaultdict: Dictionaries with default values

`defaultdict` is a dict subclass that calls a factory function to supply missing values. This is particularly useful when working with nested dictionaries or when you want to initialize values automatically.

Add the following code to `collections_examples.py`:

```python
from collections import defaultdict

# Create a defaultdict with int as the default_factory
word_lengths = defaultdict(int)

sentence = "the quick brown fox jumps over the lazy dog"
for word in sentence.split():
    word_lengths[word] += 1

print("Word lengths:")
for word, count in word_lengths.items():
    print(f"{word}: {count}")

# Using defaultdict for nested dictionaries
nested = defaultdict(lambda: defaultdict(list))

# Add items to the nested defaultdict
nested['animals']['mammals'].append('dog')
nested['animals']['mammals'].append('cat')
nested['animals']['birds'].append('eagle')

print("\nNested defaultdict:")
for category, subcategories in nested.items():
    for subcategory, items in subcategories.items():
        print(f"{category} - {subcategory}: {items}")
```

This example demonstrates how to use `defaultdict` with `int` as the default factory to count word occurrences, and how to create nested dictionaries using `defaultdict`.

## 5. deque: Efficient queue operations

`deque` (double-ended queue) is a list-like container that allows efficient insertion and deletion at both ends. It's particularly useful for implementing queues and maintaining a fixed-size buffer.

Add the following code to `collections_examples.py`:

```python
from collections import deque

# Create a deque
queue = deque(['a', 'b', 'c'])

# Add elements to both ends
queue.append('d')
queue.appendleft('z')

print(f"Queue after adding elements: {queue}")

# Remove elements from both ends
popped_right = queue.pop()
popped_left = queue.popleft()

print(f"Popped from right: {popped_right}")
print(f"Popped from left: {popped_left}")
print(f"Queue after popping: {queue}")

# Rotate the deque
queue.rotate(1)  # Rotate right by 1
print(f"Queue after rotating right: {queue}")

queue.rotate(-1)  # Rotate left by 1
print(f"Queue after rotating left: {queue}")

# Create a fixed-size deque
limited_queue = deque(maxlen=3)
for i in range(5):
    limited_queue.append(i)
    print(f"Limited queue: {limited_queue}")
```

This example shows how to create and manipulate a `deque`, including adding and removing elements from both ends, rotating the deque, and creating a fixed-size deque.

## Cross-platform Considerations

The `collections` module is part of Python's standard library, so its behavior is consistent across different operating systems (Windows, macOS, and Linux). However, there are a few points to keep in mind:

1. File paths: When working with file paths in your data structures, use `os.path` or `pathlib` to ensure cross-platform compatibility.

2. Line endings: If you're storing text data in your collections, be aware that line endings may differ between operating systems ('\r\n' on Windows, '\n' on Unix-based systems).

3. Performance: While the behavior of these data structures is consistent across platforms, performance characteristics may vary slightly due to differences in underlying system libraries and hardware.

## Conclusion

In this lesson, we've explored the powerful data structures provided by the `collections` module. These specialized containers can help you write more efficient and expressive code by providing optimized solutions for common programming tasks.

To practice what you've learned, try the following exercises:

1. Use `namedtuple` to create a `Book` type with fields for title, author, and publication year. Create a list of books and sort them by publication year.

2. Use `Counter` to find the most common characters in a given text file.

3. Implement a simple cache using `OrderedDict` that stores a maximum of 10 items, removing the least recently used item when the cache is full.

4. Use `defaultdict` to create a simple graph structure and implement a function to add edges between nodes.

5. Implement a simple task queue using `deque` that processes tasks in the order they were added, but allows for high-priority tasks to be added to the front of the queue.

By mastering these advanced data structures, you'll be better equipped to tackle complex programming challenges and write more efficient Python code.

