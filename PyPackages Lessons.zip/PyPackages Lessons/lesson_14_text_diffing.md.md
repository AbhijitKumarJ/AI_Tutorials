# Lesson 14: Text Diffing and Comparison with difflib

## Introduction

Welcome to Lesson 14 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore text diffing and comparison using Python's `difflib` module. We'll learn how to compare sequences and files, generate unified and context diffs, create HTML diffs for visual comparison, and perform fuzzy string matching. These techniques are crucial for version control systems, text comparison tools, and any application that needs to analyze text differences.

## Setting Up

Let's set up our project structure:

```
text_diffing_project/
├── venv/
├── diff_operations.py
├── file1.txt
├── file2.txt
└── requirements.txt
```

1. Create a new directory for our project:
   ```
   mkdir text_diffing_project
   cd text_diffing_project
   ```

2. Create and activate a virtual environment:
   - On Windows:
     ```
     python -m venv venv
     venv\Scripts\activate
     ```
   - On macOS/Linux:
     ```
     python3 -m venv venv
     source venv/bin/activate
     ```

3. Create a `requirements.txt` file (we won't need to install any external packages for this lesson, but it's good practice):
   ```
   # requirements.txt is intentionally left empty for this lesson
   ```

Now, let's create our `diff_operations.py` file and two sample text files for comparison:

```python
# Create file1.txt
with open('file1.txt', 'w') as f:
    f.write("""This is the first line of file 1.
This is the second line of file 1.
This is the third line of file 1.
This is the fourth line of file 1.
This is the fifth line of file 1.""")

# Create file2.txt
with open('file2.txt', 'w') as f:
    f.write("""This is the first line of file 2.
This is the second line of file 2.
This is the third line of file 1.
This is the inserted line in file 2.
This is the fifth line of file 2.""")
```

## Comparing Sequences

Let's start by comparing two sequences using `difflib.SequenceMatcher`:

```python
import difflib

def compare_sequences():
    sequence1 = "The quick brown fox jumps over the lazy dog.".split()
    sequence2 = "The quick brown dog jumps over the lazy fox.".split()
    
    matcher = difflib.SequenceMatcher(None, sequence1, sequence2)
    
    print(f"Sequences being compared:")
    print(f"Sequence 1: {sequence1}")
    print(f"Sequence 2: {sequence2}")
    print(f"Similarity ratio: {matcher.ratio():.2f}")
    
    print("\nMatching blocks:")
    for block in matcher.get_matching_blocks():
        print(f"Sequence 1 index: {block.a}, Sequence 2 index: {block.b}, Size: {block.size}")
        if block.size > 0:
            print(f"Matched content: {' '.join(sequence1[block.a:block.a+block.size])}")
    
    print("\nDifferences (opcodes):")
    for opcode in matcher.get_opcodes():
        print(f"{opcode[0]:7} Seq1[{opcode[1]:d}:{opcode[2]:d}] Seq2[{opcode[3]:d}:{opcode[4]:d}]")

if __name__ == "__main__":
    compare_sequences()
```

This function demonstrates how to compare two sequences, get their similarity ratio, find matching blocks, and identify differences using opcodes.

## Generating File Diffs

Now let's use `difflib.unified_diff()` to generate a unified diff between two files:

```python
import difflib

def generate_file_diff():
    with open('file1.txt', 'r') as f1, open('file2.txt', 'r') as f2:
        file1_lines = f1.readlines()
        file2_lines = f2.readlines()
    
    diff = difflib.unified_diff(file1_lines, file2_lines, fromfile='file1.txt', tofile='file2.txt')
    
    print("Unified diff:")
    sys.stdout.writelines(diff)

if __name__ == "__main__":
    generate_file_diff()
```

This function reads two files and generates a unified diff between them.

## HTML Diff Generation

`difflib` can also generate HTML diffs for visual comparison:

```python
import difflib

def generate_html_diff():
    with open('file1.txt', 'r') as f1, open('file2.txt', 'r') as f2:
        file1_lines = f1.readlines()
        file2_lines = f2.readlines()
    
    diff = difflib.HtmlDiff().make_file(file1_lines, file2_lines, 'file1.txt', 'file2.txt')
    
    with open('diff.html', 'w') as f:
        f.write(diff)
    
    print("HTML diff has been generated as 'diff.html'")

if __name__ == "__main__":
    generate_html_diff()
```

This function generates an HTML file showing the differences between two files side by side.

## Fuzzy String Matching

`difflib` provides tools for fuzzy string matching, which is useful for finding close matches:

```python
import difflib

def fuzzy_string_matching():
    choices = ["python", "pyhton", "pyton", "python", "pytohn", "pyplot"]
    search_term = "python"
    
    print(f"Searching for: {search_term}")
    print("Close matches:")
    close_matches = difflib.get_close_matches(search_term, choices)
    for match in close_matches:
        print(f"- {match}")
    
    print("\nDifflib's SequenceMatcher ratios:")
    for choice in choices:
        ratio = difflib.SequenceMatcher(None, search_term, choice).ratio()
        print(f"- {choice}: {ratio:.2f}")

if __name__ == "__main__":
    fuzzy_string_matching()
```

This function demonstrates fuzzy string matching to find close matches to a given term and calculate similarity ratios.

## Handling Different Line Endings

When working with files from different operating systems, you may encounter issues with line endings. Here's how to handle them:

```python
import difflib
import os

def normalize_line_endings(text):
    return text.replace('\r\n', '\n').replace('\r', '\n')

def diff_with_normalized_endings():
    with open('file1.txt', 'r', newline='') as f1, open('file2.txt', 'r', newline='') as f2:
        file1_content = normalize_line_endings(f1.read())
        file2_content = normalize_line_endings(f2.read())
    
    file1_lines = file1_content.splitlines(keepends=True)
    file2_lines = file2_content.splitlines(keepends=True)
    
    diff = difflib.unified_diff(file1_lines, file2_lines, fromfile='file1.txt', tofile='file2.txt')
    
    print("Unified diff with normalized line endings:")
    sys.stdout.writelines(diff)

if __name__ == "__main__":
    diff_with_normalized_endings()
```

This function normalizes line endings before performing the diff, ensuring consistent comparison across different platforms.

## Context Diff

In addition to unified diffs, `difflib` can generate context diffs:

```python
import difflib

def generate_context_diff():
    with open('file1.txt', 'r') as f1, open('file2.txt', 'r') as f2:
        file1_lines = f1.readlines()
        file2_lines = f2.readlines()
    
    diff = difflib.context_diff(file1_lines, file2_lines, fromfile='file1.txt', tofile='file2.txt')
    
    print("Context diff:")
    sys.stdout.writelines(diff)

if __name__ == "__main__":
    generate_context_diff()
```

This function generates a context diff between two files, which provides more context around the changes.

## Conclusion

In this lesson, we've explored text diffing and comparison using Python's `difflib` module. We've covered:

1. Comparing sequences and calculating similarity ratios
2. Generating file diffs in unified format
3. Creating HTML diffs for visual comparison
4. Performing fuzzy string matching
5. Handling different line endings in diffs
6. Generating context diffs

These techniques are essential for version control systems, text comparison tools, and any application that needs to analyze text differences. They can be applied in various scenarios, from code review tools to plagiarism detection systems.

## Exercises

To reinforce your learning, try these exercises:

1. Create a simple version control system that uses `difflib` to track changes in text files over time.
2. Implement a plagiarism checker that uses fuzzy string matching to compare a given text against a database of known documents.
3. Build a tool that compares two directories and generates an HTML report showing the differences between files with the same name.
4. Create a function that takes two strings and returns a list of edit operations (insertions, deletions, substitutions) needed to transform one string into the other.
5. Implement a "smart merge" function that can automatically merge changes from two different versions of a file, using `difflib` to detect and resolve conflicts.

Remember, practice is key to mastering these concepts. Happy coding!

