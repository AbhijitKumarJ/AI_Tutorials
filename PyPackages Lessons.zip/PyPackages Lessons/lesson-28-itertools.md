# Lesson 28: Efficient Iteration with itertools

## Introduction

Welcome to Lesson 28 of our "Mastering Python Packages for Efficient Programming" series! Today, we're diving into the `itertools` module, a powerful tool in Python's standard library that provides a collection of fast, memory-efficient tools for creating and working with iterators.

By the end of this lesson, you'll understand what iterators are, how to use various `itertools` functions, and how to apply them to solve real-world problems efficiently.

## What are Iterators?

Before we jump into `itertools`, let's quickly review what iterators are in Python:

- An iterator is an object that can be iterated (looped) upon.
- It represents a stream of data and returns one element at a time.
- Iterators are memory-efficient because they generate values on-the-fly instead of storing them all in memory.

In Python, any object that has `__iter__()` and `__next__()` methods is an iterator.

## Getting Started with itertools

The `itertools` module provides a set of fast, memory-efficient tools for creating iterators for efficient looping. Let's start by importing it:

```python
import itertools
```

Now, let's explore the main categories of functions in `itertools`:

1. Infinite iterators
2. Iterators terminating on the shortest input sequence
3. Combinatoric iterators

## 1. Infinite Iterators

Infinite iterators generate an endless stream of data. They're useful when you need a continuous source of values. Let's look at some examples:

### count()

`count()` generates an endless stream of evenly spaced values.

```python
counter = itertools.count(start=1, step=2)
for _ in range(5):
    print(next(counter))
```

Output:
```
1
3
5
7
9
```

### cycle()

`cycle()` repeats an iterable indefinitely.

```python
colors = itertools.cycle(['red', 'green', 'blue'])
for _ in range(6):
    print(next(colors))
```

Output:
```
red
green
blue
red
green
blue
```

### repeat()

`repeat()` repeats an object, either indefinitely or for a specific number of times.

```python
repeater = itertools.repeat("Hello", 3)
for item in repeater:
    print(item)
```

Output:
```
Hello
Hello
Hello
```

## 2. Iterators Terminating on the Shortest Input Sequence

These functions work on one or more iterables and terminate when the shortest input iterable is exhausted.

### chain()

`chain()` combines multiple iterables into a single iterator.

```python
numbers = [1, 2, 3]
letters = ['A', 'B', 'C']
combined = itertools.chain(numbers, letters)
print(list(combined))
```

Output:
```
[1, 2, 3, 'A', 'B', 'C']
```

### zip_longest()

`zip_longest()` combines elements from multiple iterables, filling in missing values with a specified fillvalue.

```python
numbers = [1, 2]
letters = ['A', 'B', 'C']
combined = itertools.zip_longest(numbers, letters, fillvalue='N/A')
print(list(combined))
```

Output:
```
[(1, 'A'), (2, 'B'), ('N/A', 'C')]
```

## 3. Combinatoric Iterators

Combinatoric iterators generate combinations and permutations of input iterables.

### product()

`product()` computes the Cartesian product of input iterables.

```python
sizes = ['S', 'M', 'L']
colors = ['Red', 'Blue']
products = itertools.product(sizes, colors)
print(list(products))
```

Output:
```
[('S', 'Red'), ('S', 'Blue'), ('M', 'Red'), ('M', 'Blue'), ('L', 'Red'), ('L', 'Blue')]
```

### permutations()

`permutations()` generates all possible orderings of an iterable.

```python
letters = ['A', 'B', 'C']
perms = itertools.permutations(letters, 2)
print(list(perms))
```

Output:
```
[('A', 'B'), ('A', 'C'), ('B', 'A'), ('B', 'C'), ('C', 'A'), ('C', 'B')]
```

### combinations()

`combinations()` generates all possible combinations of a specified length from an iterable.

```python
letters = ['A', 'B', 'C', 'D']
combs = itertools.combinations(letters, 2)
print(list(combs))
```

Output:
```
[('A', 'B'), ('A', 'C'), ('A', 'D'), ('B', 'C'), ('B', 'D'), ('C', 'D')]
```

## Practical Example: Efficient Data Processing

Let's create a practical example that demonstrates how `itertools` can be used for efficient data processing. We'll create a simple log analysis tool that processes log entries and extracts useful information.

First, let's set up our project structure:

```
itertools_example/
│
├── logs/
│   ├── app_log_1.txt
│   └── app_log_2.txt
│
├── log_analyzer.py
└── main.py
```

Now, let's create some sample log files:

`app_log_1.txt`:
```
2023-05-01 10:15:30 INFO User login successful
2023-05-01 10:16:45 WARNING High CPU usage detected
2023-05-01 10:17:20 ERROR Database connection failed
2023-05-01 10:18:10 INFO User logout
```

`app_log_2.txt`:
```
2023-05-01 11:20:15 INFO New user registered
2023-05-01 11:21:30 WARNING Low disk space
2023-05-01 11:22:45 INFO User login successful
2023-05-01 11:23:50 ERROR Application crash detected
```

Now, let's create our `log_analyzer.py`:

```python
import itertools
from collections import Counter
from datetime import datetime

def parse_log_line(line):
    parts = line.split(maxsplit=3)
    return {
        'timestamp': datetime.strptime(f"{parts[0]} {parts[1]}", "%Y-%m-%d %H:%M:%S"),
        'level': parts[2],
        'message': parts[3]
    }

def read_logs(file_paths):
    for file_path in file_paths:
        with open(file_path, 'r') as f:
            yield from f

def analyze_logs(file_paths):
    # Parse all log lines
    log_entries = map(parse_log_line, read_logs(file_paths))

    # Group log entries by hour
    grouped_by_hour = itertools.groupby(
        sorted(log_entries, key=lambda x: x['timestamp'].replace(minute=0, second=0)),
        key=lambda x: x['timestamp'].replace(minute=0, second=0)
    )

    # Analyze log levels and messages for each hour
    for hour, entries in grouped_by_hour:
        entries = list(entries)
        level_counts = Counter(entry['level'] for entry in entries)
        most_common_message = Counter(entry['message'] for entry in entries).most_common(1)[0][0]

        yield {
            'hour': hour,
            'total_entries': len(entries),
            'level_counts': dict(level_counts),
            'most_common_message': most_common_message
        }

```

Now, let's create our `main.py`:

```python
from log_analyzer import analyze_logs

def main():
    log_files = ['logs/app_log_1.txt', 'logs/app_log_2.txt']
    
    print("Hourly Log Analysis:")
    print("-------------------")
    
    for result in analyze_logs(log_files):
        print(f"\nHour: {result['hour']}")
        print(f"Total entries: {result['total_entries']}")
        print("Log levels:")
        for level, count in result['level_counts'].items():
            print(f"  {level}: {count}")
        print(f"Most common message: {result['most_common_message']}")

if __name__ == "__main__":
    main()
```

To run the example, execute `main.py`:

```
python main.py
```

This example demonstrates several `itertools` concepts:

1. We use `itertools.groupby()` to group log entries by hour.
2. We use the `map()` function (not from `itertools`, but a related concept) to efficiently parse log lines.
3. The `read_logs()` function uses `yield from` to create an iterator that reads lines from multiple files.

This approach is memory-efficient because it processes log entries one at a time, rather than loading all logs into memory at once.

## Cross-platform Considerations

The `itertools` module is part of Python's standard library, so it works consistently across Windows, macOS, and Linux. However, there are a few things to keep in mind when working with files on different platforms:

1. **Line endings**: Different operating systems use different line ending characters. Windows uses `\r\n`, while macOS and Linux use `\n`. Python's file handling generally takes care of this, but be aware of it if you're processing text files from different sources.

2. **File paths**: Use `os.path.join()` or `pathlib.Path` to create file paths to ensure they're correct for the current operating system.

3. **File permissions**: When working with files, be aware that file permissions work differently on Windows compared to macOS and Linux. This might affect your ability to read or write files in certain locations.

## Memory Considerations for Large Datasets

When working with large datasets, `itertools` functions can be particularly useful:

1. They generate values on-the-fly, reducing memory usage.
2. They can be chained together to create complex data processing pipelines without intermediate lists.

However, be cautious with functions like `permutations()` and `combinations()` on large inputs, as the number of results can grow exponentially and consume a lot of memory.

## Conclusion

In this lesson, we've explored the `itertools` module and its various functions for efficient iteration. We've seen how to use infinite iterators, iterators that terminate on the shortest input sequence, and combinatoric iterators. We've also applied these concepts to a practical log analysis example.

`itertools` is a powerful tool for writing efficient, memory-friendly Python code. As you continue to work with data processing and analysis tasks, you'll find many opportunities to apply these techniques to improve your code's performance and readability.

## Exercises

To reinforce your understanding, try these exercises:

1. Modify the log analyzer to find the most common log level for each day, using `itertools.groupby()`.
2. Create a function that generates all possible color combinations for a traffic light (red, yellow, green) where each color can be on or off. Use `itertools.product()`.
3. Implement a simple task scheduler that cycles through a list of tasks indefinitely using `itertools.cycle()`.

Remember, practice is key to mastering these concepts. Keep experimenting and applying `itertools` in your projects!

