# Lesson 3: Navigating the File System with os and sys

## Introduction

Welcome to the third lesson of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore the `os` and `sys` modules, which provide powerful tools for interacting with the operating system and file system. These modules are essential for writing cross-platform Python scripts that can work with files, directories, and system-specific operations.

## The `os` Module

The `os` module provides a way to use operating system-dependent functionality in a portable manner. It allows you to interact with the file system, manage processes, and access environment variables.

### Basic File and Directory Operations

Let's start with some common file and directory operations:

```python
import os

# Get current working directory
current_dir = os.getcwd()
print(f"Current directory: {current_dir}")

# List contents of a directory
contents = os.listdir(current_dir)
print(f"Contents of current directory: {contents}")

# Create a new directory
os.mkdir("new_directory")
print("Created 'new_directory'")

# Rename a directory
os.rename("new_directory", "renamed_directory")
print("Renamed 'new_directory' to 'renamed_directory'")

# Remove a directory
os.rmdir("renamed_directory")
print("Removed 'renamed_directory'")

# Create a file
with open("example.txt", "w") as f:
    f.write("Hello, world!")
print("Created 'example.txt'")

# Check if a file exists
if os.path.exists("example.txt"):
    print("'example.txt' exists")

# Get file size
file_size = os.path.getsize("example.txt")
print(f"Size of 'example.txt': {file_size} bytes")

# Remove a file
os.remove("example.txt")
print("Removed 'example.txt'")
```

### Working with File Paths

The `os.path` submodule provides functions for working with file paths in a cross-platform manner:

```python
import os

# Join path components
path = os.path.join("folder", "subfolder", "file.txt")
print(f"Joined path: {path}")

# Get the base name of a path
base = os.path.basename(path)
print(f"Base name: {base}")

# Get the directory name of a path
directory = os.path.dirname(path)
print(f"Directory name: {directory}")

# Split a path into directory and file
dir_name, file_name = os.path.split(path)
print(f"Split path: directory = {dir_name}, file = {file_name}")

# Check if a path is absolute
is_absolute = os.path.isabs(path)
print(f"Is absolute path: {is_absolute}")

# Get the absolute path
abs_path = os.path.abspath(path)
print(f"Absolute path: {abs_path}")

# Normalize a path (resolve '..' and '.')
norm_path = os.path.normpath("/path/to/../folder/./file.txt")
print(f"Normalized path: {norm_path}")
```

### Environment Variables

The `os` module also allows you to access and modify environment variables:

```python
import os

# Get an environment variable
path = os.environ.get('PATH')
print(f"PATH: {path}")

# Set an environment variable
os.environ['MY_VAR'] = 'my_value'
print(f"MY_VAR: {os.environ['MY_VAR']}")

# Delete an environment variable
del os.environ['MY_VAR']
```

## The `sys` Module

The `sys` module provides access to some variables and functions used or maintained by the Python interpreter. It's useful for accessing command-line arguments, Python version information, and more.

### Accessing Command-Line Arguments

One of the most common uses of the `sys` module is to access command-line arguments:

```python
import sys

# Print all command-line arguments
print(f"All arguments: {sys.argv}")

# Print the script name (first argument)
print(f"Script name: {sys.argv[0]}")

# Print other arguments
if len(sys.argv) > 1:
    print("Other arguments:")
    for arg in sys.argv[1:]:
        print(arg)
else:
    print("No additional arguments provided")
```

Save this script as `cli_args.py` and run it with some arguments:

```bash
python cli_args.py arg1 arg2 arg3
```

### Python Version and Platform Information

The `sys` module also provides information about the Python interpreter and the platform it's running on:

```python
import sys

print(f"Python version: {sys.version}")
print(f"Python version info: {sys.version_info}")
print(f"Platform: {sys.platform}")
```

### Managing Python's Search Path

The `sys.path` list contains the search path for Python modules. You can modify this to add additional directories for Python to search for modules:

```python
import sys

print(f"Current search path: {sys.path}")

# Add a new directory to the search path
sys.path.append('/path/to/my/modules')

print(f"Updated search path: {sys.path}")
```

## Practical Example: File Organizer Script

Let's create a practical example that uses both `os` and `sys` to organize files in a directory based on their extensions:

```python
import os
import sys
import shutil

def organize_files(directory):
    # Get all files in the directory
    files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]
    
    for file in files:
        # Get the file extension
        _, extension = os.path.splitext(file)
        extension = extension[1:]  # Remove the dot
        
        if not extension:
            extension = 'no_extension'
        
        # Create a directory for the extension if it doesn't exist
        extension_dir = os.path.join(directory, extension)
        if not os.path.exists(extension_dir):
            os.makedirs(extension_dir)
        
        # Move the file to the corresponding directory
        source = os.path.join(directory, file)
        destination = os.path.join(extension_dir, file)
        shutil.move(source, destination)
        print(f"Moved {file} to {extension_dir}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python file_organizer.py <directory>")
        sys.exit(1)
    
    target_directory = sys.argv[1]
    if not os.path.isdir(target_directory):
        print(f"Error: {target_directory} is not a valid directory")
        sys.exit(1)
    
    organize_files(target_directory)
    print("File organization complete!")
```

Save this script as `file_organizer.py` and run it with a target directory:

```bash
python file_organizer.py /path/to/target/directory
```

This script will organize all files in the specified directory into subdirectories based on their file extensions.

## Cross-Platform Considerations

When working with `os` and `sys`, it's important to keep cross-platform compatibility in mind:

1. **Path Separators**: Use `os.path.join()` to create paths instead of hardcoding separators. This ensures your code works on both Windows (`\`) and Unix-like systems (`/`).

2. **Line Endings**: When working with text files, use `'r'` (read) or `'w'` (write) modes with `open()`. Python will handle line ending differences (`\r\n` on Windows, `\n` on Unix) automatically.

3. **File Permissions**: On Unix-like systems, you can use `os.chmod()` to set file permissions. This function exists on Windows but has limited functionality.

4. **Environment Variables**: Environment variable names are case-sensitive on Unix-like systems but case-insensitive on Windows.

5. **Executable Extensions**: On Windows, executable files typically have a `.exe` extension, while on Unix-like systems they don't. Use `sys.executable` to get the path of the Python interpreter across platforms.

## Best Practices

1. Always use `os.path` functions for path manipulations to ensure cross-platform compatibility.
2. Use context managers (`with` statements) when working with files to ensure they are properly closed.
3. Check for file existence before performing operations to avoid errors.
4. Use `os.path.expanduser('~')` to get the user's home directory across platforms.
5. When possible, use the newer `pathlib` module (which we'll cover in the next lesson) for more object-oriented path manipulations.

## Conclusion

In this lesson, we've explored the `os` and `sys` modules, which provide powerful tools for interacting with the file system and operating system. We've covered basic file and directory operations, path manipulations, environment variables, and command-line argument handling. We've also created a practical file organizer script to demonstrate these concepts in action.

Understanding these modules is crucial for writing Python scripts that can work across different platforms and interact effectively with the underlying operating system.

## Exercises

1. Write a script that recursively lists all files in a directory and its subdirectories, printing their relative paths.

2. Create a script that finds all Python files in a directory, reads them, and prints the total number of lines of code (excluding blank lines and comments).

3. Modify the file organizer script to also organize files based on their creation date (e.g., move files into year/month subdirectories).

4. Write a script that takes a source directory and a destination directory as command-line arguments, and creates a backup of the source directory in the destination directory, maintaining the directory structure.

In the next lesson, we'll explore the `pathlib` module, which provides an object-oriented interface for working with file paths and offers some advantages over the `os.path` module.

