# Lesson 23: Git Operations in Python with GitPython

## Introduction

Welcome to Lesson 23 of our "Mastering Python Packages for Efficient Programming" series! Today, we're diving into GitPython, a powerful library that allows you to interact with Git repositories directly from your Python code. This integration enables you to automate Git operations, analyze repository history, and build custom Git-based tools.

In this lesson, we'll cover:

1. Setting up and initializing Git repositories
2. Basic Git operations: add, commit, push, pull
3. Working with branches and merging
4. Analyzing repository history
5. Handling Git hooks in Python
6. Cross-platform considerations for Git operations

By the end of this lesson, you'll be comfortable using GitPython to perform various Git operations programmatically.

## Project Setup

Let's start by setting up our project structure. Create a new directory for this lesson and navigate into it:

```
mkdir lesson_23_gitpython
cd lesson_23_gitpython
```

Now, let's create our main Python file and a directory for our sample repository:

```
touch git_operations.py
mkdir sample_repo
```

Your project structure should look like this:

```
lesson_23_gitpython/
│
├── git_operations.py
└── sample_repo/
```

Before we begin, make sure you have GitPython installed. You can install it using pip:

```
pip install GitPython
```

Now, let's open `git_operations.py` in your favorite text editor and start exploring GitPython!

## 1. Setting up and initializing Git repositories

First, let's learn how to create a new Git repository or work with an existing one using GitPython. Add the following code to `git_operations.py`:

```python
import os
from git import Repo, GitCommandError

def create_or_open_repo(path):
    if os.path.exists(os.path.join(path, '.git')):
        print(f"Opening existing repository at {path}")
        return Repo(path)
    else:
        print(f"Creating new repository at {path}")
        return Repo.init(path)

# Use the sample_repo directory
repo_path = os.path.join(os.path.dirname(__file__), 'sample_repo')
repo = create_or_open_repo(repo_path)

print(f"Repository working directory: {repo.working_dir}")
print(f"Repository is bare: {repo.bare}")
```

This code defines a function `create_or_open_repo` that either creates a new repository or opens an existing one at the specified path. We then use this function to create or open a repository in our `sample_repo` directory.

## 2. Basic Git operations: add, commit, push, pull

Now that we have a repository, let's perform some basic Git operations. Add the following code to `git_operations.py`:

```python
def perform_basic_operations(repo):
    # Create a new file
    file_path = os.path.join(repo.working_dir, 'example.txt')
    with open(file_path, 'w') as f:
        f.write('This is an example file.\n')

    # Add the file to the repository
    repo.index.add(['example.txt'])
    print("Added example.txt to the repository")

    # Commit the changes
    commit_message = "Add example.txt"
    repo.index.commit(commit_message)
    print(f"Committed changes: {commit_message}")

    # Try to push changes (this will fail if there's no remote repository)
    try:
        origin = repo.remote('origin')
        origin.push()
        print("Pushed changes to remote repository")
    except GitCommandError:
        print("No remote repository set up. Skipping push operation.")

    # Pull changes (this will also fail without a remote repository)
    try:
        origin = repo.remote('origin')
        origin.pull()
        print("Pulled changes from remote repository")
    except GitCommandError:
        print("No remote repository set up. Skipping pull operation.")

perform_basic_operations(repo)
```

This code demonstrates how to create a new file, add it to the repository, commit the changes, and attempt to push and pull changes. Note that the push and pull operations will fail in this example because we haven't set up a remote repository.

## 3. Working with branches and merging

Let's explore how to work with branches and perform merging operations. Add the following code to `git_operations.py`:

```python
def work_with_branches(repo):
    # Create a new branch
    new_branch = repo.create_head('feature-branch')
    print(f"Created new branch: {new_branch}")

    # Switch to the new branch
    new_branch.checkout()
    print(f"Switched to branch: {repo.active_branch}")

    # Make changes in the new branch
    file_path = os.path.join(repo.working_dir, 'feature.txt')
    with open(file_path, 'w') as f:
        f.write('This is a new feature.\n')

    # Commit changes in the new branch
    repo.index.add(['feature.txt'])
    repo.index.commit("Add feature.txt")
    print("Committed changes in feature-branch")

    # Switch back to the main branch
    main_branch = repo.heads.master
    main_branch.checkout()
    print(f"Switched back to branch: {repo.active_branch}")

    # Merge the feature branch into the main branch
    repo.git.merge('feature-branch')
    print("Merged feature-branch into master")

    # Delete the feature branch
    repo.delete_head('feature-branch')
    print("Deleted feature-branch")

work_with_branches(repo)
```

This code demonstrates creating a new branch, switching between branches, making changes, committing them, merging branches, and deleting a branch.

## 4. Analyzing repository history

GitPython allows you to analyze the repository's history easily. Let's add some code to examine commits and diffs. Add the following to `git_operations.py`:

```python
def analyze_history(repo):
    print("\nRepository History:")
    for commit in list(repo.iter_commits())[:5]:  # Get the last 5 commits
        print(f"Commit: {commit.hexsha}")
        print(f"Author: {commit.author}")
        print(f"Date: {commit.committed_datetime}")
        print(f"Message: {commit.message}")
        print("Files changed:")
        for item in commit.stats.files:
            print(f"  {item}")
        print()

    # Get the diff between the last two commits
    if len(list(repo.iter_commits())) >= 2:
        last_commit = repo.head.commit
        second_last_commit = last_commit.parents[0]
        diff = second_last_commit.diff(last_commit)

        print("Diff between the last two commits:")
        for d in diff:
            print(f"File: {d.a_path}")
            print(f"Change type: {d.change_type}")
            print(f"Lines added: {d.diff.count(b'+')}")
            print(f"Lines removed: {d.diff.count(b'-')}")
            print()

analyze_history(repo)
```

This code shows how to iterate through commits, display commit information, and analyze the differences between commits.

## 5. Handling Git hooks in Python

Git hooks are scripts that Git executes before or after events such as commit, push, and receive. GitPython allows you to manage these hooks programmatically. Let's add an example of creating a pre-commit hook:

```python
import stat

def create_pre_commit_hook(repo):
    hooks_dir = os.path.join(repo.git_dir, 'hooks')
    pre_commit_path = os.path.join(hooks_dir, 'pre-commit')

    hook_content = """#!/usr/bin/env python
import sys

print("Running pre-commit hook...")

# Add your custom checks here
# For example, check if the commit message is not empty
commit_msg_file = sys.argv[1]
with open(commit_msg_file, 'r') as f:
    commit_msg = f.read().strip()

if not commit_msg:
    print("Error: Empty commit message")
    sys.exit(1)

print("Pre-commit hook passed")
sys.exit(0)
"""

    with open(pre_commit_path, 'w') as f:
        f.write(hook_content)

    # Make the hook executable
    os.chmod(pre_commit_path, os.stat(pre_commit_path).st_mode | stat.S_IEXEC)

    print(f"Created pre-commit hook at {pre_commit_path}")

create_pre_commit_hook(repo)
```

This code creates a simple pre-commit hook that checks if the commit message is empty. The hook is written as a Python script and made executable.

## 6. Cross-platform considerations for Git operations

When working with GitPython across different platforms (Windows, macOS, and Linux), keep the following points in mind:

1. Path separators: Use `os.path.join()` for constructing file paths to ensure compatibility across platforms.

2. Line endings: Git can be configured to handle line ending conversions automatically, but be aware that different platforms use different line endings by default (CRLF on Windows, LF on Unix-based systems).

3. Executable permissions: On Unix-based systems, you need to set the executable bit for Git hooks. The code above uses `os.chmod()` to do this, which works on all platforms but only has an effect on Unix-based systems.

4. Python shebang: In the pre-commit hook example, we used `#!/usr/bin/env python` as the shebang. This is more portable than specifying an absolute path to the Python interpreter.

5. Git installation: Ensure that Git is installed and accessible from the command line on all platforms where your script will run.

Here's an example of how to handle some of these cross-platform issues:

```python
import os
import sys
import stat

def create_cross_platform_hook(repo, hook_name, content):
    hooks_dir = os.path.join(repo.git_dir, 'hooks')
    hook_path = os.path.join(hooks_dir, hook_name)

    # Use platform-specific line endings
    if sys.platform.startswith('win'):
        content = content.replace('\n', '\r\n')

    with open(hook_path, 'w', newline='') as f:
        f.write(content)

    # Make the hook executable on Unix-based systems
    if not sys.platform.startswith('win'):
        current_permissions = os.stat(hook_path).st_mode
        os.chmod(hook_path, current_permissions | stat.S_IEXEC)

    print(f"Created {hook_name} hook at {hook_path}")

# Example usage
create_cross_platform_hook(repo, 'pre-commit', """#!/usr/bin/env python
import sys
print("Cross-platform pre-commit hook")
# Add your hook logic here
""")
```

This function handles line ending differences and sets executable permissions only on Unix-based systems.

## Conclusion

In this lesson, we've explored how to use GitPython to perform various Git operations programmatically. We've covered repository initialization, basic Git operations, branch management, history analysis, and hook creation. We've also discussed some important cross-platform considerations when working with GitPython.

To practice what you've learned, try the following exercises:

1. Create a script that automatically commits and pushes changes to a remote repository every hour.

2. Implement a program that analyzes a Git repository and generates a report of the most active contributors and the files they've modified.

3. Build a pre-receive hook that enforces a specific branch naming convention for your team.

4. Create a tool that compares two branches and lists all the files that differ between them.

5. Implement a post-commit hook that automatically creates a tag for every 10th commit.

By mastering GitPython, you'll be able to automate Git workflows, build custom Git-based tools, and integrate version control seamlessly into your Python applications.

