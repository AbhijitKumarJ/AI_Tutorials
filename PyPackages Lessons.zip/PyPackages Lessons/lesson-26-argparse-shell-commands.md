# Lesson 26: Argument Parsing and Shell Commands

## Introduction

Welcome to Lesson 26 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore how to create command-line interfaces (CLIs) using the `argparse` module and how to work with shell commands using the `shlex` module. These skills are crucial for developing versatile Python applications that can be easily controlled from the command line and interact with the operating system.

In this lesson, we'll cover:

1. Building CLIs with argparse
2. Handling command-line options and arguments
3. Using shlex for shell-like syntax parsing
4. Creating interactive command-line applications
5. Cross-platform considerations for CLI development

By the end of this lesson, you'll be able to create sophisticated command-line interfaces and work effectively with shell commands in your Python programs.

## Project Setup

Let's start by setting up our project structure. Create a new directory for this lesson and navigate into it:

```
mkdir lesson_26_cli_shell
cd lesson_26_cli_shell
```

Now, let's create our main Python files:

```
touch cli_app.py
touch interactive_cli.py
```

Your project structure should look like this:

```
lesson_26_cli_shell/
│
├── cli_app.py
└── interactive_cli.py
```

Both `argparse` and `shlex` are part of the Python standard library, so no additional installation is needed. Let's dive into creating command-line interfaces and working with shell commands!

## 1. Building CLIs with argparse

The `argparse` module makes it easy to create user-friendly command-line interfaces. Let's start by creating a simple CLI application. Open `cli_app.py` and add the following code:

```python
import argparse

def main():
    parser = argparse.ArgumentParser(description="A simple CLI application")
    parser.add_argument("name", help="Name of the user")
    parser.add_argument("-a", "--age", type=int, help="Age of the user")
    parser.add_argument("-g", "--greeting", default="Hello", help="Greeting to use")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose output")

    args = parser.parse_args()

    greeting = f"{args.greeting}, {args.name}!"
    if args.age:
        greeting += f" You are {args.age} years old."

    print(greeting)

    if args.verbose:
        print("Verbose mode enabled")
        print(f"Arguments received: {args}")

if __name__ == "__main__":
    main()
```

This script creates a simple CLI that takes a name as a positional argument and offers optional arguments for age, greeting, and verbose mode. You can run it like this:

```
python cli_app.py John --age 30 --greeting Hi -v
```

## 2. Handling command-line options and arguments

Let's expand our CLI to handle more complex scenarios, including subcommands. Modify `cli_app.py` as follows:

```python
import argparse

def greet(args):
    greeting = f"{args.greeting}, {args.name}!"
    if args.age:
        greeting += f" You are {args.age} years old."
    print(greeting)

def calculate(args):
    if args.operation == "add":
        result = args.x + args.y
    elif args.operation == "subtract":
        result = args.x - args.y
    elif args.operation == "multiply":
        result = args.x * args.y
    elif args.operation == "divide":
        result = args.x / args.y if args.y != 0 else "Error: Division by zero"
    else:
        result = "Error: Invalid operation"
    
    print(f"Result: {result}")

def main():
    parser = argparse.ArgumentParser(description="A multi-function CLI application")
    subparsers = parser.add_subparsers(title="subcommands", dest="subcommand")

    # Greet subcommand
    greet_parser = subparsers.add_parser("greet", help="Greet the user")
    greet_parser.add_argument("name", help="Name of the user")
    greet_parser.add_argument("-a", "--age", type=int, help="Age of the user")
    greet_parser.add_argument("-g", "--greeting", default="Hello", help="Greeting to use")
    greet_parser.set_defaults(func=greet)

    # Calculate subcommand
    calc_parser = subparsers.add_parser("calculate", help="Perform a calculation")
    calc_parser.add_argument("operation", choices=["add", "subtract", "multiply", "divide"], help="Operation to perform")
    calc_parser.add_argument("x", type=float, help="First number")
    calc_parser.add_argument("y", type=float, help="Second number")
    calc_parser.set_defaults(func=calculate)

    args = parser.parse_args()
    
    if args.subcommand is None:
        parser.print_help()
    else:
        args.func(args)

if __name__ == "__main__":
    main()
```

This updated script now supports two subcommands: `greet` and `calculate`. You can run it like this:

```
python cli_app.py greet John --age 30
python cli_app.py calculate add 5 3
```

## 3. Using shlex for shell-like syntax parsing

The `shlex` module is useful for parsing shell-like syntaxes. It's particularly helpful when you need to split strings into tokens, respecting quoted substrings. Let's create a simple example that uses `shlex` to parse a command string. Add the following to `cli_app.py`:

```python
import shlex

def parse_command(command_string):
    return shlex.split(command_string)

# Add this to the main function
    if args.subcommand == "parse":
        parsed = parse_command(args.command)
        print(f"Parsed command: {parsed}")

# Add this to the argument parser setup in the main function
    parse_parser = subparsers.add_parser("parse", help="Parse a shell-like command")
    parse_parser.add_argument("command", help="Command string to parse")
```

Now you can use the `parse` subcommand to split a command string:

```
python cli_app.py parse "echo 'Hello, World!' | grep Hello"
```

## 4. Creating interactive command-line applications

Let's create an interactive CLI application that allows users to enter commands repeatedly. Create a new file called `interactive_cli.py` with the following content:

```python
import cmd
import shlex

class InteractiveCLI(cmd.Cmd):
    intro = "Welcome to the Interactive CLI. Type help or ? to list commands.\n"
    prompt = "(cli) "

    def do_greet(self, arg):
        """Greet a person: greet [name] [--greeting GREETING]"""
        args = shlex.split(arg)
        parser = argparse.ArgumentParser(prog="greet")
        parser.add_argument("name", nargs="?", default="User")
        parser.add_argument("--greeting", default="Hello")
        
        try:
            parsed_args = parser.parse_args(args)
            print(f"{parsed_args.greeting}, {parsed_args.name}!")
        except SystemExit:
            # Catch the SystemExit exception to prevent the program from exiting on help or error
            pass

    def do_calculate(self, arg):
        """Perform a calculation: calculate <operation> <x> <y>"""
        args = shlex.split(arg)
        if len(args) != 3:
            print("Usage: calculate <operation> <x> <y>")
            return
        
        operation, x, y = args
        try:
            x, y = float(x), float(y)
        except ValueError:
            print("Error: x and y must be numbers")
            return
        
        if operation == "add":
            result = x + y
        elif operation == "subtract":
            result = x - y
        elif operation == "multiply":
            result = x * y
        elif operation == "divide":
            result = x / y if y != 0 else "Error: Division by zero"
        else:
            result = "Error: Invalid operation"
        
        print(f"Result: {result}")

    def do_exit(self, arg):
        """Exit the application"""
        print("Goodbye!")
        return True

if __name__ == "__main__":
    InteractiveCLI().cmdloop()
```

This interactive CLI allows users to enter commands repeatedly without restarting the script. You can run it with:

```
python interactive_cli.py
```

## 5. Cross-platform considerations for CLI development

When developing CLI applications, it's important to consider cross-platform compatibility. Here are some key points to keep in mind:

1. Use `os.path` for file path operations to ensure compatibility across different operating systems.

2. Be mindful of line endings (`\n` on Unix-like systems, `\r\n` on Windows) when reading or writing files.

3. Use the `subprocess` module for running external commands, as it provides better cross-platform support than `os.system()`.

4. Consider using `click` or `typer` libraries for more advanced CLI features and better cross-platform support.

5. Be aware of terminal color support differences between platforms.

Let's add a cross-platform example to our `cli_app.py`:

```python
import os
import subprocess

def list_directory(args):
    directory = args.directory or os.getcwd()
    try:
        if os.name == 'nt':  # Windows
            result = subprocess.run(["dir", "/B", directory], capture_output=True, text=True, check=True)
        else:  # Unix-like systems
            result = subprocess.run(["ls", "-1", directory], capture_output=True, text=True, check=True)
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print(f"Error listing directory: {e}")

# Add this to the argument parser setup in the main function
    list_parser = subparsers.add_parser("list", help="List directory contents")
    list_parser.add_argument("directory", nargs="?", help="Directory to list (default: current directory)")
    list_parser.set_defaults(func=list_directory)
```

This example demonstrates how to create a cross-platform directory listing command that works on both Windows and Unix-like systems.

## Conclusion

In this lesson, we've explored how to create command-line interfaces using `argparse` and work with shell commands using `shlex`. We've covered:

1. Building CLIs with argparse
2. Handling command-line options and arguments
3. Using shlex for shell-like syntax parsing
4. Creating interactive command-line applications
5. Cross-platform considerations for CLI development

These skills are essential for creating robust, user-friendly Python applications that can be easily controlled from the command line and interact with the operating system.

To practice what you've learned, try the following exercises:

1. Extend the `calculate` subcommand to support more operations (e.g., exponentiation, modulus).

2. Create a file manipulation CLI that can create, read, update, and delete files using subcommands.

3. Implement a simple task management CLI that allows users to add, list, and complete tasks, storing the data in a JSON file.

4. Develop a CLI tool that can compress and decompress directories using the `zipfile` module, with progress reporting.

5. Create a cross-platform system information tool that displays CPU, memory, and disk usage information.

By mastering these CLI and shell command techniques, you'll be well-equipped to create powerful and flexible Python applications that can be easily used and automated from the command line.

