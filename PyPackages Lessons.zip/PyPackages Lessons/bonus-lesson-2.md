# Bonus Lesson 2: Implementing Core Functionality with ArgParse and Click

In this lesson, we'll implement the core functionality of our TaskMaster CLI tool using both ArgParse and Click. We'll compare these two popular libraries for creating command-line interfaces in Python.

## Part 1: Implementing with ArgParse

First, let's implement our CLI using ArgParse, which is part of the Python standard library.

Create a new file `taskmaster/cli_argparse.py`:

```python
import argparse
from datetime import datetime, timedelta
from .task import Task
from .database import TaskDatabase

class TaskMasterCLI:
    def __init__(self):
        self.parser = argparse.ArgumentParser(description="TaskMaster: A simple CLI task manager.")
        self.subparsers = self.parser.add_subparsers(dest="command", help="Available commands")
        self.db = TaskDatabase()

        # Add command
        add_parser = self.subparsers.add_parser("add", help="Add a new task")
        add_parser.add_argument("title", help="Title of the task")
        add_parser.add_argument("-d", "--due", help="Due date (YYYY-MM-DD)")

        # List command
        list_parser = self.subparsers.add_parser("list", help="List all tasks")

        # Complete command
        complete_parser = self.subparsers.add_parser("complete", help="Mark a task as complete")
        complete_parser.add_argument("task_id", type=int, help="ID of the task to complete")

    def run(self):
        args = self.parser.parse_args()

        if args.command == "add":
            due_date = datetime.strptime(args.due, "%Y-%m-%d") if args.due else None
            task = Task(args.title, due_date)
            self.db.add_task(task)
            print(f"Task added: {task}")

        elif args.command == "list":
            tasks = self.db.get_all_tasks()
            if tasks:
                for task in tasks:
                    print(task)
            else:
                print("No tasks found.")

        elif args.command == "complete":
            task = self.db.get_task(args.task_id)
            if task:
                task.complete()
                self.db.update_task(task)
                print(f"Task completed: {task}")
            else:
                print(f"Task with ID {args.task_id} not found.")

        else:
            self.parser.print_help()

if __name__ == "__main__":
    cli = TaskMasterCLI()
    cli.run()
```

## Part 2: Implementing with Click

Now, let's implement the same functionality using Click. Update the `taskmaster/cli.py` file:

```python
import click
from datetime import datetime
from .task import Task
from .database import TaskDatabase

@click.group()
@click.pass_context
def cli(ctx):
    """TaskMaster: A simple CLI task manager."""
    ctx.obj = TaskDatabase()

@cli.command()
@click.argument("title")
@click.option("-d", "--due", help="Due date (YYYY-MM-DD)")
@click.pass_obj
def add(db, title, due):
    """Add a new task."""
    due_date = datetime.strptime(due, "%Y-%m-%d") if due else None
    task = Task(title, due_date)
    db.add_task(task)
    click.echo(f"Task added: {task}")

@cli.command()
@click.pass_obj
def list(db):
    """List all tasks."""
    tasks = db.get_all_tasks()
    if tasks:
        for task in tasks:
            click.echo(task)
    else:
        click.echo("No tasks found.")

@cli.command()
@click.argument("task_id", type=int)
@click.pass_obj
def complete(db, task_id):
    """Mark a task as complete."""
    task = db.get_task(task_id)
    if task:
        task.complete()
        db.update_task(task)
        click.echo(f"Task completed: {task}")
    else:
        click.echo(f"Task with ID {task_id} not found.")

if __name__ == "__main__":
    cli()
```

## Implementing Task and Database Classes

Let's create the `Task` and `TaskDatabase` classes. 

Update `taskmaster/task.py`:

```python
from datetime import datetime

class Task:
    def __init__(self, title, due_date=None, completed=False):
        self.id = None
        self.title = title
        self.due_date = due_date
        self.completed = completed
        self.created_at = datetime.now()

    def complete(self):
        self.completed = True

    def __str__(self):
        status = "Completed" if self.completed else "Pending"
        due = f", Due: {self.due_date.strftime('%Y-%m-%d')}" if self.due_date else ""
        return f"[{self.id}] {self.title} ({status}{due})"
```

Update `taskmaster/database.py`:

```python
import json
import os
from .task import Task

class TaskDatabase:
    def __init__(self, filename="tasks.json"):
        self.filename = filename
        self.tasks = []
        self.load_tasks()

    def load_tasks(self):
        if os.path.exists(self.filename):
            with open(self.filename, "r") as f:
                data = json.load(f)
                self.tasks = [Task(**task) for task in data]

    def save_tasks(self):
        with open(self.filename, "w") as f:
            json.dump([task.__dict__ for task in self.tasks], f, default=str)

    def add_task(self, task):
        task.id = len(self.tasks) + 1
        self.tasks.append(task)
        self.save_tasks()

    def get_all_tasks(self):
        return self.tasks

    def get_task(self, task_id):
        for task in self.tasks:
            if task.id == task_id:
                return task
        return None

    def update_task(self, updated_task):
        for i, task in enumerate(self.tasks):
            if task.id == updated_task.id:
                self.tasks[i] = updated_task
                self.save_tasks()
                return
        raise ValueError(f"Task with ID {updated_task.id} not found.")
```

## Comparing ArgParse and Click

Both ArgParse and Click are powerful libraries for creating command-line interfaces, but they have some key differences:

1. **Syntax**: ArgParse uses a more imperative style, while Click uses decorators, making Click code often more concise and readable.

2. **Subcommands**: Click makes it easier to create nested subcommands, which can be helpful for complex CLI tools.

3. **Documentation**: Click automatically generates help texts and man pages, which can save time in documentation.

4. **Type Conversion**: Click handles type conversion automatically, while ArgParse requires more manual type specification.

5. **Testing**: Click provides better support for testing CLI applications.

6. **Extensibility**: Click is more easily extensible with custom types and commands.

For our TaskMaster tool, Click's decorator-based approach and built-in features make it a better choice, especially as we plan to add more complex functionality in future lessons.

## Cross-platform Considerations

1. **File Paths**: We used os.path.exists() in the TaskDatabase class, which works across platforms.

2. **Date Handling**: We used the datetime module, which works consistently across platforms. However, be aware that the default string representation of dates can vary between platforms. We've used explicit formatting (%Y-%m-%d) to ensure consistency.

3. **File I/O**: We've used the 'w' mode for writing JSON files, which handles line endings appropriately across platforms.

4. **Console Output**: Both ArgParse and Click handle console output in a cross-platform manner. Click, in particular, has features for handling colored output across different terminals and operating systems.

## Testing Our Implementation

Let's test our Click-based implementation:

```bash
# Add a task
taskmaster add "Complete the CLI tool" --due 2023-12-31

# List tasks
taskmaster list

# Complete a task
taskmaster complete 1

# List tasks again
taskmaster list
```

## Conclusion

In this lesson, we've implemented the core functionality of our TaskMaster CLI tool using both ArgParse and Click. We've seen how these libraries differ in their approach to creating command-line interfaces, and we've chosen Click for our project due to its more modern and flexible API.

In the next lesson, we'll add advanced features to our CLI tool, including logging, configuration management, and a plugin system. We'll also explore how to make these features work seamlessly across different operating systems.

