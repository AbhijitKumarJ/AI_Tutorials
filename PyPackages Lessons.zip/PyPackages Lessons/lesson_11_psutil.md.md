# Lesson 11: Process and System Monitoring with psutil

## Introduction

Welcome to Lesson 11 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore the powerful `psutil` (Python System and Process Utilities) library. This cross-platform library is incredibly useful for retrieving information on running processes and system utilization (CPU, memory, disks, network, sensors) in Python.

By the end of this lesson, you'll be able to monitor system resources, manage processes, and gather detailed system information using Python, regardless of whether you're working on Windows, macOS, or Linux.

## Setting Up

First, let's set up our project structure and install the necessary package:

```
python_monitoring_project/
├── venv/
├── system_monitor.py
└── requirements.txt
```

1. Create a new directory for our project:
   ```
   mkdir python_monitoring_project
   cd python_monitoring_project
   ```

2. Create and activate a virtual environment:
   - On Windows:
     ```
     python -m venv venv
     venv\Scripts\activate
     ```
   - On macOS/Linux:
     ```
     python3 -m venv venv
     source venv/bin/activate
     ```

3. Install psutil:
   ```
   pip install psutil
   ```

4. Create a `requirements.txt` file:
   ```
   pip freeze > requirements.txt
   ```

Now, let's create our `system_monitor.py` file and start exploring psutil!

## Basic Usage of psutil

Let's start with some basic system information retrieval:

```python
import psutil

def print_system_info():
    print(f"CPU cores: {psutil.cpu_count()}")
    print(f"Total memory: {psutil.virtual_memory().total / (1024 * 1024 * 1024):.2f} GB")
    print(f"Available memory: {psutil.virtual_memory().available / (1024 * 1024 * 1024):.2f} GB")
    print(f"Disk usage: {psutil.disk_usage('/').percent}%")
    print(f"Battery percentage: {psutil.sensors_battery().percent if psutil.sensors_battery() else 'N/A'}%")

if __name__ == "__main__":
    print_system_info()
```

This script provides basic system information. Run it to see the output:

```
python system_monitor.py
```

## CPU Monitoring

Let's add a function to monitor CPU usage:

```python
import psutil
import time

def monitor_cpu(duration=10, interval=1):
    print(f"Monitoring CPU usage for {duration} seconds...")
    for _ in range(duration):
        cpu_percent = psutil.cpu_percent(interval=interval)
        print(f"CPU Usage: {cpu_percent}%")

if __name__ == "__main__":
    monitor_cpu()
```

This function monitors CPU usage for a specified duration, printing the percentage every second.

## Memory Monitoring

Next, let's add a function to monitor memory usage:

```python
def monitor_memory(duration=10, interval=1):
    print(f"Monitoring memory usage for {duration} seconds...")
    for _ in range(duration):
        memory = psutil.virtual_memory()
        print(f"Total: {memory.total / (1024 * 1024 * 1024):.2f} GB, "
              f"Available: {memory.available / (1024 * 1024 * 1024):.2f} GB, "
              f"Used: {memory.percent}%")
        time.sleep(interval)

if __name__ == "__main__":
    monitor_memory()
```

This function monitors memory usage, showing total, available, and used memory.

## Disk Usage

Let's add a function to check disk usage:

```python
def check_disk_usage(path="/"):
    disk = psutil.disk_usage(path)
    print(f"Disk usage for {path}:")
    print(f"Total: {disk.total / (1024 * 1024 * 1024):.2f} GB")
    print(f"Used: {disk.used / (1024 * 1024 * 1024):.2f} GB")
    print(f"Free: {disk.free / (1024 * 1024 * 1024):.2f} GB")
    print(f"Percentage used: {disk.percent}%")

if __name__ == "__main__":
    check_disk_usage()
```

This function checks the disk usage for a specified path (default is the root directory).

## Network Statistics

Now, let's add a function to monitor network statistics:

```python
def monitor_network(duration=10, interval=1):
    print(f"Monitoring network usage for {duration} seconds...")
    old_net_io = psutil.net_io_counters()
    for _ in range(duration):
        time.sleep(interval)
        new_net_io = psutil.net_io_counters()
        
        bytes_sent = new_net_io.bytes_sent - old_net_io.bytes_sent
        bytes_recv = new_net_io.bytes_recv - old_net_io.bytes_recv
        
        print(f"Bytes sent: {bytes_sent / 1024:.2f} KB, "
              f"Bytes received: {bytes_recv / 1024:.2f} KB")
        
        old_net_io = new_net_io

if __name__ == "__main__":
    monitor_network()
```

This function monitors network usage, showing bytes sent and received over the specified duration.

## Process Management

Let's add some functions for process management:

```python
def list_processes():
    for process in psutil.process_iter(['pid', 'name', 'status']):
        print(f"PID: {process.info['pid']}, "
              f"Name: {process.info['name']}, "
              f"Status: {process.info['status']}")

def get_process_info(pid):
    try:
        process = psutil.Process(pid)
        print(f"Process name: {process.name()}")
        print(f"CPU usage: {process.cpu_percent(interval=1)}%")
        print(f"Memory usage: {process.memory_percent():.2f}%")
        print(f"Status: {process.status()}")
    except psutil.NoSuchProcess:
        print(f"No process found with PID {pid}")

if __name__ == "__main__":
    list_processes()
    pid = int(input("Enter a PID to get more info: "))
    get_process_info(pid)
```

These functions list all running processes and provide detailed information about a specific process.

## Cross-Platform Considerations

While psutil is largely cross-platform, there are some differences to be aware of:

1. **Sensors**: On Windows, `sensors_battery()` might not be available on desktop PCs. On macOS and Linux, additional sensor information (like temperatures) might be available.

2. **Process names**: Process names might differ across platforms. For example, the Python interpreter might be "python.exe" on Windows and "python" on Unix-like systems.

3. **Disk partitions**: The way disk partitions are represented differs between platforms. On Windows, you'll see drive letters (C:, D:), while on Unix-like systems, you'll see mount points (/home, /usr).

4. **Users and permissions**: Certain operations might require elevated privileges on some systems. For example, accessing information about other users' processes might require root/administrator access on Unix-like systems.

Let's add a function to demonstrate some of these differences:

```python
import platform

def show_platform_specifics():
    system = platform.system()
    print(f"Operating System: {system}")
    
    if system == "Windows":
        print("Windows-specific info:")
        print(f"Boot time: {psutil.boot_time()}")
        print(f"Windows version: {platform.version()}")
    elif system == "Darwin":  # macOS
        print("macOS-specific info:")
        print(f"macOS version: {platform.mac_ver()[0]}")
        temps = psutil.sensors_temperatures()
        if temps:
            print("CPU Temperature:")
            for name, entries in temps.items():
                for entry in entries:
                    print(f"{name}: {entry.current}°C")
    elif system == "Linux":
        print("Linux-specific info:")
        print(f"Linux distribution: {' '.join(platform.dist())}")
        temps = psutil.sensors_temperatures()
        if temps:
            print("CPU Temperature:")
            for name, entries in temps.items():
                for entry in entries:
                    print(f"{name}: {entry.current}°C")
    
    print("\nCommon info:")
    print(f"CPU frequency: {psutil.cpu_freq().current:.2f} MHz")
    print(f"Total RAM: {psutil.virtual_memory().total / (1024 * 1024 * 1024):.2f} GB")

if __name__ == "__main__":
    show_platform_specifics()
```

This function demonstrates some platform-specific features and information that psutil can provide.

## Conclusion

In this lesson, we've explored the powerful psutil library for monitoring system resources and managing processes. We've covered CPU, memory, and disk usage monitoring, network statistics, and process management. We've also looked at some cross-platform considerations when using psutil.

Here's a quick recap of what we've learned:
1. Basic system information retrieval
2. CPU and memory monitoring
3. Disk usage checking
4. Network statistics monitoring
5. Process listing and information retrieval
6. Platform-specific features and information

As you continue to work with psutil, remember to consider the differences between operating systems, especially when developing cross-platform applications.

## Exercises

To reinforce your learning, try these exercises:

1. Create a real-time system monitor that updates every second, showing CPU, memory, and disk usage.
2. Write a script that finds the top 5 processes by CPU usage and top 5 by memory usage.
3. Create a network usage logger that records data transfer rates to a CSV file every minute.
4. Write a function that alerts you when CPU usage goes above 80% or when available disk space falls below 10%.

Remember, practice is key to mastering these concepts. Happy coding!

