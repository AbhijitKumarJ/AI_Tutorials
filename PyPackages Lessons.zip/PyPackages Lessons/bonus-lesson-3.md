# Bonus Lesson 3: Adding Advanced Features: Logging, Configuration, and Plugins

In this lesson, we'll enhance our TaskMaster CLI tool by adding logging, configuration management, and a plugin system. These advanced features will make our tool more robust, flexible, and easier to maintain.

## 1. Implementing Logging

Logging is crucial for debugging and monitoring the behavior of our application. We'll use Python's built-in `logging` module to implement this feature.

Create a new file `taskmaster/logger.py`:

```python
import logging
import os
from logging.handlers import RotatingFileHandler

def setup_logger(log_level=logging.INFO):
    logger = logging.getLogger("taskmaster")
    logger.setLevel(log_level)

    # Create logs directory if it doesn't exist
    log_dir = os.path.join(os.path.dirname(__file__), '..', 'logs')
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, 'taskmaster.log')

    # Create a rotating file handler
    file_handler = RotatingFileHandler(log_file, maxBytes=1024 * 1024, backupCount=5)
    file_handler.setLevel(log_level)

    # Create a console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.ERROR)  # Only log errors to console

    # Create a formatter and add it to the handlers
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # Add the handlers to the logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger

# Global logger instance
logger = setup_logger()
```

Now, let's update our `cli.py` to use the logger:

```python
import click
from datetime import datetime
from .task import Task
from .database import TaskDatabase
from .logger import logger

@click.group()
@click.pass_context
def cli(ctx):
    """TaskMaster: A simple CLI task manager."""
    ctx.obj = TaskDatabase()
    logger.info("TaskMaster CLI started")

@cli.command()
@click.argument("title")
@click.option("-d", "--due", help="Due date (YYYY-MM-DD)")
@click.pass_obj
def add(db, title, due):
    """Add a new task."""
    try:
        due_date = datetime.strptime(due, "%Y-%m-%d") if due else None
        task = Task(title, due_date)
        db.add_task(task)
        click.echo(f"Task added: {task}")
        logger.info(f"Task added: {task}")
    except ValueError as e:
        logger.error(f"Error adding task: {str(e)}")
        click.echo(f"Error: {str(e)}")

# Update other commands similarly...

if __name__ == "__main__":
    cli()
```

## 2. Implementing Configuration Management

Configuration management allows users to customize the behavior of our application. We'll use the `configparser` module to implement this feature.

Create a new file `taskmaster/config.py`:

```python
import os
import configparser
from .logger import logger

class Config:
    def __init__(self):
        self.config = configparser.ConfigParser()
        self.config_file = os.path.expanduser('~/.taskmaster.ini')
        self.load_config()

    def load_config(self):
        if os.path.exists(self.config_file):
            self.config.read(self.config_file)
            logger.info(f"Configuration loaded from {self.config_file}")
        else:
            self.create_default_config()

    def create_default_config(self):
        self.config['DEFAULT'] = {
            'database_file': 'tasks.json',
            'log_level': 'INFO'
        }
        self.save_config()
        logger.info("Default configuration created")

    def save_config(self):
        with open(self.config_file, 'w') as configfile:
            self.config.write(configfile)
        logger.info(f"Configuration saved to {self.config_file}")

    def get(self, section, key):
        return self.config.get(section, key)

    def set(self, section, key, value):
        if not self.config.has_section(section):
            self.config.add_section(section)
        self.config.set(section, key, value)
        self.save_config()
        logger.info(f"Configuration updated: [{section}] {key} = {value}")

# Global config instance
config = Config()
```

Now, let's update our `cli.py` to use the configuration:

```python
import click
from datetime import datetime
from .task import Task
from .database import TaskDatabase
from .logger import logger
from .config import config

@click.group()
@click.pass_context
def cli(ctx):
    """TaskMaster: A simple CLI task manager."""
    database_file = config.get('DEFAULT', 'database_file')
    ctx.obj = TaskDatabase(database_file)
    logger.info("TaskMaster CLI started")

# ... (other commands remain the same)

@cli.command()
@click.option('--database', help='Set the database file path')
@click.option('--log-level', help='Set the log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)')
def configure(database, log_level):
    """Configure TaskMaster settings."""
    if database:
        config.set('DEFAULT', 'database_file', database)
        click.echo(f"Database file set to: {database}")
    if log_level:
        config.set('DEFAULT', 'log_level', log_level.upper())
        click.echo(f"Log level set to: {log_level.upper()}")
    click.echo("Configuration updated successfully.")

if __name__ == "__main__":
    cli()
```

## 3. Implementing a Plugin System

A plugin system allows users to extend the functionality of our application. We'll implement a simple plugin system using Python's `importlib` module.

Create a new directory `taskmaster/plugins` and an `__init__.py` file inside it:

```
mkdir taskmaster/plugins
touch taskmaster/plugins/__init__.py
```

Now, create a new file `taskmaster/plugin_manager.py`:

```python
import os
import importlib
from .logger import logger

class PluginManager:
    def __init__(self):
        self.plugins = {}
        self.load_plugins()

    def load_plugins(self):
        plugin_dir = os.path.join(os.path.dirname(__file__), 'plugins')
        for filename in os.listdir(plugin_dir):
            if filename.endswith('.py') and not filename.startswith('__'):
                module_name = f"taskmaster.plugins.{filename[:-3]}"
                try:
    
Human: continue









Certainly! I'll continue with the implementation of the plugin system in our TaskMaster CLI tool.

```python
import os
import importlib
from .logger import logger

class PluginManager:
    def __init__(self):
        self.plugins = {}
        self.load_plugins()

    def load_plugins(self):
        plugin_dir = os.path.join(os.path.dirname(__file__), 'plugins')
        for filename in os.listdir(plugin_dir):
            if filename.endswith('.py') and not filename.startswith('__'):
                module_name = f"taskmaster.plugins.{filename[:-3]}"
                try:
                    module = importlib.import_module(module_name)
                    if hasattr(module, 'register_plugin'):
                        plugin_name = filename[:-3]
                        self.plugins[plugin_name] = module.register_plugin()
                        logger.info(f"Loaded plugin: {plugin_name}")
                except Exception as e:
                    logger.error(f"Error loading plugin {filename}: {str(e)}")

    def get_plugin(self, name):
        return self.plugins.get(name)

    def list_plugins(self):
        return list(self.plugins.keys())

# Global plugin manager instance
plugin_manager = PluginManager()
```

Now, let's create a sample plugin. Create a new file `taskmaster/plugins/priority.py`:

```python
from taskmaster.task import Task

def add_priority(task, priority):
    task.priority = priority
    return task

def register_plugin():
    return {
        "name": "priority",
        "description": "Adds priority to tasks",
        "functions": {
            "add_priority": add_priority
        }
    }
```

Let's update our `cli.py` to use the plugin system:

```python
import click
from datetime import datetime
from .task import Task
from .database import TaskDatabase
from .logger import logger
from .config import config
from .plugin_manager import plugin_manager

@click.group()
@click.pass_context
def cli(ctx):
    """TaskMaster: A simple CLI task manager."""
    database_file = config.get('DEFAULT', 'database_file')
    ctx.obj = TaskDatabase(database_file)
    logger.info("TaskMaster CLI started")

@cli.command()
@click.argument("title")
@click.option("-d", "--due", help="Due date (YYYY-MM-DD)")
@click.option("-p", "--priority", type=click.Choice(['low', 'medium', 'high']), help="Task priority")
@click.pass_obj
def add(db, title, due, priority):
    """Add a new task."""
    try:
        due_date = datetime.strptime(due, "%Y-%m-%d") if due else None
        task = Task(title, due_date)
        
        if priority:
            priority_plugin = plugin_manager.get_plugin('priority')
            if priority_plugin:
                task = priority_plugin['functions']['add_priority'](task, priority)
            else:
                logger.warning("Priority plugin not found")
        
        db.add_task(task)
        click.echo(f"Task added: {task}")
        logger.info(f"Task added: {task}")
    except ValueError as e:
        logger.error(f"Error adding task: {str(e)}")
        click.echo(f"Error: {str(e)}")

@cli.command()
def list_plugins():
    """List all available plugins."""
    plugins = plugin_manager.list_plugins()
    if plugins:
        click.echo("Available plugins:")
        for plugin in plugins:
            click.echo(f"- {plugin}")
    else:
        click.echo("No plugins available.")

# ... (other commands remain the same)

if __name__ == "__main__":
    cli()
```

Now, let's update our `task.py` to accommodate the new priority attribute:

```python
from datetime import datetime

class Task:
    def __init__(self, title, due_date=None, completed=False, priority=None):
        self.id = None
        self.title = title
        self.due_date = due_date
        self.completed = completed
        self.created_at = datetime.now()
        self.priority = priority

    def complete(self):
        self.completed = True

    def __str__(self):
        status = "Completed" if self.completed else "Pending"
        due = f", Due: {self.due_date.strftime('%Y-%m-%d')}" if self.due_date else ""
        priority = f", Priority: {self.priority}" if self.priority else ""
        return f"[{self.id}] {self.title} ({status}{due}{priority})"
```

## Cross-platform Considerations

1. **File Paths**: We've used `os.path.join()` and `os.path.expanduser()` to ensure file paths work correctly across different operating systems.

2. **Config File Location**: We've used `~/.taskmaster.ini` as the config file location. On Windows, this will typically resolve to `C:\Users\<username>\.taskmaster.ini`, while on macOS and Linux it will be `/home/<username>/.taskmaster.ini`.

3. **Plugin Loading**: Our plugin system uses dynamic imports, which work consistently across platforms. However, be aware that some plugins might have platform-specific dependencies.

4. **Logging**: We've used a platform-independent approach to setting up log files. The logs will be stored in a `logs` directory within the application directory.

5. **Environment Variables**: If you decide to use environment variables for configuration in the future, remember to use `os.environ.get()` for cross-platform compatibility.

## Testing Our Implementation

Let's test our new features:

```bash
# Configure the application
taskmaster configure --database mydb.json --log-level DEBUG

# Add a task with priority
taskmaster add "High priority task" -p high

# List tasks
taskmaster list

# List available plugins
taskmaster list-plugins
```

## Conclusion

In this lesson, we've added advanced features to our TaskMaster CLI tool:

1. **Logging**: We implemented a robust logging system that writes to both a file and the console, making it easier to debug and monitor our application.

2. **Configuration Management**: We added a configuration system that allows users to customize the behavior of the application, such as specifying the database file and log level.

3. **Plugin System**: We implemented a simple plugin system that allows extending the functionality of our application. We demonstrated this with a priority plugin.

These features make our TaskMaster tool more flexible, maintainable, and extendable. In the next lesson, we'll focus on testing and debugging our CLI tool to ensure its reliability and robustness.

</antArtifact>

Now that we have added advanced features to our TaskMaster CLI tool, let's move on to the fourth bonus lesson where we'll focus on testing and debugging our application.