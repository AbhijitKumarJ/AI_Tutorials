# Lesson 25: Basic Image Handling with Pillow

## Introduction

Welcome to Lesson 25 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore Pillow, a powerful and user-friendly fork of the Python Imaging Library (PIL). Pillow provides a wide range of image processing capabilities, making it an essential tool for developers working with images in Python.

In this lesson, we'll cover:

1. Opening, saving, and converting images
2. Basic image manipulations (resize, rotate, crop)
3. Drawing on images
4. Working with image metadata
5. Using ImageGrab for screenshot capture (platform-specific features)

By the end of this lesson, you'll be comfortable performing basic image operations using Pillow, setting the foundation for more advanced image processing tasks.

## Project Setup

Let's start by setting up our project structure. Create a new directory for this lesson and navigate into it:

```
mkdir lesson_25_pillow
cd lesson_25_pillow
```

Now, let's create our main Python file and a directory for our sample images:

```
touch image_processing.py
mkdir sample_images
```

Your project structure should look like this:

```
lesson_25_pillow/
│
├── image_processing.py
└── sample_images/
```

Before we begin, make sure you have Pillow installed. You can install it using pip:

```
pip install Pillow
```

Now, let's open `image_processing.py` in your favorite text editor and start exploring image handling with Pillow!

## 1. Opening, saving, and converting images

Let's start with the basics of opening, saving, and converting images using Pillow. Add the following code to `image_processing.py`:

```python
from PIL import Image
import os

def open_save_convert(input_path, output_dir):
    # Open an image
    with Image.open(input_path) as img:
        print(f"Original format: {img.format}")
        print(f"Size: {img.size}")
        print(f"Mode: {img.mode}")

        # Save as PNG
        png_path = os.path.join(output_dir, "converted_image.png")
        img.save(png_path, "PNG")
        print(f"Saved as PNG: {png_path}")

        # Convert to grayscale and save as JPEG
        grayscale_img = img.convert("L")
        jpeg_path = os.path.join(output_dir, "grayscale_image.jpg")
        grayscale_img.save(jpeg_path, "JPEG")
        print(f"Saved as grayscale JPEG: {jpeg_path}")

# Example usage
input_image = "sample_images/example.jpg"  # Make sure to add an image to this directory
output_dir = "sample_images"

open_save_convert(input_image, output_dir)
```

This code demonstrates how to open an image, display its properties, save it in a different format, and convert it to grayscale. Make sure to add a sample image (e.g., "example.jpg") to your `sample_images` directory before running the script.

## 2. Basic image manipulations (resize, rotate, crop)

Now let's explore some basic image manipulations like resizing, rotating, and cropping. Add the following code to `image_processing.py`:

```python
def basic_manipulations(input_path, output_dir):
    with Image.open(input_path) as img:
        # Resize
        resized_img = img.resize((300, 200))
        resized_path = os.path.join(output_dir, "resized_image.jpg")
        resized_img.save(resized_path)
        print(f"Saved resized image: {resized_path}")

        # Rotate
        rotated_img = img.rotate(45)
        rotated_path = os.path.join(output_dir, "rotated_image.jpg")
        rotated_img.save(rotated_path)
        print(f"Saved rotated image: {rotated_path}")

        # Crop
        width, height = img.size
        left = width // 4
        top = height // 4
        right = 3 * width // 4
        bottom = 3 * height // 4
        cropped_img = img.crop((left, top, right, bottom))
        cropped_path = os.path.join(output_dir, "cropped_image.jpg")
        cropped_img.save(cropped_path)
        print(f"Saved cropped image: {cropped_path}")

# Example usage
basic_manipulations(input_image, output_dir)
```

This code shows how to resize an image to a specific size, rotate it by 45 degrees, and crop it to the center quarter of the original image.

## 3. Drawing on images

Pillow also allows you to draw shapes, lines, and text on images. Let's create a function to demonstrate these capabilities. Add the following code to `image_processing.py`:

```python
from PIL import Image, ImageDraw, ImageFont

def draw_on_image(output_dir):
    # Create a blank image
    img = Image.new('RGB', (400, 300), color='white')
    draw = ImageDraw.Draw(img)

    # Draw a rectangle
    draw.rectangle([50, 50, 350, 250], outline='red', width=2)

    # Draw a line
    draw.line([100, 100, 300, 200], fill='blue', width=3)

    # Draw a circle
    draw.ellipse([150, 100, 250, 200], outline='green', width=2)

    # Add text
    try:
        font = ImageFont.truetype("arial.ttf", 24)
    except IOError:
        font = ImageFont.load_default()

    draw.text((100, 50), "Hello, Pillow!", fill='black', font=font)

    # Save the image
    drawing_path = os.path.join(output_dir, "drawing.png")
    img.save(drawing_path)
    print(f"Saved drawing: {drawing_path}")

# Example usage
draw_on_image(output_dir)
```

This function creates a new image and demonstrates drawing various shapes and text on it. Note that we use a try-except block when loading the font to handle cases where the specified font might not be available on the system.

## 4. Working with image metadata

Images often contain metadata (EXIF data for photos) that can provide valuable information. Let's create a function to read and display this metadata. Add the following code to `image_processing.py`:

```python
def display_image_metadata(input_path):
    with Image.open(input_path) as img:
        # Print basic image info
        print(f"Format: {img.format}")
        print(f"Size: {img.size}")
        print(f"Mode: {img.mode}")

        # Print EXIF data if available
        exif_data = img._getexif()
        if exif_data:
            print("\nEXIF Data:")
            for tag_id, value in exif_data.items():
                tag = TAGS.get(tag_id, tag_id)
                print(f"{tag}: {value}")
        else:
            print("\nNo EXIF data found.")

# Example usage
display_image_metadata(input_image)
```

This function displays basic image information and any available EXIF data. Note that not all image formats support EXIF data, and some images may not have this information.

## 5. Using ImageGrab for screenshot capture (platform-specific features)

Pillow's ImageGrab module provides platform-specific functionality for capturing screenshots. Let's create a function to demonstrate this feature, with considerations for different operating systems. Add the following code to `image_processing.py`:

```python
import sys
from PIL import ImageGrab

def capture_screenshot(output_dir):
    if sys.platform.startswith('win'):
        # Windows
        screenshot = ImageGrab.grab()
    elif sys.platform == 'darwin':
        # macOS
        screenshot = ImageGrab.grab()
    else:
        # Linux and other platforms
        print("Screenshot capture is not supported on this platform.")
        return

    screenshot_path = os.path.join(output_dir, "screenshot.png")
    screenshot.save(screenshot_path)
    print(f"Saved screenshot: {screenshot_path}")

# Example usage
capture_screenshot(output_dir)
```

This function uses ImageGrab to capture a screenshot on Windows and macOS. Note that ImageGrab is not available on Linux by default, so we provide a message for unsupported platforms.

## Cross-platform Considerations

When working with Pillow across different platforms (Windows, macOS, and Linux), keep the following points in mind:

1. Font availability: Different systems have different fonts installed. Always provide a fallback option when specifying fonts.

2. File paths: Use `os.path.join()` for constructing file paths to ensure compatibility across platforms.

3. ImageGrab: As demonstrated in the screenshot function, ImageGrab functionality varies across platforms. Always check the platform and provide appropriate alternatives or error messages.

4. Image formats: While Pillow supports a wide range of formats, some may require additional libraries on certain platforms. Always check Pillow's documentation for platform-specific requirements.

5. Performance: Image processing can be resource-intensive. Be mindful of memory usage, especially when working with large images on systems with limited resources.

## Conclusion

In this lesson, we've explored the basics of image handling with Pillow, covering:

1. Opening, saving, and converting images
2. Basic image manipulations (resize, rotate, crop)
3. Drawing on images
4. Working with image metadata
5. Using ImageGrab for screenshot capture (platform-specific features)

These skills form the foundation for more advanced image processing tasks and can be applied in various applications, from web development to data analysis and computer vision projects.

To practice what you've learned, try the following exercises:

1. Create a script that batch processes a directory of images, resizing them all to a specific dimension while maintaining their aspect ratios.

2. Build a simple image watermarking tool that adds text or a logo to the corner of an image.

3. Implement a function that creates a photo collage from multiple images, arranging them in a grid layout.

4. Develop a script that extracts and analyzes color information from an image, displaying the most common colors used.

5. Create a tool that adds filters to images (e.g., increasing brightness, applying sepia tone, or creating a vignette effect).

By mastering these Pillow basics, you'll be well-equipped to handle a wide range of image processing tasks in your Python projects, from simple resizing operations to more complex image analysis and manipulation.

