# Lesson 15: Time Operations and Measurements

## Introduction

Welcome to Lesson 15 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll dive into time operations and measurements using Python's built-in modules and some additional libraries. We'll explore working with timestamps, handling time zones, parsing and formatting time strings, measuring code execution time, and implementing sleep and delays. These skills are crucial for various applications, from data processing to creating time-sensitive applications.

## Setting Up

Let's set up our project structure:

```
time_operations_project/
├── venv/
├── time_ops.py
└── requirements.txt
```

1. Create a new directory for our project:
   ```
   mkdir time_operations_project
   cd time_operations_project
   ```

2. Create and activate a virtual environment:
   - On Windows:
     ```
     python -m venv venv
     venv\Scripts\activate
     ```
   - On macOS/Linux:
     ```
     python3 -m venv venv
     source venv/bin/activate
     ```

3. Install required packages:
   ```
   pip install pytz python-dateutil
   ```

4. Create a `requirements.txt` file:
   ```
   pip freeze > requirements.txt
   ```

Now, let's create our `time_ops.py` file and start exploring time operations and measurements!

## Working with Timestamps and Time Zones

Let's start by working with timestamps and time zones using the `datetime` module and `pytz`:

```python
from datetime import datetime, timedelta
import pytz

def demonstrate_timestamps_and_timezones():
    # Current time in UTC
    utc_now = datetime.now(pytz.UTC)
    print(f"Current UTC time: {utc_now}")

    # Convert to a specific time zone
    ny_tz = pytz.timezone('America/New_York')
    ny_time = utc_now.astimezone(ny_tz)
    print(f"Current time in New York: {ny_time}")

    # Create a specific datetime in a time zone
    specific_time = datetime(2023, 6, 15, 14, 30, tzinfo=pytz.UTC)
    print(f"Specific time in UTC: {specific_time}")

    # Convert specific time to another time zone
    tokyo_tz = pytz.timezone('Asia/Tokyo')
    tokyo_time = specific_time.astimezone(tokyo_tz)
    print(f"Specific time in Tokyo: {tokyo_time}")

    # Time arithmetic
    one_day_later = specific_time + timedelta(days=1)
    print(f"One day after specific time: {one_day_later}")

    # Time comparison
    if ny_time > tokyo_time:
        print("It's later in New York than in Tokyo")
    else:
        print("It's earlier in New York than in Tokyo")

if __name__ == "__main__":
    demonstrate_timestamps_and_timezones()
```

This function demonstrates how to work with timestamps, convert between time zones, perform time arithmetic, and compare times.

## Parsing and Formatting Time Strings

Now let's look at parsing and formatting time strings using `datetime` and `dateutil`:

```python
from datetime import datetime
from dateutil import parser

def parse_and_format_times():
    # Parsing time strings
    time_string = "2023-06-15 14:30:00"
    parsed_time = datetime.strptime(time_string, "%Y-%m-%d %H:%M:%S")
    print(f"Parsed time: {parsed_time}")

    # Parsing with dateutil (more flexible)
    flexible_string = "Jun 15, 2023 at 2:30 PM"
    flexible_parsed = parser.parse(flexible_string)
    print(f"Flexibly parsed time: {flexible_parsed}")

    # Formatting time to string
    formatted_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"Formatted current time: {formatted_time}")

    # ISO format
    iso_formatted = datetime.now().isoformat()
    print(f"ISO formatted current time: {iso_formatted}")

    # Custom format
    custom_format = datetime.now().strftime("%B %d, %Y at %I:%M %p")
    print(f"Custom formatted current time: {custom_format}")

if __name__ == "__main__":
    parse_and_format_times()
```

This function shows how to parse time strings into datetime objects and format datetime objects into strings.

## Measuring Code Execution Time

Measuring code execution time is crucial for performance optimization. Let's explore different ways to do this:

```python
import time
from timeit import default_timer as timer
from contextlib import contextmanager

def slow_function():
    """A function that takes some time to execute."""
    time.sleep(2)

@contextmanager
def measure_time():
    start_time = timer()
    yield
    elapsed_time = timer() - start_time
    print(f"Elapsed time: {elapsed_time:.4f} seconds")

def measure_execution_time():
    # Using time.time()
    start = time.time()
    slow_function()
    end = time.time()
    print(f"Execution time (time.time): {end - start:.4f} seconds")

    # Using timeit
    timeit_time = timer()
    slow_function()
    print(f"Execution time (timeit): {timer() - timeit_time:.4f} seconds")

    # Using context manager
    with measure_time():
        slow_function()

    # Measuring multiple iterations
    iterations = 5
    total_time = sum(timer() for _ in range(iterations))
    average_time = total_time / iterations
    print(f"Average execution time over {iterations} iterations: {average_time:.4f} seconds")

if __name__ == "__main__":
    measure_execution_time()
```

This function demonstrates different methods to measure code execution time, including using `time.time()`, `timeit`, a custom context manager, and measuring multiple iterations.

## Sleep and Delays

Implementing sleep and delays is often necessary in time-sensitive applications. Let's explore different ways to do this:

```python
import time
import asyncio

def demonstrate_sleep_and_delays():
    print("Demonstrating time.sleep():")
    for i in range(3):
        print(f"Iteration {i + 1}")
        time.sleep(1)

    print("\nDemonstrating asyncio.sleep():")
    async def async_sleep_demo():
        for i in range(3):
            print(f"Async iteration {i + 1}")
            await asyncio.sleep(1)

    asyncio.run(async_sleep_demo())

if __name__ == "__main__":
    demonstrate_sleep_and_delays()
```

This function shows how to use `time.sleep()` for synchronous delays and `asyncio.sleep()` for asynchronous delays.

## Time-related Challenges in Cross-platform Development

When developing cross-platform applications, it's important to be aware of time-related challenges. Here are some considerations:

```python
import platform
import time

def demonstrate_cross_platform_time_challenges():
    print(f"Operating System: {platform.system()}")

    # Epoch time (differs between Unix and Windows)
    print(f"Epoch time: {time.time()}")

    # Time resolution
    print(f"Time resolution: {time.get_clock_info('time').resolution}")

    # Daylight Saving Time handling
    local_time = time.localtime()
    print(f"Is DST in effect: {local_time.tm_isdst}")

    # Monotonic time (for measuring intervals)
    start = time.monotonic()
    time.sleep(1)
    end = time.monotonic()
    print(f"Monotonic time difference: {end - start}")

    # High-resolution time
    start = time.perf_counter()
    time.sleep(1)
    end = time.perf_counter()
    print(f"High-resolution time difference: {end - start}")

if __name__ == "__main__":
    demonstrate_cross_platform_time_challenges()
```

This function demonstrates various time-related challenges and considerations when developing cross-platform applications, such as epoch time differences, time resolution, DST handling, and using monotonic time for accurate interval measurements.

## Conclusion

In this lesson, we've explored time operations and measurements in Python. We've covered:

1. Working with timestamps and time zones
2. Parsing and formatting time strings
3. Measuring code execution time
4. Implementing sleep and delays
5. Handling time-related challenges in cross-platform development

These techniques are essential for various applications, from data processing and scheduling tasks to creating time-sensitive applications and optimizing code performance.

## Exercises

To reinforce your learning, try these exercises:

1. Create a function that takes two datetime objects and calculates the time difference in days, hours, minutes, and seconds, accounting for different time zones.

2. Implement a simple scheduler that executes different functions at specified times or intervals.

3. Write a program that measures the execution time of sorting algorithms (e.g., bubble sort, quicksort) for different input sizes and compares their performance.

4. Create a time conversion tool that converts a given time between different time zones, accounting for daylight saving time.

5. Implement a countdown timer that uses asyncio to allow for concurrent execution of other tasks while counting down.

Remember, practice is key to mastering these concepts. Happy coding!

