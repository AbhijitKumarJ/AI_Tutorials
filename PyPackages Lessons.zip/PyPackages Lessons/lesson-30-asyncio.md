# Lesson 30: Asynchronous Programming Basics

## Introduction

Welcome to Lesson 30 of our "Mastering Python Packages for Efficient Programming" series! Today, we're diving into asynchronous programming using Python's `asyncio` module. By the end of this lesson, you'll understand the basics of asynchronous programming, how to write asynchronous functions, and how to use coroutines and tasks to build efficient, concurrent programs.

## What is Asynchronous Programming?

Before we jump into `asyncio`, let's understand what asynchronous programming is:

- Asynchronous programming is a programming paradigm that allows multiple operations to be executed concurrently without blocking the main program flow.
- It's particularly useful for I/O-bound operations, such as network requests or file operations, where the program spends a lot of time waiting for external resources.
- In asynchronous programming, when a task is waiting for I/O, it can yield control to other tasks, allowing them to run in the meantime.

Key concepts in asynchronous programming include:
- Coroutines: Functions that can be paused and resumed
- Event Loop: The core of async programming, responsible for executing and managing coroutines
- Tasks: Wrappers around coroutines that allow them to be scheduled and run concurrently

## Getting Started with asyncio

The `asyncio` module provides a framework for writing asynchronous code using coroutines, event loops, and tasks. Let's start by importing it:

```python
import asyncio
```

Now, let's explore the main components of asyncio:

1. Writing coroutines with `async` and `await`
2. Running coroutines with the event loop
3. Creating and managing tasks
4. Using asyncio for concurrent operations
5. Asynchronous context managers and iterators

## 1. Writing Coroutines with `async` and `await`

Coroutines are the building blocks of asynchronous programming in Python. They are defined using the `async def` syntax and can use the `await` keyword to pause execution and wait for other coroutines.

Here's a simple example:

```python
import asyncio

async def greet(name):
    print(f"Hello, {name}!")
    await asyncio.sleep(1)  # Simulate some asynchronous operation
    print(f"Goodbye, {name}!")

async def main():
    await greet("Alice")
    await greet("Bob")

asyncio.run(main())
```

Output:
```
Hello, Alice!
Goodbye, Alice!
Hello, Bob!
Goodbye, Bob!
```

In this example:
1. We define two coroutines: `greet` and `main`.
2. The `greet` coroutine uses `await asyncio.sleep(1)` to simulate an asynchronous operation.
3. The `main` coroutine calls `greet` twice using `await`.
4. We use `asyncio.run()` to run the `main` coroutine, which sets up the event loop and runs the coroutine to completion.

## 2. Running Coroutines with the Event Loop

The event loop is the core of asyncio. It runs asynchronous tasks and callbacks, performs network IO operations, and runs subprocesses. Here's how to work with the event loop explicitly:

```python
import asyncio

async def hello_world():
    print("Hello, World!")
    await asyncio.sleep(1)
    print("Goodbye, World!")

# Get the event loop
loop = asyncio.get_event_loop()

# Run the coroutine until it completes
loop.run_until_complete(hello_world())

# Close the loop
loop.close()
```

However, in most cases, you can simply use `asyncio.run()` as we did in the previous example, which handles the event loop for you.

## 3. Creating and Managing Tasks

Tasks are used to schedule coroutines concurrently. They are wrappers around coroutines and are used to manage their execution.

```python
import asyncio

async def task_function(task_no):
    print(f"Task {task_no} starting")
    await asyncio.sleep(1)
    print(f"Task {task_no} finished")

async def main():
    # Create tasks
    task1 = asyncio.create_task(task_function(1))
    task2 = asyncio.create_task(task_function(2))
    
    # Wait for both tasks to complete
    await task1
    await task2

asyncio.run(main())
```

Output:
```
Task 1 starting
Task 2 starting
Task 1 finished
Task 2 finished
```

In this example, both tasks start concurrently, sleep for 1 second, and then finish.

## 4. Using asyncio for Concurrent Operations

One of the main benefits of asyncio is the ability to perform concurrent operations efficiently. Here's an example that demonstrates concurrent network requests:

```python
import asyncio
import aiohttp
import time

async def fetch_url(url):
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()

async def main():
    urls = [
        "http://example.com",
        "http://example.org",
        "http://example.net"
    ]
    
    tasks = [asyncio.create_task(fetch_url(url)) for url in urls]
    results = await asyncio.gather(*tasks)
    
    for url, result in zip(urls, results):
        print(f"Content length of {url}: {len(result)} characters")

start_time = time.time()
asyncio.run(main())
print(f"Total time: {time.time() - start_time:.2f} seconds")
```

This example uses `aiohttp`, an asynchronous HTTP client, to fetch multiple URLs concurrently. Note that you'll need to install `aiohttp` using pip: `pip install aiohttp`.

## 5. Asynchronous Context Managers and Iterators

Asyncio also supports asynchronous context managers and iterators:

### Asynchronous Context Managers

```python
import asyncio

class AsyncContextManager:
    async def __aenter__(self):
        print("Entering the context")
        await asyncio.sleep(1)
        return self

    async def __aexit__(self, exc_type, exc_value, traceback):
        print("Exiting the context")
        await asyncio.sleep(1)

async def main():
    async with AsyncContextManager() as manager:
        print("Inside the context")

asyncio.run(main())
```

### Asynchronous Iterators

```python
import asyncio

class AsyncIterator:
    def __init__(self, start, end):
        self.current = start
        self.end = end

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self.current < self.end:
            await asyncio.sleep(0.5)
            result = self.current
            self.current += 1
            return result
        else:
            raise StopAsyncIteration

async def main():
    async for i in AsyncIterator(1, 5):
        print(i)

asyncio.run(main())
```

## Practical Example: Asynchronous Web Scraper

Let's create a practical example that demonstrates how `asyncio` can be used for efficient web scraping. We'll create a simple tool that scrapes titles from multiple web pages concurrently.

First, let's set up our project structure:

```
asyncio_example/
│
├── websites.txt
├── async_scraper.py
└── main.py
```

Now, let's create a file with some websites to scrape:

`websites.txt`:
```
https://www.python.org
https://www.github.com
https://www.stackoverflow.com
https://www.reddit.com
https://www.wikipedia.org
```

Now, let's create our `async_scraper.py`:

```python
import asyncio
import aiohttp
from bs4 import BeautifulSoup

async def fetch_url(session, url):
    async with session.get(url) as response:
        return await response.text()

async def get_title(session, url):
    try:
        html = await fetch_url(session, url)
        soup = BeautifulSoup(html, 'html.parser')
        return url, soup.title.string.strip() if soup.title else "No title found"
    except Exception as e:
        return url, f"Error: {str(e)}"

async def scrape_websites(websites):
    async with aiohttp.ClientSession() as session:
        tasks = [asyncio.create_task(get_title(session, website)) for website in websites]
        results = await asyncio.gather(*tasks)
    return results

def load_websites(filename):
    with open(filename, 'r') as f:
        return [line.strip() for line in f if line.strip()]

```

Now, let's create our `main.py`:

```python
import asyncio
import time
from async_scraper import scrape_websites, load_websites

async def main():
    websites = load_websites('websites.txt')
    
    print("Starting web scraping...")
    start_time = time.time()
    
    results = await scrape_websites(websites)
    
    print("\nScraping results:")
    for url, title in results:
        print(f"{url}: {title}")
    
    print(f"\nTotal time: {time.time() - start_time:.2f} seconds")

if __name__ == "__main__":
    asyncio.run(main())
```

To run the example, first install the required packages:

```
pip install aiohttp beautifulsoup4
```

Then execute `main.py`:

```
python main.py
```

This example demonstrates several `asyncio` concepts:

1. We use `aiohttp` for asynchronous HTTP requests.
2. We create multiple tasks to scrape websites concurrently.
3. We use `asyncio.gather()` to wait for all tasks to complete.
4. We use asynchronous context managers (`async with`) for managing sessions and connections.

## Cross-platform Considerations

The `asyncio` module is part of Python's standard library and works across Windows, macOS, and Linux. However, there are a few things to keep in mind:

1. **Event loop implementation**: On Windows, the default event loop uses the ProactorEventLoop, while on Unix systems it uses the SelectorEventLoop. This can sometimes lead to subtle differences in behavior.

2. **Performance**: The performance of asyncio can vary across different operating systems due to differences in the underlying I/O multiplexing mechanisms (e.g., epoll on Linux, kqueue on macOS, IOCP on Windows).

3. **Subprocess handling**: Asyncio's subprocess support works differently on Windows compared to Unix systems. On Windows, it uses the Proactor event loop, which has some limitations.

4. **File I/O**: Asynchronous file I/O is not uniformly supported across all platforms. It's generally better to use a thread pool for file operations to ensure consistent behavior.

## Best Practices and Pitfalls

When working with asyncio, keep these best practices and common pitfalls in mind:

1. **Don't block the event loop**: Avoid using blocking I/O or CPU-bound operations in coroutines. If you need to perform such operations, use `asyncio.to_thread()` or a thread pool.

2. **Use `asyncio.create_task()` for concurrency**: When you want to run multiple coroutines concurrently, create tasks for them.

3. **Be careful with shared state**: When multiple coroutines access shared state, use synchronization primitives like `asyncio.Lock()` to prevent race conditions.

4. **Handle exceptions properly**: Use try/except blocks in your coroutines to handle exceptions, or they may be lost.

5. **Don't mix asyncio with threading or multiprocessing** without careful consideration. If you need to use them together, use appropriate synchronization mechanisms.

6. **Be aware of the "async all the way" principle**: Once you start using async functions, you generally need to use async all the way up the call stack.

## Conclusion

In this lesson, we've explored the basics of asynchronous programming with Python's `asyncio` module. We've seen how to write coroutines, run them with the event loop, create and manage tasks, and use asyncio for concurrent operations. We've also applied these concepts to a practical web scraping example.

Asynchronous programming can significantly improve the performance of I/O-bound applications, making it a valuable tool in a Python developer's toolkit. As you continue to work with network programming, web scraping, or any I/O-heavy tasks, you'll find many opportunities to apply these techniques to improve your code's efficiency and responsiveness.

## Exercises

To reinforce your understanding, try these exercises:

1. Modify the web scraper to also extract and print the first paragraph (`<p>` tag) from each website.
2. Create an asynchronous file reader that can read multiple files concurrently and count the number of lines in each.
3. Implement a simple asynchronous chat server and client using asyncio's networking capabilities.

Remember, asynchronous programming can be tricky to grasp at first. Practice and experimentation are key to mastering these concepts. Keep coding, and don't hesitate to refer back to this lesson and the Python documentation as you explore more advanced asyncio features!

