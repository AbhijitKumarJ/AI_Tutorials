# Lesson 13: Clipboard Operations with pyperclip

## Introduction

Welcome to Lesson 13 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore clipboard operations using the `pyperclip` module. Clipboard functionality is crucial for many applications, allowing easy transfer of data between programs. We'll learn how to read from and write to the clipboard, handle different data types, and discuss cross-platform considerations.

## Setting Up

Let's set up our project structure:

```
clipboard_operations_project/
├── venv/
├── clipboard_ops.py
└── requirements.txt
```

1. Create a new directory for our project:
   ```
   mkdir clipboard_operations_project
   cd clipboard_operations_project
   ```

2. Create and activate a virtual environment:
   - On Windows:
     ```
     python -m venv venv
     venv\Scripts\activate
     ```
   - On macOS/Linux:
     ```
     python3 -m venv venv
     source venv/bin/activate
     ```

3. Install pyperclip:
   ```
   pip install pyperclip
   ```

4. Create a `requirements.txt` file:
   ```
   pip freeze > requirements.txt
   ```

Now, let's create our `clipboard_ops.py` file and start exploring clipboard operations with pyperclip!

## Basic Clipboard Operations

Let's start with basic reading from and writing to the clipboard:

```python
import pyperclip

def basic_clipboard_operations():
    # Writing to clipboard
    pyperclip.copy("Hello, Clipboard!")
    print("Text 'Hello, Clipboard!' has been copied to clipboard.")

    # Reading from clipboard
    clipboard_content = pyperclip.paste()
    print(f"Current clipboard content: '{clipboard_content}'")

    # Clearing the clipboard (by copying an empty string)
    pyperclip.copy('')
    print("Clipboard has been cleared.")

    # Verifying the clipboard is empty
    clipboard_content = pyperclip.paste()
    print(f"Clipboard content after clearing: '{clipboard_content}'")

if __name__ == "__main__":
    basic_clipboard_operations()
```

This function demonstrates how to write to the clipboard, read from it, and clear its contents. Run it to see the output:

```
python clipboard_ops.py
```

## Handling Different Data Types

While the clipboard primarily deals with text, we can handle different data types by converting them to and from strings:

```python
import json

def handle_different_data_types():
    # Copying a list
    my_list = [1, 2, 3, 4, 5]
    pyperclip.copy(json.dumps(my_list))
    print(f"Copied list: {my_list}")

    # Reading the list back
    clipboard_content = pyperclip.paste()
    recovered_list = json.loads(clipboard_content)
    print(f"Recovered list: {recovered_list}")

    # Copying a dictionary
    my_dict = {"name": "John", "age": 30, "city": "New York"}
    pyperclip.copy(json.dumps(my_dict))
    print(f"Copied dictionary: {my_dict}")

    # Reading the dictionary back
    clipboard_content = pyperclip.paste()
    recovered_dict = json.loads(clipboard_content)
    print(f"Recovered dictionary: {recovered_dict}")

if __name__ == "__main__":
    handle_different_data_types()
```

This function shows how to copy and paste complex data types like lists and dictionaries using JSON serialization.

## Clipboard Monitoring

While pyperclip doesn't directly support clipboard change events, we can simulate monitoring by periodically checking the clipboard contents:

```python
import time

def monitor_clipboard(duration=10, interval=1):
    print(f"Monitoring clipboard for {duration} seconds...")
    end_time = time.time() + duration
    last_content = pyperclip.paste()

    while time.time() < end_time:
        current_content = pyperclip.paste()
        if current_content != last_content:
            print(f"Clipboard content changed: '{current_content}'")
            last_content = current_content
        time.sleep(interval)

    print("Clipboard monitoring ended.")

if __name__ == "__main__":
    monitor_clipboard()
```

This function monitors the clipboard for changes over a specified duration, checking at regular intervals.

## Cross-platform Considerations

Pyperclip aims to work across different platforms (Windows, macOS, Linux) seamlessly, but there are some considerations:

1. On Linux, pyperclip requires a copy/paste mechanism to be installed. Common options include:
   - `xclip` (for X11-based systems)
   - `xsel` (for X11-based systems)
   - `wl-clipboard` (for Wayland-based systems)

2. On macOS and Windows, pyperclip should work out of the box.

Let's create a function to check if pyperclip is working correctly on the current system:

```python
import sys

def check_pyperclip_availability():
    try:
        pyperclip.copy("test")
        content = pyperclip.paste()
        if content == "test":
            print("Pyperclip is working correctly on this system.")
        else:
            print("Pyperclip copy/paste operations are not working as expected.")
    except pyperclip.PyperclipException as e:
        print(f"Pyperclip encountered an error: {e}")
        if sys.platform.startswith('linux'):
            print("On Linux, make sure xclip, xsel, or wl-clipboard is installed.")
        elif sys.platform == 'darwin':
            print("On macOS, pyperclip should work out of the box. Please check your permissions.")
        elif sys.platform == 'win32':
            print("On Windows, pyperclip should work out of the box. Please check your permissions.")

if __name__ == "__main__":
    check_pyperclip_availability()
```

This function tests pyperclip's functionality and provides platform-specific advice if it's not working.

## Handling Large Amounts of Data

When dealing with large amounts of data, it's important to be mindful of memory usage and potential limitations of the clipboard. Here's an example of how to handle larger data incrementally:

```python
def handle_large_data(data, chunk_size=1000):
    total_size = len(data)
    for i in range(0, total_size, chunk_size):
        chunk = data[i:i+chunk_size]
        pyperclip.copy(chunk)
        print(f"Copied chunk {i//chunk_size + 1} to clipboard. Please paste it and press Enter.")
        input()  # Wait for user to paste the data

    print("All data has been processed.")

if __name__ == "__main__":
    large_data = "This is a long string. " * 1000
    handle_large_data(large_data)
```

This function demonstrates how to copy large amounts of data in chunks, allowing the user to paste each chunk before proceeding.

## Clipboard Security Considerations

When working with clipboard data, it's important to consider security implications:

```python
import re

def sanitize_clipboard_content(max_length=1000):
    content = pyperclip.paste()
    
    # Truncate if too long
    if len(content) > max_length:
        content = content[:max_length] + "... (truncated)"
    
    # Remove any potential HTML or script tags
    content = re.sub(r'<[^>]*>', '', content)
    
    # Remove any non-printable characters
    content = ''.join(char for char in content if char.isprintable())
    
    return content

def secure_clipboard_operation():
    print("Please copy some content to the clipboard.")
    input("Press Enter when ready...")
    
    sanitized_content = sanitize_clipboard_content()
    print(f"Sanitized clipboard content: {sanitized_content}")

if __name__ == "__main__":
    secure_clipboard_operation()
```

This example shows how to sanitize clipboard content by truncating long data, removing HTML tags, and filtering out non-printable characters.

## Conclusion

In this lesson, we've explored clipboard operations using the pyperclip module. We've covered:

1. Basic clipboard reading and writing
2. Handling different data types in the clipboard
3. Simulating clipboard monitoring
4. Cross-platform considerations
5. Handling large amounts of data
6. Security considerations when working with clipboard content

These techniques will help you integrate clipboard functionality into your Python projects efficiently and securely, regardless of the operating system you're using.

## Exercises

To reinforce your learning, try these exercises:

1. Create a simple password manager that stores encrypted passwords in a file and copies them to the clipboard when needed.
2. Implement a "clipboard history" feature that keeps track of the last 5 items copied to the clipboard.
3. Write a program that monitors the clipboard for URLs and automatically downloads the content of those URLs.
4. Create a tool that formats and prettifies code snippets copied to the clipboard (e.g., adding syntax highlighting for Python code).
5. Implement a secure note-taking application that uses the clipboard for transferring encrypted notes between the application and other text editors.

Remember, practice is key to mastering these concepts. Happy coding!

