# Lesson 31: Web Scraping and Document Conversion

## Introduction

Welcome to Lesson 31 of our "Mastering Python Packages for Efficient Programming" series! Today, we're diving into web scraping and document conversion. We'll explore how to extract data from websites using Python libraries and how to convert between different document formats. By the end of this lesson, you'll be able to scrape web content and convert documents between various formats.

## Part 1: Web Scraping with requests and BeautifulSoup

Web scraping is the process of automatically extracting data from websites. It's a powerful technique for gathering information, but it's important to use it responsibly and ethically.

### Getting Started with Web Scraping

For web scraping, we'll use two main libraries:
1. `requests`: For making HTTP requests to web pages
2. `BeautifulSoup`: For parsing HTML and extracting data

First, let's install these libraries:

```
pip install requests beautifulsoup4
```

Now, let's start with a simple example:

```python
import requests
from bs4 import BeautifulSoup

# Make a request to a web page
url = "https://quotes.toscrape.com/"
response = requests.get(url)

# Parse the HTML content
soup = BeautifulSoup(response.text, 'html.parser')

# Extract all quotes
quotes = soup.find_all('span', class_='text')

# Print the first 5 quotes
for quote in quotes[:5]:
    print(quote.text)
```

This script does the following:
1. Sends a GET request to the website
2. Parses the HTML content using BeautifulSoup
3. Finds all `<span>` elements with class 'text' (which contain the quotes)
4. Prints the first 5 quotes

### Advanced Web Scraping Techniques

Let's expand our scraping to include more information and handle multiple pages:

```python
import requests
from bs4 import BeautifulSoup

def scrape_quotes(url):
    quotes_data = []
    while url:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        for quote in soup.find_all('div', class_='quote'):
            text = quote.find('span', class_='text').text
            author = quote.find('small', class_='author').text
            tags = [tag.text for tag in quote.find_all('a', class_='tag')]
            quotes_data.append({'text': text, 'author': author, 'tags': tags})
        
        next_button = soup.find('li', class_='next')
        url = 'https://quotes.toscrape.com' + next_button.find('a')['href'] if next_button else None
    
    return quotes_data

# Scrape all quotes from all pages
all_quotes = scrape_quotes('https://quotes.toscrape.com')

# Print the first 3 quotes
for quote in all_quotes[:3]:
    print(f"Quote: {quote['text']}")
    print(f"Author: {quote['author']}")
    print(f"Tags: {', '.join(quote['tags'])}")
    print()
```

This script introduces several advanced concepts:
1. Pagination handling: It follows the 'Next' button to scrape multiple pages
2. Structured data extraction: It extracts not just the quote, but also the author and tags
3. Use of a function for modular design

### Handling Dynamic Websites

Some websites load content dynamically using JavaScript. For these, you might need to use a tool like Selenium, which can interact with a real browser. Here's a simple example:

```python
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time

# Set up the driver
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)

# Navigate to a dynamic website
driver.get("https://www.example.com")  # Replace with a dynamic website

# Wait for the content to load
time.sleep(5)

# Find elements and extract data
elements = driver.find_elements(By.CLASS_NAME, "example-class")
for element in elements:
    print(element.text)

# Close the browser
driver.quit()
```

Note: You'll need to install Selenium and webdriver-manager:
```
pip install selenium webdriver-manager
```

## Part 2: Document Conversion with pypandoc

Pypandoc is a Python wrapper for Pandoc, a universal document converter. It can convert between numerous markup and document formats.

### Installing pypandoc and Pandoc

First, install pypandoc:

```
pip install pypandoc
```

You also need to install Pandoc on your system. The installation process varies by operating system:

- On Windows: Download and run the installer from the [Pandoc website](https://pandoc.org/installing.html)
- On macOS with Homebrew: `brew install pandoc`
- On Ubuntu or Debian: `sudo apt-get install pandoc`

### Basic Document Conversion

Let's start with a simple conversion from Markdown to HTML:

```python
import pypandoc

# Convert Markdown to HTML
markdown_text = """
# Hello, Pandoc!

This is a simple Markdown document.

- Item 1
- Item 2
- Item 3
"""

html = pypandoc.convert_text(markdown_text, 'html', format='md')
print(html)
```

This script converts a Markdown string to HTML. You can also convert between file formats:

```python
import pypandoc

# Convert a Markdown file to PDF
pypandoc.convert_file('input.md', 'pdf', outputfile='output.pdf')

# Convert a Word document to Markdown
pypandoc.convert_file('input.docx', 'md', outputfile='output.md')
```

### Advanced Document Conversion

Pypandoc supports many conversion options. Here's an example that converts a Markdown file to a styled HTML file:

```python
import pypandoc

# Read the Markdown content
with open('input.md', 'r') as file:
    markdown_content = file.read()

# Convert Markdown to HTML with a table of contents and syntax highlighting
html = pypandoc.convert_text(
    markdown_content,
    'html',
    format='md',
    extra_args=[
        '--standalone',
        '--table-of-contents',
        '--toc-depth=2',
        '--highlight-style=pygments',
        '--css=style.css'
    ]
)

# Write the HTML to a file
with open('output.html', 'w') as file:
    file.write(html)
```

This script:
1. Reads a Markdown file
2. Converts it to a standalone HTML file
3. Adds a table of contents
4. Applies syntax highlighting
5. Links a CSS file for styling

Note: You'll need to create a `style.css` file in the same directory for the styling to take effect.

## Practical Example: Web Content Extractor and Converter

Let's create a practical example that combines web scraping and document conversion. We'll create a tool that extracts content from a web page and converts it to various formats.

First, let's set up our project structure:

```
web_extractor/
│
├── requirements.txt
├── web_extractor.py
└── main.py
```

Now, let's create our `requirements.txt`:

```
requests
beautifulsoup4
pypandoc
```

Next, let's create our `web_extractor.py`:

```python
import requests
from bs4 import BeautifulSoup
import pypandoc

class WebExtractor:
    def __init__(self, url):
        self.url = url
        self.soup = None
        self.content = ""

    def fetch_page(self):
        response = requests.get(self.url)
        self.soup = BeautifulSoup(response.text, 'html.parser')

    def extract_content(self):
        if not self.soup:
            self.fetch_page()
        
        # Extract the main content (this may need to be adjusted based on the website structure)
        main_content = self.soup.find('main') or self.soup.find('article') or self.soup.find('body')
        
        if main_content:
            self.content = main_content.get_text(separator='\n\n')
        else:
            self.content = "Could not extract main content."

    def convert_content(self, output_format):
        if not self.content:
            self.extract_content()
        
        # Convert content to the desired format
        converted = pypandoc.convert_text(self.content, output_format, format='md')
        
        return converted

    def save_content(self, filename, output_format):
        converted_content = self.convert_content(output_format)
        
        with open(filename, 'w', encoding='utf-8') as file:
            file.write(converted_content)
```

Now, let's create our `main.py`:

```python
from web_extractor import WebExtractor

def main():
    url = input("Enter the URL of the web page to extract: ")
    output_format = input("Enter the desired output format (e.g., html, pdf, docx): ")
    output_filename = input("Enter the output filename: ")

    extractor = WebExtractor(url)
    
    print("Fetching and extracting content...")
    extractor.extract_content()
    
    print(f"Converting content to {output_format}...")
    extractor.save_content(output_filename, output_format)
    
    print(f"Content has been extracted and saved to {output_filename}")

if __name__ == "__main__":
    main()
```

To run the example, first install the required packages:

```
pip install -r requirements.txt
```

Then execute `main.py`:

```
python main.py
```

This example demonstrates several concepts:
1. Web scraping with requests and BeautifulSoup
2. Document conversion with pypandoc
3. Object-oriented design for modular and reusable code
4. User input for flexible usage

## Cross-platform Considerations

While the Python code we've written is cross-platform, there are a few things to keep in mind:

1. **Pandoc installation**: The process for installing Pandoc varies by operating system, as mentioned earlier.

2. **File paths**: When working with files, use `os.path.join()` or `pathlib.Path` to ensure paths are correct for the current OS.

3. **Character encoding**: Different systems might use different default encodings. Always specify the encoding (e.g., 'utf-8') when reading or writing files.

4. **SSL Certificates**: On some Windows systems, you might encounter SSL certificate verification errors with requests. You can install the `certifi` package to resolve this.

## Legal and Ethical Considerations

When scraping websites and converting documents, it's crucial to consider legal and ethical implications:

1. **Respect robots.txt**: Check a website's robots.txt file for scraping guidelines.

2. **Rate limiting**: Don't overwhelm websites with too many requests. Implement delays between requests.

3. **Terms of Service**: Ensure your scraping activities don't violate a website's terms of service.

4. **Copyright**: Be aware of copyright laws when extracting and republishing content.

5. **Personal Data**: Be cautious about scraping and storing personal data, which may be subject to data protection laws like GDPR.

## Conclusion

In this lesson, we've explored web scraping with requests and BeautifulSoup, and document conversion with pypandoc. We've seen how to extract data from websites, handle both static and dynamic web pages, and convert between various document formats. We've also created a practical tool that combines these techniques to extract and convert web content.

These skills are valuable for data collection, content aggregation, and document processing tasks. As you continue to work with web data and documents, you'll find many opportunities to apply and expand upon these techniques.

## Exercises

To reinforce your understanding, try these exercises:

1. Modify the WebExtractor class to extract and save images from the web page along with the text content.
2. Create a script that scrapes a news website and converts the latest articles to a single PDF document.
3. Implement error handling in the WebExtractor class to gracefully handle network errors and conversion failures.

Remember, while web scraping and document conversion are powerful tools, they should be used responsibly. Always respect website terms of service and be mindful of the load your scripts place on web servers.

