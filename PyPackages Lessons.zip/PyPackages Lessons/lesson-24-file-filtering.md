# Lesson 24: File Filtering and Ignoring

## Introduction

Welcome to Lesson 24 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore techniques for file filtering and ignoring, which are essential skills for managing large projects, implementing version control systems, and building efficient file processing tools. We'll focus on two main approaches: using the `pathspec` library for `.gitignore`-style matching and Python's built-in `glob` module for file selection.

In this lesson, we'll cover:

1. Using pathspec for .gitignore-style matching
2. Glob patterns for file selection
3. Recursive file matching and filtering
4. Implementing custom ignore patterns
5. Platform-specific path matching considerations

By the end of this lesson, you'll be able to efficiently filter and select files based on various criteria and patterns.

## Project Setup

Let's start by setting up our project structure. Create a new directory for this lesson and navigate into it:

```
mkdir lesson_24_file_filtering
cd lesson_24_file_filtering
```

Now, let's create our main Python file and a directory structure for our example:

```
touch file_filtering.py
mkdir -p project/{src,docs,tests}
touch project/.gitignore
```

Your project structure should look like this:

```
lesson_24_file_filtering/
│
├── file_filtering.py
└── project/
    ├── src/
    ├── docs/
    ├── tests/
    └── .gitignore
```

Before we begin, make sure you have pathspec installed. You can install it using pip:

```
pip install pathspec
```

Now, let's open `file_filtering.py` in your favorite text editor and start exploring file filtering techniques!

## 1. Using pathspec for .gitignore-style matching

The `pathspec` library allows us to use `.gitignore`-style patterns to match and filter files. This is particularly useful when you want to implement ignore functionality similar to version control systems. Let's start by creating a simple `.gitignore` file and using pathspec to filter files based on it.

First, add some content to the `.gitignore` file:

```
# Add this content to project/.gitignore
*.pyc
__pycache__/
.DS_Store
*.log
```

Now, let's use pathspec to filter files based on this `.gitignore` file. Add the following code to `file_filtering.py`:

```python
import os
import pathspec

def create_sample_files(base_path):
    """Create sample files for demonstration"""
    os.makedirs(os.path.join(base_path, 'src'), exist_ok=True)
    os.makedirs(os.path.join(base_path, 'docs'), exist_ok=True)
    os.makedirs(os.path.join(base_path, 'tests'), exist_ok=True)

    with open(os.path.join(base_path, 'src', 'main.py'), 'w') as f:
        f.write('print("Hello, World!")')
    with open(os.path.join(base_path, 'src', 'main.pyc'), 'w') as f:
        f.write('Compiled Python file')
    with open(os.path.join(base_path, 'docs', 'index.html'), 'w') as f:
        f.write('<html><body>Documentation</body></html>')
    with open(os.path.join(base_path, 'tests', 'test_main.py'), 'w') as f:
        f.write('def test_main(): pass')
    with open(os.path.join(base_path, 'app.log'), 'w') as f:
        f.write('Application log')

def filter_files_with_pathspec(base_path):
    """Filter files using pathspec based on .gitignore"""
    with open(os.path.join(base_path, '.gitignore'), 'r') as ignore_file:
        spec = pathspec.PathSpec.from_lines(
            pathspec.patterns.GitWildMatchPattern, ignore_file
        )

    all_files = []
    for root, _, files in os.walk(base_path):
        for file in files:
            all_files.append(os.path.relpath(os.path.join(root, file), base_path))

    filtered_files = [f for f in all_files if not spec.match_file(f)]
    
    print("All files:")
    print('\n'.join(all_files))
    print("\nFiltered files (excluding ignored):")
    print('\n'.join(filtered_files))

# Use the project directory
project_path = os.path.join(os.path.dirname(__file__), 'project')

create_sample_files(project_path)
filter_files_with_pathspec(project_path)
```

This code creates sample files in our project structure and then uses pathspec to filter out files based on the patterns in the `.gitignore` file.

## 2. Glob patterns for file selection

Python's built-in `glob` module provides a way to find files and directories using Unix shell-style wildcards. Let's explore how to use glob patterns for file selection. Add the following code to `file_filtering.py`:

```python
import glob

def select_files_with_glob(base_path):
    """Select files using glob patterns"""
    # Select all Python files
    python_files = glob.glob(os.path.join(base_path, '**', '*.py'), recursive=True)
    
    # Select all HTML files
    html_files = glob.glob(os.path.join(base_path, '**', '*.html'), recursive=True)
    
    # Select all files in the src directory
    src_files = glob.glob(os.path.join(base_path, 'src', '*'))
    
    print("Python files:")
    print('\n'.join(python_files))
    print("\nHTML files:")
    print('\n'.join(html_files))
    print("\nFiles in src directory:")
    print('\n'.join(src_files))

select_files_with_glob(project_path)
```

This code demonstrates how to use glob patterns to select files based on their extensions or location within the project structure.

## 3. Recursive file matching and filtering

When working with large project structures, it's often necessary to recursively match and filter files. We've already seen recursive matching with glob, but let's create a more advanced example that combines glob and custom filtering. Add the following code to `file_filtering.py`:

```python
import fnmatch

def recursive_custom_filter(base_path, include_patterns, exclude_patterns):
    """Recursively match files using custom include and exclude patterns"""
    matched_files = []
    
    for root, _, files in os.walk(base_path):
        for file in files:
            relative_path = os.path.relpath(os.path.join(root, file), base_path)
            
            # Check if the file matches any include pattern
            if any(fnmatch.fnmatch(relative_path, pattern) for pattern in include_patterns):
                # Check if the file doesn't match any exclude pattern
                if not any(fnmatch.fnmatch(relative_path, pattern) for pattern in exclude_patterns):
                    matched_files.append(relative_path)
    
    return matched_files

# Example usage
include_patterns = ['*.py', '*.html']
exclude_patterns = ['tests/*']

filtered_files = recursive_custom_filter(project_path, include_patterns, exclude_patterns)

print("\nCustom filtered files (Python and HTML, excluding tests):")
print('\n'.join(filtered_files))
```

This example demonstrates how to implement a custom recursive file matching and filtering function that allows you to specify both include and exclude patterns.

## 4. Implementing custom ignore patterns

Sometimes you might need more complex ignoring logic that goes beyond simple pattern matching. Let's implement a custom ignore function that takes into account file size and modification time. Add the following code to `file_filtering.py`:

```python
import time

def custom_ignore_function(file_path, max_size_kb=100, max_age_days=30):
    """Custom ignore function based on file size and age"""
    file_size_kb = os.path.getsize(file_path) / 1024  # Convert to KB
    file_age_days = (time.time() - os.path.getmtime(file_path)) / (24 * 3600)  # Convert to days
    
    return file_size_kb > max_size_kb or file_age_days > max_age_days

def filter_with_custom_ignore(base_path):
    """Filter files using a custom ignore function"""
    filtered_files = []
    
    for root, _, files in os.walk(base_path):
        for file in files:
            file_path = os.path.join(root, file)
            relative_path = os.path.relpath(file_path, base_path)
            
            if not custom_ignore_function(file_path):
                filtered_files.append(relative_path)
    
    print("\nFiles not ignored by custom function:")
    print('\n'.join(filtered_files))

filter_with_custom_ignore(project_path)
```

This example shows how to implement a custom ignore function that filters files based on their size and age, which can be useful for managing large repositories or backup systems.

## 5. Platform-specific path matching considerations

When working with file paths across different platforms (Windows, macOS, and Linux), it's important to consider the differences in path separators and case sensitivity. Here are some tips for handling platform-specific issues:

1. Use `os.path.join()` for constructing file paths to ensure compatibility across platforms.
2. Use `os.path.normpath()` to normalize paths (e.g., convert forward slashes to backslashes on Windows).
3. Be aware of case sensitivity: Windows is case-insensitive, while macOS and Linux are case-sensitive by default.

Let's add a function to demonstrate these considerations:

```python
import sys

def platform_aware_path_matching(base_path, pattern):
    """Demonstrate platform-aware path matching"""
    matched_files = []
    
    for root, _, files in os.walk(base_path):
        for file in files:
            # Normalize the path to handle different separators
            relative_path = os.path.normpath(os.path.relpath(os.path.join(root, file), base_path))
            
            # On Windows, convert to lowercase for case-insensitive matching
            if sys.platform.startswith('win'):
                relative_path = relative_path.lower()
                pattern = pattern.lower()
            
            if fnmatch.fnmatch(relative_path, pattern):
                matched_files.append(os.path.join(root, file))
    
    return matched_files

# Example usage
pattern = '**/*.py'
matched_files = platform_aware_path_matching(project_path, pattern)

print("\nPlatform-aware matched Python files:")
print('\n'.join(matched_files))
```

This function demonstrates how to perform platform-aware path matching, taking into account differences in path separators and case sensitivity across different operating systems.

## Conclusion

In this lesson, we've explored various techniques for file filtering and ignoring, including:

1. Using pathspec for .gitignore-style matching
2. Glob patterns for file selection
3. Recursive file matching and filtering
4. Implementing custom ignore patterns
5. Platform-specific path matching considerations

These techniques are essential for managing large projects, implementing version control systems, and building efficient file processing tools.

To practice what you've learned, try the following exercises:

1. Create a function that combines pathspec and glob to filter files based on both include and exclude patterns.
2. Implement a custom ignore function that takes into account file content (e.g., ignore files containing specific keywords).
3. Build a simple backup tool that uses file filtering to exclude unnecessary files and directories.
4. Create a script that generates a report of file types and sizes in a given directory, using file filtering to focus on specific file categories.
5. Implement a cross-platform file search tool that allows users to specify complex search criteria using a combination of patterns and custom filters.

By mastering these file filtering and ignoring techniques, you'll be better equipped to handle large-scale file operations, improve the efficiency of your scripts, and build more robust file management tools.

