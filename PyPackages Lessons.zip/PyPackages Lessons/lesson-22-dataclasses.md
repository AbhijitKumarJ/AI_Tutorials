# Lesson 22: Object-Oriented Programming with dataclasses

## Introduction

Welcome to Lesson 22 of our "Mastering Python Packages for Efficient Programming" series! Today, we're diving into the `dataclasses` module, which provides a decorator and functions for automatically adding generated special methods to classes. Introduced in Python 3.7, dataclasses simplify the process of creating classes that are primarily used to store data, reducing boilerplate code and making your classes more readable and maintainable.

In this lesson, we'll cover:

1. Introduction to dataclasses
2. Creating classes with less boilerplate
3. Customizing dataclass behaviors
4. Inheritance and mixins with dataclasses
5. Performance considerations and limitations

By the end of this lesson, you'll be comfortable using dataclasses to create efficient and clean object-oriented code.

## Project Setup

Let's start by setting up our project structure. Create a new directory for this lesson and navigate into it:

```
mkdir lesson_22_dataclasses
cd lesson_22_dataclasses
```

Now, let's create our main Python file and a directory for some sample data:

```
touch dataclass_examples.py
mkdir sample_data
```

Your project structure should look like this:

```
lesson_22_dataclasses/
│
├── dataclass_examples.py
└── sample_data/
```

Now, let's open `dataclass_examples.py` in your favorite text editor and start exploring dataclasses!

## 1. Introduction to dataclasses

Dataclasses are a feature in Python that automatically adds special methods like `__init__()`, `__repr__()`, and `__eq__()` to user-defined classes. They're designed to reduce the boilerplate code required when creating classes that are primarily used to store data.

Add the following code to `dataclass_examples.py`:

```python
from dataclasses import dataclass

@dataclass
class Point:
    x: float
    y: float

# Create a Point instance
p = Point(1.0, 2.0)

print(f"Point: {p}")
print(f"x-coordinate: {p.x}")
print(f"y-coordinate: {p.y}")

# Equality comparison
p2 = Point(1.0, 2.0)
print(f"p == p2: {p == p2}")
```

In this example, we create a simple `Point` class using the `@dataclass` decorator. The decorator automatically generates methods like `__init__()`, `__repr__()`, and `__eq__()` for us, based on the class attributes we define.

## 2. Creating classes with less boilerplate

Let's compare a traditional class definition with a dataclass to see how much boilerplate code we can save. Add the following code to `dataclass_examples.py`:

```python
# Traditional class definition
class TraditionalPerson:
    def __init__(self, name: str, age: int, email: str):
        self.name = name
        self.age = age
        self.email = email
    
    def __repr__(self):
        return f"TraditionalPerson(name='{self.name}', age={self.age}, email='{self.email}')"
    
    def __eq__(self, other):
        if not isinstance(other, TraditionalPerson):
            return NotImplemented
        return (self.name, self.age, self.email) == (other.name, other.age, other.email)

# Dataclass definition
@dataclass
class DataclassPerson:
    name: str
    age: int
    email: str

# Create instances of both classes
tp = TraditionalPerson("Alice", 30, "alice@example.com")
dp = DataclassPerson("Alice", 30, "alice@example.com")

print(f"Traditional Person: {tp}")
print(f"Dataclass Person: {dp}")
print(f"tp == dp: {tp == dp}")
```

As you can see, the dataclass version is much more concise, yet it provides the same functionality as the traditional class definition.

## 3. Customizing dataclass behaviors

Dataclasses offer various options to customize their behavior. Let's explore some of these options:

```python
from dataclasses import dataclass, field, InitVar

@dataclass(order=True, frozen=True)
class Product:
    name: str
    price: float
    quantity: int = 0
    total_value: float = field(init=False, repr=False)
    discount: InitVar[float] = 0.0

    def __post_init__(self, discount):
        # frozen=True makes the class immutable, but we can still set attributes in __post_init__
        object.__setattr__(self, 'total_value', self.price * self.quantity * (1 - discount))

# Create Product instances
p1 = Product("Apple", 0.5, 10, 0.1)
p2 = Product("Banana", 0.3, 15)

print(f"Product 1: {p1}")
print(f"Product 2: {p2}")
print(f"p1 < p2: {p1 < p2}")

try:
    p1.price = 0.6
except AttributeError as e:
    print(f"Error: {e}")
```

In this example, we use several dataclass features:

- `order=True`: Adds comparison methods (`__lt__`, `__le__`, etc.) based on field order.
- `frozen=True`: Makes the class immutable.
- `field()`: Customizes individual fields (e.g., `total_value` is not included in `__init__` or `__repr__`).
- `InitVar`: Defines a parameter for `__init__` that's not stored as an attribute.
- `__post_init__()`: Performs additional initialization after `__init__`.

## 4. Inheritance and mixins with dataclasses

Dataclasses support inheritance and can be used as mixins. Let's see how this works:

```python
from dataclasses import dataclass

@dataclass
class Person:
    name: str
    age: int

@dataclass
class Employee(Person):
    employee_id: str
    department: str

@dataclass
class AddressMixin:
    street: str
    city: str
    country: str

    def full_address(self):
        return f"{self.street}, {self.city}, {self.country}"

@dataclass
class Customer(Person, AddressMixin):
    customer_id: str

# Create instances
employee = Employee("Bob", 35, "E12345", "Engineering")
customer = Customer("Charlie", 28, "123 Main St", "Anytown", "USA", "C67890")

print(f"Employee: {employee}")
print(f"Customer: {customer}")
print(f"Customer address: {customer.full_address()}")
```

This example demonstrates how dataclasses can be used with inheritance and as mixins. The `Employee` class inherits from `Person`, while the `Customer` class inherits from both `Person` and `AddressMixin`.

## 5. Performance considerations and limitations

While dataclasses offer many benefits, it's important to be aware of their performance characteristics and limitations:

1. Performance: Dataclasses are generally as fast as regular classes for most operations. However, class creation might be slightly slower due to the additional processing required by the decorator.

2. Memory usage: Dataclasses may use slightly more memory than regular classes due to the additional generated methods.

3. Limitations:
   - Dataclasses are designed for simple data storage; for complex behaviors, traditional classes might be more appropriate.
   - The order of field definitions matters, especially when using inheritance or comparison methods.

Let's create a simple benchmark to compare dataclasses with regular classes:

```python
import timeit
from dataclasses import dataclass

# Regular class
class RegularPoint:
    def __init__(self, x, y):
        self.x = x
        self.y = y

# Dataclass
@dataclass
class DataPoint:
    x: float
    y: float

def create_regular_points():
    return [RegularPoint(i, i) for i in range(1000)]

def create_data_points():
    return [DataPoint(i, i) for i in range(1000)]

regular_time = timeit.timeit(create_regular_points, number=1000)
data_time = timeit.timeit(create_data_points, number=1000)

print(f"Time to create 1,000,000 RegularPoints: {regular_time:.4f} seconds")
print(f"Time to create 1,000,000 DataPoints: {data_time:.4f} seconds")
```

This benchmark creates a million instances of both regular classes and dataclasses, allowing you to compare their performance.

## Cross-platform Considerations

Dataclasses are part of Python's standard library (introduced in Python 3.7), so their behavior is consistent across different operating systems (Windows, macOS, and Linux). However, there are a few points to keep in mind:

1. Python version: Ensure you're using Python 3.7 or later on all platforms. If you need to support earlier versions, consider using the `dataclasses` backport available on PyPI.

2. Type hints: Dataclasses rely heavily on type hints. While these are ignored at runtime, they can be useful for static type checkers like mypy. Ensure your development environment supports type hinting across all platforms.

3. Performance: While dataclasses' behavior is consistent across platforms, performance characteristics may vary slightly due to differences in underlying system libraries and hardware.

## Conclusion

In this lesson, we've explored the power and simplicity of dataclasses in Python. Dataclasses provide a concise way to create classes that are primarily used to store data, reducing boilerplate code and improving readability.

To practice what you've learned, try the following exercises:

1. Create a `Book` dataclass with fields for title, author, publication year, and ISBN. Add a method to return the book's age based on the current year.

2. Implement a `BankAccount` dataclass with methods for deposit and withdrawal. Use the `__post_init__` method to validate the initial balance.

3. Create a hierarchy of dataclasses to represent different shapes (e.g., Circle, Rectangle, Triangle). Include methods to calculate area and perimeter for each shape.

4. Implement a `Cache` dataclass that stores a maximum number of items. Use `field(default_factory=...)` to initialize an empty dictionary for storage.

5. Create a dataclass to represent a configuration file, using `field(default=...)` to provide default values for optional settings.

By mastering dataclasses, you'll be able to write cleaner, more maintainable object-oriented code in Python, reducing the amount of boilerplate and focusing on the essential aspects of your data structures.

