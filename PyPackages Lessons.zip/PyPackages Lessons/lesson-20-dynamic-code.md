# Lesson 20: Dynamic Code Execution and Importing

## Introduction

Welcome to Lesson 20 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore dynamic code execution and importing in Python. These powerful features allow us to work with code and modules in a more flexible way at runtime, enabling dynamic behavior in our applications.

## Setting Up Our Project

Let's start by setting up a new project for this lesson. Here's our folder structure:

```
dynamic_code_tutorial/
│
├── src/
│   ├── dynamic_execution.py
│   ├── dynamic_importing.py
│   ├── custom_importer.py
│   └── modules/
│       ├── __init__.py
│       ├── module_a.py
│       ├── module_b.py
│       └── module_c.py
│
├── tests/
│   └── test_dynamic_code.py
│
└── requirements.txt
```

For this lesson, we don't need to install any additional packages beyond the Python standard library. However, let's create an empty `requirements.txt` file for consistency with our project structure.

## Dynamic Code Execution

Let's start by exploring dynamic code execution in Python. Create a file `src/dynamic_execution.py`:

```python
import ast

def safe_eval(expr, globals_dict=None, locals_dict=None):
    """
    Safely evaluate an expression string.
    """
    if globals_dict is None:
        globals_dict = {}
    if locals_dict is None:
        locals_dict = {}
    
    # Parse the expression
    parsed_expr = ast.parse(expr, mode='eval')
    
    # Validate the expression
    if not isinstance(parsed_expr.body, (ast.Expr, ast.Num, ast.Str, ast.Name, ast.NameConstant,
                                         ast.List, ast.Tuple, ast.Set, ast.Dict)):
        raise ValueError("Invalid expression")
    
    # Compile and evaluate the expression
    code_object = compile(parsed_expr, '<string>', 'eval')
    return eval(code_object, globals_dict, locals_dict)

def execute_code(code, globals_dict=None, locals_dict=None):
    """
    Execute a code string.
    """
    if globals_dict is None:
        globals_dict = {}
    if locals_dict is None:
        locals_dict = {}
    
    # Compile and execute the code
    compiled_code = compile(code, '<string>', 'exec')
    exec(compiled_code, globals_dict, locals_dict)

# Example usage
if __name__ == "__main__":
    # Safe evaluation of expressions
    print("Safe evaluation examples:")
    print(safe_eval("2 + 3 * 4"))  # Output: 14
    print(safe_eval("'Hello, ' + 'World!'"))  # Output: Hello, World!
    print(safe_eval("[1, 2, 3] + [4, 5]"))  # Output: [1, 2, 3, 4, 5]
    
    try:
        safe_eval("__import__('os').system('echo Dangerous command')")
    except ValueError as e:
        print(f"Caught expected error: {e}")
    
    # Code execution
    print("\nCode execution example:")
    globals_dict = {}
    locals_dict = {}
    
    code = """
def greet(name):
    return f"Hello, {name}!"

result = greet("Alice")
"""
    
    execute_code(code, globals_dict, locals_dict)
    print(locals_dict['result'])  # Output: Hello, Alice!
    
    # Demonstrating the difference between exec and eval
    print("\nDifference between exec and eval:")
    exec_result = exec("2 + 2")  # Returns None
    eval_result = eval("2 + 2")  # Returns 4
    
    print(f"exec result: {exec_result}")
    print(f"eval result: {eval_result}")
```

This script demonstrates:

1. Safe evaluation of expressions using `ast.parse` and `eval`
2. Execution of code strings using `compile` and `exec`
3. The difference between `exec` and `eval`

Run the script to see dynamic code execution in action:

```bash
python src/dynamic_execution.py
```

## Dynamic Importing

Now let's explore dynamic importing in Python. Create `src/dynamic_importing.py`:

```python
import importlib
import sys

def import_module(module_name):
    """
    Dynamically import a module.
    """
    return importlib.import_module(module_name)

def reload_module(module):
    """
    Reload an already imported module.
    """
    return importlib.reload(module)

def import_from_file(file_path):
    """
    Import a module from a file path.
    """
    module_name = file_path.replace('/', '.').rstrip('.py')
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

# Example modules
module_a_code = """
def greet(name):
    return f"Hello, {name}!"
"""

module_b_code = """
def farewell(name):
    return f"Goodbye, {name}!"
"""

# Example usage
if __name__ == "__main__":
    # Dynamic importing of built-in modules
    math_module = import_module('math')
    print(f"Pi from dynamically imported math module: {math_module.pi}")
    
    # Creating and importing modules from code strings
    with open('src/modules/module_a.py', 'w') as f:
        f.write(module_a_code)
    
    with open('src/modules/module_b.py', 'w') as f:
        f.write(module_b_code)
    
    module_a = import_module('src.modules.module_a')
    print(module_a.greet("Alice"))
    
    module_b = import_from_file('src/modules/module_b.py')
    print(module_b.farewell("Bob"))
    
    # Reloading a module
    with open('src/modules/module_a.py', 'a') as f:
        f.write("\ndef new_function():\n    return 'This is a new function!'\n")
    
    reloaded_module_a = reload_module(module_a)
    print(reloaded_module_a.new_function())
    
    # Cleaning up
    import os
    os.remove('src/modules/module_a.py')
    os.remove('src/modules/module_b.py')
```

This script demonstrates:

1. Dynamically importing modules using `importlib.import_module`
2. Importing modules from file paths
3. Reloading modules using `importlib.reload`
4. Creating and importing modules from code strings

Run the script to see dynamic importing in action:

```bash
python src/dynamic_importing.py
```

## Custom Importer

Python's import system is highly customizable. Let's create a custom importer that can import modules from a ZIP file. Create `src/custom_importer.py`:

```python
import sys
import zipimport
import zipfile

class ZipImporter:
    def __init__(self, zip_file):
        self.zip_file = zip_file
        self.zimp = zipimport.zipimporter(zip_file)
    
    def find_module(self, fullname, path=None):
        try:
            self.zimp.load_module(fullname)
            return self
        except ImportError:
            return None
    
    def load_module(self, fullname):
        module = self.zimp.load_module(fullname)
        module.__loader__ = self
        module.__file__ = f"{self.zip_file}/{fullname.replace('.', '/')}.py"
        return module

def create_module_zip(zip_filename, modules):
    with zipfile.ZipFile(zip_filename, 'w') as zf:
        for module_name, module_code in modules.items():
            zf.writestr(f"{module_name.replace('.', '/')}.py", module_code)

# Example usage
if __name__ == "__main__":
    # Create a ZIP file with sample modules
    modules = {
        'module_x': "def function_x():\n    return 'This is function X'",
        'module_y': "def function_y():\n    return 'This is function Y'",
        'subpackage.module_z': "def function_z():\n    return 'This is function Z'"
    }
    
    zip_filename = 'src/modules/sample_modules.zip'
    create_module_zip(zip_filename, modules)
    
    # Add the custom importer to sys.meta_path
    sys.meta_path.insert(0, ZipImporter(zip_filename))
    
    # Import and use the modules from the ZIP file
    import module_x
    import module_y
    import subpackage.module_z
    
    print(module_x.function_x())
    print(module_y.function_y())
    print(subpackage.module_z.function_z())
    
    # Clean up
    import os
    os.remove(zip_filename)
    
    # Remove the custom importer
    sys.meta_path.pop(0)
```

This script demonstrates:

1. Creating a custom importer for ZIP files
2. Adding the custom importer to `sys.meta_path`
3. Importing modules from a ZIP file using the custom importer

Run the script to see the custom importer in action:

```bash
python src/custom_importer.py
```

## Cross-Platform Considerations

While dynamic code execution and importing are generally consistent across platforms, there are a few things to keep in mind:

1. **File paths**: Use `os.path.join()` for constructing file paths to ensure cross-platform compatibility.

2. **Module names**: On case-insensitive file systems (like Windows), be cautious with module names that differ only in case.

3. **Security**: Be extra careful when executing dynamically loaded code, especially on production systems. Always validate and sanitize input to prevent security vulnerabilities.

4. **Performance**: Dynamic importing can be slower than static importing. On resource-constrained systems, this performance difference may be more noticeable.

5. **ZIP file handling**: Ensure that your ZIP file creation and handling code works consistently across platforms, especially with regards to file path separators.

## Best Practices for Dynamic Code Execution and Importing

1. **Security first**: Always validate and sanitize any code or module names that come from external sources before execution or importing.

2. **Use safe_eval**: When evaluating expressions from untrusted sources, use a safe evaluation function like the one demonstrated in this lesson.

3. **Error handling**: Implement robust error handling when working with dynamic code execution and importing, as these operations can fail in various ways.

4. **Caching**: For frequently used dynamically imported modules, consider implementing a caching mechanism to improve performance.

5. **Documentation**: Clearly document any dynamic behavior in your code, including potential security implications and performance considerations.

6. **Testing**: Thoroughly test your dynamic code execution and importing mechanisms across different platforms and Python versions.

7. **Limit scope**: Use dynamic code execution and importing judiciously. In many cases, static imports and regular function calls are safer and more maintainable.

8. **Version compatibility**: Be aware of changes in the import system between Python versions, especially if your code needs to support multiple Python versions.

## Conclusion

In this lesson, we've explored dynamic code execution and importing in Python. We've covered techniques for safely evaluating expressions, executing code strings, dynamically importing modules, and even creating custom importers.

These powerful features allow for great flexibility in Python programming, enabling scenarios such as:

- Plugin systems where new functionality can be loaded at runtime
- Interactive Python environments (like Jupyter notebooks)
- Configuration systems that can include executable code
- Testing frameworks that dynamically generate test cases

However, with great power comes great responsibility. Always be mindful of the security implications when working with dynamic code, especially in production environments or when dealing with untrusted input.

As you continue to develop Python applications, consider how dynamic code execution and importing can enhance your programs' flexibility and extensibility. At the same time, always weigh these benefits against the potential risks and complexity they introduce.

In the next lesson, we'll explore advanced data structures with the `collections` module, which provides specialized container datatypes that can significantly improve the efficiency and readability of your Python code. Stay tuned!
