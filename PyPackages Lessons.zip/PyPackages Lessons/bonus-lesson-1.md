# Bonus Lesson 1: Setting Up the Project Structure and Environment

In this lesson, we'll set up the foundation for our comprehensive CLI tool. We'll create a project structure that follows best practices and set up a virtual environment to manage our dependencies.

## Project Overview

We're going to build a CLI tool called "TaskMaster" that helps users manage their tasks, set reminders, and generate simple reports. This tool will demonstrate many of the concepts we've learned throughout the course.

## Setting Up the Project Structure

Let's start by creating our project structure. Open your terminal and run the following commands:

```bash
mkdir taskmaster
cd taskmaster
```

Now, let's create our project structure:

```bash
mkdir taskmaster tests docs
touch README.md LICENSE.txt setup.py
```

Your project structure should look like this:

```
taskmaster/
│
├── taskmaster/
│   ├── __init__.py
│   ├── cli.py
│   ├── task.py
│   └── database.py
│
├── tests/
│   ├── __init__.py
│   ├── test_cli.py
│   └── test_task.py
│
├── docs/
│   └── README.md
│
├── README.md
├── LICENSE.txt
└── setup.py
```

Let's break down the purpose of each file and directory:

- `taskmaster/`: This is our main package directory.
  - `__init__.py`: Makes the directory a Python package.
  - `cli.py`: Will contain our command-line interface code.
  - `task.py`: Will define our Task class and related functions.
  - `database.py`: Will handle data storage and retrieval.
- `tests/`: Contains our unit tests.
- `docs/`: For project documentation.
- `README.md`: Project description and usage instructions.
- `LICENSE.txt`: License information for our project.
- `setup.py`: Used for packaging and distribution.

## Setting Up a Virtual Environment

Virtual environments are crucial for managing project dependencies. They allow us to create isolated Python environments for each project, preventing conflicts between package versions.

### For Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

### For macOS and Linux:

```bash
python3 -m venv venv
source venv/bin/activate
```

You should now see `(venv)` at the beginning of your command prompt, indicating that the virtual environment is active.

## Installing Dependencies

Let's install the packages we'll need for our project:

```bash
pip install click pytest python-dateutil
```

Now, let's create a `requirements.txt` file to keep track of our dependencies:

```bash
pip freeze > requirements.txt
```

## Creating the Initial Files

Let's create some basic content for our files:

1. `taskmaster/__init__.py`:

```python
__version__ = "0.1.0"
```

2. `taskmaster/cli.py`:

```python
import click

@click.group()
def cli():
    """TaskMaster: A simple CLI task manager."""
    pass

@cli.command()
def hello():
    """Say hello to TaskMaster."""
    click.echo("Hello from TaskMaster!")

if __name__ == "__main__":
    cli()
```

3. `setup.py`:

```python
from setuptools import setup, find_packages

setup(
    name="taskmaster",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "Click",
    ],
    entry_points={
        "console_scripts": [
            "taskmaster=taskmaster.cli:cli",
        ],
    },
)
```

## Testing Our Initial Setup

Let's install our package in editable mode:

```bash
pip install -e .
```

Now, you should be able to run:

```bash
taskmaster hello
```

You should see the output: "Hello from TaskMaster!"

## Cross-platform Considerations

1. **File Paths**: Always use `os.path.join()` or `pathlib.Path` for constructing file paths to ensure compatibility across different operating systems.

2. **Line Endings**: Be aware that Windows uses "\r\n" for line endings, while Unix-based systems (macOS and Linux) use "\n". When reading or writing files, use the appropriate mode (e.g., "rt" for text mode) to handle line endings correctly.

3. **Environment Variables**: Use `os.environ` to access environment variables, as the syntax is the same across platforms.

4. **Executable Scripts**: For the entry point in `setup.py`, we used the `console_scripts` approach, which works across all platforms. Avoid using platform-specific script files (like `.bat` for Windows).

5. **File Permissions**: Remember that file permissions work differently on Windows compared to Unix-based systems. Use `os.chmod()` carefully and be aware of these differences when dealing with file operations.

## Conclusion

In this lesson, we've set up the basic structure for our TaskMaster CLI tool. We've created a virtual environment, installed dependencies, and set up our project structure. In the next lesson, we'll start implementing the core functionality of our CLI tool using ArgParse and Click.

Remember to always activate your virtual environment when working on this project:

- Windows: `venv\Scripts\activate`
- macOS/Linux: `source venv/bin/activate`

In the next lesson, we'll dive into implementing the core functionality of our TaskMaster CLI tool!
