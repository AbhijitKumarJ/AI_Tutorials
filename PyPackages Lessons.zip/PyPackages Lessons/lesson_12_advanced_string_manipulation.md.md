# Lesson 12: Advanced String Manipulation

## Introduction

Welcome to Lesson 12 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll dive deep into advanced string manipulation techniques in Python. We'll explore built-in string methods, the `textwrap` module for text wrapping and filling, string constants, and handling Unicode and encoding issues. By the end of this lesson, you'll have a comprehensive understanding of how to work with strings efficiently in Python, regardless of your operating system.

## Setting Up

Let's set up our project structure:

```
string_manipulation_project/
├── venv/
├── string_operations.py
└── requirements.txt
```

1. Create a new directory for our project:
   ```
   mkdir string_manipulation_project
   cd string_manipulation_project
   ```

2. Create and activate a virtual environment:
   - On Windows:
     ```
     python -m venv venv
     venv\Scripts\activate
     ```
   - On macOS/Linux:
     ```
     python3 -m venv venv
     source venv/bin/activate
     ```

3. Create a `requirements.txt` file (we won't need to install any external packages for this lesson, but it's good practice):
   ```
   # requirements.txt
   # This file is intentionally left empty for this lesson
   ```

Now, let's create our `string_operations.py` file and start exploring advanced string manipulation!

## Built-in String Methods

Python provides a rich set of built-in methods for string manipulation. Let's explore some of the most useful ones:

```python
def demonstrate_string_methods():
    # Sample string
    s = "  Hello, World!  "
    
    print(f"Original string: '{s}'")
    print(f"Stripped: '{s.strip()}'")
    print(f"Uppercase: '{s.upper()}'")
    print(f"Lowercase: '{s.lower()}'")
    print(f"Capitalized: '{s.capitalize()}'")
    print(f"Title case: '{s.title()}'")
    print(f"Centered (20): '{s.center(20, "*")}'")
    print(f"Replaced: '{s.replace("World", "Python")}'")
    
    # Splitting and joining
    words = s.split()
    print(f"Split: {words}")
    print(f"Joined: '{" ".join(words)}'")
    
    # Checking string properties
    print(f"Starts with 'Hello': {s.strip().startswith('Hello')}")
    print(f"Ends with 'World!': {s.strip().endswith('World!')}")
    print(f"Contains 'World': {'World' in s}")
    
    # Finding substrings
    print(f"Index of 'World': {s.index('World')}")
    print(f"Count of 'l': {s.count('l')}")

if __name__ == "__main__":
    demonstrate_string_methods()
```

This function demonstrates various string methods. Run it to see the output:

```
python string_operations.py
```

## Text Wrapping and Filling with textwrap

The `textwrap` module provides tools for wrapping and filling text. This is particularly useful when dealing with long strings or formatting text for display.

Let's add some functions to demonstrate `textwrap`:

```python
import textwrap

def demonstrate_textwrap():
    long_string = "This is a very long string that we will use to demonstrate the textwrap module's functionality. It will be wrapped and filled according to our specifications."
    
    print("Original string:")
    print(long_string)
    
    print("\nWrapped to 40 characters:")
    print(textwrap.fill(long_string, width=40))
    
    print("\nWrapped to 40 characters with 4 space indent:")
    print(textwrap.fill(long_string, width=40, initial_indent="    ", subsequent_indent="    "))
    
    print("\nWrapped to 40 characters with custom prefix:")
    print(textwrap.fill(long_string, width=40, initial_indent="-> ", subsequent_indent="   "))
    
    print("\nShortened to 50 characters:")
    print(textwrap.shorten(long_string, width=50, placeholder="..."))

if __name__ == "__main__":
    demonstrate_textwrap()
```

This function shows how to wrap text to a specific width, add indentation, and shorten text while preserving whole words.

## String Constants and String-related Functions

Python's `string` module provides various string constants and utility functions. Let's explore some of them:

```python
import string
import random

def demonstrate_string_constants():
    print(f"ASCII Lowercase: {string.ascii_lowercase}")
    print(f"ASCII Uppercase: {string.ascii_uppercase}")
    print(f"ASCII Letters: {string.ascii_letters}")
    print(f"Digits: {string.digits}")
    print(f"Hexadecimal Digits: {string.hexdigits}")
    print(f"Punctuation: {string.punctuation}")
    print(f"Printable Characters: {string.printable}")

def generate_random_string(length):
    characters = string.ascii_letters + string.digits + string.punctuation
    return ''.join(random.choice(characters) for _ in range(length))

if __name__ == "__main__":
    demonstrate_string_constants()
    print(f"\nRandom string of length 16: {generate_random_string(16)}")
```

These functions demonstrate string constants and how to use them to generate random strings.

## Unicode Handling and Encoding Issues

Handling Unicode and different encodings is crucial, especially when working with text from various sources or in multiple languages. Let's explore some Unicode operations and encoding issues:

```python
def demonstrate_unicode_operations():
    # Unicode string
    unicode_string = "Hello, 世界! 🌍"
    print(f"Unicode string: {unicode_string}")
    
    # Encoding and decoding
    utf8_encoded = unicode_string.encode('utf-8')
    print(f"UTF-8 encoded: {utf8_encoded}")
    print(f"Decoded back: {utf8_encoded.decode('utf-8')}")
    
    # Handling encoding errors
    try:
        unicode_string.encode('ascii')
    except UnicodeEncodeError as e:
        print(f"ASCII encoding error: {e}")
    
    # Handling decoding errors
    try:
        b'\xff\xfe'.decode('utf-8')
    except UnicodeDecodeError as e:
        print(f"UTF-8 decoding error: {e}")
    
    # Replacing characters that can't be encoded
    ascii_compatible = unicode_string.encode('ascii', errors='replace')
    print(f"ASCII compatible: {ascii_compatible}")
    
    # Normalizing Unicode strings
    from unicodedata import normalize
    original = "café"
    nfd = normalize('NFD', original)
    nfc = normalize('NFC', original)
    print(f"Original: {original}, NFD: {nfd}, NFC: {nfc}")
    print(f"Original == NFD: {original == nfd}")
    print(f"NFD == NFC: {nfd == nfc}")

if __name__ == "__main__":
    demonstrate_unicode_operations()
```

This function demonstrates Unicode string operations, encoding/decoding, error handling, and normalization.

## Platform-specific Line Endings and Encoding

Different operating systems use different line ending characters. Let's explore how to handle this:

```python
import os

def demonstrate_platform_specifics():
    print(f"Default line ending on this system: {repr(os.linesep)}")
    
    # Creating a multi-line string
    multiline_string = "Line 1\nLine 2\nLine 3"
    
    # Writing to a file with platform-specific line endings
    with open('test_file.txt', 'w', newline='') as f:
        f.write(multiline_string)
    
    # Reading the file back
    with open('test_file.txt', 'r', newline='') as f:
        content = f.read()
    
    print(f"Content read from file: {repr(content)}")
    
    # Clean up
    os.remove('test_file.txt')
    
    # Handling different encodings
    encodings = ['utf-8', 'ascii', 'latin-1', 'utf-16']
    test_string = "Hello, world! 世界"
    
    for encoding in encodings:
        try:
            encoded = test_string.encode(encoding)
            decoded = encoded.decode(encoding)
            print(f"{encoding}: Encoded: {encoded}, Decoded: {decoded}")
        except UnicodeEncodeError:
            print(f"{encoding}: Cannot encode '世界'")
        except UnicodeDecodeError:
            print(f"{encoding}: Cannot decode properly")

if __name__ == "__main__":
    demonstrate_platform_specifics()
```

This function demonstrates how to handle platform-specific line endings and different text encodings.

## Conclusion

In this lesson, we've explored advanced string manipulation techniques in Python. We've covered:

1. Built-in string methods for various operations
2. Text wrapping and filling using the `textwrap` module
3. String constants and utility functions from the `string` module
4. Unicode handling and encoding/decoding operations
5. Platform-specific considerations for line endings and text encoding

These techniques will help you work more efficiently with strings in your Python projects, regardless of the operating system you're using.

## Exercises

To reinforce your learning, try these exercises:

1. Create a function that takes a paragraph of text and returns a summary by extracting the first sentence of each paragraph.
2. Write a program that reads a text file, replaces all occurrences of a given word with another word, and writes the result to a new file. Make sure it works with files using different line endings.
3. Implement a simple text-based justified printing function that takes a string and a width, and prints the text justified to that width.
4. Create a function that takes a string containing mixed case words and converts it to "snake_case" (e.g., "HelloWorld" becomes "hello_world").
5. Write a program that detects the encoding of a given text file and prints its content, handling potential encoding errors gracefully.

Remember, practice is key to mastering these concepts. Happy coding!

