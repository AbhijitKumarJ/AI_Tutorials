# Lesson 27: Interactive Shell Programming with pexpect

## Introduction

Welcome to Lesson 27 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore pexpect, a powerful Python module for automating interactive applications and controlling other programs. pexpect is particularly useful for tasks that involve interacting with command-line interfaces, shell prompts, and other text-based interfaces.

In this lesson, we'll cover:

1. Introduction to pexpect and its capabilities
2. Automating interactive command-line programs
3. Sending and receiving data from child processes
4. Handling timeouts and errors
5. Screen scraping and terminal control
6. Alternatives for Windows (wexpect)

By the end of this lesson, you'll be able to automate complex interactions with command-line tools and create sophisticated scripts for system administration and testing.

## Project Setup

Let's start by setting up our project structure. Create a new directory for this lesson and navigate into it:

```
mkdir lesson_27_pexpect
cd lesson_27_pexpect
```

Now, let's create our main Python file:

```
touch pexpect_examples.py
```

Your project structure should look like this:

```
lesson_27_pexpect/
│
└── pexpect_examples.py
```

Before we begin, make sure you have pexpect installed. You can install it using pip:

```
pip install pexpect
```

Note: If you're using Windows, you'll need to install wexpect instead:

```
pip install wexpect
```

Now, let's open `pexpect_examples.py` in your favorite text editor and start exploring pexpect!

## 1. Introduction to pexpect and its capabilities

pexpect is a pure Python module for spawning child applications, controlling them, and responding to expected patterns in their output. It's particularly useful for automating interactive applications like ssh, ftp, passwd, telnet, etc.

Let's start with a simple example to demonstrate pexpect's basic functionality. Add the following code to `pexpect_examples.py`:

```python
import pexpect
import sys

def basic_pexpect_example():
    # Spawn a child process
    child = pexpect.spawn('python -c "print(\'Hello, what is your name?\'); name = input(); print(f\'Nice to meet you, {name}!\')"')

    # Expect the prompt and respond
    child.expect('Hello, what is your name?')
    print("Child process asks:", child.after.decode())

    # Send a response
    child.sendline('Alice')

    # Expect the final output
    child.expect(pexpect.EOF)
    print("Child process says:", child.before.decode())

if __name__ == "__main__":
    basic_pexpect_example()
```

This example demonstrates how to spawn a simple Python script as a child process, interact with it, and capture its output.

## 2. Automating interactive command-line programs

Now, let's look at a more practical example of automating an interactive command-line program. We'll create a function that interacts with the `ftp` command to download a file. Add the following code to `pexpect_examples.py`:

```python
import pexpect
import getpass

def automate_ftp_download(host, username, remote_file, local_file):
    # Spawn the FTP process
    child = pexpect.spawn(f'ftp {host}')

    try:
        # Login
        child.expect('Name .*: ')
        child.sendline(username)
        child.expect('Password:')
        password = getpass.getpass('Enter your FTP password: ')
        child.sendline(password)

        # Navigate and download
        child.expect('ftp> ')
        child.sendline(f'get {remote_file} {local_file}')
        child.expect('ftp> ')

        # Exit FTP
        child.sendline('bye')
        child.expect(pexpect.EOF)

        print(f"Successfully downloaded {remote_file} to {local_file}")
    except pexpect.TIMEOUT:
        print("FTP operation timed out")
    except pexpect.EOF:
        print("FTP operation failed")
    finally:
        child.close()

# Usage example (commented out to prevent accidental execution)
# automate_ftp_download('ftp.example.com', 'your_username', 'remote_file.txt', 'local_file.txt')
```

This example shows how to automate an FTP session to download a file. It handles login, file transfer, and graceful exit from the FTP session.

## 3. Sending and receiving data from child processes

pexpect allows you to send data to child processes and receive their output. Let's create an example that interacts with a simple calculator program. Add the following code to `pexpect_examples.py`:

```python
import pexpect

def interactive_calculator():
    # Spawn a Python interpreter as our calculator
    child = pexpect.spawn('python')
    child.expect('>>>')

    while True:
        # Get user input
        expression = input("Enter a mathematical expression (or 'quit' to exit): ")
        
        if expression.lower() == 'quit':
            break

        # Send the expression to the Python interpreter
        child.sendline(expression)
        child.expect('>>>')

        # Get the result
        result = child.before.decode().strip().split('\n')[-1]
        print(f"Result: {result}")

    child.close()

# Uncomment to run the interactive calculator
# interactive_calculator()
```

This example creates an interactive calculator by spawning a Python interpreter and sending it expressions to evaluate.

## 4. Handling timeouts and errors

When working with pexpect, it's important to handle timeouts and errors gracefully. Let's create an example that demonstrates how to do this. Add the following code to `pexpect_examples.py`:

```python
import pexpect

def ping_with_timeout(host, timeout=5):
    child = pexpect.spawn(f'ping -c 4 {host}')

    try:
        # Wait for the ping to complete or timeout
        child.expect(pexpect.EOF, timeout=timeout)
        output = child.before.decode()
        print(f"Ping results for {host}:")
        print(output)
    except pexpect.TIMEOUT:
        print(f"Ping to {host} timed out after {timeout} seconds")
    except pexpect.EOF:
        print(f"Ping to {host} failed unexpectedly")
    finally:
        child.close()

# Example usage
ping_with_timeout('www.example.com')
ping_with_timeout('invalid-host', timeout=2)
```

This example demonstrates how to handle timeouts and unexpected termination when running a ping command.

## 5. Screen scraping and terminal control

pexpect can be used for screen scraping and terminal control, which is useful for automating interactions with full-screen applications like text editors. Let's create an example that interacts with the `nano` text editor. Add the following code to `pexpect_examples.py`:

```python
import pexpect

def automate_nano(filename, content):
    # Spawn nano
    child = pexpect.spawn(f'nano {filename}')

    try:
        # Wait for nano to start
        child.expect(r'\[.*\]')

        # Type the content
        child.send(content)

        # Save and exit
        child.send('\x1B\x18')  # Ctrl-X
        child.expect('Save modified buffer')
        child.send('y')
        child.expect('File Name to Write')
        child.send('\r')

        # Wait for nano to exit
        child.expect(pexpect.EOF)
        print(f"Successfully created and saved {filename}")
    except pexpect.TIMEOUT:
        print("Operation timed out")
    except pexpect.EOF:
        print("Unexpected error occurred")
    finally:
        child.close()

# Example usage
automate_nano('example.txt', 'This is some example content.\nCreated using pexpect and nano.')
```

This example shows how to automate the creation of a file using the nano text editor, demonstrating pexpect's ability to interact with full-screen applications.

## 6. Alternatives for Windows (wexpect)

pexpect doesn't work natively on Windows, but there's an alternative called wexpect that provides similar functionality. Here's how you can use wexpect on Windows. Add the following code to `pexpect_examples.py`:

```python
import sys

if sys.platform.startswith('win'):
    import wexpect as pexpect
else:
    import pexpect

def windows_example():
    # This will work on both Windows (using wexpect) and Unix-like systems (using pexpect)
    child = pexpect.spawn('echo Hello, World!')
    child.expect('Hello, World!')
    print("Received:", child.after.decode())

# Run the Windows example
windows_example()
```

This example demonstrates how to write code that works on both Windows and Unix-like systems by using wexpect as a drop-in replacement for pexpect on Windows.

## Cross-platform Considerations

When using pexpect (or wexpect on Windows), keep these cross-platform considerations in mind:

1. Use `sys.platform` to detect the operating system and choose between pexpect and wexpect.
2. Be aware that some commands and their outputs may differ between operating systems.
3. Use `os.path` for file path manipulations to ensure cross-platform compatibility.
4. When automating terminal-based applications, be mindful of differences in terminal emulation between platforms.
5. Consider using higher-level libraries like Fabric or Ansible for complex system administration tasks that need to work across multiple platforms.

## Conclusion

In this lesson, we've explored pexpect and its capabilities for automating interactive command-line programs. We've covered:

1. Introduction to pexpect and its basic usage
2. Automating interactive command-line programs
3. Sending and receiving data from child processes
4. Handling timeouts and errors
5. Screen scraping and terminal control
6. Alternatives for Windows (wexpect)

These skills are valuable for system administration, automated testing, and creating complex automation scripts.

To practice what you've learned, try the following exercises:

1. Create a script that automates the process of changing a user's password on a Unix-like system.
2. Develop a program that interacts with a command-line database tool (e.g., sqlite3) to perform CRUD operations.
3. Write a script that automates the process of connecting to a remote server via SSH, executing commands, and retrieving the results.
4. Create a tool that interacts with a text-based game, automating certain actions or gameplay elements.
5. Develop a cross-platform script that can interact with both Windows Command Prompt and Unix-like shells to perform system information gathering.

By mastering pexpect and its Windows alternative wexpect, you'll be able to create powerful automation scripts and interact with a wide variety of command-line tools and applications programmatically.

