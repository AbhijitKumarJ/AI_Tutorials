# Lesson 4: Modern Path Handling with pathlib

## Introduction

Welcome to the fourth lesson of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore the `pathlib` module, which was introduced in Python 3.4 and provides an object-oriented interface for working with file system paths. `pathlib` offers a more intuitive and consistent way to handle paths across different operating systems compared to the traditional `os.path` module.

## Why Use pathlib?

1. **Object-oriented**: Paths are represented as objects, not strings.
2. **Cross-platform**: Works consistently across Windows, macOS, and Linux.
3. **Simpler interface**: Many common operations are method calls on path objects.
4. **Type checking**: Different classes for different path types (e.g., `WindowsPath`, `PosixPath`).
5. **Reduced imports**: Many operations that previously required `os` or `os.path` are now methods on `Path` objects.

## Basic Usage of pathlib

Let's start with some basic operations using `pathlib`:

```python
from pathlib import Path

# Create a Path object
path = Path("documents/projects/python_project/main.py")

# Get the file name
print(f"File name: {path.name}")

# Get the stem (file name without extension)
print(f"File stem: {path.stem}")

# Get the file extension
print(f"File extension: {path.suffix}")

# Get the parent directory
print(f"Parent directory: {path.parent}")

# Get the absolute path
print(f"Absolute path: {path.absolute()}")

# Check if the path exists
print(f"Path exists: {path.exists()}")

# Check if it's a file
print(f"Is file: {path.is_file()}")

# Check if it's a directory
print(f"Is directory: {path.is_dir()}")
```

## Creating and Manipulating Paths

`pathlib` makes it easy to create and manipulate paths:

```python
from pathlib import Path

# Create a path using parts
path = Path("documents", "projects", "python_project", "main.py")
print(f"Path: {path}")

# Join paths
base_path = Path("documents/projects")
full_path = base_path / "python_project" / "main.py"
print(f"Full path: {full_path}")

# Resolve a path (follow symlinks and eliminate ".." components)
resolved_path = path.resolve()
print(f"Resolved path: {resolved_path}")

# Get the home directory
home = Path.home()
print(f"Home directory: {home}")

# Relative path
relative_path = path.relative_to(Path.cwd())
print(f"Relative path: {relative_path}")
```

## File Operations with pathlib

`pathlib` provides methods for common file operations:

```python
from pathlib import Path

# Write to a file
path = Path("example.txt")
path.write_text("Hello, pathlib!")
print("File written")

# Read from a file
content = path.read_text()
print(f"File content: {content}")

# Get file size
size = path.stat().st_size
print(f"File size: {size} bytes")

# Rename a file
new_path = path.rename("new_example.txt")
print(f"File renamed to: {new_path}")

# Delete a file
new_path.unlink()
print("File deleted")
```

## Directory Operations with pathlib

Working with directories is also straightforward with `pathlib`:

```python
from pathlib import Path

# Create a directory
dir_path = Path("new_directory")
dir_path.mkdir(exist_ok=True)
print(f"Directory created: {dir_path}")

# Create nested directories
nested_path = Path("parent/child/grandchild")
nested_path.mkdir(parents=True, exist_ok=True)
print(f"Nested directories created: {nested_path}")

# Iterate over directory contents
for item in dir_path.iterdir():
    print(item)

# Find files by pattern
py_files = list(dir_path.glob("*.py"))
print(f"Python files: {py_files}")

# Recursive search
all_py_files = list(dir_path.rglob("*.py"))
print(f"All Python files (recursive): {all_py_files}")

# Remove a directory
dir_path.rmdir()
print(f"Directory removed: {dir_path}")
```

## Comparing pathlib with os.path

Let's compare some common operations between `pathlib` and `os.path`:

```python
import os
from pathlib import Path

# Join paths
os_path = os.path.join("documents", "projects", "python_project", "main.py")
pathlib_path = Path("documents") / "projects" / "python_project" / "main.py"

print(f"os.path: {os_path}")
print(f"pathlib: {pathlib_path}")

# Get file name
os_name = os.path.basename(os_path)
pathlib_name = Path(os_path).name

print(f"os.path basename: {os_name}")
print(f"pathlib name: {pathlib_name}")

# Get directory name
os_dirname = os.path.dirname(os_path)
pathlib_dirname = Path(os_path).parent

print(f"os.path dirname: {os_dirname}")
print(f"pathlib parent: {pathlib_dirname}")

# Check if path exists
os_exists = os.path.exists(os_path)
pathlib_exists = Path(os_path).exists()

print(f"os.path exists: {os_exists}")
print(f"pathlib exists: {pathlib_exists}")
```

## Practical Example: File Type Analyzer

Let's create a practical example that uses `pathlib` to analyze file types in a directory:

```python
from pathlib import Path
from collections import defaultdict

def analyze_directory(directory):
    dir_path = Path(directory)
    if not dir_path.is_dir():
        raise ValueError(f"{directory} is not a valid directory")

    file_types = defaultdict(list)
    
    for file_path in dir_path.rglob("*"):
        if file_path.is_file():
            file_types[file_path.suffix.lower() or "no_extension"].append(file_path.name)

    return file_types

def print_analysis(file_types):
    print("File Type Analysis:")
    for file_type, files in sorted(file_types.items()):
        print(f"{file_type}: {len(files)} files")
        for file in sorted(files)[:5]:  # Print up to 5 examples
            print(f"  - {file}")
        if len(files) > 5:
            print(f"  ... and {len(files) - 5} more")
        print()

if __name__ == "__main__":
    import sys

    if len(sys.argv) != 2:
        print("Usage: python file_analyzer.py <directory>")
        sys.exit(1)

    try:
        file_types = analyze_directory(sys.argv[1])
        print_analysis(file_types)
    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)
```

Save this script as `file_analyzer.py` and run it with a target directory:

```bash
python file_analyzer.py /path/to/target/directory
```

This script will analyze the file types in the specified directory and its subdirectories, providing a summary of the different file extensions found.

## Cross-Platform Considerations

One of the major advantages of `pathlib` is its built-in cross-platform compatibility:

1. **Path separators**: `pathlib` automatically uses the correct path separator for the current operating system.

2. **Drive letters**: On Windows, `Path` objects handle drive letters correctly.

3. **UNC paths**: `pathlib` supports Windows UNC (Universal Naming Convention) paths.

4. **Case sensitivity**: `pathlib` respects the case sensitivity of the underlying file system.

Here's an example demonstrating some of these cross-platform features:

```python
from pathlib import Path, PureWindowsPath

# Current system path
path = Path("documents/projects/main.py")
print(f"Current system path: {path}")

# Windows-specific path
windows_path = PureWindowsPath("C:/Users/username/Documents/projects/main.py")
print(f"Windows path: {windows_path}")

# Convert between path flavors
posix_path = Path(windows_path)
print(f"Converted to current system path: {posix_path}")

# UNC path (Windows)
unc_path = PureWindowsPath("//server/share/file.txt")
print(f"UNC path: {unc_path}")
```

## Best Practices

1. Use `Path.home()` to get the user's home directory across platforms.
2. Use the `/` operator to join paths instead of string concatenation.
3. Use `Path.resolve()` to get the absolute path and resolve symlinks.
4. Use `Path.glob()` and `Path.rglob()` for flexible file matching.
5. Use `with` statements when opening files with `Path.open()`.
6. Prefer `pathlib` over `os.path` for new code, but be prepared to work with both in existing codebases.

## Conclusion

In this lesson, we've explored the `pathlib` module, which provides a powerful and intuitive object-oriented interface for working with file system paths. We've covered basic path operations, file and directory manipulations, and compared `pathlib` with the traditional `os.path` module. We've also created a practical file type analyzer script to demonstrate these concepts in action.

The `pathlib` module offers significant advantages in terms of readability, simplicity, and cross-platform compatibility. As you continue to work with file systems in Python, `pathlib` will be an invaluable tool in your programming toolkit.

## Exercises

1. Write a script that recursively searches for duplicate files in a directory based on their content (not just name). Use `pathlib` for file and directory operations.

2. Create a script that organizes photos by their creation date, moving them into year/month subdirectories. Use `pathlib` for path manipulations and file operations.

3. Implement a simple file backup system that copies files from a source directory to a backup directory, maintaining the directory structure. Only copy files that have been modified since the last backup.

4. Write a script that finds all broken symlinks in a directory tree. Use `pathlib`'s `is_symlink()` and `exists()` methods.

In the next lesson, we'll explore advanced file operations using the `shutil` module, which complements `pathlib` by providing high-level operations on files and collections of files.

