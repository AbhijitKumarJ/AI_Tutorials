# Lesson 18: Logging and Warnings

## Introduction

Welcome to Lesson 18 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore logging and warnings in Python. These features are essential for creating robust, maintainable applications by providing ways to record important information about your program's execution and alert users or developers to potential issues.

## Setting Up Our Project

Let's start by setting up a new project for this lesson. Here's our folder structure:

```
logging_warnings_tutorial/
│
├── src/
│   ├── basic_logging.py
│   ├── advanced_logging.py
│   ├── warnings_demo.py
│   └── config/
│       └── logging_config.ini
│
├── logs/
│   └── (log files will be created here)
│
└── requirements.txt
```

First, let's create a virtual environment and install the required packages:

```bash
python -m venv venv
source venv/bin/activate  # On Windows, use: venv\Scripts\activate
pip install colorlog
```

Create a `requirements.txt` file with the following content:

```
colorlog==6.7.0
```

## Basic Logging

Let's start with the basics of logging in Python. Create a file `src/basic_logging.py`:

```python
import logging

# Basic configuration
logging.basicConfig(level=logging.DEBUG, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    filename='logs/app.log')

# Creating a logger
logger = logging.getLogger(__name__)

def main():
    # Using different log levels
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")

    # Logging exceptions
    try:
        result = 10 / 0
    except ZeroDivisionError:
        logger.exception("Tried to divide by zero")

if __name__ == "__main__":
    main()
```

This script demonstrates:

1. Basic configuration of logging using `basicConfig`
2. Creating a logger instance
3. Using different log levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
4. Logging exceptions with traceback information

Run the script to see how different log messages are recorded:

```bash
python src/basic_logging.py
```

Check the `logs/app.log` file to see the logged messages.

## Advanced Logging

Now let's explore more advanced logging techniques. Create `src/advanced_logging.py`:

```python
import logging
import logging.config
import os
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
from colorlog import ColoredFormatter

# Ensure the logs directory exists
os.makedirs('logs', exist_ok=True)

# Custom logger class with color support
class ColorLogger(logging.Logger):
    def __init__(self, name):
        super().__init__(name)
        color_formatter = ColoredFormatter(
            "%(log_color)s%(levelname)-8s%(reset)s %(blue)s%(message)s",
            datefmt=None,
            reset=True,
            log_colors={
                'DEBUG':    'cyan',
                'INFO':     'green',
                'WARNING':  'yellow',
                'ERROR':    'red',
                'CRITICAL': 'red,bg_white',
            },
            secondary_log_colors={},
            style='%'
        )
        console = logging.StreamHandler()
        console.setFormatter(color_formatter)
        self.addHandler(console)

# Register the custom logger class
logging.setLoggerClass(ColorLogger)

# Create loggers
logger = logging.getLogger("main_logger")
logger.setLevel(logging.DEBUG)

# Create handlers
console_handler = logging.StreamHandler()
file_handler = RotatingFileHandler('logs/app_rotating.log', maxBytes=1024*1024, backupCount=5)
timed_handler = TimedRotatingFileHandler('logs/app_timed.log', when='midnight', interval=1, backupCount=7)

# Create formatters
console_format = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# Set formatters for handlers
console_handler.setFormatter(console_format)
file_handler.setFormatter(file_format)
timed_handler.setFormatter(file_format)

# Add handlers to logger
logger.addHandler(file_handler)
logger.addHandler(timed_handler)

def main():
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")

    # Demonstrate logging with extra parameters
    extra = {'user': 'John Doe', 'ip': '192.168.0.1'}
    logger.info("User logged in", extra=extra)

if __name__ == "__main__":
    main()

    # Demonstrate logging configuration from a file
    logging.config.fileConfig('src/config/logging_config.ini')
    config_logger = logging.getLogger("config_example")
    config_logger.debug("This message uses a configuration file")
```

Create a configuration file `src/config/logging_config.ini`:

```ini
[loggers]
keys=root,configExample

[handlers]
keys=consoleHandler

[formatters]
keys=simpleFormatter

[logger_root]
level=DEBUG
handlers=consoleHandler

[logger_configExample]
level=DEBUG
handlers=consoleHandler
qualname=config_example
propagate=0

[handler_consoleHandler]
class=StreamHandler
level=DEBUG
formatter=simpleFormatter
args=(sys.stdout,)

[formatter_simpleFormatter]
format=%(asctime)s - %(name)s - %(levelname)s - %(message)s
```

This script demonstrates:

1. Creating a custom logger class with color support
2. Using different handlers (console, rotating file, timed rotating file)
3. Configuring formatters for different handlers
4. Logging with extra parameters
5. Loading logging configuration from a file

Run the script to see advanced logging in action:

```bash
python src/advanced_logging.py
```

## Working with Warnings

Warnings are used to alert the programmer to possible issues or future changes in behavior. Let's explore how to use warnings in Python. Create `src/warnings_demo.py`:

```python
import warnings
import logging

# Configure logging to capture warnings
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def deprecated_function():
    warnings.warn("This function is deprecated", DeprecationWarning, stacklevel=2)
    print("Deprecated function called")

def main():
    # Simple warning
    warnings.warn("This is a warning message")

    # Warning of a specific category
    warnings.warn("This is a deprecation warning", DeprecationWarning)

    # Using the deprecated function
    deprecated_function()

    # Catching warnings
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")  # Always trigger all warnings
        warnings.warn("This is a caught warning", UserWarning)
        
        if len(w) == 1:
            print(f"Caught warning: {w[-1].message}")

    # Filtering warnings
    warnings.filterwarnings("ignore", category=DeprecationWarning)
    warnings.warn("This warning will be ignored", DeprecationWarning)

    # Turning warnings into exceptions
    warnings.filterwarnings("error", category=UserWarning)
    try:
        warnings.warn("This warning will raise an exception", UserWarning)
    except UserWarning:
        print("Caught UserWarning exception")

if __name__ == "__main__":
    main()
```

This script demonstrates:

1. Raising simple warnings
2. Using specific warning categories
3. Creating a deprecated function with a warning
4. Catching and inspecting warnings
5. Filtering warnings
6. Turning warnings into exceptions

Run the script to see how warnings work:

```bash
python src/warnings_demo.py
```

## Cross-Platform Considerations

While logging and warnings work consistently across different platforms, there are a few things to keep in mind:

1. **File paths**: When specifying log file paths, use `os.path.join()` to ensure cross-platform compatibility.

2. **Line endings**: Log files may have different line endings on Windows (\r\n) and Unix-like systems (\n). When processing log files, consider using the `universal newlines` mode when opening files.

3. **Console output**: Color support in console output may vary between platforms. Always provide a fallback for environments that don't support color output.

4. **File locking**: Some logging handlers that write to files may behave differently on different platforms due to file locking mechanisms. Test your logging setup on all target platforms.

5. **Default encoding**: Be aware that the default encoding may differ between platforms. Always specify the encoding explicitly when working with file handlers.

## Best Practices for Logging and Warnings

1. **Use appropriate log levels**: Use DEBUG for detailed information, INFO for general information, WARNING for potential issues, ERROR for more serious problems, and CRITICAL for critical errors that may cause the application to fail.

2. **Structure log messages**: Include relevant information in your log messages, such as timestamps, function names, and line numbers. Use a consistent format across your application.

3. **Use context managers**: When dealing with resources or specific code blocks, use context managers to ensure proper setup and teardown of logging.

4. **Configure logging at the application level**: Set up logging configuration at the start of your application to ensure consistent logging across all modules.

5. **Use warnings judiciously**: Use warnings to indicate deprecated features, runtime situations that are not necessarily exceptions, or to warn about pending changes in behavior.

6. **Don't abuse warnings**: Avoid using warnings for expected events or regular program flow. Use logging for such cases instead.

7. **Handle warnings appropriately**: Decide whether to ignore, log, or raise exceptions for different types of warnings based on their severity and impact on your application.

## Conclusion

In this lesson, we've explored logging and warnings in Python. We've covered basic and advanced logging techniques, including configuration, custom loggers, and various handlers. We've also looked at how to work with warnings, including raising, catching, and filtering them.

Proper logging and warning handling are crucial for creating maintainable and debuggable applications. They help you track the execution of your program, identify issues, and provide valuable information for troubleshooting and improving your code.

As you continue to develop Python applications, make sure to incorporate these logging and warning techniques to improve the reliability, maintainability, and user experience of your programs. Remember to consider cross-platform compatibility and follow best practices to ensure your logging and warning systems work effectively across different environments.

In the next lesson, we'll explore Abstract Syntax Tree (AST) analysis with the `grep_ast` package, which will allow us to parse and analyze Python code programmatically. Stay tuned!
