# Lesson 2: Package Management with pip and virtualenv

## Introduction

Welcome to the second lesson of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll dive into package management using pip and virtual environments. These tools are crucial for managing dependencies in Python projects and ensuring reproducibility across different systems.

## What is pip?

pip (Pip Installs Packages) is the standard package manager for Python. It allows you to install, upgrade, and manage Python packages from the Python Package Index (PyPI) and other package indexes.

### Installing pip

Most Python installations come with pip pre-installed. To check if pip is installed, run:

```bash
pip --version
```

If pip is not installed, you can download and run the official get-pip.py script:

```bash
curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
python get-pip.py
```

## Basic pip Usage

Here are some common pip commands:

1. Install a package:
   ```bash
   pip install package_name
   ```

2. Upgrade a package:
   ```bash
   pip install --upgrade package_name
   ```

3. Uninstall a package:
   ```bash
   pip uninstall package_name
   ```

4. List installed packages:
   ```bash
   pip list
   ```

5. Show information about a package:
   ```bash
   pip show package_name
   ```

## Virtual Environments

Virtual environments are isolated Python environments that allow you to install packages for specific projects without affecting your system-wide Python installation. This is crucial for managing dependencies across different projects.

### Why Use Virtual Environments?

1. **Isolation**: Each project can have its own dependencies, regardless of what dependencies every other project has.
2. **Reproducibility**: You can recreate the exact environment on a different machine.
3. **Clean System**: Your system Python installation remains clean and uncluttered.

### Creating and Managing Virtual Environments

Python 3.3+ comes with the `venv` module for creating virtual environments. For older versions, you can use the `virtualenv` package.

#### Using venv (Python 3.3+)

1. Create a new virtual environment:
   ```bash
   python -m venv myenv
   ```

2. Activate the virtual environment:
   - On Windows:
     ```
     myenv\Scripts\activate
     ```
   - On macOS and Linux:
     ```bash
     source myenv/bin/activate
     ```

3. Deactivate the virtual environment:
   ```bash
   deactivate
   ```

#### Using virtualenv (for older Python versions)

1. Install virtualenv:
   ```bash
   pip install virtualenv
   ```

2. Create a new virtual environment:
   ```bash
   virtualenv myenv
   ```

3. Activate and deactivate as shown above for venv.

## Project Structure with Virtual Environments

Here's a typical project structure using a virtual environment:

```
my_project/
│
├── myenv/            # Virtual environment directory
├── src/              # Source code
│   └── my_package/
│       ├── __init__.py
│       └── module.py
├── tests/            # Test files
├── requirements.txt  # Project dependencies
└── README.md         # Project documentation
```

## Installing Packages in a Virtual Environment

After activating your virtual environment, you can use pip to install packages. These packages will only be available within the virtual environment.

```bash
pip install requests
```

## Requirements Files

A `requirements.txt` file lists all the dependencies for your project. This makes it easy to recreate the environment on another machine.

1. Create a requirements.txt file:
   ```bash
   pip freeze > requirements.txt
   ```

2. Install packages from a requirements.txt file:
   ```bash
   pip install -r requirements.txt
   ```

## Practical Example: Creating a Web Scraping Project

Let's create a simple web scraping project to demonstrate these concepts.

1. Create and activate a virtual environment:
   ```bash
   python -m venv webscraper_env
   source webscraper_env/bin/activate  # On Windows, use webscraper_env\Scripts\activate
   ```

2. Install required packages:
   ```bash
   pip install requests beautifulsoup4
   ```

3. Create a new Python file `scraper.py`:

```python
import requests
from bs4 import BeautifulSoup

def scrape_python_org():
    url = "https://www.python.org"
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Extract the latest news titles
    news_titles = soup.select('#news-items ul.menu li a')
    
    print("Latest Python News:")
    for title in news_titles:
        print(f"- {title.text.strip()}")

if __name__ == "__main__":
    scrape_python_org()
```

4. Run the script:
   ```bash
   python scraper.py
   ```

5. Create a requirements.txt file:
   ```bash
   pip freeze > requirements.txt
   ```

Now you have a self-contained web scraping project with its own virtual environment and a requirements file for easy replication.

## Cross-Platform Considerations

While pip and virtual environments work similarly across platforms, there are some differences to keep in mind:

1. **Activation Scripts**: The activation script for virtual environments is different on Windows (`activate.bat` or `Activate.ps1`) compared to macOS/Linux (`activate`).

2. **Path Separators**: Use forward slashes (`/`) in your Python code for paths, even on Windows, to ensure cross-platform compatibility.

3. **Global vs. User Installs**: On Unix-like systems, global package installations may require sudo, while on Windows, they may require administrator privileges.

4. **Windows-specific Packages**: Some packages may have Windows-specific versions or dependencies. Always check the package documentation for any platform-specific instructions.

5. **Executable Scripts**: On Windows, pip installs scripts with `.exe` extensions, while on Unix-like systems, they're installed without extensions.

## Best Practices

1. **Always use virtual environments** for your projects to keep dependencies isolated.
2. **Include a requirements.txt file** in your project repositories.
3. **Use version pinning** in your requirements file (e.g., `requests==2.25.1`) to ensure reproducibility.
4. **Regularly update your dependencies**, but test thoroughly after updates.
5. **Don't commit your virtual environment** to version control; only commit the requirements.txt file.

## Conclusion

In this lesson, we've covered the basics of package management with pip and virtual environments. These tools are essential for any Python developer, allowing you to manage dependencies effectively and create reproducible development environments.

We've learned how to install and use pip, create and manage virtual environments, and work with requirements files. We've also created a practical web scraping project to demonstrate these concepts in action.

Understanding and using these tools will greatly improve your Python development workflow and help you manage complex projects with ease.

## Exercises

1. Create a new virtual environment and install the `requests` and `matplotlib` packages. Create a simple script that fetches data from a public API and plots it using matplotlib.

2. Take an existing Python project you have and convert it to use a virtual environment. Create a requirements.txt file for the project.

3. Create a new project that uses a package that has different versions for different operating systems (like `pywin32` for Windows). Write instructions in the README on how to set up the environment on different platforms.

4. Experiment with different pip commands, such as `pip search`, `pip check`, and `pip wheel`. Write a short explanation of what each command does and when it might be useful.

In the next lesson, we'll explore file system operations and path manipulation using the `os` and `sys` modules, building on the environment management skills we've learned here.

