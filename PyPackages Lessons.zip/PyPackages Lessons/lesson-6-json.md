# Lesson 6: Working with JSON Data

## Introduction

Welcome to Lesson 6 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll dive into working with JSON (JavaScript Object Notation) data in Python. JSON is a lightweight data interchange format that's easy for humans to read and write, and easy for machines to parse and generate. It's widely used for data storage and exchange, especially in web applications and APIs.

By the end of this lesson, you'll be comfortable reading, writing, and manipulating JSON data in Python, and you'll understand the nuances of working with JSON across different platforms.

## Prerequisites

Before we begin, make sure you have Python installed on your system. This lesson works with Python 3.6 and above. We'll be using the built-in `json` module, so no additional installations are required.

## Project Structure

Let's start by setting up a simple project structure. Create a new directory for this lesson and add the following files:

```
json_lesson/
│
├── data/
│   └── sample.json
│
├── json_basics.py
├── json_advanced.py
└── json_cross_platform.py
```

You can create this structure using the following commands:

On Unix-like systems (Linux/macOS):
```bash
mkdir -p json_lesson/data
touch json_lesson/data/sample.json
touch json_lesson/json_basics.py
touch json_lesson/json_advanced.py
touch json_lesson/json_cross_platform.py
```

On Windows:
```cmd
mkdir json_lesson
mkdir json_lesson\data
type nul > json_lesson\data\sample.json
type nul > json_lesson\json_basics.py
type nul > json_lesson\json_advanced.py
type nul > json_lesson\json_cross_platform.py
```

## 1. JSON Basics

Let's start with the basics of working with JSON in Python. Open `json_basics.py` and add the following code:

```python
import json

# Sample Python dictionary
person = {
    "name": "Alice",
    "age": 30,
    "city": "New York",
    "is_student": False,
    "grades": [85, 90, 88]
}

# Converting Python object to JSON string
json_string = json.dumps(person)
print("JSON string:")
print(json_string)

# Converting JSON string back to Python object
python_object = json.loads(json_string)
print("\nPython object:")
print(python_object)

# Writing JSON to a file
with open("data/sample.json", "w") as json_file:
    json.dump(person, json_file, indent=4)

# Reading JSON from a file
with open("data/sample.json", "r") as json_file:
    loaded_person = json.load(json_file)

print("\nLoaded from file:")
print(loaded_person)
```

Now, let's break down this code and explain each part:

1. We import the `json` module, which provides functions for working with JSON data.

2. We create a sample Python dictionary `person` with various data types (string, integer, boolean, list).

3. `json.dumps()` converts a Python object to a JSON string. This is useful when you need to send data over a network or store it in a format that requires a string.

4. `json.loads()` does the opposite, converting a JSON string back into a Python object.

5. `json.dump()` writes a Python object to a JSON file. The `indent` parameter makes the output file more readable by adding indentation.

6. `json.load()` reads a JSON file and converts it to a Python object.

Run this script to see how Python objects are converted to JSON and vice versa.

## 2. Advanced JSON Handling

Now let's look at some more advanced JSON handling techniques. Open `json_advanced.py` and add the following code:

```python
import json
from datetime import datetime

class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

def datetime_decoder(dct):
    for k, v in dct.items():
        if isinstance(v, str) and v.endswith(('Z', '+00:00')) and 'T' in v:
            try:
                dct[k] = datetime.fromisoformat(v.rstrip('Z'))
            except ValueError:
                pass
    return dct

# Sample data with a datetime object
data = {
    "name": "Event",
    "date": datetime.now(),
    "attendees": ["Alice", "Bob", "Charlie"]
}

# Custom encoding
json_string = json.dumps(data, cls=DateTimeEncoder, indent=4)
print("Encoded JSON:")
print(json_string)

# Custom decoding
decoded_data = json.loads(json_string, object_hook=datetime_decoder)
print("\nDecoded data:")
print(decoded_data)
print(f"Type of 'date': {type(decoded_data['date'])}")

# Handling large JSON files
def json_reader(file_path):
    BUFFER_SIZE = 1024
    with open(file_path, 'rb') as f:
        reader = json.JSONDecoder()
        buffer = ''
        for chunk in iter(lambda: f.read(BUFFER_SIZE), b''):
            buffer += chunk.decode('utf-8')
            while buffer:
                try:
                    result, index = reader.raw_decode(buffer)
                    yield result
                    buffer = buffer[index:]
                except json.JSONDecodeError:
                    break

# Example usage of json_reader
for item in json_reader('data/sample.json'):
    print(item)
```

Let's break down these advanced techniques:

1. **Custom JSON Encoding**: We define a `DateTimeEncoder` class that inherits from `json.JSONEncoder`. This allows us to customize how certain objects (in this case, `datetime` objects) are encoded to JSON.

2. **Custom JSON Decoding**: The `datetime_decoder` function is used as an object hook when decoding JSON. It looks for string values that look like ISO format dates and converts them back to `datetime` objects.

3. **Handling Large JSON Files**: The `json_reader` function demonstrates how to process large JSON files without loading the entire file into memory. It reads the file in chunks and yields JSON objects as they are parsed.

## 3. Cross-Platform Considerations

When working with JSON across different platforms, there are a few things to keep in mind. Open `json_cross_platform.py` and add the following code:

```python
import json
import os

# Sample data
data = {
    "name": "Cross-Platform App",
    "version": "1.0",
    "files": [
        "main.py",
        "config.json",
        "data/users.db"
    ]
}

# Writing JSON with proper line endings
def write_json_platform_safe(file_path, data):
    with open(file_path, 'w', newline='') as f:
        json.dump(data, f, indent=4)
    
    # Ensure consistent line endings
    with open(file_path, 'rb') as f:
        content = f.read()
    content = content.replace(b'\r\n', b'\n').replace(b'\r', b'\n')
    with open(file_path, 'wb') as f:
        f.write(content)

# Reading JSON and normalizing paths
def read_json_normalize_paths(file_path):
    with open(file_path, 'r') as f:
        data = json.load(f)
    
    if 'files' in data:
        data['files'] = [os.path.normpath(path) for path in data['files']]
    
    return data

# Write the JSON file
write_json_platform_safe('data/config.json', data)

# Read and normalize the JSON file
normalized_data = read_json_normalize_paths('data/config.json')

print("Normalized data:")
print(json.dumps(normalized_data, indent=4))

# Platform-specific path handling
print("\nPlatform-specific paths:")
for file_path in normalized_data['files']:
    print(os.path.abspath(file_path))
```

This script demonstrates several important cross-platform considerations:

1. **Line Endings**: Different operating systems use different line ending characters (Windows uses `\r\n`, while Unix-like systems use `\n`). The `write_json_platform_safe` function ensures that the JSON file is written with consistent line endings.

2. **Path Normalization**: The `read_json_normalize_paths` function demonstrates how to normalize file paths when reading JSON data. This is important because different platforms may use different path separators.

3. **Absolute Paths**: The last part of the script shows how to convert relative paths to absolute paths, which can be useful when your application needs to work with files across different platforms.

## Conclusion

In this lesson, we've covered the basics of working with JSON in Python, including reading and writing JSON data, handling complex data types, and considering cross-platform issues. Here's a summary of what we've learned:

1. Basic JSON operations: `json.dumps()`, `json.loads()`, `json.dump()`, and `json.load()`.
2. Advanced techniques: custom encoding/decoding and handling large JSON files.
3. Cross-platform considerations: consistent line endings and path normalization.

JSON is a versatile and widely-used data format, and mastering these techniques will be invaluable in your Python programming journey, especially when working on cross-platform applications or web services.

## Exercises

To reinforce your learning, try these exercises:

1. Create a JSON file containing a list of dictionaries, each representing a book with properties like title, author, and publication year. Write a Python script to read this file and print out all books published after a certain year.

2. Modify the `DateTimeEncoder` to also handle `date` objects. Then create a Python object with both `datetime` and `date` objects, encode it to JSON, and then decode it back to Python.

3. Write a script that recursively walks through a directory, collects information about all the files (name, size, last modified date), and saves this information as a JSON file. Ensure that your script works correctly on both Windows and Unix-like systems.

Remember, practice is key to mastering these concepts. Don't hesitate to experiment with the code and explore the `json` module's documentation for more features and options.

Happy coding!
