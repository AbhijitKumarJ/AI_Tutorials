# Lesson 10: Cross-platform System Information with platform

## Introduction

Welcome to Lesson 10 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore the `platform` module, which provides a wealth of information about the system on which your Python script is running. Understanding how to retrieve system information is crucial for writing cross-platform applications, performing system-specific optimizations, and debugging environment-related issues.

By the end of this lesson, you'll be able to gather detailed information about the operating system, Python environment, and hardware, and use this information to write more robust cross-platform code.

## Prerequisites

Before we begin, ensure you have Python installed on your system (Python 3.6 or later is recommended). We'll be using the built-in `platform` module, so no additional installations are required.

## Project Structure

Let's set up our project structure. Create a new directory for this lesson and add the following files:

```
platform_lesson/
│
├── system_info.py
├── python_info.py
└── hardware_info.py
```

You can create this structure using the following commands:

On Unix-like systems (Linux/macOS):
```bash
mkdir platform_lesson
touch platform_lesson/system_info.py
touch platform_lesson/python_info.py
touch platform_lesson/hardware_info.py
```

On Windows:
```cmd
mkdir platform_lesson
type nul > platform_lesson\system_info.py
type nul > platform_lesson\python_info.py
type nul > platform_lesson\hardware_info.py
```

## 1. System Information

Let's start by exploring how to retrieve basic system information. Open `system_info.py` and add the following code:

```python
import platform
import sys

def get_os_info():
    print("Operating System Information:")
    print(f"System: {platform.system()}")
    print(f"Release: {platform.release()}")
    print(f"Version: {platform.version()}")
    print(f"Platform: {platform.platform()}")
    if platform.system() == 'Darwin':
        print(f"Mac Version: {platform.mac_ver()[0]}")
    print(f"Processor: {platform.processor()}")

def get_linux_distribution():
    if platform.system() == 'Linux':
        try:
            print("Linux Distribution Information:")
            print(f"Distribution: {platform.freedesktop_os_release().get('NAME', 'Unknown')}")
            print(f"Version: {platform.freedesktop_os_release().get('VERSION', 'Unknown')}")
        except AttributeError:
            # platform.freedesktop_os_release() is available in Python 3.10+
            print("Linux distribution information is not available (requires Python 3.10+)")

def get_windows_info():
    if platform.system() == 'Windows':
        print("Windows Information:")
        print(f"Edition: {platform.win32_edition()}")
        print(f"Is 64-bit: {platform.machine().endswith('64')}")

def main():
    print(f"Running on Python {sys.version}")
    print("-" * 40)
    
    get_os_info()
    print("-" * 40)
    
    get_linux_distribution()
    print("-" * 40)
    
    get_windows_info()

if __name__ == "__main__":
    main()
```

Let's break down this code and explain each part:

1. **Basic OS Information**: We use various functions from the `platform` module to get information about the operating system, including its name, version, and release.

2. **Mac-specific Information**: For macOS (Darwin), we use `platform.mac_ver()` to get the macOS version.

3. **Linux Distribution Information**: On Linux systems, we use `platform.freedesktop_os_release()` (available in Python 3.10+) to get information about the specific distribution.

4. **Windows-specific Information**: For Windows, we use `platform.win32_edition()` to get the Windows edition and check if it's a 64-bit system.

## 2. Python Environment Information

Now let's gather information about the Python environment. Open `python_info.py` and add the following code:

```python
import platform
import sys
import site
import sysconfig

def get_python_info():
    print("Python Environment Information:")
    print(f"Python Version: {platform.python_version()}")
    print(f"Python Implementation: {platform.python_implementation()}")
    print(f"Python Compiler: {platform.python_compiler()}")
    print(f"Python Build: {platform.python_build()}")

def get_interpreter_info():
    print("\nInterpreter Information:")
    print(f"Executable: {sys.executable}")
    print(f"64-bit: {sys.maxsize > 2**32}")
    print(f"Byte Order: {sys.byteorder}")

def get_path_info():
    print("\nPython Path Information:")
    print(f"sys.prefix: {sys.prefix}")
    print(f"sys.exec_prefix: {sys.exec_prefix}")
    print(f"User site-packages: {site.getusersitepackages()}")
    print("\nSystem site-packages:")
    for path in site.getsitepackages():
        print(f"  {path}")

def get_config_info():
    print("\nPython Configuration:")
    config_vars = sysconfig.get_config_vars()
    important_vars = ['CC', 'LDFLAGS', 'CFLAGS', 'PY_CFLAGS', 'LIBDIR', 'BINDIR']
    for var in important_vars:
        if var in config_vars:
            print(f"{var}: {config_vars[var]}")

def main():
    get_python_info()
    get_interpreter_info()
    get_path_info()
    get_config_info()

if __name__ == "__main__":
    main()
```

Let's break down these functions:

1. **Python Version Information**: We use `platform` functions to get detailed information about the Python version, implementation, and build.

2. **Interpreter Information**: We use `sys` to get information about the Python interpreter, including its location and whether it's 64-bit.

3. **Path Information**: We use `sys` and `site` to get information about important Python paths, including site-packages directories.

4. **Configuration Information**: We use `sysconfig` to get compilation and installation configuration details.

## 3. Hardware Information

Finally, let's gather some hardware information. Open `hardware_info.py` and add the following code:

```python
import platform
import os
import multiprocessing
import socket
import uuid

def get_cpu_info():
    print("CPU Information:")
    print(f"Processor: {platform.processor()}")
    print(f"Machine: {platform.machine()}")
    print(f"CPU Count: {multiprocessing.cpu_count()}")

def get_memory_info():
    print("\nMemory Information:")
    if platform.system() == 'Linux':
        with open('/proc/meminfo', 'r') as f:
            mem_info = f.readlines()
        total_mem = [line for line in mem_info if 'MemTotal' in line][0].split()[1]
        print(f"Total Memory: {int(total_mem) // 1024} MB")
    elif platform.system() == 'Darwin':  # macOS
        total_mem = os.popen('sysctl -n hw.memsize').read().strip()
        print(f"Total Memory: {int(total_mem) // (1024 * 1024)} MB")
    elif platform.system() == 'Windows':
        total_mem = os.popen('wmic computersystem get totalphysicalmemory').read().split('\n')[1]
        print(f"Total Memory: {int(total_mem) // (1024 * 1024)} MB")
    else:
        print("Memory information not available for this platform.")

def get_disk_info():
    print("\nDisk Information:")
    if platform.system() in ['Linux', 'Darwin']:  # Linux or macOS
        disk_usage = os.statvfs('/')
        total_space = disk_usage.f_frsize * disk_usage.f_blocks
        free_space = disk_usage.f_frsize * disk_usage.f_bfree
        print(f"Total Disk Space: {total_space // (1024 * 1024 * 1024)} GB")
        print(f"Free Disk Space: {free_space // (1024 * 1024 * 1024)} GB")
    elif platform.system() == 'Windows':
        total_space = os.popen('wmic logicaldisk get size').read().split('\n')[1]
        free_space = os.popen('wmic logicaldisk get freespace').read().split('\n')[1]
        print(f"Total Disk Space: {int(total_space) // (1024 * 1024 * 1024)} GB")
        print(f"Free Disk Space: {int(free_space) // (1024 * 1024 * 1024)} GB")
    else:
        print("Disk information not available for this platform.")

def get_network_info():
    print("\nNetwork Information:")
    print(f"Hostname: {socket.gethostname()}")
    print(f"IP Address: {socket.gethostbyname(socket.gethostname())}")
    print(f"MAC Address: {':'.join(['{:02x}'.format((uuid.getnode() >> elements) & 0xff) for elements in range(0,2*6,2)][::-1])}")

def main():
    get_cpu_info()
    get_memory_info()
    get_disk_info()
    get_network_info()

if __name__ == "__main__":
    main()
```

Let's break down these functions:

1. **CPU Information**: We use `platform` and `multiprocessing` to get information about the processor and the number of CPU cores.

2. **Memory Information**: We use different methods to get memory information depending on the operating system.

3. **Disk Information**: We retrieve disk space information using OS-specific methods.

4. **Network Information**: We use `socket` and `uuid` modules to get network-related information like hostname, IP address, and MAC address.

## Cross-Platform Considerations

When working with system information across different platforms, keep these points in mind:

1. **OS-Specific Information**: Some information is only available on specific operating systems. Always check the platform before attempting to retrieve OS-specific details.

2. **Python Version Differences**: Some functions (like `platform.freedesktop_os_release()`) are only available in newer Python versions. Use version checks or try-except blocks to handle these cases.

3. **Hardware Information Retrieval**: Methods for retrieving hardware information can vary significantly between operating systems. You may need to use different approaches or external libraries for consistent results across platforms.

4. **Permissions**: Some system information may require elevated permissions to access, especially on Unix-like systems. Be prepared to handle permission-related errors.

5. **Internationalization**: On systems with non-English locales, some command outputs may be in different languages. Consider using language-independent methods or setting the locale when running shell commands.

## Conclusion

In this lesson, we've covered how to use the `platform` module and other Python standard library modules to retrieve a wide range of system information, including:

1. Operating system details
2. Python environment information
3. Hardware specifications
4. Network details

Understanding how to gather and use this information is crucial for writing cross-platform applications, performing system-specific optimizations, and debugging environment-related issues.

## Exercises

To reinforce your learning, try these exercises:

1. Write a function that determines if the current system meets the minimum requirements for a hypothetical application (e.g., minimum Python version, RAM, disk space).

2. Create a script that generates a detailed system report in a structured format like JSON or YAML, which could be used for remote system monitoring.

3. Implement a function that suggests the best Python package to use for a specific task based on the current system (e.g., suggesting `nvidia-cuda-runtime` for systems with NVIDIA GPUs on Linux).

4. Write a cross-platform script that checks for available system updates (e.g., using `apt` on Ubuntu, `brew` on macOS, or `winget` on Windows) and reports the results.

5. Create a simple benchmark tool that measures and reports on CPU performance, memory speed, and disk I/O across different platforms.

Remember, when working with system information, always consider the potential differences between platforms and handle exceptions that might occur due to missing information or insufficient permissions.

Happy coding!
