# Lesson 5: Advanced File Operations with shutil

## Introduction

Welcome to the fifth lesson of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore the `shutil` (shell utilities) module, which provides a higher-level interface for file and directory operations. The `shutil` module complements the `os` and `pathlib` modules we've previously discussed, offering more advanced operations like copying, moving, and archiving files and directories.

## Why Use shutil?

1. **High-level operations**: Provides functions for complex file operations that would otherwise require multiple steps.
2. **Cross-platform**: Works consistently across different operating systems.
3. **Error handling**: Includes built-in error handling for many common file operation issues.
4. **File metadata preservation**: Can preserve file metadata (permissions, timestamps, etc.) during copy operations.
5. **Archive handling**: Supports creating and extracting various archive formats.

## Basic File Operations with shutil

Let's start with some basic file operations using `shutil`:

```python
import shutil
from pathlib import Path

# Create some test files and directories
Path("source_file.txt").write_text("Hello, shutil!")
Path("source_dir").mkdir(exist_ok=True)
Path("source_dir/file1.txt").write_text("File 1 content")
Path("source_dir/file2.txt").write_text("File 2 content")

# Copy a file
shutil.copy("source_file.txt", "destination_file.txt")
print("File copied")

# Copy a file and preserve metadata
shutil.copy2("source_file.txt", "destination_file_with_metadata.txt")
print("File copied with metadata")

# Copy an entire directory
shutil.copytree("source_dir", "destination_dir")
print("Directory copied")

# Move a file
shutil.move("source_file.txt", "moved_file.txt")
print("File moved")

# Delete a directory and its contents
shutil.rmtree("source_dir")
print("Directory removed")
```

## Working with File Permissions

`shutil` provides functions to work with file permissions:

```python
import shutil
import os
from pathlib import Path

# Create a test file
test_file = Path("test_permissions.txt")
test_file.write_text("Testing permissions")

# Get current permissions
current_mode = test_file.stat().st_mode
print(f"Current permissions: {oct(current_mode)}")

# Change permissions
new_mode = 0o755  # rwxr-xr-x
os.chmod(test_file, new_mode)
print(f"New permissions: {oct(test_file.stat().st_mode)}")

# Copy file and preserve permissions
shutil.copy2(test_file, "test_permissions_copy.txt")
copy_mode = Path("test_permissions_copy.txt").stat().st_mode
print(f"Copied file permissions: {oct(copy_mode)}")
```

Note: On Windows, not all permission operations are applicable. The `chmod` function exists but has limited functionality.

## Disk Usage and File System Space

`shutil` provides a function to check disk usage:

```python
import shutil

total, used, free = shutil.disk_usage("/")
print(f"Total: {total // (2**30)} GiB")
print(f"Used: {used // (2**30)} GiB")
print(f"Free: {free // (2**30)} GiB")
```

## Working with Archives

`shutil` supports creating and extracting various archive formats:

```python
import shutil
from pathlib import Path

# Create some files to archive
Path("archive_dir").mkdir(exist_ok=True)
Path("archive_dir/file1.txt").write_text("File 1 content")
Path("archive_dir/file2.txt").write_text("File 2 content")

# Create a ZIP archive
shutil.make_archive("my_archive", "zip", "archive_dir")
print("ZIP archive created")

# Create a TAR archive
shutil.make_archive("my_archive", "tar", "archive_dir")
print("TAR archive created")

# Create a gzipped TAR archive
shutil.make_archive("my_archive", "gztar", "archive_dir")
print("Gzipped TAR archive created")

# Extract a ZIP archive
shutil.unpack_archive("my_archive.zip", "extracted_zip")
print("ZIP archive extracted")

# Clean up
shutil.rmtree("archive_dir")
shutil.rmtree("extracted_zip")
Path("my_archive.zip").unlink()
Path("my_archive.tar").unlink()
Path("my_archive.tar.gz").unlink()
```

## Practical Example: Backup Script

Let's create a practical example that uses `shutil` to create a backup of a directory:

```python
import shutil
import os
from pathlib import Path
from datetime import datetime

def create_backup(source_dir, backup_dir):
    source_path = Path(source_dir).resolve()
    if not source_path.is_dir():
        raise ValueError(f"{source_dir} is not a valid directory")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = Path(backup_dir) / f"backup_{timestamp}"

    try:
        shutil.copytree(source_path, backup_path)
        print(f"Backup created successfully: {backup_path}")

        # Create a zip archive of the backup
        shutil.make_archive(str(backup_path), "zip", backup_path)
        print(f"Zip archive created: {backup_path}.zip")

        # Remove the uncompressed backup directory
        shutil.rmtree(backup_path)

        return True
    except Exception as e:
        print(f"Backup failed: {e}")
        return False

if __name__ == "__main__":
    import sys

    if len(sys.argv) != 3:
        print("Usage: python backup_script.py <source_directory> <backup_directory>")
        sys.exit(1)

    source_dir = sys.argv[1]
    backup_dir = sys.argv[2]

    success = create_backup(source_dir, backup_dir)
    sys.exit(0 if success else 1)
```

Save this script as `backup_script.py` and run it with source and backup directories:

```bash
python backup_script.py /path/to/source/directory /path/to/backup/directory
```

This script will create a timestamped backup of the source directory, compress it into a zip file, and store it in the specified backup directory.

## Cross-Platform Considerations

While `shutil` aims to provide cross-platform functionality, there are some considerations to keep in mind:

1. **File permissions**: As mentioned earlier, file permission operations have limited functionality on Windows.

2. **Symbolic links**: The `copytree()` function's behavior with symbolic links varies between platforms. Use the `symlinks` parameter to control this behavior.

3. **File locking**: Some operations may fail on Windows if files are locked by other processes.

4. **Long path support**: On Windows, you might encounter issues with long paths. Use the `\\?\` prefix for paths to enable long path support.

Here's an example demonstrating some of these cross-platform considerations:

```python
import shutil
import os
import sys
from pathlib import Path

def copy_with_long_paths(src, dst):
    if sys.platform == "win32":
        src = "\\\\?\\" + os.path.abspath(src)
        dst = "\\\\?\\" + os.path.abspath(dst)
    
    shutil.copytree(src, dst, symlinks=True)

# Create a deep directory structure
deep_dir = Path("deep_directory/a/b/c/d/e/f/g/h/i/j")
deep_dir.mkdir(parents=True, exist_ok=True)
(deep_dir / "test_file.txt").write_text("Test content")

# Copy the deep directory
copy_with_long_paths("deep_directory", "deep_directory_copy")
print("Deep directory copied")

# Clean up
shutil.rmtree("deep_directory")
shutil.rmtree("deep_directory_copy")
```

## Best Practices

1. Use `shutil.copy2()` instead of `shutil.copy()` when you want to preserve file metadata.
2. Always use `shutil.rmtree()` with caution, as it recursively deletes directories.
3. Use `shutil.disk_usage()` to check for available space before performing large file operations.
4. When working with archives, prefer using `shutil.make_archive()` and `shutil.unpack_archive()` over lower-level zipfile or tarfile operations.
5. Handle exceptions when using `shutil` functions, especially for operations that might fail due to permissions or locked files.
6. Use `shutil.which()` to find the path to executable programs across platforms.

## Conclusion

In this lesson, we've explored the `shutil` module, which provides powerful tools for advanced file and directory operations in Python. We've covered file copying and moving, permission handling, disk usage checking, and working with archives. We've also created a practical backup script to demonstrate these concepts in action.

The `shutil` module complements the file system operations we've learned in previous lessons, allowing you to perform complex file management tasks with ease. As you continue to work with files and directories in Python, `shutil` will be an essential tool in your programming toolkit.

## Exercises

1. Create a script that synchronizes two directories, copying new and updated files from the source to the destination, and optionally deleting files in the destination that no longer exist in the source.

2. Write a program that monitors a directory for changes (new files, modified files, deleted files) and creates incremental backups when changes are detected. Use `shutil` for file operations and consider using the `watchdog` library for monitoring directory changes.

3. Implement a file cleanup utility that searches for and removes duplicate files in a directory tree. Use file hashing to identify duplicates and `shutil` to remove them.

4. Create a script that compresses old log files in a directory. Files older than a certain date should be compressed into a single archive, and the original files should be deleted to save space.

In the next lesson, we'll explore working with JSON data, which is a common format for storing and exchanging structured data in Python applications.

