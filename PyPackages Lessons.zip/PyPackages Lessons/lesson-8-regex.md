# Lesson 8: Regular Expressions for Pattern Matching

## Introduction

Welcome to Lesson 8 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll dive into regular expressions (regex) using Python's built-in `re` module. Regular expressions are powerful tools for pattern matching and text manipulation, essential for tasks like data validation, parsing, and text processing.

By the end of this lesson, you'll understand how to create and use regular expressions in Python, and you'll be equipped to handle complex pattern matching tasks across different platforms.

## Prerequisites

Before we begin, ensure you have Python installed on your system (Python 3.6 or later is recommended). We'll be using the built-in `re` module, so no additional installations are required.

## Project Structure

Let's set up our project structure. Create a new directory for this lesson and add the following files:

```
regex_lesson/
│
├── data/
│   ├── sample_text.txt
│   └── log_file.txt
│
├── regex_basics.py
├── regex_advanced.py
└── regex_cross_platform.py
```

You can create this structure using the following commands:

On Unix-like systems (Linux/macOS):
```bash
mkdir -p regex_lesson/data
touch regex_lesson/data/sample_text.txt
touch regex_lesson/data/log_file.txt
touch regex_lesson/regex_basics.py
touch regex_lesson/regex_advanced.py
touch regex_lesson/regex_cross_platform.py
```

On Windows:
```cmd
mkdir regex_lesson
mkdir regex_lesson\data
type nul > regex_lesson\data\sample_text.txt
type nul > regex_lesson\data\log_file.txt
type nul > regex_lesson\regex_basics.py
type nul > regex_lesson\regex_advanced.py
type nul > regex_lesson\regex_cross_platform.py
```

## 1. Regular Expression Basics

Let's start with the basics of using regular expressions in Python. Open `regex_basics.py` and add the following code:

```python
import re

def main():
    # Basic pattern matching
    pattern = r"python"
    text = "I love Python programming!"
    match = re.search(pattern, text, re.IGNORECASE)
    if match:
        print(f"Found '{match.group()}' at position {match.start()}")
    else:
        print("Pattern not found")

    # Character classes
    pattern = r"[aeiou]"
    text = "Hello, World!"
    vowels = re.findall(pattern, text, re.IGNORECASE)
    print(f"Vowels found: {vowels}")

    # Quantifiers
    pattern = r"\d+"
    text = "There are 123 apples and 456 oranges."
    numbers = re.findall(pattern, text)
    print(f"Numbers found: {numbers}")

    # Using groups
    pattern = r"(\w+),(\w+)"
    text = "Smith,John"
    match = re.match(pattern, text)
    if match:
        print(f"Last name: {match.group(1)}, First name: {match.group(2)}")

    # Splitting text
    pattern = r"[,;\s]+"
    text = "apple,banana;cherry grape"
    fruits = re.split(pattern, text)
    print(f"Fruits: {fruits}")

    # Substitution
    pattern = r"(\d{3})-(\d{3})-(\d{4})"
    text = "Phone: 123-456-7890"
    formatted = re.sub(pattern, r"(\1) \2-\3", text)
    print(f"Formatted: {formatted}")

if __name__ == "__main__":
    main()
```

Let's break down this code and explain each part:

1. **Basic Pattern Matching**: We use `re.search()` to find a pattern in the text. The `re.IGNORECASE` flag makes the search case-insensitive.

2. **Character Classes**: `[aeiou]` matches any single vowel. We use `re.findall()` to find all occurrences.

3. **Quantifiers**: `\d+` matches one or more digits. Again, we use `re.findall()` to get all matches.

4. **Groups**: Parentheses `()` create capturing groups. We use `re.match()` to match from the start of the string and access groups with `group()` method.

5. **Splitting Text**: `re.split()` is used to split the text based on a pattern.

6. **Substitution**: `re.sub()` is used to replace patterns in the text. `\1`, `\2`, etc., refer to captured groups.

## 2. Advanced Regular Expression Techniques

Now let's explore some more advanced regex techniques. Open `regex_advanced.py` and add the following code:

```python
import re

def main():
    # Lookahead and lookbehind
    text = "I have $100 and £200"
    pattern = r"(?<=\$)\d+"  # Positive lookbehind
    dollars = re.search(pattern, text)
    print(f"Dollars: {dollars.group() if dollars else 'Not found'}")

    pattern = r"\d+(?=\s*pounds)"  # Positive lookahead
    text = "I have 300 pounds"
    pounds = re.search(pattern, text, re.IGNORECASE)
    print(f"Pounds: {pounds.group() if pounds else 'Not found'}")

    # Non-capturing groups
    pattern = r"(?:Mr|Mrs|Ms)\s(\w+)"
    text = "Mr Smith and Mrs Johnson"
    names = re.findall(pattern, text)
    print(f"Names: {names}")

    # Greedy vs non-greedy matching
    pattern_greedy = r"<.*>"
    pattern_non_greedy = r"<.*?>"
    text = "<p>This is a paragraph.</p><p>This is another paragraph.</p>"
    print(f"Greedy: {re.findall(pattern_greedy, text)}")
    print(f"Non-greedy: {re.findall(pattern_non_greedy, text)}")

    # Named groups
    pattern = r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})"
    text = "Date: 2023-05-15"
    match = re.search(pattern, text)
    if match:
        print(f"Year: {match.group('year')}, Month: {match.group('month')}, Day: {match.group('day')}")

    # Using flags
    pattern = r"""
    (\d{3})  # Area code
    \s*-?\s*  # Optional separator
    (\d{3})  # First 3 digits
    \s*-?\s*  # Optional separator
    (\d{4})  # Last 4 digits
    """
    text = "My phone number is 123 456 7890"
    match = re.search(pattern, text, re.VERBOSE)
    if match:
        print(f"Phone: ({match.group(1)}) {match.group(2)}-{match.group(3)}")

if __name__ == "__main__":
    main()
```

Let's break down these advanced techniques:

1. **Lookahead and Lookbehind**: These are zero-width assertions. Lookahead (`(?=...)`) asserts what follows, while lookbehind (`(?<=...)`) asserts what precedes.

2. **Non-capturing Groups**: `(?:...)` creates a group that doesn't capture.

3. **Greedy vs Non-greedy Matching**: By default, quantifiers are greedy. Adding `?` after a quantifier makes it non-greedy.

4. **Named Groups**: `(?P<name>...)` creates a named group, which can be accessed by name.

5. **Flags**: `re.VERBOSE` allows you to write more readable regular expressions by ignoring whitespace and allowing comments.

## 3. Cross-Platform Considerations

When using regular expressions across different platforms, there are a few things to keep in mind. Open `regex_cross_platform.py` and add the following code:

```python
import re
import os

def main():
    # Handling different line endings
    text = "Line 1\r\nLine 2\nLine 3\rLine 4"
    lines = re.split(r'\r\n|\n|\r', text)
    print("Lines split by different newlines:", lines)

    # File path matching
    def normalize_path(path):
        return os.path.normpath(path).replace(os.sep, '/')

    windows_path = r"C:\Users\John\Documents\file.txt"
    unix_path = "/home/john/documents/file.txt"

    pattern = r"(.+)/([^/]+)\.txt$"
    
    for path in [windows_path, unix_path]:
        normalized = normalize_path(path)
        match = re.search(pattern, normalized)
        if match:
            print(f"For path: {path}")
            print(f"  Directory: {match.group(1)}")
            print(f"  Filename: {match.group(2)}")

    # Matching file contents with different encodings
    encodings = ['utf-8', 'latin-1', 'utf-16']
    text = "Héllo, wörld!"
    pattern = r"H.llo,\s*w.rld!"

    for encoding in encodings:
        byte_string = text.encode(encoding)
        if re.search(pattern.encode(encoding), byte_string):
            print(f"Pattern matched in {encoding} encoding")

    # Date format matching
    date_formats = [
        "2023-05-15",  # ISO format
        "15/05/2023",  # Common in Europe
        "05/15/2023",  # Common in US
    ]
    patterns = [
        r"(\d{4})-(\d{2})-(\d{2})",
        r"(\d{2})/(\d{2})/(\d{4})",
        r"(\d{2})/(\d{2})/(\d{4})",
    ]

    for date, pattern in zip(date_formats, patterns):
        match = re.match(pattern, date)
        if match:
            print(f"Matched date: {date}")
            print(f"  Year: {match.group(3 if '/' in date else 1)}")
            print(f"  Month: {match.group(2)}")
            print(f"  Day: {match.group(1 if '/' in date else 3)}")

if __name__ == "__main__":
    main()
```

This script demonstrates several important cross-platform considerations:

1. **Line Endings**: Different operating systems use different line ending characters. We use a regex that matches all common line endings.

2. **File Paths**: We normalize file paths to use forward slashes, which allows us to use a single regex pattern for both Windows and Unix-like paths.

3. **Text Encodings**: When working with text in different encodings, it's important to encode both the pattern and the text consistently.

4. **Date Formats**: Different regions use different date formats. We demonstrate how to match and parse various date formats using regex.

## Conclusion

In this lesson, we've covered the fundamentals of regular expressions in Python, including:

1. Basic pattern matching, character classes, and quantifiers
2. Advanced techniques like lookarounds, non-greedy matching, and named groups
3. Cross-platform considerations for line endings, file paths, text encodings, and date formats

Regular expressions are a powerful tool for text processing and pattern matching. While they can be complex, mastering them will greatly enhance your ability to work with text data efficiently across different platforms.

## Exercises

To reinforce your learning, try these exercises:

1. Write a regex to validate email addresses. Consider the various forms an email address can take.

2. Create a regex to extract all URLs from a given text. Consider both http and https URLs.

3. Write a function that takes a filename as input and uses regex to determine if it's a valid filename for both Windows and Unix-like systems.

4. Implement a log parser that extracts timestamps, log levels, and messages from a log file. Consider different log formats.

5. Create a regex to validate and parse complex password requirements (e.g., at least one uppercase letter, one lowercase letter, one number, and one special character).

Remember, the key to mastering regular expressions is practice. Don't hesitate to use online regex testers to visualize and debug your patterns.

Happy coding!
