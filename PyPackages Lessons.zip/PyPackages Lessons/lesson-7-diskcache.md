# Lesson 7: Efficient Data Caching with diskcache

## Introduction

Welcome to Lesson 7 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore efficient data caching using the `diskcache` package. Caching is a technique used to store and retrieve frequently accessed data quickly, reducing computation time and improving application performance.

The `diskcache` package provides a disk-based cache implementation that's fast, persistent, and supports a variety of data types. It's particularly useful for applications that need to cache large amounts of data or maintain cache between program runs.

By the end of this lesson, you'll understand how to implement caching in your Python programs, improving their efficiency and responsiveness.

## Prerequisites

Before we begin, make sure you have Python installed on your system (Python 3.6 or later is recommended). You'll also need to install the `diskcache` package. You can install it using pip:

```bash
pip install diskcache
```

## Project Structure

Let's set up our project structure. Create a new directory for this lesson and add the following files:

```
diskcache_lesson/
│
├── cache/
│
├── basic_caching.py
├── advanced_caching.py
└── cross_platform_caching.py
```

You can create this structure using the following commands:

On Unix-like systems (Linux/macOS):
```bash
mkdir -p diskcache_lesson/cache
touch diskcache_lesson/basic_caching.py
touch diskcache_lesson/advanced_caching.py
touch diskcache_lesson/cross_platform_caching.py
```

On Windows:
```cmd
mkdir diskcache_lesson
mkdir diskcache_lesson\cache
type nul > diskcache_lesson\basic_caching.py
type nul > diskcache_lesson\advanced_caching.py
type nul > diskcache_lesson\cross_platform_caching.py
```

## 1. Basic Caching with diskcache

Let's start with the basics of using `diskcache`. Open `basic_caching.py` and add the following code:

```python
from diskcache import Cache
import time

# Create a Cache object
cache = Cache('./cache')

def expensive_operation(n):
    """Simulate an expensive operation."""
    time.sleep(2)  # Simulate a 2-second computation
    return n ** 2

def cached_operation(n):
    """Cached version of the expensive operation."""
    # Check if the result is in the cache
    if n in cache:
        print(f"Cache hit for {n}")
        return cache[n]
    
    # If not in cache, compute the result and store it
    print(f"Cache miss for {n}, computing...")
    result = expensive_operation(n)
    cache[n] = result
    return result

# Using the cached operation
for i in range(5):
    start_time = time.time()
    result = cached_operation(i)
    end_time = time.time()
    print(f"Result for {i}: {result}, Time taken: {end_time - start_time:.2f} seconds")

# Clear the cache
cache.clear()

print("\nCache statistics:")
print(f"Cache size: {len(cache)}")
print(f"Cache directory: {cache.directory}")
```

Let's break down this code and explain each part:

1. We import the `Cache` class from `diskcache` and the `time` module for our simulated expensive operation.

2. We create a `Cache` object, specifying the directory where the cache files will be stored.

3. The `expensive_operation` function simulates a time-consuming computation.

4. `cached_operation` is a wrapper that checks the cache before performing the expensive operation. If the result is in the cache, it's returned immediately. Otherwise, the operation is performed, and its result is stored in the cache.

5. We demonstrate the caching behavior by calling `cached_operation` multiple times with different inputs.

6. Finally, we clear the cache and print some cache statistics.

Run this script to see how caching improves performance for repeated operations.

## 2. Advanced Caching Techniques

Now let's explore some more advanced features of `diskcache`. Open `advanced_caching.py` and add the following code:

```python
from diskcache import FanoutCache, Deque
import time
from functools import wraps

# Create a FanoutCache object for better concurrency
cache = FanoutCache('./cache', shards=4, timeout=1)

# Decorator for caching function results
def cached(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        key = str(args) + str(kwargs)
        result = cache.get(key, default=None)
        if result is None:
            result = func(*args, **kwargs)
            cache.set(key, result, expire=3600)  # Cache for 1 hour
        return result
    return wrapper

@cached
def fibonacci(n):
    """Calculate the nth Fibonacci number."""
    if n < 2:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Using the cached fibonacci function
for i in range(35):
    start_time = time.time()
    result = fibonacci(i)
    end_time = time.time()
    print(f"Fibonacci({i}) = {result}, Time: {end_time - start_time:.6f} seconds")

# Using Deque as a persistent list
queue = Deque(directory='./cache/queue')
for i in range(5):
    queue.append(f"Item {i}")

print("\nQueue contents:")
for item in queue:
    print(item)

# Tag-based invalidation
cache.set('user:1', {'name': 'Alice', 'age': 30}, tag='users')
cache.set('user:2', {'name': 'Bob', 'age': 25}, tag='users')

print("\nUsers before invalidation:")
print(cache.get('user:1'))
print(cache.get('user:2'))

# Invalidate all items with the 'users' tag
cache.evict('users')

print("\nUsers after invalidation:")
print(cache.get('user:1'))
print(cache.get('user:2'))

# Clear the cache
cache.clear()
queue.clear()
```

Let's break down these advanced techniques:

1. **FanoutCache**: This is a cache implementation that uses multiple shards for better concurrency in multi-threaded applications.

2. **Caching Decorator**: We define a `cached` decorator that can be applied to any function to automatically cache its results based on the input arguments.

3. **Expiration**: When setting cache items, we can specify an `expire` parameter to automatically invalidate the cache after a certain time.

4. **Persistent Queue**: `diskcache.Deque` provides a disk-based double-ended queue that persists between program runs.

5. **Tag-based Invalidation**: We can associate cache items with tags and then invalidate all items with a specific tag at once.

## 3. Cross-Platform Considerations

When using `diskcache` across different platforms, there are a few things to keep in mind. Open `cross_platform_caching.py` and add the following code:

```python
import os
from diskcache import Cache
import tempfile
import shutil

def get_cache_dir():
    """Get a suitable cache directory for the current platform."""
    if os.name == 'nt':  # Windows
        return os.path.join(os.environ.get('LOCALAPPDATA', tempfile.gettempdir()), 'MyAppCache')
    else:  # macOS and Linux
        return os.path.join(os.path.expanduser('~'), '.cache', 'MyAppCache')

# Create a cache using the platform-specific directory
cache_dir = get_cache_dir()
cache = Cache(cache_dir)

# Example usage
cache['platform'] = os.name
cache['python_version'] = '.'.join(map(str, os.sys.version_info[:3]))

print(f"Cache directory: {cache.directory}")
print(f"Platform: {cache['platform']}")
print(f"Python version: {cache['python_version']}")

# Handling file path differences
if os.name == 'nt':
    file_path = r'C:\path\to\file.txt'
else:
    file_path = '/path/to/file.txt'

cache['important_file'] = os.path.normpath(file_path)

print(f"Stored file path: {cache['important_file']}")

# Ensuring cache size doesn't exceed platform limits
max_size = 1_000_000_000  # 1 GB
current_size = sum(os.path.getsize(os.path.join(dp, f)) for dp, dn, fn in os.walk(cache_dir) for f in fn)
if current_size > max_size:
    print(f"Cache size ({current_size} bytes) exceeds limit. Clearing cache...")
    cache.clear()
    print("Cache cleared.")

# Proper cache cleanup
cache.close()
shutil.rmtree(cache_dir, ignore_errors=True)
print("Cache cleaned up.")
```

This script demonstrates several important cross-platform considerations:

1. **Cache Directory**: We use a function `get_cache_dir()` to determine an appropriate cache directory based on the operating system. On Windows, we use the `LOCALAPPDATA` environment variable, while on Unix-like systems, we use the `.cache` directory in the user's home folder.

2. **Platform Information**: We store platform-specific information in the cache, which can be useful for debugging or platform-specific optimizations.

3. **File Path Handling**: We demonstrate how to handle file paths, which differ between Windows and Unix-like systems. We use `os.path.normpath()` to ensure consistent path formatting.

4. **Cache Size Management**: We check the size of the cache directory and clear it if it exceeds a certain limit. This is important because different platforms may have different storage constraints.

5. **Cleanup**: We show how to properly close the cache and clean up the cache directory when it's no longer needed.

## Conclusion

In this lesson, we've covered the basics of efficient data caching using the `diskcache` package, including:

1. Basic caching operations with `Cache`
2. Advanced techniques like function result caching, expiration, and tag-based invalidation
3. Cross-platform considerations for cache directory location and file path handling

Caching is a powerful technique for improving the performance of your Python applications, especially when dealing with expensive computations or frequent data access. The `diskcache` package provides a robust, cross-platform solution for implementing caching in your projects.

## Exercises

To reinforce your learning, try these exercises:

1. Implement a caching system for a web scraping application. Cache the content of web pages to avoid repeatedly downloading the same data.

2. Create a simple key-value store application using `diskcache` that allows users to set, get, and delete key-value pairs. Include features like automatic expiration and size limits.

3. Modify the Fibonacci example to use memoization with `diskcache`. Compare the performance with and without caching for large Fibonacci numbers.

4. Implement a caching layer for a database application. Cache query results to reduce database load, and implement cache invalidation when the database is updated.

Remember, the key to mastering caching is understanding when and how to use it effectively. Consider the trade-offs between memory usage, disk space, and computation time in your specific use cases.

Happy coding!
