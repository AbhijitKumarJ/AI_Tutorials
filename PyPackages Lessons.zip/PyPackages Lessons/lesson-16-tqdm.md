Certainly! I'll create Lesson 16 of the "Mastering Python Packages for Efficient Programming" series, focusing on progress bars and status indicators with tqdm. I'll make sure to provide a thorough explanation with examples, including folder layouts, and address any cross-platform considerations.



# Lesson 16: Progress Bars and Status Indicators with tqdm

## Introduction

Welcome to Lesson 16 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore the `tqdm` package, which allows us to easily add progress bars and status indicators to our Python programs. This is especially useful when working with long-running operations or processing large datasets.

## What is tqdm?

`tqdm` is a fast, extensible progress bar library for Python. Its name comes from the Arabic word taqaddum (تقدّم), which means "progress." It's designed to be easy to use, highly customizable, and works well in various environments, including terminals, Jupyter notebooks, and GUI applications.

## Setting Up Our Project

Let's start by setting up a new project for this lesson. Here's our folder structure:

```
tqdm_tutorial/
│
├── data/
│   └── large_file.txt
│
├── scripts/
│   ├── basic_usage.py
│   ├── custom_progress.py
│   ├── nested_progress.py
│   └── pandas_integration.py
│
└── requirements.txt
```

First, let's create a virtual environment and install the required packages:

```bash
python -m venv venv
source venv/bin/activate  # On Windows, use: venv\Scripts\activate
pip install tqdm pandas numpy
```

Create a `requirements.txt` file with the following content:

```
tqdm==4.65.0
pandas==1.5.3
numpy==1.24.3
```

## Basic Usage of tqdm

Let's start with a simple example to understand how tqdm works. Create a file `scripts/basic_usage.py`:

<antArtifact identifier="basic-usage-py" type="application/vnd.ant.code" language="python" title="scripts/basic_usage.py">
import time
from tqdm import tqdm

# Simple iteration
for i in tqdm(range(100)):
    time.sleep(0.1)  # Simulate some work

# List processing
my_list = [1, 2, 3, 4, 5]
for item in tqdm(my_list, desc="Processing items"):
    time.sleep(0.5)  # Simulate processing each item

# Manual control
with tqdm(total=100, desc="Manual progress") as pbar:
    for i in range(10):
        time.sleep(0.1)
        pbar.update(10)


In this example, we demonstrate three ways to use tqdm:

1. Wrapping an iterable (range) directly with tqdm.
2. Processing a list with a custom description.
3. Manually controlling the progress bar.

Run the script to see the progress bars in action:

```bash
python scripts/basic_usage.py
```

You should see three progress bars appearing one after another in your terminal.

## Customizing Progress Bars

tqdm offers many customization options. Let's explore some of them in `scripts/custom_progress.py`:

```python
import time
from tqdm import tqdm

# Customized progress bar
for i in tqdm(range(100), 
              desc="Customized bar", 
              ncols=100, 
              unit="step", 
              bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]"):
    time.sleep(0.1)

# Color and ASCII options (UNIX-like systems only)
for i in tqdm(range(100), 
              desc="Colored bar", 
              colour="green", 
              ascii=True):
    time.sleep(0.1)

# Dynamic description updates
with tqdm(total=100, desc="Dynamic updates") as pbar:
    for i in range(10):
        time.sleep(0.5)
        pbar.set_description(f"Step {i+1}/10")
        pbar.update(10)

```

This script demonstrates:

1. A customized progress bar with a specific width, unit, and format.
2. A colored progress bar using ASCII characters (note: colors work on UNIX-like systems, but may not work on all Windows terminals).
3. A progress bar with dynamic description updates.

Run the script to see these customized progress bars:

```bash
python scripts/custom_progress.py
```

## Nested Progress Bars

tqdm allows you to create nested progress bars, which is useful for tracking progress of nested loops or hierarchical tasks. Let's create `scripts/nested_progress.py`:

```python
import time
from tqdm import tqdm

# Nested progress bars
for i in tqdm(range(3), desc="Outer loop"):
    time.sleep(0.5)
    for j in tqdm(range(100), desc=f"Inner loop {i+1}", leave=False):
        time.sleep(0.01)

# Manually controlled nested bars
with tqdm(total=3, desc="Main task") as main_pbar:
    for i in range(3):
        with tqdm(total=100, desc=f"Subtask {i+1}", leave=False) as sub_pbar:
            for j in range(100):
                time.sleep(0.01)
                sub_pbar.update()
        main_pbar.update()

```

This script shows two ways to create nested progress bars:

1. Using nested tqdm-wrapped loops.
2. Manually controlling nested progress bars using context managers.

Run the script to see the nested progress bars:

```bash
python scripts/nested_progress.py
```

## Integration with Pandas and NumPy

tqdm integrates well with popular data processing libraries like Pandas and NumPy. Let's create `scripts/pandas_integration.py` to demonstrate this:

```python
import pandas as pd
import numpy as np
from tqdm import tqdm

# Create a sample DataFrame
df = pd.DataFrame(np.random.rand(1000000, 5), columns=['A', 'B', 'C', 'D', 'E'])

# Use tqdm with pandas apply
df['F'] = df.progress_apply(lambda row: row['A'] + row['B'] + row['C'], axis=1)

# Use tqdm with pandas iterrows
for index, row in tqdm(df.iterrows(), total=df.shape[0], desc="Processing rows"):
    # Simulate some processing
    _ = row['D'] * row['E']

# Use tqdm with numpy operations
arr = np.random.rand(1000000)
for _ in tqdm(range(100), desc="NumPy operations"):
    np.sum(arr)
    np.mean(arr)
    np.std(arr)

```

This script demonstrates:

1. Using tqdm with Pandas' `apply` method.
2. Using tqdm with Pandas' `iterrows` method.
3. Using tqdm with NumPy operations.

Before running this script, we need to enable the Pandas integration. Add the following lines at the beginning of the script:

```python
import pandas as pd
import numpy as np
from tqdm import tqdm
tqdm.pandas()
```

Now, run the script:

```bash
python scripts/pandas_integration.py
```

## Cross-Platform Considerations

While tqdm works well across different platforms, there are a few things to keep in mind:

1. **Colors**: On Windows, colors may not work in all terminals. You can use the `colorama` package to enable colors on Windows.

2. **Unicode support**: Some older Windows versions might have issues with Unicode characters. In such cases, use `ascii=True` when creating progress bars.

3. **Terminal width**: tqdm tries to auto-detect the terminal width, but this might not work correctly in all environments. You can manually set the width using the `ncols` parameter.

4. **Jupyter Notebooks**: tqdm has special integration for Jupyter Notebooks. Use `from tqdm.notebook import tqdm` when working in Jupyter environments.

5. **GUI applications**: For non-terminal environments, consider using `tqdm.gui.tqdm` instead of the regular `tqdm`.

To ensure maximum compatibility, you can create a helper function that chooses the appropriate tqdm variant:

```python
import sys
import os

def get_tqdm(**kwargs):
    if hasattr(sys, 'ps1'):
        # Interactive Python shell
        from tqdm import tqdm
        return tqdm(**kwargs)
    elif 'JPY_PARENT_PID' in os.environ:
        # Jupyter notebook
        from tqdm.notebook import tqdm
        return tqdm(**kwargs)
    elif os.name == 'nt':
        # Windows
        from tqdm import tqdm
        try:
            import colorama
            colorama.init()
        except ImportError:
            kwargs['ascii'] = True
        return tqdm(**kwargs)
    else:
        # UNIX-like systems
        from tqdm import tqdm
        return tqdm(**kwargs)

```

By using this helper function, you can ensure that your progress bars work well across different environments.

## Conclusion

In this lesson, we've explored the tqdm package and learned how to add progress bars and status indicators to our Python programs. We've covered basic usage, customization options, nested progress bars, and integration with Pandas and NumPy. We've also discussed cross-platform considerations to ensure our progress bars work well in different environments.

Progress bars are an essential tool for providing visual feedback in long-running operations, making our programs more user-friendly and informative. As you continue to develop Python applications, consider incorporating tqdm to enhance the user experience and provide better insights into the progress of your operations.

In the next lesson, we'll dive into exception handling and tracebacks, which are crucial for writing robust and maintainable Python code. Stay tuned!
</antArtifact>

This lesson provides a comprehensive introduction to tqdm, covering its basic usage, customization options, integration with other libraries, and cross-platform considerations. The examples are structured in a way that gradually builds up the complexity, making it easy for beginners to follow along and understand the concepts. The folder structure and sample code files help visualize the project organization, and the cross-platform section addresses potential issues that may arise on different operating systems.