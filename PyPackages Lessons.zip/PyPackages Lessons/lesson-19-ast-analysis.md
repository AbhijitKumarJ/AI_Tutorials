# Lesson 19: Abstract Syntax Tree Analysis with grep_ast

## Introduction

Welcome to Lesson 19 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore Abstract Syntax Tree (AST) analysis using the `grep_ast` package. AST analysis allows us to parse and analyze Python code programmatically, which is useful for tasks such as code analysis, refactoring, and static code checking.

## Setting Up Our Project

Let's start by setting up a new project for this lesson. Here's our folder structure:

```
ast_analysis_tutorial/
│
├── src/
│   ├── basic_ast_analysis.py
│   ├── advanced_ast_analysis.py
│   ├── code_transformation.py
│   └── sample_code/
│       ├── example1.py
│       ├── example2.py
│       └── example3.py
│
├── tests/
│   └── test_ast_analysis.py
│
└── requirements.txt
```

First, let's create a virtual environment and install the required packages:

```bash
python -m venv venv
source venv/bin/activate  # On Windows, use: venv\Scripts\activate
pip install grep_ast pytest
```

Create a `requirements.txt` file with the following content:

```
grep_ast==2.0.0
pytest==7.3.1
```

## Understanding Abstract Syntax Trees

Before we dive into using `grep_ast`, let's briefly discuss what an Abstract Syntax Tree (AST) is.

An AST is a tree representation of the abstract syntactic structure of source code. Each node of the tree denotes a construct occurring in the code. ASTs are used in compilers to represent the structure of program code and are useful for static code analysis.

In Python, the `ast` module provides tools to work with ASTs. The `grep_ast` package builds on top of this to provide a more user-friendly interface for common AST operations.

## Basic AST Analysis

Let's start with some basic AST analysis using `grep_ast`. Create a file `src/basic_ast_analysis.py`:

```python
import ast
from grep_ast import grep

# Sample Python code to analyze
sample_code = """
def greet(name):
    print(f"Hello, {name}!")

def calculate_sum(a, b):
    return a + b

result = calculate_sum(5, 7)
greet("Alice")
"""

# Parse the code into an AST
tree = ast.parse(sample_code)

# Find all function definitions
function_defs = grep(tree, ast.FunctionDef)
print("Function definitions:")
for func in function_defs:
    print(f"- {func.name}")

# Find all function calls
function_calls = grep(tree, ast.Call)
print("\nFunction calls:")
for call in function_calls:
    if isinstance(call.func, ast.Name):
        print(f"- {call.func.id}")
    elif isinstance(call.func, ast.Attribute):
        print(f"- {call.func.attr}")

# Find all print statements
print_calls = grep(tree, ast.Call, lambda node: isinstance(node.func, ast.Name) and node.func.id == 'print')
print("\nPrint statements:")
for print_call in print_calls:
    print(f"- {ast.unparse(print_call)}")

# Find all string literals
string_literals = grep(tree, ast.Str)
print("\nString literals:")
for string in string_literals:
    print(f"- {string.value}")

# Find all numeric literals
numeric_literals = grep(tree, ast.Num)
print("\nNumeric literals:")
for num in numeric_literals:
    print(f"- {num.n}")
```

This script demonstrates:

1. Parsing Python code into an AST
2. Finding function definitions
3. Finding function calls
4. Finding specific types of function calls (print statements)
5. Finding string and numeric literals

Run the script to see basic AST analysis in action:

```bash
python src/basic_ast_analysis.py
```

## Advanced AST Analysis

Now let's explore more advanced AST analysis techniques. Create `src/advanced_ast_analysis.py`:

```python
import ast
from grep_ast import grep, match, or_
from grep_ast import TreeContext

# Sample Python code to analyze
with open('src/sample_code/example1.py', 'r') as file:
    sample_code = file.read()

# Parse the code into an AST
tree = ast.parse(sample_code)

# Find all class definitions
class_defs = grep(tree, ast.ClassDef)
print("Class definitions:")
for class_def in class_defs:
    print(f"- {class_def.name}")
    # Find methods within the class
    methods = grep(class_def, ast.FunctionDef)
    for method in methods:
        print(f"  - Method: {method.name}")

# Find all import statements
imports = grep(tree, or_(ast.Import, ast.ImportFrom))
print("\nImport statements:")
for imp in imports:
    if isinstance(imp, ast.Import):
        for alias in imp.names:
            print(f"- import {alias.name}")
    elif isinstance(imp, ast.ImportFrom):
        for alias in imp.names:
            print(f"- from {imp.module} import {alias.name}")

# Find all assignments
assignments = grep(tree, ast.Assign)
print("\nAssignments:")
for assign in assignments:
    targets = ", ".join(ast.unparse(target) for target in assign.targets)
    value = ast.unparse(assign.value)
    print(f"- {targets} = {value}")

# Find all if statements
if_statements = grep(tree, ast.If)
print("\nIf statements:")
for if_stmt in if_statements:
    print(f"- {ast.unparse(if_stmt.test)}")

# Find all for loops
for_loops = grep(tree, ast.For)
print("\nFor loops:")
for for_loop in for_loops:
    print(f"- for {ast.unparse(for_loop.target)} in {ast.unparse(for_loop.iter)}:")

# Find all list comprehensions
list_comps = grep(tree, ast.ListComp)
print("\nList comprehensions:")
for list_comp in list_comps:
    print(f"- {ast.unparse(list_comp)}")

# Find all try-except blocks
try_blocks = grep(tree, ast.Try)
print("\nTry-except blocks:")
for try_block in try_blocks:
    print(f"- try:")
    for handler in try_block.handlers:
        print(f"  except {ast.unparse(handler.type) if handler.type else ''}:")

# Using TreeContext to get more information about nodes
print("\nUsing TreeContext:")
ctx = TreeContext(sample_code)
for node in grep(tree, ast.Assign):
    print(f"Assignment at line {ctx.get_line(node)}:")
    print(ctx.get_context(node))
    print()
```

Create a sample Python file `src/sample_code/example1.py` with some code to analyze:

```python
import os
from datetime import datetime

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def greet(self):
        print(f"Hello, my name is {self.name} and I'm {self.age} years old.")

def calculate_squares(numbers):
    return [n ** 2 for n in numbers]

def main():
    person = Person("Alice", 30)
    person.greet()

    numbers = [1, 2, 3, 4, 5]
    squares = calculate_squares(numbers)
    print(f"Squares: {squares}")

    current_time = datetime.now()
    print(f"Current time: {current_time}")

    try:
        result = 10 / 0
    except ZeroDivisionError:
        print("Error: Division by zero")

if __name__ == "__main__":
    main()
```

This script demonstrates:

1. Finding class definitions and their methods
2. Analyzing import statements
3. Finding assignments, if statements, and for loops
4. Identifying list comprehensions and try-except blocks
5. Using TreeContext to get more information about nodes

Run the script to see advanced AST analysis in action:

```bash
python src/advanced_ast_analysis.py
```

## Code Transformation

AST analysis can also be used for code transformation. Let's create a simple code transformer in `src/code_transformation.py`:

```python
import ast
from grep_ast import grep, replace_node

class ConstantFolding(ast.NodeTransformer):
    def visit_BinOp(self, node):
        self.generic_visit(node)
        if isinstance(node.left, ast.Num) and isinstance(node.right, ast.Num):
            if isinstance(node.op, ast.Add):
                return ast.Num(n=node.left.n + node.right.n)
            elif isinstance(node.op, ast.Mult):
                return ast.Num(n=node.left.n * node.right.n)
        return node

def remove_print_statements(tree):
    prints = grep(tree, ast.Call, lambda node: isinstance(node.func, ast.Name) and node.func.id == 'print')
    for print_node in prints:
        replace_node(print_node, ast.Expr(value=ast.Str(s='# Print statement removed')))

# Sample code to transform
sample_code = """
def calculate():
    x = 5 + 3
    y = 2 * 4
    print("Result:", x * y)

calculate()
"""

# Parse the code into an AST
tree = ast.parse(sample_code)

# Apply constant folding
folder = ConstantFolding()
folded_tree = folder.visit(tree)

# Remove print statements
remove_print_statements(folded_tree)

# Convert the transformed AST back to code
transformed_code = ast.unparse(folded_tree)

print("Original code:")
print(sample_code)
print("\nTransformed code:")
print(transformed_code)
```

This script demonstrates:

1. Implementing a simple constant folding optimization
2. Removing print statements from the code
3. Combining AST transformations

Run the script to see code transformation in action:

```bash
python src/code_transformation.py
```

## Cross-Platform Considerations

While AST analysis is generally consistent across platforms, there are a few things to keep in mind:

1. **Line endings**: Different platforms use different line ending characters (\n on Unix, \r\n on Windows). When reading files, use the `universal newlines` mode to handle this automatically.

2. **Encoding**: Always specify the encoding when reading files to ensure consistent behavior across platforms. UTF-8 is a good default choice.

3. **Path separators**: Use `os.path.join()` for constructing file paths to ensure cross-platform compatibility.

4. **AST versions**: The AST structure may vary slightly between Python versions. If your code needs to support multiple Python versions, consider using tools like `astroid` which provide a more stable AST API.

## Best Practices for AST Analysis

1. **Use high-level libraries**: While the built-in `ast` module is powerful, using higher-level libraries like `grep_ast` can make your code more readable and maintainable.

2. **Handle exceptions**: AST parsing can fail if the input code is invalid. Always handle potential exceptions when parsing code.

3. **Preserve formatting**: When transforming code, try to preserve the original formatting as much as possible. Libraries like `astor` can help with this.

4. **Test thoroughly**: AST analysis and transformation can be complex. Write comprehensive tests to ensure your code works correctly for various input cases.

5. **Document assumptions**: If your AST analysis makes assumptions about the structure of the input code, document these clearly.

6. **Be cautious with transformations**: Code transformations can introduce subtle bugs. Always validate the transformed code thoroughly.

7. **Consider performance**: For large codebases, AST analysis can be computationally expensive. Consider using caching or incremental analysis for better performance.

## Conclusion

In this lesson, we've explored Abstract Syntax Tree (AST) analysis using the `grep_ast` package. We've covered basic and advanced AST analysis techniques, as well as simple code transformation. AST analysis is a powerful tool for understanding and manipulating Python code programmatically.

As you continue to develop Python applications, consider using AST analysis for tasks such as:

- Static code analysis and linting
- Refactoring and code transformation
- Generating documentation from code
- Creating custom code optimizations
- Building domain-specific language tools

Remember to consider cross-platform compatibility and follow best practices to ensure your AST analysis tools work effectively across different environments.

In the next lesson, we'll explore dynamic code execution and importing, which will allow us to work with code and modules in a more flexible way at runtime. Stay tuned!
