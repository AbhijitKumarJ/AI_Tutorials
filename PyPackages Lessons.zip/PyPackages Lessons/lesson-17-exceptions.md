Certainly! I'll create Lesson 17 of the "Mastering Python Packages for Efficient Programming" series, focusing on Exception Handling and Tracebacks. I'll provide a thorough explanation with examples, including folder layouts, and address any cross-platform considerations.



# Lesson 17: Exception Handling and Tracebacks

## Introduction

Welcome to Lesson 17 of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll dive into exception handling and tracebacks in Python. Understanding how to properly handle errors and debug your code is crucial for writing robust and maintainable software.

## Setting Up Our Project

Let's start by setting up a new project for this lesson. Here's our folder structure:

```
exception_handling_tutorial/
│
├── src/
│   ├── basic_exceptions.py
│   ├── custom_exceptions.py
│   ├── traceback_examples.py
│   └── advanced_techniques.py
│
├── tests/
│   └── test_exceptions.py
│
└── requirements.txt
```

First, let's create a virtual environment and install the required packages:

```bash
python -m venv venv
source venv/bin/activate  # On Windows, use: venv\Scripts\activate
pip install pytest
```

Create a `requirements.txt` file with the following content:

```
pytest==7.3.1
```

## Basic Exception Handling

Let's start with the basics of exception handling in Python. Create a file `src/basic_exceptions.py`:

<antArtifact identifier="basic-exceptions-py" type="application/vnd.ant.code" language="python" title="src/basic_exceptions.py">
def divide(a, b):
    try:
        result = a / b
    except ZeroDivisionError:
        print("Error: Division by zero!")
        return None
    except TypeError:
        print("Error: Invalid type for division!")
        return None
    else:
        print("Division successful!")
        return result
    finally:
        print("Division operation completed.")

# Test the function
print(divide(10, 2))  # Normal division
print(divide(10, 0))  # Division by zero
print(divide("10", 2))  # Type error

# Multiple exception handling
def process_data(data):
    try:
        value = data['key']
        result = 10 / value
    except (KeyError, ZeroDivisionError, TypeError) as e:
        print(f"An error occurred: {type(e).__name__} - {str(e)}")
    else:
        print(f"Result: {result}")

# Test the function
process_data({'key': 5})  # Normal case
process_data({'wrong_key': 5})  # KeyError
process_data({'key': 0})  # ZeroDivisionError
process_data({'key': '5'})  # TypeError


In this example, we demonstrate:

1. Basic `try`-`except`-`else`-`finally` structure
2. Handling specific exceptions (`ZeroDivisionError`, `TypeError`)
3. The `else` clause for code that runs when no exception occurs
4. The `finally` clause for cleanup code that always runs
5. Handling multiple exceptions in a single `except` clause

Run the script to see how different scenarios are handled:

```bash
python src/basic_exceptions.py
```

## Custom Exceptions

Creating custom exceptions can help make your code more readable and maintainable. Let's create `src/custom_exceptions.py`:

```python
class InsufficientFundsError(Exception):
    def __init__(self, balance, amount):
        self.balance = balance
        self.amount = amount
        super().__init__(f"Insufficient funds: balance is {balance}, tried to withdraw {amount}")

class NegativeAmountError(ValueError):
    pass

class BankAccount:
    def __init__(self, initial_balance):
        self.balance = initial_balance

    def withdraw(self, amount):
        if amount < 0:
            raise NegativeAmountError("Cannot withdraw a negative amount")
        if self.balance < amount:
            raise InsufficientFundsError(self.balance, amount)
        self.balance -= amount
        return self.balance

# Test the BankAccount class
account = BankAccount(100)

try:
    print(account.withdraw(50))  # Successful withdrawal
    print(account.withdraw(100))  # Insufficient funds
except InsufficientFundsError as e:
    print(f"Error: {e}")

try:
    print(account.withdraw(-10))  # Negative amount
except NegativeAmountError as e:
    print(f"Error: {e}")

```

This script demonstrates:

1. Creating a custom exception (`InsufficientFundsError`) that inherits from the base `Exception` class
2. Creating a custom exception (`NegativeAmountError`) that inherits from a built-in exception (`ValueError`)
3. Using custom exceptions in a `BankAccount` class to handle specific error scenarios

Run the script to see how custom exceptions are raised and caught:

```bash
python src/custom_exceptions.py
```

## Working with Tracebacks

Tracebacks provide valuable information for debugging. Let's explore how to work with tracebacks in `src/traceback_examples.py`:

```python
import traceback
import sys

def function_c():
    raise ValueError("An error occurred in function_c")

def function_b():
    function_c()

def function_a():
    function_b()

# Basic traceback printing
try:
    function_a()
except ValueError:
    print("Basic traceback:")
    traceback.print_exc()

# Customizing traceback output
try:
    function_a()
except ValueError:
    print("\nCustomized traceback:")
    exc_type, exc_value, exc_traceback = sys.exc_info()
    traceback.print_exception(exc_type, exc_value, exc_traceback, limit=2)

# Formatting traceback as a string
try:
    function_a()
except ValueError:
    print("\nFormatted traceback:")
    formatted_traceback = traceback.format_exc()
    print(formatted_traceback)

# Extracting traceback information
def extract_tb_info(tb):
    return [
        {
            'filename': frame.filename,
            'line': frame.lineno,
            'function': frame.name,
            'code': frame.line
        }
        for frame in traceback.extract_tb(tb)
    ]

try:
    function_a()
except ValueError:
    print("\nExtracted traceback info:")
    _, _, exc_traceback = sys.exc_info()
    tb_info = extract_tb_info(exc_traceback)
    for frame in tb_info:
        print(f"File: {frame['filename']}, Line: {frame['line']}, Function: {frame['function']}")
        print(f"Code: {frame['code']}")
        print()

```

This script demonstrates:

1. Basic traceback printing using `traceback.print_exc()`
2. Customizing traceback output using `sys.exc_info()` and `traceback.print_exception()`
3. Formatting traceback as a string with `traceback.format_exc()`
4. Extracting and processing traceback information using `traceback.extract_tb()`

Run the script to see different ways of working with tracebacks:

```bash
python src/traceback_examples.py
```

## Advanced Exception Handling Techniques

Let's explore some advanced exception handling techniques in `src/advanced_techniques.py`:

```python
import contextlib

# Context manager for exception handling
class HandleException:
    def __init__(self, exception_type, handler):
        self.exception_type = exception_type
        self.handler = handler

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if exc_type is not None and issubclass(exc_type, self.exception_type):
            self.handler(exc_value)
            return True  # Suppress the exception
        return False  # Propagate the exception

# Using the context manager
def divide(a, b):
    with HandleException(ZeroDivisionError, lambda e: print("Caught zero division error")):
        return a / b

print(divide(10, 2))  # Normal division
print(divide(10, 0))  # Division by zero

# Chaining exceptions
def fetch_data():
    try:
        # Simulating a database error
        raise ConnectionError("Database connection failed")
    except ConnectionError as e:
        raise RuntimeError("Failed to fetch data") from e

try:
    fetch_data()
except RuntimeError as e:
    print(f"Error: {e}")
    if e.__cause__:
        print(f"Caused by: {e.__cause__}")

# Using contextlib.suppress to ignore specific exceptions
import os

with contextlib.suppress(FileNotFoundError):
    os.remove("non_existent_file.txt")
print("Continued execution after trying to remove file")

# Exception groups (Python 3.11+)
if sys.version_info >= (3, 11):
    def process_items(items):
        errors = []
        for item in items:
            try:
                # Process item (simulated)
                if item % 2 == 0:
                    raise ValueError(f"Even number not allowed: {item}")
                print(f"Processed item: {item}")
            except ValueError as e:
                errors.append(e)
        
        if errors:
            raise ExceptionGroup("Processing errors", errors)

    try:
        process_items([1, 2, 3, 4, 5])
    except* ValueError as eg:
        print(f"Caught {len(eg.exceptions)} ValueError(s):")
        for i, e in enumerate(eg.exceptions, 1):
            print(f"  {i}. {e}")
else:
    print("Exception groups are only available in Python 3.11+")

```

This script demonstrates:

1. Creating a context manager for exception handling
2. Chaining exceptions using the `raise ... from ...` syntax
3. Using `contextlib.suppress` to ignore specific exceptions
4. Working with exception groups (Python 3.11+)

Run the script to see these advanced techniques in action:

```bash
python src/advanced_techniques.py
```

## Cross-Platform Considerations

While exception handling works consistently across different platforms, there are a few things to keep in mind:

1. **File paths**: When working with file-related exceptions, remember that file paths are different on Windows (backslashes) and Unix-like systems (forward slashes). Use `os.path` functions to handle paths in a cross-platform manner.

2. **Line endings**: Tracebacks may display differently on Windows (\r\n) and Unix-like systems (\n). When parsing tracebacks as text, account for these differences.

3. **System-specific exceptions**: Some exceptions may be specific to certain operating systems. For example, `WindowsError` is only available on Windows. Use more generic exceptions (e.g., `OSError`) for better cross-platform compatibility.

4. **Encoding issues**: When dealing with file I/O or network operations, be aware that different systems may use different default encodings. Always specify the encoding explicitly to avoid inconsistencies.

## Testing Exception Handling

It's important to test your exception handling code. Let's create a simple test file `tests/test_exceptions.py`:

```python
import pytest
from src.custom_exceptions import BankAccount, InsufficientFundsError, NegativeAmountError

def test_bank_account_withdraw():
    account = BankAccount(100)
    assert account.withdraw(50) == 50

def test_insufficient_funds():
    account = BankAccount(100)
    with pytest.raises(InsufficientFundsError) as exc_info:
        account.withdraw(150)
    assert str(exc_info.value) == "Insufficient funds: balance is 100, tried to withdraw 150"

def test_negative_amount():
    account = BankAccount(100)
    with pytest.raises(NegativeAmountError) as exc_info:
        account.withdraw(-50)
    assert str(exc_info.value) == "Cannot withdraw a negative amount"

def test_chained_exceptions():
    def inner_function():
        raise ValueError("Inner error")

    def outer_function():
        try:
            inner_function()
        except ValueError as e:
            raise RuntimeError("Outer error") from e

    with pytest.raises(RuntimeError) as exc_info:
        outer_function()
    
    assert str(exc_info.value) == "Outer error"
    assert str(exc_info.value.__cause__) == "Inner error"

```

Run the tests using pytest:

```bash
pytest tests/test_exceptions.py
```

## Conclusion

In this lesson, we've explored exception handling and tracebacks in Python. We've covered basic exception handling, creating custom exceptions, working with tracebacks, and advanced exception handling techniques. We've also discussed cross-platform considerations and how to test exception handling code.

Proper exception handling is crucial for writing robust and maintainable Python code. It helps you gracefully handle errors, provide meaningful feedback to users, and simplify debugging. As you continue to develop Python applications, make sure to incorporate these exception handling techniques to improve the reliability and user experience of your programs.

In the next lesson, we'll dive into logging and warnings, which complement exception handling by providing a way to record and manage information about your application's behavior. Stay tuned!
</antArtifact>

This lesson provides a comprehensive introduction to exception handling and tracebacks in Python. It covers basic concepts, custom exceptions, working with tracebacks, and advanced techniques. The examples are structured to gradually build up complexity, making it easy for beginners to follow along and understand the concepts. The folder structure and sample code files help visualize the project organization, and the cross-platform section addresses potential issues that may arise on different operating systems. Additionally, the lesson includes a section on testing exception handling, which is crucial for ensuring the robustness of error-handling code.