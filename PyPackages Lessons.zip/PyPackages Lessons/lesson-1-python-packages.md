# Lesson 1: Understanding Python Packages and Their Importance

## Introduction

Welcome to the first lesson of our "Mastering Python Packages for Efficient Programming" series! In this lesson, we'll explore the fundamental concept of Python packages, their importance in software development, and how to create and use them. By the end of this lesson, you'll have a solid understanding of Python packages and be ready to start organizing your code more efficiently.

## What are Python Packages?

A Python package is a way of organizing related Python modules into a directory hierarchy. It's essentially a directory that contains Python modules and a special `__init__.py` file. Packages allow you to group related functionality together, making your code more organized, reusable, and easier to maintain.

Think of packages like folders on your computer. Just as you might organize your documents into different folders, you can organize your Python code into packages.

### Key Concepts:

1. **Module**: A single Python file containing Python code.
2. **Package**: A directory containing Python modules and an `__init__.py` file.
3. **Subpackage**: A package inside another package.

## Why Do We Need Packages?

Packages are crucial for several reasons:

1. **Organization**: They help structure large codebases logically.
2. **Namespace Management**: They prevent naming conflicts between modules.
3. **Reusability**: Packages make it easy to reuse code across different projects.
4. **Distribution**: They simplify the process of sharing and distributing code.

## Package Structure and `__init__.py` Files

Let's look at a basic package structure:

```
my_package/
│
├── __init__.py
├── module1.py
├── module2.py
└── subpackage/
    ├── __init__.py
    └── module3.py
```

### The `__init__.py` File

The `__init__.py` file is what makes a directory a Python package. It can be empty, or it can contain initialization code for the package. When you import a package, the `__init__.py` file is executed.

Let's create a simple package to demonstrate:

1. Create a directory called `my_package`:

```bash
mkdir my_package
```

2. Inside `my_package`, create an empty `__init__.py` file:

```bash
touch my_package/__init__.py
```

3. Create two module files, `module1.py` and `module2.py`:

```bash
touch my_package/module1.py my_package/module2.py
```

4. Add some simple functions to each module:

In `my_package/module1.py`:
```python
def greet(name):
    return f"Hello, {name}!"
```

In `my_package/module2.py`:
```python
def farewell(name):
    return f"Goodbye, {name}!"
```

5. In the `__init__.py` file, you can import these functions to make them directly available when the package is imported:

```python
from .module1 import greet
from .module2 import farewell
```

## Importing Packages and Modules

Now that we have created a package, let's see how to import and use it. Create a new file called `main.py` outside the `my_package` directory:

```
project_root/
│
├── my_package/
│   ├── __init__.py
│   ├── module1.py
│   └── module2.py
│
└── main.py
```

In `main.py`, you can now import and use your package:

```python
import my_package

print(my_package.greet("Alice"))  # Output: Hello, Alice!
print(my_package.farewell("Bob"))  # Output: Goodbye, Bob!
```

You can also import specific functions:

```python
from my_package import greet, farewell

print(greet("Charlie"))  # Output: Hello, Charlie!
print(farewell("Diana"))  # Output: Goodbye, Diana!
```

## Creating Your First Package

Let's create a more comprehensive package to demonstrate these concepts. We'll create a simple math package with basic arithmetic operations.

1. Create the package structure:

```
math_operations/
│
├── __init__.py
├── basic_ops.py
└── advanced_ops.py
```

2. In `basic_ops.py`, add some basic arithmetic functions:

```python
def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b
```

3. In `advanced_ops.py`, add some slightly more advanced operations:

```python
import math

def square_root(a):
    if a < 0:
        raise ValueError("Cannot calculate square root of a negative number")
    return math.sqrt(a)

def power(base, exponent):
    return math.pow(base, exponent)
```

4. In `__init__.py`, import the functions you want to make available when the package is imported:

```python
from .basic_ops import add, subtract, multiply, divide
from .advanced_ops import square_root, power
```

5. Create a `main.py` file outside the `math_operations` directory to use your new package:

```python
from math_operations import add, subtract, multiply, divide, square_root, power

print(add(5, 3))        # Output: 8
print(subtract(10, 4))  # Output: 6
print(multiply(2, 6))   # Output: 12
print(divide(15, 3))    # Output: 5.0

print(square_root(16))  # Output: 4.0
print(power(2, 3))      # Output: 8.0
```

## Cross-Platform Considerations

Python's package system works consistently across Windows, macOS, and Linux, but there are a few things to keep in mind:

1. **Path Separators**: Windows uses backslashes (`\`) in file paths, while macOS and Linux use forward slashes (`/`). Python can handle both, but it's best to use forward slashes in your code for consistency.

2. **Line Endings**: Windows uses `\r\n` for line endings, while macOS and Linux use `\n`. Python handles this automatically, but be aware when reading or writing text files.

3. **Case Sensitivity**: Windows file systems are case-insensitive, while macOS and Linux are case-sensitive. It's best to always use consistent casing in your package and module names to avoid issues.

4. **Executable Permissions**: On macOS and Linux, you may need to set executable permissions on your Python files. This isn't necessary on Windows.

## Conclusion

In this lesson, we've covered the basics of Python packages, including what they are, why they're important, and how to create and use them. We've also created a simple math operations package to demonstrate these concepts in practice.

Packages are a fundamental part of Python programming, allowing you to organize your code efficiently and create reusable, modular software. As you continue through this course, you'll see how packages form the building blocks of larger Python projects and how they can significantly improve your productivity as a developer.

## Exercises

1. Create a new package called `string_utils` with modules for string manipulation operations (e.g., reversing strings, counting characters, etc.).

2. Modify the `math_operations` package to include a new module for trigonometric functions (sin, cos, tan).

3. Create a package that works with file operations, considering the cross-platform issues we discussed. Include functions for reading, writing, and appending to files.

In the next lesson, we'll dive into package management with pip and virtual environments, which will allow you to use third-party packages and manage your project dependencies effectively.

