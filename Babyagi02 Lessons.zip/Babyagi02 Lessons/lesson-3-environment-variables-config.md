# Lesson 3: Environment Variables and Configuration

## 1. Concept of Environment Variables

Environment variables are dynamic-named values that can affect the way running processes behave on a computer. They are part of the environment in which a process runs and are typically used to pass configuration information to applications.

In the context of Python programming and specifically BabyAGI 2o, environment variables serve several important purposes:

1. **Security**: They allow you to store sensitive information (like API keys) outside of your codebase, reducing the risk of accidentally exposing this information when sharing or publishing your code.

2. **Flexibility**: Environment variables make it easy to change configuration without modifying the code, allowing the same code to run in different environments (development, testing, production) with different configurations.

3. **Separation of Concerns**: They help maintain a clear separation between code and configuration, adhering to the principle that code should be environment-agnostic.

In BabyAGI 2o, environment variables are crucial for storing API keys for the AI models and other configuration parameters that might change between different setups or environments.

## 2. Setting Up Environment Variables on Different Platforms

The process of setting up environment variables varies depending on the operating system. Let's look at how to set them up on Windows, macOS, and Linux.

### Windows

On Windows, you can set environment variables through the GUI or the command line.

#### Using the GUI:
1. Right-click on 'This PC' or 'My Computer' and select 'Properties'
2. Click on 'Advanced system settings'
3. Click on 'Environment Variables'
4. Under 'User variables' or 'System variables', click 'New' to add a new variable

#### Using the Command Prompt:
To set a variable for the current session:
```
set VARIABLE_NAME=value
```

To set a persistent variable:
```
setx VARIABLE_NAME "value"
```

### macOS and Linux

On macOS and Linux, you typically set environment variables in shell configuration files.

For temporary variables in the current session:
```
export VARIABLE_NAME=value
```

For persistent variables, add the above line to your shell's configuration file (e.g., `~/.bash_profile`, `~/.bashrc`, or `~/.zshrc`), then reload the configuration:
```
source ~/.bash_profile
```

### Setting Variables for BabyAGI 2o

For BabyAGI 2o, you'll need to set variables like `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` depending on the model you're using. For example:

```
export OPENAI_API_KEY=your_api_key_here
export LITELLM_MODEL=gpt-4
```

Remember to replace `your_api_key_here` with your actual API key.

## 3. Using .env Files for Configuration

While setting environment variables directly on your system works, it's often more convenient to use a `.env` file for project-specific variables. This approach is especially useful for managing multiple projects with different configurations.

### What is a .env File?

A `.env` file is a simple text file that contains key-value pairs of environment variables. Each line in the file represents one variable:

```
VARIABLE_NAME=value
ANOTHER_VARIABLE=another_value
```

### Creating a .env File for BabyAGI 2o

1. In your BabyAGI 2o project directory, create a new file named `.env`
2. Add your configuration variables to this file. For example:

```
LITELLM_MODEL=gpt-4
OPENAI_API_KEY=your_openai_api_key_here
ANTHROPIC_API_KEY=your_anthropic_api_key_here
```

3. Save the file

### Using python-dotenv to Load .env Files

To use the variables defined in your `.env` file, you'll need to use a library like `python-dotenv`. Here's how to set it up:

1. Install python-dotenv:
   ```
   pip install python-dotenv
   ```

2. In your Python script, add the following at the beginning:

```python
from dotenv import load_dotenv
import os

load_dotenv()  # This loads the variables from .env

# Now you can access the variables like this:
model = os.getenv('LITELLM_MODEL')
api_key = os.getenv('OPENAI_API_KEY')
```

By using `load_dotenv()`, your script will automatically load the variables from your `.env` file, making them available through `os.getenv()`.

## 4. Security Considerations When Handling API Keys

When working with API keys and other sensitive information, security should be a top priority. Here are some best practices to keep in mind:

1. **Never commit .env files to version control**: Add `.env` to your `.gitignore` file to prevent it from being accidentally committed.

2. **Use different keys for development and production**: This limits the potential damage if a development key is accidentally exposed.

3. **Rotate keys regularly**: Regularly updating your API keys can help mitigate the risk if a key is compromised.

4. **Use the principle of least privilege**: Only give your keys the minimum permissions necessary for your application to function.

5. **Monitor key usage**: Many API providers offer usage dashboards. Monitor these to detect any unusual activity that might indicate a compromised key.

6. **Use environment variables or secure vaults in production**: When deploying your application, use the hosting platform's built-in secrets management system rather than `.env` files.

7. **Be cautious with error messages**: Ensure that your application doesn't expose API keys in error messages or logs.

## 5. Best Practices for Managing Configurations in Python Applications

Managing configurations effectively is crucial for maintaining clean, secure, and flexible Python applications. Here are some best practices:

1. **Use a configuration management library**: Libraries like `python-decouple` or `dynaconf` provide more advanced features for configuration management.

2. **Implement configuration validation**: Validate your configuration at startup to catch any missing or incorrect values early.

3. **Use configuration files for complex settings**: For more complex configurations, consider using formats like YAML or TOML, which are more readable for nested configurations.

4. **Implement a configuration hierarchy**: Use a hierarchy of configurations (e.g., default < environment-specific < local) to allow for flexible overrides.

5. **Document your configuration**: Maintain clear documentation of all configuration options, including their purpose, allowed values, and any default values.

6. **Use type hints and validation**: Use Python's type hints and validation libraries to ensure configuration values are of the correct type and within expected ranges.

7. **Centralize configuration access**: Create a centralized configuration object or module to access settings throughout your application, rather than reading from environment variables directly in multiple places.

Here's an example of how you might implement some of these practices in BabyAGI 2o:

```python
from dotenv import load_dotenv
import os
from typing import Optional

class Config:
    def __init__(self):
        load_dotenv()
        self.model: str = self._get_required('LITELLM_MODEL')
        self.openai_api_key: Optional[str] = os.getenv('OPENAI_API_KEY')
        self.anthropic_api_key: Optional[str] = os.getenv('ANTHROPIC_API_KEY')
        self.validate()

    def _get_required(self, name: str) -> str:
        value = os.getenv(name)
        if value is None:
            raise ValueError(f"Missing required environment variable: {name}")
        return value

    def validate(self):
        if self.model.startswith('gpt') and not self.openai_api_key:
            raise ValueError("OpenAI API key is required when using a GPT model")
        if self.model.startswith('claude') and not self.anthropic_api_key:
            raise ValueError("Anthropic API key is required when using a Claude model")

config = Config()

# Usage in your application:
print(f"Using model: {config.model}")
```

This example demonstrates several best practices:
- It uses `python-dotenv` to load environment variables.
- It implements a centralized `Config` class to manage all configuration.
- It validates the configuration at startup, ensuring all required values are present and consistent.
- It uses type hints to clearly indicate the expected types of configuration values.
- It provides clear error messages when required configuration is missing or invalid.

## Conclusion

Understanding environment variables and proper configuration management is crucial for developing secure, flexible, and maintainable Python applications. In the context of BabyAGI 2o, these practices allow you to securely manage API keys and other sensitive information, making it easier to share and deploy your code without exposing critical data.

By following the best practices outlined in this lesson, you can ensure that your BabyAGI 2o setup (and other Python projects) are configured securely and efficiently. Remember that good configuration management is an ongoing process – regularly review and update your practices as your project evolves and as you learn about new tools and techniques.

In the next lesson, we'll dive into the external libraries used in BabyAGI 2o, focusing on how they extend the functionality of the project and how to work with them effectively.
