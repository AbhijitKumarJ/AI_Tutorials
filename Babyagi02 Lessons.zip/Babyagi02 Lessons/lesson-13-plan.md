# Lesson 13: Practical Project: Extending BabyAGI 2o

## Introduction

Welcome to the final lesson in our series on understanding the BabyAGI 2o codebase! In this practical project, we'll apply everything we've learned to extend BabyAGI 2o with new features and improvements. This hands-on experience will solidify your understanding of the codebase and give you valuable experience in working with autonomous AI systems.

## Lesson Objectives

By the end of this lesson, you will be able to:
1. Plan and implement a new feature for BabyAGI 2o
2. Integrate external APIs or services into the project
3. Improve error handling and user feedback mechanisms
4. Implement a simple user interface (CLI or web-based)
5. Write unit tests for the new features

## Project Overview

Our practical project will involve extending BabyAGI 2o with a new capability: sentiment analysis of web content. We'll create a new tool that allows BabyAGI 2o to fetch web content, analyze its sentiment, and provide a summary. This project will touch on various aspects of the BabyAGI 2o codebase and introduce new concepts and integrations.

## 1. Planning and Implementing a New Feature

### 1.1 Feature Planning

Before we start coding, let's plan our new feature. We'll create a new tool called `analyze_web_sentiment` that will:
1. Fetch content from a given URL
2. Analyze the sentiment of the content
3. Provide a summary of the content and its sentiment

This feature will demonstrate BabyAGI 2o's ability to interact with external data sources and perform complex analysis tasks.

### 1.2 Implementation Steps

Let's break down the implementation into manageable steps:

1. Create a new function to fetch web content
2. Implement sentiment analysis using a natural language processing library
3. Create a summary generation function
4. Integrate these components into a new BabyAGI 2o tool

### 1.3 Code Implementation

We'll start by adding the necessary imports and creating our new functions. Add the following code to the top of `main.py`:

```python
import requests
from bs4 import BeautifulSoup
from textblob import TextBlob
import nltk

# Download necessary NLTK data
nltk.download('punkt')
```

Now, let's implement our new functions:

```python
def fetch_web_content(url):
    """Fetch and parse web content from a given URL."""
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        return soup.get_text()
    except requests.RequestException as e:
        return f"Error fetching content: {e}"

def analyze_sentiment(text):
    """Analyze the sentiment of the given text."""
    blob = TextBlob(text)
    sentiment = blob.sentiment.polarity
    if sentiment > 0.1:
        return "Positive"
    elif sentiment < -0.1:
        return "Negative"
    else:
        return "Neutral"

def generate_summary(text, max_sentences=3):
    """Generate a summary of the given text."""
    sentences = nltk.sent_tokenize(text)
    return " ".join(sentences[:max_sentences])

def analyze_web_sentiment(url):
    """Fetch web content, analyze sentiment, and generate a summary."""
    content = fetch_web_content(url)
    if content.startswith("Error"):
        return content
    
    sentiment = analyze_sentiment(content)
    summary = generate_summary(content)
    
    return f"Summary: {summary}\n\nSentiment: {sentiment}"
```

Now, let's register this new tool with BabyAGI 2o. Add the following code after the existing tool registrations:

```python
register_tool(
    "analyze_web_sentiment",
    analyze_web_sentiment,
    "Analyzes the sentiment of web content from a given URL and provides a summary.",
    {
        "url": {
            "type": "string",
            "description": "The URL of the web page to analyze."
        }
    }
)
```

## 2. Integrating External APIs or Services

In our implementation, we've integrated several external services:

1. **requests**: For fetching web content
2. **BeautifulSoup**: For parsing HTML content
3. **TextBlob**: For sentiment analysis
4. **NLTK**: For text summarization

To ensure these dependencies are available, we need to update our `requirements.txt` file. Add the following lines:

```
requests
beautifulsoup4
textblob
nltk
```

Remember to install these new dependencies by running:

```
pip install -r requirements.txt
```

## 3. Improving Error Handling and User Feedback

Our new tool already includes basic error handling for web requests. Let's enhance it further by adding more detailed feedback. Update the `analyze_web_sentiment` function as follows:

```python
def analyze_web_sentiment(url):
    """Fetch web content, analyze sentiment, and generate a summary."""
    content = fetch_web_content(url)
    if content.startswith("Error"):
        return content
    
    try:
        sentiment = analyze_sentiment(content)
        summary = generate_summary(content)
        
        return {
            "summary": summary,
            "sentiment": sentiment,
            "full_content_length": len(content)
        }
    except Exception as e:
        return f"Error analyzing content: {e}"
```

This updated version provides more structured output and includes additional error handling.

## 4. Implementing a Simple User Interface

For this project, we'll implement a simple command-line interface (CLI) to interact with our new tool directly. Add the following code at the end of `main.py`:

```python
def cli_analyze_web_sentiment():
    print("Web Content Sentiment Analyzer")
    print("------------------------------")
    url = input("Enter a URL to analyze: ")
    result = analyze_web_sentiment(url)
    
    if isinstance(result, dict):
        print("\nAnalysis Result:")
        print(f"Summary: {result['summary']}")
        print(f"Sentiment: {result['sentiment']}")
        print(f"Full content length: {result['full_content_length']} characters")
    else:
        print(f"\nError: {result}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--analyze":
        cli_analyze_web_sentiment()
    else:
        run_main_loop(input(f"{Colors.BOLD}Describe the task you want to complete: {Colors.ENDC}"))
```

Now, users can run the sentiment analysis tool directly by using the `--analyze` flag:

```
python main.py --analyze
```

## 5. Writing Unit Tests

Finally, let's write some unit tests for our new feature. Create a new file called `test_sentiment_analysis.py` in the project root directory:

```python
import unittest
from unittest.mock import patch
from main import analyze_sentiment, generate_summary, analyze_web_sentiment

class TestSentimentAnalysis(unittest.TestCase):

    def test_analyze_sentiment(self):
        self.assertEqual(analyze_sentiment("I love this product!"), "Positive")
        self.assertEqual(analyze_sentiment("I hate this product."), "Negative")
        self.assertEqual(analyze_sentiment("This product is okay."), "Neutral")

    def test_generate_summary(self):
        text = "This is the first sentence. This is the second sentence. This is the third sentence. This is the fourth sentence."
        summary = generate_summary(text, max_sentences=2)
        self.assertEqual(summary, "This is the first sentence. This is the second sentence.")

    @patch('main.fetch_web_content')
    def test_analyze_web_sentiment(self, mock_fetch):
        mock_fetch.return_value = "This is a great website. I love the content."
        result = analyze_web_sentiment("http://example.com")
        self.assertEqual(result['sentiment'], "Positive")
        self.assertTrue('summary' in result)

if __name__ == '__main__':
    unittest.main()
```

To run the tests, use the following command:

```
python -m unittest test_sentiment_analysis.py
```

## Conclusion

In this practical project, we've extended BabyAGI 2o with a new sentiment analysis capability. We've integrated external APIs, improved error handling, implemented a simple CLI, and written unit tests. This project demonstrates how to build upon the existing BabyAGI 2o framework to add new, complex functionalities.

## Further Challenges

To continue your learning, consider the following challenges:

1. Enhance the sentiment analysis tool to handle multiple URLs and provide a comparative analysis.
2. Implement a caching mechanism to store previously analyzed URLs and their results.
3. Create a web-based interface using a framework like Flask or FastAPI.
4. Extend the tool to perform more advanced NLP tasks, such as named entity recognition or topic modeling.
5. Integrate the new sentiment analysis capability into BabyAGI 2o's autonomous decision-making process.

By completing this project and exploring these additional challenges, you'll gain valuable experience in working with and extending autonomous AI systems like BabyAGI 2o.
