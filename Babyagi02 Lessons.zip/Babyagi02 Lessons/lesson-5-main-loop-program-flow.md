# Lesson 5: Understanding the Main Loop and Program Flow

## Introduction

In this lesson, we will dive deep into the heart of the BabyAGI 2o project: the main loop and program flow. Understanding how the program executes its tasks, manages iterations, and handles the flow of information is crucial for grasping the functionality of this autonomous agent. We'll explore the `run_main_loop` function, analyze how messages are passed in AI conversations, and examine the decision-making process that drives the agent's actions.

## File Layout

Before we begin, let's review the file structure of the BabyAGI 2o project:

```
babyagi2o/
├── main.py
├── README.md
├── LICENSE
├── requirements.txt
└── .env (if using environment variables)
```

The core functionality we'll be discussing in this lesson is primarily contained within the `main.py` file.

## 1. Analyzing the run_main_loop Function

The `run_main_loop` function is the central component of the BabyAGI 2o project. It orchestrates the entire process of task completion, tool creation, and AI interaction. Let's break down its structure and functionality:

```python
def run_main_loop(user_input):
    # ... (function body)
```

### Key Components:

a) **Initialization**:
   The function starts by setting up the initial messages list, which includes a system message and the user's input. This forms the basis of the conversation with the AI model.

   ```python
   messages = [{
       "role": "system",
       "content": (
           "You are an AI assistant designed to iteratively build and execute Python functions using tools provided to you. "
           # ... (rest of the system message)
       )
   }, {"role": "user", "content": user_input}]
   ```

   The system message is crucial as it sets the context for the AI, defining its role and capabilities. It includes instructions on how to use tools, handle errors, and approach the task completion process.

b) **Iteration Control**:
   The function uses a while loop to control the number of iterations, preventing infinite loops:

   ```python
   iteration, max_iterations = 0, 50
   while iteration < max_iterations:
       # ... (loop body)
   ```

   This structure allows the agent to make multiple attempts at completing the task, with a maximum limit to ensure the process doesn't run indefinitely.

c) **AI Interaction**:
   Within each iteration, the function interacts with the AI model using the `completion` function from `litellm`:

   ```python
   response = completion(model=MODEL_NAME, messages=messages, tools=tools, tool_choice="auto")
   response_message = response.choices[0].message
   ```

   This step is where the AI model receives the current context (messages) and available tools, and decides on the next action.

d) **Response Handling**:
   The function processes the AI's response, which may include content to be displayed and/or tool calls to be executed:

   ```python
   if response_message.content:
       print(f"{Colors.OKCYAN}{Colors.BOLD}LLM Response:{Colors.ENDC}\n{response_message.content}\n")
   messages.append(response_message)
   ```

e) **Tool Execution**:
   If the AI response includes tool calls, the function executes each tool and appends the results to the messages:

   ```python
   if response_message.tool_calls:
       for tool_call in response_message.tool_calls:
           function_name = tool_call.function.name
           args = json.loads(tool_call.function.arguments)
           tool_result = call_tool(function_name, args)
           # ... (append result to messages)
   ```

f) **Task Completion Check**:
   After each iteration, the function checks if the task has been completed:

   ```python
   if 'task_completed' in [tc.function.name for tc in response_message.tool_calls]:
       print(f"{Colors.OKGREEN}{Colors.BOLD}Task completed.{Colors.ENDC}")
       break
   ```

g) **Error Handling**:
   The entire process is wrapped in a try-except block to catch and handle any exceptions that may occur during execution:

   ```python
   try:
       # ... (main loop logic)
   except Exception as e:
       print(f"{Colors.FAIL}{Colors.BOLD}Error:{Colors.ENDC} Error in main loop: {e}")
       traceback.print_exc()
   ```

## 2. Concept of Message Passing in AI Conversations

In the BabyAGI 2o project, message passing is a crucial concept that facilitates communication between the program and the AI model. This message-based approach allows for a structured conversation that maintains context and history.

### Key Points:

a) **Message Structure**:
   Each message in the conversation is a dictionary with specific keys:
   - `role`: Indicates who the message is from (e.g., "system", "user", "assistant", "tool")
   - `content`: The actual text of the message
   - Additional keys like `name` and `tool_call_id` for tool-related messages

b) **Conversation History**:
   The `messages` list maintains the entire conversation history, allowing the AI to have context from previous interactions when making decisions.

c) **System Message**:
   The initial system message sets the stage for the entire conversation, providing instructions and context to the AI assistant.

d) **Tool Results as Messages**:
   When tools are executed, their results are appended to the messages list as "tool" messages, allowing the AI to process and use this information in subsequent decisions.

## 3. Understanding Iterations and Loop Control

The main loop in BabyAGI 2o uses a controlled iteration approach to manage the task completion process.

### Key Aspects:

a) **Iteration Limit**:
   The `max_iterations` variable (set to 50 in the code) prevents the loop from running indefinitely, which is crucial for autonomous systems to prevent resource exhaustion.

b) **Iteration Counter**:
   The `iteration` variable keeps track of the current iteration number, allowing for potential logging or debugging based on the iteration count.

c) **Break Conditions**:
   The loop can be exited early if the task is completed, as indicated by the 'task_completed' tool call.

d) **Sleep Time**:
   A small sleep time (2 seconds) is added at the end of each iteration to prevent overwhelming the AI service with rapid requests:

   ```python
   sleep(2)
   ```

## 4. Implementing Basic Error Handling and Logging

Error handling and logging are crucial for maintaining the stability and debuggability of the BabyAGI 2o system.

### Implementation Details:

a) **Try-Except Block**:
   The main loop is wrapped in a try-except block to catch and handle any exceptions that may occur during execution.

b) **Error Messaging**:
   When an error occurs, it's printed to the console with a distinctive color and formatting for easy identification:

   ```python
   print(f"{Colors.FAIL}{Colors.BOLD}Error:{Colors.ENDC} Error in main loop: {e}")
   ```

c) **Traceback Printing**:
   For more detailed error information, the full traceback is printed:

   ```python
   traceback.print_exc()
   ```

d) **Colored Output**:
   The `Colors` class is used to provide colored console output, making it easier to distinguish between different types of messages (errors, AI responses, tool results, etc.).

## 5. Flow Control and Decision-Making in Autonomous Systems

The BabyAGI 2o project demonstrates a sophisticated approach to flow control and decision-making in autonomous systems.

### Key Concepts:

a) **AI-Driven Decision Making**:
   The AI model, through its responses and tool calls, drives the decision-making process. It determines which tools to use, when to use them, and how to interpret their results.

b) **Tool-Based Actions**:
   The system's actions are primarily executed through tools. This modular approach allows for flexibility and extensibility of the system's capabilities.

c) **Iterative Problem Solving**:
   The loop structure allows for iterative refinement of the solution. The AI can make multiple attempts, learning from previous actions and their results.

d) **Dynamic Tool Creation**:
   The ability to create new tools on the fly (using the `create_or_update_tool` function) allows the system to adapt to new challenges and expand its capabilities dynamically.

e) **Task Completion Recognition**:
   The system recognizes task completion through a specific tool call ('task_completed'), allowing it to terminate the process when the goal is achieved.

## Conclusion

Understanding the main loop and program flow in BabyAGI 2o is crucial for grasping how this autonomous agent operates. The interplay between AI decision-making, tool execution, and iterative problem-solving forms the core of its functionality. By mastering these concepts, you'll be well-equipped to work with, modify, and extend the capabilities of this innovative system.

## Practical Exercise

To reinforce your understanding, try the following exercise:

1. Modify the `run_main_loop` function to include a simple logging mechanism that records each iteration's main actions (AI response, tools called, etc.) to a file.
2. Implement a new tool that allows the AI to "reflect" on its previous actions. This tool should summarize the last N iterations and provide this summary to the AI for consideration in its next decision.
3. Add a feature that allows the user to interrupt the loop and provide additional input or guidance mid-task.

These exercises will give you hands-on experience with the core concepts of the main loop and program flow in BabyAGI 2o.
