import json
from config.settings import Colors
from utils.helpers import install_package, serialize_tool_result

tools = []
available_functions = {}

def initialize_tools():
    register_tool("create_or_update_tool", create_or_update_tool, "Creates or updates a tool with the specified name, code, description, and parameters.", {
        "name": {"type": "string", "description": "The tool name."},
        "code": {"type": "string", "description": "The Python code for the tool."},
        "description": {"type": "string", "description": "A description of the tool."},
        "parameters": {
            "type": "object",
            "description": "A dictionary defining the parameters for the tool.",
            "additionalProperties": {
                "type": "object",
                "properties": {
                    "type": {"type": "string", "description": "Data type of the parameter."},
                    "description": {"type": "string", "description": "Description of the parameter."}
                },
                "required": ["type", "description"]
            }
        }
    })

    register_tool("install_package", install_package, "Installs a Python package using pip.", {
        "package_name": {"type": "string", "description": "The name of the package to install."}
    })

    register_tool("task_completed", task_completed, "Marks the current task as completed.", {})

    return tools

def register_tool(name, func, description, parameters):
    global tools
    tools = [tool for tool in tools if tool["function"]["name"] != name]
    available_functions[name] = func
    tools.append({
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": parameters,
                "required": list(parameters.keys())
            }
        }
    })
    print(f"{Colors.OKGREEN}{Colors.BOLD}Registered tool:{Colors.ENDC} {name}")

def create_or_update_tool(name, code, description, parameters):
    try:
        exec(code, globals())
        register_tool(name, globals()[name], description, parameters)
        return f"Tool '{name}' created/updated successfully."
    except Exception as e:
        return f"Error creating/updating tool '{name}': {e}"

def call_tool(function_name, args):
    func = available_functions.get(function_name)
    if not func:
        print(f"{Colors.FAIL}{Colors.BOLD}Error:{Colors.ENDC} Tool '{function_name}' not found.")
        return f"Tool '{function_name}' not found."
    try:
        print(f"{Colors.OKBLUE}{Colors.BOLD}Calling tool:{Colors.ENDC} {function_name} with args: {args}")
        result = func(**args)
        print(f"{Colors.OKCYAN}{Colors.BOLD}Result of {function_name}:{Colors.ENDC} {result}")
        return result
    except Exception as e:
        print(f"{Colors.FAIL}{Colors.BOLD}Error:{Colors.ENDC} Error executing '{function_name}': {e}")
        return f"Error executing '{function_name}': {e}"

def task_completed():
    return "Task marked as completed."
