import os
from dotenv import load_dotenv
from config.settings import initialize_config
from tools.manager import initialize_tools
from ai.model import initialize_ai_model
from cli.interface import display_welcome_message, get_user_task
from core.engine import run_main_loop

def main():
    # Load environment variables
    load_dotenv()

    # Initialize configuration
    config = initialize_config()

    # Initialize tools
    tools = initialize_tools()

    # Initialize AI model
    ai_model = initialize_ai_model(config['model_name'])

    # Display welcome message
    display_welcome_message()

    # Get user task
    user_task = get_user_task()

    # Run main loop
    run_main_loop(user_task, ai_model, tools, config)

if __name__ == "__main__":
    main()
