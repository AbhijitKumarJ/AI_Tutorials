I'll analyze the BabyAGI 2o codebase and recreate it as a project with multiple modules. I'll start by creating a plan, then outline the project file layout, provide individual file descriptions, and finally create the individual files as separate artifacts.

Let's begin with the plan:

1. Analyze the existing codebase structure and functionality
2. Identify core components and potential modules
3. Design a modular project structure
4. Create a project file layout
5. Describe each file's purpose and contents
6. Implement individual files as separate artifacts

Now, let's proceed with each step:

1. Analyzing the existing codebase:
The current BabyAGI 2o project consists of a single main.py file that contains all the functionality. It includes tool management, user interaction, AI model interaction, and the main execution loop. The project also has a README.md file for documentation and a LICENSE file.

2. Identifying core components and potential modules:
Based on the analysis, we can identify the following core components:
- Configuration and environment setup
- Tool management
- AI model interaction
- User interaction
- Main execution loop
- Utility functions (e.g., color formatting, package installation)

3. Designing a modular project structure:
We'll reorganize the project into the following modules:
- config: For configuration and environment setup
- tools: For tool management and registration
- ai: For AI model interaction
- cli: For user interaction and command-line interface
- core: For the main execution loop and core functionality
- utils: For utility functions

4. Project file layout:
Here's the proposed file layout for the modular BabyAGI 2o project:

```
babyagi2o/
│
├── config/
│   ├── __init__.py
│   └── settings.py
│
├── tools/
│   ├── __init__.py
│   └── manager.py
│
├── ai/
│   ├── __init__.py
│   └── model.py
│
├── cli/
│   ├── __init__.py
│   └── interface.py
│
├── core/
│   ├── __init__.py
│   └── engine.py
│
├── utils/
│   ├── __init__.py
│   └── helpers.py
│
├── main.py
├── requirements.txt
├── README.md
└── LICENSE
```

5. Individual file descriptions:

config/settings.py:
This file will contain configuration settings for the project, including environment variable handling, default values, and any other global configuration options.

tools/manager.py:
This file will handle tool registration, creation, updating, and execution. It will include functions like register_tool, create_or_update_tool, and call_tool.

ai/model.py:
This file will manage interactions with the AI model, including sending messages and processing responses. It will use the litellm library for model interactions.

cli/interface.py:
This file will handle user input and output, including displaying colored messages and prompting for user input.

core/engine.py:
This file will contain the main execution loop and core functionality of BabyAGI 2o, orchestrating the interactions between different modules.

utils/helpers.py:
This file will include utility functions such as color formatting, package installation, and any other helper functions used across the project.

main.py:
This file will serve as the entry point for the application, importing and initializing the necessary modules and starting the main execution loop.

6. Implementing individual files as artifacts:

Now, I'll create each file as a separate artifact, starting with the main.py file.



```python
import os
from dotenv import load_dotenv
from config.settings import initialize_config
from tools.manager import initialize_tools
from ai.model import initialize_ai_model
from cli.interface import display_welcome_message, get_user_task
from core.engine import run_main_loop

def main():
    # Load environment variables
    load_dotenv()

    # Initialize configuration
    config = initialize_config()

    # Initialize tools
    tools = initialize_tools()

    # Initialize AI model
    ai_model = initialize_ai_model(config['model_name'])

    # Display welcome message
    display_welcome_message()

    # Get user task
    user_task = get_user_task()

    # Run main loop
    run_main_loop(user_task, ai_model, tools, config)

if __name__ == "__main__":
    main()

```

Now, let's create the config/settings.py file:



```python
import os

def initialize_config():
    config = {
        'model_name': os.environ.get('LITELLM_MODEL', 'anthropic/claude-3-5-sonnet-20240620'),
        'max_iterations': 50,
        'max_tool_output_length': 5000,
        'available_api_keys': _get_available_api_keys(),
    }
    return config

def _get_available_api_keys():
    api_key_patterns = ['API_KEY', 'ACCESS_TOKEN', 'SECRET_KEY', 'TOKEN', 'APISECRET']
    return [key for key in os.environ.keys() if any(pattern in key.upper() for pattern in api_key_patterns)]

# ANSI escape codes for color and formatting
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

```

Next, let's create the tools/manager.py file:



```python
import json
from config.settings import Colors
from utils.helpers import install_package, serialize_tool_result

tools = []
available_functions = {}

def initialize_tools():
    register_tool("create_or_update_tool", create_or_update_tool, "Creates or updates a tool with the specified name, code, description, and parameters.", {
        "name": {"type": "string", "description": "The tool name."},
        "code": {"type": "string", "description": "The Python code for the tool."},
        "description": {"type": "string", "description": "A description of the tool."},
        "parameters": {
            "type": "object",
            "description": "A dictionary defining the parameters for the tool.",
            "additionalProperties": {
                "type": "object",
                "properties": {
                    "type": {"type": "string", "description": "Data type of the parameter."},
                    "description": {"type": "string", "description": "Description of the parameter."}
                },
                "required": ["type", "description"]
            }
        }
    })

    register_tool("install_package", install_package, "Installs a Python package using pip.", {
        "package_name": {"type": "string", "description": "The name of the package to install."}
    })

    register_tool("task_completed", task_completed, "Marks the current task as completed.", {})

    return tools

def register_tool(name, func, description, parameters):
    global tools
    tools = [tool for tool in tools if tool["function"]["name"] != name]
    available_functions[name] = func
    tools.append({
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": parameters,
                "required": list(parameters.keys())
            }
        }
    })
    print(f"{Colors.OKGREEN}{Colors.BOLD}Registered tool:{Colors.ENDC} {name}")

def create_or_update_tool(name, code, description, parameters):
    try:
        exec(code, globals())
        register_tool(name, globals()[name], description, parameters)
        return f"Tool '{name}' created/updated successfully."
    except Exception as e:
        return f"Error creating/updating tool '{name}': {e}"

def call_tool(function_name, args):
    func = available_functions.get(function_name)
    if not func:
        print(f"{Colors.FAIL}{Colors.BOLD}Error:{Colors.ENDC} Tool '{function_name}' not found.")
        return f"Tool '{function_name}' not found."
    try:
        print(f"{Colors.OKBLUE}{Colors.BOLD}Calling tool:{Colors.ENDC} {function_name} with args: {args}")
        result = func(**args)
        print(f"{Colors.OKCYAN}{Colors.BOLD}Result of {function_name}:{Colors.ENDC} {result}")
        return result
    except Exception as e:
        print(f"{Colors.FAIL}{Colors.BOLD}Error:{Colors.ENDC} Error executing '{function_name}': {e}")
        return f"Error executing '{function_name}': {e}"

def task_completed():
    return "Task marked as completed."

```

Now, let's create the ai/model.py file:



```python
from litellm import completion
from config.settings import Colors

def initialize_ai_model(model_name):
    return AIModel(model_name)

class AIModel:
    def __init__(self, model_name):
        self.model_name = model_name

    def get_completion(self, messages, tools):
        try:
            response = completion(model=self.model_name, messages=messages, tools=tools, tool_choice="auto")
            return response.choices[0].message
        except Exception as e:
            print(f"{Colors.FAIL}{Colors.BOLD}Error:{Colors.ENDC} Failed to get completion from AI model: {e}")
            return None

    def process_response(self, response_message, messages):
        if response_message.content:
            print(f"{Colors.OKCYAN}{Colors.BOLD}LLM Response:{Colors.ENDC}\n{response_message.content}\n")
        messages.append(response_message)
        return messages, response_message.tool_calls if hasattr(response_message, 'tool_calls') else None

```

Next, let's create the cli/interface.py file:



```python
from config.settings import Colors

def display_welcome_message():
    print(f"{Colors.HEADER}{Colors.BOLD}Welcome to BabyAGI 2o!{Colors.ENDC}")
    print("This autonomous agent will attempt to complete your task by creating and using tools iteratively.")
    print("Let's get started!\n")

def get_user_task():
    return input(f"{Colors.BOLD}Please describe the task you want to complete: {Colors.ENDC}")

def display_iteration_start(iteration):
    print(f"\n{Colors.HEADER}{Colors.BOLD}Iteration {iteration + 1} running...{Colors.ENDC}")

def display_task_completion():
    print(f"\n{Colors.OKGREEN}{Colors.BOLD}Task completed.{Colors.ENDC}")

def display_max_iterations_reached():
    print(f"\n{Colors.WARNING}{Colors.BOLD}Max iterations reached.{Colors.ENDC}")

def display_error(error_message):
    print(f"{Colors.FAIL}{Colors.BOLD}Error:{Colors.ENDC} {error_message}")

```

Now, let's create the core/engine.py file:



```python
import json
from time import sleep
from config.settings import Colors
from cli.interface import display_iteration_start, display_task_completion, display_max_iterations_reached, display_error
from tools.manager import call_tool
from utils.helpers import serialize_tool_result

def run_main_loop(user_task, ai_model, tools, config):
    messages = [{
        "role": "system",
        "content": _generate_system_prompt(config['available_api_keys'])
    }, {"role": "user", "content": user_task}]

    iteration = 0
    while iteration < config['max_iterations']:
        display_iteration_start(iteration)
        try:
            response_message = ai_model.get_completion(messages, tools)
            if not response_message:
                break

            messages, tool_calls = ai_model.process_response(response_message, messages)
            
            if tool_calls:
                for tool_call in tool_calls:
                    function_name = tool_call.function.name
                    args = json.loads(tool_call.function.arguments)
                    tool_result = call_tool(function_name, args)
                    serialized_tool_result = serialize_tool_result(tool_result, config['max_tool_output_length'])
                    messages.append({
                        "role": "tool",
                        "name": function_name,
                        "tool_call_id": tool_call.id,
                        "content": serialized_tool_result
                    })
                if 'task_completed' in [tc.function.name for tc in tool_calls]:
                    display_task_completion()
                    break
        except Exception as e:
            display_error(f"Error in main loop: {e}")
        
        iteration += 1
        sleep(2)
    
    if iteration >= config['max_iterations']:
        display_max_iterations_reached()

def _generate_system_prompt(available_api_keys):
    if available_api_keys:
        api_keys_info = "Available API keys:\n" + "\n".join(f"- {key}" for key in available_api_keys) + "\n\n"
    else:
        api_keys_info = "No API keys are available.\n\n"

    return (
        "You are an AI assistant designed to iteratively build and execute Python functions using tools provided to you. "
```














Certainly! I'll continue with the core/engine.py file and then move on to the remaining files.



```python
import json
from time import sleep
from config.settings import Colors
from cli.interface import display_iteration_start, display_task_completion, display_max_iterations_reached, display_error
from tools.manager import call_tool
from utils.helpers import serialize_tool_result

def run_main_loop(user_task, ai_model, tools, config):
    messages = [{
        "role": "system",
        "content": _generate_system_prompt(config['available_api_keys'])
    }, {"role": "user", "content": user_task}]

    iteration = 0
    while iteration < config['max_iterations']:
        display_iteration_start(iteration)
        try:
            response_message = ai_model.get_completion(messages, tools)
            if not response_message:
                break

            messages, tool_calls = ai_model.process_response(response_message, messages)
            
            if tool_calls:
                for tool_call in tool_calls:
                    function_name = tool_call.function.name
                    args = json.loads(tool_call.function.arguments)
                    tool_result = call_tool(function_name, args)
                    serialized_tool_result = serialize_tool_result(tool_result, config['max_tool_output_length'])
                    messages.append({
                        "role": "tool",
                        "name": function_name,
                        "tool_call_id": tool_call.id,
                        "content": serialized_tool_result
                    })
                if 'task_completed' in [tc.function.name for tc in tool_calls]:
                    display_task_completion()
                    break
        except Exception as e:
            display_error(f"Error in main loop: {e}")
        
        iteration += 1
        sleep(2)
    
    if iteration >= config['max_iterations']:
        display_max_iterations_reached()

def _generate_system_prompt(available_api_keys):
    if available_api_keys:
        api_keys_info = "Available API keys:\n" + "\n".join(f"- {key}" for key in available_api_keys) + "\n\n"
    else:
        api_keys_info = "No API keys are available.\n\n"

    return (
        "You are an AI assistant designed to iteratively build and execute Python functions using tools provided to you. "
        "Your task is to complete the requested task by creating and using tools in a loop until the task is fully done. "
        "Do not ask for user input until you find it absolutely necessary. If you need required information that is likely available online, create the required tools to find this information. "
        f"Here are API keys you have access to: {api_keys_info}"
        "If you do not know how to use an API, look up the documentation and find examples.\n\n"
        "Your workflow should include:\n"
        "- Creating or updating tools with all required arguments.\n"
        "- Using 'install_package' when a required library is missing.\n"
        "- Using created tools to progress towards completing the task.\n"
        "- When creating or updating tools, provide the complete code as it will be used without any edits.\n"
        "- Handling any errors by adjusting your tools or arguments as necessary.\n"
        "- Being token-efficient: avoid returning excessively long outputs. If a tool returns a large amount of data, consider summarizing it or returning only relevant parts.\n"
        "- Prioritize using tools that you have access to via the available API keys.\n"
        "- Signaling task completion with 'task_completed()' when done.\n"
        "\nPlease ensure that all function calls include all required parameters, and be mindful of token limits when handling tool outputs."
    )

```

Now, let's create the utils/helpers.py file:



```python
import json
import subprocess
import sys
from config.settings import Colors

def serialize_tool_result(tool_result, max_length):
    try:
        serialized_result = json.dumps(tool_result)
    except TypeError:
        serialized_result = str(tool_result)
    if len(serialized_result) > max_length:
        return serialized_result[:max_length] + f"\n\n{Colors.WARNING}(Note: Result was truncated to {max_length} characters out of {len(serialized_result)} total characters.){Colors.ENDC}"
    else:
        return serialized_result

def install_package(package_name):
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
        return f"Package '{package_name}' installed successfully."
    except Exception as e:
        return f"Error installing package '{package_name}': {e}"

```

Now, let's create the requirements.txt file:



```text
litellm==1.15.3
python-dotenv==1.0.0

```

Finally, let's update the README.md file to reflect the new project structure:





# BabyAGI 2o

**BabyAGI 2o** - *the simplest self-building autonomous agent.*

BabyAGI 2o is an exploration into creating the simplest self-building autonomous agent. It aims to iteratively build itself by creating and registering tools as required to complete tasks provided by the user.

## Features

- **Simple Autonomous Agent**: Capable of building and updating tools to solve user-defined tasks.
- **Dynamic Tool Creation**: The agent creates and updates its tools, enabling it to solve increasingly complex tasks without human intervention.
- **Package Management**: Automatically installs required packages for tools.
- **Error Handling and Iteration**: Handles errors gracefully, learns from them, and continues iterating towards task completion.
- **Function Storage**: Functions are registered dynamically, allowing them to be reused in future tasks.
- **Model Flexibility**: Compatible with multiple models via `litellm`, as long as they support tool calling.

## Project Structure

```
babyagi2o/
│
├── config/
│   ├── __init__.py
│   └── settings.py
│
├── tools/
│   ├── __init__.py
│   └── manager.py
│
├── ai/
│   ├── __init__.py
│   └── model.py
│
├── cli/
│   ├── __init__.py
│   └── interface.py
│
├── core/
│   ├── __init__.py
│   └── engine.py
│
├── utils/
│   ├── __init__.py
│   └── helpers.py
│
├── main.py
├── requirements.txt
├── README.md
└── LICENSE
```

## Getting Started

### Prerequisites

- Python 3.7 or higher
- `pip` package manager

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/babyagi2o.git
   cd babyagi2o
   ```

2. Create a virtual environment (optional but recommended):
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows, use venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

### Setting Environment Variables

Set the following environment variables:

- `LITELLM_MODEL`: The AI model to use (e.g., `gpt-4`, `claude-2`)
- API key for your chosen model (e.g., `OPENAI_API_KEY` or `ANTHROPIC_API_KEY`)

You can set these in a `.env` file in the project root:

```
LITELLM_MODEL=your_chosen_model
OPENAI_API_KEY=your_api_key
```

### Usage

Run the application:

```bash
python main.py
```

Follow the prompts to enter your task and watch BabyAGI 2o work on completing it.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.


This completes the recreation of the BabyAGI 2o project as a modular structure. The project now has a clear organization with separate modules for different functionalities, making it easier to maintain and extend. The main.py file serves as the entry point, orchestrating the different components defined in the other modules.

Here's a summary of the changes and improvements:

1. Modular Structure: The project is now organized into logical modules (config, tools, ai, cli, core, utils), each responsible for a specific aspect of the system.

2. Configuration Management: The config/settings.py file centralizes all configuration settings, making it easier to manage and update global parameters.

3. Tool Management: The tools/manager.py file provides a clean interface for registering, creating, updating, and calling tools.

4. AI Model Interaction: The ai/model.py file encapsulates all interactions with the AI model, providing a clear API for the rest of the system.

5. User Interface: The cli/interface.py file handles all user interactions, improving the separation of concerns.

6. Core Engine: The core/engine.py file contains the main execution loop, orchestrating the interactions between different components.

7. Utility Functions: Common utility functions are now centralized in utils/helpers.py, promoting code reuse and maintainability.

8. Updated Documentation: The README.md file has been updated to reflect the new project structure and provide clear instructions for setup and usage.

This modular structure allows for easier testing, maintenance, and future extensions to the BabyAGI 2o project.