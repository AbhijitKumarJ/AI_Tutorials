import os

def initialize_config():
    config = {
        'model_name': os.environ.get('LITELLM_MODEL', 'anthropic/claude-3-5-sonnet-20240620'),
        'max_iterations': 50,
        'max_tool_output_length': 5000,
        'available_api_keys': _get_available_api_keys(),
    }
    return config

def _get_available_api_keys():
    api_key_patterns = ['API_KEY', 'ACCESS_TOKEN', 'SECRET_KEY', 'TOKEN', 'APISECRET']
    return [key for key in os.environ.keys() if any(pattern in key.upper() for pattern in api_key_patterns)]

# ANSI escape codes for color and formatting
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
