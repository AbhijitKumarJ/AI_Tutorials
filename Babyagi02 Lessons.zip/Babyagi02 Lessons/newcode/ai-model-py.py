from litellm import completion
from config.settings import Colors

def initialize_ai_model(model_name):
    return AIModel(model_name)

class AIModel:
    def __init__(self, model_name):
        self.model_name = model_name

    def get_completion(self, messages, tools):
        try:
            response = completion(model=self.model_name, messages=messages, tools=tools, tool_choice="auto")
            return response.choices[0].message
        except Exception as e:
            print(f"{Colors.FAIL}{Colors.BOLD}Error:{Colors.ENDC} Failed to get completion from AI model: {e}")
            return None

    def process_response(self, response_message, messages):
        if response_message.content:
            print(f"{Colors.OKCYAN}{Colors.BOLD}LLM Response:{Colors.ENDC}\n{response_message.content}\n")
        messages.append(response_message)
        return messages, response_message.tool_calls if hasattr(response_message, 'tool_calls') else None
