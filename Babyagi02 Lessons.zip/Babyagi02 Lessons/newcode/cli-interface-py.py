from config.settings import Colors

def display_welcome_message():
    print(f"{Colors.HEADER}{Colors.BOLD}Welcome to BabyAGI 2o!{Colors.ENDC}")
    print("This autonomous agent will attempt to complete your task by creating and using tools iteratively.")
    print("Let's get started!\n")

def get_user_task():
    return input(f"{Colors.BOLD}Please describe the task you want to complete: {Colors.ENDC}")

def display_iteration_start(iteration):
    print(f"\n{Colors.HEADER}{Colors.BOLD}Iteration {iteration + 1} running...{Colors.ENDC}")

def display_task_completion():
    print(f"\n{Colors.OKGREEN}{Colors.BOLD}Task completed.{Colors.ENDC}")

def display_max_iterations_reached():
    print(f"\n{Colors.WARNING}{Colors.BOLD}Max iterations reached.{Colors.ENDC}")

def display_error(error_message):
    print(f"{Colors.FAIL}{Colors.BOLD}Error:{Colors.ENDC} {error_message}")
