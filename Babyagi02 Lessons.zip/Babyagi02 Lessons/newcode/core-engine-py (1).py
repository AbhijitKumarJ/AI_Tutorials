import json
from time import sleep
from config.settings import Colors
from cli.interface import display_iteration_start, display_task_completion, display_max_iterations_reached, display_error
from tools.manager import call_tool
from utils.helpers import serialize_tool_result

def run_main_loop(user_task, ai_model, tools, config):
    messages = [{
        "role": "system",
        "content": _generate_system_prompt(config['available_api_keys'])
    }, {"role": "user", "content": user_task}]

    iteration = 0
    while iteration < config['max_iterations']:
        display_iteration_start(iteration)
        try:
            response_message = ai_model.get_completion(messages, tools)
            if not response_message:
                break

            messages, tool_calls = ai_model.process_response(response_message, messages)
            
            if tool_calls:
                for tool_call in tool_calls:
                    function_name = tool_call.function.name
                    args = json.loads(tool_call.function.arguments)
                    tool_result = call_tool(function_name, args)
                    serialized_tool_result = serialize_tool_result(tool_result, config['max_tool_output_length'])
                    messages.append({
                        "role": "tool",
                        "name": function_name,
                        "tool_call_id": tool_call.id,
                        "content": serialized_tool_result
                    })
                if 'task_completed' in [tc.function.name for tc in tool_calls]:
                    display_task_completion()
                    break
        except Exception as e:
            display_error(f"Error in main loop: {e}")
        
        iteration += 1
        sleep(2)
    
    if iteration >= config['max_iterations']:
        display_max_iterations_reached()

def _generate_system_prompt(available_api_keys):
    if available_api_keys:
        api_keys_info = "Available API keys:\n" + "\n".join(f"- {key}" for key in available_api_keys) + "\n\n"
    else:
        api_keys_info = "No API keys are available.\n\n"

    return (
        "You are an AI assistant designed to iteratively build and execute Python functions using tools provided to you. "
        "Your task is to complete the requested task by creating and using tools in a loop until the task is fully done. "
        "Do not ask for user input until you find it absolutely necessary. If you need required information that is likely available online, create the required tools to find this information. "
        f"Here are API keys you have access to: {api_keys_info}"
        "If you do not know how to use an API, look up the documentation and find examples.\n\n"
        "Your workflow should include:\n"
        "- Creating or updating tools with all required arguments.\n"
        "- Using 'install_package' when a required library is missing.\n"
        "- Using created tools to progress towards completing the task.\n"
        "- When creating or updating tools, provide the complete code as it will be used without any edits.\n"
        "- Handling any errors by adjusting your tools or arguments as necessary.\n"
        "- Being token-efficient: avoid returning excessively long outputs. If a tool returns a large amount of data, consider summarizing it or returning only relevant parts.\n"
        "- Prioritize using tools that you have access to via the available API keys.\n"
        "- Signaling task completion with 'task_completed()' when done.\n"
        "\nPlease ensure that all function calls include all required parameters, and be mindful of token limits when handling tool outputs."
    )
